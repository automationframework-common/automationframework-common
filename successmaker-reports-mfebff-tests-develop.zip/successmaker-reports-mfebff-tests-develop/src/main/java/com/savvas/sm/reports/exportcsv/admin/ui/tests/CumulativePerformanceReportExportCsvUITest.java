package com.savvas.sm.reports.exportcsv.admin.ui.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformanceReportViewerPage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.DemographicFilters;
import com.savvas.sm.reports.constants.ReportsUIConstants.ExportCsvOptions;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.ReportDataCreation;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.CPRExportCSVConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;

import io.restassured.response.Response;

public class CumulativePerformanceReportExportCsvUITest extends EnvProperties {

    private String smUrl;
    private String browser;

    private String districtAdminUsername;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    private String districtAdminUserId;
    private String districtId;

    private String flexSchool;
    private String flexSchoolId;
    private String mathSchool;
    private String mathSchoolId;

    private String teacherId;
    private String teacherUsername;
    private String teacherName;
    private String studentUsername;
    private String studentDemographic;

    RBSUtils rbsUtils = new RBSUtils();
    private Map<String, Object> saveReportOptionalFilters = new HashMap<>();
    private Map<String, Object> optionalFilter = new HashMap<>();
    private Map<String, String> headers = new HashMap<>();
    private List<Map<String, String>> defaultCsvDataApiSingleOrg = new ArrayList<>();
    private List<Map<String, String>> customCsvDataApiSingleOrg = new ArrayList<>();
    private List<Map<String, String>> defaultCsvDataApiMultiOrgs = new ArrayList<>();
    private List<Map<String, String>> customCsvDataApiMultiOrgs = new ArrayList<>();

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        districtId = configProperty.getProperty( "district_ID" ).trim();
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        flexSchoolId = rbsUtils.getOrganizationIDByName( districtId, flexSchool );

        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        mathSchoolId = rbsUtils.getOrganizationIDByName( districtId, mathSchool );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        teacherUsername = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 2, usernameSuffixTest );
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );
        String teacherDetails = rbsUtils.getUser( teacherId );
        teacherName = SMUtils.getKeyValueFromResponse( teacherDetails, "firstAndLastName" ) + " (" + mathSchool + ")";

        studentUsername = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 2, 3, usernameSuffixTest );
        String studentDetails = rbsUtils.getUserWithUserService( rbsUtils.getUserIDByUserName( studentUsername ) );
        studentDemographic = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( studentDetails, "userMetaData,demographics" ), "migrantStatus" );

        districtAdminUsername = ReportDataCollection.districtAdmin;
        districtAdminUserId = rbsUtils.getUserIDByUserName( districtAdminUsername );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + rbsUtils.getAccessToken( districtAdminUsername, password ) );
        headers.put( Constants.USERID_SM_HEADER, districtAdminUserId );
        headers.put( Constants.ORGID_SM_HEADER, districtId );

        getDefaultCsvDataFromApiForSingleOrg();
        getCustomCsvDataFromApiForSingleOrg();

        optionalFilter.put( "filterByTeacher", teacherId );
        getDefaultCsvDataFromApiForMultiOrgs();
        getCustomCsvDataFromApiForMultiOrgs();
    }

    @Test ( description = "Verify Export CSV popup when selecting single org in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest01() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest01 - Verify Export CSV popup when selecting single org in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            List<String> exportOptions = exportPopup.getAllExportTypeLabels();

            Log.assertThat( exportOptions.containsAll( Arrays.asList( ExportCsvOptions.EXPORT_DEFAULT_COLUMNS.toString(), ExportCsvOptions.EXPORT_SELECTED_COLUMNS.toString() ) ),
                    "Export options are displayed as expected when selecting single organization", "Export options are not displayed as expected when selecting single organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Export CSV popup when selecting multiple orgs in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest02() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest02 - Verify Export CSV popup when selecting multiple orgs in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            List<String> exportOptions = exportPopup.getAllExportTypeLabels();

            Log.assertThat( exportOptions.containsAll( ExportCsvOptions.EXPORT_OPTION_LIST ), "Export options are displayed as expected when selecting multiple organizations",
                    "Export options are not displayed as expected when selecting multiple organizations" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Export CSV popup when selecting All Selected Organizations", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest03() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest03 - Verify Export CSV popup when selecting All Selected Organizations" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            List<String> exportOptions = exportPopup.getAllExportTypeLabels();

            Log.assertThat( exportOptions.containsAll( ExportCsvOptions.EXPORT_OPTION_LIST ), "Export options are displayed as expected when selecting All Selected Organizations",
                    "Export options are not displayed as expected when selecting All Selected Organizations" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Export CSV popup when selecting Current Organization", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest04() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest04 - Verify Export CSV popup when selecting Current Organization" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickRadioButton( ExportCsvOptions.CURRENT_ORGANIZATIONS );
            List<String> exportOptions = exportPopup.getAllExportTypeLabels();

            Log.assertThat( exportOptions.containsAll( ExportCsvOptions.EXPORT_OPTION_LIST ), "Export options are displayed as expected when selecting Current Organization",
                    "Export options are not displayed as expected when selecting Current Organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Export CSV popup when selecting Export selected columns under Current Organization", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest05() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest05 - Verify Export CSV popup when selecting Export selected columns under Current Organization" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickRadioButton( ExportCsvOptions.EXPORT_SELECTED_COLUMNS );

            List<String> exportOptions = exportPopup.getAllAvailableColumns();

            Log.assertThat( exportOptions.containsAll( ExportCsvOptions.MATH_EXPORT_SELECTED_COLUMN_LIST ), "Export options are displayed as expected when selecting Current Organization",
                    "Export options are not displayed as expected when selecting Current Organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify default csv file is exported when selecting single org in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest06() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest06 - Verify default csv file is exported when selecting single org in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            String csvDataUI = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( splitCsvData( csvDataUI, ReportsUIConstants.DEFAULT ).stream().anyMatch( uiData -> defaultCsvDataApiSingleOrg.contains( uiData ) ), "Default csv file is exported as expected when selecting single org",
                    "Default csv file is not exported as expected when selecting single org" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify custom csv file is exported when selecting single org in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest07() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest07 - Verify custom csv file is exported when selecting single org in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();

            exportPopup.clickRadioButton( ExportCsvOptions.EXPORT_SELECTED_COLUMNS );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );

            Log.assertThat( splitCsvData( csvDataUi, ReportsUIConstants.CUSTOM ).stream().anyMatch( uiData -> customCsvDataApiSingleOrg.contains( uiData ) ), "Default csv file is exported as expected when selecting single org",
                    "Default csv file is not exported as expected when selecting single org" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify default csv file is exported for All Selected Organizations when selecting multiple orgs in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest08() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest08 - Verify default csv file is exported for All Selected Organizations when selecting multiple orgs in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( splitCsvData( csvDataUi, ReportsUIConstants.DEFAULT ).stream().anyMatch( uiData -> defaultCsvDataApiMultiOrgs.contains( uiData ) ), "Default csv file is exported as expected when selecting multiple orgs",
                    "Default csv file is not exported as expected when selecting multiple orgs" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify custom csv file is exported for All Selected Organizations when selecting multiple orgs in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest09() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest09 - Verify custom csv file is exported for All Selected Organizations when selecting multiple orgs in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickRadioButton( ExportCsvOptions.EXPORT_SELECTED_COLUMNS );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( splitCsvData( csvDataUi, ReportsUIConstants.CUSTOM ).stream().anyMatch( uiData -> customCsvDataApiMultiOrgs.contains( uiData ) ), "Custom csv file is exported as expected when selecting multiple orgs",
                    "Custom csv file is not exported as expected when selecting multiple orgs" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify default csv file is exported for Current Organization when selecting multiple orgs in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest10() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest10 - Verify default csv file is exported for Current Organization when selecting multiple orgs in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickRadioButton( ExportCsvOptions.CURRENT_ORGANIZATIONS );
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );

            Log.assertThat( splitCsvData( csvDataUi, ReportsUIConstants.DEFAULT ).stream().anyMatch( uiData -> defaultCsvDataApiMultiOrgs.contains( uiData ) ), "Default csv file is exported as expected when selecting multiple orgs",
                    "Default csv file is not exported as expected when selecting multiple orgs" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify custom csv file is exported for Current Organization when selecting multiple orgs in report filter page", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest11() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest11 - Verify custom csv file is exported for Current Organization when selecting multiple orgs in report filter page" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickRadioButton( ExportCsvOptions.CURRENT_ORGANIZATIONS );
            exportPopup.clickRadioButton( ExportCsvOptions.EXPORT_SELECTED_COLUMNS );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );

            Log.assertThat( splitCsvData( csvDataUi, ReportsUIConstants.CUSTOM ).stream().anyMatch( uiData -> customCsvDataApiMultiOrgs.contains( uiData ) ), "Default csv file is exported as expected when selecting multiple orgs",
                    "Default csv file is not exported as expected when selecting multiple orgs" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Export CSV popup when selecting single org in report filter page whick doesn't have any data", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest12() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest12 - Verify Export CSV popup when selecting single org in report filter page whick doesn't have any data" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.READING );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandStudentDemographics();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,
                    Arrays.asList( DemographicFilters.MIGRANT_STATUS.stream().filter( value -> !value.equalsIgnoreCase( studentDemographic ) ).findFirst().get() ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( ExportCsvUtils.splitCSVDataFromResponse( csvDataUi ).get( 0 ).get( "Assignment Name/Course Name" ).equals( "" ), "Csv file is exported as expected when selecting an org with no data",
                    "Csv file is exported as expected when selecting an org with no data" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Export CSV popup when selecting multiple orgs in report filter page and one of the selected org doesn't have any data", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest13() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest13 - Verify Export CSV popup when selecting multiple orgs in report filter page and one of the selected org doesn't have any data" );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );

            Log.assertThat( splitCsvData( csvDataUi, ReportsUIConstants.DEFAULT ).stream().anyMatch( uiData -> defaultCsvDataApiMultiOrgs.contains( uiData ) ), "Csv file is exported as expected when selecting multiple orgs",
                    "Csv file is not exported as expected when selecting multiple orgs" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify csv file is exported when selecting a group which is associated with two or more teachers.", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest14() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest14 - Verify csv file is exported when selecting a group which is associated with two or more teachers." );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportDataCreation.SHARED_GROUP + " (" + flexSchool + ")" ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );

            Log.assertThat( ExportCsvUtils.splitCSVDataFromResponse( csvDataUi ).get( 0 ).get( "Group" ).equals( ReportDataCreation.SHARED_GROUP ), "Csv file is exported as expected when selecting a group which is associated with two or more teachers",
                    "Csv file is not exported as expected when selecting a group which is associated with two or more teachers" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify csv file is exported when selecting a group which is associated with two or more Students.", groups = { "smoke_test_case", "SMK-71302", "Admin Cumulative Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminCprExportCsvTest15() throws Exception {
        SMUtils.logDescriptionTC( "tcAdminCprExportCsvTest15 - Verify csv file is exported when selecting a group which is associated with two or more Students." );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            //To select the teacher option in Teacher dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportDataCreation.SHARED_GROUP + " (" + flexSchool + ")" ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver );

            ExportPopupComponent exportPopup = cpReportViewerPage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickRadioButton( ExportCsvOptions.EXPORT_SELECTED_COLUMNS );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.clickOkButton();

            String csvDataUi = ExportCsvUtils.getCsvDataFromBS( driver );

            Log.assertThat( ExportCsvUtils.splitCSVDataFromResponse( csvDataUi ).get( 0 ).get( "studentUsername" ).equals( studentUsername ), "Csv file is exported as expected when selecting a group which is associated with two or more Students",
                    "Csv file is not exported as expected when selecting a group which is associated with two or more Students" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    private void getDefaultCsvDataFromApiForSingleOrg() throws Exception {
        // Get CSV data from API
        Response saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( flexSchoolId ), "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
        Response response = postCPRExportCSVAPI( headers, Arrays.asList( flexSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );

        final WebDriver chromeDriver = WebDriverFactory.get( browser );
        try {
            chromeDriver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
            String csvDataAPI = ExportCsvUtils.getCsvDataFromBS( chromeDriver );

            ExportCsvUtils.splitCSVDataFromResponse( csvDataAPI ).stream().forEach( map -> {
                map.remove( "Report Run" );
                map.remove( "Group" );
                defaultCsvDataApiSingleOrg.add( map );
            } );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            chromeDriver.quit();
        }
    }

    private void getDefaultCsvDataFromApiForMultiOrgs() throws Exception {
        // Get CSV data from API
        Response saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( mathSchoolId, flexSchoolId ), "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
        Response response = postCPRExportCSVAPI( headers, Arrays.asList( mathSchoolId, flexSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );

        final WebDriver chromeDriver = WebDriverFactory.get( browser );
        try {
            chromeDriver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
            String csvDataAPI = ExportCsvUtils.getCsvDataFromBS( chromeDriver );

            ExportCsvUtils.splitCSVDataFromResponse( csvDataAPI ).stream().forEach( map -> {
                map.remove( "Report Run" );
                map.remove( "Group" );
                defaultCsvDataApiMultiOrgs.add( map );
            } );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            chromeDriver.quit();
        }
    }

    private void getCustomCsvDataFromApiForSingleOrg() throws Exception {
        // Get CSV data from API
        Response saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( flexSchoolId ), "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
        Response response = postCPRExportCSVAPI( headers, Arrays.asList( flexSchoolId ), "custom", requestId, "01/23/23 - 11:31 AM", Constants.MATH, CPRExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS, optionalFilter );

        final WebDriver chromeDriver = WebDriverFactory.get( browser );
        try {
            chromeDriver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
            String csvDataAPI = ExportCsvUtils.getCsvDataFromBS( chromeDriver );

            ExportCsvUtils.splitCSVDataFromResponse( csvDataAPI ).stream().forEach( map -> {
                map.remove( "reportDate" );
                map.remove( "groupName" );
                map.remove( "exercisesPercentCorrect" );
                customCsvDataApiSingleOrg.add( map );
            } );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            chromeDriver.quit();
        }
    }

    private void getCustomCsvDataFromApiForMultiOrgs() throws Exception {
        // Get CSV data from API
        Response saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( mathSchoolId, flexSchoolId ), "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
        Response response = postCPRExportCSVAPI( headers, Arrays.asList( mathSchoolId, flexSchoolId ), "custom", requestId, "01/23/23 - 11:31 AM", Constants.MATH, CPRExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS, optionalFilter );

        final WebDriver chromeDriver = WebDriverFactory.get( browser );
        try {
            chromeDriver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
            String csvDataAPI = ExportCsvUtils.getCsvDataFromBS( chromeDriver );

            ExportCsvUtils.splitCSVDataFromResponse( csvDataAPI ).stream().forEach( map -> {
                map.remove( "reportDate" );
                map.remove( "groupName" );
                map.remove( "exercisesPercentCorrect" );
                customCsvDataApiMultiOrgs.add( map );
            } );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            chromeDriver.quit();
        }
    }

    private List<Map<String, String>> splitCsvData( String csvData, String exportType ) {
        List<Map<String, String>> splitCsvData = new ArrayList<>();
        if ( exportType.equals( "default" ) ) {
            ExportCsvUtils.splitCSVDataFromResponse( csvData ).stream().forEach( map -> {
                map.remove( "Report Run" );
                map.remove( "Group" );
                splitCsvData.add( map );
            } );
        } else {
            ExportCsvUtils.splitCSVDataFromResponse( csvData ).stream().forEach( map -> {
                map.remove( "reportDate" );
                map.remove( "groupName" );
                map.remove( "exercisesPercentCorrect" );
                splitCsvData.add( map );
            } );
        }
        return splitCsvData;
    }

    /**
     * Csv data API
     * 
     * @param headers
     * @param selectedOrgId
     * @param exportType
     * @param requestId
     * @param reportRun
     * @param subject
     * @param selectedFieldsOrdered
     * @param optionalFilters
     * @return
     * @throws IOException
     */
    public static Response postCPRExportCSVAPI( Map<String, String> headers, List<String> selectedOrgId, String exportType, String requestId, String reportRun, String subject, List<String> selectedFieldsOrdered, Map<String, Object> optionalFilters )
            throws IOException {
        Response response = null;
        try {

            String endPoint = "/export-csv";

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPReportCSVPayload.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", exportType ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", headers.get( Constants.ORGID_SM_HEADER ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.reportRun", reportRun ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterBySchool", selectedOrgId ) );

            if ( exportType.equals( "custom" ) ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFieldsOrdered ) );
            } else {
                if ( subject.equalsIgnoreCase( "Math" ) ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", CPRExportCSVConstants.DEFAULT_MATH_SELECTED_FILTERS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", CPRExportCSVConstants.DEFAULT_READING_SELECTED_FILTERS ) );
                }
            }

            if ( Objects.nonNull( optionalFilters ) ) {
                optionalFilters.keySet().stream().forEach( fieldName -> {
                    if ( ExportCsvConstants.DEMOGRAPHIC_FIELD_VALUES.contains( fieldName ) ) {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterByDemographics." + fieldName, optionalFilters.get( fieldName ) ) );
                    } else {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams." + fieldName, optionalFilters.get( fieldName ) ) );
                    }
                } );
            }
            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

}