package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.admin.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.Constants.Reports;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;

public class CPRTeacherDropdownWithMultipleOrgSelection extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtId;
    private String adminUsername;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String flexSchool;
    private String mathSchool;
    private String flexSchoolId;
    private String mathSchoolId;
    private String adminUserId;
    private String multiOrgTeacher;

    RBSUtils rbsUtils = new RBSUtils();
    ReportAPI reportApi = new ReportAPI();

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );

        adminUsername = ReportDataCollection.districtAdmin;
        adminUserId = rbsUtils.getUserIDByUserName( adminUsername );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        flexSchoolId = rbsUtils.getOrganizationIDByName( districtId, flexSchool );
        mathSchoolId = rbsUtils.getOrganizationIDByName( districtId, flexSchool );

        String multiOrgTeacherDetails = ReportDataCollection.sharedTeacherDetails;
        multiOrgTeacher = SMUtils.getKeyValueFromResponse( multiOrgTeacherDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( multiOrgTeacherDetails, "lastName" );
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection", "smoke_test_case" }, description = "Verify teacher dropdown under optional filter is loaded with all the teachers for the selected school" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection001() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection001 - Verify teacher dropdown under optional filter is loaded with all the teachers for the selected school" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "Available Teachers - " + availableOptionsFromTeacherDropdown );

            // Getting All Teachers of an organization
            HashMap<String, HashMap<String, String>> flexOrgTeacherList =  reportApi.getAllTeachersOfAnOrganization( adminUserId, districtId, adminUsername, Arrays.asList( flexSchoolId ) ).get( flexSchoolId );
            List<String> teacherIdList = new ArrayList<>( flexOrgTeacherList.keySet() );
            List<String> teacherNameList = teacherIdList.stream().map( teacher -> flexOrgTeacherList.get( teacher ).get( "firstName" ) + " " + flexOrgTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( teacherNameList ), "Teacher dropdown under optional filter is loaded with all the teachers for the selected school",
                    "All teachers are not displyed. Expected- " + teacherNameList + "\nActual- " + availableOptionsFromTeacherDropdown );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection", "smoke_test_case" }, description = "Verify teacher dropdown under optional filter is reloaded with all the teachers when any one of the org is selected additionally" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection002() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection002 - Verify teacher dropdown under optional filter is reloaded with all the teachers when any one of the org is selected additionally" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            // Getting All Teachers of an organization
            HashMap<String, HashMap<String, HashMap<String, String>>> mathAndFlexSchoolTeachers = reportApi.getAllTeachersOfAnOrganization( adminUserId, districtId, adminUsername, Arrays.asList( flexSchoolId, mathSchoolId ) );

            HashMap<String, HashMap<String, String>> mathTeacherList = mathAndFlexSchoolTeachers.get( mathSchoolId );
            HashMap<String, HashMap<String, String>> flexTeacherList = mathAndFlexSchoolTeachers.get( flexSchoolId );

            List<String> allTeacherNameList = new ArrayList<>( mathTeacherList.keySet() ).stream().map(
                    teacher -> mathTeacherList.get( teacher ).get( "firstName" ) + " " + mathTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );
            List<String> flexTeacherNameList = new ArrayList<>( flexTeacherList.keySet() ).stream().map(
                    teacher -> flexTeacherList.get( teacher ).get( "firstName" ) + " " + flexTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );

            allTeacherNameList.addAll( flexTeacherNameList );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( allTeacherNameList ), "Teacher dropdown under optional filter is reloaded with all the teachers when selecting multiple schools",
                    "All teachers are not displyed. Expected- " + allTeacherNameList + "\nActual- " + availableOptionsFromTeacherDropdown );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection", "smoke_test_case" }, description = "Verify teacher dropdown under optional filter is reloaded with all the teachers when any one of the org is deselected" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection003() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection003 - Verify teacher dropdown under optional filter is reloaded with all the teachers when any one of the org is deselected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            // Getting All Teachers of an organization
            HashMap<String, HashMap<String, String>> flexOrgTeacherList = reportApi.getAllTeachersOfAnOrganization( adminUserId, districtId, adminUsername, Arrays.asList( flexSchoolId ) ).get( flexSchoolId );
            List<String> teacherIdList = new ArrayList<>( flexOrgTeacherList.keySet() );
            List<String> teacherNameList = teacherIdList.stream().map( teacher -> flexOrgTeacherList.get( teacher ).get( "firstName" ) + " " + flexOrgTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );

            HashSet<String> hashSetUI = new HashSet<>( availableOptionsFromTeacherDropdown );
            HashSet<String> hashSetAPI = new HashSet<>( teacherNameList );
            hashSetUI.removeAll( hashSetAPI );

            Log.message( hashSetUI + "" );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( teacherNameList ), "Teacher dropdown under optional filter is loaded with all the teachers when de-selecting one of the school",
                    "All teachers are not displyed. Expected- " + teacherNameList + "\nActual- " + availableOptionsFromTeacherDropdown );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection",
            "smoke_test_case" }, description = "Verify teacher dropdown should show the teacher once when teacher belongs to multiple schools and both schools are selected in organization dropdown" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection004() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection004 - Verify teacher dropdown should show the teacher once when teacher belongs to multiple schools and both schools are selected in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( Arrays.asList( multiOrgTeacher + " (" + flexSchool + ")", multiOrgTeacher + " (" + mathSchool + ")" ) ),
                    "Teacher associated with multiple schools is displayed when selecting both the schools", "Teacher associated with multiple schools is not displayed when selecting both the schools" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection",
            "smoke_test_case" }, description = "Verify teacher dropdown under optional filter is reloaded with all the teachers when Select All option is selected in Organization dropdown" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection005() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection005 - Verify teacher dropdown under optional filter is reloaded with all the teachers when Select All option is selected in Organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            // Getting All Teachers of an organization
            HashMap<String, HashMap<String, HashMap<String, String>>> mathAndFlexSchoolTeachers = reportApi.getAllTeachersOfAnOrganization( adminUserId, districtId, adminUsername, Arrays.asList( flexSchoolId, mathSchoolId ) );

            HashMap<String, HashMap<String, String>> mathTeacherList = mathAndFlexSchoolTeachers.get( mathSchoolId );
            HashMap<String, HashMap<String, String>> flexTeacherList = mathAndFlexSchoolTeachers.get( flexSchoolId );

            List<String> allTeacherNameList = new ArrayList<>( mathTeacherList.keySet() ).stream().map(
                    teacher -> mathTeacherList.get( teacher ).get( "firstName" ) + " " + mathTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );
            List<String> flexTeacherNameList = new ArrayList<>( flexTeacherList.keySet() ).stream().map(
                    teacher -> flexTeacherList.get( teacher ).get( "firstName" ) + " " + flexTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );

            allTeacherNameList.addAll( flexTeacherNameList );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( allTeacherNameList ), "Teacher dropdown under optional filter is reloaded with all the teachers when selecting multiple schools",
                    "All teachers are not displyed. Expected- " + allTeacherNameList + "\nActual- " + availableOptionsFromTeacherDropdown );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection",
            "smoke_test_case" }, description = "Verify teacher dropdown under optional filter is reloaded with all the teachers when Select All option is deselected in Organization dropdown" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection006() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection006 - Verify teacher dropdown under optional filter is reloaded with all the teachers when Select All option is deselected in Organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            Log.assertThat( availableOptionsFromTeacherDropdown.remove( 0 ).contains( "" ), "Teachers are not disaplyed when all organizations are unselected", "Teachers are disaplyed when all organizations are unselected" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69730", "Teachers - Multi Org Selection", "smoke_test_case" }, description = "Verify multiple organization teachers selection should be retained when saved report option is loaded" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection007() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection007 - Verify multiple organization teachers selection should be retained when saved report option is loaded" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Reports.SELECT_ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> selectedTeachers = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            SaveReportFilterPopup saveReportOptionPopup = cprPage.reportFilterComponent.clickSaveReportOptionButton();

            String filterName = "Specfic Filter" + System.nanoTime();
            Log.message( "Filter Name: " + filterName );

            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            saveReportOptionPopup.clickSaveButton();
            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.clickResetButton();
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL, filterName );
            SMUtils.nap( 5 );

            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> savedTeachers = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            Log.assertThat( savedTeachers.containsAll( selectedTeachers ), "Teachers are retained when saved report option is loaded", "Teachers are not retained when saved report option is loaded" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70084", "Teachers - Multi Org Selection",
            "smoke_test_case" }, description = "Verify the Organization name should display in the teacher dropdown after all the teacher name, if the admin selects single organization in organization dropdown" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection008() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection008 - Verify the Organization name should display in the teacher dropdown after all the teacher name, if the admin selects single organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "Available Teachers - " + availableOptionsFromTeacherDropdown );

            // Getting All Teachers of an organization
            HashMap<String, HashMap<String, String>> flexOrgTeacherList = reportApi.getAllTeachersOfAnOrganization( adminUserId, districtId, adminUsername, Arrays.asList( flexSchoolId ) ).get( flexSchoolId );
            List<String> teacherIdList = new ArrayList<>( flexOrgTeacherList.keySet() );
            List<String> teacherNameList = teacherIdList.stream().map( teacher -> flexOrgTeacherList.get( teacher ).get( "firstName" ) + " " + flexOrgTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( teacherNameList ), "Teacher dropdown under optional filter is loaded with all the teachers for the selected school",
                    "All teachers are not displyed. Expected- " + teacherNameList + "\nActual- " + availableOptionsFromTeacherDropdown );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70084", "Teachers - Multi Org Selection",
            "smoke_test_case" }, description = "Verify the Organization name should display in the teacher dropdown after all the teacher name, if the admin selects multiple organization in organization dropdown" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection009() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection009 - Verify the Organization name should display in the teacher dropdown after all the teacher name, if the admin selects multiple organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            // Getting All Teachers of an organization
            HashMap<String, HashMap<String, HashMap<String, String>>> mathAndFlexSchoolTeachers = reportApi.getAllTeachersOfAnOrganization( adminUserId, districtId, adminUsername, Arrays.asList( flexSchoolId, mathSchoolId ) );

            HashMap<String, HashMap<String, String>> mathTeacherList = mathAndFlexSchoolTeachers.get( mathSchoolId );
            HashMap<String, HashMap<String, String>> flexTeacherList = mathAndFlexSchoolTeachers.get( flexSchoolId );

            List<String> allTeacherNameList = new ArrayList<>( mathTeacherList.keySet() ).stream().map(
                    teacher -> mathTeacherList.get( teacher ).get( "firstName" ) + " " + mathTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );
            List<String> flexTeacherNameList = new ArrayList<>( flexTeacherList.keySet() ).stream().map(
                    teacher -> flexTeacherList.get( teacher ).get( "firstName" ) + " " + flexTeacherList.get( teacher ).get( "lastName" ) + " (" + flexSchool + ")" ).collect( Collectors.toList() );

            allTeacherNameList.addAll( flexTeacherNameList );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( allTeacherNameList ), "Teacher dropdown under optional filter is reloaded with all the teachers when selecting multiple schools",
                    "All teachers are not displyed. Expected- " + allTeacherNameList + "\nActual- " + availableOptionsFromTeacherDropdown );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70084", "Teachers - Multi Org Selection", "smoke_test_case" }, description = "Verify the Organization name should display in the teacher dropdown , if the selected organizations has multiple school teacher" )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection010() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection010 - Verify the Organization name should display in the teacher dropdown , if the selected organizations has multiple school teacher" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            Log.assertThat( availableOptionsFromTeacherDropdown.containsAll( Arrays.asList( multiOrgTeacher + " (" + flexSchool + ")", multiOrgTeacher + " (" + mathSchool + ")" ) ),
                    "Teacher associated with multiple schools is displayed when selecting both the schools", "Teacher associated with multiple schools is not displayed when selecting both the schools" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70084", "Teachers - Multi Org Selection",
            "smoke_test_case" }, description = "Verify the Organization name should display for multi school teacher, if admin selects single organization in organization dropdown." )
    public void tcCPRTeacherDropdownWithMultipleOrgSelection011() throws Exception {

        Log.testCaseInfo( "tcCPRTeacherDropdownWithMultipleOrgSelection011 - Verify the Organization name should display for multi school teacher, if admin selects single organization in organization dropdown." );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> availableOptionsFromTeacherDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            Log.assertThat( availableOptionsFromTeacherDropdown.contains( multiOrgTeacher + " (" + flexSchool + ")" ), "Teacher associated with multiple schools is displayed when selecting both the schools",
                    "Teacher associated with multiple schools is not displayed when selecting both the schools" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    
}
