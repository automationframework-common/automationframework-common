package com.savvas.sm.reports.smoke.admin.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class PerspectiveSchedulingAggregateReport extends LoadableComponent<PerspectiveSchedulingAggregateReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Prescriptive Scheduling Aggregate Report']", AI = false )
    public WebElement txtPerspectiveSchedulingAggregateReportHeader;

    @IFindBy ( how = How.CSS, using = "input#gradek", AI = false )
    public WebElement fldGradeK;

    @IFindBy ( how = How.CSS, using = "input#grade1", AI = false )
    public WebElement fldGrade1;

    @IFindBy ( how = How.CSS, using = "input#grade2", AI = false )
    public WebElement fldGrade2;

    @IFindBy ( how = How.CSS, using = "input#grade3", AI = false )
    public WebElement fldGrade3;

    @IFindBy ( how = How.CSS, using = "input#grade4", AI = false )
    public WebElement fldGrade4;

    @IFindBy ( how = How.CSS, using = "input#grade5", AI = false )
    public WebElement fldGrade5;

    @IFindBy ( how = How.CSS, using = "input#grade6", AI = false )
    public WebElement fldGrade6;

    @IFindBy ( how = How.CSS, using = "input#grade7", AI = false )
    public WebElement fldGrade7;

    @IFindBy ( how = How.CSS, using = "input#grade8", AI = false )
    public WebElement fldGrade8;

    @IFindBy ( how = How.CSS, using = "input#grade9", AI = false )
    public WebElement fldGrade9;

    @IFindBy ( how = How.CSS, using = "input#grade10", AI = false )
    public WebElement fldGrade10;

    @IFindBy ( how = How.CSS, using = "input#grade11", AI = false )
    public WebElement fldGrade11;

    @IFindBy ( how = How.CSS, using = "input#grade12", AI = false )
    public WebElement fldGrade12;

    @IFindBy ( how = How.XPATH, using = "//label[text()=' SET TARGET DATE ']", AI = false )
    public WebElement txtSetTargetDate;

    @IFindBy ( how = How.CSS, using = "div.col.date-container", AI = false )
    public WebElement eleDateContainer;

    @IFindBy ( how = How.XPATH, using = "//*[text()=' SET TARGET LEVEL PER GRADE ']", AI = false )
    public WebElement txtSetTargetLevelPerGrade;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Sort By']", AI = false )
    public WebElement txtSortLabel;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String calDateInput[] = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('#celDateInput')" };
    public String iconDatePicker[] = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('div > cel-icon-button').shadowRoot.querySelector('button > cel-icon')" };
    public String drpDwnAdditionalGroupingshadowDOM[] = { "cel-single-select", "document.querySelector('#additional-grouping').shadowRoot.querySelector('#dropdown')" };
    public String drpDwnSortshadowDOM[] = { "cel-accordion-item", "document.querySelector('#sort-by').shadowRoot.querySelector('#dropdown')" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };

    List<String> expectedGrades = new ArrayList<String>( Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12" ) );
    /* String used for List of Elements inside Methods */

    public String grades = "//label[contains(text(),' Grade ')]";
    public String targetDate = " SET TARGET DATE ";
    public String targetLevelPerGrade = " SET TARGET LEVEL PER GRADE ";
    public String txtAdditionalGroupingDrpdwn = "grade";
    public String txtSortInAdditionalGrouping = "Sort By";
    public String txtSortValueDrpdwn = "school";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtPerspectiveSchedulingAggregateReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public PerspectiveSchedulingAggregateReport() {}

    public PerspectiveSchedulingAggregateReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas Validate Calendar Date Input Field
     * @throws InterruptedException
     */
    public void validateCalendarDateInputField( WebDriver driver ) throws InterruptedException {
        WebElement calDateInput = ShadowDOMUtils.retryAndGetWebElement( driver, this.calDateInput[0], this.calDateInput[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, calDateInput, "Calendar Date Input" );
    }

    /**
     * @author aravindan.srinivas Validate Icon Date Picker
     * @throws InterruptedException
     */
    public void validateIconDatePicker( WebDriver driver ) throws InterruptedException {
        WebElement iconDatePicker = ShadowDOMUtils.retryAndGetWebElement( driver, this.iconDatePicker[0], this.iconDatePicker[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, iconDatePicker, "Icon Date Picker" );
    }

    /**
     * @author aravindan.srinivas verify the text Set Target Date is Displayed
     *         in the web page.
     * @param driver
     */
    public void verifyTextSetTargetDate( WebDriver driver ) {
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSetTargetDate, targetDate, "Set Target Date" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSetTargetDate, "Set Target Date Element" );
    }

    /**
     * @author aravindan.srinivas verify the Set Target Level PerGrade is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSetTargetLevelPerGrade( WebDriver driver ) {
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSetTargetLevelPerGrade, targetLevelPerGrade, "Set Target Level PerGrade" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSetTargetLevelPerGrade, "Set Target Level PerGrade Element" );
    }

    /**
     * @author aravindan.srinivas verify the Date Container is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyDateContainer( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, eleDateContainer, "Date Container Element" );
    }

    /**
     * @author aravindan.srinivas Validate Grade from K to 12
     */
    public void validateGrades( WebDriver driver ) {
        List<WebElement> elements = driver.findElements( By.xpath( grades ) );

        List<String> actualGrades = new ArrayList<String>();
        for ( WebElement ele : elements ) {
            actualGrades.add( ele.getText().trim() );
        }
        Log.assertThat( actualGrades.equals( expectedGrades ), "Grades Matched", "Grades MisMatched!!" );

    }

    /**
     * @author aravindan.srinivas verify the Elements Grade is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyElementGrades( WebDriver driver ) {

        List<WebElement> gradeElement = driver.findElements( By.cssSelector( "input[id*='grade']" ) );

        for ( int i = 0; i < gradeElement.size(); i++ ) {
            String attributeID = gradeElement.get( i ).getAttribute( "id" );
            ReportsBrowserActions.verifyElementIsDisplayed( driver, gradeElement.get( i ), attributeID );
        }
        Log.assertThat( gradeElement.size() == 13, "Grades Count :" + gradeElement.size() + "Is Matched", "Grades Count :" + gradeElement.size() + "Is MisMatched" );
    }

    /**
     * @author aravindan.srinivas validate Additional Grouping drop down Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAdditionalGroupingDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnAdditionalGroupingshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnAdditionalGroupingshadowDOM[0], this.drpDwnAdditionalGroupingshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnAdditionalGroupingshadowDOM, "Additional Grouping Drop Down Field" );
        String attributeValue = drpDwnAdditionalGroupingshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equalsIgnoreCase( txtAdditionalGroupingDrpdwn ), "Selected '" + attributeValue + "' as default value in Additional Grouping Drpdwn Field",
                "'" + attributeValue + "' is not a default value in Additional Grouping Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas verify the text Sort in Optional Filter is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSortInOptionalFilter( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSortLabel, "Sort In Optional Filter" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSortLabel, txtSortInAdditionalGrouping, "Sort In Optional Filter" );
    }

    /**
     * @author aravindan.srinivas validate Sort drop down Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSortDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnSortshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnSortshadowDOM[0], this.drpDwnSortshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnSortshadowDOM, "Sort Drop Down Field" );
        String attributeValue = drpDwnSortshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.trim().equalsIgnoreCase( txtSortValueDrpdwn ), "Selected '" + attributeValue + "' as default value in Sort Drpdwn Field", "'" + attributeValue + "' is not a default value in Sort Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas Validate all the fields and headers present in
     *         the Perspective Scheduling Aggregate Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInPerspectiveSchedulingAggregateReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtPerspectiveSchedulingAggregateReportHeader.getText();
        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        reportsFilterUtils.verifyTextOrganizationsHeader( driver );
        reportsFilterUtils.validateOrgDrpdwnField( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        verifyTextSetTargetDate( driver );
        verifyDateContainer( driver );
        validateCalendarDateInputField( driver );
        validateIconDatePicker( driver );
        verifyTextSetTargetLevelPerGrade( driver );
        validateGrades( driver );
        verifyElementGrades( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );

        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );

        verifyTextSortInOptionalFilter( driver );
        validateSortDrpdwnField( driver );

        // Demographics Filter
        WebElement txtStudentDemographics = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtStudentDemographicsShadowDOM[0], reportsFilterUtils.txtStudentDemographicsShadowDOM[1] );
        SMUtils.click( driver, txtStudentDemographics );

        reportsFilterUtils.verifyTextDisablityStatus( driver );
        reportsFilterUtils.validateDisabilityStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextEnglishLanguageProficiency( driver );
        reportsFilterUtils.validateEnglishLanguageProficiencyDrpdwnField( driver );

        reportsFilterUtils.verifyTextEthnicity( driver );
        reportsFilterUtils.validateEthnicityDrpdwnField( driver );

        reportsFilterUtils.verifyTextMigrantStatus( driver );
        reportsFilterUtils.validateMigrantStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextRace( driver );
        reportsFilterUtils.validateRaceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSpecialServices( driver );
        reportsFilterUtils.validateSpecialServiceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSocioEconomicStatus( driver );
        reportsFilterUtils.validateSocioEconomicStatusDrpdwnField( driver );
    }

    /**
     * @author sathish.suresh Validate PS Aggregate run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validatePSAggregateRunReport( WebDriver driver, String flexSchoolId ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        this.chooseOrganization( driver, flexSchoolId );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        PerspectiveSchedulingReport perspectiveSchedulingReport = new PerspectiveSchedulingReport( driver );
        perspectiveSchedulingReport.selectTargetDate( driver, 3 );
        perspectiveSchedulingReport.SelectGradeAndEnterTheGrade( driver );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sathish.suresh Perscriptive Scheduling Aggregate saved report
     *         Validation
     * @param driver
     * @throws InterruptedException
     */
    public void validatePSAggregateSavedReports( WebDriver driver , String flexSchoolId ) throws InterruptedException {
        Random rnd = new Random();
        int n = 1 + rnd.nextInt();
        String savedReportName = "Automation Validation" + n; // update
        System.out.println( savedReportName );
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Prescriptive Scheduling Aggregate Report" ), "User Landed On Areas Of Growth Report", "User Not Landed On Areas Of Growth Report" );

        WebElement drpdwnSubjectshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnSubjectshadowDOM[0], reportsFilterUtils.drpdwnSubjectshadowDOM[1] );
        WebElement drpdwnCoursesshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnCoursesshadowDOM[0], reportsFilterUtils.drpdwnCoursesshadowDOM[1] );


        this.chooseOrganization( driver, flexSchoolId );
        
        SMUtils.click( driver, drpdwnSubjectshadowDOM );
        Log.message( "User Clicked On Subject Drop Down" );
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelect( driver, drpdwnSubjectshadowDOM, "Math", "Course drop Down" );

        Thread.sleep( 2000 );
        reportsFilterUtils.verifyCourseDropDownIsEnabled( driver, drpdwnCoursesshadowDOM );
        ArrayList<String> optionToSelect = new ArrayList<String>( Arrays.asList( "Select All" ) );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", optionToSelect );

        PerspectiveSchedulingReport perspectiveSchedulingReport = new PerspectiveSchedulingReport( driver );
        // select date
        perspectiveSchedulingReport.selectTargetDate( driver, 3 );
        // select grade
        perspectiveSchedulingReport.SelectGradeAndEnterTheGrade( driver );

        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author sakthi.sasi Used to perform Organization choosing
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public PerspectiveSchedulingAggregateReport chooseOrganization( WebDriver driver, String orgId ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.nap( 5 );
        System.out.println( orgId );
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, drpOrganizationOptions[0], drpOrganizationOptions[1] );
        drpdwnElement.click();
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelectValue( driver, drpdwnElement, orgId, "Choosing Organization" );
        return this;

    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public PerspectiveSchedulingAggregateReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtPerspectiveSchedulingAggregateReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to verify the Organization ID's
     * 
     * @param driver
     * @param districtAdmin
     * @param smUrl
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingAggregateReport verifyOrgIds( WebDriver driver, Admins districtAdmin, String smUrl ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.compareOrganizationElements( driver, districtAdmin, smUrl ), "Organization List Matches", "Organization List doesn't Match" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Organization is available or not
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public PerspectiveSchedulingAggregateReport verifyOrg( WebDriver driver, String orgName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.validateOrganizationDropdownValue( driver, orgName ), "Organization is Available", "Organization is not Available" );
        return this;
    }

    /**
     * @author raseem.mohamed Used to verify the Courses
     * @param driver
     * @param admin
     * @param orgIds
     * @param SubjectName
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingAggregateReport verifyCourses( WebDriver driver, Admins admin, List<String> orgIds, String SubjectName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expcourseNames = new ArrayList<String>();
        List<String> actualCourseNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.COURSES );
        Log.message( "Actual Courses Name From UI : " + actualCourseNames );
        if ( SubjectName.equalsIgnoreCase( "reading" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "prescriptiveScheduling", "2" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        } else if ( SubjectName.equalsIgnoreCase( "math" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "prescriptiveScheduling", "1" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        }

        Log.message( "Courses Name From UI : " + actualCourseNames );

        int actualSize = actualCourseNames.size();
        int expectSize = expcourseNames.size();
        String actual = String.valueOf( actualSize );
        String expect = String.valueOf( expectSize );

        boolean validate = false;
        if ( actualSize == expectSize ) {
            for ( int i = 0; i < actualCourseNames.size(); i++ ) {
                validate = actualCourseNames.get( i ).contains( expcourseNames.get( i ) );
                if ( validate == false ) {
                    Log.softAssertThat( validate, "Course " + actualCourseNames + "Value Is Matching", "Course" + actualCourseNames + " Value Is Not Matching" );
                }
            }
        }
        Log.assertThat( actual.equalsIgnoreCase( expect ), "Passed : Courses Are Matching", "Failed : Courses Are Not Matching" );
        return this;

    }
}
