package com.savvas.sm.reports.ui.tests.admin.psr;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.PSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.PSUIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.reactivex.internal.util.LinkedArrayList;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PSROutputScreen extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private WebDriver driver;
    private String orgId;
    private String school;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        username = ReportData.districtAdmin;
    }

    @Test ( dataProvider = "getSubjectData", description = "Verify Prescriptive Scheduling  Report without filter Test", groups = { "SMK-57297", "Prescriptive Scheduling  Report", "PSR" }, priority = 1 )
    public void tcSMPrescriptiveSchedulingTest001( String Subject ) throws Exception {
        Log.message( "Login in with Admin: " + username );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = smLoginPage.loginToSMPSReportAdmin( username, password );

            prescriptiveSchedulingPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
            orgId = prescriptiveSchedulingPage.reportFilterComponent.setOrganizationDropdown( school );

            if ( Subject.equalsIgnoreCase( "math" ) ) {
                prescriptiveSchedulingPage.reportFilterComponent.selectSubject( "Math" );
            } else {
                prescriptiveSchedulingPage.reportFilterComponent.selectSubject( "Reading" );
            }

            prescriptiveSchedulingPage.reportFilterComponent.setCoursesDropdownSelectAll();

            // Setting Grade Level 
            List<Float> targetLevelArray = new ArrayList<>( Arrays.asList( 2f, 4f, 4f, 4f, 6f, 6f, 7f, 8f, 8.95f, 8.95f, 8.95f, 8.95f, 8.95f ) );

            IntStream.range( 0, targetLevelArray.size() ).forEach( index -> {
                prescriptiveSchedulingPage.setTargetLevelForGrade( prescriptiveSchedulingPage.GradeLevels.get( index ), targetLevelArray.get( index ) );
            } );

            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();

            prescriptiveSchedulingPage.clickIncrementGrade( prescriptiveSchedulingPage.GradeLevels.get( 0 ) );
            prescriptiveSchedulingPage.clickDecrementGrade( prescriptiveSchedulingPage.GradeLevels.get( 0 ) );

            prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            // Setting date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
            LocalDate date = LocalDate.now();
            String targetDate = formatter.format( date );

            String subject = Subject;

            List<String> teacherIdList = new ArrayList<>( Arrays.asList() );
            List<String> groupIdList = new ArrayList<>( Arrays.asList() );
            int additionalGrouping = PSRConstants.GROUP_BY_GRADE;

            HashMap<String, String> headers = new HashMap<>();
            String adminDetails = new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( username ) );
            JsonPath jsonPathEvaluator = new JsonPath( adminDetails );
            String adminId = jsonPathEvaluator.getString( Constants.USERID );
            String adminOrgId = jsonPathEvaluator.getString( "affiliationInfo[0]." + Constants.ORGANIZATION_ID );

            List<String> assignmentIds = new ArrayList<>( Arrays.asList() );
            String payload = getBody( orgId, subject, assignmentIds, targetDate, targetLevelArray, teacherIdList, groupIdList, additionalGrouping );

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.USERID_SM_HEADER, adminId );
            headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getListOfValuesFromAPIOutput( response );
            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );

            // Verification
            SoftAssert softassert = new SoftAssert();
            act.keySet().forEach( key -> {
                softassert.assertEquals( act.get( key ), exp.get( key ), "The value is not Matched for " + key + "\nActual:" + act.get( key ) + "\nExpected:" + exp.get( key ) );
            } );

            softassert.assertAll();

            //
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public HashMap<String, List<String>> getListOfValuesFromAPIOutput( Response response ) {

        // Storing values
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();

        List<Object> assignments = response.then().extract().path( "data.getAdminPSReportData.assignments" );

        JSONArray assignmentList = new JSONArray( assignments );
        System.out.println( "Assignment Length: " + assignmentList.length() );

        int i = 0;
        // Iterating each Assignment Data
        for ( Object oneAssignment : assignmentList ) {

            JSONObject singleAssignment = new JSONObject( oneAssignment.toString() );
            String assignmentTitle = (String) singleAssignment.get( "assignmentTitle" );

            JSONArray assignmentStudents = new JSONArray( singleAssignment.get( "studentRows" ).toString() );

            java.util.stream.IntStream.range( 0, assignmentStudents.length() ).forEach( index -> {

                List<String> singleStudentData = new LinkedList<>();
                String stuName = (String) assignmentStudents.query( "/" + index + "/studentName" );

                String assignmentStudentName = assignmentTitle + ":" + stuName;

                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/currentCourseLevel" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/ipLevel" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/timeSinceIp" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/skillsPercentMastered" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentRate/sessionLength" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentRate/averageMinDay" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentRate/currentLearningRate" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentForecast/time" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentForecast/level" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/prescription/addlSessionsToTarget" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/prescription/addlTimeToTarget" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/prescription/addlMinDayToTarget" ) );

                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    System.out.println( assignmentStudentName + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName ) );
                } else {
                    allStudentValuesList.put( assignmentStudentName, singleStudentData );
                }

            } );

        }
        return allStudentValuesList;
    }

    public HashMap<String, List<String>> getListOfValuesFromUIOutput( WebDriver driver ) {
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();

        PrescriptiveSchedulingPage prescriptiveSchedulingPage = new PrescriptiveSchedulingPage( driver );
        boolean flag = true;
        while ( flag ) {

            // Data From UI
            String assignmentTitle = driver.findElement( By.tagName( "h3" ) ).getText().trim();
            // Single Page row count
            int rowCount = driver.findElements( By.xpath( prescriptiveSchedulingPage.rowCountXpath ) ).size();

            IntStream.rangeClosed( 1, rowCount ).forEach( rowIndex -> {
                List<String> arrayList = new LinkedList<String>();

                arrayList.clear();
                // Getting all the values from single row
                IntStream.rangeClosed( 1, 13 ).forEach( columnIndex -> {
                    String formatted = prescriptiveSchedulingPage.studentData.format( prescriptiveSchedulingPage.studentData, rowIndex, columnIndex );
                    arrayList.add( driver.findElement( By.xpath( formatted ) ).getText().trim() );
                } );

                String assignmentStudentName = assignmentTitle + ":" + arrayList.get( 0 );
                arrayList.remove( 0 );

                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    Log.message( allStudentValuesList + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName ) );
                } else {
                    allStudentValuesList.put( assignmentStudentName, arrayList );
                }
            } );

            // clicking next button
            flag = prescriptiveSchedulingPage.clickNextButtoninOuputPage();
            SMUtils.nap( 1.5 );
        }
        return allStudentValuesList;
    }

    private Map<Object, Map<Object, Object>> expectedValues = new HashMap<Object, Map<Object, Object>>();

    public Map<Object, Map<Object, Object>> getExpectedValues( Response response ) {
        expectedValues.clear();

        // Response Code Validation
        response.then().statusCode( 200 );

        List<Object> assignments = response.then().extract().path( "data.getAdminPSReportData.assignments" );
        Log.message( "\n The Assignment Size is : " + assignments.size() );
        assignments.forEach( assignment -> {

            Map<String, Object> eachAssignment = (Map<String, Object>) assignment;
            Object report_run = eachAssignment.get( PSRConstants.REPORT_RUN );

            Object assignmentTitle = eachAssignment.get( PSRConstants.ASSIGNMENT_TITLE );
            Object targetLevel = eachAssignment.get( PSRConstants.TARGET_LEVEL );
            Object targetDate1 = eachAssignment.get( PSRConstants.TARGET_DATE );
            Object daysToTarget = eachAssignment.get( PSRConstants.DAYS_TO_TARGET );
            Object organizationName = eachAssignment.get( PSRConstants.ORGANIZATION_NAME );
            Object teacherID = eachAssignment.get( PSRConstants.TEACHER_ID );
            Object grade = eachAssignment.get( PSRConstants.GRADE );

            // Verify Individually
            Map<Object, Object> eachAssignmentData = new HashMap<Object, Object>();
            eachAssignmentData.put( PSRConstants.TARGET_LEVEL, targetLevel );
            eachAssignmentData.put( PSRConstants.TARGET_DATE, targetDate1 );
            eachAssignmentData.put( PSRConstants.DAYS_TO_TARGET, daysToTarget );
            eachAssignmentData.put( PSRConstants.ORGANIZATION_NAME, organizationName );
            eachAssignmentData.put( PSRConstants.TEACHER_ID, teacherID );
            eachAssignmentData.put( PSRConstants.ASSIGNMENT_TITLE, assignmentTitle );
            eachAssignmentData.put( PSRConstants.GRADE, grade );

            Map<Object, Object> eachStudentData = new HashMap<Object, Object>();

            List<Object> students = (List<Object>) eachAssignment.get( PSRConstants.STUDENTS_ROW );

            // list of object of studnet
            // each student - has each value
            List<Map<Object, Object>> studnetsData = new ArrayList<Map<Object, Object>>();

            students.forEach( student -> {

                Map<String, Object> eachStudent = (Map<String, Object>) student;
                Object studentName = eachStudent.get( PSRConstants.STUDENT_NAME );
                Object studentUsername = eachStudent.get( PSRConstants.STUDENT_USERNAME );

                Object ipmStatusId = eachStudent.get( PSRConstants.IPM_STATUS_ID );

                Map<String, Object> studentData = new HashMap<String, Object>();
                studentData.put( PSRConstants.STUDENT_NAME, studentName );
                studentData.put( PSRConstants.STUDENT_USERNAME, studentUsername );
                studentData.put( PSRConstants.PERSON_ID, new RBSUtils().getUserIDByUserName( studentUsername.toString() ) );
                studentData.put( PSRConstants.IPM_STATUS_ID, ipmStatusId );

                Map<String, Object> eachPerfomanceData = (Map<String, Object>) eachStudent.get( PSRConstants.PERFOMANCE_DATA );
                Object currentCourseLevel = eachPerfomanceData.get( PSRConstants.CURRENT_COURSE_LEVEL );
                Object ipLevel = eachPerfomanceData.get( PSRConstants.IP_LEVEL );
                Object timeSinceIp = eachPerfomanceData.get( PSRConstants.TIME_SINCE_IP );
                Object skillsPercentMastered = eachPerfomanceData.get( PSRConstants.SKILL_PERCENT_MASTERED );

                Map<String, Object> performanceData = new HashMap<String, Object>();
                performanceData.put( PSRConstants.CURRENT_COURSE_LEVEL, currentCourseLevel );
                performanceData.put( PSRConstants.IP_LEVEL, ipLevel );
                performanceData.put( PSRConstants.TIME_SINCE_IP, timeSinceIp );
                performanceData.put( PSRConstants.SKILL_PERCENT_MASTERED, skillsPercentMastered );

                Map<String, Object> eachCurrentRate = (Map<String, Object>) eachStudent.get( PSRConstants.CURRENT_RATE );
                Object sessionLength = eachCurrentRate.get( PSRConstants.SESSION_LENGTH );
                Object averageMinDay = eachCurrentRate.get( PSRConstants.AVERAGE_MIN_DAY );
                Object currentLearningRate = eachCurrentRate.get( PSRConstants.CURRENT_LEARNING_RATE );

                Map<String, Object> currentRate = new HashMap<String, Object>();
                currentRate.put( PSRConstants.SESSION_LENGTH, sessionLength );
                currentRate.put( PSRConstants.AVERAGE_MIN_DAY, averageMinDay );
                currentRate.put( PSRConstants.CURRENT_LEARNING_RATE, currentLearningRate );

                Map<String, Object> eachCurrentForecast = (Map<String, Object>) eachStudent.get( PSRConstants.CURRENT_FORECAST );
                Object time = eachCurrentForecast.get( PSRConstants.TIME );
                Object level = eachCurrentForecast.get( PSRConstants.LEVEL );

                Map<String, Object> currentForecast = new HashMap<String, Object>();
                currentForecast.put( PSRConstants.TIME, time );
                currentForecast.put( PSRConstants.LEVEL, level );

                Map<String, Object> eachPrescription = (Map<String, Object>) eachStudent.get( PSRConstants.PRESCRIPTION );
                Object addlSessionsToTarget = eachPrescription.get( PSRConstants.ADDL_SESSION_TO_TARGET );
                Object addlTimeToTarget = eachPrescription.get( PSRConstants.ADDL_TIME_TO_TARGET );
                Object addlMinDayToTarget = eachPrescription.get( PSRConstants.ADDL_MIN_DAY_TO_TARGET );

                Map<String, Object> prescription = new HashMap<String, Object>();
                prescription.put( PSRConstants.ADDL_SESSION_TO_TARGET, addlSessionsToTarget );
                prescription.put( PSRConstants.ADDL_TIME_TO_TARGET, addlTimeToTarget );
                prescription.put( PSRConstants.ADDL_MIN_DAY_TO_TARGET, addlMinDayToTarget );

                // Adding all Details into one Map for one studnet
                eachStudentData.put( "studentData", studentData );
                eachStudentData.put( PSRConstants.PERFOMANCE_DATA, performanceData );
                eachStudentData.put( PSRConstants.CURRENT_RATE, currentRate );
                eachStudentData.put( PSRConstants.CURRENT_FORECAST, currentForecast );
                eachStudentData.put( PSRConstants.PRESCRIPTION, prescription );
                studnetsData.add( eachStudentData );

            } );

            Map<Object, Object> oneAssignment = new HashMap<Object, Object>();

            oneAssignment.put( "assignmentData", eachAssignmentData );
            oneAssignment.put( "studentsData", studnetsData );

            expectedValues.put( report_run, oneAssignment );

        } );

        Log.message( "\n Collected Data is:\n" + expectedValues.toString() );
        return expectedValues;
    }

    public String getBody( String orgId, String subject, List<String> assignmentIds, String targetDate,

            List<Float> targetLevelArray, List<String> teacherIdList, List<String> groupIdList, int additionalGrouping ) throws IOException {

        JSONObject variableBody = new JSONObject();

        JSONObject psrResponsBody = new JSONObject();
        JSONArray jsonarray = new JSONArray( teacherIdList );

        psrResponsBody.put( PSRConstants.SUBJECT, subject );
        psrResponsBody.put( PSRConstants.TARGET_DATE, targetDate );
        psrResponsBody.put( PSRConstants.ADDITIONAL_GROUPING, additionalGrouping );

        // course list
        JSONArray courseList = new JSONArray();
        assignmentIds.stream().forEach( value -> courseList.put( value ) );
        psrResponsBody.put( PSRConstants.COURSE_LIST, courseList );

        // teacherList list
        JSONArray teacherList = new JSONArray();
        teacherIdList.stream().forEach( value -> teacherList.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_TEACHER, teacherList );

        // group list
        JSONArray groupList = new JSONArray();
        groupIdList.stream().forEach( value -> groupList.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_GROUP, groupList );

        // target level list
        JSONArray targetLevel = new JSONArray();
        targetLevelArray.stream().forEach( value -> targetLevel.put( value ) );
        psrResponsBody.put( PSRConstants.TARGET_LEVEL_ARRAY, targetLevel );

        // filter by school list
        JSONArray orgJson = new JSONArray();
        new ArrayList<>( Arrays.asList( orgId ) ).stream().forEach( value -> orgJson.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_SCHOOL, orgJson );

        // filter by Grades
        psrResponsBody.put( PSRConstants.FILTER_BY_GRADE, new JSONArray() );
        JSONObject demoJSON = new JSONObject();

        demoJSON.put( PSRConstants.DISABILLITY_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.ENGLISH_LANGUGAGE_PROFICIENCY, new JSONArray() );
        demoJSON.put( PSRConstants.GENDER, new JSONArray() );
        demoJSON.put( PSRConstants.RACE, new JSONArray() );
        demoJSON.put( PSRConstants.ETHINICITY, new JSONArray() );
        demoJSON.put( PSRConstants.SOCIO_ECONOMIC_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.MIGRANT_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.SPECIAL_SERVICES, new JSONArray() );

        psrResponsBody.put( PSRConstants.DEMOGRAPHICS_INPUT, demoJSON );
        variableBody.put( PSRConstants.PRS_REPORT_REQUEST, psrResponsBody );

        Log.message( "\nGraphQL Variable:\n" + variableBody.toString() );
        String requestBody = SMUtils.convertFileToString( new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator
                + "report" + File.separator + "PSRRequestBody.json" );
        String formatted = requestBody.format( requestBody, subject, courseList.toString(), targetDate, targetLevel.toString(), additionalGrouping, orgJson.toString(), teacherList.toString(), groupList.toString() );
        Log.message( "PayLoad:\n" + formatted.toString() );
        return formatted;
    }

    public HashMap<Integer, List<Object>> getExpectedListValues( List<Object> assignments ) {

        HashMap<Integer, List<Object>> allStudentsData = new HashMap<Integer, List<Object>>();

        JSONArray assignmentList = new JSONArray( assignments );
        System.out.println( "Assignment Length: " + assignmentList.length() );

        int i = 0;
        // Iterating each Assignment Data
        for ( Object oneAssignment : assignmentList ) {
            List<Object> listOfDats = new ArrayList<Object>();

            String formattted = oneAssignment.toString().substring( 1, oneAssignment.toString().length() - 1 );
            JSONObject assignment = new JSONObject( formattted );
            Map<String, Object> StudentData = assignment.toMap();

            Map<String, Object> expPerformanceData = (Map<String, Object>) StudentData.get( PSRConstants.PERFOMANCE_DATA );
            Map<String, Object> expCurrentRate = (Map<String, Object>) StudentData.get( PSRConstants.CURRENT_RATE );
            Map<String, Object> expCurrentForecast = (Map<String, Object>) StudentData.get( PSRConstants.CURRENT_FORECAST );
            Map<String, Object> expPrescription = (Map<String, Object>) StudentData.get( PSRConstants.PRESCRIPTION );

            listOfDats.add( expPerformanceData );
            listOfDats.add( expCurrentRate );
            listOfDats.add( expCurrentForecast );
            listOfDats.add( expPrescription );
            allStudentsData.put( i + 1, listOfDats );
            i++;
        }

        return allStudentsData;
    }

    public void assertionEachStudentData( String StudentName, List<Object> act, List<Object> exp ) {

        Map<String, String> expPerformanceData = (Map<String, String>) exp.get( 0 );
        Map<String, String> expCurrentRate = (Map<String, String>) exp.get( 1 );
        Map<String, String> expCurrentForecast = (Map<String, String>) exp.get( 2 );
        Map<String, String> expPrescription = (Map<String, String>) exp.get( 3 );

        Map<String, String> performanceData = (Map<String, String>) act.get( 0 );
        Map<String, String> currentRate = (Map<String, String>) act.get( 1 );
        Map<String, String> currentForecast = (Map<String, String>) act.get( 2 );
        Map<String, String> prescription = (Map<String, String>) act.get( 3 );

        Log.message( "Verification of :- " + StudentName );

        // Verification of perfomance data
        logAssert( performanceData.get( PSUIConstants.CURRENT_COURSE_LEVEL ), expPerformanceData.get( PSRConstants.CURRENT_COURSE_LEVEL ), "Current Coruse Level is Matched!", "Current Coruse Level is not Matched!" );
        logAssert( performanceData.get( PSUIConstants.IP_LEVEL ), expPerformanceData.get( PSRConstants.IP_LEVEL ), "IP Level is matched!", "IP Level is not matched!" );
        logAssert( performanceData.get( PSUIConstants.TIME_SINCE_IP ), expPerformanceData.get( PSRConstants.TIME_SINCE_IP ), "Time since IP is matched!", "Time since IP is not matched!" );
        logAssert( performanceData.get( PSUIConstants.SKILLS_PERCENT_MASTERED ), expPerformanceData.get( PSRConstants.SKILL_PERCENT_MASTERED ), "Skill Percent Mastered is matched!", "Skill Percent Mastered is not matched!" );

        // Verification of Current rate
        logAssert( currentRate.get( PSUIConstants.SESSION_LENGTH_SETTING ), expCurrentRate.get( PSRConstants.SESSION_LENGTH ), "Session Length is matched!", "Session Length is not matched!" );
        logAssert( currentRate.get( PSUIConstants.AVERAGE_MIN_DAY ), expCurrentRate.get( PSRConstants.AVERAGE_MIN_DAY ), "Average min Per Day is matched!", "Average min Per Day is not matched!" );
        logAssert( currentRate.get( PSUIConstants.CURRENT_LEARNING_RATE ), expCurrentRate.get( PSRConstants.CURRENT_LEARNING_RATE ), "Current Learning  Rate is matched!", "Current Learning  Rate is not matched!" );

        // Verification of Current Forecast
        logAssert( currentForecast.get( PSUIConstants.TIME ), expCurrentForecast.get( PSRConstants.TIME ), "Current forecast Time is matched!", "Current forecast Time is not matched!" );
        logAssert( currentForecast.get( PSUIConstants.LEVEL ), expCurrentForecast.get( PSRConstants.LEVEL ), "Current forecast Level is matched!", "Current forecast Level is not matched!" );

        // Verification of Prescription
        logAssert( prescription.get( PSUIConstants.ADDL_SESSIONS_TO_TARGET ), expPrescription.get( PSRConstants.ADDL_SESSION_TO_TARGET ), "Prescription Additional Session to Target is matched!",
                "Prescription Additional Session to Target is not matched!" );
        logAssert( prescription.get( PSUIConstants.ADDL_TIME_TO_TARGET ), expPrescription.get( PSRConstants.ADDL_TIME_TO_TARGET ), "Prescription Additional Time to Target is matched!", "Prescription Additional Time to Target is not matched!" );
        logAssert( prescription.get( PSUIConstants.ADDL_MIN_PER_DAY_TO_TARGET ), expPrescription.get( PSRConstants.ADDL_MIN_DAY_TO_TARGET ), "Prescripton Additional Minute Per Day to Target is matched!",
                "Prescripton Additional Minute Per Day to Target is not matched!" );

    }

    public void logAssert( String act, String exp, String PassMessage, String FailMessage ) {
        Log.message( "\nVerifying Values...\nActual: " + act + "\nExpected: " + exp );
        Log.assertThat( act.equals( exp ), PassMessage, FailMessage );
    }

    @DataProvider
    public Object[][] getSubjectData() {
        return new Object[][] { { "math" }, { "reading" } };
    }
}