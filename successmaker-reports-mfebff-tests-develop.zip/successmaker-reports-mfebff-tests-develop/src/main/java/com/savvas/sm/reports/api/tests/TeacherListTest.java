package com.savvas.sm.reports.api.tests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.reports.constants.ReportsAPIConstants;

public class TeacherListTest extends ReportAPI {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    LeftNavigationBar dashBoardPage;
    AdminLauncherPage smLoginPage;
    RecentSessionsPage recentSessionPage;

    // Expected values
    HashMap<String, HashMap<String, String>> expectedDetails = new HashMap<String, HashMap<String, String>>();
    HashMap<String, HashMap<String, String>> actualDetails = new HashMap<String, HashMap<String, String>>();

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }
    

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "testcases" )
    public Object[][] positiveData() {
        Object[][] inputData = { { "SAVVAS_ADMIN" },
                { "SUB_DISTRICT_ADMIN" },
                { "SUB_DISTRICT_WIHOUT_SCHOOLS" },
                { "SCHOOL_ADMIN" } };
        return inputData;
    }
/**
 * To Verify All the values From the Teacher List From the OrgIds
 * @param expectedValues
 * @param actualValues
 */
    public void Verfify( HashMap<String, HashMap<String, String>> expectedValues, HashMap<String, HashMap<String, String>> actualValues ) {
        Log.message( "Expected Values:\n"+expectedValues.toString() );
        Log.message( "Actual Values:\n"+actualValues.toString() );
        Set<String> userIds = expectedValues.keySet();
        userIds.forEach( userId -> {
            Log.assertThat( SMUtils.compareTwoHashMap( expectedValues.get( userId ), actualValues.get( userId ) ), "The Values are matching for the user ID:" + userId,
                    "The values are not matching" + expectedValues.get( userId ).toString() + "=>" + actualValues.get( userId ).toString() );
        } );
    }

    /** To get all the Teacher Details From the OrgIds
     * 
     * @param orgIds
     * @return          
     */
    public HashMap<String, HashMap<String, String>> getExpectedValues( List<String> orgIds ) {
        expectedDetails.clear();
        orgIds.forEach( orgId -> {
            JSONArray teacherJsonArray = new RBSUtils().getAllTeachesForOrg( orgId );
            if ( !teacherJsonArray.equals( new JSONArray() ) ) {
                for ( Object user : teacherJsonArray ) {
                    JSONObject userJson = new JSONObject( user.toString() );
                    HashMap<String, String> otherDetails = new HashMap<String, String>();
                    otherDetails.put( Constants.USER_NAME, userJson.get( ReportsAPIConstants.TNS_USESRNAME ).toString() );
                    otherDetails.put( Constants.FIRSTNAME, userJson.get( ReportsAPIConstants.TNS_FIRSTNAME ).toString() );
                    otherDetails.put( Constants.LASTNAME, userJson.get( ReportsAPIConstants.TNS_LASTNAME ).toString() );
                    try {
                        otherDetails.put( Constants.MIDDLENAME, userJson.get( ReportsAPIConstants.TNS_MIDDLENAME ).toString() );
                    } catch ( Exception e ) {
                        otherDetails.put( Constants.MIDDLENAME, null );
                    }
                    expectedDetails.put( userJson.get( "tns:UserId" ).toString(), otherDetails );
                }
            }
        } );
        return actualDetails;


    }

    /** To get the Actual Values of Teacher List From the API
     * 
     * @param response
     * @return
     */
    public HashMap<String, HashMap<String, String>> getActualValues( HashMap<String, String> response ) {
        String actualResponse = response.get( Constants.REPORT_BODY );
        String resip = SMUtils.getKeyValueFromResponseWithArray( actualResponse, "data,getOptionalFilters" );
        JSONArray dsf = new JSONArray( new JSONObject( resip ).get( "teachers" ).toString() );
        actualDetails.clear();
        dsf.forEach( object -> { 
            HashMap<String, String> otherDetails = new HashMap<String, String>();
            otherDetails.put( Constants.USER_NAME, new JSONObject( object.toString() ).get( Constants.USER_NAME ).toString() );
            otherDetails.put( Constants.FIRSTNAME, new JSONObject( object.toString() ).get( Constants.FIRSTNAME ).toString() );
            otherDetails.put( Constants.MIDDLENAME, new JSONObject( object.toString() ).get( Constants.MIDDLENAME ).toString() );
            otherDetails.put( Constants.LASTNAME, new JSONObject( object.toString() ).get( Constants.LASTNAME ).toString() );
            actualDetails.put( new JSONObject( object.toString() ).get( Constants.USERID ).toString(), otherDetails );
        } );
        return actualDetails;
    }


    @Test ( description = "Verify the Teacher Details for the", dataProvider = "testcases",groups = { "SMK-57813", "RecentSessionReport", "OptionalFilters","SmokeTest" }, priority = 1 )
    public void tcTeacherListPostive(String Scenario) throws Exception {

        String adminUseID = null;
        String adminUsername = null;
        List<String> orgIds = null;
        String accessToken = null;
        HashMap<String, String> postResponse = null;
        
        switch ( Scenario ) {
            case "SAVVAS_ADMIN":
                SMUtils.logDescriptionTC(" Verify the API  for response contains all the teachers for selected all the organizations");
                SMUtils.logDescriptionTC(" Verify the API  when admin is for system admin");
                SMUtils.logDescriptionTC(" Verify the API  for access_token of school admin for the  system admin user id");
                adminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
                accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
                orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername ).subList( 0, 10 );
                postResponse = getTeachersList( adminUseID, orgIds, accessToken );
                break;
            case "SUB_DISTRICT_ADMIN":
                SMUtils.logDescriptionTC(" Verify the API  when the admin is for Subdistrict admin");
                SMUtils.logDescriptionTC(" Verify the API  for response contains all the teachers for selected two organizations");
                adminUsername = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
                accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
                orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername );
                postResponse = getTeachersList( adminUseID, orgIds, accessToken );
                break;
            case "SUB_DISTRICT_WIHOUT_SCHOOLS":
                SMUtils.logDescriptionTC(" Verify the API  when the organization is has no teachers in it");
                adminUsername = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN );
                adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
                accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
                orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername );
                postResponse = getTeachersList( adminUseID, orgIds, accessToken );
                break;
            case "SCHOOL_ADMIN":
                SMUtils.logDescriptionTC(" Verify the API  When the admin is for one school");
                SMUtils.logDescriptionTC(" Verify the api when the response code is 200");
                SMUtils.logDescriptionTC(" Verify the API  for the response having all the Data");
                SMUtils.logDescriptionTC(" Verify the API  for the teacher having first middle last name");
                SMUtils.logDescriptionTC(" Verify the API  for the teacher having without middle name");
                SMUtils.logDescriptionTC(" Verify the API  for response contains all the teachers for selected one organizations");
                adminUsername = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
                adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
                accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
                orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername );
                postResponse = getTeachersList( adminUseID, orgIds, accessToken );
                break;
                
            default:
                break;
        }
     // Status code matches
        String actualStatusCode = postResponse.get( Constants.STATUS_CODE );
        Log.assertThat( actualStatusCode.equals( "200"), "The response code Matches! as 200 ", "The response code doesnot Matches expected 200 but received " + actualStatusCode );
        Verfify( getExpectedValues( orgIds ), getActualValues( postResponse ) );
    }
    
    /**
     * To Verify Invalid scenarios for Grade Listing
     * 
     * @param testcaseName
     * @param statusCode
     * @param testcaseDescription
     * @param scenarioType
     * @throws Exception
     */
    @Test(dataProvider = "negativeScenariosData", groups = { "SMK-58053", "Grade List Report bff",
            "API" }, priority = 1,enabled = false )
    public void tcTeacherListNegative (String Scenario , String statusCode)
            throws Exception {

        String adminUseID = null;
        String adminUsername = null;
        List<String> orgIds = null;
        String accessToken = null;
        HashMap<String, String> postResponse = null;
        
        
        switch (Scenario) {
        case "INVALID USER ID":
            
            adminUsername = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
            adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
            accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
            orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername );
            postResponse = getTeachersList( adminUseID+1, orgIds, accessToken );
            break;

        case "INVALID ORG ID":

            adminUsername = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
            adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
            accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
            orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername );
            orgIds.set( 0, orgIds.get( 0 )+1 );
            postResponse = getTeachersList( adminUseID, orgIds, accessToken );
            break;

        case "INVALID TOKEN":

            adminUsername = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
            adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
            accessToken = new RBSUtils().getAccessToken( adminUsername.toLowerCase(), password );
            orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername );
            postResponse = getTeachersList( adminUseID, orgIds, accessToken+'A' );
            break;

        case "SCHOOL_ACCESS_TOKEN_SYSADMIN":
            adminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
            adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
            accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );
            orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername ).subList( 0, 10 );
            postResponse = getTeachersList( adminUseID, orgIds, accessToken );
            break;
            
        case "SCHOOL_ACCESS_TOKEN_DISTRICTADMIN":
            adminUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
            adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
            accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );
            orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername ).subList( 0, 10 );
            postResponse = getTeachersList( adminUseID, orgIds, accessToken );
            break;
            
        case "SUBDISTRICTL_ACCESS_TOKEN_SYSADMIN":
            adminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
            adminUseID = new RBSUtils().getUserIDByUserName( adminUsername.toLowerCase() );
            accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );
            orgIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsername ).subList( 0, 10 );
            postResponse = getTeachersList( adminUseID, orgIds, accessToken );
            break;

        }

        // status code Validation
        Log.assertThat(postResponse.get(Constants.STATUS_CODE).equals(statusCode),
                "The Status code is expected " + statusCode + " and actual " + postResponse.get(Constants.STATUS_CODE)
                        + " Verified",
                "The Status code is expected " + statusCode + " and actual " + postResponse.get(Constants.STATUS_CODE)
                        + "is not Verified");

        Log.testCaseResult();
        Log.endTestCase();
    }

    // @DataProvider

    /*
     * Invalid scenarios get valid response bodies. This scenario will be fixed
     * in 257 sprints by the developer team.
     * 
     */
    public Object[][] negativeScenariosData() {
        Object[][] data = {
                { "INVALID USER ID" },
                { "INVALID ORG ID" },
                { "INVALID TOKEN" },
                { "SCHOOL_ACCESS_TOKEN_SYSADMIN" },
                { "SCHOOL_ACCESS_TOKEN_DISTRICTADMIN" },
                { "SUBDISTRICTL_ACCESS_TOKEN_SYSADMIN" } };
        return data;
    }

}
