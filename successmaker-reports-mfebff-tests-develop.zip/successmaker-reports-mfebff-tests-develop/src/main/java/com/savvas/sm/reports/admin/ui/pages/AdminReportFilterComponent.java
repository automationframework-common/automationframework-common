package com.savvas.sm.reports.admin.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AdminReportFilterComponent extends LeftNavigationBar {

    WebDriver driver;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @IFindBy ( how = How.CSS, using = "h1", AI = false )
    WebElement pageTitle;

    @IFindBy ( how = How.CSS, using = "p.description", AI = false )
    WebElement pageDescription;

    @IFindBy ( how = How.CSS, using = "div.report-body-wrapper cel-accordion-item", AI = false )
    WebElement optionalFilterRoot;

    @IFindBy ( how = How.CSS, using = "div label", AI = false )
    List<WebElement> dropdownLabels;

    @IFindBy ( how = How.CSS, using = "cel-single-select.hydrated", AI = false )
    WebElement singleSelectRoot;

    @IFindBy ( how = How.CSS, using = ".save-report-modal.hydrated", AI = false )
    WebElement saveReportBtnRoot;

    @IFindBy ( how = How.CSS, using = "save-report-options cel-modal", AI = false )
    WebElement saveReportButtonParent;

    @IFindBy ( how = How.CSS, using = "cel-button.ml-auto", AI = false )
    WebElement resetButtonRoot;

    @IFindBy ( how = How.CSS, using = "div.report-body-wrapper cel-accordion-item.hydrated", AI = false )
    WebElement optionalFilterElement;

    @IFindBy ( how = How.CSS, using = "cel-button.pr-2", AI = false )
    WebElement runReportButtonRoot;

    @IFindBy ( how = How.CSS, css = "cel-accordion-item[class='hydrated']", AI = false )
    WebElement studentDemographicsAccordionRoot;
    
    @IFindBy (  how = How.TAG_NAME, tagName = "cel-icon" , AI = false)
    WebElement helpIconRoot;
    
    @IFindBy ( how = How.CSS, css= "div.section-main-title.mt-3.text-uppercase", AI = false  )
    WebElement courseSelectionLabel;

    @IFindBy ( how = How.CSS, css = "h2.section-main-title", AI = false )
    WebElement selectStudentBy;
    
    @IFindBy (  how = How.CSS, css = "cel-modal-window", AI = false )
    WebElement studentIDPopupparent;
    
    // Child Elements
    private String multiSelectDropdownRoot = "cel-multi-select.hydrated";
    private String button = "button";
    private String childSavedReportArrow = "cel-icon";
    private String childMultiCheckBox = "cel-multi-checkbox";
    private String childMultiCheckBoxItems = "cel-checkbox-item";
    private String grandChildCheckBoxLabel = "span.checkbox-label";
    private String inputCheckbox = "input";
    private String dropdownplaceHolder = "span.label";
    private String singleDropdownDropdownItem = "option";
    private String singleSelectDropdownRoot = "cel-single-select.hydrated";
    private String singleSelectDropRoot = ".single-icon";
    private String celbutton = "cel-button";
    private String searchFieldRoot = "cel-search-field.search";
    private String searchfieldChild = "input.search-field";
    private String celIconButton = "cel-icon-button";
    private String toolTipRoot = "cel-tooltip";
    private String toolTipLbl = "span.link-tooltip";
    private String errorMessage = "div.error-container span.error-message";
    private String select = "select";
    private String childHelpIcon = "div.icon-inner";
    private String optionalFilter = "span.item-heading";
    private String studnetIDPopup = "cel-button.hydrated";

    public AdminReportFilterComponent( WebDriver driver ) {
        super( driver );
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * To get the root Element for multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, singleSelectRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( multiSelectDropdownRoot ) );
    }

    /**
     * To verify the Multi-select is Displaying or not
     * 
     * @return
     */
    public boolean isMultiSelectDropDownDisplayed( String dropdownName ) {
        Log.message( "Verifing " + dropdownName + "Drop Down is displayed" );
        return getRootElementForMultiSelectDropdown( dropdownName ).isDisplayed();
    }

    /**
     * To verify the multi-select dropdown arrow is displayed or not
     * 
     * @return
     */
    public boolean isMultiSelectDropDownArrowDisplayed( String dropdownName ) {
        Log.message( "Verifing  Save Report Option Drop Down Arrow is displayed" );
        return SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), childSavedReportArrow ).isDisplayed();
    }

    /**
     * To get arrow direction for multi select dropdown
     * 
     * @return
     */
    public String getMultiSelectDropdownArrowDirection( String dropdownName ) {
        Log.message( "Getting " + dropdownName + " drop down arrow direction" );
        String value = SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), childSavedReportArrow ).getAttribute( "data-name" ).trim();
        return value.equals( "caret-down" ) ? "Down" : "Up";
    }

    /**
     * To verify the multi-Select dropdown is enabled or not
     * 
     * @return
     */
    public boolean isMultiSelectDropdownEnabled( String dropdownName ) {
        Log.message( "Verifying " + dropdownName + " drop down is enabled" );
        try {
            return SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), button ).isEnabled();
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify the multi-select dropdown is expanded or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectDropdownExpanded( String dropdownName ) {
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return !SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * To verify the multi-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * Expand the multi-select drop-down
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void expandMultiSelectDropdown( String dropdownName ) {
        if ( isMultiSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.waitForElementToBeClickable( parentRoot, driver );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * To Collapse the multi-select drop-down
     * 
     * @param dropdownName
     */
    public void collapseMultiSelectDropdown( String dropdownName ) {
        if ( isMultiSelectDropdownExpanded( dropdownName ) ) {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.waitForElementToBeClickable( parentRoot, driver );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Collapsed " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get available options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getAvailableOptionsFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 120 );
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.waitForElement( driver, parentRoot );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().parallel().map(
                element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get tootltip content for the options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getOptionsTooltipFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.waitForElement( driver, parentRoot );
        List<WebElement> parentElements = SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems );
        //To remove the select all element
        parentElements.remove( 0 );
        return parentElements.stream().parallel().map( element -> {
            try {
                return SMUtils.getWebElementDirect( driver, element, toolTipRoot, toolTipLbl ).getText().trim();
            } catch ( Exception e ) {
                return SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim();
            }
        } ).collect( Collectors.toList() );

    }

    /**
     * To select options in multi-select dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void selectOptionsFromMultiSelectDropdown( String dropdownName, List<String> options ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 120 );
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        options.stream().forEach( optionName -> {
            if ( !optionName.equalsIgnoreCase( ReportsUIConstants.SELECT_ALL ) && !optionName.equalsIgnoreCase( "Select All Visible" ) ) {
                try {
                    if ( dropdownName.equals( ReportsUIConstants.ORGANIZATIONS_LABEL ) || dropdownName.equals( ReportsUIConstants.CPR_COURSES_LABEL ) || dropdownName.equals( ReportsUIConstants.TEACHER_LABEL )
                            || dropdownName.equals( ReportsUIConstants.GROUP_LABEL ) ) {
                        enterTextInSearchBar( dropdownName, optionName );
                    }
                } catch ( Exception e ) {
                    Log.message( "Getting issue while enter the text in the search box!!!!" );
                }
                try {
                    SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().parallel().filter(
                            element -> optionName.equalsIgnoreCase( SMUtils.getWebElementDirect( driver, element, toolTipRoot, toolTipLbl ).getText().trim() ) ).forEach( element -> {
                                SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                                Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                            } );
                } catch ( Exception e ) {
                    SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().parallel().filter(
                            element -> optionName.equalsIgnoreCase( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).forEach( element -> {
                                SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                                Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                            } );
                }
            } else {
                Optional<WebElement> parentElement = SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                        element -> optionName.equalsIgnoreCase( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).findFirst();
                SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, parentElement.get(), inputCheckbox ) );
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentElement.get(), inputCheckbox ) );
                Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, parentElement.get(), grandChildCheckBoxLabel ).getText().trim() );

            }
        } );
        SMUtils.moveToElementJS( driver, pageDescription );
    }

    /**
     * To get the selected options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getSelectedOptionsFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().parallel().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputCheckbox ).isSelected() && !SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim().equalsIgnoreCase( ReportsUIConstants.ALL_OPTION ) ).map(
                        element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get the place holder in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder ).getText().trim();
    }

    /**
     * To get the root Element for single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelectDropdown( String dropdownName ) {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            SMUtils.waitForElement( driver, singleSelectRoot );
            return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );

        } catch ( InterruptedException e ) {
            Log.message( "Getting Issue while get the Organization dropdown root element!!!" );
            return null;
        }
    }

    /**
     * To get the root Element for single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelect( String dropdownName ) {
        SMUtils.waitForElement( driver, singleSelectRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropRoot ) );
    }

    /**
     * To verify the Single dropdown is Displaying or not
     * 
     * @return
     */
    public boolean isSingleSelectDropDownDisplayed( String dropdownName ) {
        Log.message( "Verifing " + dropdownName + "Drop Down is displayed" );
        return getRootElementForSingleSelectDropdown( dropdownName ).isDisplayed();
    }

    /**
     * To verify the single select dropdown arrow is displayed or not
     * 
     * @return
     */
    public boolean isSingleSelectDropDownArrowDisplayed( String dropdownName ) {
        Log.message( "Verifing " + dropdownName + " Drop Down Arrow is displayed" );
        return SMUtils.getWebElement( driver, getRootElementForSingleSelectDropdown( dropdownName ), childSavedReportArrow ).isDisplayed();
    }

    /**
     * To get arrow direction for single select dropdown
     * 
     * @return
     */
    public String getSingleSelectDropdownArrowDirection( String dropdownName ) {
        Log.message( "Getting " + dropdownName + " drop down arrow direction" );
        String value = SMUtils.getWebElement( driver, getRootElementForSingleSelectDropdown( dropdownName ), childSavedReportArrow ).getAttribute( "data-name" ).trim();
        return value.equals( "caret-down" ) ? "Down" : "Up";
    }

    /**
     * To verify the single-select dropdown is expanded or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownExpanded( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return !SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * To verify the single-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).stream().allMatch( element -> element.isDisplayed() );
    }

    /**
     * Expand the single-select drop-down
     * 
     * @param dropdownName
     */
    public void expandSingleSelectDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.click( driver, SMUtils.getWebElementDirect( driver, parentRoot, select ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * To Collapse the single-select drop-down
     * 
     * @param dropdownName
     */
    public void collapseSingleSelectDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownExpanded( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, select ) );
            Log.message( "Collapsed " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get available options in single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAvailableOptionsFromSingleSelectDropdown( String dropdownName ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );

    }

    /**
     * To select options in single-select dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void selectOptionsFromSingleSelectDropdown( String dropdownName, String options ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement optionElement;

        optionElement = SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().filter( element -> options.equalsIgnoreCase( element.getText().trim() ) ).findFirst().orElse( null );

        if ( !Objects.isNull( optionElement ) ) {
            SMUtils.click( driver, optionElement );
            Log.message( "Selected Option in " + dropdownName + " - " + options );
        } else {
            Log.fail( "The Selected option " + options + " is not presented under " + dropdownName + "dropdown!!!" );
        }
        SMUtils.moveToElementJS( driver, pageDescription );

    }

    /**
     * Enter Text in Search Bar
     * 
     * @return
     */
    public void enterTextInSearchBar( String dropdowName, String text ) {
        WebElement atualElementParent = SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdowName ), searchFieldRoot );
        WebElement searchBar = SMUtils.getWebElement( driver, atualElementParent, searchfieldChild );
        SMUtils.clickJS( driver, searchBar );
        searchBar.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript( "arguments[0].value='" + text + "'", searchBar );
        Log.message( "Entered value as: " + text );

    }

    /**
     * Enter Text in Search Bar
     * 
     * @return
     */
    public void clearTextInSearchBar( String dropdowName ) {
        WebElement atualElementParent = SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdowName ), searchFieldRoot );
        WebElement cancelIcon = SMUtils.getWebElementDirect( driver, atualElementParent, celIconButton, button );
        SMUtils.clickJS( driver, cancelIcon );
    }

    /**
     * To click the Save Report options button
     * 
     */
    public SaveReportFilterPopup clickSaveReportOptionButton() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ) );
        return new SaveReportFilterPopup( driver ).get();
    }

    /**
     * To Click Reset Button
     */
    public void clickResetButton() {
        SMUtils.waitForElement( driver, resetButtonRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, resetButtonRoot, button ) );
        Log.message( "Clicked Reset Button!" );
    }

    /**
     * To verify the Save Report options button
     * 
     */
    public boolean isSaveReportOptionButtonEnabled() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        return SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ).isEnabled();
    }

    /**
     * To expand optional filter
     *
     * @return
     */
    public boolean expandOptionalFilter() {

        SMUtils.waitForElement( driver, optionalFilterElement );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterElement, button );
        SMUtils.click( driver, actualElement );
        SMUtils.scrollDownPage( driver );
        if ( actualElement.getAttribute( "aria-expanded" ).equalsIgnoreCase( "true" ) ) {
            Log.message( "Optional filter Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expand the Optional filter!" );
            return false;
        }
    }

    /**
     * To click the run report button
     * 
     * @return
     */
    public boolean clickRunReportButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, runReportButtonRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, runReportButtonRoot, button ) );
            Log.message( "Clicked Run Report Button!" );
            try {
                WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
                wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
                ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                driver.switchTo().window( child.get( 2 ) );
            } catch ( Exception e ) {
                Log.message( "Getting issue while change the driver to report output page!!!!" );
            }
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Clicked Run Report Button Failed" );
            return false;
        }
    }

    /**
     * To verify the error message
     * 
     * @param dropdownName
     * @throws InterruptedException
     */

    public Boolean isErrorMessageDisplayed( String dropdownName ) {
        try {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            return SMUtils.getWebElementDirect( driver, parentRoot, errorMessage ).isDisplayed();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verify the error message" );
            return false;
        }
    }

    /**
     * To get the error message
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public String getErrorMessage( String dropdownName ) {
        try {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            return SMUtils.getWebElementDirect( driver, parentRoot, errorMessage ).getText().trim();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verify the error message" );
            return null;
        }
    }

    /**
     * To Expand Student Demographics filters
     * 
     */
    public boolean expandStudentDemographics() {
        SMUtils.waitForElement( driver, studentDemographicsAccordionRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentDemographicsAccordionRoot, button ) );
        SMUtils.scrollDownPage( driver );
        if ( SMUtils.getWebElementDirect( driver, studentDemographicsAccordionRoot, button ).getAttribute( "aria-expanded" ).equalsIgnoreCase( "true" ) ) {
            Log.message( "Student demographics Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expand the Student demographics!" );
            return false;
        }
    }
    
    
    /**
     * To verify the Report title is displaying or not
     * 
     * @return
     */
    public boolean isReportTitleDisplayed() {
        Log.message( "Verifing Prescriptive Scheduling Report Title is displayed" );

        SMUtils.waitForElement( driver, pageTitle );
        return pageTitle.isDisplayed();
    }
    
    
    /**
     * To verify the Report description is displaying or not
     * 
     * @return
     */
    public boolean isReportDescriptionDisplayed() {
        Log.message( "Verifing Recent Session Description is displayed" );
        SMUtils.waitForElement( driver, pageDescription );
        return pageDescription.isDisplayed();
    }

    
    /**
     * To verify the help icon
     * 
     * @return
     */
    public boolean isHelpIconDisplayed() {
        Log.message( "Verifing reports help icon is displayed" );
        SMUtils.waitForElement( driver, helpIconRoot );
        WebElement iconWebElement = SMUtils.getWebElement( driver, helpIconRoot, childHelpIcon );
        return iconWebElement.isDisplayed();
    }
    
    
    /**
     * To get the course selection label
     * 
     * @return
     */
    public String getCourseSelectionLabel() {
        Log.message( "Getting Course Selection text" );
        SMUtils.waitForElement( driver, courseSelectionLabel );
        return courseSelectionLabel.getText().trim();
    }
    
    
    /**
     * To Verify the Label is displayed or not
     * 
     * @return
     */
    public boolean isDropdownLabelDisplayed( String dropdownName ) {
        Log.message( "Verifing drodpown Label is displayed" );
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equals( dropdownName ) ).allMatch( WebElement::isDisplayed );
    }
    
    /**
     * To get the student demographic drop-down labels for
     * 
     * @return
     */
    public List<String> getDropdownLabels() {
        Log.message( "Getting drodown labels!" );
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }
    
    
    /**
     * Get Text of select student By
     * 
     * @return
     */
    public String getSelectStudentBy() {
        SMUtils.waitForElement( driver, selectStudentBy );
        Log.message( "Get text of select student by" );
        return selectStudentBy.getText().trim();
    }

    
    /**
     * Verify Optional Filters is displaying
     * 
     * @return
     */
    public Boolean isOptionalFilterDisplaying() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterRoot, optionalFilter );
        Log.message( "Verify Optional filter is displaying" );
        return actualElement.isDisplayed();
    }
    
    
    /**
     * To handle the Warning pop-up while selecting display option as 'Student_ID'
     * 
     * @return
     */
    public void handleStudentPopup() {
        SMUtils.waitForElement( driver, studentIDPopupparent );
        SMUtils.getWebElementDirect( driver, studentIDPopupparent, studnetIDPopup, button );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentIDPopupparent, studnetIDPopup, button ) );

    }
}
