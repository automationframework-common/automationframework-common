package com.savvas.sm.reports.api.report;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class LoadSaveMasteryReportGraphQLTest extends UserAPI {

    String requestID;

    @Test ( dataProvider = "getDataforSaveMasteryReport", groups = { "SMK-59881", "GraphQL API to save Mastery report options", "API" }, priority = 1 )
    public void testSaveReportAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType, String reportType, String userType, String reportParameters ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        String payload = getPayload();
        String query;
        Response response = null;

        switch ( scenarioType ) {
            case "VALID_DATA":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );

                JSONObject responseObject = new JSONObject( response.getBody().asString() );
                JSONObject dataObject = responseObject.getJSONObject( "data" );
                JSONObject queryObject = dataObject.getJSONObject( "saveMasteryReportOption" );
                Log.message( "queryObject: " + queryObject );
                requestID = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + queryObject.getString( "requestId" ) + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                Log.message( "Request ID: " + requestID );
                break;
            case "INVALID_AUTHORIZATION":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + ReportAPIConstants.INVALID );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_ORG_ID":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, "\\\"\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_USER_ID":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_REPORT_TYPE":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_USER_TYPE":
                queryItem.put( ReportAPIConstants.USER_TYPE, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_REPORT_PARAMETERS":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_ORG-ID":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.INVALID_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INTEGER_USER_ID":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, Integer.toString( ReportAPIConstants.INTERGER_USERNAME ) );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "NON_EXISTING_ORG_ID":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.NON_EXISTING_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                break;
            case "INTEGER_ORG_ID":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, Integer.toString( ReportAPIConstants.INTERGER_USERNAME ) );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "SAME_PAYLOAD":
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        String responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : "No Response Code";
        // Validation

        if ( statusCode.equalsIgnoreCase( "200" ) ) {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        } else if ( response.getBody().asString().contains( statusCode ) ) {
            Log.assertThat( response.getBody().asString().contains( statusCode ), "The Status code is expected " + statusCode + " and actual " + statusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " is not Verified" );
        } else {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        }

        //Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataforSaveMasteryReport() {
        return new Object[][] { { "TC001", "200", "TC01_Verify 200 status when valid Request Payload is given", "VALID_DATA", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC002", "401", "TC02_Verify 200 status and Response Body with message \"Unauthorized\" & code as \"401\" when invalid/expired authorization is given.", "INVALID_AUTHORIZATION", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC003", "400", "TC03_Verify 200 status and Response Body with message \"Bad Request\" & code as \"400\" when invalid/Empty Org-ID is given in Request Body.", "EMPTY_ORG_ID", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC004", "400", "TC04_Verify 200 status and Response Body with message \"Bad Request\" & code as \"400\" when invalid/Empty User-ID is given in Request Body.", "EMPTY_USER_ID", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC005", "400", "TC05_Verify 200 status and Response Body with message \"Bad Request\" & code as \"400\" when invalid/Empty Report Type is given in Request Body.", "EMPTY_REPORT_TYPE", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC006", "400", "TC06_Verify 200 status and Response Body with message \"Bad Request\" & code as \"400\" when invalid/empty User Type is given in Request Body.", "EMPTY_USER_TYPE", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC007", "200", "TC07_Verify 200 status and Response Body with message \"Unexpected token d in JSON at position 1\" when invalid/empty Report Parameter is given in Request Body.", "EMPTY_REPORT_PARAMETERS", "\\\"Mastery\\\"",
                        "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC008", "500", "TC08_Verify 200 status and Response Body with message \"Internal Server Error\" & code as \"500\" when Non existing Org-id - (orgID) is given in Request Body.", "INVALID_ORG-ID", "\\\"Mastery\\\"", "\\\"teacher\\\"",
                        "\\\"{}\\\"" },
                { "TC009", "400", "TC09_Verify 400 status when integer is given as User-Id and other fields in Request Body.", "INTEGER_USER_ID", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC010", "401", "TC10_Verify 200 status and Response Body with message \"Unauthorized\" & code as \"401\" when Non_existing org-id is given in Request Body.", "NON_EXISTING_ORG_ID", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC011", "400", "TC11_Verify 400 status when Integer is given for Org-ID instead of String in Request Body.", "INTEGER_ORG_ID", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                { "TC012", "200", "TC12_Verify 200 status when Same Request Payload(which was already used) is given.", "SAME_PAYLOAD", "\\\"Mastery\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" } };
    }

    @Test ( dataProvider = "getDataforLoadMasteryReport", groups = { "SMK-59881", "GraphQL API to load Mastery report options", "API" }, priority = 2 )
    public void testLoadReportAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        String payload = getLoadPayload();
        String query;
        Response response = null;

        switch ( scenarioType ) {
            case "VALID_DATA":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );

                //                JSONObject responseObject = new JSONObject( response.getBody().asString() );
                //                JSONObject dataObject = responseObject.getJSONObject( "data" );
                //                JSONObject queryObject = dataObject.getJSONObject( "saveMasteryReportOption" );
                //                Log.message( "queryObject: " +queryObject );
                //                requestID = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + queryObject.getString("requestId") + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                //                Log.message( "Request ID: " +requestID );
                break;
            case "INVALID_AUTHORIZATION":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + ReportAPIConstants.INVALID );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, "\\\"\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "NON_EXISTING_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.NON_EXISTING_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                break;
            case "NON_EXISTING_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "NON_EXISTING_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.NON_EXISTING_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY, query );
                Log.message( payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_MASTERY_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        String responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : "No Response Code";
        // Validation

        if ( statusCode.equalsIgnoreCase( "200" ) ) {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        } else if ( response.getBody().asString().contains( statusCode ) ) {
            Log.assertThat( response.getBody().asString().contains( statusCode ), "The Status code is expected " + statusCode + " and actual " + statusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " is not Verified" );
        } else {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        }

        //Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataforLoadMasteryReport() {
        return new Object[][] { { "TC013", "200", "TC13_Verify 200 status when valid Request Payload is given.", "VALID_DATA" },
                { "TC014", "401", "TC14_Verify 200 status and Response Body with message \"Unauthorized\" & code as \"401\"  when Invalid/Expired authorization is given.", "INVALID_AUTHORIZATION" },
                { "TC015", "400", "TC15_Verify 200 status and Response Body with message \"Bad Request\" & code as \"400\"  when Invalid/Empty Org-ID is given.", "EMPTY_ORG_ID" },
                { "TC016", "400", "TC16_Verify 200 status and Response Body with message \\\"Bad Request\\\" & code as \\\"400\\\" when Invalid/Empty User-ID is given.", "EMPTY_USER_ID" },
                { "TC017", "400", "TC17_Verify 200 status and Response Body with message \"Bad Request\" & code as \"400\" when Invalid/Empty Request-ID is given.", "EMPTY_REQUEST_ID" },
                { "TC018", "401", "TC18_Verify  200 status and Response Body with message \"Unauthorized\" & code as \"401\" when Non-Existing Org-ID is given.", "NON_EXISTING_ORG_ID" },
                { "TC019", "404", "TC19_Verify  200 status and Response Body with message \"Not Found\" & code as \"404\" when Non-Existing User-ID is given.", "NON_EXISTING_USER_ID" },
                { "TC020", "400", "TC20_Verify  200 status and Response Body with message \"Bad Request\" & code as \"400\" when Non-Existing Request-ID is given.", "NON_EXISTING_REQUEST_ID" } };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "SaveMasteryReportOption" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getLoadPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "LoadMasteryReportOption" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

}
