package com.savvas.sm.reports.ui.tests.admin.seu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.ui.pages.SystemEnrollmentAndUsagePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class SEUReportLoadAndSaveReportOptionsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String org;
    private List<String> teachers;
    private List<String> groups;
    SaveReportFilterPopup saveReportOptionPopup;
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String flexSchool;
    private String mathSchool;

    @BeforeClass(alwaysRun=true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );

        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify 'Save Report Option'  button in System enrollment and usage report page", groups = { "Smoke", "SMK-64019", "SaveReportOption", "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smSEULoadSaveReport_001: Verify 'Save Report Option'  button in System enrollment and usage report page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            SMUtils.logDescriptionTC( "Verify 'Save Report Option'  button in System enrollment and usage report page" );
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in SEU  report",
                    "The save report option is not displayed in SEU report" );
            Log.assertThat( !systemEnrollmentAndUsageReportPage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify user can click the 'Save Report Option'  button in System Enrollment And Usage report page" );
            SMUtils.logDescriptionTC( "Verify all available fields in 'Save Report Option  Popup." );
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to cancel the in 'Save Report Option ' Popup on CPR aggregate report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with new name." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with default Optional filters." );

            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            SaveReportFilterPopup saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is enabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not enabled if the user does not have already saved options" );
            Log.testCaseResult();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );

            Log.testCaseResult();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify If User enter more than 50 characters in new custom report configuration text box" );
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            SMUtils.logDescriptionTC( "Verify User can able to click the cancel and close(X) in save report option." );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to select the option in Existing custom report configuration dropdown ." );
            SMUtils.logDescriptionTC( "Verify the Existing custom report configuration dropdown if the user select the saved report and save the report." );
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with single options in all required and optional filters  with Subject (Math)", groups = { "Smoke", "SMK-64019", "SaveReportOption",
            "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smSEULoadSaveReport_002:Verify User can able to save the report option with single options in all required and optional filters  with Subject (Math)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters  with Subject (Math)" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilters();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Username (login)" );
            systemEnrollmentAndUsageReportPage.clickMaskStudentCheckBox();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandDemographicFilters();

            HashMap<String, String> getAllOptionBeforeSelected = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading) " );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_READING_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Reading)" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent-SM Math" );

            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC(
                    "Verify User can able to save the report option with 'Teacher' option in Additional Grouping,  and  'Username(Login)' in sort Dropdowm with Mask Student display on System Enrollment And Usage Report and load the report" );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_READING_WITH_CUSTOM );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Username (login)" );
            systemEnrollmentAndUsageReportPage.clickMaskStudentCheckBox();

            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameSaveReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameSaveReport );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameSaveReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.testCaseResult();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with all options in all required and optional filters " );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Username (login)" );
            systemEnrollmentAndUsageReportPage.clickMaskStudentCheckBox();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String saveReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( saveReport );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( saveReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if new teacher created for the organization after saved  the filter option with any one teacher", groups = { "SMK-64019", "SaveReportOption",
            "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smSEULoadSaveReport_003:Verify if new teacher created for the organization after saved  the filter option with any one teacher<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.logDescriptionTC( "Verify if new teacher created for the organization after saved  the filter option with any one teacher" );
            SMUtils.logDescriptionTC( "Verify if new group created by the teacher after saved  the filter option with all groups" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();
            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            //Creating teacher and student
            String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
            String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
            String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

            String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
            groupDetails.put( GroupConstants.GROUP_NAME, "groupNameRVC" );
            Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Group' option in Additional Grouping and  'Time spent -SM reading' in sort Dropdown with All options in student demographics dropdowns and load the report", groups = {
            "SMK-64019", "SaveReportOption", "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smSEULoadSaveReport_004:Verify User can able to save the report option with 'Group' option in Additional Grouping and  'Time spent -SM reading' in sort Dropdown with All options in student demographics dropdowns and load the report<small><b><i>["
                        + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'Total time spent' in sort Dropdown with Select any one options in all student demographics dropdowns and load the report" );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent-SM Math" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'Time Spent-custom courses' in sort Dropdown with Select multiple options in student demographics dropdowns and load the report" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent-Custom Course" );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,
                    Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,
                    Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,
                    Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );

            HashMap<String, String> getAllOptionBeforeSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSaved, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'grade' option in Additional Grouping and  'Time spent -SM math in sort Dropdown " );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent-SM Math" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );

            HashMap<String, String> getAllOptionBeforeSavedReport = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameSaveReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameSaveReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameSaveReport );
            HashMap<String, String> getAllOptionPostSaveReport = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameSaveReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSavedReport, getAllOptionPostSaveReport ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Group' option in Additional Grouping and  'Time spent -SM reading' in sort Dropdown with All options in student demographics dropdowns and load the report", groups = {
            "SMK-64019", "SaveReportOption", "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smSEULoadSaveReport_005:Verify User can able to save the report option with 'Group' option in Additional Grouping and  'Time spent -SM reading' in sort Dropdown with All options in student demographics dropdowns and load the report<small><b><i>["
                        + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent-SM Math" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'Total sessions' in sort Dropdown with Select 'Yes' option in 'Disability  Status' dropdown and 'English' in English Language Proficiency dropdown. " );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent-SM Math" );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );

            HashMap<String, String> getAllOptionBeforeSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSaved, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "Smoke", "SMK-64019", "SaveReportOption",
            "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smSEULoadSaveReport_006:Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_READING_WITH_CUSTOM );

            SaveReportFilterPopup saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is enabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not enabled if the user does not have already saved options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User can able to save the report option with  'Total sessions' in sort Dropdown with Select 'Yes' option in 'Disability  Status' dropdown and 'English' in English Language Proficiency dropdown. ", groups = { "SMK-64019",
            "SaveReportOption", "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smSEULoadSaveReport_007:Verify User can able to save the report option with  'Total sessions' in sort Dropdown with Select 'Yes' option in 'Disability  Status' dropdown and 'English' in English Language Proficiency dropdown. <small><b><i>["
                        + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Total Sessions" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'Average sessions time' in sort Dropdown with Select 'Female' option in 'Gender' dropdown and 'Migrant' in Migrant status dropdown. " );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Average Session Time" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );

            HashMap<String, String> getAllOptionBeforeSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSaved, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User can able to save the report option with  'Last Session date' in sort Dropdown with Select 'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown. ", groups = { "SMK-64019",
            "SaveReportOption", "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smSEULoadSaveReport_008:Verify User can able to save the report option with  'Last Session date' in sort Dropdown with Select 'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown. <small><b><i>["
                        + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'Last Session date' in sort Dropdown with Select 'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown. " );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'White' option in 'Race' dropdown and 'Hispanico or Latino' in special services dropdown. " );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Last Session Date" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 3 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 3 ) ) );

            HashMap<String, String> getAllOptionBeforeSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.testCaseResult();
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSaved, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if new Group created by the teacher after saved  the filter option with any one of the Group", groups = { "SMK-64019", "SaveReportOption",
            "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smSEULoadSaveReport_009:Verify if new Group created by the teacher after saved  the filter option with any one of the Group<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify if new Group created by the teacher after saved  the filter option with any one of the Group" );
            SMUtils.logDescriptionTC( "Verify if new teacher created for the organization after saved  the filter option with any one teacher" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            teachers = systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            groups = systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();

            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            //Creating teacher and student
            String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
            String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
            String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

            String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
            groupDetails.put( GroupConstants.GROUP_NAME, "groupNameRVC" );
            Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if delete the Group, after saved the filters options with the groups", groups = { "SMK-64019", "SaveReportOption", "System Enrollment and Usage Report: Admin - Input UI: Report Options" }, priority = 1 )
    public void smSEULoadSaveReport_010() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smSEULoadSaveReport_010:Verify if delete the Group, after saved the filters options with the groups<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            SMUtils.logDescriptionTC( "Verify if delete the Group, after saved the filters options with the groups" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();
            HashMap<String, String> getAllOptionBeforeSave = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            saveReportOptionPopup = systemEnrollmentAndUsageReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();
            Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

            //adding the student to the  group for the  teacher
            String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userId" ) ),
                    RBSDataSetup.organizationIDs.get( flexSchool ), new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            //delete group with assignment
            new GroupAPI().deleteGroup( newGroupId, teacherId, RBSDataSetup.organizationIDs.get( flexSchool ),
                    new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = systemEnrollmentAndUsageReportPage.getAllSelectedFilters();
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ),
                    "Report filter options saved successfully", "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}