package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class OptionalFiltersTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    AreaForGrowthPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    RecentSessionsPage recentSessionPage;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify all field available under Optional Filters field.", groups = {"Smoke", "SMK-57813", "RecentSessionReport", "OptionalFilters" }, priority = 1 )
    public void tcSMRecentSesssionOptionalFilter001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMRecentSesssionOptionalFilter001: Verify all field available under Optional Filters field. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Recent Sessions Report page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'SELECT STUDENTS BY' text under Optional Filters " );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Teacher Dropdown should display under Recent Session Report" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.TEACHER_LABEL ), "Teacher label is displaying", "Teacher label is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Grade Dropdown should display under Recent Session Report" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GRADE_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Group Dropdown should display under Recent Session Report" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Sort Dropdown should display under Recent Session Report" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Additional Grouping Dropdown should display under Recent Session Report" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Display Dropdown should display under Recent Session Report" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Mask Student Dispaly should be display ." );
            Log.assertThat( recentSessionPage.reportFilterComponent.getMaskStudentDisplayAndRemovePageBreaklbl().contains( ReportsUIConstants.MASK_STUDENT_DISPLAY ), "Mask Student is displaying", "Mask Student is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify ALL Checkbox should be dislayed for Teacher dropdown" );
            SMUtils.logDescriptionTC( "Verify SearchBar should be display under Teacher dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.TEACHER_LABEL ), "Search Bar is displaying for Teacher", "Search Bar is not displaying for teacher" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Teacher dropdown",
                    "All is not displaying for Teacher dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify ALL Checkbox should be dislayed for Grade dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Grade dropdown",
                    "All is not displaying for Grade dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify ALL Checkbox should be dislayed for Group dropdown" );
            SMUtils.logDescriptionTC( "Verify SearchBar should be display under Group dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.GROUP_LABEL ), "Search Bar is displaying for Group", "Search Bar is not displaying for Group" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Group dropdown",
                    "All is not displaying for Group dropdown" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all option available for Additional Grouping, Display dropdown", groups = {"Smoke", "SMK-57813", "RecentSessionReport", "OptionalFilters" }, priority = 1 )
    public void tcSMRecentSesssionOptionalFilter002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMRecentSesssionOptionalFilter002:Verify all field available under addition grouping and Display dropdown<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify all field available under additional grouping dropdown" );
            recentSessionPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ),
                    "All the additional grouping option are displaying", "Additional grouping option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify all field available under Display dropdown" );
            recentSessionPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all option available for Sort dropdown", groups = {"Smoke", "SMK-57813", "RecentSessionReport", "OptionalFilters" }, priority = 1 )
    public void tcSMRecentSesssionOptionalFilter003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMRecentSesssionOptionalFilter003: Verify all field available under Sort dropdown<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify all option available for Sort dropdown" );
            recentSessionPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).containsAll( ReportsUIConstants.SORT ), "All the sorts filter option are displaying",
                    "Sort filter option are not displaying" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify zero state message when no option slected for multi selet dropdown ", groups = { "SMK-57813", "RecentSessionReport", "OptionalFilters" }, priority = 1 )
    public void tcSMRecentSesssionOptionalFilter004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMRecentSesssionOptionalFilter004: Verify zero state message when no option slected for multi selet dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify message when no teacher has selected under Teacher dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_TEACHER ), "Zero state is displaying for teacher",
                    "Zero state is not displaying for teacher" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when no grade has selected under Grade dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_GRADES ), "Zero state is displaying for Grades",
                    "Zero state is not displaying for Grades" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when no group has selected under Group dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_GROUPS ), "Zero state is displaying for Groups",
                    "Zero state is not displaying for Groups" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify when single option selected for multi select dropdown", groups = { "SMK-57813", "RecentSessionReport", "OptionalFilters" }, priority = 1 )
    public void tcSMRecentSesssionOptionalFilter005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMRecentSesssionOptionalFilter005:Verify when single option selected for multi select dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify message when one teacher has selected under Teacher dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            String headerText = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).get( 1 );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( headerText ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( headerText ), "Selected Teacher is displaying", "Selected Teacher is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when one grade has selected under Grade dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            headerText = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).get( 1 );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( headerText ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equalsIgnoreCase( headerText ), "Selected Grade is displaying", "Selected Grade is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when one group has selected under Group dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            headerText = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).get( 1 );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( headerText ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( headerText ), "Selected Group is displaying", "Selected Group is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify when multiple option selected for multi select dropdown", groups = { "SMK-57813", "RecentSessionReport", "OptionalFilters" }, priority = 1 )
    public void tcSMRecentSesssionOptionalFilter006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMRecentSesssionOptionalFilter006: Verify when multiple option selected for multi select dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify message when multilple teacher has selected under Teacher dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            List<String> availableOptionList = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            List<String> selectedOptions = Arrays.asList( availableOptionList.get( 1 ), availableOptionList.get( 2 ) );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, selectedOptions );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_OPTION ), "Multiple teacher has selected",
                    "Selected Teacher is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when multiple group has selected under Teacher dropdown" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            availableOptionList = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            selectedOptions = Arrays.asList( availableOptionList.get( 1 ), availableOptionList.get( 2 ) );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, selectedOptions );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_OPTION ), "Multiple Group has selected",
                    "Selected group  is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when multiple  has selected under Teacher dropdown" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, selectedOptions );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            availableOptionList = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            selectedOptions = Arrays.asList( availableOptionList.get( 1 ), availableOptionList.get( 2 ) );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, selectedOptions );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_OPTION ), "Multiple grade has selected",
                    "Selected grade  is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
