package com.savvas.sm.reports.ui.tests.admin.afg;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;

import io.restassured.response.Response;

public class AFGDataGridIntegration extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String organizationName;
    private String teacherUsername;
    private String teacherName;
    private String adminUserId;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = ReportData.districtAdmin;
        adminUserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, RBSDataSetupConstants.USERID );
        Log.message( adminUserId );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        teacherUsername = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 1, usernameSuffixTest );
        teacherName = "(" + SMUtils.getKeyValueFromResponse( ReportData.teacherDetails.get( teacherUsername ), RBSDataSetupConstants.FIRSTNAME ) + " "
                + SMUtils.getKeyValueFromResponse( ReportData.teacherDetails.get( teacherUsername ), RBSDataSetupConstants.LASTNAME ) + ")";
    }

    @Test ( description = "tcAFGDataGrid001: Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns.", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGDataGrid001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGDataGrid001: Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
            Log.assertThat( afgReportViewerPage.getColumnHeaders().containsAll( AFGReportConstants.COLUMN_HEADERS ), "All the column headers are displaying properly", "column headers are not displaying properly!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Student, Date At Risk, Targeted Lesson columns should display under Skill Description." );
            Log.assertThat( afgReportViewerPage.getColumnSubHeaders().containsAll( AFGReportConstants.COLUMN_SUBHEADERS ), "All the subheaders under the skill description are displaying properly", "All the subheaders under the skill description are not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Skill Desciption, Level and Strand, when student is not mastered (Watch Closely)" );
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level and Strand, when student is At risk. " );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, "Math" );
            filters.put( ReportAdminConstants.COURSES, ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGDataGrid002: Verify Skill Desciption,Level  and Strand, for Default Reading course when student is not Mastered", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGDataGrid002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGDataGrid002: Verify Skill Desciption,Level  and Strand, for Default Reading course when student is not Mastered" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level  and Strand, for Default Reading course when student is not Mastered" );
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level and Strand, for Default Reading course when student is mastred" );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.READING );
            filters.put( ReportAdminConstants.COURSES, ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );
            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), ReportsUIConstants.READING, ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default reading course", "Skills are not displayed properly for default reading course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), ReportsUIConstants.READING, ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry ->{
                    List<String> expectedValueFromBFF = studentDetails.get( entry.getKey() );
                    Collections.sort(expectedValueFromBFF);
                     return  expectedValueFromBFF.equals( entry.getValue() );
                }),
                        "All the students are displaying properly for default reading course", "Student details are not displayed properly for default reading course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGDataGrid003: Verify Skill Desciption and Strand, for custom by setting -Math(IP-on) course when student is not mastered", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGDataGrid003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGDataGrid003: Verify Skill Desciption and Strand, for custom by setting -Math(IP-on) course when student is not mastered" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            String assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportData.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            Log.message( "assignmentName: " + assignmentName );

            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify Skill Desciption and Strand, for custom by setting -Math(IP-on) course when student is not mastered" );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportData.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().map( assignment -> SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ).filter(
                    assignmentId -> Objects.nonNull( assignmentId ) ).findFirst().orElse( null ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );
            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for custom by setting -Math(IP-on) course", "Skills are not displayed properly for custom by setting -Math(IP-on) course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for custom by setting -Math(IP-on) course", "Student details are not displayed properly for custom by setting -Math(IP-on) course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGDataGrid004: Verify Skill Desciption,Level  and Strand, for custom by setting -Reading(IP-on) course when student is at risk", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGDataGrid004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGDataGrid004: Verify Skill Desciption,Level  and Strand, for custom by setting -Reading(IP-on) course when student is at risk" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            String assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportData.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            Log.message( "assignmentName: " + assignmentName );
            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();
            SMUtils.logDescriptionTC( "Verify Skill Desciption, Level  and Strand, for custom by setting -Reading(IP-on) course when student is at risk" );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.READING );
            filters.put( ReportAdminConstants.COURSES, ReportData.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().map( assignment -> SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ).filter(
                    assignmentId -> Objects.nonNull( assignmentId ) ).findFirst().orElse( null ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );
            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for custom by setting -Reading(IP-on) course", "Skills are not displayed properly for custom by setting -Reading(IP-on) course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for custom by setting -Reading(IP-on) course", "Student details are not displayed properly for custom by setting -Reading(IP-on) course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGDataGrid005: Verify Skill Desciption,Level  and Strand, for custom by setting -Math(IP-off) course when student is at risk", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGDataGrid005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGDataGrid005: Verify Skill Desciption,Level  and Strand, for custom by setting -Math(IP-off) course when student is at risk" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            String assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            Log.message( "assignmentName: " + assignmentName );
            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level  and Strand, for custom by setting -Math(IP-off) course when student is at risk" );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().map( assignment -> SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ).filter(
                    assignmentId -> Objects.nonNull( assignmentId ) ).findFirst().orElse( null ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );
            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for  custom by setting -Math(IP-off) course", "Skills are not displayed properly for  custom by setting -Math(IP-off) course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for  custom by setting -Math(IP-off) course", "Student details are not displayed properly for  custom by setting -Math(IP-off) course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGDataGrid006:Verify Skill Desciption,Level  and Strand, for custom by setting -Reading(IP-off) course when student is at risk", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGDataGrid006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGDataGrid006: Verify Skill Desciption,Level  and Strand, for custom by setting -Reading(IP-off) course when student is at risk" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            String assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            Log.message( "assignmentName: " + assignmentName );
            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level  and Strand, for custom by setting -Reading(IP-off) course when student is at risk" );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.READING );
            filters.put( ReportAdminConstants.COURSES, ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().map( assignment -> SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ).filter(
                    assignmentId -> Objects.nonNull( assignmentId ) ).findFirst().orElse( null ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for custom by setting -Reading(IP-off) course", "Skills are not displayed properly for custom by setting -Reading(IP-off) math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for custom by setting -Reading(IP-off) course", "Student details are not displayed properly for custom by setting -Reading(IP-off) course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the skill details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, Map<String, String>> getSkillsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, Map<String, String>> SkillDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                skillDetails.put( AFGReportConstants.STRAND, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_NAME ) );
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                skillDetails.put( AFGReportConstants.TARGETED_LESSON,
                        SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LESSON_NUMBER ) + ". " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LESSON_TITLE ) );
                if ( skillDetails.get( AFGReportConstants.TARGETED_LESSON ).equals( ". " ) ) {
                    skillDetails.put( AFGReportConstants.TARGETED_LESSON, "" );
                }
                SkillDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), skillDetails );
            } );

        } );
        return SkillDetailFromResponse;
    }

    /**
     * To get the student details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, List<String>> getstudentsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, List<String>> studentDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.stream().forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                List<String> students = new ArrayList<>();
                JSONArray stduentArray = new JSONObject( skillDetail.toString() ).getJSONArray( AFGReportConstants.STUDENT_ROWS );
                List<String> studentDetailList = new ArrayList<>();
                IntStream.range( 0, stduentArray.length() ).forEach( itr -> studentDetailList.add( stduentArray.get( itr ).toString() ) );

                studentDetailList.stream().forEach( student -> {
                    String[] dateArray = SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.FAILED_DATE ).substring( 0, 10 ).split( "-" );
                    String dateAtRisk = dateArray[1] + "/" + dateArray[2] + "/" + dateArray[0];
                    students.add( SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.STUDENT_NAME ) + " - " + dateAtRisk );
                } );

                studentDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), students );
            } );

        } );
        return studentDetailFromResponse;
    }

}
