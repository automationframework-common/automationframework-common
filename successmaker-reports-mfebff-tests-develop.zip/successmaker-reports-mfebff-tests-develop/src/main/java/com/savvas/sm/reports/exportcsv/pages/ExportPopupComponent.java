package com.savvas.sm.reports.exportcsv.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ExportCsvOptions;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class ExportPopupComponent extends LoadableComponent<ExportPopupComponent> {

    WebDriver driver;
    private boolean isPageLoaded;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @IFindBy ( how = How.CSS, using = "export-data-modal cel-modal.export-data-modal", AI = false )
    private WebElement popupGrantRoot;

    @IFindBy ( how = How.CSS, using = "export-data-modal div.export-data-wrapper cel-radio-button-group", AI = false )
    private WebElement radioButtonGrantRoot;

    @IFindBy ( how = How.CSS, using = "export-data-modal div.export-data-wrapper cel-radio-button-group", AI = false )
    private List<WebElement> radioButtonGrantRootList;

    @IFindBy ( how = How.CSS, using = "div.available-columns-container cel-multi-checkbox", AI = false )
    private WebElement checkBoxGrantRoot;

    @IFindBy ( how = How.CSS, using = "div.selected-columns-container cel-multi-checkbox", AI = false )
    private WebElement selectedColumnsGrantRoot;

    @IFindBy ( how = How.CSS, using = "cel-icon-button[data-name~='chevron-right']", AI = false )
    private WebElement chevronRightArrow;

    @IFindBy ( how = How.CSS, using = "cel-icon-button[data-name~='chevron-left']", AI = false )
    private WebElement chevronLeftArrow;

    @IFindBy ( how = How.CSS, using = "cel-icon-button[data-name~='chevron-up']", AI = false )
    private WebElement chevronUpArrow;

    @IFindBy ( how = How.CSS, using = "cel-icon-button[data-name~='chevron-down']", AI = false )
    private WebElement chevronDownArrow;

    @IFindBy ( how = How.CSS, using = "div.left-controls cel-icon-button[data-name='chevron-double']", AI = false )
    private WebElement chevronDoubleRightArrow;

    @IFindBy ( how = How.CSS, using = "div.right-controls cel-icon-button[data-name='chevron-double']", AI = false )
    private WebElement chevronDoubleLeftArrow;

    @IFindBy ( how = How.CSS, using = "downloading-modal cel-modal-window", AI = false )
    private WebElement downloadingModalPopupRoot;

    @IFindBy ( how = How.CSS, using = "error-modal cel-modal-window:nth-child(2)", AI = false )
    private WebElement errorModalPopupRoot;

    /**
     * Child Elements
     */
    private String header = "div.top-container div.title-container h1";
    private String downloadingModalPopupHeader = "div.top-container div.title-container h2";
    private String downloadingModalPopupText = "div.top-container div.body-container span";
    private String closeIconRoot = "cel-icon-button";
    private String radioButtonChildRoot = "cel-radio-button";
    private String checkBoxChildRoot = "cel-checkbox-item";
    private String okBtnChildRoot = "div.footer-container cel-button.ok-button";
    private String cancelBtnChildRoot = "div.footer-container cel-button.cancel-button ";
    private String label = "label";
    private String input = "input";
    private String button = "button";
    private String errorPopupText = "div.error-container p";

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && SMUtils.waitForElement( driver, this.popupGrantRoot, 30 ) ) {
            if ( SMUtils.getWebElementDirect( driver, this.popupGrantRoot, this.header ).getText().trim().equalsIgnoreCase( ReportsUIConstants.EXPORT_DATA_HEADER ) ) {
                Log.message( "Export csv popup - Loaded Properly." );
            } else {
                Log.fail( "Export csv popup did not Loaded Properly. Site might be down.", driver );
            }
        } else {
            Log.fail( "Export csv popup did not Loaded Properly. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public ExportPopupComponent() {}

    /**
     * 
     * @param driver
     */
    public ExportPopupComponent( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * To Click the Default Export radio button.
     */
    public void clickExportDefaultRadioButton() {
        SMUtils.waitForElement( driver, radioButtonGrantRoot, 30 );
        SMUtils.getWebElementsDirect( driver, radioButtonGrantRoot, radioButtonChildRoot ).stream().filter( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim().equalsIgnoreCase( ReportsUIConstants.EXPORT_DEFAULT ) ).forEach(
                element -> {
                    try {
                        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                        if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                            Log.message( "Export Default button clicked successfully!!!" );
                        } else {
                            Log.message( "Getting issue in clicking the Export Default radio button....Retrying!!" );
                            throw new Exception();
                        }
                    } catch ( Exception e ) {
                        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                        if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                            Log.message( "Export Default button clicked successfully!!!" );
                        } else {
                            Log.fail( "Getting issue in clicking the Export Default radio button...." );
                        }
                    }
                } );
    }

    /**
     * To Click the Customize Export radio button.
     */
    public void clickCustomizeExportRadioButton() {
        SMUtils.waitForElement( driver, radioButtonGrantRoot, 30 );
        SMUtils.getWebElementsDirect( driver, radioButtonGrantRoot, radioButtonChildRoot ).stream().filter( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim().equalsIgnoreCase( ReportsUIConstants.CUSTOMIZE_EXPORT ) ).forEach(
                element -> {
                    try {
                        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                        if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                            Log.message( "Customize Export button clicked successfully!!!" );
                        } else {
                            Log.message( "Getting issue in clicking the Customize Export radio button....Retrying!!" );
                            throw new Exception();
                        }
                    } catch ( Exception e ) {
                        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                        if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                            Log.message( "Customize Export button clicked successfully!!!" );
                        } else {
                            Log.fail( "Getting issue in clicking the Customize Export radio button...." );
                        }
                    }
                } );
    }

    /**
     * To get the available columns for custom Export
     * 
     * @return
     */
    public List<String> getAllAvailableColumns() {
        SMUtils.waitForElement( driver, checkBoxGrantRoot, 30 );
        List<String> availableList = SMUtils.getWebElementsDirect( driver, checkBoxGrantRoot, checkBoxChildRoot ).stream().map( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim() ).collect( Collectors.toList() );
        Log.message( "The Avilable Columns from UI  - " + availableList );
        return availableList;
    }

    /**
     * To get the available columns for custom Export
     * 
     * @return
     */
    public List<String> getAllSelectedColumns() {
        SMUtils.waitForElement( driver, selectedColumnsGrantRoot, 30 );
        List<String> availableList = SMUtils.getWebElementsDirect( driver, selectedColumnsGrantRoot, checkBoxChildRoot ).stream().map( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim() ).collect( Collectors.toList() );
        Log.message( "The selected Columns from UI  - " + availableList );
        return availableList;
    }

    /**
     * To select the given columns for custom export
     * 
     * @param columns
     */
    public void selectAvailableColumns( List<String> columns ) {
        SMUtils.waitForElement( driver, checkBoxGrantRoot, 30 );
        SMUtils.getWebElementsDirect( driver, checkBoxGrantRoot, checkBoxChildRoot ).stream().filter( element -> columns.contains( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() ) ).forEach( element -> {
            try {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                    Log.message( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() + " - Selected successfully!!!" );
                } else {
                    Log.message( "Getting issue while selecting the column name -" + SMUtils.getWebElementDirect( driver, element, label ).getText().trim() + "....Retrying!!" );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                SMUtils.click( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                    Log.message( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() + " - Selected successfully!!!" );
                } else {
                    Log.fail( "Getting issue while selecting the column name -" + SMUtils.getWebElementDirect( driver, element, label ).getText().trim() );
                }
            }
        } );
    }

    /**
     * To select the given columns in selected columns
     * 
     * @param columns
     */
    public void selectSelectedColumns( List<String> columns ) {
        SMUtils.waitForElement( driver, selectedColumnsGrantRoot, 30 );
        SMUtils.getWebElementsDirect( driver, selectedColumnsGrantRoot, checkBoxChildRoot ).stream().filter( element -> columns.contains( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() ) ).forEach( element -> {
            try {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                    Log.message( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() + " - Selected successfully!!!" );
                } else {
                    Log.message( "Getting issue while selecting the column name -" + SMUtils.getWebElementDirect( driver, element, label ).getText().trim() + "....Retrying!!" );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                SMUtils.click( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                    Log.message( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() + " - Selected successfully!!!" );
                } else {
                    Log.fail( "Getting issue while selecting the column name -" + SMUtils.getWebElementDirect( driver, element, label ).getText().trim() );
                }
            }
        } );
    }

    /**
     * To get the selected columns for available columns
     * 
     * @param columns
     * @return
     */
    public List<String> getCheckedAvailableColumns() {
        List<String> selectedColumns = new ArrayList<>();
        SMUtils.waitForElement( driver, checkBoxGrantRoot, 30 );
        SMUtils.getWebElementsDirect( driver, checkBoxGrantRoot, checkBoxChildRoot ).stream().forEach( element -> {
            try {
                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                    selectedColumns.add( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() );
                }
            } catch ( Exception e ) {
                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                    selectedColumns.add( SMUtils.getWebElementDirect( driver, element, label ).getText().trim() );
                }
            }
        } );
        return selectedColumns;
    }

    /**
     * To click the chevron Right button
     */
    public void clickChevronRightButton() {
        SMUtils.waitForElement( driver, chevronRightArrow, 30 );
        if ( SMUtils.getWebElementDirect( driver, chevronRightArrow, button ).isEnabled() ) {
            try {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronRightArrow, button ) );
                if ( !SMUtils.getWebElementDirect( driver, chevronRightArrow, button ).isEnabled() ) {
                    Log.message( "Clicked the Chevron Right Button Properly!!!" );

                } else {
                    Log.message( "Issue in Clicking the Chevron Right Button!!!" );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronRightArrow, button ) );
                if ( !SMUtils.getWebElementDirect( driver, chevronRightArrow, button ).isEnabled() ) {
                    Log.message( "Clicked the Chevron Right Button Properly!!!" );

                } else {
                    Log.fail( "Issue in Clicking the Chevron Right Button!!!" );
                }
            }
        } else {
            Log.message( "Chevron Right Arrow - is disabled" );
        }
    }

    /**
     * To click the chevron Left button
     */
    public void clickChevronLeftButton() {
        SMUtils.waitForElement( driver, chevronLeftArrow, 30 );
        if ( SMUtils.getWebElementDirect( driver, chevronLeftArrow, button ).isEnabled() ) {
            try {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronLeftArrow, button ) );
                if ( !SMUtils.getWebElementDirect( driver, chevronLeftArrow, button ).isEnabled() ) {
                    Log.message( "Clicked the Chevron Left Button Properly!!!" );

                } else {
                    Log.message( "Issue in Clicking the Chevron Left Button!!!" );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronLeftArrow, button ) );
                if ( !SMUtils.getWebElementDirect( driver, chevronLeftArrow, button ).isEnabled() ) {
                    Log.message( "Clicked the Chevron Left Button Properly!!!" );

                } else {
                    Log.fail( "Issue in Clicking the Left Right Button!!!" );
                }
            }
        } else {
            Log.message( "Chevron Left Arrow - is disabled" );
        }
    }

    /**
     * To click the chevron Up button
     */
    public void clickChevronUpButton() {
        SMUtils.waitForElement( driver, chevronUpArrow, 30 );
        if ( SMUtils.getWebElementDirect( driver, chevronUpArrow, button ).isEnabled() ) {
            try {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronUpArrow, button ) );
                Log.message( "Clicked the Chevron up Button Properly!!!" );
            } catch ( Exception e ) {
                SMUtils.click( driver, SMUtils.getWebElementDirect( driver, chevronUpArrow, button ) );
                Log.message( "Clicked the Chevron up Button Properly!!!" );
            }
        } else {
            Log.message( "Chevron up Arrow - is disabled" );
        }
    }

    /**
     * To click the chevron down button
     */
    public void clickChevronDownButton() {
        SMUtils.waitForElement( driver, chevronDownArrow, 30 );
        if ( SMUtils.getWebElementDirect( driver, chevronDownArrow, button ).isEnabled() ) {
            try {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronDownArrow, button ) );
                Log.message( "Clicked the Chevron down Button Properly!!!" );
            } catch ( Exception e ) {
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronUpArrow, button ) );
                Log.message( "Clicked the Chevron down Button Properly!!!" );
            }
        } else {
            Log.message( "Chevron down Arrow - is disabled" );
        }
    }

    /**
     * To Click OK button
     */
    public void clickOkButton() {
        SMUtils.waitForElement( driver, popupGrantRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, popupGrantRoot, okBtnChildRoot, button ) );
        Log.message( "Clicked ok button in Export Report csv popup" );
    }

    /**
     * To Click cancel button
     */
    public void clickCancelButtonInExportReportCSVPopup() {
        SMUtils.waitForElement( driver, popupGrantRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, popupGrantRoot, cancelBtnChildRoot, button ) );
        Log.message( "Clicked cancel button in Export Report csv popup" );
    }

    /**
     * To Verifying the cancel Button is displaying or not
     * 
     */
    public boolean isCloseButtonDisplayedInExportReportCSVPopup() {
        try {
            SMUtils.waitForElement( driver, popupGrantRoot );
            return SMUtils.getWebElementDirect( driver, popupGrantRoot, cancelBtnChildRoot, button ).isDisplayed();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close button in Export Report csv popup!!!" );
        }
        return false;
    }

    /**
     * To get the downloading modal popup header
     * 
     * @return
     * @throws InterruptedException
     */
    public String getDownloadingModalPopupHeader() throws InterruptedException {
        SMUtils.waitForElement( driver, downloadingModalPopupRoot, 30 );
        String headerTxt = null;
        try {
            headerTxt = SMUtils.getWebElementDirect( driver, downloadingModalPopupRoot, downloadingModalPopupHeader ).getText().trim();
            Log.message( "The downloading popup header from UI - " + headerTxt );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while fetching the downloading popup header!!!" );
        }
        return headerTxt;
    }

    /**
     * To get the downloading modal popup Text
     * 
     * @return
     */
    public String getDownloadingModalPopupText() {
        SMUtils.waitForElement( driver, downloadingModalPopupRoot, 30 );
        String popupTxt = null;
        try {
            popupTxt = SMUtils.getWebElementDirect( driver, downloadingModalPopupRoot, downloadingModalPopupText ).getText().trim();
            Log.message( " The downloading popup header from UI - " + popupTxt );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while fetching the downloading popup header!!!" );
        }
        return popupTxt;
    }

    /**
     * To Verifying the Close Button is displaying or not
     * 
     */
    public boolean isCloseButtonDisplayedInDownloadingModalPopup() {
        try {
            SMUtils.waitForElement( driver, downloadingModalPopupRoot );
            return SMUtils.getWebElementDirect( driver, downloadingModalPopupRoot, okBtnChildRoot, button ).isDisplayed();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close button in delay popup!!!" );
        }
        return false;
    }

    /**
     * To Verifying the Close Button is enabled or not
     * 
     */
    public boolean isCloseButtonEnabledInDownloadingModalPopup() {
        SMUtils.waitForElement( driver, downloadingModalPopupRoot );
        try {
            return SMUtils.getWebElementDirect( driver, downloadingModalPopupRoot, okBtnChildRoot, button ).isEnabled();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close button in delay popup!!!" );
        }
        return false;
    }

    /**
     * To Verifying the Close Button is enabled or not
     * 
     */
    public boolean isCloseIconEnabledInDownloadingModalPopup() {
        SMUtils.waitForElement( driver, downloadingModalPopupRoot );
        try {
            return SMUtils.getWebElementDirect( driver, downloadingModalPopupRoot, closeIconRoot, button ).isEnabled();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close icon in delay popup!!!" );
        }
        return false;
    }

    /**
     * To click the close button
     */
    public void clickCloseButtonInDownloadingModalPopup() {
        SMUtils.waitForElement( driver, downloadingModalPopupRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, downloadingModalPopupRoot, okBtnChildRoot, button ) );
    }

    /**
     * To get the error modal popup header
     * 
     * @return
     * @throws InterruptedException
     */
    public String getErrorModalPopupHeader() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 40 );
        SMUtils.waitForElement( driver, errorModalPopupRoot, 30 );
        String headerTxt = null;
        try {
            headerTxt = SMUtils.getWebElementDirect( driver, errorModalPopupRoot, downloadingModalPopupHeader ).getText().trim();
            Log.message( " The error popup header from UI - " + headerTxt );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while fetching the error popup header!!!" );
        }
        return headerTxt;
    }

    /**
     * To get the error modal popup Text
     * 
     * @return
     */
    public String getErrorModalPopupText() {
        SMUtils.waitForElement( driver, errorModalPopupRoot, 30 );
        String popupTxt = null;
        try {
            popupTxt = errorModalPopupRoot.findElement( By.cssSelector( errorPopupText ) ).getText().trim();
            Log.message( "The error modal popup text from UI - " + popupTxt );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while fetching the error popup text!!!" );
        }
        return popupTxt;
    }

    /**
     * To Verifying the Close Button is displaying or not
     * 
     */
    public boolean isCloseButtonDisplayedInErrorModalPopup() {
        try {
            SMUtils.waitForElement( driver, errorModalPopupRoot );
            return SMUtils.getWebElementDirect( driver, errorModalPopupRoot, okBtnChildRoot, button ).isDisplayed();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close button in error popup!!!" );
        }
        return false;
    }

    /**
     * To Verifying the Close Button is enabled or not
     * 
     */
    public boolean isCloseButtonEnabledInErrorModalPopup() {
        SMUtils.waitForElement( driver, errorModalPopupRoot );
        try {
            return SMUtils.getWebElementDirect( driver, errorModalPopupRoot, okBtnChildRoot, button ).isEnabled();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close button in error popup!!!" );
        }
        return false;
    }

    /**
     * To Verifying the Close Button is enabled or not
     * 
     */
    public boolean isCloseIconEnabledInErrorModalPopup() {
        SMUtils.waitForElement( driver, errorModalPopupRoot );
        try {
            return SMUtils.getWebElementDirect( driver, errorModalPopupRoot, closeIconRoot, button ).isEnabled();
        } catch ( Exception e ) {
            Log.message( "Getting issue while verifying the close icon in error popup!!!" );
        }
        return false;
    }

    /**
     * To click the close button
     */
    public void clickCloseButtonInErrorModalPopup() {
        SMUtils.waitForElement( driver, errorModalPopupRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, errorModalPopupRoot, okBtnChildRoot, button ) );
    }

    /**
     * To get the Export CSV popup Header
     * 
     * @return
     */
    public String getExportReportCsvPopupHeader() {
        SMUtils.waitForElement( driver, popupGrantRoot );
        try {
            return SMUtils.getWebElementDirect( driver, popupGrantRoot, header ).getText().trim();
        } catch ( Exception e ) {
            Log.message( "Getting issue while get the header in Export CSV popup!!!" );
        }
        return null;
    }

    /**
     * To click Chevron Double Right button
     */
    public void clickChevronDoubleRightButton() {
        SMUtils.waitForElement( driver, chevronDoubleRightArrow, 30 );
        try {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronDoubleRightArrow, button ) );
            if ( !SMUtils.getWebElementDirect( driver, chevronDoubleRightArrow, button ).isEnabled() ) {
                Log.message( "Clicked the Chevron Double Right Button Properly!!!" );

            } else {
                Log.message( "Issue in Clicking the Chevron Double Right Button!!!" );
                throw new Exception();
            }
        } catch ( Exception e ) {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronDoubleRightArrow, button ) );
            if ( !SMUtils.getWebElementDirect( driver, chevronDoubleRightArrow, button ).isEnabled() ) {
                Log.message( "Clicked the Chevron Right Button Properly!!!" );

            } else {
                Log.fail( "Issue in Clicking the Chevron Double Right Button!!!" );
            }
        }
    }

    /**
     * To click Chevron Double Left button
     */
    public void clickChevronDoubleLeftButton() {
        SMUtils.waitForElement( driver, chevronDoubleLeftArrow, 30 );
        try {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronDoubleLeftArrow, button ) );
            if ( !SMUtils.getWebElementDirect( driver, chevronDoubleLeftArrow, button ).isEnabled() ) {
                Log.message( "Clicked the Chevron Double Left Button Properly!!!" );

            } else {
                Log.message( "Issue in Clicking the Chevron Double Left Button!!!" );
                throw new Exception();
            }
        } catch ( Exception e ) {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chevronDoubleLeftArrow, button ) );
            if ( !SMUtils.getWebElementDirect( driver, chevronDoubleLeftArrow, button ).isEnabled() ) {
                Log.message( "Clicked the Chevron Left Button Properly!!!" );

            } else {
                Log.fail( "Issue in Clicking the Chevron Double Left Button!!!" );
            }
        }
    }

    /**
     * To check the Chevron double arrow is enabled or not
     * 
     * @return
     */
    public boolean isChevronDoubleRightButtonEnabled() {
        SMUtils.waitForElement( driver, chevronDoubleRightArrow, 30 );
        try {
            return SMUtils.getWebElementDirect( driver, chevronDoubleRightArrow, button ).isEnabled();
        } catch ( Exception e ) {
            Log.message( "Issue while check the Chevron Double Right Button!!! Retrying..." );
            return SMUtils.getWebElementDirect( driver, chevronDoubleRightArrow, button ).isEnabled();
        }
    }

    /**
     * To get the Export Type labels
     * 
     * @return
     */
    public List<String> getExportTypeLabels() {
        return SMUtils.getWebElementsDirect( driver, radioButtonGrantRoot, radioButtonChildRoot ).stream().map( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getAllExportTypeLabels() {
        List<String> list = new ArrayList<>();
        radioButtonGrantRootList.stream().forEach( parentElement -> {
            SMUtils.getWebElementsDirect( driver, parentElement, radioButtonChildRoot ).stream().map( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim() ).forEach( text -> list.add( text ) );
        } );
        return list;
    }

    /**
     * To check whether the default export radio button is selected or not
     */
    public boolean isDefaultExportRadioButtonSelected() {
        SMUtils.waitForElement( driver, radioButtonGrantRoot, 30 );
        WebElement parentElement = SMUtils.getWebElementsDirect( driver, radioButtonGrantRoot, radioButtonChildRoot ).stream().filter(
                element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim().equalsIgnoreCase( ReportsUIConstants.EXPORT_DEFAULT ) ).findFirst().orElse( null );
        if ( Objects.nonNull( parentElement ) ) {
            return Boolean.valueOf( SMUtils.getWebElementDirect( driver, parentElement, input ).getAttribute( "aria-checked" ) );
        } else {
            return false;
        }
    }

    /**
     * To click the close button in CSV Export Popup
     */
    public void clickCloseButtonInCsvExportPopup() {
        SMUtils.waitForElement( driver, popupGrantRoot );
        try {
            SMUtils.isElementPresent( popupGrantRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, popupGrantRoot, closeIconRoot, button ) );
        } catch ( Exception e ) {
            Log.message( "Unable to click close button. Check whether CSV Download popup is displayed" );
        }
    }

    public void clickRadioButton( ExportCsvOptions exportOption ) {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            SMUtils.waitForElement( driver, radioButtonGrantRoot, 30 );
            radioButtonGrantRootList.stream().forEach( parentElement -> {
                SMUtils.getWebElementsDirect( driver, parentElement, radioButtonChildRoot ).stream().filter( element -> SMUtils.getWebElementDirect( driver, element, label ).getText().trim().equalsIgnoreCase( exportOption.toString() ) ).forEach(
                        element -> {
                            try {
                                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                                    Log.message( "Customize Export button clicked successfully!!!" );
                                } else {
                                    Log.message( "Getting issue in clicking the Customize Export radio button....Retrying!!" );
                                    throw new Exception();
                                }
                            } catch ( Exception e ) {
                                SMUtils.click( driver, SMUtils.getWebElementDirect( driver, element, input ) );
                                if ( Boolean.TRUE.equals( Boolean.valueOf( SMUtils.getWebElementDirect( driver, element, input ).getAttribute( "aria-checked" ) ) ) ) {
                                    Log.message( "Customize Export button clicked successfully!!!" );
                                } else {
                                    Log.fail( "Getting issue in clicking the Customize Export radio button...." );
                                }
                            }
                        } );
            } );

        } catch ( Exception e ) {
            Log.message( "Issue on selecting radio button - " + exportOption.toString() );
        }
    }

}
