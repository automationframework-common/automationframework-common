package com.savvas.sm.reports.ui.tests.teacher.psr;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.lang.reflect.Method;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class is used to test PSR teacher input screen
 * 
 * @author lakshmi.ramalingam
 *
 */
public class PSRTeacherReportTest extends EnvProperties {
	private String smUrl;
	private String browser;
	private String username;
	private String password;
	private String teacherDetails;
	private String configGraphQL;
	public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);

	@BeforeClass(alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		configGraphQL = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, "userName");
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

	}

	@Test(description = "Verify PSR input screen & UI validation", groups = { "Smoke", "SMK-65102", "Teacher Dashboard",
			"Reports", "Prescriptive Scheduling Report" }, priority = 1)
	public void tcPrescriptiveScheduling001() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		try {

			Log.testCaseInfo("tcSMLeftNav01: Verify Prescriptive Scheduling Page title and description <small><b><i>["
					+ browser + "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher("teacher_d12", "testing123$");

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			SMUtils.logDescriptionTC(
					"TC:01 Verify the teacher can able to see Prescriptive Scheduling option should present under the Reports top menu.");
			Log.assertThat(
					dashBoardPage.reportFilterComponent
							.subNavigationMenuisDisplayed(ReportTypes.PRESCRIPTIVE_SCHEDULING),
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
					"The Recent Sessions is displayed in Report MFE sub-navigation");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:02 Verify Prescriptive Scheduling Report input Page should be Open after teacher click the Prescriptive Scheduling option in sub menu.");
			SMUtils.logDescriptionTC(
					"Verify the click function on Prescriptive Scheduling menu navigates the user to the Prescriptive Scheduling Page");
			Log.assertThat(prescriptiveschedulingPage.isPSRsubNavigationSelected(),
					"The Prescriptive Scheduling in sub navigation is selected and it is verified",
					"The Prescriptive Scheduling in sub navigation is not selected and it is verified");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:03 Verify the title of Prescriptive Scheduling page is displayed");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isReportTitleDisplayed(),
					"The Prescriptive Scheduling title is displayed and it is verified",
					"The Prescriptive Scheduling title is not displayed and it is verified");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:04 Verify the page description is displayed below the title of the Prescriptive Scheduling Page");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isReportDescriptionDisplayed(),
					"The Prescriptive Scheduling description is displayed and it is verified",
					"The Prescriptive Scheduling description is not displayed and it is verified");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:05 Verify the help icon (?) is displayed along with the title of the Prescriptive Scheduling Page");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isHelpIconDisplayed(),
					"The Prescriptive Scheduling help icon is displayed and it is verified",
					"The Recent Session help icon is not displayed and it is verified");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:06 Verify the Course Selection label is displayed in the Prescriptive Scheduling report page");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getCourseSelectionLabel()
							.equalsIgnoreCase(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL),
					"The Course Selection label is verified ", "The Course Selection label is not verified");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the subject label and drop down", groups = { "SMK-65102", "Teacher Dashboard",
			"Reports", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling002(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(" Verify the Subject label and drop down <small><b><i>[" + browser + "]</b></i></small>");

		DevTools tools = null;

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			if (context != null && context.getIncludedGroups() != null
					&& Arrays.stream(context.getIncludedGroups()).anyMatch(group -> group.equals("mock"))) {

				String json = DevToolsUtils.readJsonResponse("PSR_ReadingAssignments.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}


			SMUtils.logDescriptionTC(
					"TC:07 Verify the Subject label is displayed in the Prescriptive Scheduling report page");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isDropdownLabelDisplayed(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL),
					"The Subject label is displayed", "The Subject label is not displayed");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getDropdownLabels()
							.contains(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL),
					"The Subject label is verified ", "The Subject label is not verified ");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:08 Verify the Subject drop down is displayed in the Prescriptive Scheduling report Page");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isSingleSelectDropDownDisplayed(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL),
					"The Subject drop down is displayed", "The Subject drop down is not displayed");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:09 Verify the default text is displayed in the subject drop down");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getDefaultSubjectFromSingleSelectDropdown()
							.equals(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_WATERMARK),
					"The Subject drop down default text is verified",
					"The Subject drop down default text is not verified");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:10 Verify the drop down values of the Subject drop down values");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSubjectDropdown()
							.containsAll(ReportsUIConstants.SUBJECTS),
					"The Subject drop down values are verified", "The Subject drop down values are not verified");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}

	}

	@Test(description = "Verify the functionality of Save Report Option drop down", groups = { "SMK-65102",
			"Teacher Dashboard", "Reports", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling003(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(" Verify the functionality of Save Report Option drop down <small><b><i>[" + browser
				+ "]</b></i></small>");

		DevTools tools = null;
		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			if (context != null && context.getIncludedGroups() != null
					&& Arrays.stream(context.getIncludedGroups()).anyMatch(group -> group.equals("mock"))) {

				String json = DevToolsUtils.readJsonResponse("PSR_SaveReport.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetAllReportOption", "post", json);

				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());

			} 

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			SMUtils.logDescriptionTC(
					"TC:11 Verify Saved Report Option label is displayed in the Prescriptive Scheduling Page");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.isDropdownLabelDisplayed(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL),
					"The Prescriptive scheduling Save Report Option label is displayed and it is verified",
					"The Prescriptive Scheduling Save Report Option label is not displayed and it is verified");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getDropdownLabels()
							.contains(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL),
					"The Prescriptive Scheduling Save Report Option label text is displayed as "
							+ ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL,
					"The Prescriptive Scheduling Save Report Option label text is not displayed as "
							+ ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL);
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:12 Verify Saved Report Option drop down is displayed in the Prescriptive Scheduling page");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.isSingleSelectDropDownDisplayed(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL),
					"The Prescriptive scheduling Save Report Option drop down is displayed and it is verified",
					"The Prescriptive Scheduling Save Report Option drop down is not displayed and it is verified");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:13 Verify the default text in the displayed in the Saved Report Option drop down");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromSingleSelectDropdown(
									ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL)
							.equals(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK),
					"The Prescriptive Scheduling Save Report Option drop down water mark text is displayed as "
							+ ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK,
					"The Prescriptive Scheduling Save Report Option drop down water mark text is not displayed as "
							+ ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK);
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:14 Verify the arrow button is displayed in the Saved Report Option drop down");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL),
					"The Prescriptive scheduling Save Report Option drop down arrow is displayed and it is verified",
					"The Prescriptive Scheduling Save Report Option drop down arrow is not displayed and it is verified");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getSingleSelectDropdownArrowDirection(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL).equals("Down"),
					"The arrow is in downward direction when it is collapsed",
					"The arrow is in Upward direction when it is collapsed");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:15 Verify the Saved Report option drop down is listed with saved report options");
			prescriptiveschedulingPage.reportFilterComponent.expandSingleSelectDropdown("SAVED REPORT OPTIONS");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL).size() > 0,
					"The saved options values are displayed", "The saved options values are not displayed");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:16 Verify the Saved report option name is displayed when it is selected");
			String selectingOption = prescriptiveschedulingPage.reportFilterComponent
					.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL)
					.get(0);
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL, selectingOption);
			Log.message(selectingOption);
			String savedReportWaterMarkText = prescriptiveschedulingPage.reportFilterComponent
					.getPlaceHolderFromSingleSelectDropdown(
							ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL);
			Log.message(savedReportWaterMarkText);
			Log.assertThat(selectingOption.contentEquals(savedReportWaterMarkText),
					"The saved report option is displaying the selected saved Report",
					"The saved report option is not displaying the selected saved Report!");
			Log.testCaseResult();

			Log.assertThat(savedReportWaterMarkText.equals(selectingOption),
					"The selected option is displayed in the drop down text",
					"The selected option is not displayed in the drop down text");

		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}

	}

	@Test(description = "Verify all field available under Optional Filters field.", groups = { "Smoke", "SMK-65102",
			"Teacher Dashboard", "Reports", "Prescriptive Scheduling Report" }, priority = 1)
	public void tcPrescriptiveScheduling004() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo(" Verify all field available under Optional Filters field. <small><b><i>[" + browser
					+ "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			SMUtils.logDescriptionTC(
					"TC:17 Verify Optional Filters should display on Prescriptive Scheduling Report page");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isOptionalFilterDisplaying(),
					"Optional filter is displaying", "Optional Filter is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:18 Verify Students Dropdown should display under Prescriptive Scheduling Report ");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.isDropdownLabelDisplayed(
							ReportsUIConstants.STUDENT_LABEL),
					"Student dropdown label is displayed under PSR",
					"Student dropdown label is not displayed under PSR!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:19 Verify Group Dropdown should display under Prescriptive Scheduling Report");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isDropdownLabelDisplayed(ReportsUIConstants.GROUP_LABEL),
					"Group label is not displaying", "Group lebel is displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:20 Verify Sort Dropdown should display under Prescriptive Scheduling Report");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isDropdownLabelDisplayed(ReportsUIConstants.SORT_LABEL),
					"Sort header is displaying", "Sort header is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:21 Verify Additional Grouping Dropdown should display under Prescriptive Scheduling Report");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isDropdownLabelDisplayed(ReportsUIConstants.ADDITIONAL_GROUPING_LBL),
					"Additional grouping is displaying", "Additional grouping is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:22 Verify Display Dropdown should display under Prescriptive Scheduling Report");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isDropdownLabelDisplayed(ReportsUIConstants.DISPLAY_LABEL),
					"Displaying header is displaying", "Displaying header is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:23 Verify Mask Student Dispaly should be display .");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getMaskStudentDisplayAndRemovePageBreaklbl()
							.containsAll(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_MASK_STUDENT_DISPLAY),
					"Mask Student is displaying", "Mask Student is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:24 Verify  SET TARGET DATE label is displayed under PSR .");
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.isDropdownLabelDisplayed(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SET_TARGET_DATE),
					"SET TARGET DATE label is displayed under PSR .",
					"SET TARGET DATE label is not displayed under PSR .");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:25 Verify  SET TARGET LEVEL PER GRADE label is displayed under PSR .");
			Log.assertThat(prescriptiveschedulingPage.isSetTargetLevelPerGradeIsDisplayed(),
					"SET TARGET DATE label is displayed under PSR .",
					"SET TARGET DATE label is not displayed under PSR .");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify all option available for Additional Grouping, Display dropdown", groups = { "SMK-65102",
			"Smoke", "Teacher Dashboard", "Reports", "Prescriptive Scheduling Report" }, priority = 1)
	public void tcPrescriptiveScheduling005() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("Verify all field available under addition grouping and Display dropdown<small><b><i>["
					+ browser + "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			SMUtils.logDescriptionTC("TC:26 Verify all field available under additional grouping dropdown");
			prescriptiveschedulingPage.reportFilterComponent
					.expandSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL)
							.containsAll(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_ADDITIONAL_GROUPING),
					"All the additional grouping option are displaying",
					"Additional grouping option are not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:27 Verify all field available under Display dropdown");
			prescriptiveschedulingPage.reportFilterComponent
					.expandSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL)
							.containsAll(ReportsUIConstants.DISPLAY),
					"All the display option are displaying", "Display option are not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:28 Verify all field available under Sort dropdown");
			prescriptiveschedulingPage.reportFilterComponent.expandSingleSelectDropdown(ReportsUIConstants.SORT_LABEL);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL)
							.containsAll(ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SORT),
					"All the sort option are displaying as expected",
					"Sort option values are not displaying as expected!");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the teacher able to select Groups and Students Radio button", groups = { "SMK-65102",
			"Smoke", "Teacher Dashboard", "Reports", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling006(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify the teacher able to select Groups and Students Radio button <small><b><i>[" + browser
				+ "]</b></i></small>");
		DevTools tools = null;

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			if (context != null && context.getIncludedGroups() != null
					&& Arrays.stream(context.getIncludedGroups()).anyMatch(group -> group.equals("mock"))) {

				String json = DevToolsUtils.readJsonResponse("PSR_GroupsAndStudent.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			SMUtils.logDescriptionTC("TC:29 Verify the teacher able to select Groups radio button under PSR Report");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isGroupButtonClickable(),
					"The teacher able to select Groups radio button under PSR Report",
					"The teacher is not able to select Groups radio button under PSR Report");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:30 Verify the teacher able to select Groups radio button under PSR Report");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isStudentRadioButtonClickable(),
					"The teacher able to select Groups radio button under PSR Report",
					"The teacher is not able to select Groups radio button under PSR Report");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:31 Verify as a teacher able see run report option is diabled as default under PSR Report");
			Log.assertThat(prescriptiveschedulingPage.isRunReportDisabled(),
					"Teacher able see run report option is diabled as default under PSR Report",
					"Teacher is not able see run report option is diabled as default under PSR Report");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:32 Verify as a teacher able see Save Report option is diabled as default under PSR Report");
			Log.assertThat(prescriptiveschedulingPage.isSaveReportOptionDisabled(),
					"Teacher able see Save Report option is diabled as default under PSR Report",
					"Teacher is not able see Save Report option is diabled as default under PSR Report");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:33 Verify as a teacher able see Reset option is diabled as default under PSR Report");
			Log.assertThat(prescriptiveschedulingPage.isResetBtnDisabled(),
					"Teacher able see Reset option is diabled as default under PSR Report",
					"Teacher is not able see Reset option is diabled as default under PSR Report");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:34 Verify as a teacher able see Save Report option is diabled as default under PSR Report");
			Log.assertThat(prescriptiveschedulingPage.isSaveReportOptionDisabled(),
					"Teacher able see Save Report option is diabled as default under PSR Report",
					"Teacher is not able see Save Report option is diabled as default under PSR Report");
			Log.testCaseResult();
		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}

			driver.quit();
		}

	}

	@Test(description = "Verify the Set Target Date, Run Report and Save Report Options field  ", groups = {
			"SMK-65102", "Teacher Dashboard", "Reports", "Prescriptive Scheduling Report" }, priority = 1)
	public void tcPrescriptiveScheduling007() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo(" Verify the Set Target Date, Run Report and Save Report Options field  <small><b><i>["
					+ browser + "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			SMUtils.logDescriptionTC(
					"TC:35 Verify the teacher able to select selection of Current Date in 'Set Target Date' field");
			Log.assertThat(prescriptiveschedulingPage.selectTargetDateAsCurrentDate(),
					"The teacher able to select selection of Current Date in 'Set Target Date' field",
					" The teacher is not able to select selection of Current Date in 'Set Target Date' field");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:36 Verify the Run Report button enabling or not after selecting 'Set Target Date' field");
			prescriptiveschedulingPage.fillGrade("5");
			Log.assertThat(prescriptiveschedulingPage.isRunReportEnabled(),
					"The Run Report button enabling after selecting 'Set Target Date' field",
					"The Run Report button is not enabling after selecting 'Set Target Date' field");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:37 Verify the Run Report button Clickable or not");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.clickRunReportButton(),
					"The Run Report button Clickable", "The Run Report button is not Clickable");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:38 Verify the Save Report Options button is Enabled");
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isSaveReportButtonEnabled(),
					"The Save Report Options button is Enabled", "The Save Report Options button is not Enabled");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:39 Verify the Save Report Options pop is appearing when teacher click Save Report Options button");
			SaveReportFilterPopup s = prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			Log.assertThat(s.isCancelButtonDisplayed(),
					"The Save Report Options pop is appearing when teacher click Save Report Options button",
					"The Save Report Options pop is not appearing when teacher click Save Report Options button");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the teacher can able to single option from single select dropdown in PSR Teacher report", groups = {
			"SMK-65102", "Smoke", "Teacher Dashboard", "Reports", "Prescriptive Scheduling Report",
			"mock" }, priority = 1)
	public void tcPrescriptiveScheduling008(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		DevTools tools = null;
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			if (context != null && context.getIncludedGroups() != null
					&& Arrays.stream(context.getIncludedGroups()).anyMatch(group -> group.equals("mock"))) {
				Log.testCaseInfo(
						"tc008: Verify the Groups dropdown matches with the two mocked Group count. <small><b><i>["
								+ browser + "]</b></i></small>");

				SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the two mocked Group count");

				String json = DevToolsUtils.readJsonResponse("PSR_GroupAndStudentDetails_twoGroups.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());

			}


			SMUtils.logDescriptionTC("TC:41 Verify the teacher able to select Reading from Subject dropdown");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.READING);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromSingleSelectSubjectDropdown(
									ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL)
							.equalsIgnoreCase(ReportsUIConstants.READING),
					"The teacher able to select Reading from Subject dropdown",
					"The teacher is not able to select Reading from Subject dropdown");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:42 Verify the teacher able to select Grade then Group from Additional Grouping dropdown");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_ADDITIONAL_GROUPING_LABEL,
					ReportsUIConstants.GRADETHENGROUP);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromSingleSelectSubjectDropdown(
									ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_ADDITIONAL_GROUPING_LABEL)
							.equalsIgnoreCase(ReportsUIConstants.GRADETHENGROUP),
					"The teacher able to select Grade then Group from Additional Grouping dropdown",
					"The teacher is not able to select Grade then Group from Additional Grouping dropdown");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:43 Verify the teacher able to select Student Username from Display dropdown");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromSingleSelectSubjectDropdown(
									ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_DISPLAY_LABEL)
							.equalsIgnoreCase(ReportsUIConstants.STUDENTUSERNAME),
					"The teacher able to select Student Username from Display dropdown",
					"The teacher is not able to select Student Username from Display dropdown");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:43 Verify the teacher able to select Current Course Level from Sort dropdown");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SORT_LABEL, ReportsUIConstants.CURRENTCOURSELEVEL);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromSingleSelectSubjectDropdown(
									ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SORT_LABEL)
							.equalsIgnoreCase(ReportsUIConstants.CURRENTCOURSELEVEL),
					"The teacher able to select Current Course Level from Sort dropdown",
					"The teacher is not able to select Current Course Level from Sort dropdown");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);

			}
			driver.quit();
		}
	}

	@Test(description = "Verify when single option selected for multi select dropdown", groups = { "SMK-65102",
			"Teacher Dashboard", "Reports", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling009(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		DevTools tools = null;
		Log.testCaseInfo("Verify when single option selected for multi select dropdown <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			if (context != null && context.getIncludedGroups() != null
					&& Arrays.stream(context.getIncludedGroups()).anyMatch(group -> group.equals("mock"))) {

				SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the one mocked Group count");

				String json = DevToolsUtils.readJsonResponse("PSR_GroupAndStudentDetails_OneGroup.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());

			} 
			String headerText = "";


			SMUtils.logDescriptionTC("TC:42 Verify message when one student has selected under student dropdown");
			prescriptiveschedulingPage.reportFilterComponent.clickStudentRadioButton();
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.STUDENT_LABEL, Arrays.asList(ReportsUIConstants.SELECT_ALL));
			headerText = prescriptiveschedulingPage.reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL).get(1);
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL, Arrays.asList(headerText));
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL)
							.equalsIgnoreCase(headerText),
					"Selected Student is displaying", "Selected Student is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:43 Verify message when one group has selected under Group dropdown");
			prescriptiveschedulingPage.reportFilterComponent.clickGroupRadioButton();
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUP_LABEL, Arrays.asList(ReportsUIConstants.SELECT_ALL));
			headerText = prescriptiveschedulingPage.reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL).get(1);
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL, Arrays.asList(headerText));
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent
					.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL).equalsIgnoreCase(headerText),
					"Selected Group is displaying", "Selected Group is not displaying");
			Log.testCaseResult();

		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);

			}
			driver.quit();
		}

	}

	@Test(description = "Verify when multiple option selected for multi select dropdown", groups = { "SMK-57813",
			"Prescriptive Scheduling Report", "OptionalFilters" }, priority = 1)
	public void tcPrescriptiveScheduling010() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo(" Verify when multiple option selected for multi select dropdown <small><b><i>[" + browser
					+ "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveschedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			List<String> availableOptionList = prescriptiveschedulingPage.reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);
			List<String> selectedOptions = Arrays.asList(availableOptionList.get(1));

			SMUtils.logDescriptionTC("TC:45 Verify message when multiple group has selected under Group dropdown");
			prescriptiveschedulingPage.reportFilterComponent.clickGroupRadioButton();
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUP_LABEL, Arrays.asList(ReportsUIConstants.SELECT_ALL));
			availableOptionList = prescriptiveschedulingPage.reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);
			selectedOptions = Arrays.asList(availableOptionList.get(1), availableOptionList.get(2));
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL, selectedOptions);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL)
							.equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
					"Multiple Groups has selected", "Selected group  is not displaying");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:46 Verify message when multiple  has selected under student dropdown");
			prescriptiveschedulingPage.reportFilterComponent.clickStudentRadioButton();
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.STUDENT_LABEL, Arrays.asList(ReportsUIConstants.SELECT_ALL));
			availableOptionList = prescriptiveschedulingPage.reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);
			selectedOptions = Arrays.asList(availableOptionList.get(1), availableOptionList.get(2));
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL, selectedOptions);
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent
							.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL)
							.equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
					"Multiple students has selected", "Selected students  is not displaying");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify whether the multiple option selected for multi select dropdown", groups = { "SMK-57813",
			"Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling011() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {
			Log.testCaseInfo(
					"tc001: Verify the Math-Assignments count matches with the mocked assignments count. <small><b><i>["
							+ browser + "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC(
					"SMK-12162 - Verify Prescriptive Scheduling option should present under the Reports top menu.");

			String json = DevToolsUtils.readJsonResponse("PSR_MathAssignments.json");
			Log.message(json);
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			Log.assertThat(prescriptiveSchedulingPage.isPSRsubNavigationSelected(),
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation");

			Log.message("Okay");

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> allOptions = reportFilterComponent
					.getAllOptionsFromAssignmentMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);
			Log.message(allOptions.toString());
			Log.assertThat((allOptions.size() - 1) == 2, "Assignments count matches", "Assignments count didn't match");

			RequestMockUtils.closeMock(tools);

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Student dropdown can select one student", groups = { "SMK-57813",
			"Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling012() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("tc004: Verify the Students dropdown matches with the one mocked students count");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC(
					"Verify Prescriptive Scheduling option should present under the Reports top menu.");

			String json = DevToolsUtils.readJsonResponse("PSR_GroupAndStudentDetails_OneStudent.json");
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			reportFilterComponent.expandExistingReportOptionDropdown();
			List<String> allSavedOptions = reportFilterComponent.getAvailableOptionsFromSavedReportOptionDropdown();

			Log.message("count : " + allSavedOptions.size());

			Log.assertThat((allSavedOptions.size() - 1) == 0, "Saved Options count matches.",
					"Saved Options count didn't match");

			RequestMockUtils.closeMock(tools);
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Student dropdown can select multiple students", groups = { "SMK-57813",
			"Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling013() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("tc005: Verify the Students dropdown matches with the four mocked students count");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC(
					"SMK-12162 - Verify Prescriptive Scheduling option should present under the Reports top menu.");

			String json = DevToolsUtils.readJsonResponse("PSR_GroupsAndStudent.json");
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			Log.assertThat(prescriptiveSchedulingPage.isPSRsubNavigationSelected(),
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation");

			Log.message("Okay");

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			reportFilterComponent.clickStudentRadioButton();
			reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);

			List<String> allOption = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);

			Log.message("The count of the Students is " + allOption.size());

			Log.assertThat((allOption.size()) - 1 == 5, "Student Counts matched", "Student Counts didn't match");

			RequestMockUtils.closeMock(tools);
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the students dropdown matches with the multiple students selection", groups = {
			"SMK-67093", "Teacher Dashboard", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling014() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("tc005: Verify the Students dropdown matches with the Five mocked students count");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC(
					"SMK-12162 - Verify Prescriptive Scheduling option should present under the Reports top menu.");

			String json = DevToolsUtils.readJsonResponse("PSR_GroupsAndStudent.json");
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			Log.assertThat(prescriptiveSchedulingPage.isPSRsubNavigationSelected(),
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation");

			Log.message("Okay");

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			reportFilterComponent.clickStudentRadioButton();
			reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);

			List<String> allOption = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);

			Log.message("The count of the Students is " + allOption.size());

			Log.assertThat((allOption.size() - 1) == 5, "Student Counts matched", "Student Counts didn't match");

			RequestMockUtils.closeMock(tools);

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Groups dropdown has no option when no groups created", groups = { "SMK-67093",
			"Teacher Dashboard", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling015() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("tc007: Verify the Groups dropdown matches with the Zero mocked Group count");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the Zero mocked Group count");

			String json = DevToolsUtils.readJsonResponse("PSR_ZeroGroup.json");
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			Log.assertThat(prescriptiveSchedulingPage.isPSRsubNavigationSelected(),
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
					"The Prescriptive Scheduling is displayed in Report MFE sub-navigation");

			Log.message("Okay");

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			reportFilterComponent.clickGroupRadioButton();
			reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);

			List<String> allOption = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);

			Log.message("The count of the Group is " + allOption.size());

			Log.assertThat((allOption.size() - 1) == 0, "Group count returned as expected",
					"Group count didn't match.");

			RequestMockUtils.closeMock(tools);

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Groups selection has minimum dropdown selection", groups = { "SMK-67093", "Smoke",
			"Teacher Dashboard", "Reports", "Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling016() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("tc008: Verify the Groups dropdown matches with the two mocked Group count. <small><b><i>["
					+ browser + "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the two mocked Group count");

			String json = DevToolsUtils.readJsonResponse("PSR_GroupAndStudentDetails_twoGroups.json");
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> options = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);
			int availableGroupOptions = options.size() - 1;
			Log.message("Group count : " + availableGroupOptions);
			Log.assertThat(availableGroupOptions == 2, "Group count returned as expected.",
					"Group count didn't match.");

			RequestMockUtils.closeMock(tools);

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Zero State Message is displaying when no assignments", groups = { "SMK-67093",
			"Prescriptive Scheduling Report", "mock" }, priority = 1)
	public void tcPrescriptiveScheduling017() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		try {

			Log.testCaseInfo("Mocked: Verify the Zero State Message is displaying when no assignments. <small><b><i>["
					+ browser + "]</b></i></small>");

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Zero State Message for the Zero mocked students data");

			String json = DevToolsUtils.readJsonResponse("PSR_GroupAndStudentDetails_ZeroStudents.json");
			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			// navigate to PSR Page
			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();
			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			String zeroStateMessage = "No students exist in the database. Once students are available, you will be able to use the Reports feature.";
			Log.assertThat(reportFilterComponent.verifyZeroStateMessage().contains(zeroStateMessage),
					"Zero State verified!", "Zero State not verified.");

			RequestMockUtils.closeMock(tools);
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
}