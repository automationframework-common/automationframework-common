package com.savvas.sm.reports.ui.tests.teacher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.reports.ui.tests.admin.spr.StudentPerfomanceReportTest;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

/**
 * This class is used to test sorting in all reports
 * 
 * @author saravanan.murugesan
 *
 */
public class TeacherSortingFuctionalityTest extends EnvProperties {
	private String smUrl;
	private String browser;
	private String username;
	private String password;
	private String teacherDetails;
	public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

	@BeforeClass(alwaysRun = true)
	public void initTest() throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	}

	@Test(description = "Verify Cumulative Performance Report sorting", groups = { "Smoke", "SMK-66289", "Teacher Dashboard",
			"Reports", "Cumulative Performance Report" }, priority = 1)
	public void tcCumulativePerformanceSorting001() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Cumulative Peformance Report Sorting <small><b><i>[" + browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			//Verify Student user-name sorting
			CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent
					.clickOnCumulativePerformancePage();
			cumulativePerformancePage.reportFilterComponent.selectOptionsFromSelectDropdown(
					ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
			cumulativePerformancePage.reportFilterComponent
					.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME);
			

			String rootWindow = driver.getWindowHandle();
			cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			List<WebElement> studentUserNameEle = driver
					.findElements(By.cssSelector(cumulativePerformancePage.studentNameCSS));
			List<String> studentUNameActual = new ArrayList<String>();
			List<String> studentUNameExpected = new ArrayList<String>();
			studentUserNameEle.forEach(element -> studentUNameActual.add(element.getText()));
			studentUserNameEle.forEach(element -> studentUNameExpected.add(element.getText()));
			studentUNameExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentUNameActual, studentUNameExpected, Constants.ASCENDING),
					"'Student Username' sorting is matching as expected for cumulative report", "'Student Username' sorting is not matching as expected for cumulative report");
			
			//Verify Student id sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			cumulativePerformancePage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID);
			cumulativePerformancePage.reportFilterComponent.handleStudentPopup();
			cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentUserIdEle = driver
					.findElements(By.cssSelector(cumulativePerformancePage.studentNameCSS));
			List<String> studentIDActual = new ArrayList<String>();
			List<String> studentIDExpected = new ArrayList<String>();
			studentUserIdEle.forEach(element -> studentIDActual.add(element.getText()));
			studentUserIdEle.forEach(element -> studentIDExpected.add(element.getText()));
			studentIDExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentIDActual, studentIDExpected, Constants.ASCENDING),
					"'Student ID' sorting is matching as expected for cumulative report", "'Student ID' sorting is not matching as expected for cumulative report");
			
			//Verify Student Name sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			cumulativePerformancePage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DEFAULT_DISPLAY);
			cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentFullNameEle = driver
					.findElements(By.cssSelector(cumulativePerformancePage.studentNameCSS));
			List<String> studentFullNameActual = new ArrayList<String>();
			List<String> studentFullNameExpected = new ArrayList<String>();
			studentFullNameEle.forEach(element -> studentFullNameActual.add(element.getText()));
			studentFullNameEle.forEach(element -> studentFullNameExpected.add(element.getText()));
			List<String> lastNameOnlyActual = getLastNameOfStudentName(studentUNameActual);
			List<String> lastNameOnlyExpected = getLastNameOfStudentName(studentUNameExpected);
			lastNameOnlyActual.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(lastNameOnlyActual, lastNameOnlyExpected, Constants.ASCENDING),
					"'Student Name' sorting is matching as expected in cumulative report", "'Student Name' sorting is not matching as expected in cumulative report");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}
	
	
	@Test(description = "Verify Last Session Report sorting", groups = { "Smoke", "SMK-66289", "Teacher Dashboard",
			"Reports", "Last Session Report" }, priority = 2)
	public void tcLastSessionReportSorting002() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Last Session Report Sorting <small><b><i>[" + browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent
					.clickOnLastSessionsPage();
			lastSessionPage.reportFilterComponent.selectOptionsFromSelectDropdown(
					ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
			lastSessionPage.reportFilterComponent
					.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME);
			
			String rootWindow = driver.getWindowHandle();
			lastSessionPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

		
			List<WebElement> studentUserNameEle = driver
					.findElements(By.cssSelector(lastSessionPage.studentNameCSS));
			List<String> studentUNameActual = new ArrayList<String>();
			List<String> studentUNameExpected = new ArrayList<String>();
			studentUserNameEle.forEach(element -> studentUNameActual.add(element.getText()));
			studentUserNameEle.forEach(element -> studentUNameExpected.add(element.getText()));
			studentUNameExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentUNameActual, studentUNameExpected, Constants.ASCENDING),
					"'Student Username' sorting is matching as expected for cumulative report", "'Student Username' sorting is not matching as expected for cumulative report");
			
			//Verify Student id sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			lastSessionPage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID);
			lastSessionPage.reportFilterComponent.handleStudentPopup();
			lastSessionPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentUserIdEle = driver
					.findElements(By.cssSelector(lastSessionPage.studentNameCSS));
			List<String> studentIDActual = new ArrayList<String>();
			List<String> studentIDExpected = new ArrayList<String>();
			studentUserIdEle.forEach(element -> studentIDActual.add(element.getText()));
			studentUserIdEle.forEach(element -> studentIDExpected.add(element.getText()));
			studentIDExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentIDActual, studentIDExpected, Constants.ASCENDING),
					"'Student ID' sorting is matching as expected for cumulative report", "'Student ID' sorting is not matching as expected for cumulative report");
			
			//Verify Student Name sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			lastSessionPage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DEFAULT_DISPLAY);
			lastSessionPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentFullNameEle = driver
					.findElements(By.cssSelector(lastSessionPage.studentNameCSS));
			List<String> studentFullNameActual = new ArrayList<String>();
			List<String> studentFullNameExpected = new ArrayList<String>();
			studentFullNameEle.forEach(element -> studentFullNameActual.add(element.getText()));
			studentFullNameEle.forEach(element -> studentFullNameExpected.add(element.getText()));
			List<String> lastNameOnlyActual = getLastNameOfStudentName(studentUNameActual);
			List<String> lastNameOnlyExpected = getLastNameOfStudentName(studentUNameExpected);
			lastNameOnlyActual.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(lastNameOnlyActual, lastNameOnlyExpected, Constants.ASCENDING),
					"'Student Name' sorting is matching as expected in last session report", "'Student Name' sorting is not matching as expected in last session report");


		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}
	
	@Test(description = "Verify Prescriptive Scheduling Performance Report sorting", groups = { "Smoke", "SMK-66289", "Teacher Dashboard",
			"Reports", "Prescriptive Scheduling Report" }, priority = 3)
	public void tcPerscriptiveSchedulingReportSorting003() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Prescriptive Scheduling Report Sorting <small><b><i>[" + browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent
					.clickOnPrescriptiveSchedulingPage();
			prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSelectDropdown(
					ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
			prescriptiveSchedulingPage.reportFilterComponent
					.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME);
			prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
			String rootWindow = driver.getWindowHandle();
			prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

		
			List<WebElement> studentUserNameEle = driver
					.findElements(By.cssSelector(prescriptiveSchedulingPage.studentNameCSS));
			List<String> studentUNameActual = new ArrayList<String>();
			List<String> studentUNameExpected = new ArrayList<String>();
			studentUserNameEle.forEach(element -> studentUNameActual.add(element.getText()));
			studentUserNameEle.forEach(element -> studentUNameExpected.add(element.getText()));
			studentUNameExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentUNameActual, studentUNameExpected, Constants.ASCENDING),
					"'Student Username' sorting is matching as expected for cumulative report", "'Student Username' sorting is not matching as expected for cumulative report");
			
			//Verify Student id sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			prescriptiveSchedulingPage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID);
			prescriptiveSchedulingPage.reportFilterComponent.handleStudentPopup();
			prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentUserIdEle = driver
					.findElements(By.cssSelector(prescriptiveSchedulingPage.studentNameCSS));
			List<String> studentIDActual = new ArrayList<String>();
			List<String> studentIDExpected = new ArrayList<String>();
			studentUserIdEle.forEach(element -> studentIDActual.add(element.getText()));
			studentUserIdEle.forEach(element -> studentIDExpected.add(element.getText()));
			studentIDExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentIDActual, studentIDExpected, Constants.ASCENDING),
					"'Student ID' sorting is matching as expected for cumulative report", "'Student ID' sorting is not matching as expected for cumulative report");
			
			//Verify Student Name sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			prescriptiveSchedulingPage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DEFAULT_DISPLAY);
			prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentFullNameEle = driver
					.findElements(By.cssSelector(prescriptiveSchedulingPage.studentNameCSS));
			List<String> studentFullNameActual = new ArrayList<String>();
			List<String> studentFullNameExpected = new ArrayList<String>();
			studentFullNameEle.forEach(element -> studentFullNameActual.add(element.getText()));
			studentFullNameEle.forEach(element -> studentFullNameExpected.add(element.getText()));
			List<String> lastNameOnlyActual = getLastNameOfStudentName(studentUNameActual);
			List<String> lastNameOnlyExpected = getLastNameOfStudentName(studentUNameExpected);
			lastNameOnlyActual.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(lastNameOnlyActual, lastNameOnlyExpected, Constants.ASCENDING),
					"'Student Name' sorting is matching as expected for prescriptive scheduling report", "'Student Name' sorting is not matching as expected for prescriptive scheduling report");


		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}
	
	
	@Test(description = "Verify Student Performance Report sorting", groups = { "Smoke", "SMK-66289", "Teacher Dashboard",
			"Reports", "Student Performance Report" }, priority = 4)
	public void tcStudentPerformanceReportSorting004() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Student Performance Report Sorting <small><b><i>[" + browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent
					.clickOnStudentPerformancePage();
			studentPerformancePage.reportFilterComponent.selectOptionsFromSelectDropdown(
					ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
			studentPerformancePage.reportFilterComponent
					.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME);
			studentPerformancePage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			List<String> assignmentNamesTitle = studentPerformancePage.getAssignmentName();
			Log.assertThat(SMUtils.sortAndCompareList(assignmentNamesTitle, assignmentNamesTitle, Constants.ASCENDING),
					"'Assignemnt Title' sorting is matching as expected in Student Performance report", "'Student Name' sorting is not matching as expected in Student Performance report");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}
	
	
	@Test(description = "Verify Areas For Growth Report sorting", groups = { "Smoke", "SMK-66289", "Teacher Dashboard",
			"Reports", "Areas For Growth Report" }, priority = 1)
	public void tcAreasForGrowthSorting005() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Areas For Growth Report Sorting <small><b><i>[" + browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areasForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);

			//Verify Student user-name sorting
			areasForGrowthPage.reportFilterComponent
					.clickOnAreaForGrowthPage();
			areasForGrowthPage.reportFilterComponent.selectOptionsFromSelectDropdown(
					ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
			areasForGrowthPage.reportFilterComponent
					.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME);

			String rootWindow = driver.getWindowHandle();
			areasForGrowthPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			
			List<WebElement> studentUserNameEle = driver
					.findElements(By.cssSelector(areasForGrowthPage.studentNameCSS));
			List<String> studentUNameActual = new ArrayList<String>();
			List<String> studentUNameExpected = new ArrayList<String>();
			studentUserNameEle.forEach(element -> studentUNameActual.add(element.getText()));
			studentUserNameEle.forEach(element -> studentUNameExpected.add(element.getText()));
			studentUNameExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentUNameActual, studentUNameExpected, Constants.ASCENDING),
					"'Student Username' sorting is matching as expected for Areas For Growth report", "'Student Username' sorting is not matching as expected for Areas For Growth report");
			
			
			//Verify Student id sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			areasForGrowthPage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID);
			areasForGrowthPage.reportFilterComponent.handleStudentPopup();
			areasForGrowthPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentUserIdEle = driver
					.findElements(By.cssSelector(areasForGrowthPage.studentNameCSS));
			List<String> studentIDActual = new ArrayList<String>();
			List<String> studentIDExpected = new ArrayList<String>();
			studentUserIdEle.forEach(element -> studentIDActual.add(element.getText()));
			studentUserIdEle.forEach(element -> studentIDExpected.add(element.getText()));
			studentIDExpected.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(studentIDActual, studentIDExpected, Constants.ASCENDING),
					"'Student ID' sorting is matching as expected for Areas For Growth report", "'Student ID' sorting is not matching as expected for Areas For Growth report");
			
			//Verify Student Name sorting
			SMUtils.closeCurrentWindowAndSwitchtoWindow(driver, rootWindow);
			areasForGrowthPage.reportFilterComponent
			.selectOptionsFromSelectDropdown(ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DEFAULT_DISPLAY);
			areasForGrowthPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			
			List<WebElement> studentFullNameEle = driver
					.findElements(By.cssSelector(areasForGrowthPage.studentNameCSS));
			List<String> studentFullNameActual = new ArrayList<String>();
			List<String> studentFullNameExpected = new ArrayList<String>();
			studentFullNameEle.forEach(element -> studentFullNameActual.add(element.getText()));
			studentFullNameEle.forEach(element -> studentFullNameExpected.add(element.getText()));
			List<String> lastNameOnlyActual = getLastNameOfStudentName(studentUNameActual);
			List<String> lastNameOnlyExpected = getLastNameOfStudentName(studentUNameExpected);
			lastNameOnlyActual.forEach(System.out::println);
			Log.assertThat(SMUtils.sortAndCompareList(lastNameOnlyActual, lastNameOnlyExpected, Constants.ASCENDING),
					"'Student Name' sorting is matching as expected in Areas For Growth report", "'Student Name' sorting is not matching as expected in Areas For Growth report");

			
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
	

	private List<String> getLastNameOfStudentName(List<String> studentName) throws Exception{
		List<String> studentLastName = new ArrayList<String>();
		for(String sName : studentName){
			String lastName = Stream.of(sName.split(" ")).reduce((first,last)->last).get();
			studentLastName.add(lastName);
		}
		
		return studentLastName;
	}
}