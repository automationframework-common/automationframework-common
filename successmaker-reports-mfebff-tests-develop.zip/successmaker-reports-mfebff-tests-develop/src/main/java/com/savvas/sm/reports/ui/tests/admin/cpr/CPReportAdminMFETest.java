package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.bff.admin.tests.CPRReportAdminGraphQLTest;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPAReport;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPReport;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

import io.restassured.response.Response;

public class CPReportAdminMFETest extends EnvProperties {

    private String browser;
    CourseAPI coursesMethod = new CourseAPI();
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String firstTeacherOrgID;
    String orgName;
    List<String> courses;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        RBSUtils rbsUtils = new RBSUtils();

        // Teacher UserNames
        firstTeacherUserName = ReportDataCollection.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportDataCollection.teacherDetails.keySet().toArray()[1].toString();

        //Selected School Name
        firstTeacherOrgID = ReportDataCollection.orgId;
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        //Teacher User ID's
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );
        
        // District admin details
        distAdminUserName = ReportDataCollection.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, "userId" );

        //Filter By Values - OrgId
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        // Sub district admin details
        subDistAdminUserName = ReportDataCollection.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportDataCollection.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        //School admin details
        schoolAdminUserName = ReportDataCollection.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportDataCollection.schoolAdminDetails, "primaryOrgId" );

    }

    // Check selecting "Select All" option and Run Report in Demographics

    @Test ( description = "Verify the CP Report generation with 'Select All' option in Student Demographic", groups = { "SMK-66772", "AdminDashboard", "Reports", "Cumulative Performance " }, priority = 1 )
    public void tcCumulativePerformance001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance001: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
           

            cumulativePerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            cumulativePerformancePage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level" );
            cumulativePerformancePage.reportFilterComponent.expandStudentDemographics();
            List<String> availableOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            List<String> selectedOptions = Arrays.asList( availableOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, selectedOptions );
            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all disablity options",
                    "Selected disablity options are not checked" );
            Log.testCaseResult();

            // Get English Proficiency List and Select multiple options from drop-down
            List<String> availableEnglishProficiencyOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.message( availableEnglishProficiencyOptionList.toString() );
            List<String> selectedEnglishProficiencyOptions = Arrays.asList( availableEnglishProficiencyOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, selectedEnglishProficiencyOptions );

            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ),
                    "Selected all english language proficiency options", "Selected english language proficiency options are not checked" );
            Log.testCaseResult();

            // Get Ethnicity List and Select multiple options from drop-down
            List<String> EthnicityOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            List<String> selectedEthnicityOptions = Arrays.asList( EthnicityOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, selectedEthnicityOptions );

            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all ethnicity options",
                    "Selected ethnicity options are not checked" );
            Log.testCaseResult();

            // Get Migrant Status List and Select multiple options from drop-down
            List<String> MigrantStatusOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            List<String> selectedMigrantStatusOptions = Arrays.asList( MigrantStatusOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, selectedMigrantStatusOptions );

            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all migrant status options",
                    "Selected migrant status options are not checked" );
            Log.testCaseResult();

            // Get Race List and Select multiple options from drop-down
            List<String> raceOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );
            List<String> selectedRaceOptions = Arrays.asList( raceOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, selectedRaceOptions );

            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.RACE ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all race options",
                    "Selected race options are not checked" );
            Log.testCaseResult();

            // Get Special Services List and Select multiple options from drop-down
            List<String> specialServicesOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            List<String> selectedSpecialServicesOptions = Arrays.asList( specialServicesOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, selectedSpecialServicesOptions );

            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all special services options",
                    "Selected special services are not displaying" );
            Log.testCaseResult();

            // Get Socioeconomic Status List and Select multiple options from drop-down
            List<String> socioeconomicStatusOptionList = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            List<String> selectedSocioeconomicStatusOptions = Arrays.asList( socioeconomicStatusOptionList.get( 0 ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, selectedSocioeconomicStatusOptions );

            Log.softAssertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all socioeconomic status options",
                    "Selected socioeconomic status are not displaying" );
            Log.testCaseResult();
            CPReportViewerPage reportViewerPage = cumulativePerformancePage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify 'the CPR  Report generation with mandatory field'." );
            SMUtils.logDescriptionTC( "Verify the report name is display in the header in CPR ." );
            Log.softAssertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPR_HEADER ), "Cumulative Performance  is displayed in report viewer page header",
                    "Cumulative Performance  is not displayed in report viewer page header" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the CP Report generation with 'Select All' option in Student Demographic", groups = { "SMK-66772", "AdminDashboard", "Reports", "Cumulative Performance " }, priority = 1 )
    public void tcCumulativePerformance002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance002: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cumulativePerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            cumulativePerformancePage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level" );
            CPReportViewerPage reportViewerPage = cumulativePerformancePage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify 'the CPR  Report generation with mandatory field'." );
            SMUtils.logDescriptionTC( "Verify the report name is display in the header in CPR ." );
            Log.softAssertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPR_HEADER ), "Cumulative Performance  is displayed in report viewer page header",
                    "Cumulative Performance  is not displayed in report viewer page header" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Course name, Report run, school, teacher, grade and group are present under the header in CPR ." );
            Log.softAssertThat( reportViewerPage.getSubjectLabel().equals( Constants.MATH ), "Assignment name is present", "Assignment name is not present" );
            Log.softAssertThat( reportViewerPage.getDateLabel().equals( reportViewerPage.getDateAndTime() ), "Date is present", "Date is not present" );
            Log.softAssertThat( reportViewerPage.getSelectedOptionLabel().contains( ReportsUIConstants.SELECTED_OPTION_HEADER ), "Selected Options header is present", "Selected Options header is not present" );
            Log.softAssertThat( reportViewerPage.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the available columns in CPR ." );
            Log.softAssertThat( reportViewerPage.getColumnHeaders().equals( CPReport.TABLE_HEADER ), "Table column names are displayed as expected", "Table column names are not displayed as expected" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the CP Report generation with API response Math", groups = { "SMK-66772", "AdminDashboard", "Reports", "Cumulative Performance " }, priority = 1 )
    public void tcCumulativePerformance003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance003: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
           

            cumulativePerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            cumulativePerformancePage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.testCaseResult();
            CPReportViewerPage reportViewerPage = cumulativePerformancePage.clickRunReportButton();

            Log.softAssertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPR_HEADER ), "Cumulative Performance  is displayed in report viewer page header",
                    "Cumulative Performance  is not displayed in report viewer page header" );
            SMUtils.logDescriptionTC( "Verify the available columns in CPR ." );
            Log.softAssertThat( reportViewerPage.getColumnHeaders().equals( CPReport.TABLE_HEADER ), "Table column names are displayed as expected", "Table column names are not displayed as expected" );
            Log.testCaseResult();
            HashMap<String, HashMap<String, String>> responseCPRUI=cumulativePerformancePage.getCPReportAllDataFromUI( driver );
            HashMap<String, HashMap<String, String>> responseCPR=getCompleteDataFromBFF(Constants.MATH);
            Log.message( "Data from UI :"+responseCPRUI);
            boolean validation = responseCPR.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), responseCPRUI.get( entry.getKey() ) ) );
           Log.softAssertThat( validation, "MFE BFF data verification Successful", "MFE BFF data verification Failed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify the CP Report generation with API response for Reading", groups = { "SMK-66772", "AdminDashboard", "Reports", "Cumulative Performance " }, priority = 1 )
    public void tcCumulativePerformance004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance004: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            cumulativePerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            cumulativePerformancePage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.READING );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.testCaseResult();
            CPReportViewerPage reportViewerPage = cumulativePerformancePage.clickRunReportButton();

            Log.softAssertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPR_HEADER ), "Cumulative Performance  is displayed in report viewer page header",
                    "Cumulative Performance  is not displayed in report viewer page header" );
            
            HashMap<String, HashMap<String, String>> responseCPRUI=cumulativePerformancePage.getCPReportAllDataFromUI( driver );
            HashMap<String, HashMap<String, String>> responseCPR=getCompleteDataFromBFF(Constants.READING);
            Log.message( "Data from UI :"+responseCPRUI);
            boolean validation = responseCPR.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), responseCPRUI.get( entry.getKey() ) ) );
            Log.softAssertThat( validation, "MFE BFF data verification Successful", "MFE BFF data verification Failed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public HashMap<String, HashMap<String, String>> getCompleteDataFromBFF(String subject) throws Exception {
        HashMap<String, String> filterByValues = new HashMap<>();
        CPRReportAdminGraphQLTest cPRReportAdminGraphQLTest = new CPRReportAdminGraphQLTest();
        response = cPRReportAdminGraphQLTest.getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, subject, filterByValues );
        HashMap<String, HashMap<String, String>> responseFromCPR=cPRReportAdminGraphQLTest.getDataFromResponseForVerification( response.getBody().asString() );
        return responseFromCPR;
    }
}