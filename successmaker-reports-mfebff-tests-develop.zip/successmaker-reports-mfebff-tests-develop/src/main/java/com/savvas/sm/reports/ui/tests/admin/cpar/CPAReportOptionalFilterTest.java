package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPAReport;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class CPAReportOptionalFilterTest extends EnvProperties {

    private String smUrl;
    private String browser;

    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String organizationName;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host 
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        username = String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest );
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    }

    @Test ( description = "tcCPAROptionalFilter001 Verify the Cumulative Performance Aggregate Report page is loaded with mandatory fields", groups = { "SMK-57905", "CPAR", "CPAROptionalFilterTest" }, priority = 1 )
    public void tcCPAROptionalFilter001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPAROptionalFilter001 Verify the Cumulative Performance Aggregate Report page is loaded with mandatory fields" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CPAReportPage.reportFilterComponent.expandOptionalFilter();
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );
            CPAReportPage.reportFilterComponent.clickRunReportButton();
            
            ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);
            
            SMUtils.logDescriptionTC( "Verify 'the CPR aggregate Report generation with mandatory field'." );
            SMUtils.logDescriptionTC( "Verify the report name is display in the header in CPR aggregate." );
            Log.assertThat( outputPage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Course name, Report run, school, teacher, grade and group are present under the header in CPR aggregate." );
            Log.assertThat( outputPage.getSubjectLabel().equals( Constants.MATH ), "Assignment name is present", "Assignment name is not present" );
            Log.assertThat( outputPage.getDateLabel().equals( outputPage.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( outputPage.getDistrictName().equals( SMUtils.getKeyValueFromResponse( new RBSUtils().getOrg( configProperty.getProperty( "district_ID" ) ), "displayName" ) ), "District name is displayed",
                    "District name is not displayed" );
            Log.assertThat( outputPage.getSelectedOptionLabel().contains( ReportsUIConstants.SELECTED_OPTION_HEADER ), "Selected Options header is present", "Selected Options header is not present" );
            Log.assertThat( outputPage.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.assertThat( outputPage.verifyLegend(), "Legend values are displayed", "Legend values are not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the available columns in CPR aggregate." );
            Log.assertThat( outputPage.getColumnHeaders().equals( CPAReport.TABLE_HEADER ), "Table column names are displayed as expected", "Table column names are not displayed as expected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the page number in CPR aggregate." );
            Log.assertThat( outputPage.verifyPagination(), "Page number is displayed in CPA report viewer page ", "Page number is not displayed in CPA report viewer page " );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcCPAROptionalFilter002 Verify all column values are sorted in ascending order in Cumulative Performance Aggregate Report page.", groups = { "SMK-57905", "CPAR", "CPAROptionalFilterTest" }, priority = 1 )
    public void tcCPAROptionalFilter002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPAROptionalFilter002 Verify all column values are sorted in ascending order in Cumulative Performance Aggregate Report page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CPAReportPage.reportFilterComponent.expandOptionalFilter();

            IntStream.range( 0, ReportsUIConstants.SORT_CPAR.size() ).forEach( itr -> {
                String columnSorted = ReportsUIConstants.SORT_CPAR.get( itr );
                Log.message( "Sorting " + columnSorted + " ..." );
                CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, columnSorted );

                //To click the run report button 
                CPAReportPage.reportFilterComponent.clickRunReportButton();
                
                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                
                Log.assertThat( outputPage.sortAndCompareColumnvalues( columnSorted ), columnSorted + " column is sorted in ascending order", columnSorted + " column is not sorted in ascending order" );

                // Navigating to report filter page
                driver.close();
                driver.switchTo().window( new ArrayList<>( driver.getWindowHandles() ).get( 1 ) );
            } );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcCPAROptionalFilter003 Verify the Cumulative Performance Aggregate Report page is loaded with Additional Grouping", groups = { "SMK-57905", "CPAR", "CPAROptionalFilterTest" }, priority = 1 )
    public void tcCPAROptionalFilter003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPAROptionalFilter003 Verify the Cumulative Performance Aggregate Report page is loaded with Additional Grouping" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CPAReportPage.reportFilterComponent.expandOptionalFilter();
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            //To click the run report button 
            CPAReportPage.reportFilterComponent.clickRunReportButton();
            
            ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "Verify 'the CPR aggregate Report generation with 'Grade' option in Additional grouping'." );
            Log.assertThat( outputPage.getGradeValues().containsAll( ReportsUIConstants.SUB_HEADER_GRADE ), "Report is displayed on grade wise when selecting Additional Grouping as Grade",
                    "Report is not displayed on grade wise when selecting Additional Grouping as Grade" );
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
