package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.admin.ui.pages.LastSessionReportPage;
import com.savvas.sm.reports.admin.ui.pages.PrescriptiveSchedulingReport;
import com.savvas.sm.reports.admin.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.admin.ui.pages.StudentEnrollmentUsageReportPage;
import com.savvas.sm.reports.admin.ui.pages.StudentPerformanceReportPage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CPAndCPAReportMultiSelectOrgDropdownTest extends EnvProperties {

    private String adminUsername;
    private String password;
    private String smUrl;
    private String browser;
    private String flexSchool;
    private String mathSchool;

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        adminUsername = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify CPR report is showing multi org selection dropdown in report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest001() throws Exception {

        Log.testCaseInfo( "Verify CPR report is showing multi org selection dropdown in report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify CPR report is showing multi org selection dropdown in report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            Log.assertThat( cprPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation Multiselect dropdwon is displaying properly",
                    "Organiation Multiselect dropdown is not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc-002: Verify admin can select all the orgs from multi org selection dropdown in CPR report input screen" );
            List<String> availableOptionsFromOrganzationDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            List<String> selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( availableOptionsFromOrganzationDropdown ), "Admin able to select the select all option in organization dropdown",
                    "Admin unable to select the select all option in organization dropdown" );

            SMUtils.logDescriptionTC( "tc-003: Verify admin can select single org from multi org selection dropdown in CPR report input screen" );

            //To deselect all
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.contains( flexSchool ), "Admin able to select the single option in organization dropdown", "Admin unable to select the single option in organization dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc-004: Verify admin can select multiple orgs from multi org selection dropdown in CPR report input screen" );
            //To deselect all
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool, mathSchool ) ), "Admin able to select the multiple option in organization dropdown",
                    "Admin unable to select the multiple option in organization dropdown. Actual -" + selectedOptionsFromOrganizationDropdown );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can save report option with multiple orgs in CPR report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest002() throws Exception {

        Log.testCaseInfo( "Verify admin can save report option with multiple orgs in CPR report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-005: Verify admin can save report option with multiple orgs in CPR report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the filters
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To save the filter
            SaveReportFilterPopup saveReportFilterPopup = cprPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "saved report " + System.nanoTime();
            saveReportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportFilterPopup.clickSaveButton();

            //To reset the filters
            cprPage.reportFilterComponent.clickResetButton();

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            List<String> selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool, mathSchool ) ), "Admin able to save the filter with multiple selected option in organization dropdown",
                    "Admin unable to save the filter with multiple selected option in organization dropdown. Actual -" + selectedOptionsFromOrganizationDropdown );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can save report option with single org in CPR report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest003() throws Exception {

        Log.testCaseInfo( "Verify admin can save report option with single org in CPR report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-006: Verify admin can save report option with single org in CPR report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the filters
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To save the filter
            SaveReportFilterPopup saveReportFilterPopup = cprPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "saved report " + System.nanoTime();
            saveReportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportFilterPopup.clickSaveButton();

            //To reset the filters
            cprPage.reportFilterComponent.clickResetButton();

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            List<String> selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool ) ), "Admin able to save the filter with single selected option in organization dropdown",
                    "Admin unable to save the filter with single selected option in organization dropdown. Actual -" + selectedOptionsFromOrganizationDropdown );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can save report option with all orgs in CPR report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest004() throws Exception {

        Log.testCaseInfo( "Verify admin can save report option with all orgs in CPR report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "tc-007: Verify admin can save report option with all orgs in CPR report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            List<String> availableOptionsFromOrganzationDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To select the filters
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To save the filter
            SaveReportFilterPopup saveReportFilterPopup = cprPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "saved report " + System.nanoTime();
            saveReportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportFilterPopup.clickSaveButton();

            //To reset the filters
            cprPage.reportFilterComponent.clickResetButton();

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            List<String> selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( availableOptionsFromOrganzationDropdown ), "Admin able to save the filter with all option in organization dropdown",
                    "Admin unable to save the filter with all option in organization dropdown" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify CPA report is showing multi org selection dropdown in report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest005() throws Exception {

        Log.testCaseInfo( "Verify CPA report is showing multi org selection dropdown in report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-008: Verify CPA report is showing multi org selection dropdown in report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpaPage = cprPage.navigateToCPAReport();
            Log.assertThat( cpaPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation Multiselect dropdwon is displaying properly",
                    "Organiation Multiselect dropdown is not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc-009: Verify admin can select all the orgs from multi org selection dropdown in CPA report input screen" );
            List<String> availableOptionsFromOrganzationDropdown = cpaPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            List<String> selectedOptionsFromOrganizationDropdown = cpaPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( availableOptionsFromOrganzationDropdown ), "Admin able to select the select all option in organization dropdown",
                    "Admin unable to select the select all option in organization dropdown" );

            SMUtils.logDescriptionTC( "tc-010: Verify admin can select single org from multi org selection dropdown in CPA report input screen" );

            //To deselect all
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            selectedOptionsFromOrganizationDropdown = cpaPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool ) ), "Admin able to select the single option in organization dropdown", "Admin unable to select the single option in organization dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc-011: Verify admin can select multiple orgs from multi org selection dropdown in CPA report input screen" );
            //To deselect all
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown = cpaPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool, mathSchool ) ), "Admin able to select the multiple option in organization dropdown",
                    "Admin unable to select the multiple option in organization dropdown. Actual -" + selectedOptionsFromOrganizationDropdown );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can save report option with multiple orgs in CPA report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest006() throws Exception {

        Log.testCaseInfo( "Verify admin can save report option with multiple orgs in CPAR report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-012: Verify admin can save report option with multiple orgs in CPAR report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpapage = cprPage.navigateToCPAReport();

            //To select the filters
            cpapage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cpapage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cpapage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To save the filter
            SaveReportFilterPopup saveReportFilterPopup = cpapage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "saved report " + System.nanoTime();
            saveReportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportFilterPopup.clickSaveButton();

            //To reset the filters
            cpapage.reportFilterComponent.clickResetButton();

            cpapage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            List<String> selectedOptionsFromOrganizationDropdown = cpapage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool, mathSchool ) ), "Admin able to save the filter with multiple selected option in organization dropdown",
                    "Admin unable to save the filter with multiple selected option in organization dropdown. Actual -" + selectedOptionsFromOrganizationDropdown );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can save report option with single org in CPA report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest007() throws Exception {

        Log.testCaseInfo( "Verify admin can save report option with single org in CPA report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-013: Verify admin can save report option with single org in CPA report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpaPage = cprPage.navigateToCPAReport();

            //To select the filters
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To save the filter
            SaveReportFilterPopup saveReportFilterPopup = cpaPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "saved report " + System.nanoTime();
            saveReportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportFilterPopup.clickSaveButton();

            //To reset the filters
            cpaPage.reportFilterComponent.clickResetButton();

            cpaPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            List<String> selectedOptionsFromOrganizationDropdown = cpaPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( Arrays.asList( flexSchool ) ), "Admin able to save the filter with single selected option in organization dropdown",
                    "Admin unable to save the filter with single selected option in organization dropdown. Actual -" + selectedOptionsFromOrganizationDropdown );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can save report option with all orgs in CPA report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest008() throws Exception {

        Log.testCaseInfo( "Verify admin can save report option with all orgs in CPA report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "tc-014: Verify admin can save report option with all orgs in CPA report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpaPage = cprPage.navigateToCPAReport();
            List<String> availableOptionsFromOrganzationDropdown = cpaPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To select the filters
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cpaPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cpaPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To save the filter
            SaveReportFilterPopup saveReportFilterPopup = cpaPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "saved report " + System.nanoTime();
            saveReportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportFilterPopup.clickSaveButton();

            //To reset the filters
            cpaPage.reportFilterComponent.clickResetButton();

            cpaPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            List<String> selectedOptionsFromOrganizationDropdown = cpaPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( availableOptionsFromOrganzationDropdown ), "Admin able to save the filter with all option in organization dropdown",
                    "Admin unable to save the filter with all option in organization dropdown" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify admin can search org with different keywords" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest009() throws Exception {

        Log.testCaseInfo( "Verify admin can search org with different keywords" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-015: Verify admin can search org with different keywords" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            List<String> availableOptionsFromOrganzationDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String keyword = availableOptionsFromOrganzationDropdown.get( 1 ).length() > 3 ? availableOptionsFromOrganzationDropdown.get( 1 ).substring( 0, 3 ) : availableOptionsFromOrganzationDropdown.get( 1 );
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, keyword );
            List<String> filteredOptionFromOrganzationDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            filteredOptionFromOrganzationDropdown.remove( "Select All Visible" );
            Log.assertThat( filteredOptionFromOrganzationDropdown.stream().allMatch( org -> org.toLowerCase().contains( keyword.toLowerCase() ) ), "Search functionality is working properly for organization dropdown",
                    "Search functionality is not working properly for organization dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc-016: Verify filtered organization alone selected when admin search few orgs using keyword and \"Select all visible\" option is selected" );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL );
            List<String> selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.containsAll( filteredOptionFromOrganzationDropdown ), "Filtered organizations alone selected when admin search few orgs using keyword and \"Select all visible\" option is selected",
                    "Filtered organizations are not selected when admin search few orgs using keyword and \"Select all visible\" option is selected" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //Rework id  - SMK-70063
    @Test ( enabled = false, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify filtered organization alone deselected when admin search few orgs using keyword and \"Select all visible\" option is deselected" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest010() throws Exception {

        Log.testCaseInfo( "Verify filtered organization alone deselected when admin search few orgs using keyword and \"Select all visible\" option is deselected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-017: Verify filtered organization alone deselected when admin search few orgs using keyword and \"Select all visible\" option is deselected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            List<String> availableOptionsFromOrganzationDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            String keyword = availableOptionsFromOrganzationDropdown.get( 1 ).length() > 3 ? availableOptionsFromOrganzationDropdown.get( 1 ).substring( 0, 3 ) : availableOptionsFromOrganzationDropdown.get( 1 );
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, keyword );
            List<String> filteredOptionFromOrganzationDropdown = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            filteredOptionFromOrganzationDropdown.remove( "Select All Visible" );
            Log.assertThat( filteredOptionFromOrganzationDropdown.stream().allMatch( org -> org.toLowerCase().contains( keyword.toLowerCase() ) ), "Search functionality is working properly for organization dropdown",
                    "Search functionality is not working properly for organization dropdown" );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL );
            List<String> selectedOptionsFromOrganizationDropdown = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            selectedOptionsFromOrganizationDropdown.remove( ReportsUIConstants.SELECT_ALL );
            Log.assertThat( selectedOptionsFromOrganizationDropdown.stream().allMatch( selectedOrg -> !filteredOptionFromOrganzationDropdown.contains( selectedOrg ) ),
                    "Filtered organizations alone deselected when admin search few orgs using keyword and \"Select all visible\" option is deselected",
                    "Filtered organizations are not deselected when admin search few orgs using keyword and \"Select all visible\" option is deselected" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69551", "Organization- muliselect", "smoke_test_case" }, description = "Verify AFG, LSR, SPR, PSR, PSA and SEU reports are not showing multi org selection dropdown in report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest011() throws Exception {

        Log.testCaseInfo( "Verify AFG, LSR, SPR, PSR, PSA and SEU reports are not showing multi org selection dropdown in report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-018: Verify AFG, LSR, SPR, PSR, PSA and SEU reports are not showing multi org selection dropdown in report input screen" );

            Log.assertThat( !afgPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation multiselect dropdwon is not displaying for AFG Report",
                    "Organiation multiselect dropdwon is displaying for AFG Report" );

            LastSessionReportPage lsrPage = afgPage.reportFilterComponent.clickOnLastSessionsPage();
            Log.assertThat( !lsrPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation multiselect dropdwon is not displaying for LSR Report",
                    "Organiation multiselect dropdwon is displaying for LSR Report" );

            PrescriptiveSchedulingReport psrPage = lsrPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            Log.assertThat( !psrPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation multiselect dropdwon is not displaying for PSR Report",
                    "Organiation multiselect dropdwon is displaying for PSR Report" );

            StudentPerformanceReportPage sprPage = psrPage.reportFilterComponent.clickOnStudentPerformancePage();
            Log.assertThat( !sprPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation multiselect dropdwon is not displaying for SPR Report",
                    "Organiation multiselect dropdwon is displaying for SPR Report" );

            StudentEnrollmentUsageReportPage seuPage = sprPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();
            Log.assertThat( !seuPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "Organiation multiselect dropdwon is not displaying for SEU Report",
                    "Organiation multiselect dropdwon is displaying for SEU Report" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
