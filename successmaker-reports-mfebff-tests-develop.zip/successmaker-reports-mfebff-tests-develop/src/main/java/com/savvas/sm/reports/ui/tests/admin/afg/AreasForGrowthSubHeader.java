package com.savvas.sm.reports.ui.tests.admin.afg;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AreasForGrowthSubHeader extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private String org;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify areas for growth header is displayed in the areas for growth report viewer.", groups = { "SMK-63441", "AreasForGrowth", "AreasForGrowth" }, priority = 1 )
    public void tcAreasForGrowthSubheaderOption001() throws Exception {
        // final WebDriver driver = WebDriverFactory.get( browser );
        WebDriverManager.chromedriver().setup();
        final WebDriver driver = new ChromeDriver();

        Log.testCaseInfo( "Verify areas for growth header is displayed in the areas for growth report viewer.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            AFGReportViewerPage afgReportViewerPage = dashBoardPage.clickRunReportButton();
            Log.assertThat( dashBoardPage.getReportPageTitle().equals( ReportsUIConstants.AFG_HEADER ), "Areas for growth report viewer page title is displayed successfully!!!", "Areas for growth report viewer page title is not displayed properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();

        }
    }

    @Test ( description = "Verify user can enter the page number in the 'Go to' text box and page number is displayed in the areas for growth report viewer.", groups = { "SMK-63441", "AreasForGrowth", "AreasForGrowth" }, priority = 1 )
    public void tcAreasForGrowthSubheaderOption002() throws Exception {
        // final WebDriver driver = WebDriverFactory.get( browser );
        WebDriverManager.chromedriver().setup();
        final WebDriver driver = new ChromeDriver();

        Log.testCaseInfo( "Verify user can enter the page number in the 'Go to' text box and page number is displayed in the areas for growth report viewer.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            AFGReportViewerPage afgReportViewerPage = dashBoardPage.clickRunReportButton();
            dashBoardPage.totalPageNo();

            Log.assertThat( dashBoardPage.goToPage( 5 ), "User should able to enter the number in 'Go to' text box.!!!", "User should not able to enter the number in 'Go to' text box." );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the Back and Next button nearer to the page number  in the areas for growth report vieiwer.", groups = { "SMK-63441", "AreasForGrowth", "AreasForGrowth" }, priority = 1 )
    public void tcAreasForGrowthSubheaderOption003() throws Exception {
        // final WebDriver driver = WebDriverFactory.get( browser );
        WebDriverManager.chromedriver().setup();
        final WebDriver driver = new ChromeDriver();

        Log.testCaseInfo( "Verify the Back and Next button nearer to the page number  in the areas for growth report vieiwer.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );

            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            AFGReportViewerPage afgReportViewerPage = dashBoardPage.clickRunReportButton();
            Log.assertThat( afgReportViewerPage.reportOutputComponent.isdisableBackBtn(), "Areas for growth report viewer page Back button is disabled!!!", "Areas for growth report viewer page back button is not disabled" );
            Log.assertThat( afgReportViewerPage.reportOutputComponent.isenableNextBtn(), "Areas for growth report viewer page Next button is enabled!!!", "Areas for growth report viewer page Next button is not enabled" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();

        }
    }

    @Test ( description = "Verify the Subject name, Report run, School, Teacher, Grade, Group, Total skills at risk and Total Studentsat risk in the areas for growth report Viewer.", groups = { "SMK-63441", "AreasForGrowth",
            "AreasForGrowth" }, priority = 1 )
    public void tcAreasForGrowthSubheaderOption004() throws Exception {
        // final WebDriver driver = WebDriverFactory.get( browser );
        WebDriverManager.chromedriver().setup();
        final WebDriver driver = new ChromeDriver();

        Log.testCaseInfo( "Verify the Subject name, Report run, School, Teacher, Grade, Group, Total skills at risk and Total Studentsat risk in the areas for growth report Viewer.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );

            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            AFGReportViewerPage afgReportViewerPage = dashBoardPage.clickRunReportButton();
            Log.assertThat( afgReportViewerPage.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( afgReportViewerPage.getDateLabel().equals( afgReportViewerPage.dateAndTime() ), "Date and time is present", "Date and time is not present" );

            SMUtils.logDescriptionTC( "Verify the school name in the Areas for growth report Viewer" );
            SMUtils.logDescriptionTC( "Verify Teacher name in the Areas for growth report Viewer" );
            SMUtils.logDescriptionTC( "Verify Grade field in the Areas for growth report Viewer" );
            SMUtils.logDescriptionTC( "Verify Group name in the Areas for growth report Viewer" );

            List<String> infoHeaders = afgReportViewerPage.reportOutputComponent.getInfoHeader();
            IntStream.range( 0, infoHeaders.size() ).forEach( itr -> {
                Log.assertThat( infoHeaders.get( itr ).equals( ReportsUIConstants.INFO_LABELS.get( itr ) ), infoHeaders.get( itr ) + " is displayed in the Areas for growth report Viewer", ReportsUIConstants.INFO_LABELS.get( itr ) + " is not displayed in the Areas for growth report Viewer" );

                Log.assertThat( afgReportViewerPage.getTotalSkillAtRiskValues().contains( "Total Skills At Risk:" ), "Total skills at risk label is present", "Total skills at risk label is not present" );
                Log.assertThat( afgReportViewerPage.getTotalStudentsAtRiskValues().contains( "Total Students At Risk:" ), "Total students at risk label is present", "Total students at risk label is not present" );

                Log.testCaseResult();
            } );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify selected options field in the areas for growth report viewer..", groups = { "SMK-63441", "AreasForGrowth", "AreasForGrowth" }, priority = 1 )
    public void tcAreasForGrowthSubheaderOption005() throws Exception {
        // final WebDriver driver = WebDriverFactory.get( browser );
        WebDriverManager.chromedriver().setup();
        final WebDriver driver = new ChromeDriver();

        Log.testCaseInfo( "Verify selected options field in the areas for growth report viewer..<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );

            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            AFGReportViewerPage afgReportViewerPage = dashBoardPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify selected options field in the Areas for growth report viewer." );
            Log.assertThat( afgReportViewerPage.reportOutputComponent.getSelectedOptionHeader().equals( ReportsUIConstants.SELECTED_OPTION_HEADER ) || afgReportViewerPage.reportOutputComponent.getSelectedOptionValues().size() == 6,
                    "Selected options field is displayed as expected in the Areas for growth report viewer", "Selected options field is not displayed as expected in the Areas for growth report viewer" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();

        }
    }

    @Test ( description = "Verify Legend in the areas for growth report viewer page...", groups = { "SMK-63441", "AreasForGrowth", "AreasForGrowth" }, priority = 1 )
    public void tcAreasForGrowthSubheaderOption006() throws Exception {
        // final WebDriver driver = WebDriverFactory.get( browser );
        WebDriverManager.chromedriver().setup();
        final WebDriver driver = new ChromeDriver();

        Log.testCaseInfo( "Verify Legend in the areas for growth report viewer page...<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            AFGReportViewerPage afgReportViewerPage = dashBoardPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify Legend in the Areas for growth report viewer page." );
            Log.assertThat( afgReportViewerPage.verifyLegendHeaderAndLabels(), "Legend header and its values are displayed as expected in the Areas for growth report viewer page",
                    "Legend header and its values are not displayed as expected in the Areas for growth report viewer page" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();

        }
    }
}