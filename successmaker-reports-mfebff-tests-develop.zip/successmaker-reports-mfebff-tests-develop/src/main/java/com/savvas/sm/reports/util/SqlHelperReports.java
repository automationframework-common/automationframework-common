package com.savvas.sm.reports.util;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.FileConstants;

public class SqlHelperReports {

    /**
     * This method is used to get values from DB for CP Admin Reports
     * 
     * @param mathAssignmentIds
     * @return
     */
    public Map<String, Map<String, String>> getCPRDataFromDB( String mathAssignmentIds ) {
        Map<String, Map<String, String>> valuesFromDB = new HashMap<>();
        String query = "SELECT CAST (AVG (CASE WHEN (au.assignment_current_level is null)\r\n" + "THEN au.assignment_current_level\r\n" + "                                 WHEN au.ipm_status_id != 3\r\n" + "THEN null\r\n"
                + "ELSE least(au.assignment_current_level, 8.95)\r\n" + "END) as numeric(10,2)) as currentCourseLevel,\r\n" + "                \r\n" + "                CAST (AVG (CASE WHEN au.ipm_status_id != 3\r\n" + "THEN null\r\n"
                + "ELSE au.ipm_end_level\r\n" + "                END) as numeric(10,2)) as ipmEndLevel,\r\n" + "                \r\n" + "CAST (Avg (CASE WHEN (au.assignment_current_level is null)\r\n"
                + "                                         THEN au.assignment_current_level\r\n" + "                                 WHEN au.ipm_status_id != 3\r\n" + "                                         THEN null\r\n"
                + "                                 ELSE least(au.assignment_current_level, 8.95)\r\n" + "                END - CASE WHEN au.ipm_status_id != 3\r\n" + "                                    THEN null\r\n"

                + "                     ELSE au.ipm_end_level\r\n" + "                END) as numeric(10,2)) as gain,\r\n" + "                CAST(AVG(msh.total_session_min) as numeric(10,2)) as Time_Spent,\r\n" + "                \r\n"
                + "                CAST(AVG(session_presented_count) as numeric(10,2)) as Total_Sessions,\r\n" + "                \r\n" + "                CAST(AVG(CASE WHEN au.ipm_status_id = 3\r\n"
                + "                                            THEN msh.total_correct - COALESCE(msh.ipm_correct, 0)\r\n" + "                                        ELSE msh.total_correct\r\n"
                + "                                                END)as numeric(10,2)) AS totalExercisesCorrect,\r\n" + "                        \r\n" + "                CAST(AVG(CASE WHEN au.ipm_status_id = 3\r\n"
                + "                                            THEN msh.total_attempts - COALESCE(msh.ipm_attempts, 0)\r\n" + "                                        ELSE msh.total_attempts\r\n"
                + "                                            END)as numeric(10,2)) AS totalExercisesAttempted,\r\n" + "                                                \r\n" + "                CAST(AVG((CASE WHEN au.ipm_status_id = 3\r\n"
                + "                                            THEN msh.total_attempts - COALESCE(msh.ipm_attempts, 0)\r\n" + "                                        ELSE msh.total_attempts\r\n"
                + "                                            END  /CASE WHEN au.ipm_status_id = 3\r\n" + "                                            THEN msh.total_correct - COALESCE(msh.ipm_correct, 0)\r\n"
                + "                                        ELSE msh.total_correct\r\n" + "                                                END) *100 ) as numeric(10,2)) AS percentCorrected,\r\n" + "                \r\n"
                + "CAST (AVG (CASE WHEN au.ipm_status_id != 3\r\n" + "THEN null\r\n" + "ELSE msh.total_lo_passed\r\n" + "END) as numeric(10,2)) as skillMastered,\r\n" + "\r\n" + "\r\n" + "\r\n" + "CAST (AVG (CASE WHEN au.ipm_status_id != 3\r\n"
                + "THEN null\r\n" + "ELSE msh.total_lo_completed\r\n" + "END) as numeric(10,2)) as skillAssessed,\r\n" + "\r\n" + "\r\n" + "\r\n" + "CAST (AVG ( CASE WHEN (au.ipm_status_id != 3 OR msh.total_lo_passed = 0)\r\n" + "THEN null\r\n"
                + "ELSE (msh.total_lo_completed *100 ) /msh.total_lo_passed\r\n" + "END ) as numeric(10,2)) as percentMastered\r\n" + "\r\n" + "\r\n" + "\r\n" + "FROM assignment_user au,\r\n" + "math_assignment_history msh\r\n"
                + "WHERE au.assignment_user_id IN (" + mathAssignmentIds + ")\r\n" + "AND msh.assignment_user_id = au.assignment_user_id";

        List<Object[]> rowList = SQLUtil.executeQuery( query );
        rowList.forEach( object -> {

            Map<String, String> values = new HashMap<>();

            values.put( "currentCourseLevel", new DecimalFormat( "0.0" ).format( Double.valueOf( object[0].toString() ) ) );
            values.put( "gain", object[2].toString() );
            values.put( "timeSpent", String.valueOf( (int) Double.parseDouble( object[3].toString() ) ) );
            values.put( "totalSessions", String.valueOf( (int) Double.parseDouble( object[4].toString() ) ) );
            valuesFromDB.put( object[2].toString(), values );

        } );

        return valuesFromDB;
    }

}
