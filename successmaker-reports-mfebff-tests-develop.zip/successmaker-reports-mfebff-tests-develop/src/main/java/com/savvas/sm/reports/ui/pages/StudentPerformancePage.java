package com.savvas.sm.reports.ui.pages;

import java.text.DecimalFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.learningservices.utils.Log;
import com.savvas.sm.reports.bff.admin.tests.SPReportAdminGrphQLTest;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.rbs.RBSUtils;

public class StudentPerformancePage extends LoadableComponent<StudentPerformancePage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    /***************** POM for Page **************************/

    @FindBy ( css = "cel-tab-panel.tab-panel-studentPerformance" )
    WebElement cprAggregatetoggle;

    @FindBy ( css = "h2.header" )
    WebElement reportHeader;

    @FindBy ( css = "saved-report-options label" )
    WebElement savereportOptionLabel;

    @FindBy ( css = "cel-tab-panel.tab-panel" )
    WebElement togglebutton;

    @FindBy ( css = "table.areas-for-growth" )
    WebElement reportTable;

    @FindBy ( css = "span.pagination-text-suffix" )
    WebElement totalPageCount;

    @FindBy ( css = "h3.assignment-name" )
    WebElement assignmentName;
    /**************** Child Elements *******************/

    private static String cprAggregateChild = "div.tab-container button.selected";

    //child element
    private String button = "button";
    private String selectedButton = "button.selected";

    @FindBy ( tagName = "h1" )
    WebElement pageTitle;

    @FindBy ( css =  "spr-performance-summary td:nth-child(1)")
    List<WebElement>  performanceSummaryKey;

    @FindBy ( css =  "spr-performance-summary td:nth-child(2)")
    List<WebElement> performanceSummaryValues;

    @FindBy ( css =  "report-grid[class='flex-adjust first'] tr td:nth-of-type(1)")
    List<WebElement> performanceByCompStrandName;

    @FindBy ( css =  "report-grid[class='flex-adjust first'] tr td:nth-of-type(2)")
    List<WebElement> performanceByCompStrandLevel;

    @FindBy ( css =  "report-grid[class='flex-adjust first'] tr td:nth-of-type(3)")
    List<WebElement> performanceByCompSkillMast;

    @FindBy ( css =  "report-grid[class='flex-adjust first'] tr td:nth-of-type(4)")
    List<WebElement> performanceByCompSkillAssessed;

    @FindBy ( css =  "report-grid[class='flex-adjust last'] tr td:nth-of-type(1)")
    List<WebElement> performanceByAppStrandName;

    @FindBy ( css =  "report-grid[class='flex-adjust last'] tr td:nth-of-type(2)")
    List<WebElement> performanceByAppStrandLevel;

    @FindBy ( css =  "report-grid[class='flex-adjust last'] tr td:nth-of-type(3)")
    List<WebElement> performanceByAppSkillMast;

    @FindBy ( css =  "report-grid[class='flex-adjust last'] tr td:nth-of-type(4)")
    List<WebElement> performanceByAppSkillAssessed;

    @FindBy ( css =  "spr-areas-for-growth td:nth-child(1)")
    List<WebElement> performanceByAFGStrandName;

    @FindBy ( css =  "spr-areas-for-growth td:nth-child(2)")
    List<WebElement> performanceByAFGStrandLevel;

    @FindBy ( css =  "spr-areas-for-growth td:nth-child(3)")
    List<WebElement> performanceByAFGStrandDesc;

    @FindBy ( css =  "spr-areas-for-growth td:nth-child(1)")
    List<WebElement> performanceByAFGDateAtRisk;

    @FindBy ( xpath = "//th[contains(.,'Computation Strands')]")
    WebElement performanceByStrandElement;

    @FindBy (css = ".spr-area-for-growth-grid > div:nth-of-type(1) > .rectangle-for-subheading")
    WebElement afgStrandElement;

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public StudentPerformancePage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "Student Performance Page loaded successfully." );
        } else {
            Log.fail( "Student Performance Page not loaded successfully." );
        }

    }

    /**
     * To verify the sub navigation is selected or not
     * 
     * @return
     */
    public boolean isCPAReportSelected() {
        // TODO Auto-generated method stub
        Log.message( "Verifing Student Performance Aggregate is selected" );
        return SMUtils.getWebElementDirect( driver, togglebutton, selectedButton ).getText().trim().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE );

    }

    @FindBy ( css = "student-performance > cel-accordion-item" )
    WebElement optionalFilterRoot;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement nextBtnRoot;

    @FindBy ( css = "student-performance > cel-accordion-item > section > section> div > cel-accordion-item" )
    WebElement studentDemographicsrRoot;

    @FindBy ( css = "organizations-filter > div > div > multi-select > cel-multi-select" )
    WebElement ddOorgIdRoot;

    @FindBy ( css = "#teachers > cel-multi-select" )
    WebElement ddTeacherRoot;

    @FindBy ( css = "div.spinner-container" )
    WebElement Spinner;

    @FindBy ( css = "student-demographics-filter div label" )
    public List<WebElement> demographicsDropdownLabel;

    @FindBy ( css = "section.additional-filters-section checkbox-item > cel-checkbox-item" )
    WebElement checkBoxParent;

    @FindBy(css = "report-footer cel-button")
    WebElement runReportButton;
    
    @FindBy ( css = ".info > dd:nth-of-type(3)")
    WebElement zeroState;

    private int counter = 0;

    public static String DISABLITY_STATUS = "#disability-status";
    public static String ENGLISH_LANGUAGE_PROFICIENCY = "#english-language-proficiency";
    public static String GENDER = "#gender";
    public static String MIGRANT_STATUS = "#migrant-status";
    public static String RACE = "#race";
    public static String ETHINICIY = "#ethnicity";
    public static String SOCIO_ECONOMIC_STATUS = "#socioeconomic-status";
    public static String SPECIAL_SERVICES = "#special-services";
    public static List<String> STUDENT_DEMOGRAPHICS_DROPDOWNS = new ArrayList<String>( Arrays.asList( DISABLITY_STATUS, ENGLISH_LANGUAGE_PROFICIENCY, GENDER, RACE, ETHINICIY, SOCIO_ECONOMIC_STATUS, SPECIAL_SERVICES ) );
    public static String maskStudentCheckBoxCSS = "label > input[type=checkbox]";
    public String cssSelectorForRunReport = "section.report-container report-footer cel-button";
    public String BUTTON = "button";

    public static String TEACHERS = "#teachers";
    public static String GROUPS = "#groups";
    public static String GRADES = "#grades";
    public static String COURSES = "#courses";

    public static String ORGANIZATIONS = "#organization > div > cel-single-select";
    public static String SUBJECT = "#subject > div > cel-single-select";
    public static String DISPLAY = "div.row.filters > single-select > div > cel-single-select";
    public static String DATE_AT_RISH = "div.row.filter > single-select:nth-child(1)";
    public static String LANGUAGE = "div.row.filter > single-select:nth-child(2)";

    public static List<String> OPTIONAL_FILTER_STATIC_DROPDOWNS = new ArrayList<String>( Arrays.asList( SUBJECT, DISPLAY, DATE_AT_RISH ) );

    public static String DROPDOWN_GRADNPARENT = "%s > cel-multi-select";
    public static String DROPDOWN_LIST_Root1 = "#dropdown > cel-multi-checkbox.multi-checkbox.hydrated";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1_Old = "#dropdown > cel-single-select-item";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1 = "ul>li";

    public static String DROPDOWN_DATA_ROOT = "div > div.bottom-container > div > cel-checkbox-item";
    public static String DROPDOWN_GRAND_CHILD = "label > span";
    public static String DROPDOWN_LIST_Root2 = "div > div.bottom-container div";
    public static String DROPDOWN_PARENT1 = "div > button > cel-icon";
    public static String DIV = "div";
    public static String LABEL = "label";
    public static String checkMarkCCSS = "checkmark-icon cel-color cel-color-disabled icon-small hydrated";

    public static String SELECT_ALL_ROOT2 = "div > div.header-container.item-container.border-bottom > cel-checkbox-item";
    public static String SELECT_ALL_ROOT3 = "label > input[type=checkbox]";
    public static String SELECT_ALL_PARTIAL_SELECT = "label > input.indeterminate";

    public static List<String> SINGLE_SELECT_DROPDOWNS = new ArrayList<String>( Arrays.asList( ORGANIZATIONS, SUBJECT, DISPLAY, DATE_AT_RISH, LANGUAGE ) );
    public static List<String> SORT_DROPDOWN_VALUES = new ArrayList<>( Arrays.asList( "School", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent", "Total Sessions", "Exercises Correct", "Exercises Attempted",
            "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );

    private String headerCSS = "h2.header";
    private String totalPageCountCSS = "header-pagination > div > span.pagination-text-suffix";
    public String studentNameCSS = "#table > tbody > tr  > td:nth-child(1) > div";
    private String nextBtnCSS = "cel-button.next-btn";
    private String backBtnCSS = "cel-button.back-btn";

    /**
     * Return true if the Dropdown is expanded
     * 
     * @param dropdown
     * @return
     */
    public boolean isDropdownExpanded( String dropdown ) {
        SMUtils.nap( 10 );
        WebElement rootElement = null;
        WebElement lisRoot = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
        }
        Log.message( "isDropdownExpanded is " + lisRoot );
        return lisRoot != null ? true : false;
    }

    /**
     * Expand Dropdown
     * 
     * @param dropdownName
     */
    public void expanDropdown( String dropdownName ) {
        if ( !isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
            SMUtils.nap( 2 ); // wait for dropdown load

            Log.message( "Dropdown expanded: " + dropdownName );
        } else {
            Log.message( dropdownName + " Dropdown already expanded" );
        }
    }

    /**
     * Close dropdown Element
     * 
     * @param dropdownName
     */
    public void closeDropdown( String dropdownName ) {
        if ( isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
        } else {
            Log.message( dropdownName + " Dropdown already closed" );
        }
    }

    /**
     * It will return the Dropdown Values
     * 
     * @param dropdown
     * @return
     */
    public List<String> getAllValuesFromDropdown( String dropdown ) {
        final List<String> values = new ArrayList<String>();
        WebElement rootElement = null;
        WebElement parent = null;
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> elements = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            values.addAll( elements.stream().map( element -> SMUtils.getWebElementDirect( driver, element, LABEL ).getAttribute( "data-label" ).trim() ).collect( Collectors.toList() ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            SMUtils.nap( 2 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_Root2 );
            values.addAll( element.stream().map( ddElement -> ddElement.getText().trim() ).collect( Collectors.toList() ) );
        }
        closeDropdown( dropdown );
        return values;
    }

    /***
     * It will opend and the Tick the Values in the Dropdown With options and
     * close the dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void setValuesForDropdown( String dropdownName, List<String> options ) {
        expanDropdown( dropdownName );
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            selectOptionsFromDropdown( dropdownName, options );
        } else {
            unSelectAll( dropdownName );
            selectOptionsFromDropdown( dropdownName, options );
            closeDropdown( dropdownName );
        }
        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }
    }

    /**
     * To get the Dropdown Elements
     * 
     * @param dropdown
     * @return
     */
    public List<WebElement> getAllDropdownElements( String dropdown ) {
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> parent = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );

            List<WebElement> ddElements = new ArrayList<WebElement>();

            parent.stream().forEach( element -> {
                ddElements.add( element.findElement( By.cssSelector( LABEL ) ) );
            }

                    );
            return ddElements;
        } else if ( dropdown.equals( ORGANIZATIONS ) ) {
            return getAllOrganizationDropdownElements();
        } else {
            final List<WebElement> streamList = new ArrayList<WebElement>();
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> dataParent = SMUtils.getWebElements( driver, parent, DROPDOWN_DATA_ROOT );
            dataParent.stream().forEach( ddElement -> {
                streamList.add( SMUtils.getWebElementDirect( driver, ddElement, DROPDOWN_GRAND_CHILD ) );
            } );
            return streamList;
        }
    }

    /**
     * Select the options in the Dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void selectOptionsFromDropdown( String dropdownName, List<String> options ) {
        List<WebElement> elements = getAllDropdownElements( dropdownName );
        if ( elements.size() > 0 ) {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                WebElement option = elements.stream().filter( element -> options.contains( element.getText().trim() ) ).findFirst().orElse( null );
                SMUtils.scrollDownIntoViewElement( driver, option );
                String optionName = option.getText().trim();
                Log.message( "Found option is " + optionName );
                SMUtils.click( driver, option );
                Log.message( optionName + " is ticked" );
            } else {
                elements.stream().filter( element -> options.contains( element.getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollDownIntoViewElement( driver, element );
                    SMUtils.click( driver, element );
                    Log.message( element.getText().trim() + " is ticked" );
                } );
            }

        } else {
            Log.message( "Issue in Selecting values for " + dropdownName );
        }
    }

    /**
     * Return true if Organization Dropdown is expanded
     * 
     * @return
     */
    public boolean isOrganizaionDropdownExpanded() {
        return isDropdownExpanded( ORGANIZATIONS );
    }

    public void expandOrganizationDropdown() {
        if ( !isOrganizaionDropdownExpanded() ) {
            expanDropdown( ORGANIZATIONS );
        } else {
            Log.message( "Organization Dropdown is Expanded" );
        }
    }

    /**
     * This will click and Set the values in Organization Dropdown and close and
     * wait for sppinner to load
     * 
     * @param orgName
     */
    public void setOrganizationsValue( String orgName ) {
        expandOrganizationDropdown();
        setValuesForDropdown( ORGANIZATIONS, new ArrayList<String>( Arrays.asList( orgName ) ) );
        waitForSpinnerToLoadAndDisppear();

        if ( SMUtils.waitForLocator( driver, By.cssSelector( "reports-wrapper > div > img" ), 2 ) ) {
            counter++;
            SMUtils.sendF5Key( driver );
            waitForSpinnerToLoadAndDisppear();
            setOrganizationsValue( orgName );
        }
        counter = 0;
    }

    /**
     * Click optional Filter in Report
     */
    public void clickOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }

    /**
     * Click Student Demographics in Report
     */
    public void clickStudentDemographics() {
        SMUtils.waitForElement( driver, studentDemographicsrRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, studentDemographicsrRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Student Demographics is clicked" );
    }

    /**
     * To Click Org Dropdown
     */
    public void clickOrganizationDropdown() {
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        String query = "return document.querySelector('organizations-filter > div > div > multi-select > cel-multi-select').shadowRoot.querySelector('div > button > cel-icon').shadowRoot.querySelector('div');";
        WebElement DropdownElement = (WebElement) javascriptExecutor.executeScript( query );
        SMUtils.scrollIntoView( driver, DropdownElement );
        SMUtils.click( driver, DropdownElement );
        Log.message( "Orgaanization Dropdown is clicked" );
        SMUtils.nap( 2 ); // nap for Organization dropdown

    }

    /**
     * Get all the Org Dropdown elements
     * 
     * @return
     */
    public List<WebElement> getAllOrganizationDropdownElements() {
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > cel-single-select-item');var labels =[]; root.forEach ( ele => { labels.push(ele.shadowRoot.querySelector('label'))}); { return labels ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    /**
     * To get the organization Details in the Dropdown From click dropdown and
     * get the details and close dropdown
     * 
     * @return
     */
    public HashMap<String, String> getOrganizationDetails() {
        Log.message( "Getting Organization Details..." );
        expandOrganizationDropdown();
        HashMap<String, String> details = new HashMap<String, String>();
        List<WebElement> allOrganizationDropdownElements = getAllOrganizationDropdownElements();
        allOrganizationDropdownElements.stream().forEach( elements -> {
            details.put( elements.getAttribute( "data-label" ), elements.getAttribute( "for" ) );
        } );
        closeDropdown( ORGANIZATIONS );
        Log.message( "Organization details fetched!" );
        return details;
    }

    /**
     * Get OrgIds of the Organization Dropdown
     * 
     * @return
     */
    public List<String> getOrganizationIds() {
        Log.message( "Getting Organization Details..." );
        expandOrganizationDropdown();
        List<String> details = new ArrayList<>();
        List<WebElement> allOrganizationDropdownElements = getAllOrganizationDropdownElements();
        allOrganizationDropdownElements.stream().forEach( elements -> {
            details.add( elements.getAttribute( "for" ) );
        } );
        closeDropdown( ORGANIZATIONS );
        Log.message( "Organization details fetched!" );
        return details;
    }

    /**
     * Get the organization dropdown values
     */
    public List<String> getOrganizationNames() {
        return new ArrayList<String>( getOrganizationDetails().keySet() );

    }

    /**
     * To get the details of the TEacher dropdown
     * 
     * @return
     */
    public List<String> getTeacherIds() {
        return new ArrayList<String>( getDropdownsDataDetails( TEACHERS ).keySet() );
    }

    public List<String> getTeacherUserNames() {
        HashMap<String, String> dropdownsDataDetails = getDropdownsDataDetails( TEACHERS );
        return dropdownsDataDetails.keySet().stream().map( key -> dropdownsDataDetails.get( key ) ).collect( Collectors.toList() );
    }

    /**
     * To get the data for the Dropdown data details From expand and getting and
     * close dropdown
     * 
     * @param dropdownName
     * @return
     */
    public HashMap<String, String> getDropdownsDataDetails( String dropdownName ) {
        HashMap<String, String> details = new HashMap<String, String>();
        WebElement rootElement = null;
        expanDropdown( dropdownName );

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            List<WebElement> ddValues = SMUtils.getWebElementsDirect( driver, parent, LABEL );
            ddValues.stream().forEach( eachElement -> {
                details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
            } );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_DATA_ROOT );
            element.stream().forEach( eachElement -> {
                details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
            } );
        }
        closeDropdown( dropdownName );
        return details;
    }

    public ArrayList<String> getGroupIds() {
        return new ArrayList<String>( getDropdownsDataDetails( GROUPS ).keySet() );
    }

    public List<String> getGroupNames() {
        HashMap<String, String> dropdownsDataDetails = getDropdownsDataDetails( GROUPS );
        return dropdownsDataDetails.keySet().stream().map( key -> dropdownsDataDetails.get( key ) ).collect( Collectors.toList() );
    }

    /**
     * Wait for the spinner to Load and Wait for disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, Duration.ofSeconds( 60 ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }

    /**
     * To return the dropdown valuses that are checked
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getCheckedValuesForDropdown( String dropdownName ) {
        expanDropdown( dropdownName );
        ArrayList<String> filteredValue = new ArrayList<String>();
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            WebElement checkMark = driver.findElement( By.cssSelector( checkMarkCCSS ) ).findElement( By.xpath( "./.." ) );
            String value = checkMark.getAttribute( "data-label" );
            filteredValue.add( value );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_Root2 );
            element.stream().forEach( eachElement -> {
                WebElement colorChecking = SMUtils.getWebElementDirect( driver, eachElement.findElement( By.cssSelector( "cel-checkbox-item" ) ), SELECT_ALL_ROOT3 );
                try {
                    if ( SMUtils.checkBackgroundColor( colorChecking, selectAllCheckBoxColor ) ) {
                        filteredValue.add( eachElement.findElement( By.cssSelector( "cel-checkbox-item" ) ).getAttribute( "data-label" ) );
                    }
                } catch ( Exception e ) {}
            } );
        }

        closeDropdown( dropdownName );
        return filteredValue;
    }

    /**
     * Click Select all options in the Dropdown
     * 
     */
    public void clickSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( !SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
            if ( !verifySelectAllCheckBoxColor( dropdownName ) ) {
                SMUtils.click( driver, element );
            } else {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
            }
            Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
            closeDropdown( dropdownName );
        }
    }

    /**
     * Unselect All options in Dropdown
     * 
     * @param dropdownName
     */
    public void unSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        }
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
        if ( verifySelectAllCheckBoxColor( dropdownName ) ) {
            SMUtils.click( driver, element );
        } else {
            SMUtils.click( driver, element );
            SMUtils.click( driver, element );
        }
        Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
        closeDropdown( dropdownName );
    }

    public static String selectAllCheckBoxColor = "#006be0";

    /**
     * Return true if the checkBox is selected
     * 
     * @param dropdownName
     * @return
     */
    public boolean verifySelectAllCheckBoxColor( String dropdownName ) {
        WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_ROOT3 );
        String color = Color.fromString( element.getCssValue( "background-color" ) ).asHex();
        return ( color.equals( selectAllCheckBoxColor ) ) ? true : false;
    }

    /**
     * Return true if Select All option is Selected
     * 
     * @param dropdown
     * @return
     */
    public boolean isSelectAllChecked( String dropdown ) {
        expanDropdown( dropdown );
        boolean flag = false;
        if ( verifySelectAllCheckBoxColor( dropdown ) ) {
            WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_PARTIAL_SELECT );
            if ( element == null ) {
                flag = true;
            } else {
                flag = false;
            }
        }
        closeDropdown( dropdown );
        return flag;
    }

    /**
     * click checkbox Mask Student CheckBox
     */
    public void clickMaskStudentCheckBox() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }

    /**
     * return true if check box is checked For MaskStudentDisplay
     * 
     * @return
     */
    public boolean isMaskStudentisChecked() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        try {
            if ( SMUtils.checkBackgroundColor( element, selectAllCheckBoxColor ) ) {
                return true;
            } else {
                return false;
            }
        } catch ( Exception e ) {
            return false;
        }
    }

    @FindBy ( css = "student-demographics-filter > div div" )
    List<WebElement> demographicsHeaader;
    public static List<String> demographicsHeaders = new ArrayList<String>( Arrays.asList( "Disability Status", "English Language Proficiency", "Gender", "Migrant Status", "Race", "Ethnicity", "Socioeconomic Status", "Special Services" ) );

    /**
     * Verify the Headers in demographics Dropdown
     * 
     * @return
     */
    public boolean verifyStudentDemographicsHeader() {
        List<String> header = new ArrayList<>();
        demographicsHeaader.stream().forEach( element -> {
            header.add( element.findElement( By.cssSelector( LABEL ) ).getText().trim() );
        } );
        return SMUtils.compareTwoList( header, demographicsHeaders );
    }

    public void clickGradesDropdown() {
        expanDropdown( GRADES );
    }

    public void expandCoursesDropdown() {
        expanDropdown( COURSES );
    }

    public void expandSubjectDropdown() {
        expanDropdown( SUBJECT );
    }

    public void selectOptionsFromSubjectDropdown( String subjectName ) {
        setValuesForDropdown( SUBJECT, new ArrayList<String>( Arrays.asList( subjectName ) ) );
        waitForSpinnerToLoadAndDisppear();
    }

    public StudentPerformanceOutputPage clickRunReport() {

        try {
            WebElement webElementDirect = SMUtils.getWebElementDirect( driver, runReportButton, button );
            SMUtils.clickJS( driver, webElementDirect );
            Log.message( "Clicked Run report Button" );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Unable to click the run report button!!!" );
        }
        return new StudentPerformanceOutputPage( driver ).get();
    }

    public StudentPerformanceOutputPage clickRunBtn() {
        SMUtils.nap( 10 );
        String parent = driver.getWindowHandle();
        Set<String> s = driver.getWindowHandles();
        Iterator<String> I1 = s.iterator();
        while ( I1.hasNext() ) {
            String child_window = I1.next();
            if ( !parent.equals( child_window ) ) {
                driver.switchTo().window( child_window );
                Log.message( driver.switchTo().window( child_window ).getTitle() );
            }
        }
        return new StudentPerformanceOutputPage( driver ).get();

    }

    public List<WebElement> getDropdownElement( String dropdownName ) {
        String query = "var root = document.querySelector('#" + dropdownName + " > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > li > label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    public boolean selectOrganization( String name ) {
        expanDropdown( ORGANIZATIONS );
        List<WebElement> ddElements = getDropdownElement( "organization" );
        for ( WebElement element : ddElements ) {
            if ( element.getAttribute( "data-label" ).equals( name ) ) {
                SMUtils.clickJS( driver, element );
                break;
            }
        }
        closeDropdown( ORGANIZATIONS );
        return true;
    }

    public boolean selectSubject( String name ) {
        expanDropdown( SUBJECT );
        List<WebElement> ddElements = getDropdownElement( "subject" );
        for ( WebElement element : ddElements ) {
            if ( element.getAttribute( "data-label" ).equals( name ) ) {
                SMUtils.clickJS( driver, element );
                break;
            }
        }
        closeDropdown( SUBJECT );
        return true;
    }

    public boolean checkReportHeaderAfterRun() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( headerCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( headerCSS ) ), 5000 );
            WebElement heading = driver.findElement( By.cssSelector( headerCSS ) );
            return heading.getText().equals( "Student Performance" );
        } catch ( Exception e ) {
            Log.message( "Header not found" );
        }
        return false;
    }

    public int countPage() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( studentNameCSS ), 10000 );
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( totalPageCountCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( totalPageCountCSS ) ), 5000 );
            WebElement countTxt = driver.findElement( By.cssSelector( totalPageCountCSS ) );
            return Integer.parseInt( countTxt.getText().replace( "of ", "" ) );
        } catch ( Exception e ) {
            Log.message( "Page Count found" );
        }
        return 0;
    }

    public boolean clickNextButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( nextBtnCSS ) ) );
            WebElement nextBtnShd = driver.findElement( By.cssSelector( nextBtnCSS ) );

            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, nextBtnShd, button ) );
            Log.message( "Clicked Next Button!" );
            return true;
        } catch ( Exception e ) {
            Log.message( "Clicked next Button Failed" );
            return false;
        }
    }

    public boolean isNextButtonEnable() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( nextBtnCSS ) ) );
            WebElement nextBtnShd = driver.findElement( By.cssSelector( nextBtnCSS ) );

            return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, nextBtnShd, button ) );
        } catch ( Exception e ) {
            Log.message( "Next Button Enable/Disable Status Not recognized" );
            return false;
        }
    }

    public boolean isBackButtonEnable() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( backBtnCSS ) ) );
            WebElement nextBtnShd = driver.findElement( By.cssSelector( backBtnCSS ) );

            return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, nextBtnShd, button ) );
        } catch ( Exception e ) {
            Log.message( "Back Button Enable/Disable Status Not recognized" );
            return false;
        }
    }

    /**
     * To get assignment names
     * 
     * @return
     * @throws InterruptedException
     */
    public List<String> getAssignmentName() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        List<String> assignmentNameList = new ArrayList<>();
        IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
            assignmentNameList.add( assignmentName.getText().trim() );
            WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
            if ( nextBtn.isEnabled() ) {
                SMUtils.click( driver, nextBtn );
            }
        } );
        return assignmentNameList;
    }


    public  List<String> getPerformanceSummaryKey(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceSummaryKey.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceSummaryValues(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceSummaryValues.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByCompStrandName(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByCompStrandName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByCompStrandLevel(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByCompStrandLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByCompSkillMast(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByCompSkillMast.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByCompSkillAssessed(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8);
        return performanceByCompSkillAssessed.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    //  -------------------------------------------------------------------------------------------------------------------------------

    public  List<String> getPerformanceByAppStrandName(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAppStrandName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAppStrandLevel(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAppStrandLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAppSkillMast(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAppSkillMast.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAppSkillAssessed(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAppSkillAssessed.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAFGStrandName(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAFGStrandName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAFGStrandLevel(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAFGStrandLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAFGStrandDesc(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAFGStrandDesc.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public  List<String> getPerformanceByAFGDateAtRisk(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader, 8 );
        return performanceByAFGDateAtRisk.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public HashMap<String, List<String>> getDataFromOutputUI( WebDriver driver ) throws InterruptedException {
        SPReportAdminGrphQLTest spObject = new SPReportAdminGrphQLTest();
        
        List<String> level = new ArrayList<>();
        List<String> name = new ArrayList<>();
        List<String> skilMastered = new ArrayList<>();
        List<String> skilAssessed = new ArrayList<>();
        List<String> appName = new ArrayList<>();
        List<String> appLevel = new ArrayList<>();
        List<String> appSkilMastered = new ArrayList<>();
        List<String> appSkilAssessed = new ArrayList<>();
        
        name =  getPerformanceByCompStrandName(driver);
        name.remove( name.size() - 1 );
        level =  getPerformanceByCompStrandLevel(driver);
        skilMastered =  getPerformanceByCompSkillMast(driver);
        skilAssessed =  getPerformanceByCompSkillAssessed(driver);
        appName =  getPerformanceByAppStrandName(driver);
        appName.remove( appName.size() - 1 );
        appLevel =  getPerformanceByAppStrandLevel(driver);
        appSkilMastered =  getPerformanceByAppSkillMast(driver);
        appSkilAssessed =  getPerformanceByAppSkillAssessed(driver);

        HashMap<String, List<String>> studentReport = new HashMap<String, List<String>>();
        List<String> newList = name.stream().distinct().collect( Collectors.toList() );
        List<String> newList2 = level.stream().distinct().collect( Collectors.toList() );
        List<String> newList3 = appName.stream().distinct().collect( Collectors.toList() );
        List<String> newList4 = appLevel.stream().distinct().collect( Collectors.toList() );
        List<String> newList5 = skilMastered.stream().distinct().collect( Collectors.toList() );
        List<String> newList6 = skilAssessed.stream().distinct().collect( Collectors.toList() );
        List<String> newList7 = appSkilMastered.stream().distinct().collect( Collectors.toList() );
        List<String> newList8 = appSkilAssessed.stream().distinct().collect( Collectors.toList() );

        studentReport.put( "computationName", newList );
        studentReport.put( "computationLevel", newList2 );
        studentReport.put( "computationSkillsMastered", newList5 );
        studentReport.put( "computationSkillsAssessed", newList6 );
        studentReport.put( "applicationName", newList3 );
        studentReport.put( "applicationLevel", newList4 );
        studentReport.put( "applicationSkillsMastered", newList7 );
        studentReport.put( "applicationSkillsAssessed", newList8 );

        Log.message( "DataFromUI:  " + studentReport );
        return studentReport;
    }
    
    
    public HashMap<String, List<String>> getDataFromOutputUIReading( WebDriver driver ) throws InterruptedException {
        SPReportAdminGrphQLTest spObject = new SPReportAdminGrphQLTest();
        
        List<String> description = new ArrayList<>();
        List<String> strand = new ArrayList<>();
        List<String> level = new ArrayList<>();

        description =  getPerformanceByAFGStrandDesc(driver);
        description.remove( description.size() - 1 );
        level =  getPerformanceByAFGStrandLevel(driver);
        level.remove( level.size() - 1 );
        strand =  getPerformanceByAFGStrandName(driver);
        strand.remove( strand.size() - 1 );

        HashMap<String, List<String>> studentReport = new HashMap<String, List<String>>();
        List<String> newList = description.stream().distinct().collect( Collectors.toList() );
        List<String> newList1 = level.stream().distinct().collect( Collectors.toList() );
        List<String> newList2 = strand.stream().distinct().collect( Collectors.toList() );

        studentReport.put( "level", newList1 );
        studentReport.put( "strand", newList2 );

        Log.message( "DataFromUI:  " + studentReport );
        return studentReport;
    }

    public Map<String, Map<String, String>> getSPRPerformanceSummaryUI( WebDriver driver) throws InterruptedException {
        Map<String, Map<String, String>> spDetails = new HashMap<>();
        SMUtils.waitForSpinnertoDisapper(driver, 5);
        Log.message( "Getting Data From output..." );

        List<String> getPerformanceByCompStrandName =  getPerformanceByCompStrandName(driver);
        List<String> getPerformanceByCompStrandLevel =  getPerformanceByCompStrandLevel(driver);
        List<String> getPerformanceByCompSkillMast =  getPerformanceByCompSkillMast(driver);
        List<String> getPerformanceByCompSkillAssessed =  getPerformanceByCompSkillAssessed(driver);
        List<String> getPerformanceByAppStrandName =  getPerformanceByAppStrandName(driver);
        List<String> getPerformanceByAppStrandLevel =  getPerformanceByAppStrandLevel(driver);
        List<String> getPerformanceByAppSkillMast =  getPerformanceByAppSkillMast(driver);
        List<String> getPerformanceByAppSkillAssessed =  getPerformanceByAppSkillAssessed(driver);
        List<String> getPerformanceByAFGStrandName =  getPerformanceByAFGStrandName(driver);
        List<String> getPerformanceByAFGStrandLevel =  getPerformanceByAFGStrandLevel(driver);
        List<String> getPerformanceByAFGStrandDesc =  getPerformanceByAFGStrandDesc(driver);
        List<String> getPerformanceByAFGDateAtRisk =  getPerformanceByAFGDateAtRisk(driver);

        IntStream.range( 0, getPerformanceByCompStrandName.size() ).forEach( itr -> {
            Map<String, String> values = new HashMap<>();

            if (  performanceByStrandElement.isDisplayed()) {
                values.put( "computationName", getPerformanceByCompStrandName.get( itr ).toString() );
                values.put( "computationLevel", getPerformanceByCompStrandLevel.get( itr ).toString() );
                values.put( "computationSkillsMastered", getPerformanceByCompSkillMast.get( itr ).toString() );
                values.put( "computationSkillsAssessed", getPerformanceByCompSkillAssessed.get( itr ).toString() );
                values.put( "applicationName", getPerformanceByAppStrandName.get( itr ).toString() );
                values.put( "applicationLevel", getPerformanceByAppStrandLevel.get( itr ).toString() );
                values.put( "applicationSkillsMastered", getPerformanceByAppSkillMast.get( itr ).toString() );
                values.put( "applicationSkillsAssessed", getPerformanceByAppSkillAssessed.get( itr ).toString() );
            } else {
                Log.message( "performanceByStrandElement Data is not available !!" );
            }

            //            if ( afgStrandElement.isDisplayed() ) {
            //                values.put( "getPerformanceByAFGStrandName", getPerformanceByAFGStrandName.get( itr ).toString() );
            //                values.put( "getPerformanceByAFGStrandLevel", getPerformanceByAFGStrandLevel.get( itr ).toString() );
            //                values.put( "getPerformanceByAFGStrandDesc", getPerformanceByAFGStrandDesc.get( itr ).toString() );
            //                values.put( "getPerformanceByAFGDateAtRisk", getPerformanceByAFGDateAtRisk.get( itr ).toString() );
            //            } else {
            //                Log.message( "afgStrandElement Data is not available !!" );
            //            }
            spDetails.put(getPerformanceByCompStrandName.get( itr ), values );
        });
        Log.message( "Final UI Details: " + spDetails);
        return spDetails; 

    }

    // Generic function to convert List of String to List of String
    public static <T, U> List<U> convertIntListToStringList(List<T> listOfInteger,
            Function<T, U> function)
    {
        return Lists.transform(listOfInteger, function);
    }


    public String getAssignmentNameWithTeacherName(String assignmentTitle) {
        RBSUtils rbsUtils = new RBSUtils();
        String queryLS =  adminLSRConstants.GET_ASSIGNMENT_OWNER_ID + "'" + assignmentTitle + "'";
        Log.message( "queryLS: " + queryLS );
        List<String> assignmentownerID = new ArrayList<String>();
        List<Object[]> rowList = SQLUtil.executeQuery( queryLS );

        rowList.forEach(  object -> {
            assignmentownerID.add( object[0].toString() );
        });

        Log.message( "assignmentOwnerId: " + assignmentownerID.get( 0 ) );
        String assignmentOwnerName  = SMUtils.getKeyValueFromResponse(  rbsUtils.getUser( assignmentownerID.get( 0 ) ), "firstAndLastName" );
        String assignmentName = assignmentTitle + " " +"(" + assignmentOwnerName +")" ;
        Log.message( "assignmentName: " + assignmentName);
        return assignmentName;
    }


    public HashMap<String, List<String>> getDataFromResponse( String responseBody ) {
        SPReportAdminGrphQLTest spObject = new SPReportAdminGrphQLTest();
        List<String> level = new ArrayList<>();
        List<String> name = new ArrayList<>();
        List<String> skilMastered = new ArrayList<>();
        List<String> skilAssessed = new ArrayList<>();
        List<String> appName = new ArrayList<>();
        List<String> appLevel = new ArrayList<>();
        List<String> appSkilMastered = new ArrayList<>();
        List<String> appSkilAssessed = new ArrayList<>();

        HashMap<String, List<String>> studentReport = new HashMap<String, List<String>>();

        // Getting data from response
        String jsonObj = spObject.getKeyValueFromResponseWithArray( responseBody, "data,getSPReportData,students" );
        Log.message( "JSON Object:" + jsonObj.toString() );
        IntStream.range( 0, new JSONArray( jsonObj ).length() ).forEach( iter -> {

            String rawPerformance = spObject.getKeyValueFromResponseWithArray( new JSONArray( jsonObj ).get( iter ).toString(), "courses" );
            IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {

                String computationStrands = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,computationStrands" );
                IntStream.range( 0, new JSONArray( computationStrands ).length() ).forEach( itr2 -> {

                    name.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( computationStrands ).get( itr2 ).toString(), "name" ) );
                    level.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( computationStrands ).get( itr2 ).toString(), "level" ) );
                    skilMastered.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( computationStrands ).get( itr2 ).toString(), "skillsMastered" ) );
                    skilAssessed.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( computationStrands ).get( itr2 ).toString(), "skillsAssessed" ) );

                } );

                String applicationStrands = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,applicationStrands" );
                IntStream.range( 0, new JSONArray( applicationStrands ).length() ).forEach( itr3 -> {
                    appName.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( applicationStrands ).get( itr3 ).toString(), "name" ) );
                    appLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( applicationStrands ).get( itr3 ).toString(), "level" ) );
                    appSkilMastered.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( applicationStrands ).get( itr3 ).toString(), "skillsMastered" ) );
                    appSkilAssessed.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( applicationStrands ).get( itr3 ).toString(), "skillsAssessed" ) );
                } );

                List<String> newList = name.stream().distinct().collect( Collectors.toList() );
                List<String> newList2 = level.stream().distinct().collect( Collectors.toList() );
                List<String> newList3 = appName.stream().distinct().collect( Collectors.toList() );
                List<String> newList4 = appLevel.stream().distinct().collect( Collectors.toList() );
                List<String> newList5 = skilMastered.stream().distinct().collect( Collectors.toList() );
                List<String> newList6 = skilAssessed.stream().distinct().collect( Collectors.toList() );
                List<String> newList7 = appSkilMastered.stream().distinct().collect( Collectors.toList() );
                List<String> newList8 = appSkilAssessed.stream().distinct().collect( Collectors.toList() );

                studentReport.put( "computationName", newList );
                studentReport.put( "computationLevel", newList2 );
                studentReport.put( "computationSkillsMastered", newList5 );
                studentReport.put( "computationSkillsAssessed", newList6 );
                studentReport.put( "applicationName", newList3 );
                studentReport.put( "applicationLevel", newList4 );
                studentReport.put( "applicationSkillsMastered", newList7 );
                studentReport.put( "applicationSkillsAssessed", newList8 );
            } );

        } );

        Log.message( "Response Data: " + studentReport );
        return studentReport;
    }
    
    
    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, List<String>> getReadingDataFromResponse( String responseBody ) {
        SPReportAdminGrphQLTest spObject = new SPReportAdminGrphQLTest();
        List<String> description = new ArrayList<>();
        List<String> level = new ArrayList<>();
        List<String> strand = new ArrayList<>();
        
        List<String> appDescription = new ArrayList<>();
        List<String> appLevel = new ArrayList<>();
        List<String> appStrand = new ArrayList<>();
        
        List<String> exerciseAttempt = new ArrayList<>();

        HashMap<String, List<String>> studentReport = new HashMap<String, List<String>>();

        // Getting data from response
        String jsonObj = spObject.getKeyValueFromResponseWithArray( responseBody, "data,getSPReportData,students" );
        Log.message( "JSON Object:" + jsonObj.toString() );
        
        IntStream.range( 0, new JSONArray( jsonObj ).length() ).forEach( iter -> {
            String rawPerformance = spObject.getKeyValueFromResponseWithArray( new JSONArray( jsonObj ).get( iter ).toString(), "courses" );
            
            if ( !rawPerformance.contains( "\"skillsDelayed\":null" ) ) {
                IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                    String skillDelayed = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,skillsDelayed" );
                   
                    IntStream.range( 0, new JSONArray( skillDelayed ).length() ).forEach( itr2 -> {
                        description.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillDelayed ).get( itr2 ).toString(), "description" ) );
                        level.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillDelayed ).get( itr2 ).toString(), "level" ) );
                        strand.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillDelayed ).get( itr2 ).toString(), "strand" ) );
                    } );
                } );
            } else {
                IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                    exerciseAttempt.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,exerAttempted" ) );
                } );
            }

            if ( !rawPerformance.contains( "\"skillsNotMastered\":null" ) ) {

                IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                    String skillsNotMastered = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,skillsNotMastered" );
                    IntStream.range( 0, new JSONArray( skillsNotMastered ).length() ).forEach( itr2 -> {
                        appDescription.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillsNotMastered ).get( itr2 ).toString(), "description" ) );
                        appLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillsNotMastered ).get( itr2 ).toString(), "level" ) );
                        appStrand.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillsNotMastered ).get( itr2 ).toString(), "strand" ) );
                    } );
                } );
            } else {
                IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                    exerciseAttempt.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,exerAttempted" ) );
                } );
            }
            
            DecimalFormat twoDForm = new DecimalFormat( "0.00" );
            List<String> finalLevel = new ArrayList<>();
            
            List<String> newList =  description.stream().distinct().collect( Collectors.toList() );
            List<String> newList1 = level.stream().distinct().collect( Collectors.toList() );
            List<String> newList2 = strand.stream().distinct().collect( Collectors.toList() );
            List<String> newList3 = appDescription.stream().distinct().collect( Collectors.toList() );
            List<String> newList4 = appLevel.stream().distinct().collect( Collectors.toList() );
            List<String> newList5 = appStrand.stream().distinct().collect( Collectors.toList() );
            newList.addAll( newList3 );
            newList1.addAll( newList4 );
            newList2.addAll( newList5 );
            
            for ( String formattedValue  : newList1 ) {
                String value = twoDForm.format( Double.parseDouble( formattedValue.toString() ) );
                finalLevel.add( value );
                
            }

            studentReport.put( "level", finalLevel );
            studentReport.put( "strand", newList2 );

        } );

        Log.message( "Response Data: " + studentReport );
        return studentReport;
    }
    
    
    
    public boolean validateBFFResponseWithMFE( Map<String, List<String>> bffResponse,  Map<String, List<String>> mfeResponse) {
        boolean status = false;
        List<String> bffStrand = new ArrayList<>();
        List<String> bffLevel = new ArrayList<>();
        List<String> mfeStrand = new ArrayList<>();
        List<String> mfeLevel = new ArrayList<>();
        
        bffLevel = bffResponse.get( "level" );
        bffStrand = bffResponse.get( "strand" );
        mfeLevel = mfeResponse.get( "level" );
        mfeStrand = mfeResponse.get( "strand" );
        
        if ( bffLevel.containsAll( mfeLevel ) ) {
           Log.message( "MFE values are matched!!" );
            if ( bffStrand.containsAll( mfeStrand ) ) {
                Log.message( "MFE values are matched!!!!" );
                status = true;
            }
        }
        return status;
    }
    
    public boolean verifyZeroState(WebDriver driver) {
        boolean status = false;
        if ( zeroState.getText().equalsIgnoreCase( "NA" ) ) {
            status = true;
        } else {
            status = false;
        }
        return status;
    }
}
