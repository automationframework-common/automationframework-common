package com.savvas.sm.reports.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;

public class CumulativePerformanceReportPage extends LoadableComponent<CumulativePerformanceReportPage>{

	public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportComponents reportComponents;
    public ReportComponents reportComponent;
    public ReportFilterComponent reportFilterComponent;

    // ********* SM - CPR Report Page Elements ***************

    /***************** POM for Page **************************/

    @FindBy ( tagName = "h1" )
    WebElement pageTitle;
    
    @FindBy ( css = "teacher-cumulative-performance > cel-accordion-item" )
    WebElement optionalFilterRoot;
    
    @FindBy ( css = "report-options label.radio__label" )
    List<WebElement> lblAlldatesAndSelectedDateRange;

    @IFindBy(how = How.CSS, using=  "cel-modal.save-report-modal.hydrated",AI = false)
    public WebElement btnSaveReportRoot;
    
    @IFindBy(how = How.CSS, using=  "cel-button.pr-2.hydrated",AI = false)
    public WebElement btnRunReportRoot;
    
    @IFindBy(how = How.CSS, using=  "cel-button.ml-auto.no-border-btn.hydrated",AI = false)
    public WebElement btnRestBtnRoot;
    
    
    @IFindBy(how = How.CSS, using=  "p.description",AI = false)
    public WebElement txtReportDescription;
    
    @IFindBy(how = How.CSS, using=  "cel-radio-button-group",AI = false)
    public WebElement txtAllDatesRoot;
    
 // ****Child Elements****
    String secondary_button = ".secondary_button";
    String primary_button = ".primary_button";
    String txtAllDatesChild = "cel-radio-button.cel-radio-button.hydrated";
    String txtDateRangeChild = "cel-radio-button:nth-child(2)";
    String btnSaveReportChild1="cel-button.hydrated";
    String btnSaveReportChild2="button";
    String btnRunReportChild = "button.button";
    String btnRestBtnChild ="button.button";
    
	public CumulativePerformanceReportPage(WebDriver driver) {
		    this.driver = driver;
	        this.reportComponents = new ReportComponents( driver );
	        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
	        PageFactory.initElements( finder, this );
	        elementLayer = new ElementLayer( driver );
	    
	}

	@Override
	protected void load() {
		// TODO Auto-generated method stub
		isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );
		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		 try {
	            SMUtils.waitForSpinnertoDisapper( driver, 30 );
	        } catch ( InterruptedException e ) {
	            Log.message( "Issue in Spinner Loading" );
	        }
	        	 if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
	            Log.message( "Cumulative Performance Page loaded successfully." );
	        } else {
	            Log.fail( "Cumulative Performance Page not loaded successfully." );
	        }
		
	}
	/**
     * validate Optional filter text
     */
    public String optionalFilterValidate() {
    	  SMUtils.waitForElement( driver, optionalFilterRoot, 30 );
    	  WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, "button" );
          String reportWebElement = SMUtils.getTextOfWebElement( element, driver );
          return reportWebElement;
	
    }
    /**
     * Validate All Dates fields in CPR Page
     *
     * @param dateHeader
     * @return
     * @throws InterruptedException
     */
    public boolean isAllDatesPresent( String dateHeader ) throws InterruptedException {
        Log.message( "Verifying " + dateHeader + " Heading!" );
                  WebElement allDatesText = SMUtils.getWebElement(driver, txtAllDatesRoot, txtAllDatesChild);
                  return allDatesText.getText().trim().equals( dateHeader );
        }
    
    /**
     * Validate specific Date Range fields in CPR Page
     *
     * @param dateHeader
     * @return
     * @throws InterruptedException
     */
    public boolean isSelectedDateRangesPresent( String dateHeader ) throws InterruptedException {
        Log.message( "Verifying " + dateHeader + " Heading!" );
                  WebElement dateRangeText = SMUtils.getWebElement(driver, txtAllDatesRoot, txtDateRangeChild);
                  return dateRangeText.getText().trim().equals( dateHeader );
        }
    
    /**
     * Click Range fields in CPR Page
     *
     * @param dateHeader
     * @return
     * @throws InterruptedException
     */
    public boolean clickSelectedDateRangesPresent( String dateHeader ) throws InterruptedException {
        Log.message( "Verifying " + dateHeader + " Heading!" );
                  WebElement dateRangeText = SMUtils.getWebElement(driver, txtAllDatesRoot, txtDateRangeChild);
                  SMUtils.clickJS(driver, dateRangeText);
                  return dateRangeText.getText().trim().equals( dateHeader );
        }
   
   

    /**
     * get Save Report Option button
     *
     * @return
     */
    public boolean getSaveReportOptionButton(String data) {
        Log.message( "getting Save Report option button." );
        WebElement saveReportOptionButton1 = SMUtils.getWebElement( driver, btnSaveReportRoot, btnSaveReportChild1 );
        WebElement saveReportOptionButton = SMUtils.getWebElement( driver, saveReportOptionButton1, btnSaveReportChild2 );
        Log.message(saveReportOptionButton.getText().trim());
        return saveReportOptionButton.getText().trim().equals(data);
    }
    
    
    /**
     * get run report button
     *
     * @return
     */
    public boolean getRunReportOption(String data) {
        Log.message( "Getting Run Report button!" );
        WebElement clickRunReport = SMUtils.getWebElement( driver, btnRunReportRoot, btnRunReportChild );
        return clickRunReport.getText().trim().equals(data);
    }
    
    /**
     * get run report button
     *
     * @return
     */
    public boolean getResetOption(String data) {
        Log.message( "Getting Run Report button!" );
        WebElement clickResetReport = SMUtils.getWebElement( driver, btnRestBtnRoot, btnRestBtnChild );
        return clickResetReport.getText().trim().equals(data);
    }
    
            /** Checks and return the boolean for Report Description
    	     *
    	     * @return
    	     * @throws InterruptedException
    	     */
    	    public boolean isReportDescriptionPresent() throws InterruptedException {
    	        Log.message( "Verifying Report description!" );
    	        // There is Question mark available on text to avoid error in jenkins
    	        return txtReportDescription.getText().trim().replaceAll( "[^a-zA-Z0-9]", " " ).equals( ReportsUIConstants.CPR_DESCRIPTION.replaceAll( "[^a-zA-Z0-9]", " " ) );
    	    }
    	   
}
