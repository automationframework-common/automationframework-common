package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class CPRCourseDropdownWithMultipleOrgSelection extends EnvProperties {

    private String adminUsername;
    private String password;
    private String smUrl;
    private String browser;
    private String flexSchool;
    private String flexTeachername;
    private String mathSchool;
    private String flexTeacherDetails;
    private String mathSchoolTeacher;
    private String mathTeacherDetails;
    private String usernameSuffixTest;
    private String mathSchoolMathCourse;
    private String mathStudentUserId;
    private String flexSchoolMathCourse;
    private String flexSchoolReadingCourse;
    private String flexStudentUserId;
    private String deletedAssignment;

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        adminUsername = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        String teacherUserName = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 2, usernameSuffixTest );

        String multiOrgStudent = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 2, 3, usernameSuffixTest );

        String mathUserId = new RBSUtils().getUserIDByUserName( teacherUserName );
        mathTeacherDetails = new RBSUtils().getUser( mathUserId );
        String mathTeacherFirstName = SMUtils.getKeyValueFromResponse( mathTeacherDetails, "firstName" );
        String mathTeacherLastName = SMUtils.getKeyValueFromResponse( mathTeacherDetails, "lastName" );
        mathSchoolTeacher = mathTeacherFirstName + " " + mathTeacherLastName;

        flexTeachername = mathTeacherFirstName + " " + mathTeacherLastName;

        // Get Student details
        Map<String, String> flexStudentDetails = ReportDataCollection.defaultMathAssignmentDetails.get( teacherUserName );

        flexStudentUserId = flexStudentDetails.keySet().stream().findFirst().get();

        flexSchoolMathCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( flexStudentUserId ), "courseDetail,name" );

        flexSchoolReadingCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( flexStudentUserId ), "courseDetail,name" );

        // Get Student details

        mathStudentUserId = new RBSUtils().getUserIDByUserName( multiOrgStudent );

        mathSchoolMathCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( mathStudentUserId ), "courseDetail,name" );

        deletedAssignment = ReportDataCollection.mathDeletedAssignment;
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection", "smoke_test_case" }, description = "Verify the organization name should not display for the default courses", priority = 1 )
    public void tcCPRCourseDropdownWithMultipleOrgSelection001() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection001 - Verify the organization name should not display for the default courses" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify the organization name should not display for the default courses" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> dropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( dropdownValues.stream().filter( list -> list.trim().equals( ReportsUIConstants.MATH ) ).allMatch( assignment -> assignment.equals( ReportsUIConstants.MATH ) ), "The default course name displaying successfully",
                    "The default course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection", "smoke_test_case" }, description = "Verify the organization name for Focuses courses in the course(s) dropdown.", priority = 1 )
    public void tcCPRCourseDropdownWithMultipleOrgSelection002() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection002 - Verify the organization name for Focuses courses in the course(s) dropdown." );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify the organization name for Focuses courses in the course(s) dropdown." );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection",
            "smoke_test_case" }, description = "Verify the organization name in the course dropdown for Math subject after the course name and teacher name. if user selects single organization in organization dropdown" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection003() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection003 - Verify the organization name in the course dropdown for Math subject after the course name and teacher name. if user selects single organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify the organization name in the course dropdown for Math subject after the course name and teacher name. if user selects single organization in organization dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection",
            "smoke_test_case" }, description = "Verify the organization name in the course dropdown for Reading subject after the course name and teacher name. if user selects single organization in organization dropdown" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection004() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection004 - Verify the organization name in the course dropdown for Reading subject after the course name and teacher name. if user selects single organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify the organization name in the course dropdown for Reading subject after the course name and teacher name. if user selects single organization in organization dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.READING );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolReadingCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection",
            "smoke_test_case" }, description = "Verify the organization name in the course dropdown for Math subject after the course name and teacher name. if user select multiple organization in organization dropdown" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection005() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection005 - Verify the organization name in the course dropdown for Math subject after the course name and teacher name. if user select multiple organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify the organization name in the course dropdown for Math subject after the course name and teacher name. if user select multiple organization in organization dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection",
            "smoke_test_case" }, description = "Verify the organization name in the course dropdown for Reading subject after the course name and teacher name. if user selects multiple organization in organization dropdown" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection006() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection006 - Verify the organization name in the course dropdown for Reading subject after the course name and teacher name. if user selects multiple organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify the organization name in the course dropdown for Reading subject after the course name and teacher name. if user selects multiple organization in organization dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.READING );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolReadingCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection", "smoke_test_case" }, description = "Verify the Organization name for the shared course, if the selected organization has shared course assignment. " )
    public void tcCPRCourseDropdownWithMultipleOrgSelection007() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection007 - Verify the Organization name for the shared course, if the selected organization has shared course assignment. " );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-004: Verify the Organization name for the shared course, if the selected organization has shared course assignment. " );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70081", "Course- multi org selection", "smoke_test_case" }, description = "Verify the Organization name for the courses, if the multiple school teacher has assignments in both schools" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection008() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection008 - Verify the Organization name for the courses, if the multiple school teacher has assignments in both schools" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-004: Verify the Organization name for the courses, if the multiple school teacher has assignments in both schools" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown shows the assignment belongs to selected org" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection009() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection009 - Verify course dropdown shows the assignment belongs to selected org" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown shows the assignment belongs to selected org" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown shows the assignment belongs to selected orgs" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0010() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0010 - Verify course dropdown shows the assignment belongs to selected orgs" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown shows the assignment belongs to selected org" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown shows assignment name along with teacher name and Organization name" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0011() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0011 - Verify course dropdown shows assignment name along with teacher name and Organization name" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown shows assignment name along with teacher name and Organization name" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown should show assignments based on organization and subject selection" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0012() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0012 - Verify course dropdown should show assignments based on organization and subject selection" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown should show assignments based on organization and subject selection" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown should not show deleted assignment" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0013() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0013 - Verify course dropdown should not show deleted assignment" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown should not show deleted assignment" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( !courseDropdownValues.containsAll( Arrays.asList( deletedAssignment + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown should not show the course which is not assigned to students" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0014() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0014 - Verify course dropdown should not show the course which is not assigned to students" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-004:Verify course dropdown should not show the course which is not assigned to students" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( !courseDropdownValues.containsAll( Arrays.asList( deletedAssignment + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection",
            "smoke_test_case" }, description = "Verify course dropdown should show assignment multiple times with respective teacher for same school when same course is assigned by multiple teacher" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0015() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0015 - Verify course dropdown should show assignment multiple times with respective teacher for same school when same course is assigned by multiple teacher" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-004: Verify course dropdown should show assignment multiple times with respective teacher for same school when same course is assigned by multiple teacher" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection",
            "smoke_test_case" }, description = "Verify course dropdown should show the shared course assignments of all the selected orgs when single course is shared with multiple orgs" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0016() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0016 - Verify course dropdown should show the shared course assignments of all the selected orgs when single course is shared with multiple orgs" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001:Verify course dropdown should show the shared course assignments of all the selected orgs when single course is shared with multiple orgs" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify teacher name along with assignment should show as first name and last name within brackets in the course dropdown" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0017() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0017 - Verify teacher name along with assignment should show as first name and last name within brackets in the course dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify teacher name along with assignment should show as first name and last name within brackets in the course dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify teacher name should not appear for default courses" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0018() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0018 - Verify teacher name should not appear for default courses" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify teacher name should not appear for default courses" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> dropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( dropdownValues.stream().filter( list -> list.trim().equals( ReportsUIConstants.MATH ) ).allMatch( assignment -> assignment.equals( ReportsUIConstants.MATH ) ), "The default course name displaying successfully",
                    "The default course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown should be reloaded with proper assignments when additional org is selected" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0019() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0019 - Verify course dropdown should be reloaded with proper assignments when additional org is selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown should be reloaded with proper assignments when additional org is selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown should be reloaded with proper courses when any org is deselected" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0020() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0020 - Verify course dropdown should be reloaded with proper courses when any org is deselected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown should be reloaded with proper courses when any org is deselected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( !courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name is displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69728", "Course- multi org selection", "smoke_test_case" }, description = "Verify course dropdown should load all the courses for the selected orgs when all the organizations are selected" )
    public void tcCPRCourseDropdownWithMultipleOrgSelection0021() throws Exception {

        Log.testCaseInfo( "tcCPRCourseDropdownWithMultipleOrgSelection0021 - Verify course dropdown should load all the courses for the selected orgs when all the organizations are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify course dropdown should load all the courses for the selected orgs when all the organizations are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            List<String> courseDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( flexSchoolMathCourse + " (" + flexTeachername + ")" + " (" + flexSchool + ")" ) ), "The course name displaying successfully", "The course name not displaying properly" );
            Log.assertThat( courseDropdownValues.containsAll( Arrays.asList( mathSchoolMathCourse + " (" + mathSchoolTeacher + ")" + " (" + mathSchool + ")" ) ), "The course name is displaying successfully", "The course name not displaying properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}