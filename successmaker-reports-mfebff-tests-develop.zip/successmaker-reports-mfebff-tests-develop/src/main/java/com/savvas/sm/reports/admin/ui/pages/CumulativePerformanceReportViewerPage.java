package com.savvas.sm.reports.admin.ui.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Select;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;

public class CumulativePerformanceReportViewerPage extends LoadableComponent<CumulativePerformanceReportViewerPage> {

    WebDriver driver;
    boolean isPageLoaded;
    public AdminReportOutputComponent reportOutputComponent;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @FindBy ( css = "h2.header" )
    WebElement reportHeader;

    @IFindBy ( how = How.CSS, using = "div h3.assignment-name", AI = false )
    WebElement assignmentName;

    @IFindBy ( how = How.CSS, using = "single-select cel-single-select", AI = false )
    WebElement orgDropdownRoot;

    @FindBy ( css = "report-sub-header dl.info dd" )
    List<WebElement> selectedFields;

    @FindBy ( css = "report-grid table tr td div.names" )
    List<WebElement> studentNames;

    @FindBy ( css = "table tbody tr" )
    List<WebElement> gridValues;

    /******************* Child Elements ******************************/

    private String orgDropdownoptions = "option";
    private String selectedOrganizatioLbl = "label.dropdown-label";
    private String selectDrp = "select";
    private String tabledata = "td";

    public CumulativePerformanceReportViewerPage() {}

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public CumulativePerformanceReportViewerPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        reportOutputComponent = new AdminReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, assignmentName );
    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, assignmentName, 30 ) ) {
            Log.message( "Cumulative Performance Report viewer Page loaded successfully." );
        } else {
            Log.fail( "Cumulative Performance Page viewer Page not loaded successfully." );
        }
        elementLayer = new ElementLayer( driver );
    }

    /**
     * To verify the organization dropdown is displaying or not
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isOrganizationDropdownDisplayed() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        try {
            SMUtils.waitForElement( driver, orgDropdownRoot );
            return SMUtils.getWebElementDirect( driver, orgDropdownRoot, selectedOrganizatioLbl ).isDisplayed();
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To get the available organizations from organization dropdown
     * 
     * @throws InterruptedException
     */
    public List<String> getAvailableOrganizationsFromOrganizationDropdown() throws InterruptedException {
        try {
            SMUtils.waitForElement( driver, orgDropdownRoot );
            return SMUtils.getWebElementsDirect( driver, orgDropdownRoot, orgDropdownoptions ).stream().filter( element -> !element.getText().trim().equalsIgnoreCase( ReportsUIConstants.CHOOSE_AN_ORGANIZATION_LABEL ) ).map(
                    element -> element.getText().trim() ).collect( Collectors.toList() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while collect the organizations from organization dropdown!!!" + e.getMessage() );
            return null;
        }
    }

    /**
     * To select the organization
     * 
     * @param organizationName
     */
    public void selectOrganization( String organizationName ) {
        try {
            SMUtils.waitForElement( driver, orgDropdownRoot );
            Select select = new Select( SMUtils.getWebElementDirect( driver, orgDropdownRoot, selectDrp ) );
            select.selectByVisibleText( organizationName );
        } catch ( Exception e ) {
            Log.message( "Getting issue while select the organization in organization dropdown!!!" + e.getMessage() );
        }
    }

    /**
     * To get the selected organization
     * 
     * @return
     */
    public String getselectedOrganization() {
        try {
            SMUtils.waitForElement( driver, orgDropdownRoot );
            return SMUtils.getWebElementDirect( driver, orgDropdownRoot, selectedOrganizatioLbl ).getText().trim();
        } catch ( Exception e ) {
            Log.message( "Getting issue while get the selected organization in organization dropdown!!!" + e.getMessage() );
            return null;
        }
    }

    /**
     * To get the selected organization name in Report viewer Page
     * 
     * @throws InterruptedException
     * 
     */
    public String getSelectedDates() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        Log.message( "Getting an organization name" );
        SMUtils.waitForElement( driver, assignmentName );
        return SMUtils.getTextOfWebElement( selectedFields.get( 4 ), driver );
    }

    /**
     * To get the student names from current report viewer page
     * 
     * @return
     */
    public List<String> getStudentnamesFromCurrentReport() {
        Log.message( "Getting Student name in current report viewer page" );
        try {
            return SMUtils.getAllTextFromWebElementList( studentNames );
        } catch ( Exception e ) {
            Log.message( "Getting issue while get the student names from report viewer page" );
            return null;
        }
    }

    public Map<String, Map<String, String>> getGridvalues() {
        SMUtils.waitForElement( driver, reportHeader );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();
            String studentName = columnData.get( 0 ).getText().trim();
            gridValue.put( "Assigned Course Level", columnData.get( 1 ).getText().trim() );
            gridValue.put( "Current Course Level", columnData.get( 2 ).getText().trim() );
            gridValue.put( "IP Level", columnData.get( 3 ).getText().trim() );
            gridValue.put( "Gain", columnData.get( 4 ).getText().trim() );
            gridValue.put( "Time Spent", columnData.get( 5 ).getText().trim() );
            gridValue.put( "Total Sessions", columnData.get( 6 ).getText().trim() );
            gridValue.put( "Exercises Correct", columnData.get( 7 ).getText().trim() );
            gridValue.put( "Exercises Attempted", columnData.get( 8 ).getText().trim() );
            gridValue.put( "Exercises Percent Correct", columnData.get( 9 ).getText().trim() );
            gridValue.put( "Skills Assessed", columnData.get( 10 ).getText().trim() );
            gridValue.put( "Skills Mastered", columnData.get( 11 ).getText().trim() );
            gridValue.put( "Skills Percent Mastered", columnData.get( 12 ).getText().trim() );
            gridValue.put( "AP", columnData.get( 13 ).getText().trim() );

            allGridValues.put( studentName, gridValue );

        } );
        return allGridValues;
    }

}
