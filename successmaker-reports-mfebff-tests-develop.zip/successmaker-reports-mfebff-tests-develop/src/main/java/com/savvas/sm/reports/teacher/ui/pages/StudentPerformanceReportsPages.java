package com.savvas.sm.reports.teacher.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsBrowserActions;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.reports.smoke.teacher.pages.StudentPerformanceReport;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.IFindBy;

public class StudentPerformanceReportsPages extends LoadableComponent<StudentPerformanceReportsPages> {

	private final WebDriver driver;
	boolean isPageLoaded;
	public ReportComponents reportComponents;
	public ReportFilterComponent reportFilterComponent;

	/***************** POM for Page **************************/

	@IFindBy(how = How.XPATH, using = " //label[text()='Date at Risk']", AI = false)
	public WebElement txtDateAtRisk;

	@FindBy(tagName = "h1")
	WebElement pageTitle;

	@FindBy(css = "cel-platform-navbar.hydrated")
	public WebElement topNavBarwithShadow;

	@FindBy(css = "cel-radio-button-group.row.hydrated")
	List<WebElement> rbHeaderforAllPerformance;
	
	@FindBy(css=".spr-performance-by-strand-grid tbody tr div.cell-data")
	List<WebElement> performanceStrand;

	@FindBy(css = "p.description")
	public WebElement SPRDescriptionText;

	@IFindBy(how = How.CSS, using = "section.page-title div h1", AI = false)
	public WebElement lbSPRHeader;

	@IFindBy(how = How.CSS, using = "div.col-md-2 label.title-label", AI = false)
	public WebElement lblSubjectDropdownHeader;

	@IFindBy(how = How.CSS, using = "div.step2 div.col-md-6 label", AI = false)
	public WebElement lblAssignemntDropdownHeader;

	@FindBy(css = "cel-checkbox-item.hydrated")
	public WebElement lblMaskStudentDisplayTextRoot;

	@IFindBy(how = How.CSS, using = "report-options div.form-group div.col-md-3 label", AI = false)
	public WebElement lblSavedOptionHeading;

	@FindBy(css = "cel-button.pr-2.hydrated")
	public WebElement runReportBtnRoot;
	
	@FindBy ( css = "div.spinner-container" )
    WebElement Spinner;

	@FindBy(css = "cel-button.hydrated")
	public WebElement saveReportBtnRoot;

	@FindBy(css = "div.form-group label.form-label")
	List<WebElement> rbHeaderforAllPerformce;

	@FindBy(css = "div label")
	List<WebElement> lblMSDropdownHeader;

//	@IFindBy ( how = How.XPATH, using = "//h1[text()='Student Performance Report']", AI = false )
//	public WebElement txtStudentPerformanceReportHeader;

	@IFindBy(how = How.XPATH, using = "//h1[text()='Student Performance Report']", AI = false)
	public WebElement txtStudentPerformanceReportHeader;

	@IFindBy(how = How.CSS, using = "#dateAtRisk", AI = false)
	public WebElement lbldateAtRisk;

	// Subject filter
	@IFindBy(how = How.CSS, using = "div.col-md-2 cel-multi-check-dropdown", AI = false)
	public WebElement lblsubjectfilterroot;

	@IFindBy(how = How.CSS, using = "cel-multi-check-dropdown.ng-cel-multi-check-dropdown", AI = false)
	public WebElement math_readingCheckboxInsideSubjectFilterGrandRoot;

	@IFindBy(how = How.CSS, using = "div.radio__wrapper label[for='cel-rb-2']", AI = false)
	public WebElement performanceSummaryYesRB;

	@IFindBy(how = How.CSS, using = "div.radio__wrapper label[for='cel-rb-3']", AI = false)
	public WebElement performanceSummaryNoRB;

	@IFindBy(how = How.CSS, using = "div.radio__wrapper label[for='cel-rb-4']", AI = false)
	public WebElement performanceByStrandYesRB;

	@IFindBy(how = How.CSS, using = "div.radio__wrapper label[for='cel-rb-5']", AI = false)
	public WebElement performanceByStrandNoRB;

	@IFindBy(how = How.CSS, using = "div.radio__wrapper label[for='cel-rb-6']", AI = false)
	public WebElement areaOfDifficultyYesRB;

	@IFindBy(how = How.CSS, using = "div.radio__wrapper label[for='cel-rb-7']", AI = false)
	public WebElement areaOfDifficultyNoRB;

	@IFindBy(how = How.CSS, using = "section.page-title div h1", AI = false)
	public WebElement studentPerformanceHeader;

	@IFindBy(how = How.CSS, using = ".contextual-help-icon.hydrated", AI = false)
	public WebElement studentPerformancePageHelpIcon;

	@IFindBy(how = How.CSS, using = "#mc-main-content > h1", AI = false)
	public WebElement studentPerformanceHelpPageHeader;

	@IFindBy(how = How.XPATH, using = "//label[text()='Language']", AI = false)
	public WebElement txtLanguage;
	
	 @FindBy ( css = "section.additional-filters-section checkbox-item > cel-checkbox-item" )
	    WebElement checkBoxParent;

	 
	 @FindBy(css= "div div p.header")
	 WebElement noDataText;
	 
	/***************** Child Elements **************************/

//	public String drpDwnDateAtRisk[] = { "cel-accordion-item",
//			"document.querySelector('#date-at-risk').shadowRoot.querySelector('#dropdown')" };
	
	public String drpDwnDateAtRisk[] = { "cel-accordion-item",
	"document.querySelector('#date-at-risk').shadowRoot.querySelector('select.primary-style-select.false')" };
	public String drpDwnLanguage[] = { "cel-accordion-item",
			"document.querySelector('#language').shadowRoot.querySelector('#dropdown')" };

	private String topNavReportsMenuCSSSelector = "#Reports";
	private String reportsMenuItemsCSSSelectorwithShadow = "cel-dropdown-menu-box.hydrated";
	private String allReportSubMenuItemCSSSelector = "ul li a";
	public static String maskStudentCheckBoxCSS = "label > input[type=checkbox]";

	/*** Subject filter child ****/
	private static String lblRemoveMaskStudentDiplayText = "span.checkbox-label";
	private static String maskStudentcheckbox = "label.checkbox__container input";
	private static String runReportBtnchild = "span";
	private static String saveReportoptionsBtnchild = "span";
	
	
	public static String DROPDOWN_GRADNPARENT = "%s > cel-multi-select";
    public static String DROPDOWN_LIST_Root1 = "#dropdown > cel-multi-checkbox.multi-checkbox.hydrated";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1_Old = "#dropdown > cel-single-select-item";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1 = "ul>li";

    public static String DROPDOWN_DATA_ROOT = "div > div.bottom-container > div > cel-checkbox-item";
    public static String DROPDOWN_GRAND_CHILD = "label > span";
    public static String DROPDOWN_LIST_Root2 = "div > div.bottom-container div";
    public static String DROPDOWN_PARENT1 = "div > button > cel-icon";
    public static String DIV = "div";
    public static String LABEL = "label";
    public static String checkMarkCCSS = "checkmark-icon cel-color cel-color-disabled icon-small hydrated";

    public static String SELECT_ALL_ROOT2 = "div > div.header-container.item-container.border-bottom > cel-checkbox-item";
    public static String SELECT_ALL_ROOT3 = "label > input[type=checkbox]";
    public static String SELECT_ALL_PARTIAL_SELECT = "label > input.indeterminate";

  
    private String headerCSS = "h2.header";
    private String totalPageCountCSS = "header-pagination > div > span.pagination-text-suffix";
    public String studentNameCSS = "#table > tbody > tr  > td:nth-child(1) > div";
    private String nextBtnCSS = "cel-button.next-btn";
    private String backBtnCSS = "cel-button.back-btn";


	// Select All Checkbox inside dropdown
	private static String chbxSelectALLParentRoot = "cel-checkbox.hydrated";
	private static String chbxDropdownMS = "label.checkbox__container";
	private static String spanHeader = "span.header";
	
	public static String TEACHERS = "#teachers";
	public static String GROUPS = "#groups";
    public static String ORGANIZATIONS = "#organization > div > cel-single-select";
    public static String SUBJECT = "#subject > div > cel-single-select";
    public static String DISPLAY = "div.row.filters > single-select > div > cel-single-select";
    public static String DATE_AT_RISH = "div.row.filter > single-select:nth-child(1)";
    public static String LANGUAGE = "div.row.filter > single-select:nth-child(2)";
	
    public static List<String> SINGLE_SELECT_DROPDOWNS = new ArrayList<String>( Arrays.asList( ORGANIZATIONS, SUBJECT, DISPLAY, DATE_AT_RISH, LANGUAGE ) );
    public static List<String> SORT_DROPDOWN_VALUES = new ArrayList<>( Arrays.asList( "School", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent", "Total Sessions", "Exercises Correct", "Exercises Attempted",
	            "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );

    public static String selectAllCheckBoxColor = "#006be0";

	// label for Radio Buttons
    public String txtIncludePerformanceSummary[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(1)').shadowRoot.querySelector('span')" };
    public String txtIncludePerformanceByStrand[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(2)').shadowRoot.querySelector('span')" };
    public String txtIncludeAreasForGrowth[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(3)').shadowRoot.querySelector('span')" };
    
		// Radio buttons for student performance report -- Yes
	public String rdYesIncludePerformanceSummary[] = { "cel-accordion-item",
			"document.querySelector('cel-radio-button-group:nth-child(1)').shadowRoot.querySelector('cel-radio-button').shadowRoot.querySelector('#yes')" };
	public String rdYesIncludePerformanceByStrand[] = { "cel-accordion-item",
			"document.querySelector('cel-radio-button-group:nth-child(2)').shadowRoot.querySelector('cel-radio-button').shadowRoot.querySelector('#yes')" };
	public String rdYesIncludeAreasForGrowth[] = { "cel-accordion-item",
			"document.querySelector('cel-radio-button-group:nth-child(3)').shadowRoot.querySelector('cel-radio-button').shadowRoot.querySelector('#yes')" };
	
	
	// Radio buttons for student performance report -- No
	public String rdNoIncludePerformanceSummary[] = { "cel-accordion-item",
			"document.querySelector('cel-radio-button-group:nth-child(1)').shadowRoot.querySelector('cel-radio-button:nth-child(2)').shadowRoot.querySelector('#no')" };
	public String rdNoIncludePerformanceByStrand[] = { "cel-accordion-item",
			"document.querySelector('cel-radio-button-group:nth-child(2)').shadowRoot.querySelector('cel-radio-button:nth-child(2)').shadowRoot.querySelector('#no')" };
	public String rdNoIncludeAreasForGrowth[] = { "cel-accordion-item",
			"document.querySelector('cel-radio-button-group:nth-child(3)').shadowRoot.querySelector('cel-radio-button:nth-child(2)').shadowRoot.querySelector('#no')" };

	/* String Title Text For validations */
	public String performanceSummary = "Include Performance Summary";
	public String performanceByStrand = "Include Performance By Strand";
	public String areasForGrowth = "Include Areas For Growth";
	public String language = "Language";
	public String dateAtRisk = "Date at Risk";

	/**
	 * 
	 * Constructor class for Login page Here we initializing the driver for page
	 * factory objects.
	 * 
	 * @param driver
	 * @param url
	 */
	public StudentPerformanceReportsPages(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		reportComponents = new ReportComponents(driver);
		reportFilterComponent = new ReportFilterComponent(driver);
	}

	@Override
	protected void load() {

		isPageLoaded = true;
		SMUtils.waitForElement(driver, pageTitle);

	}

	@Override
	protected void isLoaded() throws Error {
		try {
			SMUtils.waitForSpinnertoDisapper(driver, 30);
		} catch (InterruptedException e) {
			Log.message("Issue in Spinner Loading");
		}
		if (SMUtils.waitForElement(driver, pageTitle, 30)) {
			Log.message("Student Performance Page loaded successfully.");
		} else {
			Log.fail("Student Performance Page not loaded successfully.");
		}

	}

	/**
	 * get SPR description text
	 */
	public Boolean reportDescriptionText(String descriptionText) {
		Log.message("Getting SPR Description");
		if (SPRDescriptionText.getText().equalsIgnoreCase(descriptionText)) {
			return true;

		}
		return false;
	}

	/***
	 * Checks and return Reports name Visibility
	 *
	 * @return
	 */
	public boolean isReportNameDisplayed(String reportName) throws InterruptedException {
		WebElement reportsTab = SMUtils.getWebElement(driver, topNavBarwithShadow, topNavReportsMenuCSSSelector);
		reportsTab.click();
		reportsTab.click();
		SMUtils.nap(1);// required for options load

		WebElement reportMenuItemswithShadow = SMUtils
				.getWebElements(driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow).get(1);

		List<WebElement> allReportsSubMenu = SMUtils.getWebElements(driver, reportMenuItemswithShadow,
				allReportSubMenuItemCSSSelector);

		for (WebElement reportsSubMenuItem : allReportsSubMenu) {
			if (reportsSubMenuItem.getText().equals(reportName)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Mask Student Display field validation
	 */
	public boolean isMaskStudentDisplayed(String maskStudent) {
		Log.message("Validate mask student");
		SMUtils.waitForElement(driver, lblMaskStudentDisplayTextRoot);
		WebElement maskStudentHeader = SMUtils.getWebElement(driver, lblMaskStudentDisplayTextRoot,
				lblRemoveMaskStudentDiplayText);
		if (maskStudentHeader.getText().trim().equals(maskStudent)) {

			return true;
		}
		return false;
	}

	/**
	 * Validate student dropdown heading
	 *
	 * @return
	 * @throws InterruptedException
	 */
	public boolean islabelOfperforamanceSummaryStarndAndAODHeadingPresent(String dropdownName)
			throws InterruptedException {
		boolean isHeaderPresent = false;

		for (int i = 0; i < rbHeaderforAllPerformance.size(); i++) {

			if (SMUtils.getWebElementDirect(driver, rbHeaderforAllPerformance.get(i), spanHeader).getText().trim()
					.equals(dropdownName)) {
				isHeaderPresent = true;
				break;
			}
		}
		Log.message("Verified " + dropdownName + " dropdown header");
		return isHeaderPresent;
	}
	
	
	/**
     * Return true if the Dropdown is expanded
     * 
     * @param dropdown
     * @return
     */
    public boolean isDropdownExpanded( String dropdown ) {
        SMUtils.nap( 10 );
        WebElement rootElement = null;
        WebElement lisRoot = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
        }
        Log.message( "isDropdownExpanded is " + lisRoot );
        return lisRoot != null ? true : false;
    }

    /**
     * Expand Dropdown
     * 
     * @param dropdownName
     */
    public void expanDropdown( String dropdownName ) {
        if ( !isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
            SMUtils.nap( 2 ); // wait for dropdown load

            Log.message( "Dropdown expanded: " + dropdownName );
        } else {
            Log.message( dropdownName + " Dropdown already expanded" );
        }
    }


	/**
	 * Validate heading
	 *
	 * @return
	 * @throws InterruptedException
	 */
	public boolean isMultiSelectDropdownHeadingPresent(String dropdownName) throws InterruptedException {
		boolean isHeaderPresent = false;
		for (WebElement lbldropdownHeader : lblMSDropdownHeader) {
			if (lbldropdownHeader.getText().trim().equals(dropdownName)) {
				isHeaderPresent = true;
				break;
			}
		}
		Log.message("Verified " + dropdownName + " dropdown header");
		return isHeaderPresent;
	}

	
	/**
     * To get the Dropdown Elements
     * 
     * @param dropdown
     * @return
     */
    public List<WebElement> getAllDropdownElements( String dropdown ) {
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> parent = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );

            List<WebElement> ddElements = new ArrayList<WebElement>();

            parent.stream().forEach( element -> {
                ddElements.add( element.findElement( By.cssSelector( LABEL ) ) );
            }

            );
            return ddElements;
        } else if ( dropdown.equals( ORGANIZATIONS ) ) {
            return getAllOrganizationDropdownElements();
        } else {
            final List<WebElement> streamList = new ArrayList<WebElement>();
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> dataParent = SMUtils.getWebElements( driver, parent, DROPDOWN_DATA_ROOT );
            dataParent.stream().forEach( ddElement -> {
                streamList.add( SMUtils.getWebElementDirect( driver, ddElement, DROPDOWN_GRAND_CHILD ) );
            } );
            return streamList;
        }
    }

    /**
     * Get all the Org Dropdown elements
     * 
     * @return
     */
    public List<WebElement> getAllOrganizationDropdownElements() {
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > cel-single-select-item');var labels =[]; root.forEach ( ele => { labels.push(ele.shadowRoot.querySelector('label'))}); { return labels ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }
    
	/**
	 * Run Report field validation
	 */
	public boolean isRunReportDisplayed() {
		SMUtils.waitForElement(driver, runReportBtnRoot);
		WebElement runReportBtnText = SMUtils.getWebElement(driver, runReportBtnRoot, runReportBtnchild);
		if (runReportBtnText.isDisplayed()) {
			Log.message("Run Report is displaying");
			return true;
		}
		return false;
	}

	/**
	 * Save Report Options validation
	 */
	public boolean isSaveReportDisplayed() {
		SMUtils.waitForElement(driver, saveReportBtnRoot);
		WebElement saveReportBtnText = SMUtils.getWebElement(driver, saveReportBtnRoot, saveReportoptionsBtnchild);
		if (saveReportBtnText.isDisplayed()) {
			Log.message("Save Report is displaying");
			return true;
		}
		return false;
	}

	/**
	 * Is SELECT ALLL Radio button selected
	 *
	 * @return
	 * @throws InterruptedException
	 */
	public boolean isSelectALLChecked() throws InterruptedException {
		SMUtils.nap(0.5);// This wait will required to load the page
		ReportComponents reportComponents = new ReportComponents(driver);
		reportComponents.setDropDownMS(ReportsUIConstants.ASSIGNMENTS_DROPDOWN);
		reportComponents.expandDropDownMS();
		WebElement chbxSelectAllRoot = SMUtils.getWebElement(driver, reportComponents.shadowTree,
				chbxSelectALLParentRoot);
		Log.message("Validate Select all check box selected ");
		return SMUtils.getWebElement(driver, chbxSelectAllRoot, chbxDropdownMS).isSelected();
	}

	/**
	 * Click On SPR Field to validate dropdown is closing after clicking on Anywhere
	 * on page
	 */
	public void collapseFilterButton() {
		SMUtils.clickJS(driver, SPRDescriptionText);
		Log.message("Dropdown closed successfully");
	}

	/**
	 * Click On Mask Student
	 */
	public void clickMaskStudentCB() {

		WebElement maskStudentCheckBox = SMUtils.getWebElementDirect(driver, lblMaskStudentDisplayTextRoot,
				maskStudentcheckbox);
		SMUtils.scrollIntoView(driver, maskStudentCheckBox);
		SMUtils.clickJS(driver, maskStudentCheckBox);
		Log.message("Mask Student selected successfully");
	}

	/**
	 * Mask Student
	 *
	 */
	public Boolean isMaskStudentSelected() {

		WebElement maskStudentCheckBox = SMUtils.getWebElement(driver, lblMaskStudentDisplayTextRoot,
				maskStudentcheckbox);
		Log.message("Validate Mask Student is selected");
		return maskStudentCheckBox.isSelected();
	}

	
	


	
	/**
	 * @author aravindan.srinivas Validate Drop Down Date At Risk & Its Text
	 * @throws InterruptedException
	 */
	public void validatedrpDwnDateAtRisk(WebDriver driver) throws InterruptedException {
		WebElement drpDwnDateAtRisk = ShadowDOMUtils.retryAndGetWebElement(driver, this.drpDwnDateAtRisk[0],
				this.drpDwnDateAtRisk[1]);
		ReportsBrowserActions.verifyElementTextIsDisplayed(driver, txtDateAtRisk, dateAtRisk, "Text : Date at Risk");
		ReportsBrowserActions.verifyElementIsDisplayed(driver, drpDwnDateAtRisk, "Date At Risk Drop Down Field");

	}

	/**
	 * @author aravindan.srinivas Validate Drop Down Language & Its Text
	 * @throws InterruptedException
	 */
	public void validatedrpDwnLanguage(WebDriver driver) throws InterruptedException {
		WebElement drpDwnLanguage = ShadowDOMUtils.retryAndGetWebElement(driver, this.drpDwnLanguage[0],
				this.drpDwnLanguage[1]);
		ReportsBrowserActions.verifyElementTextIsDisplayed(driver, txtLanguage, language, "Text : Language");
		ReportsBrowserActions.verifyElementIsDisplayed(driver, drpDwnLanguage, "Language Drop Down Field");

	}

	/**
	 * @author sakthi.sasi Used to verify the Groups in UI matches the Group fetched
	 *         from RBS
	 * 
	 * @param driver
	 * @return
	 * @throws Exception
	 */
	public StudentPerformanceReportsPages verifyGroup(WebDriver driver) throws Exception {
		ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);
		List<String> expgroupNames = new ArrayList<String>();
		expgroupNames = reportsFilterUtils.getGroupListNames(reportsFilterUtils.getTeacherGroupIds());
		List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getTeacherGroupNames();
		Collections.sort(expgroupNames);
		Collections.sort(allValuesFromGroupsDropdown);
		Log.softAssertThat(expgroupNames.containsAll(allValuesFromGroupsDropdown), "All the Groups is Present",
				"The groups is not matched" + expgroupNames.toString() + "Actual :"
						+ allValuesFromGroupsDropdown.toString());
		return this;
	}

	
	
	/**
     * Select the options in the Dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void selectOptionsFromDropdown( String dropdownName, List<String> options ) {
        List<WebElement> elements = getAllDropdownElements( dropdownName );
        if ( elements.size() > 0 ) {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                WebElement option = elements.stream().filter( element -> options.contains( element.getText().trim() ) ).findFirst().orElse( null );
                SMUtils.scrollDownIntoViewElement( driver, option );
                String optionName = option.getText().trim();
                Log.message( "Found option is " + optionName );
                SMUtils.click( driver, option );
                Log.message( optionName + " is ticked" );
            } else {
                elements.stream().filter( element -> options.contains( element.getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollDownIntoViewElement( driver, element );
                    SMUtils.click( driver, element );
                    Log.message( element.getText().trim() + " is ticked" );
                } );
            }

        } else {
            Log.message( "Issue in Selecting values for " + dropdownName );
        }
    }
	
    
    /***
     * It will opend and the Tick the Values in the Dropdown With options and
     * close the dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void setValuesForDropdown( String dropdownName, List<String> options ) {
        expanDropdown( dropdownName );
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            selectOptionsFromDropdown( dropdownName, options );
        } else {
            unSelectAll( dropdownName );
            selectOptionsFromDropdown( dropdownName, options );
            closeDropdown( dropdownName );
        }
        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }
    }
    
    /**
     * Wait for the spinner to Load and Wait for disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, Duration.ofSeconds( 60 ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }
    
    /**
     * Close dropdown Element
     * 
     * @param dropdownName
     */
    public void closeDropdown( String dropdownName ) {
        if ( isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
        } else {
            Log.message( dropdownName + " Dropdown already closed" );
        }
    }
    
    /**
     * Unselect All options in Dropdown
     * 
     * @param dropdownName
     */
    public void unSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        }
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
        if ( verifySelectAllCheckBoxColor( dropdownName ) ) {
            SMUtils.click( driver, element );
        } else {
            SMUtils.click( driver, element );
            SMUtils.click( driver, element );
        }
        Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
        closeDropdown( dropdownName );
    }
    
    
    /**
     * Return true if the checkBox is selected
     * 
     * @param dropdownName
     * @return
     */
    public boolean verifySelectAllCheckBoxColor( String dropdownName ) {
        WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_ROOT3 );
        String color = Color.fromString( element.getCssValue( "background-color" ) ).asHex();
        return ( color.equals( selectAllCheckBoxColor ) ) ? true : false;
    }
    
	public boolean chooseSubject(WebDriver driver, String subjectName) {
		ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);
//        SMUtils.waitForElement( driver, txtStudentPerformanceReportHeader );
		reportsFilterUtils.selectOptionFromSingleSelectDropDown("subject", subjectName);
		return true;
	}

	/**
	 * @author aravindan.srinivas Validate Include Performance Summary Element &
	 *         Text
	 * @throws InterruptedException
	 */
	public void validateTxtIncludePerformanceSummary(WebDriver driver) throws InterruptedException {
		WebElement txtIncludePerformanceSummary = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.txtIncludePerformanceSummary[0], this.txtIncludePerformanceSummary[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, txtIncludePerformanceSummary,
				"Include Performance Summary Element");
		ReportsBrowserActions.verifyElementTextIsDisplayed(driver, txtIncludePerformanceSummary, performanceSummary,
				"Text : Include Performance Summary");
	}

	/**
	 * @author aravindan.srinivas Validate Include Performance By Strand Element &
	 *         Text
	 * @throws InterruptedException
	 */
	public void validateTxtIncludePerformanceByStrand(WebDriver driver) throws InterruptedException {
		WebElement txtIncludePerformanceByStrand = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.txtIncludePerformanceByStrand[0], this.txtIncludePerformanceByStrand[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, txtIncludePerformanceByStrand,
				"Include Performance By Strand Element");
		ReportsBrowserActions.verifyElementTextIsDisplayed(driver, txtIncludePerformanceByStrand, performanceByStrand,
				"Text : Include Performance By Strand");
	}

	/**
	 * @author aravindan.srinivas Validate Include AreasForGrowth Element & Text
	 * @throws InterruptedException
	 */
	public void validateTxtIncludeAreasForGrowth(WebDriver driver) throws InterruptedException {
		WebElement txtIncludeAreasForGrowth = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.txtIncludeAreasForGrowth[0], this.txtIncludeAreasForGrowth[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, txtIncludeAreasForGrowth,
				"Include AreasForGrowth Element");
		ReportsBrowserActions.verifyElementTextIsDisplayed(driver, txtIncludeAreasForGrowth, areasForGrowth,
				"Text : Include AreasForGrowth");
	}

	/**
	 * @author aravindan.srinivas Validate Radio Button No IncludePerformanceSummary
	 * @throws InterruptedException
	 */
	public void validateRdNoIncludePerformanceSummary(WebDriver driver) throws InterruptedException {
		WebElement rdNoIncludePerformanceSummary = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.rdNoIncludePerformanceSummary[0], this.rdNoIncludePerformanceSummary[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, rdNoIncludePerformanceSummary,
				"Include Performance Summary Radio Button -> No");
	}

	/**
	 * @author aravindan.srinivas Validate Radio Button No Include Performance By
	 *         Strand
	 * @throws InterruptedException
	 */
	public void validateRdNoIncludePerformanceByStrand(WebDriver driver) throws InterruptedException {
		WebElement rdNoIncludePerformanceByStrand = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.rdNoIncludePerformanceByStrand[0], this.rdNoIncludePerformanceByStrand[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, rdNoIncludePerformanceByStrand,
				"Include Performance By Strand Radio Button -> No ");
	}

	/**
	 * @author aravindan.srinivas Validate Radio Button No Include AreasForGrowth
	 * @throws InterruptedException
	 */
	public void validateRdNoIncludeAreasForGrowth(WebDriver driver) throws InterruptedException {
		WebElement rdNoIncludeAreasForGrowth = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.rdNoIncludeAreasForGrowth[0], this.rdNoIncludeAreasForGrowth[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, rdNoIncludeAreasForGrowth,
				"Include AreasForGrowth Radio Button -> No");
	}

	/**
	 * @author aravindan.srinivas Validate Radio Button Yes
	 *         IncludePerformanceSummary
	 * @throws InterruptedException
	 */
	public boolean validateRdYesIncludePerformanceSummary(WebDriver driver) throws InterruptedException {
		WebElement rdYesIncludePerformanceSummary = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.rdYesIncludePerformanceSummary[0], this.rdYesIncludePerformanceSummary[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, rdYesIncludePerformanceSummary,
				"Include Performance Summary Radio Button -> Yes");
		return true;
	}

	/**
	 * @author aravindan.srinivas Validate Radio Button Yes Include Performance By
	 *         Strand Element
	 * @throws InterruptedException
	 */
	public boolean validateRdYesIncludePerformanceByStrand(WebDriver driver) throws InterruptedException {
		WebElement rdYesIncludePerformanceByStrand = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.rdYesIncludePerformanceByStrand[0], this.rdYesIncludePerformanceByStrand[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, rdYesIncludePerformanceByStrand,
				"Include Performance By Strand Radio Button -> Yes ");
		return true;
	}

	/**
	 * @author aravindan.srinivas Validate Radio Button Yes Include AreasForGrowth
	 * @throws InterruptedException
	 */
	public boolean validateRdYesIncludeAreasForGrowth(WebDriver driver) throws InterruptedException {
		WebElement rdYesIncludeAreasForGrowth = ShadowDOMUtils.retryAndGetWebElement(driver,
				this.rdYesIncludeAreasForGrowth[0], this.rdYesIncludeAreasForGrowth[1]);
		ReportsBrowserActions.verifyElementIsDisplayed(driver, rdYesIncludeAreasForGrowth,
				"Include AreasForGrowth Radio Button -> Yes");
		return true;
	}

	/**
     * return true if check box is checked For MaskStudentDisplay
     * 
     * @return
     */
    public boolean isMaskStudentisChecked() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        try {
            if ( SMUtils.checkBackgroundColor( element, selectAllCheckBoxColor ) ) {
                return true;
            } else {
                return false;
            }
        } catch ( Exception e ) {
            return false;
        }
    }
	
    
    public boolean isMaskStudent() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        JavascriptExecutor jse =(JavascriptExecutor)driver;
        WebElement textBox = (WebElement)jse.executeScript("return document.querySelector('cel-checkbox-item').shadowRoot.querySelector('label > input')" );
        textBox.click();
        Log.message("Mask Student checkbox is clicked");
        return true;
    }
    
    /**
     * click checkbox Mask Student CheckBox
     */
    public void clickMaskStudentCheckBox() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }

    public String noDataDisplayed() {
    	Log.message("The report is loading...");
    	SMUtils.waitForElement(driver, noDataText, 5);
    	String element = SMUtils.getTextOfWebElement(noDataText, driver).trim();
    	
    	Log.message("The report has "+ element);
    	return element;
    }
   
    public List<String> getStrandDataFromUi(WebDriver driver) {
		List<String> dataUI = new ArrayList<>();
		for (WebElement webElement : performanceStrand) {
			dataUI.add(webElement.getText().trim().replace(" ", ""));
		}
		return dataUI;
	}
}
