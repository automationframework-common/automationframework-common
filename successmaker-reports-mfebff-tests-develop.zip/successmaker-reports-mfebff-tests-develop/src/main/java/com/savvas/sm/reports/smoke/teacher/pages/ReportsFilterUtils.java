package com.savvas.sm.reports.smoke.teacher.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class ReportsFilterUtils extends LoadableComponent<ReportsFilterUtils> {

    WebDriver driver;
    public ElementLayer elementLayer;
    private boolean isPageLoaded;
    Select select;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    public ReportsFilterUtils( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtReportsHeading ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    @IFindBy ( how = How.CSS, using = "h1.report-heading.d-inline-block", AI = false )
    public WebElement txtReportsHeading;

    @IFindBy ( how = How.CSS, using = "p.description", AI = false )
    public WebElement txtPageHeaderDescription;

    @IFindBy ( how = How.CSS, using = "label[for='savedReportOptions']", AI = false )
    public WebElement txtSavedReportOptionsHeader;

    @IFindBy ( how = How.ID, using = "savedReportOptions", AI = false )
    public WebElement drpDownSavedReportOptions;

    @IFindBy ( how = How.CSS, using = "organizations-filter>label.section-main-title.text-uppercase.d-block", AI = false )
    public WebElement txtOrganizationsHeader;

    @IFindBy ( how = How.CSS, using = "div.section-main-title.mt-3.text-uppercase", AI = false )
    public WebElement txtCourseSelectionHeader;

    @IFindBy ( how = How.XPATH, using = "//label[@for='courses']", AI = false )
    public WebElement txtCoursesDropDownHeader;

    @IFindBy ( how = How.CSS, using = "label[for*='subject']", AI = false )
    public WebElement txtSubjectDropDownHeader;

    @IFindBy ( how = How.XPATH, using = " //h2[text()='Select students by']", AI = false )
    public WebElement txtSelectStudentBy;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Teacher']", AI = false )
    public WebElement txtTeacherLabel;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Grade']", AI = false )
    public WebElement txtGradeLabel;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Group']", AI = false )
    public WebElement txtGroupLabel;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Additional Grouping']", AI = false )
    public WebElement txtAdditionalGroupingLabel;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Display']", AI = false )
    public WebElement txtDisplayLabel;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Sort']", AI = false )
    public WebElement txtSortLabel;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Dates at risk']", AI = false )
    public WebElement txtDatesAtRiskLabel;

    @IFindBy ( how = How.CSS, using = "div.spinner-container", AI = false )
    public WebElement Spinner;

    //teacher - webElements
    @IFindBy ( how = How.CSS, using = "input[value='students']", AI = false )
    public WebElement rdBtnStudent;

    @IFindBy ( how = How.CSS, using = "label[for='radioGroups']", AI = false )
    public WebElement txtGroups;

    @IFindBy ( how = How.CSS, using = "label[for='radioStudents']", AI = false )
    public WebElement txtStudents;

    @IFindBy ( how = How.CSS, using = "label[for='assignments']", AI = false )
    public WebElement txtAssignments;

    @IFindBy ( how = How.XPATH, using = "//label[text()=' Groups and Students ']", AI = false )
    public WebElement txtGroupsAndStudents;

    @IFindBy ( how = How.CSS, using = "p.description", AI = false )
    public WebElement txtReportDescription;

    @FindBy ( css = "div.groups-students-wrapper div[class='col-sm-6 groups-students-option'] div.row" )
    List<WebElement> rbGroupAndStudentDropdownParent;

    @IFindBy ( how = How.CSS, using = "multi-select[formcontrolname='assignments']", AI = false )
    public WebElement shadowRootAssignmentsDropdown;

    @FindBy ( css = "label.radio-label" )
    List<WebElement> lblGroupAndStudentsDropdown;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String icnReportsHeaderHelpshadowDOM[] = { "cel-icon.contextual-help-icon.cel-color.cel-color-black.icon-small.hydrated",
            "document.querySelector(\"cel-icon.contextual-help-icon.cel-color.cel-color-black.icon-small.hydrated\").shadowRoot.querySelector(\"div > svg > path\")" };
    // SAVED REPORT OPTIONS
    public String drpdwnSavedReportOptionshadowDOM[] = { "cel-single-select", "document.querySelector('#savedReportOptions').shadowRoot.querySelector('div > div')" };
    // COURSE SELECTION
    public String drpdwnSubjectshadowDOM[] = { "#subject > div > cel-single-select", "document.querySelector(\"#subject > div > cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };
    public String drpdwnCoursesshadowDOM[] = { "#courses > cel-multi-select", "document.querySelector('#courses > cel-multi-select').shadowRoot.querySelector('div > div > button')" };
    public String txtOptionalFiltershadowDOM[] = { "cel-accordion-item", "document.querySelector('cel-accordion-item').shadowRoot.querySelector('#cel-accordionBtn-2 span')" };

    // Elements Below select student by
    public String drpDwnTeachersshadowDOM[] = { "cel-accordion-item", "document.querySelector('#teachers > cel-multi-select').shadowRoot.querySelector('button')" };
    public String drpDwnGradesshadowDOM[] = { "cel-accordion-item", "document.querySelector('#grades > cel-multi-select').shadowRoot.querySelector('div > div > button > span')" };
    public String drpDwnGroupshadowDOM[] = { "cel-accordion-item", "document.querySelector('#groups > cel-multi-select').shadowRoot.querySelector('div > div > button > span')" };
    public String drpDwnAdditionalGroupingshadowDOM[] = { "cel-single-select", "document.querySelector('#additional-grouping').shadowRoot.querySelector('#dropdown')" };
    public String drpDwnDisplayshadowDOM[] = { "cel-single-select", "document.querySelector('#display').shadowRoot.querySelector('#dropdown')" };
    public String chkMaskStudentDisplayshadowDOM[] = { "cel-accordion-item", "document.querySelector('cel-checkbox-item').shadowRoot.querySelector('input[type=checkbox]')" };
    public String drpDwnSortshadowDOM[] = { "cel-accordion-item", "document.querySelector('#sort').shadowRoot.querySelector('#dropdown')" };
    public String drpDwnsubjectAllCoursesShadowDOM[] = { "cel-accordion-item", "document.querySelector('#subjectAllCourses cel-single-select').shadowRoot.querySelector('#dropdown')" };

    // Saved Report Configuration
    public String btnSavedReportOptionsShadowDOM[] = { "cel-modal.save-report-modal.hydrated",
            "document.querySelector('cel-modal.save-report-modal.hydrated').shadowRoot.querySelector('cel-button').shadowRoot.querySelector('button[aria-disabled=\"false\"]')" };
    public String fldCustomReportConfigurationNameShadowDOM[] = { "cel-text-field.hydrated", "document.querySelector('cel-text-field.hydrated').shadowRoot.querySelector('div label input#textField')" };
    public String txtErrorCustomReportConfigurationNameShadowDOM[] = { "cel-text-field.hydrated", "document.querySelector('cel-text-field.hydrated').shadowRoot.querySelector('div label div')" };
    public String btnSaveFroCustomReportConfigurationShadowDOM[] = { "cel-modal.save-report-modal.hydrated",
            "document.querySelector('cel-modal.save-report-modal.hydrated').shadowRoot.querySelector('div>div>div.footer-container.row-end>div>cel-button.ok-button.hydrated').shadowRoot.querySelector('button')" };
    public String btnEnabledRunReportShadowDOM[] = { "cel-button", "document.querySelector('cel-button').shadowRoot.querySelector('button')" };

    // Teacher - Shadow DOM Elements
    public String drpdwnGroupShadowDOM[] = { "multi-select", "document.querySelector('multi-select[formcontrolname=\"groups\"] > cel-multi-select').shadowRoot.querySelector('button[aria-expanded=\"false\"]')" };
    public String drpdwnStudentShadowDOM[] = { "multi-select", "document.querySelector('multi-select[formcontrolname=\"students\"] > cel-multi-select').shadowRoot.querySelector('button[aria-expanded=\"false\"]')" };
    public String drpdwnAssignmentShadowDOM[] = { "cel-multi-select", "document.querySelector('#assignments > cel-multi-select').shadowRoot.querySelector('button')" };
    public String drpdwnStudentSelectAllShadowDOM[] = { "cel-multi-select",
            "document.querySelector('div:nth-child(2)> div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };
    public String drpdwnGroupSelectAllShadowDOM[] = { "cel-multi-select",
            "document.querySelector('div:nth-child(1) > div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };
    public String drpdwnAssignmentSelectAllShadowDOM[] = { "cel-multi-select",
            "document.querySelector('#assignments cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };
    /* Element text */
    public String txtDatesAtrisk = "Dates at risk";
    public String txtSortInAdditionalGrouping = "Sort";
    public String txtDisplay = "Display";
    public String txtAdditionalGrouping = "Additional Grouping";
    public String txtGroup = "Group";
    public String txtGrade = "Grade";
    public String txtTeacher = "Teacher";
    public String txtSelectStudentsBy = "SELECT STUDENTS BY";
    public String txtSubject = "Subject";
    public String txtCourses = "Course(s)";
    public String txtCourseSelection = "COURSE SELECTION";
    public String txtOrganizations = "ORGANIZATIONS";
    public String txtSavedReportOptions = "SAVED REPORT OPTIONS";
    public String txtPageHeaderDescriptionHeader = "The Areas For Growth (AFG) Report lists the Math and Reading skills with which the selected students are having difficulty. The report groups students by these skills to allow teachers to determine which students require assistance and/or intervention.";
    public String txtStudentDemographics = "Student Demographics";
    public String txtOptionalFilters = "Optional Filters";
    public String txtAdditionalGroupingDrpdwn = "NONE";
    public String txtGroupDrpdwn = "STUDENT_NAME";
    public String txtSortDrpdwn = "STRAND";
    public String txtSortStudentValueDrpdwn = "STUDENT";
    public String txtDatesAtRiskDrpdwn = "SINCE_IP";
    public String txtSubjectAllCourses = "Subject (all courses)";
    //Teacher - text
    public String txtGroupsHeader = "Groups";
    public String txtStudentsHeader = "Students";
    public String txtAssignmentsHeader = "Assignments";
    public static String groupAndStudent = " GROUPS AND STUDENTS ";
    /* SM methods */
    public WebElement shadowTree = null;
    String rbGroupAndStudentDropdown = "cel-radio-button input[type='radio']";
    String txtGroupAndStudentDropdown = "div.d-block label";
    String expandMsDropdown = "button[id='multiselect-btn']";
    String shadowRootSelectDropDownMS = ".multi-check-dropdown-container .dropdown-list .dropdown-scroll .dropdown-list-items .dropdown-single-select cel-checkbox";// List<WebElement>
    String txtDropDownMSValue = ".primary__checkbox span";
    String shadowRootGroupAndStudentsDropdown = "cel-multi-check-dropdown.hydrated";
    String valuesFromMSDropdown = ".checkbox__label";

    public static String DROPDOWN_GRADNPARENT = "%s > cel-multi-select";
    public static String DROPDOWN_LIST_Root1 = "div > div > div > cel-multi-checkbox";  //"#dropdown > cel-multi-checkbox.multi-checkbox.hydrated";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1 = "#dropdown > cel-single-select-item";
    public static String DROPDOWN_DATA_ROOT = "div > div.bottom-container > div > cel-checkbox-item";
    public static String DROPDOWN_GRAND_CHILD = "label > span";
    public static String DROPDOWN_LIST_Root2 = "div > div.bottom-container div";
    public static String DROPDOWN_PARENT1 = "div button cel-icon";
    public static String DIV = "div";
    public static String LABEL = "label";
    public static String DROPDOWN_LIST_CheckBox = "div > div.bottom-container div cel-checkbox-item";
    public static String TEACHERS = "#teachers";
    public static String GROUPS = "#groups";
    public static String GRADES = "#grades";
    public static String COURSES = "#courses";
    public static String ASSIGNMENTS = "#assignments";
    public static String Teacher_Students = "multi-select[formcontrolname='students']";
    public static String Teacher_Groups = "multi-select[formcontrolname='groups']";

    public static String ORGANIZATIONS = "#organization > div > cel-single-select";
    public static String SUBJECT = "#subject > div > cel-single-select";
    public static String ADDITIONAL_GROUPING = "#additional-grouping";
    public static String DISPLAY = "#display";
    public static String SORT = "#sort";

    public static String SELECT_ALL_ROOT2 = "div > div.header-container.item-container.border-bottom > cel-checkbox-item";
    public static String SELECT_ALL_ROOT3 = "label > input[type=checkbox]";
    public static String SELECT_ALL_PARTIAL_SELECT = "label > input.indeterminate";
    public static String selectAllCheckBoxColor = "#006be0";

    List<String> listAFGExpectedColumnList = new ArrayList<String>( Arrays.asList( "Strand", "Level", "Skill Description", "", "", "Student", "Date at Risk", "Targeted Lesson" ) );
    List<String> listCPRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Level Data", "Usage", "Instructional Performance", "Mastery", "", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent",
            "Total Sessions\nminimum of 1 assignment", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );
    List<String> listCPRAggregateExpectedColumnList = new ArrayList<String>( Arrays.asList( "School\n(Grade - # of Students)", "Level Data\nMean", "Usage\nMean", "Instructional Performance\nMean", "Mastery\nMean", "", "Current Course Level", "IP Level",
            "Gain", "Time Spent", "Total Sessions\nminimum of 1 assignment", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "Percent Students with AP" ) );
    List<String> listLSRAggregateExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Level", "Raw Performance", "Usage", "", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Help Used",
            "Time Spent", "Total Sessions\nminimum of 1 assignment", "Session Date" ) );

    public static List<String> SINGLE_SELECT_DROPDOWNS = new ArrayList<String>( Arrays.asList( ORGANIZATIONS, SUBJECT, ADDITIONAL_GROUPING, DISPLAY, SORT ) );

    /**
     * @author raseem.mohamed
     * @param driver
     * @param element
     * @param optionTextToSelect
     * @param description
     */
    public void selectOptionFromSingleSelectDropDownUsingSelect( WebDriver driver, WebElement element, String optionTextToSelect, String description ) {
        select = new Select( element );
        try {
            if ( !select.isMultiple() ) {
                Log.message( description + " Is Single Select Drop Down" );
                List<WebElement> options = select.getOptions();
                for ( WebElement allOptions : options ) {
                    String option = allOptions.getText();
                    if ( option.equals( optionTextToSelect ) ) {
                        select.selectByVisibleText( optionTextToSelect );
                        Log.message( "'" + optionTextToSelect + "' Is Selected On " + description + " Successfully" );
                    }
                }
            }
        } catch ( Exception e ) {
            Log.message( "Unable To Select Option : " + optionTextToSelect );
            e.printStackTrace();
        }
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param element
     * @param optionTextToSelect
     * @param description- Verify course Drop Down is Enabled
     */
    public void verifyCourseDropDownIsEnabled( WebDriver driver, WebElement dropDownElement ) {
        try {
            String classValue = dropDownElement.getAttribute( "class" );
            Log.assertThat( !classValue.contains( "disabled" ), "Drop Down Is Not In Disabled Status", "Drop Down Is In Disabled Status" );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /* Multi-select Works For Only Select Class */
    /**
     * @author raseem.mohamed
     * @param driver
     * @param element
     * @param optionsTextToSelect
     * @param description
     */
    public void selectOptionFromMultiSelectDropDownUsingSelect( WebDriver driver, WebElement element, List<String> optionsTextToSelect, String description ) {
        select = new Select( element );
        try {
            if ( select.isMultiple() ) {
                Log.message( description + " Is Multi Select Drop Down" );
                List<WebElement> options = select.getOptions();
                for ( int i = 0; i < optionsTextToSelect.size(); i++ ) {
                    for ( WebElement allOptions : options ) {
                        String option = allOptions.getText();
                        if ( option.equals( optionsTextToSelect.get( i ) ) ) {
                            select.selectByVisibleText( optionsTextToSelect.get( i ) );
                            Log.message( "'" + optionsTextToSelect + "' Is Selected On " + description + " Successfully" );
                        }
                    }

                }
            }
        } catch ( Exception e ) {
            Log.message( "Unable To Select Option : " + optionsTextToSelect );
            e.printStackTrace();
        }
    }

    /**
     * @author raseem.mohamed
     * @param driver, WebElement
     * @param description- Scroll to Respective Option
     */
    public static void scrollToRespectiveOption( WebDriver driver, WebElement element ) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript( "arguments[0].scrollIntoView(true);", element );
    }

    /**
     * @author sathish.suresh
     * @param dropDownName
     * @param valuesList
     * @return boolean
     * @throws InterruptedException
     */
    public boolean selectOptionFromMultiSelectDropDown( WebDriver driver, String dropDownName, List<String> valuesList ) throws InterruptedException {
        boolean status = false;
        if ( valuesList.size() > 0 ) {
            String[] fldDrpDwnshadowDOM = { "cel-multi-select", "document.querySelector('#" + dropDownName + " cel-multi-select').shadowRoot.querySelector('button')" };
            WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, fldDrpDwnshadowDOM[0], fldDrpDwnshadowDOM[1] );
            if ( drpdwnElement == null ) {
                drpdwnElement = ShadowDOMUtils.retryAndGetWebElement( driver, fldDrpDwnshadowDOM[0], fldDrpDwnshadowDOM[1] );
            }
            SMUtils.click( driver, drpdwnElement );
            for ( int j = 0; j < valuesList.size(); j++ ) {
                status = false;
                int count = 1;
                if ( !valuesList.get( j ).contains( "Select All" ) ) {
                    while ( !status ) {
                        for ( int i = 1; i <= count; i++ ) {
                            String[] fldDrpDwnValueshadowDOM = { "cel-multi-select", "document.querySelector('#" + dropDownName
                                    + " cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div div.bottom-container div:nth-child(" + i + ") > cel-checkbox-item').shadowRoot.querySelector('label span')" };
                            WebElement webElement = ShadowDOMUtils.retryAndGetWebElement( driver, fldDrpDwnValueshadowDOM[0], fldDrpDwnValueshadowDOM[1] );
                            if ( webElement.getText().equals( valuesList.get( j ) ) ) {
                                String[] checkBoxshadowDOM = { "cel-multi-select",
                                        "document.querySelector('#" + dropDownName + " cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.bottom-container div:nth-child(" + i
                                                + ") > cel-checkbox-item').shadowRoot.querySelector('label input[aria-checked=\"false\"]')" };
                                WebElement checkBox = ShadowDOMUtils.retryAndGetWebElement( driver, checkBoxshadowDOM[0], checkBoxshadowDOM[1] );
                                SMUtils.click( driver, checkBox );
                                status = true;
                                break;
                            } else {
                                count++;
                            }
                        }
                    }
                } else {
                    String[] checkBoxValueShadowDom = { "cel-multi-select", "document.querySelector('#" + dropDownName
                            + " cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container.item-container.border-bottom cel-checkbox-item').shadowRoot.querySelector('label > span')" };
                    WebElement webElement = ShadowDOMUtils.retryAndGetWebElement( driver, checkBoxValueShadowDom[0], checkBoxValueShadowDom[1] );
                    if ( webElement.getText().equals( valuesList.get( j ) ) ) {
                        String[] checkBoxShadowDom = { "cel-multi-select", "document.querySelector('#" + dropDownName
                                + " cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container.item-container.border-bottom cel-checkbox-item').shadowRoot.querySelector('label input[aria-checked=\"false\"]')" };
                        WebElement checkboxElement = ShadowDOMUtils.retryAndGetWebElement( driver, checkBoxShadowDom[0], checkBoxShadowDom[1] );
                        SMUtils.click( driver, checkboxElement );
                        status = true;
                    }
                }
                Log.softAssertThat( status, "'" + valuesList.get( j ) + "' Is Selected On " + dropDownName + " field Successfully", "Failed to Select' " + valuesList.get( j ) + "' On " + dropDownName + " field" );
            }
            SMUtils.click( driver, drpdwnElement );
        } else {
            Log.fail( dropDownName + " dropdown values list is empty!" );
        }
        return status;
    }

    /**
     * @author sathish.suresh
     * @param dropDownName
     * @param drpdwnValue
     * @return
     */
    public boolean selectOptionFromSingleSelectDropDown( String dropDownName, String drpdwnValue ) {
        String[] fldDrpDwnshadowDOM = { "cel-single-select", "document.querySelector('#" + dropDownName + " cel-single-select').shadowRoot.querySelector('#dropdown')" };
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, fldDrpDwnshadowDOM[0], fldDrpDwnshadowDOM[1] );
        SMUtils.click( driver, drpdwnElement );
        boolean value = false;
        int count = 1;
        while ( !value ) {

            for ( int i = 1; i <= count; i++ ) {
                String[] OrganizationValuesDrpDwnshadowDOM = { "cel-single-select", "document.querySelector('#" + dropDownName + " cel-single-select').shadowRoot.querySelector('#dropdown > option:nth-child(" + i + ")')" };
                WebElement webElement = ShadowDOMUtils.getWebElement( driver, OrganizationValuesDrpDwnshadowDOM[0], OrganizationValuesDrpDwnshadowDOM[1] );
                if ( webElement.getText().equals( drpdwnValue ) ) {
                    SMUtils.click( driver, webElement );
                    value = true;
                    break;
                } else {
                    count++;
                }
            }
        }
        return value;
    }

    /**
     * @author raseem.mohamed
     * @param driver
     */
    public void clickSavedReportOptionsButton( WebDriver driver ) {
        try {
            WebElement btnSavedReportOptions = ShadowDOMUtils.getWebElement( driver, btnSavedReportOptionsShadowDOM[0], btnSavedReportOptionsShadowDOM[1] );
            SMUtils.click( driver, btnSavedReportOptions );
            Log.message( "User Clicked On Saved Report Options Button " );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param ValueToEnter
     */
    public void EnterCustomReportConfigurationName( WebDriver driver, String ValueToEnter ) {
        try {
            WebElement customReportConfigurationNameShadowDOM = ShadowDOMUtils.getWebElement( driver, fldCustomReportConfigurationNameShadowDOM[0], fldCustomReportConfigurationNameShadowDOM[1] );
            SMUtils.enterValue( customReportConfigurationNameShadowDOM, ValueToEnter );
            String attribute = customReportConfigurationNameShadowDOM.getAttribute( "class" );
            if ( attribute.contains( "error" ) ) {
                Log.softAssertThat( false, "User Enter the Name In Custom Report Configuration Text Box", "Failed : Unable To Enter the Name In Custom Report Configuration Text Box" );
                WebElement webElement = ShadowDOMUtils.getWebElement( driver, txtErrorCustomReportConfigurationNameShadowDOM[0], txtErrorCustomReportConfigurationNameShadowDOM[1] );
                System.out.println( "Error Message : " + webElement.getText() );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * @author raseem.mohamed
     * @param driver
     */
    public void clickSaveButtonForCustomReportConfiguration( WebDriver driver ) {
        try {
            WebElement btnSaveFroCustomReportConfiguration = ShadowDOMUtils.getWebElement( driver, btnSaveFroCustomReportConfigurationShadowDOM[0], btnSaveFroCustomReportConfigurationShadowDOM[1] );
            SMUtils.click( driver, btnSaveFroCustomReportConfiguration );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param savedReportsName
     * @throws InterruptedException
     */
    public boolean verifySavedReportOptionRetains( WebDriver driver, String savedReportsName ) throws InterruptedException {
        String drpdwnSavedReportOptionshadowDOMs[] = { "cel-single-select", "document.querySelector('#savedReportOptions').shadowRoot.querySelector('#dropdown')" };
        WebElement drpdwnSavedReportOption = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnSavedReportOptionshadowDOMs[0], drpdwnSavedReportOptionshadowDOMs[1] );
        SMUtils.scrollDownIntoViewElement( driver, drpdwnSavedReportOption );
        Log.message( "Clicked On Saved Report Option Drop Down", driver );
        boolean status = false;
        int verify = 1;
        SMUtils.nap( 5 );
        while ( !status ) {
            for ( int i = 1; i <= verify; i++ ) {
                String drpDownSavedReportAllOptions[] = { "cel-single-select", "document.querySelector('#savedReportOptions').shadowRoot.querySelector('#dropdown option:nth-child(" + i + ")')" };
                WebElement retryAndGetWebElement = ShadowDOMUtils.retryAndGetWebElement( driver, drpDownSavedReportAllOptions[0], drpDownSavedReportAllOptions[1] );
                if ( retryAndGetWebElement.getText().equals( savedReportsName ) ) {
                    Log.message( "'" + savedReportsName + "' Option is present/retained in the Saved Report Options Drop Down" );
                    status = true;
                    break;
                } else {
                    verify++;
                }
            }
        }
        // Close The Saved Report Options Drop Down
        SMUtils.click( driver, drpDownSavedReportOptions );
        return status;
    }

    /**
     * @author aravindan.srinivas verify the text Dates At Risk Status is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextDatesAtRisk( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtDatesAtRiskLabel, "Dates At Risk" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtDatesAtRiskLabel, txtDatesAtrisk, "Dates At Risk" );
    }

    /**
     * @author aravindan.srinivas verify the text Sort in Additional grouping is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSortInAdditionalGrouping( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSortLabel, "Sort In Additional Grouping" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSortLabel, txtSortInAdditionalGrouping, "Sort In Additional Grouping" );
    }

    /**
     * @author aravindan.srinivas verify the text Display is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyTextDisplay( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtDisplayLabel, "Display" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtDisplayLabel, txtDisplay, "Display" );
    }

    /**
     * @author aravindan.srinivas verify the text Additional Grouping is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextAdditionalGrouping( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtAdditionalGroupingLabel, "Additional Grouping" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtAdditionalGroupingLabel, txtAdditionalGrouping, "Additional Grouping" );
    }

    /**
     * @author aravindan.srinivas verify the text Group is Displayed in the web
     *         page.
     * @param driver
     */
    public void verifyTextGroup( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtGroupLabel, "Group" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtGroupLabel, txtGroup, "Group" );
    }

    /**
     * @author aravindan.srinivas verify the text Grade is Displayed in the web
     *         page.
     * @param driver
     */
    public void verifyTextGrade( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtGradeLabel, "Grade" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtGradeLabel, txtGrade, "Grade" );
    }

    /**
     * @author aravindan.srinivas verify the text Teacher is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyTextTeacher( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtTeacherLabel, "Teacher" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtTeacherLabel, txtTeacher, "Teacher" );
    }

    /**
     * @author aravindan.srinivas verify the text Select StudentBy is Displayed
     *         in the web page.
     * @param driver
     */
    public void verifyTextSelectStudentBy( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSelectStudentBy, "Select StudentBy" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSelectStudentBy, txtSelectStudentsBy, "Select StudentBy" );
    }

    /**
     * @author aravindan.srinivas verify the text Subject DropDown Header is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSubjectDropDownHeader( WebDriver driver, String reportName ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSubjectDropDownHeader, "Subject DropDown Header" );
        if ( reportName.equalsIgnoreCase( "System Enrollment and Usage" ) ) {
            ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSubjectDropDownHeader, txtSubjectAllCourses, "Subject DropDown Header" );
        } else {
            ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSubjectDropDownHeader, txtSubject, "Subject DropDown Header" );
        }
    }

    /**
     * @author aravindan.srinivas verify the text Courses DropDown Header is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextCoursesDropDownHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtCoursesDropDownHeader, "Courses DropDown Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtCoursesDropDownHeader, txtCourses, "Courses DropDown Header" );
    }

    /**
     * @author aravindan.srinivas verify the text Course Selection Header is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextCourseSelectionHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtCourseSelectionHeader, "Course Selection Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtCourseSelectionHeader, txtCourseSelection, "Course Selection Header" );
    }

    /**
     * @author aravindan.srinivas verify the text Organizations Header is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextOrganizationsHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtOrganizationsHeader, "Organizations Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtOrganizationsHeader, txtOrganizations, "Organizations Header" );
    }

    /**
     * @author aravindan.srinivas verify the text Saved Report Options Header is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSavedReportOptionsHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSavedReportOptionsHeader, "Saved Report Options Header" );

        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSavedReportOptionsHeader, txtSavedReportOptions, "Saved Report Options Header" );
    }

    /**
     * @author aravindan.srinivas verify the text Page Header Description is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextPageHeaderDescription( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtPageHeaderDescription, "Page Header Description" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtPageHeaderDescription, txtPageHeaderDescriptionHeader, "Page Header Description" );
    }

    /**
     * @author sathish.suresh
     * @throws InterruptedException
     * 
     */
    public ReportsViewerPage clickRunReport( WebDriver driver ) throws InterruptedException {
        WebElement webElement = ShadowDOMUtils.retryAndGetWebElement( driver, btnEnabledRunReportShadowDOM[0], btnEnabledRunReportShadowDOM[1] );
        SMUtils.scrollDownIntoViewElement( driver, webElement );
        SMUtils.click( driver, webElement );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sathish.suresh validate Subject dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSubjectDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpdwnSubjectshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpdwnSubjectshadowDOM[0], this.drpdwnSubjectshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpdwnSubjectshadowDOM, "Subject Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Course(s) dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateCourseDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpdwnCoursesshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpdwnCoursesshadowDOM[0], this.drpdwnCoursesshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpdwnCoursesshadowDOM, "Course Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Optional Filter Header Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateOptionalFilterHeaderField( WebDriver driver ) throws InterruptedException {
        WebElement txtOptionalFiltershadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtOptionalFiltershadowDOM[0], this.txtOptionalFiltershadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtOptionalFiltershadowDOM, "Optional Filter Header Field" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtOptionalFiltershadowDOM, txtOptionalFilters, "Optional Filter Header text" );
    }

    /**
     * @author sathish.suresh validate Teacher dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateTeacherDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnTeachersshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnTeachersshadowDOM[0], this.drpDwnTeachersshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnTeachersshadowDOM, "Teacher Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Grade dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateGradeDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnGradesshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnGradesshadowDOM[0], this.drpDwnGradesshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnGradesshadowDOM, "Grade Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Group dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateGroupDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnGroupshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnGroupshadowDOM[0], this.drpDwnGroupshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnGroupshadowDOM, "Group Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Additional Grouping dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAdditionalGroupingDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnAdditionalGroupingshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnAdditionalGroupingshadowDOM[0], this.drpDwnAdditionalGroupingshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnAdditionalGroupingshadowDOM, "Additional Grouping Drop Down Field" );
        String attributeValue = drpDwnAdditionalGroupingshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equals( txtAdditionalGroupingDrpdwn ), "Selected '" + attributeValue + "' as default value in Additional Grouping Drpdwn Field", "'" + attributeValue + "' is not a default value in Additional Grouping Drpdwn Field" );
    }

    /**
     * @author sathish.suresh validate Display dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateDisplayDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnDisplayshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnDisplayshadowDOM[0], this.drpDwnDisplayshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnDisplayshadowDOM, "Display Drop Down Field" );
        String attributeValue = drpDwnDisplayshadowDOM.getAttribute( "data-selected" );
        Log.softAssertThat( attributeValue.equals( txtGroupDrpdwn ), "Selected '" + attributeValue + "' as default value in Group Drpdwn Field", "'" + attributeValue + "' is not a default value in Group Drpdwn Field" );
    }

    /**
     * @author sathish.suresh validate Sort dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSortDrpdwnField( WebDriver driver, String reportName ) throws InterruptedException {
        WebElement drpDwnSortshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnSortshadowDOM[0], this.drpDwnSortshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnSortshadowDOM, "Sort Drop Down Field" );
        String attributeValue = drpDwnSortshadowDOM.getAttribute( "data-selected" );
        if ( reportName.contains( "Growth" ) ) {
            Log.assertThat( attributeValue.trim().equalsIgnoreCase( txtSortDrpdwn ), "Selected '" + attributeValue + "' as default value in Sort Drpdwn Field", "'" + attributeValue + "' is not a default value in Sort Drpdwn Field" );
        } else {
            Log.assertThat( attributeValue.trim().equalsIgnoreCase( txtSortStudentValueDrpdwn ), "Selected '" + attributeValue + "' as default value in Sort Drpdwn Field", "'" + attributeValue + "' is not a default value in Sort Drpdwn Field" );
        }
    }

    /**
     * @author sathish.suresh validate Mask check box Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateMaskCheckBoxField( WebDriver driver ) throws InterruptedException {
        WebElement chkMaskStudentDisplayshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.chkMaskStudentDisplayshadowDOM[0], this.chkMaskStudentDisplayshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, chkMaskStudentDisplayshadowDOM, "Mask Checkbox Field" );
    }

    /**
     * @author sathish.suresh
     * @param driver
     * @param sideNavBarName
     * @throws InterruptedException
     */
    public void selectReportsFromSideNavBar( WebDriver driver, String sideNavBarName ) throws InterruptedException {
        String btnCumulativePerformanceshadowDOM[] = { "cel-side-navigation", "document.querySelector('cel-side-navigation').shadowRoot.querySelector('cel-side-item[data-label=\"" + sideNavBarName + "\"]').shadowRoot.querySelector('button')" };
        WebElement webElement = ShadowDOMUtils.retryAndGetWebElement( driver, btnCumulativePerformanceshadowDOM[0], btnCumulativePerformanceshadowDOM[1] );
        SMUtils.click( driver, webElement );
        Log.message( sideNavBarName + " Selected Successfully" );
    }

    public void validateReportData( WebDriver driver ) {
        List<WebElement> findElements = driver.findElements( By.xpath( "//p[text()='No data to display']" ) );
        if ( findElements.size() == 1 ) {
            Log.message( "Getting 'No data to display' error!!!" );
        } else {
            Log.message( "Report data is loaded properly" );
        }
    }

    /**
     * @author sathish.suresh validate Saved Report Options dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSavedReportOptionsDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpdwnSavedReportOptionshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpdwnSavedReportOptionshadowDOM[0], this.drpdwnSavedReportOptionshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpdwnSavedReportOptionshadowDOM, "Saved Report Option Drop Down Field" );
    }

    public List<String> getOrganizationsForAdmin( Admins admin, String smUrl ) throws Exception {
        String orgId;
        HashMap<String, String> headers = new HashMap<String, String>();
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
            Log.message( orgId );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "brearer" + accessToken );
        headers.put( "user-id", userId );
        headers.put( "org-id", orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers ); // organizationName
        List<String> organizationListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), "organizationName" ) ).forEach(
                iter -> organizationListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "organizationName", iter ) ) );
        return organizationListFromAPI;
    }

    /**
     * @author sathish.suresh Get Courses for Organisation
     * @param driver
     * @throws InterruptedException
     */
    public List<String> getCoursesForOrg( Admins admin, List<String> orgID, String reportName ) throws Exception {
        String orgId;
        HashMap<String, String> headers = new HashMap<String, String>();
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
            Log.message( orgId );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        // headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        headers.put( Constants.USERID_HEADER, userId );
        headers.put( Constants.ORGANIZATION_ID, orgId );
        headers.put( Constants.SUBJECT_TYPE_ID, "2" );
        HashMap<String, String> response = getCourseList( orgID, headers, reportName );

        List<String> courseListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), "assignmentTitle" ) ).forEach(
                iter -> courseListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "assignmentTitle", iter ) ) );
        System.out.println( courseListFromAPI );
        return courseListFromAPI;
    }

    /**
     * To get the Teacher Details From the OrgIds
     * 
     * @param orgIds
     * @return
     * @return
     */

    public List<String> getTeacherNames( String orgId ) {
        List<String> expteacherNames = new ArrayList<>();
        expteacherNames.clear();
        Log.message( "Getting teacher Details..." );
        List<String> teacherUsernames = new ArrayList<>();
        JSONArray teacherJsonArray = new RBSUtils().getAllTeachesForOrg( orgId );
        if ( !teacherJsonArray.equals( new JSONArray() ) ) {
            for ( Object user : teacherJsonArray ) {
                JSONObject userJson = new JSONObject( user.toString() );
                HashMap<String, String> otherDetails = new HashMap<String, String>();
                teacherUsernames.add( userJson.get( ReportsAPIConstants.TNS_FIRSTNAME ).toString() + " " + userJson.get( ReportsAPIConstants.TNS_LASTNAME ).toString() );
            }
        }
        expteacherNames.addAll( teacherUsernames );
        System.out.println( expteacherNames );
        return expteacherNames;
    }

    /**
     * Get Group List Name for the GroupIds
     * 
     * @param groupIds
     * @return
     */
    public List<String> getGroupListNames( List<String> groupIds ) {
        List<String> expgroupNames = new ArrayList<>();
        expgroupNames.clear();
        Log.message( "Getting Groups Details..." );
        groupIds.forEach( groupId -> {
            String classDetails = new RBSUtils().getClass( groupId );
            expgroupNames.add( new SMAPIProcessor().getKeyValues( new JSONObject( classDetails ), ReportsAPIConstants.CLASSNAME ).get( 0 ) );
        } );
        System.out.println( expgroupNames );
        return expgroupNames;
    }

    /**
     * @author sakthi.sasi validate the newly created organization is available
     *         or not
     * @param driver
     * @throws InterruptedException
     */
    public boolean validateOrganizationDropdownValue( WebDriver driver, String orgName ) throws InterruptedException {
        boolean flag = false;
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown  option'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> drpOptions = (List<WebElement>) javascriptExecutor.executeScript( query );
        List<String> orgNames = new ArrayList<>();
        for ( WebElement element : drpOptions ) {
            orgNames.add( element.getAttribute( "value" ) );
        }
        if ( orgNames.contains( orgName ) ) {
            flag = true;
        }
        return flag;
    }

    /**
     * @author sakthi.sasi validate the newly created courses are available or
     *         not
     * @param driver
     * @throws InterruptedException
     */
    public boolean validateCourseDropdownValue( WebDriver driver, List<String> courseNames ) throws InterruptedException {
        boolean flag = false;
        WebElement btnCourses = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnCoursesshadowDOM[0], drpdwnCoursesshadowDOM[1] );
        SMUtils.waitForElement( driver, btnCourses );
        btnCourses.click();
        String query = "var root = document.querySelector('#courses > cel-multi-select').shadowRoot.querySelector('#dropdown > cel-multi-checkbox').shadowRoot.querySelector('cel-checkbox-item').shadowRoot.querySelectorAll('span.checkbox-label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> drpOptions = (List<WebElement>) javascriptExecutor.executeScript( query );
        List<String> courseValues = new ArrayList<>();
        for ( WebElement element : drpOptions ) {
            courseValues.add( element.getText().trim() );
        }
        if ( courseValues.contains( "placeholder" ) ) {
            courseValues.remove( "placeholder" );
        }
        List<String> uniqueValues = new ArrayList<String>();
        List<String> missedValues = new ArrayList<String>();
        for ( String item : courseNames ) {
            if ( courseValues.contains( item ) ) {
                uniqueValues.add( item );
            } else {
                missedValues.add( item );
            }
        }
        Collections.sort( courseNames );
        Collections.sort( courseValues );
        if ( courseNames.equals( courseValues ) ) {
            Log.event( "All elements checked on this page:: " + uniqueValues );
            flag = true;
        } else {
            flag = false;
            if ( missedValues.size() > 0 ) {
                Log.event( "Missing element on this page:: " + missedValues );
            } else {
                List<String> extraElements = new ArrayList<String>( courseValues );
                extraElements.removeAll( courseNames );
                Log.event( "Extra elements on this list:: " + extraElements );
            }
        }
        System.out.println( "Actual values:" + courseValues );
        return flag;

    }

    /**
     * @author sakthi.sasi To compare the expected and available Organization
     *         array list values,then print unique list value and print missed
     *         list value
     * 
     * @param Webdriver
     * @param districtAdmin - admin user name
     * @return flag - returns true if both the lists are equal,else returns
     *         false
     * @throws Exception
     */
    public boolean compareOrganizationElements( WebDriver driver, Admins districtAdmin, String smURL ) throws Exception {
        boolean flag = false;

        List<String> expectedOrgIDs = getOrganizationsForAdmin( districtAdmin, smURL );
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown  option'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> drpOptions = (List<WebElement>) javascriptExecutor.executeScript( query );
        List<String> actualOrgIDs = new ArrayList<>();

        for ( WebElement element : drpOptions ) {
            actualOrgIDs.add( element.getAttribute( "value" ) );
        }
        if ( actualOrgIDs.contains( "placeholder" ) ) {
            actualOrgIDs.remove( "placeholder" );
        }
        List<String> uniqueValues = new ArrayList<String>();
        List<String> missedValues = new ArrayList<String>();
        for ( String item : expectedOrgIDs ) {
            if ( actualOrgIDs.contains( item ) ) {
                uniqueValues.add( item );
            } else {
                missedValues.add( item );
            }
        }
        Collections.sort( expectedOrgIDs );
        Collections.sort( actualOrgIDs );
        if ( expectedOrgIDs.equals( actualOrgIDs ) ) {
            Log.event( "All elements checked on this page:: " + uniqueValues );
            flag = true;
        } else {
            flag = false;
            if ( missedValues.size() > 0 ) {
                Log.event( "Missing element on this page:: " + missedValues );
            } else {
                List<String> extraElements = new ArrayList<String>( actualOrgIDs );
                extraElements.removeAll( expectedOrgIDs );
                Log.event( "Extra elements on this list:: " + extraElements );
            }
        }
        System.out.println( "Expected values:" + expectedOrgIDs );
        System.out.println( "Actual values:" + actualOrgIDs );
        return flag;
    }

    /**
     * @author sakthi.sasi
     * @param driver
     * @param element
     * @param orgIDToSelect
     * @param description
     */
    public void selectOptionFromSingleSelectDropDownUsingSelectValue( WebDriver driver, WebElement element, String orgIDToSelect, String description ) {
        select = new Select( element );
        try {
            if ( !select.isMultiple() ) {
                Log.message( description + " Is Single Select Drop Down" );
                List<WebElement> options = select.getOptions();
                for ( WebElement allOptions : options ) {
                    String option = allOptions.getAttribute( "value" );
                    if ( option.equals( orgIDToSelect ) ) {
                        select.selectByValue( orgIDToSelect );
                        Log.message( "'" + orgIDToSelect + "' Is Selected On " + description + " Successfully" );
                        break;
                    }
                }
            }
        } catch ( Exception e ) {
            Log.message( "Unable To Select Option : " + orgIDToSelect );
            e.printStackTrace();
        }
    }

    /**
     * This method is used to GET an Course listing BFF
     * 
     * @author Sakthi.sasi
     * @param orgIds
     * @param API Details
     * @return
     */

    public HashMap<String, String> getCourseList( List<String> orgIds, HashMap<String, String> apiDetails, String reportName ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        // Generating Request Body
        StringBuffer requestBody = new StringBuffer();
        requestBody.append( "{\"query\":\"query {  getCourseList(subjectTypeId:\\\"" + apiDetails.get( Constants.SUBJECT_TYPE_ID ) + "\\\", reportType:\\\"" + reportName + "\\\", userId:\\\"" + apiDetails.get( Constants.USERID_HEADER ) + "\\\" ,orgId:\\\""
                + apiDetails.get( Constants.ORGANIZATION_ID ) + "\\\",  orgIds: [  \\\"" );
        for ( int i = 0; i < orgIds.size(); i++ ) {
            requestBody.append( orgIds.get( i ) );
            if ( i != orgIds.size() - 1 ) {
                requestBody.append( "\\\",\\\"" );
            } else {
                requestBody.append( "\\\"" );
            }
        }

        // Hitting POST call
        requestBody.append( "] ) {courseList {assignmentId assignmentTitle assignerId organizationId assignerFirstName assignerLastName assignerMiddleName productId contentBaseId }}}\",\"variables\":{}}" );
        HashMap<String, String> postResponse = null;
        try {
            postResponse = RestHttpClientUtil.POST( AdminConstants.ADMIN_REPORT_BFF, headers, params, AdminConstants.GRAPHQL_ENDPOINT, requestBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param admin
     * @param orgIds
     * @return
     * @throws Exception
     */
    public List<String> getTeacherId( WebDriver driver, Admins admin, List<String> orgIds ) throws Exception {

        List<String> teacherIds = new ArrayList<String>();
        // Getting User Id
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        Log.message( "User ID :: " + userId );
        String orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        Log.message( "ORG ID For authentication" + orgId );

        // Getting Bearer Token
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Access Token :: " + accessToken );

        HashMap<String, String> teachersList = getTeachersList( userId, orgId, orgIds, accessToken );

        HashMap<String, HashMap<String, String>> actualValues = getActualValues( teachersList );

        Set<String> userIds = actualValues.keySet();
        List<String> userIdsList = new LinkedList<String>();
        userIdsList.addAll( userIds );

        for ( String teacherId : userIdsList ) {
            teacherIds.add( teacherId );
        }
        return teacherIds;
    }

    /**
     * @author raseem.mohamed Get Actual Values
     */
    public HashMap<String, HashMap<String, String>> getActualValues( HashMap<String, String> response ) {
        HashMap<String, HashMap<String, String>> actualDetails = new HashMap<String, HashMap<String, String>>();
        String actualResponse = response.get( Constants.REPORT_BODY );
        String resip = SMUtils.getKeyValueFromResponseWithArray( actualResponse, "data,getOptionalFilters" );
        JSONArray dsf = new JSONArray( new JSONObject( resip ).get( "teachers" ).toString() );
        actualDetails.clear();
        dsf.forEach( object -> {
            HashMap<String, String> otherDetails = new HashMap<String, String>();
            otherDetails.put( Constants.USER_NAME, new JSONObject( object.toString() ).get( Constants.USER_NAME ).toString() );
            otherDetails.put( Constants.FIRSTNAME, new JSONObject( object.toString() ).get( Constants.FIRSTNAME ).toString() );
            otherDetails.put( Constants.MIDDLENAME, new JSONObject( object.toString() ).get( Constants.MIDDLENAME ).toString() );
            otherDetails.put( Constants.LASTNAME, new JSONObject( object.toString() ).get( Constants.LASTNAME ).toString() );
            actualDetails.put( new JSONObject( object.toString() ).get( Constants.USERID ).toString(), otherDetails );
        } );
        return actualDetails;
    }

    /**
     * @author raseem.mohamed Get Teacher List
     */
    public HashMap<String, String> getTeachersList( String userId, String adminOrgId, List<String> orgIds, String accessToken ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // Request Body
        StringBuffer requestBody = new StringBuffer();
        requestBody = requestBody.append( AdminConstants.FILTER_QUERY_REPORT.format( AdminConstants.FILTER_QUERY_REPORT, userId ) );
        for ( int i = 0; i < orgIds.size(); i++ ) {
            requestBody.append( orgIds.get( i ) );
            if ( i != orgIds.size() - 1 ) {
                requestBody.append( "\\\",\\\"" );
            } else {
                requestBody.append( "\\\"" );
            }
        }
        requestBody.append( AdminConstants.TEACHER_FILTER );

        // Makes a POST call
        Log.message( "Making Post call for Teacher List BFF for parameter: UserId: " + userId + " OrgId List: " + orgIds.toString() + "Access Token: " + accessToken );
        Log.message( "Request Body is \n" + requestBody.toString() );
        HashMap<String, String> postResponse = null;
        try {
            postResponse = RestHttpClientUtil.POST( AdminConstants.ADMIN_REPORT_BFF, headers, params, AdminConstants.GRAPHQL_ENDPOINT, requestBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

    /**
     * @author aravindan.srinivas Wait for the spinner to Load and Wait for
     *         disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }

    /**
     * Return true if the Dropdown is expanded
     * 
     * @author aravindan.srinivas
     * @param dropdown
     * @return
     */
    public boolean isDropdownExpanded( String dropdown ) {
        WebElement rootElement = null;
        WebElement lisRoot = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
        }
        return lisRoot != null ? true : false;
    }

    /**
     * Expand Dropdown
     * 
     * @author aravindan.srinivas
     * @param dropdownName
     */
    public void expanDropdown( String dropdownName ) {
        if ( !isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
            SMUtils.nap( 2 ); // wait for dropdown load

            Log.message( "Dropdown expanded: " + dropdownName );
        } else {
            Log.message( dropdownName + " Dropdown already expanded" );
        }
    }

    /**
     * Close dropdown Element
     * 
     * @author aravindan.srinivas
     * @param dropdownName
     */
    public void closeDropdown( String dropdownName ) {
        if ( isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
        } else {
            Log.message( dropdownName + " Dropdown already closed" );
        }

        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }

    }

    /**
     * It will return the Dropdown Values
     * 
     * @author sakthi.sasi
     * @param dropdown
     * @return
     */
    public List<String> getAllValuesFromDropdown( String dropdown ) {
        final List<String> values = new ArrayList<String>();
        WebElement rootElement = null;
        WebElement parent = null;
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> elements = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            values.addAll( elements.stream().map( element -> SMUtils.getWebElementDirect( driver, element, LABEL ).getAttribute( "data-label" ).trim() ).collect( Collectors.toList() ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            SMUtils.nap( 2 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_Root2 );
            values.addAll( element.stream().map( ddElement -> ddElement.getText().trim() ).collect( Collectors.toList() ) );
        }
        closeDropdown( dropdown );
        return values;
    }

    /**
     * Return true if the checkBox is selected
     * 
     * @author sakthi.sasi
     * @param dropdownName
     * @return
     */
    public boolean verifySelectAllCheckBoxColor( String dropdownName ) {
        WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_ROOT3 );
        String color = Color.fromString( element.getCssValue( "background-color" ) ).asHex();
        return ( color.equals( selectAllCheckBoxColor ) ) ? true : false;
    }

    /**
     * Click Select all options in the Dropdown
     * 
     * @author sathish.suresh
     */
    public void clickSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( !SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
            if ( !verifySelectAllCheckBoxColor( dropdownName ) ) {
                SMUtils.click( driver, element );
            } else {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
            }
            Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
            closeDropdown( dropdownName );
        }
    }

    /**
     * Return true if Select All option is Selected
     * 
     * @author sathish.suresh
     * @param dropdown
     * @return
     */
    public boolean isSelectAllChecked( String dropdown ) {
        expanDropdown( dropdown );
        boolean flag = false;
        if ( verifySelectAllCheckBoxColor( dropdown ) ) {
            WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_PARTIAL_SELECT );
            if ( element == null ) {
                flag = true;
            } else {
                flag = false;
            }
        }
        closeDropdown( dropdown );
        return flag;
    }

    /**
     * click Grades Drop Down
     * 
     * @author sathish.suresh
     */
    public void clickGradesDropdown() {
        expanDropdown( GRADES );
    }

    /**
     * Unselect All options in Dropdown
     * 
     * @author sathish.suresh
     * @param dropdownName
     */
    public void unSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        }
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
        if ( verifySelectAllCheckBoxColor( dropdownName ) ) {
            SMUtils.click( driver, element );
        } else {
            SMUtils.click( driver, element );
            SMUtils.click( driver, element );
        }
        Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
        closeDropdown( dropdownName );
    }

    /***
     * It will opend and the Tick the Values in the Dropdown With options and
     * close the dropdown
     * 
     * @author sathish.suresh
     * @param dropdownName
     * @param options
     */
    public void setValuesForDropdown( String dropdownName, List<String> options ) {
        expanDropdown( dropdownName );
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            selectOptionsFromDropdown( dropdownName, options );
        } else {
            unSelectAll( dropdownName );
            selectOptionsFromDropdown( dropdownName, options );
            closeDropdown( dropdownName );
        }

        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }
    }

    /**
     * Get all the Org Dropdown elements
     * 
     * @author sathish.suresh
     * @return
     */
    public List<WebElement> getAllOrganizationDropdownElements() {
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > cel-single-select-item');var labels =[]; root.forEach ( ele => { labels.push(ele.shadowRoot.querySelector('label'))}); { return labels ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    /**
     * To get the Dropdown Elements
     * 
     * @author sathish.suresh
     * @param dropdown
     * @return
     */
    public List<WebElement> getAllDropdownElements( String dropdown ) {
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> parent = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            List<WebElement> ddElements = new ArrayList<WebElement>();
            parent.stream().forEach( element -> ddElements.add( SMUtils.getWebElementDirect( driver, element, LABEL ) ) );
            return ddElements;
        } else if ( dropdown.equals( ORGANIZATIONS ) ) {
            return getAllOrganizationDropdownElements();
        } else {
            final List<WebElement> streamList = new ArrayList<WebElement>();
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> dataParent = SMUtils.getWebElements( driver, parent, DROPDOWN_DATA_ROOT );
            dataParent.stream().forEach( ddElement -> {
                streamList.add( SMUtils.getWebElementDirect( driver, ddElement, DROPDOWN_GRAND_CHILD ) );
            } );
            return streamList;
        }
    }

    /**
     * Select the options in the Dropdown
     * 
     * @author sathish.suresh
     * @param dropdownName
     * @param options
     */
    public void selectOptionsFromDropdown( String dropdownName, List<String> options ) {
        List<WebElement> elements = getAllDropdownElements( dropdownName );
        if ( elements.size() > 0 ) {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                WebElement option = elements.stream().filter( element -> options.contains( element.getText().trim() ) ).findFirst().orElse( null );
                SMUtils.scrollDownIntoViewElement( driver, option );
                String optionName = option.getText().trim();
                SMUtils.click( driver, option );
                Log.message( optionName + " is ticked" );
            } else {
                elements.stream().filter( element -> options.contains( element.getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollDownIntoViewElement( driver, element );
                    SMUtils.click( driver, element );
                    Log.message( element.getText().trim() + " is ticked" );
                } );
                ;
            }

        } else {
            Log.message( "Issue in Selecting values for " + dropdownName );
        }
    }

    /**
     * To get the data for the Dropdown data details From expand and getting and
     * close dropdown
     * 
     * @author sathish.suresh
     * @param dropdownName
     * @return
     */
    public HashMap<String, String> getDropdownsDataDetails( String dropdownName ) {
        HashMap<String, String> details = new HashMap<String, String>();
        WebElement rootElement = null;
        expanDropdown( dropdownName );
        try {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
                WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
                List<WebElement> ddValues = SMUtils.getWebElementsDirect( driver, parent, LABEL );
                ddValues.stream().forEach( eachElement -> {
                    details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
                } );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
                WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
                List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_DATA_ROOT );
                element.stream().forEach( eachElement -> {
                    details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
                } );
            }
        } catch ( StaleElementReferenceException e ) {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
                WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
                List<WebElement> ddValues = SMUtils.getWebElementsDirect( driver, parent, LABEL );
                ddValues.stream().forEach( eachElement -> {
                    details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
                } );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
                WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
                List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_DATA_ROOT );
                element.stream().forEach( eachElement -> {
                    details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
                } );
            }
        }

        closeDropdown( dropdownName );
        return details;
    }

    /**
     * To get the group name
     * 
     * @author sathish.suresh
     * @return
     */
    public List<String> getGroupNames() {
        HashMap<String, String> dropdownsDataDetails = getDropdownsDataDetails( GROUPS );
        return dropdownsDataDetails.keySet().stream().map( key -> dropdownsDataDetails.get( key ) ).collect( Collectors.toList() );
    }

    /**
     * To get the group Id
     * 
     * @author sathish.suresh
     * @return
     */
    public ArrayList<String> getGroupIds() {
        return new ArrayList<String>( getDropdownsDataDetails( GROUPS ).keySet() );
    }

    /**
     * It will return the Dropdown Values
     * 
     * @author sathish.suresh
     * @param dropdown
     * @return
     */
    public List<String> getAllTeacherID( String dropdown ) {
        final List<String> values = new ArrayList<String>();
        WebElement rootElement = null;
        WebElement parent = null;
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> elements = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            values.addAll( elements.stream().map( element -> element.getAttribute( "data-identifier" ).trim() ).collect( Collectors.toList() ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            SMUtils.nap( 2 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_CheckBox );
            values.addAll( element.stream().map( ddElement -> ddElement.getAttribute( "data-identifier" ).trim() ).collect( Collectors.toList() ) );
        }
        closeDropdown( dropdown );
        return values;
    }

    /**
     * Get Course List Response For selected organization
     * 
     * @author raseem.mohamed
     * @param dropdown
     * @return HashMap
     */
    public HashMap<String, String> getCourseListResponceForOrg( String userId, String adminOrgId, List<String> orgIds, String reportType, String accessToken, String subjectTypeId ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // Generating Request Body
        StringBuffer requestBody = new StringBuffer();
        requestBody.append( "{\"query\":\"query {  getCourseList(subjectTypeId:\\\"" + subjectTypeId + "\\\", reportType:\\\"" + reportType + "\\\", userId:\\\"" + userId + "\\\" ,orgId:\\\"" + adminOrgId + "\\\",  orgIds: [  \\\"" );
        for ( int i = 0; i < orgIds.size(); i++ ) {
            requestBody.append( orgIds.get( i ) );
            if ( i != orgIds.size() - 1 ) {
                requestBody.append( "\\\",\\\"" );
            } else {
                requestBody.append( "\\\"" );
            }
        }
        // Hitting POST call
        requestBody.append( "] ) {courseList {assignmentId assignmentTitle assignerId organizationId assignerFirstName assignerLastName assignerMiddleName productId contentBaseId }}}\",\"variables\":{}}" );
        HashMap<String, String> postResponse = null;
        try {

            postResponse = RestHttpClientUtil.POST( AdminConstants.ADMIN_REPORT_BFF, headers, params, AdminConstants.GRAPHQL_ENDPOINT, requestBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );

        } catch ( Exception e ) {
            e.printStackTrace();
        }

        return postResponse;
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param admin
     * @param orgIds
     * @param reportName
     * @param subjectId
     * @return
     * @throws Exception
     */
    public List<String> verifyCourses( WebDriver driver, Admins admin, List<String> orgIds, String reportName, String subjectId ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        // Getting User Id
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        Log.message( "User ID :: " + userId );
        // Getting Org Id For Authentication
        String orgIdAuthenticate = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        Log.message( "ORG ID For authentication" + orgIdAuthenticate );

        // Getting Bearer Token
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Access Token :: " + accessToken );

        // Api Details

        HashMap<String, String> courseListResponceForOrg = reportsFilterUtils.getCourseListResponceForOrg( userId, orgIdAuthenticate, orgIds, reportName, accessToken, subjectId );
        String responce = courseListResponceForOrg.get( "body" );
        Log.message( "After the body : " + responce );
        List<String> assignmentTitle = getAssignmentTitle( responce );

        return assignmentTitle;

    }

    /**
     * To fetch the assignment Titles from the Response
     * 
     * @author sakthi.sasi
     * @param response
     * @return
     */
    public List<String> getAssignmentTitle( String response ) {

        JSONObject courseDetail = new JSONObject( response );
        List<String> assignmentTitle = new ArrayList<>();
        try {
            JSONObject data = courseDetail.getJSONObject( "data" );
            JSONObject getCourseList = data.getJSONObject( "getCourseList" );
            JSONArray courseDetails = getCourseList.getJSONArray( "courseList" );
            for ( Object course : courseDetails ) {
                JSONObject courseJson = new JSONObject( course.toString() );
                assignmentTitle.add( courseJson.get( "assignmentTitle" ).toString() );
            }
            if ( assignmentTitle.size() > 0 ) {
                Log.message( "Assignment Titles Fetched Successfully" );
            }
        } catch ( Exception e ) {
            Log.fail( "Zero state returned in response!" );
        }
        return assignmentTitle;
    }

    /**
     * select groups from group dropdown
     * 
     * @param driver
     * @param listGroups
     * @return
     * @throws InterruptedException
     */
    public boolean selectGroupsDropdwn( WebDriver driver, List<String> listGroups ) throws InterruptedException {
        boolean value = false;
        WebElement elementSelectAllOption = null;
        //click to open teacher dropdown
        WebElement elementDropdwn = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnGroupShadowDOM[0], drpdwnGroupShadowDOM[1] );
        SMUtils.click( driver, elementDropdwn );

        //Deselect 'Select All' option
        elementSelectAllOption = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnGroupSelectAllShadowDOM[0], drpdwnGroupSelectAllShadowDOM[1] );
        SMUtils.click( driver, elementSelectAllOption );

        //checking the dropdown value 
        for ( int j = 0; j < listGroups.size(); j++ ) {
            int count = 1;
            for ( int i = 1; i <= count; i++ ) {
                String optionShadowDom[] = { "multi-select", "document.querySelector('cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.bottom-container div:nth-child(" + i + ")')" };
                WebElement elementOption = ShadowDOMUtils.retryAndGetWebElement( driver, optionShadowDom[0], optionShadowDom[1] );
                if ( elementOption.getText().equals( listGroups.get( j ).trim() ) ) {
                    SMUtils.click( driver, elementOption );
                    value = true;
                    break;
                } else {
                    count++;
                }
            }

            Log.softAssertThat( value, "'" + listGroups.get( j ) + "' Is Selected On Groups dropdown field Successfully", "Failed to Select' " + listGroups.get( j ) + "' On Groups dropdown field" );
        }
        //close groups dropdown
        SMUtils.click( driver, elementDropdwn );
        return value;
    }

    /**
     * select student radio button
     * 
     * @param driver
     * @throws InterruptedException
     */
    public void selectStudentRadioBtn( WebDriver driver ) throws InterruptedException {
        SMUtils.click( driver, rdBtnStudent );
    }

    /**
     * select students from student dropdown
     * 
     * @param driver
     * @param listGroups
     * @return
     * @throws InterruptedException
     */
    public boolean selectStudentsDropdwn( WebDriver driver, List<String> listStudents ) throws InterruptedException {
        boolean value = false;
        WebElement elementSelectAllOption = null;
        //click to open students selection dropdown
        WebElement elementDropdwn = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnStudentShadowDOM[0], drpdwnStudentShadowDOM[1] );
        SMUtils.click( driver, elementDropdwn );

        //Deselect 'Select All' option
        elementSelectAllOption = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnStudentSelectAllShadowDOM[0], drpdwnStudentSelectAllShadowDOM[1] );
        SMUtils.click( driver, elementSelectAllOption );

        //checking the dropdown value 
        for ( int j = 0; j < listStudents.size(); j++ ) {
            int count = 1;
            for ( int i = 1; i <= count; i++ ) {
                String optionShadowDom[] = { "multi-select",
                        "document.querySelector('div:nth-child(2) > div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.bottom-container div:nth-child(" + i
                                + ") cel-checkbox-item').shadowRoot.querySelector('span')" };
                WebElement elementOption = ShadowDOMUtils.retryAndGetWebElement( driver, optionShadowDom[0], optionShadowDom[1] );
                if ( elementOption.getText().equals( listStudents.get( j ).trim() ) ) {
                    SMUtils.click( driver, elementOption );
                    value = true;
                    break;
                } else {
                    count++;
                }
            }

            Log.softAssertThat( value, "'" + listStudents.get( j ) + "' Is Selected On Students dropdown field Successfully", "Failed to Select' " + listStudents.get( j ) + "' On Students dropdown field" );
        }
        //close students dropdown
        SMUtils.click( driver, elementDropdwn );
        return value;
    }

    /**
     * select assignments from assignment dropdown
     * 
     * @param driver
     * @param listGroups
     * @return
     * @throws InterruptedException
     */
    public boolean selectAssignmentsDropdwn( WebDriver driver, List<String> listassignments ) throws InterruptedException {
        boolean value = false;
        WebElement elementSelectAllOption = null;
        //click to open assignments dropdown
        WebElement elementDropdwn = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnAssignmentShadowDOM[0], drpdwnAssignmentShadowDOM[1] );
        SMUtils.click( driver, elementDropdwn );

        //Deselect 'Select All' option
        elementSelectAllOption = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnAssignmentSelectAllShadowDOM[0], drpdwnAssignmentSelectAllShadowDOM[1] );
        SMUtils.click( driver, elementSelectAllOption );

        //checking the dropdown value 
        for ( int j = 0; j < listassignments.size(); j++ ) {
            int count = 1;
            for ( int i = 1; i <= count; i++ ) {
                String optionShadowDom[] = { "cel-multi-select", "document.querySelector('#assignments cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.bottom-container div:nth-child(" + i
                        + ") cel-checkbox-item').shadowRoot.querySelector('span')" };
                WebElement elementOption = ShadowDOMUtils.retryAndGetWebElement( driver, optionShadowDom[0], optionShadowDom[1] );
                if ( elementOption.getText().equals( listassignments.get( j ).trim() ) ) {
                    SMUtils.click( driver, elementOption );
                    value = true;
                    break;
                } else {
                    count++;
                }
            }

            Log.softAssertThat( value, "'" + listassignments.get( j ) + "' Is Selected On Assignments dropdown field Successfully", "Failed to Select' " + listassignments.get( j ) + "' On Assignments dropdown field" );
        }
        //close assignments dropdown
        SMUtils.click( driver, elementDropdwn );
        return value;
    }

    /**
     * @author sathish.suresh verify the text Groups Header is Displayed in the
     *         web page
     * @param driver
     */
    public void verifyTextGroupsHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtGroups, "Groups Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtGroups, txtGroupsHeader, "Groups Header" );
    }

    public boolean selectStudentDropdwn( WebDriver driver, String drpdwnValue ) throws InterruptedException {
        boolean value = false;
        WebElement elementSelectAllOption = null;
        // click student selection dropdown
        String drpDwnShadowDom[] = { "multi-select", "document.querySelector('multi-select[formcontrolname=\"students\"] > cel-multi-select').shadowRoot.querySelector('button[aria-expanded=\"false\"]')" };
        WebElement elementDropdwn = ShadowDOMUtils.retryAndGetWebElement( driver, drpDwnShadowDom[0], drpDwnShadowDom[1] );
        SMUtils.click( driver, elementDropdwn );

        // Deselect 'Select All' option
        String drpDwnShadow[] = { "cel-multi-select",
                "document.querySelector('div:nth-child(2) > div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };
        elementSelectAllOption = ShadowDOMUtils.retryAndGetWebElement( driver, drpDwnShadow[0], drpDwnShadow[1] );
        SMUtils.click( driver, elementSelectAllOption );

        // checking the dropdown value
        int count = 1;
        for ( int i = 1; i <= count; i++ ) {
            String optionShadowDom[] = { "multi-select",
                    "document.querySelector('div:nth-child(2) > div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.bottom-container div:nth-child(" + i
                            + ") cel-checkbox-item').shadowRoot.querySelector('span')" };
            WebElement elementOption = ShadowDOMUtils.retryAndGetWebElement( driver, optionShadowDom[0], optionShadowDom[1] );
            if ( elementOption.getText().equals( drpdwnValue.trim() ) ) {
                SMUtils.click( driver, elementOption );
                value = true;
                break;
            } else {
                count++;
            }
        }
        Log.softAssertThat( value, "'" + drpdwnValue + "' Is Selected On Students dropdown field Successfully", "Failed to Select' " + drpdwnValue + "' On Students dropdown field" );
        return value;
    }

    /**
     * @author sathish.suresh verify the text Students Header is Displayed in
     *         the web page
     * @param driver
     */
    public void verifyTextStudentsHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtStudents, "Students Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtStudents, txtStudentsHeader, "Students Header" );
    }

    /**
     * @author sathish.suresh verify the text Assignments Header is Displayed in
     *         the web page
     * @param driver
     */
    public void verifyTextAssignmentsHeader( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtAssignments, "Assignments Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtAssignments, txtAssignmentsHeader, "Assignments Header" );
    }

    /**
     * @author sathish.suresh validate Groups dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateGroupsDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnGroupshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpdwnGroupShadowDOM[0], this.drpdwnGroupShadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnGroupshadowDOM, "Groups Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Students dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateStudentsDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpdwnStudentShadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpdwnStudentShadowDOM[0], this.drpdwnStudentShadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpdwnStudentShadowDOM, "Students Drop Down Field" );
    }

    /**
     * @author sathish.suresh validate Assignments dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAssignmentsDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpdwnAssignmentShadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpdwnAssignmentShadowDOM[0], this.drpdwnAssignmentShadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpdwnAssignmentShadowDOM, "Assignments Drop Down Field" );
    }

    /**
     * To verify radio buttons for Group and students
     *
     */
    public boolean isGroupAndStudentRadioButtonDisplayed() {
        SMUtils.waitForElement( driver, txtReportDescription );
        return rbGroupAndStudentDropdownParent.stream().anyMatch( element -> {
            WebElement rbGroupOrStudent = element.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
            return rbGroupOrStudent.isSelected();
        } );
    }

    /***
     * Checks the Students Radio button
     *
     * @param dropdownName
     */
    public void checkGroupsOrStudentRB( String dropdownName ) {
        if ( !isGroupsOrStudentRBChecked( dropdownName ) ) {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().contains( dropdownName ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
                    rbGroupOrStudent.click();
                    Log.message( "Clicked " + dropdownName + " radio button." );
                    break;
                }
            }
        }
    }

    /***
     * Checks whether students radio button is selected or not
     *
     * @param dropdownName
     * @return
     */
    public boolean isGroupsOrStudentRBChecked( String dropdownName ) {
        boolean isChecked = false;
        try {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().equals( dropdownName ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
                    isChecked = rbGroupOrStudent.isSelected();
                    Log.message( "Verified radio button for " + dropdownName );
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "Getting error while verifying student radio button!" );
        }
        return isChecked;
    }

    /**
     * @author aravindan.srinivas verify the text Groups And Students is
     *         Displayed in the web page
     * @param driver
     */
    public void verifyTextGroupsAndStudents( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtGroupsAndStudents, "Groups and Students Header" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtGroupsAndStudents, groupAndStudent, "Text : Groups and Students Header" );
    }

    public List<String> getStudentsList( String teachername, String schoolName ) {
        // getting the Student names from data setup
        List<String> studentList = new ArrayList<>();
        HashMap<String, String> studentDetails = RBSDataSetup.teacherStudentMap.get( teachername );
        int size = studentDetails.size();
        for ( int i = 1; i <= size; i++ ) {
            String details = studentDetails.get( "Student" + i );
            if ( SMUtils.getKeyValueFromResponse( details, "middleName" ).isEmpty() ) {
                studentList.add( SMUtils.getKeyValueFromResponse( details, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( details, "lastName" ) );
            } else {
                studentList.add( SMUtils.getKeyValueFromResponse( details, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( details, "middleName" ) + ". " + SMUtils.getKeyValueFromResponse( details, "lastName" ) );
            }
        }
        return studentList;
    }

    /**
     * To get the group Id
     * 
     * @author sakthi.sasi
     * @return
     */
    public ArrayList<String> getTeacherGroupIds() {
        return new ArrayList<String>( getDropdownsDataDetails( Teacher_Groups ).keySet() );
    }

    /**
     * To get the group name
     * 
     * @author sakthi.sasi
     * @return
     */
    public List<String> getTeacherGroupNames() {
        HashMap<String, String> dropdownsDataDetails = getDropdownsDataDetails( Teacher_Groups );
        return dropdownsDataDetails.keySet().stream().map( key -> dropdownsDataDetails.get( key ) ).collect( Collectors.toList() );
    }

    public List<String> getAssignmentDetails( String smUrl, String teacherUsername, String teacherDetails, String assignmentType ) throws Exception {
        HashMap<String, String> assignmentDetails = new HashMap<>();

        // Getting User Id
        String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        Log.message( "User ID :: " + teacherId );
        // Getting Org Id For Authentication
        String orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        Log.message( "ORG ID For authentication" + orgId );

        // Getting Bearer Token
        String accessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Access Token :: " + accessToken );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        HashMap<String, String> assignmentRespose = new AssignmentAPI().getAssignmentLists( smUrl, assignmentDetails );
        List<String> assignmetNames = listAssignments( assignmentRespose, assignmentType );
        return assignmetNames;
    }

    public List<String> listAssignments( HashMap<String, String> repsonse, String assignmentType ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> assignmentsList = new ArrayList<>();
        String assignments = repsonse.get( Constants.REPORT_BODY );
        Log.message( assignments );
        IntStream.rangeClosed( 1, new JSONObject( assignments ).getJSONArray( "data" ).length() ).forEach( itr -> {
            if ( assignmentType.equalsIgnoreCase( "mathassignments" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "MATH" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "readingassignments" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "READING" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "defaultMath" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "default.math" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "defaultReading" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "default.reading" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "focusMath" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "focus.math" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "focusReading" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "focus.reading" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "mathCustomByStandards" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "MATH" )&& SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_STANDARDS" )  ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "mathCustomBySkills" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "MATH" ) && SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SKILLS" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            }/* else if ( assignmentType.equalsIgnoreCase( "mathCustomBySettingsIPON" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "MATH" ) && SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SETTINGS" )) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "mathCustomBySettingsIPOFF" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "MATH" ) && SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SETTINGS" )) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            }*/ else if ( assignmentType.equalsIgnoreCase( "readingCustomByStandards" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "READING" )&& SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_STANDARDS" )) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "readingCustomBySkills" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "READING" )&& SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SKILLS" ) ) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            }/* else if ( assignmentType.equalsIgnoreCase( "readingCustomBySettingsIPON" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "READING" ) && SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SETTINGS" )) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } else if ( assignmentType.equalsIgnoreCase( "readingCustomBySettingsIPOFF" ) ) {
                if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "READING" ) && SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SETTINGS" )) {
                    assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", itr ) );
                }
            } */
            
        } );
        System.out.println( assignmentsList );

        return assignmentsList;
    }
}