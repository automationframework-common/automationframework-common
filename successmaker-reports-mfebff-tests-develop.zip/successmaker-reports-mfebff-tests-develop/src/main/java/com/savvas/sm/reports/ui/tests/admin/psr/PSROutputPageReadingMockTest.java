package com.savvas.sm.reports.ui.tests.admin.psr;

import com.google.gson.JsonObject;
import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.LastSessionReportPage;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

import io.restassured.response.Response;
import io.restassured.response.Validatable;
import io.restassured.response.ValidatableResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.IntStream;

public class PSROutputPageReadingMockTest extends EnvProperties {
    private String browser;
    private String masteryBFF;
    String smReportsUrl;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String distId;
    LastSessionReportPage lsMethod = new LastSessionReportPage();

    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) {
        smReportsUrl = configProperty.getProperty( "PSRMockEnvironmentAdmin" );
        //replace to latest 
        browser = "Windows_10_Chrome_100";

        masteryBFF = configProperty.getProperty( "AdminReportBFFGraphQL" );

        distAdminUserName = ReportDataCollection.districtAdmin;
        Log.message( "distAdminUserName: " + distAdminUserName );
        distId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, "userId" );

        
    }

    // test

    @Test ( description = "PSR-Admin Read Mock for One assignemnt Data", groups = { "SMK-67130", "AdminDashboard", "Reports", "Prescriptive scheduling", "Mock-Reading", "mock" }, priority = 1 )
    public void tcPSRReadMock001( ITestContext context ) throws Exception {

        // Get driver
        WebDriver driver = WebDriverFactory.get( browser );
        //        RecentSessionsPage lsPage = new RecentSessionsPage( driver );
        PrescriptiveSchedulingPage psrPage = new PrescriptiveSchedulingPage( driver );
        Log.testCaseInfo( " " + browser + "]</b></i></small>" );
        String laAdminReadMock=null;
        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse( "PSRGetReportOptionResponse.json" );
                 laAdminReadMock = DevToolsUtils.readJsonResponse( "PSRAdminReadMock.json" );
                responses.put( "GetReportOptionResponse", getReportOptionResponseJson );
                responses.put( "getAdminPSReportData", laAdminReadMock );

                List<String> requestPayloadMatchers = Arrays.asList( "GetReportOptionResponse", "getAdminPSReportData" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, requestPayloadMatchers, "post", responses );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );
            }

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 20 );

            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.PRESCRIPTIVE_SCHEDULING ), "Admin PSR Run Report option displayed", "Admin PSR Run Report is not clicked" );
            SMUtils.waitForSpinnertoDisapper( driver, 15 );
            SMUtils.waitForSpinnertoDisapper( driver );

            //            Map<String, Map<String, String>> uiValues = lsMethod.getLSReportAllDataFromUI( driver, false );
            //            Log.message( "uiValues: " + uiValues );

            Log.message( "TotalPageNo: " + outputPage.totalPageNo() );
//            psrPage.getAllAssignmentNamesFromOutput( driver, outputPage.totalPageNo() );

            String orgName = psrPage.getOrgNameOutput( driver );
            Log.message( "orgName: " + orgName );

            Log.assertThat( orgName.equalsIgnoreCase( "XMotion Testing School" ), "Mock orgName is matched! Test Passed:)", "Mock orgName is not matched! Test Failed:(" );
            Log.assertThat( psrPage.verifyFooterIsDispayed( driver ), "Savvas Footer is displayed, Test passed:)", "Savvas Footer is not displayed, Test Failec:(" );
            Log.assertThat( outputPage.isNextBtnDisplayed(), "Next Button is displayed, Test passed:)", "Next Button is not displayed, Test Failed:(" );
            Log.assertThat( outputPage.clickNextBtn(), "Next Button is clickable, Test passed:)", "Next Button is not clickable, Test Failed:(" );
            Log.assertThat( outputPage.isBackBtnDisplayed(), "Back Button is displayed, Test passed:)", "Back Button is not displayed, Test Failed:(" );
            Log.assertThat( outputPage.clickBackBtn(), "Back Button is clickable, Test passed:)", "Back Button is not clickable, Test Failed:(" );

            PSReportAdminMFETest psr = new PSReportAdminMFETest();
            HashMap<String, List<String>> exp = getListOfValuesFromAPIOutput( laAdminReadMock );
            
            HashMap<String, List<String>> act = psr.getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromAPIOutput:" + exp );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // Verification
            act.keySet().forEach( key -> {
                Assert.assertEquals( act.get( key ), exp.get( key ), "The value is not Matched for " + key + "\nActual:" + act.get( key ) + "\nExpected:" + exp.get( key ) );
            } );
            Log.assertThat( exp.equals( act ), "The API values are matching with UI values", "The API values are not matching with UI values" );
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != devTool ) {
                RequestMockUtils.closeMock( devTool );
            }
            driver.quit();
        }
    }

    @Test ( enabled=false,description = "PSR-Admin Read Mock for 1000 assignemnt Data", groups = { "SMK-67130", "AdminDashboard", "Reports", "Prescriptive scheduling", "Mock-Reading", "mock" }, priority = 1 )
    public void tcPSRReadMock002( ITestContext context ) throws Exception {

        // Get driver
        WebDriver driver = WebDriverFactory.get( browser );
        //        RecentSessionsPage lsPage = new RecentSessionsPage( driver );
        PrescriptiveSchedulingPage psrPage = new PrescriptiveSchedulingPage( driver );

        Log.testCaseInfo( "Minimum " + browser + "]</b></i></small>" );
        String laAdminReadMock=null;

        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse( "PSRGetReportOptionResponse.json" );
                 laAdminReadMock = DevToolsUtils.readJsonResponse( "PSRAdminReadMockMax.json" );
                responses.put( "GetReportOptionResponse", getReportOptionResponseJson );
                responses.put( "getAdminPSReportData", laAdminReadMock );

                List<String> requestPayloadMatchers = Arrays.asList( "GetReportOptionResponse", "getAdminPSReportData" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, requestPayloadMatchers, "post", responses );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );
            }

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 20 );

            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.PRESCRIPTIVE_SCHEDULING ), "Admin PSR Run Report option displayed", "Admin PSR Run Report is not clicked" );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );


            PSReportAdminMFETest psr = new PSReportAdminMFETest();
            HashMap<String, List<String>> exp = getListOfValuesFromAPIOutput( laAdminReadMock );
            
            HashMap<String, List<String>> act = psr.getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromAPIOutput:" + exp );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // Verification
            act.keySet().forEach( key -> {
                Assert.assertEquals( act.get( key ), exp.get( key ), "The value is not Matched for " + key + "\nActual:" + act.get( key ) + "\nExpected:" + exp.get( key ) );
            } );
            Log.assertThat( exp.equals( act ), "The API values are matching with UI values", "The API values are not matching with UI values" );

           
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != devTool ) {
                RequestMockUtils.closeMock( devTool );
            }
            driver.quit();
        }
    }

    @Test ( description = "Verify LS-Admin Read Mock for Zero state", groups = { "SMK-67130", "AdminDashboard", "Reports", "Prescriptive scheduling", "Mock-Reading", "mock" }, priority = 1 )
    public void tcPSRReadMock003( ITestContext context ) throws Exception {

        // Get driver
        WebDriver driver = WebDriverFactory.get( browser );
        PrescriptiveSchedulingPage psrPage = new PrescriptiveSchedulingPage( driver );
        Log.testCaseInfo( "Zero state " + browser + "]</b></i></small>" );

        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse( "PSRGetReportOptionResponse.json" );
                String laAdminReadMock = DevToolsUtils.readJsonResponse( "psrAdminReadZeroState.json" );
                responses.put( "GetReportOptionResponse", getReportOptionResponseJson );
                responses.put( "getAdminPSReportData", laAdminReadMock );

                List<String> requestPayloadMatchers = Arrays.asList( "GetReportOptionResponse", "getAdminPSReportData" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, requestPayloadMatchers, "post", responses );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );
            }

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 20 );

            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.PRESCRIPTIVE_SCHEDULING ), "Admin PSR Run Report option displayed", "Admin PSR Run Report is not clicked" );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );

            Log.assertThat( psrPage.VerifyPSRZeroState( driver ), "Zero state mock is verified! Test passed:)", "Zero state mock is not verified! Test Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != devTool ) {
                RequestMockUtils.closeMock( devTool );
            }
            driver.quit();
        }
    }
    
    
    
    @Test ( description = "PSR-Admin Read Mock for 1000 assignemnt Data", groups = { "SMK-67130", "AdminDashboard", "Reports", "Prescriptive scheduling", "Mock-Reading", "mock" }, priority = 1 )
    public void tcPSRReadMock004( ITestContext context ) throws Exception {

        // Get driver
        WebDriver driver = WebDriverFactory.get( browser );
        PrescriptiveSchedulingPage psrPage = new PrescriptiveSchedulingPage( driver );

        Log.testCaseInfo( "Minimum " + browser + "]</b></i></small>" );
        String laAdminReadMock=null;

        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse( "PSRGetReportOptionResponse.json" );
                 laAdminReadMock = DevToolsUtils.readJsonResponse( "PSRAdminReadMockMax.json" );
                responses.put( "GetReportOptionResponse", getReportOptionResponseJson );
                responses.put( "getAdminPSReportData", laAdminReadMock );

                List<String> requestPayloadMatchers = Arrays.asList( "GetReportOptionResponse", "getAdminPSReportData" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, requestPayloadMatchers, "post", responses );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 20 );

            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.PRESCRIPTIVE_SCHEDULING ), "Admin PSR Run Report option displayed", "Admin PSR Run Report is not clicked" );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );


            PSReportAdminMFETest psr = new PSReportAdminMFETest();
            HashMap<String, List<String>> exp = getListOfValuesFromAPIOutput( laAdminReadMock );
            
            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromAPIOutput:" + exp );
            Log.message( "getListOfValuesFromUIOutput" + act );

            Log.assertThat( act.entrySet().stream().allMatch( entry -> entry.getValue().containsAll( exp.get( entry.getKey() ) ) ), "The API values are matching with UI values", "The API values are not matching with UI values" );

           
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != devTool ) {
                RequestMockUtils.closeMock( devTool );
            }
            driver.quit();
        }
    }


    
    
    public HashMap<String, List<String>> getListOfValuesFromAPIOutput( String response ) {


        // Storing values
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();


        String sam= SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, "data" ), "getAdminPSReportData" );
        JSONArray assignmentList = new JSONObject(sam).getJSONArray("assignments" );
        System.out.println( "Assignment Length: " + assignmentList.length() );

        int i = 0;
        // Iterating each Assignment Data
        for ( Object oneAssignment : assignmentList ) {

            JSONObject singleAssignment = new JSONObject( oneAssignment.toString() );
            String assignmentTitle = (String) singleAssignment.get( "assignmentTitle" );
            String grade = singleAssignment.get( "grade" ).toString();
            JSONArray assignmentStudents = new JSONArray( singleAssignment.get( "studentRows" ).toString() );
            int endRange = assignmentStudents.length();

            IntStream.range( 0, endRange ).forEach( index -> {
                List<String> singleStudentData = new LinkedList<>();
                String stuName = (String) assignmentStudents.query( "/" + index + "/studentName" );

                String assignmentStudentName = assignmentTitle + ":" + stuName;

                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/currentCourseLevel" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/ipLevel" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/timeSinceIp" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/performanceData/skillsPercentMastered" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentRate/sessionLength" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentRate/averageMinDay" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentRate/currentLearningRate" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentForecast/time" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/currentForecast/level" ) );

                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    allStudentValuesList.put( assignmentStudentName, singleStudentData );

                } else {
                    allStudentValuesList.put( assignmentStudentName, singleStudentData );
                }
                System.out.println( assignmentStudentName + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName ) );
            } );

        }
        return allStudentValuesList;
    }
    
    public HashMap<String, List<String>> getListOfValuesFromUIOutput( WebDriver driver ) throws InterruptedException {
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();

        PrescriptiveSchedulingPage prescriptiveSchedulingPage = new PrescriptiveSchedulingPage( driver );
        boolean flag = true;

            // Data From UI
            //Thread.sleep( 300000 );
            String assignmentTitle = driver.findElement( By.tagName( "h3" ) ).getText().trim();

            // Single Page row count
            int rowCount = driver.findElements( By.xpath( prescriptiveSchedulingPage.rowCountXpath ) ).size();

            IntStream.rangeClosed( 1, rowCount ).forEach( rowIndex -> {
                List<String> arrayList = new LinkedList<String>();

                arrayList.clear();
                // Getting all the values from single row
                IntStream.rangeClosed( 1, 10 ).forEach( columnIndex -> {
                    String formatted = prescriptiveSchedulingPage.studentData.format( prescriptiveSchedulingPage.studentData, rowIndex, columnIndex );
                    arrayList.add( driver.findElement( By.xpath( formatted ) ).getText().trim() );
                } );

                String assignmentStudentName = assignmentTitle + ":" + arrayList.get( 0 );
                arrayList.remove( 0 );

                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    Log.message( allStudentValuesList + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName ) );
                } else {
                    allStudentValuesList.put( assignmentStudentName, arrayList );
                }
            } );

            // clicking next button
            prescriptiveSchedulingPage.EnterpgNo(driver);
          prescriptiveSchedulingPage.clickNextButtoninOuputPage();

            SMUtils.nap( 1.5 );
            

        return allStudentValuesList;
    }

}