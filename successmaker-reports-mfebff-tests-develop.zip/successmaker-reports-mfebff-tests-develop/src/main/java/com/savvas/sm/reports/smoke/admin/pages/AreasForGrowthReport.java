package com.savvas.sm.reports.smoke.admin.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AreasForGrowthReport extends LoadableComponent<AreasForGrowthReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    Random random = new Random();
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Areas For Growth Report']", AI = false )
    public WebElement txtAreasForGrowthReportHeader;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String drpDwnAdditionalGroupingshadowDOM[] = { "cel-accordion-item",
            "document.querySelector('body > app-root > div > reports-wrapper > div > div > section > report > section > section > form > report-body > div > areas-for-growth cel-single-select').shadowRoot.querySelector('#dropdown')" };
    public String drpDwnDisplayshadowDOM[] = { "cel-accordion-item",
            "document.querySelector(\"body > app-root > div > reports-wrapper > div > div > section > report > section > section > form > report-body > div > areas-for-growth > cel-accordion-item > section > section.additional-filters-section > div:nth-child(1) > div > single-select > div >cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };
    public String drpDwnSortshadowDOM[] = { "cel-accordion-item",
            "document.querySelector(\"body > app-root > div > reports-wrapper > div > div > section > report > section > section > form > report-body > div > areas-for-growth > cel-accordion-item > section > section.additional-filters-section > div.row.filters.bottom-border > single-select:nth-child(1) > div > cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };
    public String txtAdditionalGroupingDrpdwn = "NONE";
    public String txtGroupDrpdwn = "STUDENT_NAME";
    public String txtSortDrpdwn = "STRAND";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtAreasForGrowthReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public AreasForGrowthReport() {}

    public AreasForGrowthReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas validate Additional Grouping dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAdditionalGroupingDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnAdditionalGroupingshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnAdditionalGroupingshadowDOM[0], this.drpDwnAdditionalGroupingshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnAdditionalGroupingshadowDOM, "Additional Grouping Drop Down Field" );
        String attributeValue = drpDwnAdditionalGroupingshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equals( txtAdditionalGroupingDrpdwn ), "Selected '" + attributeValue + "' as default value in Additional Grouping Drpdwn Field", "'" + attributeValue + "' is not a default value in Additional Grouping Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas validate Display dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateDisplayDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnDisplayshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnDisplayshadowDOM[0], this.drpDwnDisplayshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnDisplayshadowDOM, "Display Drop Down Field" );
        String attributeValue = drpDwnDisplayshadowDOM.getAttribute( "data-selected" );
        Log.softAssertThat( attributeValue.equals( txtGroupDrpdwn ), "Selected '" + attributeValue + "' as default value in Group Drpdwn Field", "'" + attributeValue + "' is not a default value in Group Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas validate Sort dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSortDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnSortshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnSortshadowDOM[0], this.drpDwnSortshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnSortshadowDOM, "Sort Drop Down Field" );
        String attributeValue = drpDwnSortshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.trim().equalsIgnoreCase( txtSortDrpdwn ), "Selected '" + attributeValue + "' as default value in Sort Drpdwn Field", "'" + attributeValue + "' is not a default value in Sort Drpdwn Field" );
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @throws InterruptedException
     */
    public void validateSavedReports( WebDriver driver ,String orgId) throws InterruptedException {

        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Areas For Growth Report" ), "User Landed On Areas Of Growth Report", "User Not Landed On Areas Of Growth Report" );
        WebElement drpdwnSubjectshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnSubjectshadowDOM[0], reportsFilterUtils.drpdwnSubjectshadowDOM[1] );
        WebElement drpdwnCoursesshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnCoursesshadowDOM[0], reportsFilterUtils.drpdwnCoursesshadowDOM[1] );
        this.chooseOrganization(driver, orgId);
        SMUtils.click( driver, drpdwnSubjectshadowDOM );
        Log.message( "User Clicked On Subject Drop Down" );
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelect( driver, drpdwnSubjectshadowDOM, "Math", "Subject drop Down" );
        SMUtils.nap( 2 );
        reportsFilterUtils.verifyCourseDropDownIsEnabled( driver, drpdwnCoursesshadowDOM );
        ArrayList<String> optionToSelect = new ArrayList<String>( Arrays.asList( "Select All" ) );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", optionToSelect );
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        String savedReportName = "Automation SavedReport " + random.nextInt(); // Generating Random Name For Saved
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author aravindan.srinivas validate All Fields in AFG Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInAFGReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtAreasForGrowthReportHeader.getText();
        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );
        reportsFilterUtils.verifyTextOrganizationsHeader( driver );
        reportsFilterUtils.validateOrgDrpdwnField( driver );
        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );
        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );
        reportsFilterUtils.validateOptionalFilterHeaderField( driver );
        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );
        reportsFilterUtils.verifyTextSelectStudentBy( driver );
        reportsFilterUtils.verifyTextTeacher( driver );
        reportsFilterUtils.validateTeacherDrpdwnField( driver );
        reportsFilterUtils.verifyTextGrade( driver );
        reportsFilterUtils.validateGradeDrpdwnField( driver );
        reportsFilterUtils.verifyTextGroup( driver );
        reportsFilterUtils.validateGroupDrpdwnField( driver );
        reportsFilterUtils.verifyTextAdditionalGrouping( driver );
        validateAdditionalGroupingDrpdwnField( driver );
        reportsFilterUtils.verifyTextDisplay( driver );
        validateDisplayDrpdwnField( driver );
        reportsFilterUtils.validateMaskCheckBoxField( driver );
        reportsFilterUtils.verifyTextSortInAdditionalGrouping( driver );
        validateSortDrpdwnField( driver );
        reportsFilterUtils.verifyTextDatesAtRisk( driver );
        reportsFilterUtils.validateDatesAtRiskDrpdwnField( driver );
        // Demographics Filter
        WebElement txtStudentDemographics = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtStudentDemographicsShadowDOM[0], reportsFilterUtils.txtStudentDemographicsShadowDOM[1] );
        SMUtils.click( driver, txtStudentDemographics );
        reportsFilterUtils.verifyTextDisablityStatus( driver );
        reportsFilterUtils.validateDisabilityStatusDrpdwnField( driver );
        reportsFilterUtils.verifyTextEnglishLanguageProficiency( driver );
        reportsFilterUtils.validateEnglishLanguageProficiencyDrpdwnField( driver );
        reportsFilterUtils.verifyTextEthnicity( driver );
        reportsFilterUtils.validateEthnicityDrpdwnField( driver );
        reportsFilterUtils.verifyTextMigrantStatus( driver );
        reportsFilterUtils.validateMigrantStatusDrpdwnField( driver );
        reportsFilterUtils.verifyTextRace( driver );
        reportsFilterUtils.validateRaceDrpdwnField( driver );
        reportsFilterUtils.verifyTextSpecialServices( driver );
        reportsFilterUtils.validateSpecialServiceDrpdwnField( driver );
        reportsFilterUtils.verifyTextSocioEconomicStatus( driver );
        reportsFilterUtils.validateSocioEconomicStatusDrpdwnField( driver );
    }

    /**
     * @author sathish.suresh Validate AFG run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateAFGRunReport( WebDriver driver ,String flexSchoolId) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        this.chooseOrganization( driver, flexSchoolId );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        ReportsViewerPage clickRunReport = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param reportNameToSwitch
     * @return Object
     * @throws InterruptedException
     */
    public Object selectReportFromSideNavigation( WebDriver driver, String reportName ) throws InterruptedException {
        Object returnPage = null;
        String reportNameToSwitch = String.valueOf( reportName );
        Log.message( "Report Name To Switch : " + reportNameToSwitch );
        String btnCumulativePerformanceshadowDOM[] = { "cel-side-navigation", "document.querySelector('cel-side-navigation').shadowRoot.querySelector('cel-side-item[data-label=\"" + reportNameToSwitch + "\"]').shadowRoot.querySelector('button')" };
        WebElement webElement = ShadowDOMUtils.retryAndGetWebElement( driver, btnCumulativePerformanceshadowDOM[0], btnCumulativePerformanceshadowDOM[1] );
        SMUtils.click( driver, webElement );
        // Returning Respective Reports Page Based On The Selection
        switch ( reportNameToSwitch ) {
            case "AREAS_FOR_GROWTH":
                returnPage = new AreasForGrowthReport( driver ).get();
                break;
            case "Cumulative Performance":
                returnPage = new CumulativePerformanceReport( driver ).get();
                break;
            case "Last Session":
                returnPage = new LastSessionReport( driver ).get();
                break;
            case "Student Performance":
                returnPage = new StudentPerformanceReport( driver ).get();
                break;
            case "Prescriptive Scheduling":
                returnPage = new PerspectiveSchedulingReport( driver ).get();
                break;
            case "System Enrollment and Usage":
                returnPage = new SystemEnrollmentAndUsageReport( driver ).get();
                break;
        }
        ;
        return returnPage;
    }

    /**
     * @author sakthi.sasi Used to perform Organization choosing
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public AreasForGrowthReport chooseOrganization( WebDriver driver, String orgId ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.nap( 5 );
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, drpOrganizationOptions[0], drpOrganizationOptions[1] );
        drpdwnElement.click();
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelectValue( driver, drpdwnElement, orgId, "Choosing Organization" );
        return this;

    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public AreasForGrowthReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtAreasForGrowthReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to expand optional filters
     * 
     * @param driver
     * @return
     */
    public AreasForGrowthReport clickOptionalFilters( WebDriver driver ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtAreasForGrowthReportHeader );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        SMUtils.click( driver, txtOptionalFilter );
        return this;

    }

    /**
     * @author sakthi.sasi Used to verify the Organization ID's
     * 
     * @param driver
     * @param districtAdmin
     * @param smUrl
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyOrgIds( WebDriver driver, Admins districtAdmin, String smUrl ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.compareOrganizationElements( driver, districtAdmin, smUrl ), "Organization List Matches", "Organization List doesn't Match" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Organization is available or not
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public AreasForGrowthReport verifyOrg( WebDriver driver, String orgName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.validateOrganizationDropdownValue( driver, orgName ), "Organization is Available", "Organization is not Available" );
        return this;
    }

    /**
     * @author raseem.mohamed Used to verify the Courses
     * @param driver
     * @param admin
     * @param orgIds
     * @param SubjectName
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyCourses( WebDriver driver, Admins admin, List<String> orgIds, String SubjectName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expcourseNames = new ArrayList<String>();
        List<String> actualCourseNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.COURSES );
        Log.message( "Actual Courses Name From UI : " + actualCourseNames );
        if ( SubjectName.equalsIgnoreCase( "reading" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "areasForGrowth", "2" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        } else if ( SubjectName.equalsIgnoreCase( "math" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "areasForGrowth", "1" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        }

        Log.message( "Courses Name From UI : " + actualCourseNames );
        int actualSize = actualCourseNames.size();
        int expectSize = expcourseNames.size();
        String actual = String.valueOf( actualSize );
        String expect = String.valueOf( expectSize );
        boolean validate = false;
        if ( actualSize == expectSize ) {
            for ( int i = 0; i < actualCourseNames.size(); i++ ) {
                validate = actualCourseNames.get( i ).contains( expcourseNames.get( i ) );
                if ( validate == false ) {
                    Log.softAssertThat( validate, "Course " + actualCourseNames + "Value Is Matching", "Course" + actualCourseNames + " Value Is Not Matching" );
                }
            }
        }
        Log.assertThat( actual.equalsIgnoreCase( expect ), "Passed : Courses Are Matching", "Failed : Courses Are Not Matching" );
        return this;
    }

    /**
     * @author raseem.mohamed Used to verify the Teachers in UI matches the
     *         Teaches fetched from RBS
     * 
     * @param driver
     * @param admin
     * @param orgIds
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyTeachers( WebDriver driver, Admins admin, List<String> orgIds ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        List<String> actualTeacherNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.TEACHERS );
        System.out.println( "Actual teacher Name" + actualTeacherNames );
        List<String> actualTeacherID = reportsFilterUtils.getAllTeacherID( reportsFilterUtils.TEACHERS );
        System.out.println( actualTeacherID );
        List<String> expTeacherID = reportsFilterUtils.getTeacherId( driver, admin, orgIds );
        reportsFilterUtils.setValuesForDropdown( reportsFilterUtils.TEACHERS, actualTeacherNames.subList( 1, 3 ) );
        Log.softAssertThat( expTeacherID.containsAll( actualTeacherID ), "Teachers are matching", "Teachers are not matching" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Groups in UI matches the Group
     *         fetched from RBS
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyGroup( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        List<String> actualTeacherNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.TEACHERS );
        reportsFilterUtils.setValuesForDropdown( reportsFilterUtils.TEACHERS, actualTeacherNames.subList( 1, 3 ) );
        expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getGroupIds() );
        List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getGroupNames();
        Collections.sort( expgroupNames );
        Collections.sort( allValuesFromGroupsDropdown );
        Log.softAssertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Grades
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyGrades( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> allValuesFromGradesDropdown = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.GRADES );
        Log.assertThat( allValuesFromGradesDropdown.containsAll( Constants.Students.ALL_GRADES ), "The Grade Values is matching", "The Grade Values is matching" );
        reportsFilterUtils.clickSelectAll( reportsFilterUtils.GRADES );
        Log.testCaseInfo( "Verify if the Grade All is selected when ticked All option" );
        Log.softAssertThat( reportsFilterUtils.isSelectAllChecked( reportsFilterUtils.GRADES ), "The Select All option is Checked", "The Select All option is not Checked" );
        reportsFilterUtils.clickGradesDropdown();
        return this;
    }
}
