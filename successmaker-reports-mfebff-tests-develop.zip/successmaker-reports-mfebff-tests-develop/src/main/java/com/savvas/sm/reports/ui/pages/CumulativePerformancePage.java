package com.savvas.sm.reports.ui.pages;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.Keys;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportSubHeader;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.utils.SMUtils;

public class CumulativePerformancePage extends LoadableComponent<CumulativePerformancePage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    @FindBy ( tagName = "h1" )
    WebElement pageTitle;

    @FindBy ( css = "cel-tab-panel.tab-panel" )
    WebElement togglebutton;

    @FindBy ( css = "cel-tab-panel.tab-panel-cumulativePerformance" )
    WebElement cprAggregatetoggle;

    @FindBy ( css = "cumulative-performance > cel-accordion-item" )
    WebElement optionalFilterRoot;

    @FindBy ( css = "cumulative-performance > cel-accordion-item > section > section> div > cel-accordion-item" )
    WebElement studentDemographicsrRoot;

    @FindBy ( css = "organizations-filter > div > div > multi-select > cel-multi-select" )
    WebElement ddOorgIdRoot;

    @FindBy ( css = "#teachers > cel-multi-select" )
    WebElement ddTeacherRoot;

    @FindBy ( css = "div.spinner-container" )
    WebElement Spinner;

    @FindBy ( css = "student-demographics-filter div label" )
    public List<WebElement> demographicsDropdownLabel;

    @FindBy ( css = "section.additional-filters-section > div > checkbox-item > cel-checkbox-item" )
    WebElement checkBoxParent;

    @FindBy ( css = "cel-side-navigation[class='side-nav-bar hydrated']" )
    WebElement sideNavigationRoot;

    @FindBy ( css = "cel-single-select.hydrated" )
    List<WebElement> singleSelectDropdowns;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    WebElement maskStudentRadio;
    
    //Nishanth
    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> selectedOptions;
    
    @FindBy ( css = "table.areas-for-growth" )
    WebElement reportTable;
    
     @FindBy ( css = "h2.header" )
    WebElement reportHeader;
    
     @FindBy ( css = "span.pagination-text-suffix" )
    WebElement totalPageCount;
    
     @FindBy ( css = "dl.info dd" )
    List<WebElement> subHeaderFieldValues;
     
     @FindBy ( css = "cel-button.next-btn" )
     WebElement nextBtnRoot;
     
     @FindBy ( css = "p.table-note" )
     WebElement endTableNotes;

     @FindBy ( css = "cel-button" )
     WebElement runReportRoot;
          
     @FindBy ( css = "report-grid tbody td:nth-child(1)" )
     public List<WebElement> outputStudentName;

     @FindBy ( css = "report-grid tbody td:nth-child(3)" )
     public List<WebElement> outputCurentCourseLevel;
     
     @FindBy ( css = "report-grid tbody td:nth-child(7)" )
     public List<WebElement> outputTotalSessions;

     @FindBy ( css = "report-grid tbody td:nth-child(8)" )
     public List<WebElement> outputExercisesCorrect;

     @FindBy ( css = "report-grid tbody td:nth-child(9)" )
     public List<WebElement> outputExercisesAttempted;

     
    // ****Child Elements****
    private String childSubNavigationMenu = "cel-side-item[data-label='Recent Sessions']";
    private String childSubNavigationButton = "button";

    /******************* Child Elements ******************************/

    private static String cprAggregateChild = "div.tab-container button.not-selected";
    private static String cprChild = "div.tab-container button.selected";

    private int counter = 0;

    private String button = "button";
    private String headerCSS = "h2.header";
    private String teacherLabelCSS = "dl.info dd:nth-child(4)";
    private String groupLabelCSS = "dl.info dd:nth-child(8)";
    private String dateSessionCSS = "dl.info dd:nth-child(10)";
    private String totalPageCountCSS = "header-pagination > div > span.pagination-text-suffix";
    private String assignmentCSS = "h3.assignment-name";
    public String studentNameCSS = "#table > tbody > tr  > td:nth-child(1) > div";
    private String nextBtnCSS = "cel-button.next-btn";

    public static String DISABLITY_STATUS = "#disability-status";
    public static String ENGLISH_LANGUAGE_PROFICIENCY = "#english-language-proficiency";
    public static String GENDER = "#gender";
    public static String MIGRANT_STATUS = "#migrant-status";
    public static String RACE = "#race";
    public static String ETHINICIY = "#ethnicity";
    public static String SOCIO_ECONOMIC_STATUS = "#socioeconomic-status";
    public static String SPECIAL_SERVICES = "#special-services";
    public static List<String> STUDENT_DEMOGRAPHICS_DROPDOWNS = new ArrayList<String>( Arrays.asList( DISABLITY_STATUS, ENGLISH_LANGUAGE_PROFICIENCY, GENDER, RACE, ETHINICIY, SOCIO_ECONOMIC_STATUS, SPECIAL_SERVICES ) );
    public static String maskStudentCheckBoxCSS = "label > input[type=checkbox]";

    public static String TEACHERS = "#teachers";
    public static String GROUPS = "#groups";
    public static String GRADES = "#grades";
    public static String COURSES = "#courses";

    public static String ORGANIZATIONS = "#organization > div > cel-single-select";
    public static String SUBJECT = "#subject > div > cel-single-select";
    public static String ADDITIONAL_GROUPING = "#additional-grouping";
    public static String DISPLAY = "#display";
    public static String SORT = "#sort";

    public static List<String> OPTIONAL_FILTER_STATIC_DROPDOWNS = new ArrayList<String>( Arrays.asList( SUBJECT, ADDITIONAL_GROUPING, DISPLAY, SORT ) );

    public static String DROPDOWN_GRADNPARENT = "%s > cel-multi-select";
    public static String DROPDOWN_LIST_Root1 = "#dropdown > cel-multi-checkbox.multi-checkbox.hydrated";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1 = "#dropdown > cel-single-select-item";

    public static String DROPDOWN_DATA_ROOT = "div > div.bottom-container > div > cel-checkbox-item";
    public static String DROPDOWN_GRAND_CHILD = "label > span";
    public static String DROPDOWN_LIST_Root2 = "div > div.bottom-container div";
    public static String DROPDOWN_PARENT1 = "div button cel-icon";
    public static String DIV = "div";
    public static String LABEL = "label";

    public static String SELECT_ALL_ROOT2 = "div > div.header-container.item-container.border-bottom > cel-checkbox-item";
    public static String SELECT_ALL_ROOT3 = "label > input[type=checkbox]";
    public static String SELECT_ALL_PARTIAL_SELECT = "label > input.indeterminate";
    
  //NK CPR
    String currentCourseLevel = "//div[contains(text(), '%s')]";
    String parentCurrentCourseLevel = "/parent::td/following-sibling::td[%s]";
    String tabledata = "td";
   

    public static List<String> SINGLE_SELECT_DROPDOWNS = new ArrayList<String>( Arrays.asList( ORGANIZATIONS, SUBJECT, ADDITIONAL_GROUPING, DISPLAY, SORT ) );
    public static List<String> SORT_DROPDOWN_VALUES = new ArrayList<>( Arrays.asList( "School", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent", "Total Sessions", "Exercises Correct", "Exercises Attempted",
            "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );
    private String selectedButton = "button.selected";
    private static String runReportChild = "button.button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public CumulativePerformancePage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "Cumulative Performance Page loaded successfully." );
        } else {
            Log.fail( "Cumulative Performance Page not loaded successfully." );
        }

    }

    /**
     * navigate To CPA Report
     * 
     */

    public CumulativePerformanceAggregatePage navigateToCPAReport() {
        // TODO Auto-generated method stub
        Log.message( "Clicking on the Cumulative Performance Aggregate element in sub-navigation" );
        SMUtils.getWebElementsDirect( driver, togglebutton, button ).stream().filter( element -> element.getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE_AGGREGATE ) ).forEach( element -> SMUtils.clickJS( driver, element ) );
        return new CumulativePerformanceAggregatePage( driver ).get();

    }

    public CumulativePerformanceAggregatePage navigateToCPReport() {
        // TODO Auto-generated method stub
        Log.message( "Clicking on the Cumulative Performance Aggregate element in sub-navigation" );
        SMUtils.getWebElementsDirect( driver, togglebutton, button ).stream().filter( element -> element.getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ) ).forEach( element -> SMUtils.clickJS( driver, element ) );
        return new CumulativePerformanceAggregatePage( driver ).get();

    }

    /**
     * 
     * @return
     */
    public CumulativePerformanceAggregatePage getCPRAggregatePage() {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprAggregateChild );
        SMUtils.clickJS( driver, actualElement );
        Log.message( "Click Cumulative Performance Aggregate report" );

        return new CumulativePerformanceAggregatePage( driver ).get();
    }

    /**
     * CPR color
     * 
     * @return
     * @throws Exception
     */
    public boolean isCPRColorDisplay() throws Exception {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprChild );
        Log.message( "Verifying CPR  color is displaying" );
        return SMUtils.checkColor( actualElement, ReportsUIConstants.COLOR_CPRAGGREGATE );
    }

    /**
     * Get CP header text
     * 
     * @return
     */
    public String getCPRHeading() {
        SMUtils.waitForElement( driver, pageTitle, 20 );
        Log.message( "Validating CPD header text" );
        return pageTitle.getText().trim();
    }

    /**
     * Get CPR aggregate page
     * 
     * @return
     */
    public boolean isCPRSelected() {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprChild );
        Log.message( "Verifying Cumulative performance aggregate is present and selected" );
        return SMUtils.isElementPresent( actualElement );

    }

    /**
     * Return true if the Dropdown is expanded
     * 
     * @param dropdown
     * @return
     */
    public boolean isDropdownExpanded( String dropdown ) {
        WebElement rootElement = null;
        WebElement lisRoot = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
        }
        return lisRoot != null ? true : false;
    }

    /**
     * Expand Dropdown
     * 
     * @param dropdownName
     */
    public void expanDropdown( String dropdownName ) {
        if ( !isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
            SMUtils.nap( 2 ); // wait for dropdown load

            Log.message( "Dropdown expanded: " + dropdownName );
        } else {
            Log.message( dropdownName + " Dropdown already expanded" );
        }
    }

    /**
     * Close dropdown Element
     * 
     * @param dropdownName
     */
    public void closeDropdown( String dropdownName ) {
        if ( isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
        } else {
            Log.message( dropdownName + " Dropdown already closed" );
        }

        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }

    }

    /**
     * It will return the Dropdown Values
     * 
     * @param dropdown
     * @return
     */
    public List<String> getAllValuesFromDropdown( String dropdown ) {
        final List<String> values = new ArrayList<String>();
        WebElement rootElement = null;
        WebElement parent = null;
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> elements = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            values.addAll( elements.stream().map( element -> SMUtils.getWebElementDirect( driver, element, LABEL ).getAttribute( "data-label" ).trim() ).collect( Collectors.toList() ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            SMUtils.nap( 2 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_Root2 );
            values.addAll( element.stream().map( ddElement -> ddElement.getText().trim() ).collect( Collectors.toList() ) );
        }
        closeDropdown( dropdown );
        return values;
    }

    /***
     * It will opend and the Tick the Values in the Dropdown With options and
     * close the dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void setValuesForDropdown( String dropdownName, List<String> options ) {
        expanDropdown( dropdownName );
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            selectOptionsFromDropdown( dropdownName, options );
        } else {
            unSelectAll( dropdownName );
            selectOptionsFromDropdown( dropdownName, options );
            closeDropdown( dropdownName );
        }

        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }
    }

    /**
     * Select the options in the Dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void selectOptionsFromDropdown( String dropdownName, List<String> options ) {
        List<WebElement> elements = getAllDropdownElements( dropdownName );
        if ( elements.size() > 0 ) {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                WebElement option = elements.stream().filter( element -> options.contains( element.getText().trim() ) ).findFirst().orElse( null );
                SMUtils.scrollDownIntoViewElement( driver, option );
                String optionName = option.getText().trim();
                SMUtils.click( driver, option );
                Log.message( optionName + " is ticked" );
            } else {
                elements.stream().filter( element -> options.contains( element.getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollDownIntoViewElement( driver, element );
                    SMUtils.click( driver, element );
                    Log.message( element.getText().trim() + " is ticked" );
                } );
                ;
            }

        } else {
            Log.message( "Issue in Selecting values for " + dropdownName );
        }
    }

    /**
     * Return true if Organization Dropdown is expanded
     * 
     * @return
     */
    public boolean isOrganizaionDropdownExpanded() {
        return isDropdownExpanded( ORGANIZATIONS );
    }

    public void expandOrganizationDropdown() {
        if ( !isOrganizaionDropdownExpanded() ) {
            expanDropdown( ORGANIZATIONS );
        } else {
            Log.message( "Organization Dropdown is Expanded" );
        }
    }

    /**
     * This will click and Set the values in Organization Dropdown and close and
     * wait for sppinner to load
     * 
     * @param orgName
     */
    public void setOrganizationsValue( String orgName ) {
        expandOrganizationDropdown();
        setValuesForDropdown( ORGANIZATIONS, new ArrayList<String>( Arrays.asList( orgName ) ) );
        waitForSpinnerToLoadAndDisppear();

        if ( SMUtils.waitForLocator( driver, By.cssSelector( "reports-wrapper > div > img" ), 2 ) ) {
            counter++;
            SMUtils.sendF5Key( driver );
            waitForSpinnerToLoadAndDisppear();
            setOrganizationsValue( orgName );
        }
        counter = 0;
    }

    /**
     * Click optional Filter in Report
     */
    public void clickOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }

    /**
     * Click Student Demographics in Report
     */
    public void clickStudentDemographics() {
        SMUtils.waitForElement( driver, studentDemographicsrRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, studentDemographicsrRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Student Demographics is clicked" );
    }

    /**
     * To Click Org Dropdown
     */
    public void clickOrganizationDropdown() {
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        String query = "return document.querySelector('organizations-filter > div > div > multi-select > cel-multi-select').shadowRoot.querySelector('div > button > cel-icon').shadowRoot.querySelector('div');";
        WebElement DropdownElement = (WebElement) javascriptExecutor.executeScript( query );
        SMUtils.scrollIntoView( driver, DropdownElement );
        SMUtils.click( driver, DropdownElement );
        Log.message( "Orgaanization Dropdown is clicked" );
        SMUtils.nap( 2 ); // nap for Organization dropdown

    }

    /**
     * Get all the Org Dropdown elements
     * 
     * @return
     */
    public List<WebElement> getAllOrganizationDropdownElements() {
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > cel-single-select-item');var labels =[]; root.forEach ( ele => { labels.push(ele.shadowRoot.querySelector('label'))}); { return labels ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    /**
     * To get the organization Details in the Dropdown From click dropdown and
     * get the details and close dropdown
     * 
     * @return
     */
    public HashMap<String, String> getOrganizationDetails() {
        Log.message( "Getting Organization Details..." );
        expandOrganizationDropdown();
        HashMap<String, String> details = new HashMap<String, String>();
        List<WebElement> allOrganizationDropdownElements = getAllOrganization();
        allOrganizationDropdownElements.stream().forEach( elements -> {
            details.put( elements.getAttribute( "data-label" ), elements.getAttribute( "for" ) );
        } );
        closeDropdown( ORGANIZATIONS );
        Log.message( "Organization details fetched!" );
        return details;
    }

    /**
     * Get OrgIds of the Organization Dropdown
     * 
     * @return
     */
    public List<String> getOrganizationIds() {
        Log.message( "Getting Organization Details..." );
        expandOrganizationDropdown();
        List<String> details = new ArrayList<>();
        List<WebElement> allOrganizationDropdownElements = getAllOrganizationDropdownElements();
        allOrganizationDropdownElements.stream().forEach( elements -> {
            details.add( elements.getAttribute( "for" ) );
        } );
        closeDropdown( ORGANIZATIONS );
        Log.message( "Organization details fetched!" );
        return details;
    }

    /**
     * Get the organization dropdown values
     */
    public List<String> getOrganizationNames() {
        return new ArrayList<String>( getOrganizationDetails().keySet() );

    }

    /**
     * To get the details of the TEacher dropdown
     * 
     * @return
     */
    public List<String> getTeacherIds() {
        return new ArrayList<String>( getDropdownsDataDetails( TEACHERS ).keySet() );
    }

    public List<String> getTeacherUserNames() {
        HashMap<String, String> dropdownsDataDetails = getDropdownsDataDetails( TEACHERS );
        return dropdownsDataDetails.keySet().stream().map( key -> dropdownsDataDetails.get( key ) ).collect( Collectors.toList() );
    }

    /**
     * To get the data for the Dropdown data details From expand and getting and
     * close dropdown
     * 
     * @param dropdownName
     * @return
     */
    public HashMap<String, String> getDropdownsDataDetails( String dropdownName ) {
        HashMap<String, String> details = new HashMap<String, String>();
        WebElement rootElement = null;
        expanDropdown( dropdownName );

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            List<WebElement> ddValues = SMUtils.getWebElementsDirect( driver, parent, LABEL );
            ddValues.stream().forEach( eachElement -> {
                details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
            } );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_DATA_ROOT );
            element.stream().forEach( eachElement -> {
                details.put( eachElement.getAttribute( "data-identifier" ), eachElement.getAttribute( "data-label" ) );
            } );
        }
        closeDropdown( dropdownName );
        return details;
    }

    public ArrayList<String> getGroupIds() {
        return new ArrayList<String>( getDropdownsDataDetails( GROUPS ).keySet() );
    }

    public List<String> getGroupNames() {
        HashMap<String, String> dropdownsDataDetails = getDropdownsDataDetails( GROUPS );
        return dropdownsDataDetails.keySet().stream().map( key -> dropdownsDataDetails.get( key ) ).collect( Collectors.toList() );
    }

    /**
     * Wait for the spinner to Load and Wait for disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }

    /**
     * To return the dropdown valuses that are checked
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getCheckedValuesForDropdown( String dropdownName ) {
        expanDropdown( dropdownName );
        ArrayList<String> filteredValue = new ArrayList<String>();
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            WebElement checkMark = driver.findElement( By.cssSelector( checkMarkCCSS ) ).findElement( By.xpath( "./.." ) );
            String value = checkMark.getAttribute( "data-label" );
            filteredValue.add( value );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_Root2 );
            element.stream().forEach( eachElement -> {
                WebElement colorChecking = SMUtils.getWebElementDirect( driver, eachElement.findElement( By.cssSelector( "cel-checkbox-item" ) ), SELECT_ALL_ROOT3 );
                try {
                    if ( SMUtils.checkBackgroundColor( colorChecking, selectAllCheckBoxColor ) ) {
                        filteredValue.add( eachElement.findElement( By.cssSelector( "cel-checkbox-item" ) ).getAttribute( "data-label" ) );
                    }
                } catch ( Exception e ) {}
            } );
        }

        closeDropdown( dropdownName );
        return filteredValue;
    }

    /**
     * Click Select all options in the Dropdown
     * 
     */
    public void clickSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( !SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
            if ( !verifySelectAllCheckBoxColor( dropdownName ) ) {
                SMUtils.click( driver, element );
            } else {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
            }
            Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
            closeDropdown( dropdownName );
        }
    }

    /**
     * Unselect All options in Dropdown
     * 
     * @param dropdownName
     */
    public void unSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        }
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
        if ( verifySelectAllCheckBoxColor( dropdownName ) ) {
            SMUtils.click( driver, element );
        } else {
            SMUtils.click( driver, element );
            SMUtils.click( driver, element );
        }
        Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
        closeDropdown( dropdownName );
    }

    public static String selectAllCheckBoxColor = "#006be0";

    /**
     * Return true if the checkBox is selected
     * 
     * @param dropdownName
     * @return
     */
    public boolean verifySelectAllCheckBoxColor( String dropdownName ) {
        WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_ROOT3 );
        String color = Color.fromString( element.getCssValue( "background-color" ) ).asHex();
        return ( color.equals( selectAllCheckBoxColor ) ) ? true : false;
    }

    /**
     * Return true if Select All option is Selected
     * 
     * @param dropdown
     * @return
     */
    public boolean isSelectAllChecked( String dropdown ) {
        expanDropdown( dropdown );
        boolean flag = false;
        if ( verifySelectAllCheckBoxColor( dropdown ) ) {
            WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_PARTIAL_SELECT );
            if ( element == null ) {
                flag = true;
            } else {
                flag = false;
            }
        }
        closeDropdown( dropdown );
        return flag;
    }

    public void clickDisabilityStatusDropdown() {
        expanDropdown( DISABLITY_STATUS );
    }

    public void clickGradesDropdown() {
        expanDropdown( GRADES );
    }

    public void clickEthinicityDropdown() {
        expanDropdown( ETHINICIY );
    }

    public void clickRaceDropdown() {
        expanDropdown( RACE );
    }

    public void clickGenderDropdown() {
        expanDropdown( GENDER );
    }

    public void clickEnglishProficiencyDropdown() {
        expanDropdown( ENGLISH_LANGUAGE_PROFICIENCY );
    }

    public void clickMigrantStatusDropdown() {
        expanDropdown( MIGRANT_STATUS );
    }

    public void clickSocioEconomicDropdown() {
        expanDropdown( SOCIO_ECONOMIC_STATUS );
    }

    public void clickSpecialServicesDropdown() {
        expanDropdown( SPECIAL_SERVICES );
    }

    /**
     * To get the Dropdown Elements
     * 
     * @param dropdown
     * @return
     */
    public List<WebElement> getAllDropdownElements( String dropdown ) {
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> parent = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            List<WebElement> ddElements = new ArrayList<WebElement>();
            parent.stream().forEach( element -> ddElements.add( SMUtils.getWebElementDirect( driver, element, LABEL ) ) );
            return ddElements;
        } else if ( dropdown.equals( ORGANIZATIONS ) ) {
            return getAllOrganizationDropdownElements();
        } else {
            final List<WebElement> streamList = new ArrayList<WebElement>();
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> dataParent = SMUtils.getWebElements( driver, parent, DROPDOWN_DATA_ROOT );
            dataParent.stream().forEach( ddElement -> {
                streamList.add( SMUtils.getWebElementDirect( driver, ddElement, DROPDOWN_GRAND_CHILD ) );
            } );
            return streamList;
        }
    }

    /**
     * click checkbox Mask Student CheckBox
     */
    public void clickMaskStudentCheckBox() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }

    /**
     * return true if check box is checked For MaskStudentDisplay
     * 
     * @return
     */
    public boolean isMaskStudentisChecked() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        try {
            if ( SMUtils.checkBackgroundColor( element, selectAllCheckBoxColor ) ) {
                return true;
            } else {
                return false;
            }
        } catch ( Exception e ) {
            return false;
        }
    }

    @FindBy ( css = "student-demographics-filter > div div" )
    List<WebElement> demographicsHeaader;
    public static List<String> demographicsHeaders = new ArrayList<String>( Arrays.asList( "Disability Status", "English Language Proficiency", "Gender", "Migrant Status", "Race", "Ethnicity", "Socioeconomic Status", "Special Services" ) );

    /**
     * Verify the Headers in demographics Dropdown
     * 
     * @return
     */
    public boolean verifyStudentDemographicsHeader() {
        List<String> header = new ArrayList<>();
        demographicsHeaader.stream().forEach( element -> {
            header.add( element.findElement( By.cssSelector( LABEL ) ).getText().trim() );
        } );
        return SMUtils.compareTwoList( header, demographicsHeaders );
    }

    /*** Calendar Web Elements ***/

    public static String checkMarkCCSS = "checkmark-icon cel-color cel-color-disabled icon-small hydrated";
    public static String RADIO_BUTTON_ROOT1 = "cel-radio-button-group";
    public static String RADIO_BUTTON_ROOT2 = "div > div > cel-radio-button:nth-child(%s)";
    public static String ALL_DATES_CSS = "#all";
    public static String SELECTED_DATE_RANGES_CSS = "#dates";

    /**
     * click the Radio Button All Dates
     */
    public void clickAllDatesButton() {
        WebElement root = driver.findElement( By.cssSelector( RADIO_BUTTON_ROOT1 ) );
        WebElement element = SMUtils.getWebElementDirect( driver, root, RADIO_BUTTON_ROOT2.format( RADIO_BUTTON_ROOT2, "1" ), ALL_DATES_CSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked radio button : All Dates" );
    }

    /**
     * Click the Radio Button - Selected Date Ranges
     */
    public void clickSelectedDateRangeButton() {
        WebElement root = driver.findElement( By.cssSelector( RADIO_BUTTON_ROOT1 ) );
        WebElement element = SMUtils.getWebElementDirect( driver, root, RADIO_BUTTON_ROOT2.format( RADIO_BUTTON_ROOT2, "2" ), SELECTED_DATE_RANGES_CSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked radio button : Selected Date Range" );
        SMUtils.nap( 5 );
    }

    public static String CALENDER_ICON_ROOT1 = "cel-date-range";
    public static String CALENDER_ICON_FROM_ROOT2 = "cel-date-input.date-input.from.hydrated";
    public static String CALENDER_ICON_TO_ROOT2 = "cel-date-input.date-input.to.hydrated";
    public static String CALENDER_ICON_ROOT3 = "cel-icon-button";
    public static String CALENDER_ICON_ROOT4 = "button > cel-icon";
    public static String CalendarNavIcon = "document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.date-input.%s.hydrated').shadowRoot.querySelector('cel-date-popup').shadowRoot.querySelector('cel-calendar').shadowRoot.querySelector('div.calendar-header > cel-icon-button:nth-child(%s)').shadowRoot.querySelector('button > cel-icon').shadowRoot.querySelector('div').click()";

    /**
     * Click Start Calendar Icon
     */
    public void clickStartDateCalendar() {
        WebElement element = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( CALENDER_ICON_ROOT1 ) ), CALENDER_ICON_FROM_ROOT2, CALENDER_ICON_ROOT3, CALENDER_ICON_ROOT4, DIV );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked  Calendare Icon - From" );
        SMUtils.nap( 2 ); // wait for calendar popup to load
    }

    /**
     * Click Calendar Icon End Date
     */
    public void clickEndDateCalender() {
        WebElement element = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( CALENDER_ICON_ROOT1 ) ), CALENDER_ICON_TO_ROOT2, CALENDER_ICON_ROOT3, CALENDER_ICON_ROOT4, DIV );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked  Calendare Icon - To" );
        SMUtils.nap( 2 ); // wait for calendar popup to load
    }

    /**
     * Move Left navigation in the start Date Calendar
     */
    public void moveLeftinStartDateCalendar() {
        String query = CalendarNavIcon.format( CalendarNavIcon, "from", "1" );
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript( query );

    }

    /**
     * Move right navigation in the start Date Calendar
     */
    public void moveRightinStartDateCalendar() {
        String query = CalendarNavIcon.format( CalendarNavIcon, "from", "3" );
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript( query );
    }

    /**
     * Move left navigation in the End Date Calendar
     */
    public void moveLeftinEndDateCalendar() {
        String query = CalendarNavIcon.format( CalendarNavIcon, "to", "1" );
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript( query );

    }

    /**
     * Move right navigation in the End Date Calendar
     */
    public void moveRightinEndDateCalendar() {
        String query = CalendarNavIcon.format( CalendarNavIcon, "to", "3" );
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript( query );
    }

    public static String calendarDatesQuery = "var root1 = document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.date-input.%s.hydrated').shadowRoot.querySelector('cel-date-popup').shadowRoot.querySelector('cel-calendar').shadowRoot.querySelectorAll('div.calendar-container div.square cel-calendar-date');var vl =[];root1.forEach ( ele => { if ( ele.getAttribute('data-day')!=null ) {vl.push(ele);}}); { return vl};";

    /**
     * Get the Date Value WebElements in the Calendar popup
     * 
     * @param calendayType
     * @return
     */
    public List<WebElement> getAllWebElementForCalendarDates( String calendayType ) {
        String query = calendarDatesQuery.format( calendarDatesQuery, calendayType );
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        return (List<WebElement>) javascriptExecutor.executeScript( query );
    }

    /**
     * Click Day value in the Start Date calendar popup
     * 
     * @param DayNo
     */
    public void clickDayOnStartDateCalendar( String DayNo ) {
        WebElement date = getAllWebElementForCalendarDates( "from" ).stream().filter( element -> element.getAttribute( "data-day" ).equals( DayNo ) ).findFirst().orElse( null );
        SMUtils.scrollIntoView( driver, date );
        SMUtils.click( driver, date );
        Log.message( "Clicked Day on the Start Date Calendar Popup: " + DayNo );
    }

    /**
     * Click Day value in the End Date calendar popup
     * 
     * @param DayNo
     */
    public void clickDayOnEndDateCalendar( String DayNo ) {
        WebElement date = getAllWebElementForCalendarDates( "to" ).stream().filter( element -> element.getAttribute( "data-day" ).equals( DayNo ) ).findFirst().orElse( null );
        SMUtils.scrollIntoView( driver, date );
        SMUtils.click( driver, date );
        Log.message( "Clicked Day on the End Date Calendar Popup: " + DayNo );
    }

    public static String datePickedValues = "return document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.date-input.%s.hydrated').shadowRoot.querySelector('#celDateInput').value;";

    /**
     * Get the Start Dates and End Dates from the Selected Date Range Fields
     * 
     * @return
     */
    public List<String> getSelectedDatesFromCalendar() {
        String fromDate = calendarDatesQuery.format( datePickedValues, "from" );
        String toDate = calendarDatesQuery.format( datePickedValues, "to" );
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<String> dates = new ArrayList<>();
        dates.add( (String) javascriptExecutor.executeScript( fromDate ) );
        dates.add( (String) javascriptExecutor.executeScript( toDate ) );
        return dates;
    }

    /*** End of Web Elements ***/

    public List<WebElement> getAllOrganization() {
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > li > label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    public boolean selectOrganization() {
        expandOrganizationDropdown();
        List<WebElement> ddElements = getAllOrganization();
        SMUtils.clickJS( driver, ddElements.get( 0 ) );
        closeDropdown( ORGANIZATIONS );
        return true;
    }

    public boolean selectOrganization( String name ) {
        expanDropdown( ORGANIZATIONS );
        List<WebElement> ddElements = getDropdownElement( "organization" );
        for ( WebElement element : ddElements ) {
            if ( element.getAttribute( "data-label" ).equals( name ) ) {
                SMUtils.clickJS( driver, element );
                break;
            }
        }
        closeDropdown( ORGANIZATIONS );
        return true;
    }

    public boolean selectSubject( String name ) {
        expanDropdown( SUBJECT );
        List<WebElement> ddElements = getDropdownElement( "subject" );
        for ( WebElement element : ddElements ) {
            if ( element.getAttribute( "data-label" ).equals( name ) ) {
                SMUtils.clickJS( driver, element );
                break;
            }
        }
        closeDropdown( SUBJECT );
        return true;
    }

    public List<WebElement> getDropdownElement( String dropdownName ) {
        String query = "var root = document.querySelector('#" + dropdownName + " > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > li > label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    public List<WebElement> getDropdownElementFilter( String dropdownName ) {
        String query = "var root = document.querySelector('#" + dropdownName + "').shadowRoot.querySelectorAll('#dropdown > li > label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    public boolean checkReportHeaderAfterRun() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( headerCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( headerCSS ) ), 5000 );
            WebElement heading = driver.findElement( By.cssSelector( headerCSS ) );
            return heading.getText().equals( "Cumulative Performance" );
        } catch ( Exception e ) {
            Log.message( "Header not found" );
        }
        return false;
    }

    public boolean checkTeacherAll() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( teacherLabelCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( teacherLabelCSS ) ), 5000 );
            WebElement teacher = driver.findElement( By.cssSelector( teacherLabelCSS ) );
            return teacher.getText().equals( " All " );
        } catch ( Exception e ) {
            Log.message( "Teacher data not found" );
        }
        return false;
    }

    public boolean checkGroupAll() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( groupLabelCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( groupLabelCSS ) ), 5000 );
            WebElement teacher = driver.findElement( By.cssSelector( groupLabelCSS ) );
            return teacher.getText().equals( " All " );
        } catch ( Exception e ) {
            Log.message( "Group data not found" );
        }
        return false;
    }

    public boolean checkSessionDateAll() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( dateSessionCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( dateSessionCSS ) ), 5000 );
            WebElement teacher = driver.findElement( By.cssSelector( dateSessionCSS ) );
            return teacher.getText().equals( " All Session Dates " );
        } catch ( Exception e ) {
            Log.message( "Group data not found" );
        }
        return false;
    }

    /**
     * navigate To CP Report
     * 
     */

    public CumulativePerformancePage isNavigateToCPReport() {
        // TODO Auto-generated method stub
        Log.message( "Clicking on the Cumulative Performance element in sub-navigation" );
        SMUtils.getWebElementsDirect( driver, togglebutton, button ).stream().filter( element -> element.getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ) ).forEach( element -> SMUtils.clickJS( driver, element ) );
        return new CumulativePerformancePage( driver ).get();

    }

    public boolean isCumulativePerformanceSubNavigationSelected() {
        Log.message( "Verifing CumulativePerformance Sub navigation is selected" );
        WebElement rootElement = SMUtils.getWebElement( driver, sideNavigationRoot, childSubNavigationMenu );
        WebElement cumulativePerformanceSubNav = SMUtils.getWebElement( driver, rootElement, childSubNavigationButton );
        return cumulativePerformanceSubNav.getAttribute( "class" ).contains( "side-item side-item-active" );
    }

    public int countPage() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( studentNameCSS ), 10000 );
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( totalPageCountCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( totalPageCountCSS ) ), 5000 );
            WebElement countTxt = driver.findElement( By.cssSelector( totalPageCountCSS ) );
            return Integer.parseInt( countTxt.getText().replace( "of ", "" ) );
        } catch ( Exception e ) {
            Log.message( "Page Count found" );
        }
        return 0;
    }

    public String getAssignmentName() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( assignmentCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( assignmentCSS ) ), 5000 );
            WebElement assignment = driver.findElement( By.cssSelector( assignmentCSS ) );
            return assignment.getText().trim();
        } catch ( Exception e ) {
            Log.message( "Assignment Name not found" );
        }
        return null;
    }

    public String getStudentName() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( studentNameCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( studentNameCSS ) ), 5000 );
            WebElement student = driver.findElement( By.cssSelector( studentNameCSS ) );
            return student.getText().trim();
        } catch ( Exception e ) {
            Log.message( "Assignment Name not found" );
        }
        return null;
    }

    public boolean clickNextButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( nextBtnCSS ) ) );
            WebElement nextBtnShd = driver.findElement( By.cssSelector( nextBtnCSS ) );

            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, nextBtnShd, button ) );
            Log.message( "Clicked Next Button!" );
            return true;
        } catch ( Exception e ) {
            Log.message( "Clicked next Button Failed" );
            return false;
        }
    }

    public boolean selectAdditionalGrouping( String name ) {
        expanDropdown( ADDITIONAL_GROUPING );
        List<WebElement> ddElements = getDropdownElementFilter( "additional-grouping" );
        for ( WebElement element : ddElements ) {
            if ( element.getAttribute( "data-label" ).equals( name ) ) {
                SMUtils.clickJS( driver, element );
                break;
            }
        }
        closeDropdown( ADDITIONAL_GROUPING );
        return true;
    }

    public boolean isnotCPAReportSelected() {
        // TODO Auto-generated method stub
        try {
            Log.message( "Verifing Cumulative Performance Aggregate is selected" );
            return SMUtils.getWebElementDirect( driver, cprAggregatetoggle, selectedButton ).getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE_AGGREGATE );
        } catch ( Exception e ) {
            // TODO: handle exception
            Log.message( "CPAReport should not selected" );
            return false;
        }
    }

    /**
     * click checkbox Mask Student CheckBox
     */
    public void clickMaskStudentRadio() {
        WebElement element = SMUtils.getWebElementDirect( driver, maskStudentRadio, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }

    /**
     * To click Start Date Text Box in the Selected Date Range - CP Report
     * 
     * @return
     */
    public void enterCurrentDateInStartCalendar() {
        Log.message( "Entering current Date field in From Calendar..." );
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDate dateObj = LocalDate.now();

        String startDate = dateObj.format( dateFormat );
        Log.message( "StartDate--> " + startDate );

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebElement textBox = (WebElement) jse.executeScript( "return document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.from.hydrated').shadowRoot.querySelector('input')" );

        while ( true ) {
            textBox.click();
            Actions action = new Actions( driver );
            action.sendKeys( Keys.ENTER ).build().perform();
//            SMUtils.enterValue( textBox, startDate );
            if ( textBox.getAttribute( "value" ).equals( startDate ) ) {
                Log.message( "Current value at textBox: " + textBox.getAttribute( "value" ) );
                break;
            }
        }
    }

    /**
     * To click To Date Text Box in the Selected Date Range - CP Report
     * 
     * @return
     */
    public void enterCurrentDateInToCalendar() {
        Log.message( "Entering current Date field in To Calendar..." );
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDate dateObj = LocalDate.now();

        String startDate = dateObj.format( dateFormat );
        Log.message( "StartDate--> " + startDate );

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebElement textBox = (WebElement) jse.executeScript( "return document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.to.hydrated').shadowRoot.querySelector('input')" );

        while ( true ) {
            textBox.click();
            Actions action = new Actions( driver );
            action.sendKeys( Keys.ENTER ).build().perform();
//            SMUtils.enterValue( textBox, startDate );
            if ( textBox.getAttribute( "value" ).equals( startDate ) ) {
                Log.message( "Current value at textBox: " + textBox.getAttribute( "value" ) );
                break;
            }
        }
//        SMUtils.moveToElementJS(driver,pageTitle);
    }

    // Nishanth
    /**
     * Get Selected option
     * 
     * @return
     */
    public List<String> getSelectedOptionsLegend() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Log.message( "Getting the all the selectced options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( selectedOptions );
        return allTextFromWebElementList;

    }
    
    /**
     * To get Sub Header filed values
     * 
     * @param value
     * @return
     * @throws InterruptedException
     */
    public List<String> getSubHeaderValues( ReportSubHeader value ) {
        List<String> subHeaderValues = new ArrayList<>();
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, reportTable, 10 );
            SMUtils.waitForElement( driver, reportHeader );
            IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
                subHeaderValues.add( subHeaderFieldValues.get( value.ordinal() ).getText().trim() );
                WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
                if ( nextBtn.isEnabled() ) {
                    SMUtils.click( driver, nextBtn );
                }
            } );
        } catch ( InterruptedException e ) {
            e.printStackTrace();
        }
        return subHeaderValues;
    }
    
    /**
     * Get the CPR Math grid values from UI
     * 
     * @return
     */
    public List<String> getMathCurrentCourseLevelAndRawPerformance( String studentName ) {

        List<String> rawPerformancesValues = new ArrayList<>();
        String studentCurrentCourseLevel = String.format( currentCourseLevel, studentName ) + parentCurrentCourseLevel;
        SMUtils.waitForElement( driver, endTableNotes, 10 );
        for ( int i = 1; i <= 8; i++ ) {
            WebElement StudentRawPerformance = driver.findElement( By.xpath( String.format( studentCurrentCourseLevel, i ) ) );

            rawPerformancesValues.add( StudentRawPerformance.getText().trim() );
        }

        return rawPerformancesValues;

    }
    
    /**
     * To format the percentage in DB
     * 
     * @return
     */
    public String totalPercentange( float ExercisesCorrect, float ExercisesAttempted ) {
        float percentage = 100;
        float totalPercentage;
        String exercisesPercentCorrect;
        totalPercentage = ExercisesCorrect * percentage / ExercisesAttempted;
        exercisesPercentCorrect = String.valueOf( Math.round( totalPercentage ) + "%" );
        return exercisesPercentCorrect;
    }
    /**
     * To Click RunReport Button
     * 
     * @return
     */

    public CPReportViewerPage clickRunReportButton() {
        try {
            WebElement webElementDirect = SMUtils.getWebElementDirect( driver, runReportRoot, runReportChild );
            SMUtils.clickJS( driver, webElementDirect );
            Log.message( "Clicked Run report Button" );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(0) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Unable to click Here in run report button in CPAggregate Page" );

        }
        return new CPReportViewerPage( driver ).get();

    }

    public List<String> getOutputStudentNames( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputStudentName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputCurentCourseLevel( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputCurentCourseLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputExercisesCorrect( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputExercisesCorrect.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputExercisesAttempted( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputExercisesAttempted.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputTotalSessions( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTotalSessions.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }
    public HashMap<String, HashMap<String, String>> getCPReportAllDataFromUI( WebDriver driver) throws InterruptedException {
        HashMap<String, HashMap<String, String>> cparDetails = new HashMap<>();
        SMUtils.waitForSpinnertoDisapper(driver, 5);
        Log.message( "Getting Data From output.." );

            List<String> studentNames = getOutputStudentNames(driver);
            List<String> currentCourseLevel =  getoutputCurentCourseLevel(driver);
            List<String> exerciseCorrect = getoutputExercisesCorrect(driver);
            List<String> exerciseAttempted =  getoutputExercisesAttempted(driver);
            List<String> totalSessions = getoutputTotalSessions(driver);
            
            IntStream.range( 0, currentCourseLevel.size() ).forEach( itr -> {

                HashMap<String, String> values = new HashMap<>();
                
                values.put( "exercisesAttempted", exerciseAttempted.get( itr ).toString() );
                values.put( "exercisesCorrect", exerciseCorrect.get( itr ).toString() );
                values.put( "totalSessions", totalSessions.get( itr ).toString() );
                values.put( "currentCourseLevel", currentCourseLevel.get( itr ).toString() );
                
                cparDetails.put(studentNames.get( itr ), values );
            });
            Log.message( "Final UI Details: " + cparDetails);
            return cparDetails; 
    }

    public boolean chooseSubject( WebDriver driver, String subjectName ) {
       ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
//     SMUtils.waitForElement( driver, txtStudentPerformanceReportHeader );
       reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
       return true;
    }
    /**
     * To load Cumulative report output MFE page
     * 
     */
    public CPAReportViewerPage clickRunBtn() {
        reportFilterComponent.clickRunReportButton();
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Getting issue while change the driver to report output page!!!!" );
        }
        return new CPAReportViewerPage( driver ).get();
    }
    
    /**
     * To click Start Date Text Box in the Selected Date Range - CP Report
     * 
     * @return
     * @throws InterruptedException
     */
    public void enterCurrentDateInStartAndEndCalendar() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 30 );
        Log.message( "Entering current Date field in From Calendar..." );
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDate dateObj = LocalDate.now();
        clickStartDateCalendarcp();
        Actions action = new Actions( driver );
        action.sendKeys( Keys.ENTER ).build().perform();
        action.sendKeys( Keys.ENTER ).build().perform();
    }

    /**
     * Click Start Calendar Icon
     */
    public void clickStartDateCalendarcp() {
        WebElement element = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( CALENDER_ICON_ROOT1 ) ), CALENDER_ICON_FROM_ROOT2, CALENDER_ICON_ROOT3, CALENDER_ICON_ROOT4, "div" );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked  Calendare Icon - From" );
        SMUtils.nap( 2 ); // wait for calendar popup to load
    }

}