package com.savvas.sm.reports.ui.tests.teacher.spr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.teacher.ui.pages.ReportNavigation;
import com.savvas.sm.reports.teacher.ui.pages.StudentPerformanceReportsPages;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class SPRTeacherReportTest extends EnvProperties {

	private String smUrl;
	private String browser;
	private String sessionCookie;
	private String username;
	String userId;
	private String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String teacherDetails;
	private String studentLastName;
	public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	ReportComponents reportComponents;
	ReportNavigation reportnav;
	String teacherUsername;
	String orgId;
	String endPoint;
	String teacherStaffId;
	String studentDetailsSchool1;
	String courseId;
	String studentDetails;
	String studentIdOne;
	String studentIdTwo;
	HashMap<String, String> assignmentDetails = new HashMap<>();
	String districtId;
	String studentThreeDetails;
	String studentFourDetails;
	String studentFiveDetails;
	String studentIdThree;
	String studentIdFour;
	String studentIdFive;
	String studentTwoDetail;
	List<String> studentRumbaIds = new ArrayList<>();
	Map<String, String> courseIDs = new HashMap<>();
	Map<String, String> contentBase = new HashMap<>();
	HashMap<String, String> courseName = new HashMap<>();
	String assignmentId;
	String firstMathAssignmentUserId;
	String secondMathAssignmentUserId;
	List<String> mathAssignmentUserId = new ArrayList<>();
	private HashMap<String, String> groupDetails = new HashMap<>();
	String configGraphQL;
	DevTools tools = null;

	@BeforeClass(alwaysRun = true)
	public void initTest() throws Exception, IOException {

		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		districtId = configProperty.getProperty("district_ID");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, "userName");
		userId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		configGraphQL = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";

		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdOne = SMUtils.getKeyValueFromResponse(studentDetails, "userId");

		studentTwoDetail = RBSDataSetup.getMyStudent(school, username);
		studentIdTwo = SMUtils.getKeyValueFromResponse(studentTwoDetail, "userId");

		studentThreeDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdThree = SMUtils.getKeyValueFromResponse(studentThreeDetails, "userId");

		studentFourDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdFour = SMUtils.getKeyValueFromResponse(studentFourDetails, "userId");

		studentFiveDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdFive = SMUtils.getKeyValueFromResponse(studentFiveDetails, "userId");

		orgId = new RBSUtils().getOrganizationIDByName(districtId, school);

		studentRumbaIds.add(studentIdOne);
		studentRumbaIds.add(studentIdTwo);
		studentRumbaIds.add(studentIdThree);
		studentRumbaIds.add(studentIdFour);
		studentRumbaIds.add(studentIdFive);

		contentBase.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH);
		contentBase.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING);

		courseName.put(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE,
				String.format(DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
				String.format(DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
				String.format(DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime()));

		courseIDs.put(Constants.MATH, AssignmentAPIConstants.MATH);
		courseIDs.put(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS,
						courseName.get(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse(
				smUrl, new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
				DataSetupConstants.MATH, userId, orgId, courseName.get(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD,
						courseName.get(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL,
						courseName.get(Constants.CUSTOM_BY_SKILLS_MATH_COURSE)));

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, userId);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));

		HashMap<String, String> mathAssignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, Arrays.asList(studentRumbaIds.get(0)), new ArrayList<>(courseIDs.values()));

		Log.message(mathAssignmentResponse.get("body"));

		// Getting assignment id
		JSONObject mathAssignmentDetailsJson = new JSONObject(mathAssignmentResponse.get(Constants.REPORT_BODY));
		JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray(Constants.DATA);
		JSONObject mathAssignmentInfo = new JSONObject(mathAssignmentList.get(0).toString());

		assignmentId = mathAssignmentInfo.get("assignmentId").toString();
		mathAssignmentUserId.add(new SqlHelperCourses().getAssignmentUserId(studentRumbaIds.get(0), assignmentId));

		courseName.put(Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
				String.format(DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
				String.format(DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SKILLS_READING_COURSE,
				String.format(DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime()));

		courseIDs.put(Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId, DataSetupConstants.SETTINGS,
						courseName.get(Constants.CUSTOM_BY_SETTINGS_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
				new CourseAPI().createCustomBySettingIPMOnCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId,
						courseName.get(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId, DataSetupConstants.STANDARD,
						courseName.get(Constants.CUSTOM_BY_STANDARDS_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SKILLS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId, DataSetupConstants.SKILL,
						courseName.get(Constants.CUSTOM_BY_SKILLS_READING_COURSE)));

		HashMap<String, String> readingAssignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, studentRumbaIds, new ArrayList<>(courseIDs.values()));

		Log.message(readingAssignmentResponse.get("body"));

	}

	@Test(description = "Verify Student performance Report (SPR) should display under Reports menu.", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 1)
	public void tcSM_SPR001() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR001: Verify Student performance Report (SPR) should display under Reports menu<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			Log.assertThat(reportComponents.subNavigationMenuisDisplayed(ReportTypes.STUDENT_PERFORMANCE),
					"The Student Performance Page is displaying in Report MFE sub-navigation",
					"The Student Performance Page is not displaying in Report MFE sub-navigation");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Student performance Report (SPR) decription text and availability of SPR Header on reports page", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 2)
	public void tcSM_SPR002() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_SPR002: Verify Student performance Report (SPR) decription text<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			// Validate Header description of SPR
			Log.assertThat(studentPerformanceReportsPage.reportDescriptionText(ReportsUIConstants.SPR_DESCRIPTIONTEXT),
					"Correct Description is showing in SPR Header", "Incorrect Description is showing in SPR header");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify subject filter availability for SPR and also verifying list of all subjects available in filter", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 3)
	public void tcSM_SPR003() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_SPR003: Verify subject filter availability for SPR<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			// Validate subject filter
			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.SUBJECT_DROPDOWN),
					"Subject filter is displaying", "Subject filter is not displaying");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify All fields displayed on SPR Page", groups = { "SMK-39429/SMK-66760", "reports",
			"StudentPerformanceReport" }, priority = 4)
	public void tcSM_SPR004() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR004:Verify All fields displayed on SPR Page<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			// Validate All fields on SPR

			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.GROUP_DROPDOWN),
					"Groups header is displaying", "Groups header is not displaying");
			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.STUDENTS_DROPDOWN),
					"Student header is displaying", "Student header is not displaying");

			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.ASSIGNMENTS_DROPDOWN),
					"Assignments dropdown header is displaying", "Assignments dropdown header is not displaying");
			Log.assertThat(
					reportComponents.isFilterAndReportOptionsHeadingPresent(ReportsUIConstants.OPTIONAL_FILTER_HEADER),
					"Report Options header is displaying", "Report Options header is not displaying");

			Log.assertThat(reportComponents.isStaticDropdownHeadingPresent(ReportsUIConstants.DISPLAY_DROPDOWN),
					"Display dropdown header is displaying", "Display dropdown header is not displaying");
			Log.assertThat(
					studentPerformanceReportsPage.isMaskStudentDisplayed(ReportsUIConstants.MASK_STUDENT_DISPLAY),
					"Mask Student header is displaying", "Mask Student header is not displaying");
			Log.assertThat(
					studentPerformanceReportsPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent(
							ReportsUIConstants.SPR_INCLUDEPERFORMANCE),
					"Include Performance summary header is displaying",
					"Include Performance summary header is not displaying");
			Log.assertThat(
					studentPerformanceReportsPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent(
							ReportsUIConstants.SPR_INCLUDEPERFORMANCESTRAND),
					"Include Performance by strand header is displaying",
					"Include Performance by strand header is not displaying");
			Log.assertThat(
					studentPerformanceReportsPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent(
							ReportsUIConstants.SPR_INCLUDEAFG),
					"Include Area of difficulty header is displaying",
					"Include Area of difficulty header is not displaying");
			Log.assertThat(
					studentPerformanceReportsPage
							.isMultiSelectDropdownHeadingPresent(ReportsUIConstants.DATEATRISK_DROPDOWN),
					"Date at risk dropdown header is displaying", "Date at risk dropdown header is not displaying");
			Log.assertThat(
					studentPerformanceReportsPage
							.isMultiSelectDropdownHeadingPresent(ReportsUIConstants.SPR_LANGUAGE_DROPDOWN),
					"Language dropdown header is displaying", "Language dropdown header is not displaying");
			Log.assertThat(studentPerformanceReportsPage.isRunReportDisplayed(), "Run report button is displaying",
					"Run report button is not displaying");
			Log.assertThat(studentPerformanceReportsPage.isSaveReportDisplayed(),
					"Save report options link is displaying", "Save report options link is not displaying");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify whether the reading selection of Subject drop down in Student Performance Reports Page", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 5)
	public void tcSM_SPR005() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR005:Verify whether the reading selectionof Subject drop down in Student Performance Reports Page<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			studentPerformanceReportsPage.chooseSubject(driver, "Reading");

			// Verify Reading Subject is selected
			Log.assertThat(studentPerformanceReportsPage.chooseSubject(driver, "Reading"),
					"The 'Reading' subject is selected", "The 'Reading' subject is not selected");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify user can select all and de select all assignments through SELECT ALL check box", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 6)
	public void tcSM_SPR006() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR006:Verify user can select all and de select all assignments through SELECT ALL check box<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			// Uncheck the check boxes
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_DROPDOWN,
					Arrays.asList(ReportsUIConstants.ALL));

			Log.assertThat(
					(reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_DROPDOWN,
							Arrays.asList(ReportsUIConstants.ALL))),
					"'SELECT ALL' Checkbox checked and unchecked successfully!",
					"'SELECT ALL' Checkbox has not  unchecked yet");

			// To Click the 'SELECT ALL' option again
			Log.assertThat(
					reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_DROPDOWN,
							Arrays.asList(ReportsUIConstants.ALL)),
					"'SELECT ALL' Checkbox checked again successfully", "'SELECT ALL' Checkbox has not checked yet");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Groups' dropdown field display under Filters option when only one Group is selected on SPR", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport", "mock" }, priority = 7)
	public void tcSM_SPR007(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(
				"tcSMSPR007: Verify 'Groups' dropdown field display when only one Group is selected. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

//			// single group
			if (DevToolsUtils.isMock(context)) {

				String json = DevToolsUtils.readJsonResponse("SPR_Single_Group.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			reportComponents = new ReportComponents(driver);

			// Uncheck Select All checkbox
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
					Arrays.asList(ReportsUIConstants.ALL));

			ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);

			List<String> studentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

			// Selecting single option in Group Dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
					Arrays.asList(studentsFromUI.get(1)));
			reportComponents.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

			Log.assertThat(
					(reportComponents.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN)
							.contains(studentsFromUI.get(1))),
					"The Selected Group is displaying in the dropdown",
					"The Selected Group is not displaying in the dropdown");
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	@Test(description = "Verify 'Display' dropdown should display on SPR page ,verify all list of Display filter", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 8)
	public void tcSM_SPR008() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("tcSM_SPR008:Verify 'Display' dropdown should display on SPR page<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			Log.assertThat(reportComponents.validateDisplayDrpdwnField(driver), "All Display filter list is available",
					"All Display filter list is not available");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify deleted groups should not display under Groups dropdown.", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 9)
	public void tcSM_SPR009() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_SPR009:Verify deleted groups should not display under Groups dropdown.<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			String className = "ClasstoDelete" + System.nanoTime();

			groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
			groupDetails.put(GroupConstants.GROUP_OWNER_ID, userId);
			groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, orgId);
			groupDetails.put(GroupConstants.GROUP_NAME, className);

			HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds);

			String classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");

			String groupName = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY),
					"data,groupName");
			Log.message("The group name is" + groupName);
			String accessCode = new RBSUtils().getAccessToken(username, password);

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			// get WebElements of dropdown option checkboxes
			List<String> allGroupsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);
			Log.message(allGroupsFromUI.toString());

			Log.assertThat((allGroupsFromUI.contains(className)), "Group is created successfully!!",
					"Group is not created");

			// delete group
			HashMap<String, String> deleteGroup = new GroupAPI().deleteGroup(classId, userId, orgId, accessCode);
			Log.message(deleteGroup.toString());

			driver.navigate().refresh();

			// get WebElements of dropdown option checkboxes

			List<String> groupsAfterDeletion = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

			Log.message(groupsAfterDeletion.toString());

			Log.assertThat(!(groupsAfterDeletion.contains(groupName)), "Deleted Group is not displayed as expected",
					"Deleted Group is displayed");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify removed assignments should not display under assignment dropdown.", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 10)
	public void tcSM_SPR010() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR0010:Verify removed assignments should not display under assignment dropdown.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			List<String> assignmentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER);

			Log.message(assignmentsFromUI.toString());

			Log.assertThat((assignmentsFromUI.contains(ReportsUIConstants.MATH)),
					"The Assignment is assigned to the student successfully!",
					"The Assignment is not assigned to the student!");

			HashMap<String, String> mathAssignmentDetails = new HashMap<>();

			mathAssignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
			mathAssignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, userId);
			mathAssignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD));
			mathAssignmentDetails.put(AssignmentAPIConstants.COURSE_ID, "1");
			mathAssignmentDetails.put(AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId.get(0));

			HashMap<String, String> deleteAssignment = new AssignmentAPI().deleteAssignment(smUrl,
					mathAssignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL);
			Log.message("Delete Assignment - " + deleteAssignment.get("body"));

			dashboardPage.reportComponents.clickCumulativePerformanceReportPage();
			dashboardPage.reportComponents.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			List<String> assignmentList = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER);

			Log.message(assignmentList.toString());

			Log.assertThat(!(assignmentList.contains(ReportsUIConstants.MATH)),
					"The Assignment is removed from the dropdown successfully!",
					"The Assignment is not removed from the dropdown!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify all field on Saved Report Window pop up on SPR page Including button and drop down", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 11)
	public void tcSM_SPR011() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_SPR0011:Verify all field on Saved Report Window pop up on SPR page.<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);
			// Navigate to SPR page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);
			reportComponents.clickSavedReportOptionsButton(driver);

			Log.assertThat(
					reportComponents.getSaveReportPopUpTextHeader()
							.equals(ReportsUIConstants.SPR_SAVEREPORT_POUP_HEADER),
					"Save Report Option Is displaying", "Save Report Option is not displaying");

			Log.assertThat(
					reportComponents.saveReportOptionNewFieldHeader()
							.equals(ReportsUIConstants.SPR_NEW_HEADER_SAVEREPORT),
					"The new field is displaying on Poup", "The new field is not displaying on Poup");

			Log.assertThat(
					reportComponents.saveReportOptionReplaceExistingFieldHeader()
							.equals(ReportsUIConstants.SPR_REPLACE_EXISTING_HEADER),
					"Replace Existing Report Option Field is displaying on Poup",
					"Replace Existing Report Option Field is not displaying on Poup");
			Log.assertThat(reportComponents.isSaveBtnDisplayedOnSaveReportPopUp(),
					"Save Button on save report option Field is displaying on Poup",
					"Save Button on save report option Field is not displaying on Poup");

			Log.assertThat(reportComponents.isCancelBtnDisplayedOnSaveReport(),
					"Cancel Button on save report option Field is displaying on Poup",
					"Cancel Button on save report option Field is not displaying on Poup");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected on SPR", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport", "mock" }, priority = 12)
	public void tcSM_SPR012(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR0012:Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected on SPR<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			// single assignment
			if (DevToolsUtils.isMock(context)) {

				String json = DevToolsUtils.readJsonResponse("SPR_Single_Assignment.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			reportComponents = new ReportComponents(driver);

			// Uncheck Select All checkbox
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_DROPDOWN,
					Arrays.asList(ReportsUIConstants.ALL));

			ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);
			List<String> allAssignmentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER);

			// Selecting single option in Assignment Dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_DROPDOWN,
					Arrays.asList(allAssignmentsFromUI.get(1)));
			Log.assertThat(
					(reportComponents.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_DROPDOWN)
							.contains(allAssignmentsFromUI.get(1))),
					"The Selected Assignment is displaying in the dropdown",
					"The Selected Assignment is not displaying in the dropdown");
			Log.testCaseResult();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	@Test(description = "Verify Student Summary Performance field,Include Performance by Strand,Include Areas of Difficulty radio button, Verifying when Area of difficulty is No,then Date at risk dropdwon should not display ", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 13)
	public void tcSM_SPR013() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR0013:Verify Student Summary Performance,Include Performance by Strand,Include Areas of Growth radio button<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			// Click Include Performance Summary Radio Button
			Log.assertThat(studentPerformanceReportsPage.validateRdYesIncludePerformanceSummary(driver),
					"Include Performance Summary is selected as Yes",
					"Include Performance Summary is selected as No. Validation failed!");

			// Click Include Performance By Strand Radio Button
			Log.assertThat(studentPerformanceReportsPage.validateRdYesIncludePerformanceByStrand(driver),
					"Include Performance By Strand is selected as Yes",
					"Include Performance By Strand is selected as No. Validation failed!");

			// Click Include Areas for Growth Radio Button
			Log.assertThat(studentPerformanceReportsPage.validateRdYesIncludeAreasForGrowth(driver),
					"Include Areas for Growth is selected as Yes",
					"Include Areas for Growth is selected as No. Validation failed!");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify List of all Language dropdown field options available on SPR, Mask Student checkbox field options", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport" }, priority = 14)
	public void tcSM_SPR014() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR0014:Verify List of all Language dropdown field options available on SPR, Mask Student checkbox field options<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			// Verifying List of Language Options
			SMUtils.logDescriptionTC("Verify all field available under Language dropdown");
			reportComponents.expandSingleSelectDropdownForStudentPerformance(ReportsUIConstants.LANGUAGE);
			Log.assertThat(
					reportComponents.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.LANGUAGE)
							.containsAll(ReportsUIConstants.LANGUAGE_OPTIONS),
					"All the Language option are displaying", "Language option are not displaying");

			// mask Student Check box
			studentPerformanceReportsPage.isMaskStudent();
			Log.assertThat(studentPerformanceReportsPage.isMaskStudent(),
					"The Mark Student Check box is diplayed and checked", "The Mark Student Check box is not diplayed");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.", groups = {
			"SMK-39429/SMK-66760", "reports", "StudentPerformanceReport", "mock" }, priority = 15)
	public void tcSM_SPR015(ITestContext context) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR0015:Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			// mocking multiple groups
			if (DevToolsUtils.isMock(context)) {

				String json = DevToolsUtils.readJsonResponse("SPR_GroupDetails.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			reportComponents = new ReportComponents(driver);

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
					Arrays.asList(ReportsUIConstants.ALL));

			List<String> studentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
					Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3)));

			List<String> selectedOptionsFromMultiSelectDropdown = reportComponents
					.getSelectedOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);
			Log.message(selectedOptionsFromMultiSelectDropdown.toString());

			if (studentsFromUI.size() > 2) {
				Log.assertThat(
						selectedOptionsFromMultiSelectDropdown.containsAll(
								Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3))),
						"The Groups dropdown is multiselected", "The Groups dropdown is not multiselected");
			} else {
				Log.message("The dropdown has one or two groups");
			}
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'students' dropdown field display under Filters option when more than one students are selected.", groups = {
			"SMK-39429/SMK-66760", "mock", "reports", "StudentPerformanceReport" }, priority = 16)
	public void tcSM_SPR016(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMSPR016:Verify 'students' dropdown field display under Filters option when more than one students are selected.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			// mocking multiple Students
			if (DevToolsUtils.isMock(context)) {

				String json = DevToolsUtils.readJsonResponse("SPR_StudentDetails.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			reportComponents = new ReportComponents(driver);
			reportComponents.selectStudentRadioBtn(driver);

			// DeSelect All checkbox
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
					Arrays.asList(ReportsUIConstants.ALL));

			List<String> studentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN);

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
					Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3)));

			List<String> selectedOptionsFromMultiSelectDropdown = reportComponents
					.getSelectedOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN);
			Log.message(selectedOptionsFromMultiSelectDropdown.toString());

			if (studentsFromUI.size() > 2) {

				Log.assertThat(
						selectedOptionsFromMultiSelectDropdown.containsAll(
								Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3))),
						"The dropdown is multiselected", "The dropdown is not multiselected");
			} else {
				Log.message("The dropdown has one or two students");
			}

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();

		}

	}

	@Test(description = "Verify the Save Report Option has more than one option", groups = { "SMK-39429/SMK-66760",
			"reports", "StudentPerformanceReport", "mock" }, priority = 17)
	public void tcSM_SPR017(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMSPR017:Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("SPR_Reading_Assignments.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			// Uncheck Select All checkbox
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER,
					Arrays.asList(ReportsUIConstants.ALL));

			List<String> assignmentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER);

			// Selecting multiple options in Group Dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER,
					Arrays.asList(assignmentsFromUI.get(1), assignmentsFromUI.get(2), assignmentsFromUI.get(3)));

			List<String> selectedOptionsFromMultiSelectDropdown = reportComponents
					.getSelectedOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADER);
			Log.message(selectedOptionsFromMultiSelectDropdown.toString());
			if (assignmentsFromUI.size() > 2) {

				Log.assertThat(
						selectedOptionsFromMultiSelectDropdown.containsAll(Arrays.asList(assignmentsFromUI.get(1),
								assignmentsFromUI.get(2), assignmentsFromUI.get(3))),
						"The dropdown is multiselected", "The dropdown is not multiselected");
			} else {
				Log.message("The dropdown has one or two assignments");
			}

			Log.testCaseResult();
		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	@Test(description = "Verify the Save Report Dropdown has more than one option", groups = { "SMK-39429/SMK-66760",
			"reports", "StudentPerformanceReport", "mock" }, priority = 18)
	private void tcSM_SPR018() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMSPR018:Verify the Save Report Option has more than one option.<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			String json = DevToolsUtils.readJsonResponse("SPR_Multiple_SavedReportOptions.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetAllReportOption", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			ReportFilterComponent reportFilterComponents = new ReportFilterComponent(driver);

			reportFilterComponents.expandExistingReportOptionDropdown();
			List<String> allSavedOptions = reportFilterComponents.getAvailableOptionsFromSavedReportOptionDropdown();

			Log.message("count : " + allSavedOptions.size());

			Log.assertThat((allSavedOptions.size() - 1) == 6, "Saved Options count matches.",
					"Saved Options count didn't match");
			Log.testCaseResult();
		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}

	}

	@Test(description = "Verify the Save Report Dropdown has one option", groups = { "reports",
			"StudentPerformanceReport", "mock" }, priority = 19)
	private void tcSM_SPR019() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMSPR019:Verify the Save Report Dropdown has one option.<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			String json = DevToolsUtils.readJsonResponse("SPR_Single_SavedReportOptions.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetAllReportOption", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			ReportFilterComponent reportFilterComponents = new ReportFilterComponent(driver);

			reportFilterComponents.expandExistingReportOptionDropdown();
			List<String> allSavedOptions = reportFilterComponents.getAvailableOptionsFromSavedReportOptionDropdown();

			Log.message("count : " + allSavedOptions.size());

			Log.assertThat((allSavedOptions.size() - 1) == 1, "Saved Options count matches.",
					"Saved Options count didn't match");
			Log.testCaseResult();
		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}

	}

	@Test(description = "Verify Zero State for groups/students, assignments and savedreport option", groups = {
			"reports", "StudentPerformanceReport", "mock" }, priority = 20)
	private void tcSM_SPR020() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Zero State for groups, students, assignments and savedreport option.<small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// ZeroStateAssignment
			String zeroStateAssignmentJson = DevToolsUtils.readJsonResponse("SPR_ZeroStateAssignment.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", zeroStateAssignmentJson);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			String zeroStateMessage = "No assignment are available for the selecte...";
			Log.assertThat(reportComponents.verifyZeroStateAssignment().contains(zeroStateMessage),
					"Zero State verified!", "Zero State not verified!");

			// ZeroStateSavedReportOption
			String zeroStateSavedReportJson = DevToolsUtils.readJsonResponse("SPR_ZeroStateSaveReportOption.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetAllReportOption", "post",
					zeroStateSavedReportJson);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			dashboardPage.reportComponents.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			String zeroStateSaveReportMessage = "No Saved report options [...]";
			Log.assertThat(reportComponents.verifyZeroStateSaveReportOption().contains(zeroStateSaveReportMessage),
					"Zero State verified!", "Zero State not verified!");

			Log.testCaseResult();

		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}

	}

	@Test(description = "Verify Zero State for groups/students, assignments and savedreport option", groups = {
			"reports", "StudentPerformanceReport", "mock" }, priority = 21)
	private void tcSM_SPR021() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Zero State for groups and students.<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// ZeroStateGroupsAndStudents
			String zeroStateGroupsAndStudentJson = DevToolsUtils.readJsonResponse("SPR_ZeroStateGroupAndStudents.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post",
					zeroStateGroupsAndStudentJson);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			dashboardPage.reportComponents.clickStudentPerformancePage();

			reportComponents = new ReportComponents(driver);

			String zeroStateGroupsandStudentsMessage = "No students exist in the database. Once students are available, you will be able to use the Reports feature.";
			Log.assertThat(reportComponents.verifyZeroStateMessage().contains(zeroStateGroupsandStudentsMessage),
					"Zero State verified!", "Zero State not verified!");
		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}
}
