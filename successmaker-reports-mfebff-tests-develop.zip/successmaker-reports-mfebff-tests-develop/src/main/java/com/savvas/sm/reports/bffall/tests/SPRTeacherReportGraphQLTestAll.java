package com.savvas.sm.reports.bffall.tests;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.mongodb.connection.Stream;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class SPRTeacherReportGraphQLTestAll extends EnvProperties {
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails = null;
    private String coTeacherDetails = null;
    private String orgId = null;
    private String teacherId = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> contentBaseName = new HashMap<>();
    private static HashMap<String, String> assignmentIds = new HashMap<String, String>();

    private List<String> courseIDs = new ArrayList<>();
    private List<String> schools = new ArrayList<>();
       private HashMap<String, String> groupDetails = new HashMap<>();
    private HashMap<String, String> userDetails = new HashMap<>();

    private String exception = null;
    private boolean status = false;
    private String message = null;
    // other school constants
    // other school constants
  
    private String username;
    private String studentDetail = null;
    private String studentUserID;
    private String studentUsername;
    private String groupID;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );

        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );

        studentRumbaIds.add( studentUserID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );
        HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
        groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Math: Grade 1" );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );

        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );
        String username = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        Log.message( "username:" + username );
        try {
            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );

            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );

        } catch ( IOException e ) {
            e.printStackTrace();
        }

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        Log.message( "assignmentDetailsJson" + assignmentDetailsJson );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment IDs - " + assignmentIds );
    }

    @Test ( enabled = true, priority = 1, dataProvider = "PositiveScenarios", groups = { "Teacher SPR Report Graphql", "SMK-55503", "P1", "API" } )
    public void getTeacherSPReport_Positive( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        Log.testCaseInfo( testcaseName + testcaseDescription );

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

        Response response = null;

        String payload = null;
        switch ( scenarioType ) {
            case "MATH":
                SMUtils.logDescriptionTC( "Verify the 200 graphql response is obtaining the predictable result for all set of Fields for ISP Reports query" );
                SMUtils.logDescriptionTC( "Verify the 200 graphql response is obtaining the predictable result for mandatory query input params (Teacher id and organization id)" );
                SMUtils.logDescriptionTC( "Verify the 200 graphql response is obtaining the predictable result for all query input params" );
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining the predictable result when valid studentId's data are provided in the query input params" );
                SMUtils.logDescriptionTC( "Verify the 200 response Math subject(Default) data report are returned as response when subjectId param is not provided in query input params" );
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response with respective assignments report data when valid assignmentId's are provided in the query input params" );
                SMUtils.logDescriptionTC( " Verify the 200 code response is fetching respective data with respect to the studentId's, subjectId, startdate, endDate, limit, offset, orderBy, assignmentId's with valid data are provided in the query input params\r\n");


                int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               Log.message( ""+"************************************************************************************************\n" );
               Log.message( "payload:"+payload );
               Log.message( ""+"************************************************************************************************\n" );
               
               // Get data from response
              HashMap<String, String> dataFromResponse = getDataFromResponse( response.getBody().asString() );
               Log.message( "Datas to validate from response : " + dataFromResponse );
               Log.message( ""+"************************************************************************************************\n" );
               
               String mathAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathAssignmentId)  );
               SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when multiple set query is given for psrows sub set query with in the query input params" );

               // Get data from DB
               HashMap<String, String> spRdataFromDB = SPRdataFromDB( mathAssignmentUserId );
               Log.message( "SPR Response From The DB " + ( spRdataFromDB ) );
               Log.message( ""+"************************************************************************************************\n" );
               
               Log.assertThat((spRdataFromDB.toString().equals( dataFromResponse.toString() )), "Report data are same as DB data", "Report data are not same as DB data" );

                break;
                
          
                
            case "MATH_SETTINGS":
                
                SMUtils.logDescriptionTC( "Verify the 200 response the selected dates report data are fetched when start date and end date are provided in the query input params" );

                int mathSettingsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathSettingsAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               Log.message( ""+"************************************************************************************************\n" );
               Log.message( "payload:"+payload );
               Log.message( ""+"************************************************************************************************\n" );
               
               // Get data from response
              HashMap<String, String> dataFromResponse2 = getDataFromResponse( response.getBody().asString() );
               Log.message( "Datas to validate from response : " + dataFromResponse2 );
               Log.message( ""+"************************************************************************************************\n" );
               
               String mathSettingsAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathSettingsAssignmentId)  );
               
               SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when multiple set query is given for strandrows sub set query with in the query input params" );

               // Get data from DB
               HashMap<String, String> spRdataFromDB2 = SPRdataFromDB( mathSettingsAssignmentUserId );
               Log.message( "SPR Response From The DB " + ( spRdataFromDB2 ) );
               Log.message( ""+"************************************************************************************************\n" );
               
               Log.assertThat((spRdataFromDB2.toString().equals( dataFromResponse2.toString() )), "Report data are same as DB data", "Report data are not same as DB data" );

                break;
                
          
                
            case "READING":
                
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when single set query is given for ISPReportData query with in the query input params");
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when multiple set query is given for ISPReportData query with in the query input params");
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when all set query is given for ISPReportData query with in the query input params");

                int readAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) );

                payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               Log.message( ""+"************************************************************************************************\n" );
               Log.message( "payload:"+payload );
               Log.message( ""+"************************************************************************************************\n" );
               
               // Get data from response
              HashMap<String,List<String>> dataFromResponse4 = getReadingDataFromResponse2( response.getBody().asString() );
               Log.message( "Datas to validate from response : " + dataFromResponse4 );
               Log.message( ""+"************************************************************************************************\n" );
               
               String readAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(readAssignmentId)  );
               
               // Get data from DB
               HashMap<String,List<String>> readspRdataFromDB3 = SPRdataFromDBRead2( readAssignmentUserId );
               Log.message( "SPR Response From The DB " + ( readspRdataFromDB3 ) );
               Log.message( ""+"************************************************************************************************\n" );
               boolean b =readspRdataFromDB3.entrySet().stream().anyMatch(value->dataFromResponse4.get(value.getKey()).containsAll( value.getValue() ));
               Log.assertThat(b, "Report data are same as DB data", "Report data are not same as DB data" );

               break;
               
           
                
            case "READING_SETTINGS":
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when all set query is given for ISPReportData sub set query with in the query input params" );
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when all set query is given for groupInfo sub set query with in the query input params" );
                SMUtils.logDescriptionTC( "Verify the graphql response is obtaining predictable response when single set query is given for ISPReportData sub query with in the query input params" );
                SMUtils.logDescriptionTC( "Verify the graphql 200 response is obtaining predictable response when multiple set query is given for ISPReportData sub set query with in the query input params" );

                int readSettingsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

                payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readSettingsAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               Log.message( ""+"************************************************************************************************\n" );
               Log.message( "payload:"+payload );
               Log.message( ""+"************************************************************************************************\n" );
               
               // Get data from response
               HashMap<String,List<String>> dataFromResponse6 = getReadingDataFromResponse2( response.getBody().asString() );
                Log.message( "Datas to validate from response : " + dataFromResponse6 );
                Log.message( ""+"************************************************************************************************\n" );
                
                String readSettingsAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(readSettingsAssignmentId)  );
                
                // Get data from DB
                HashMap<String,List<String>> readspRdataFromDB4 = SPRdataFromDBRead2( readSettingsAssignmentUserId );
                Log.message( "SPR Response From The DB " + ( readspRdataFromDB4 ) );
                Log.message( ""+"************************************************************************************************\n" );
                boolean c =readspRdataFromDB4.entrySet().stream().anyMatch(value->dataFromResponse6.get(value.getKey()).containsAll( value.getValue() ));
                Log.assertThat(c, "Report data are same as DB data", "Report data are not same as DB data" );
                
               
                break;
                
           
        }

    }

    @DataProvider (name="PositiveScenarios")
    public Object[][] PositiveScenarios() {
        return new Object[][] { 
            { "TC001", "200", "Verify the 200 response Math subject data report are returned as response when subjectId param is provided with 1 in the query input params", "MATH" }, 
            { "TC003", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "MATH_SETTINGS" },
            { "TC007", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "READING_SETTINGS" },
            { "TC005", "200", "Verify the 200 response Reading subject data report are returned as response when subjectId param is provided with \"2\" in the query input params", "READING" },
        
        };
    }

    @Test ( enabled = true, priority = 2, dataProvider = "getDataNegativeCases", groups = { "Teacher SPR Report Graphql", "SMK-55503", "P1", "API" } )
    public void getTeacherSPReport_Negative( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        Log.testCaseInfo( testcaseName + testcaseDescription );

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

        Map<String, String> queryItem = new HashMap<>();
        LocalDate now = LocalDate.now();
        Date date = new Date();
        LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.MONDAY ) );
        String thisWeekStartDay = firstMonday.toString();
        String thisWeekEndDay = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );
        String payload = null;
        String query;
        Response response = null;
        int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

        switch ( scenarioType ) {
            case "INVALID_TOKEN":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.AUTHORIZATION, "abcd" );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               break;

            case "INVALID_TEACHER_ID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, "ABCD" );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               break;
               
            case "INVALID_ORG_ID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, "ABCD" );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                payload = getResponseBody( teacherId, "abcd", 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               break;
           
            case "INVALID_QUERY":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, "ABCD" );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                payload = getResponseBody( teacherId, "abcd", 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               break;
               
            case "INVALID_SUB_ID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, "ABCD" );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                payload = getResponseBody( teacherId, "abcd", 5, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               break;
               
            case "EMPTY_STUDENT":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, "ABCD" );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( "" ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               break;
               
            case "MATH_SKILL":
                int mathSkillAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathSkillAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               
                break;
                
            case "MATH_FOCUS":
                int mathFocusAssignmentId = Integer.parseInt( assignmentIds.get( "SM Focus Math: Grade 1" )  );

                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathFocusAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               
                break;
                
            case "READING_SKILL":
                int readSkillAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );

                payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readSkillAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               
                break;
                
            case "READING_FOCUS":

                payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
               Log.message( "response :"+ response.getBody().asString());
               
                break;

        }

        Log.message( response.getBody().asString() );
        // Validation
        Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
        Log.message( "Test Passed" );
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataNegativeCases() {
        return new Object[][] { { "TC001", "200", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_TOKEN" },
                { "TC002", "200", "Verify \"401: UnAuthorized\" message in response when invalid treacher-id is given in input query param for SP Reports query ", "INVALID_TEACHER_ID" },
                { "TC003", "200", "Verify 403 the user is not authorized message on the response when irrespective org id is given in input query param for LS Reports query\r\n"
                        + "", "INVALID_ORG_ID" },
                { "TC004", "200", "Verify \"400: Bad Request\" in the error message of the response body when invalid query has been given", "INVALID_QUERY" },
                { "TC005", "200", "Verify 400 code in the error message of the response body when invalid subject id is given in the query \r\n"
                        + "", "INVALID_SUB_ID" },
                { "TC006", "200", "Verify 400 code and validation error in the graphql response when empty studentId is provided in the query input params\r\n"
                        + "", "EMPTY_STUDENT" },
                { "TC007", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "MATH_SKILL" },
              { "TC008", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "MATH_FOCUS" },
              { "TC009", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "READING_SKILL" },
              { "TC010", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "READING_FOCUS" },

        };
    }


    
    // Get response body
    public String getResponseBody( String userId, String orgId, int subject, boolean isGroupSelected, List<String> groupIds, List<String> studentIds, List<Integer> assignmentIds ) {
        AtomicReference<String> requestBody = new AtomicReference<>();
        try {

            // Generate Payload
            String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report"
                    + File.separator;
            requestBody.set( SMUtils.convertFileToString( basePath + "ISPReportRequest.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", orgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.teacherId", userId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.isGroupSelected", isGroupSelected ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.studentIds", studentIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.groupIds", groupIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.assignmentIds", assignmentIds ) );

            Log.message( "Payload : " + requestBody.get() );
            Log.message( ""+"************************************************************************************************\n" );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return requestBody.get();
    }

    public  HashMap<String, String> getDataFromResponse( String response ) {

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( response, "data,getISPReportData,ispReportResponse" );
        Log.message( "Response Data: " + jsonObj );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();
        HashMap<String, String> studentReport = new HashMap<>();

        

            String rawPerformance = getKeyValueFromResponseWithArray( jsonObj, "strandRows" );
            //Loop1
            IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                

                    String strandDescription = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "strandDescription" );
                    String levelJson = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "strandStatus" );
                    String strandLevel = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "strandLevel" );
                  
                    //decimal conversion test
                    BigDecimal strandLevelbd = new BigDecimal(strandLevel);
                    strandLevelbd.setScale(2, BigDecimal.ROUND_HALF_UP); // this does change bd
                    strandLevelbd = strandLevelbd.setScale(2, BigDecimal.ROUND_HALF_UP);
                    

                    studentReport.put( "StrandDescription", strandDescription );
                    studentReport.put( "StrandLevel", String.valueOf( strandLevelbd ) );
                    
                  if(levelJson==null) {
                       studentReport.put( "StrandStatus", String.valueOf( "0.00" ) );
                   }
                   else {
                    Float valueOf = Float.valueOf( levelJson );
                    int strandStatus = valueOf.intValue();
                    studentReport.put( "StrandStatus", String.valueOf( strandStatus ) );
                   }
                    

                } );
            
            
            String rawPerformance2 = getKeyValueFromResponseWithArray( jsonObj, "psRows" );
            //Loop1
            IntStream.range( 0, new JSONArray( rawPerformance2 ).length() ).forEach( itr -> {

              

                    String exercisesAttempts = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance2 ).get( itr ).toString(), "exercisesAttempts" );
                    String exercisesCorrect = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance2 ).get( itr ).toString(), "exercisesCorrect" );
                    studentReport.put( "total_attempts", exercisesAttempts );
                    studentReport.put( "total_correct", String.valueOf( exercisesCorrect ) );
                } );
        Log.message( "Response Data: " + studentReport );
        Log.message( ""+"************************************************************************************************\n" );
        return studentReport;
    }
    
    
    // Get response for reading data
    public  HashMap<String, String> getReadingDataFromResponse( String response ) {

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( response, "data,getISPReportData,ispReportResponse" );
        Log.message( "Response Data: " + jsonObj );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();
        HashMap<String, String> studentReport = new HashMap<>();
        
        //test
        List<String> StrandDescription = new ArrayList<>();
        List<String> StrandLevel = new ArrayList<>();
        List<String> total_attempts = new ArrayList<>();
        List<String> total_correct = new ArrayList<>();

        

            String rawPerformance = getKeyValueFromResponseWithArray( jsonObj, "strandRows" );
            //Loop1
            IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                
                    String strandDescription = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "cttypeName" );
                    String strandLevel = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "strandLevel" );
                  

             
                    studentReport.put( "StrandDescription", strandDescription );
                    studentReport.put( "StrandLevel", String.valueOf( strandLevel ) );
                    
                } );
            
            
            String rawPerformance2 = getKeyValueFromResponseWithArray( jsonObj, "psRows" );
            //Loop1
            IntStream.range( 0, new JSONArray( rawPerformance2 ).length() ).forEach( itr -> {

              

                    String exercisesAttempts = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance2 ).get( itr ).toString(), "exercisesAttempts" );
                    String exercisesCorrect = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance2 ).get( itr ).toString(), "exercisesCorrect" );
                    studentReport.put( "total_attempts", exercisesAttempts );
                    studentReport.put( "total_correct", String.valueOf( exercisesCorrect ) );
                } );
        Log.message( "Response Reading Data: " + studentReport );
        Log.message( ""+"************************************************************************************************\n" );
        return studentReport;
    }
    
    
    // Get response for reading data
    public  HashMap<String,List<String>> getReadingDataFromResponse2( String response ) {

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( response, "data,getISPReportData,ispReportResponse" );
        Log.message( "Response Data: " + jsonObj );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();
        //HashMap<String, String> studentReport = new HashMap<>();
        
        HashMap<String, List<String>> studentReport = null;
        studentReport = new HashMap<String, List<String>>();
        
        //test
        List<String> StrandDescription = new ArrayList<>();
        List<String> StrandLevel = new ArrayList<>();
        List<String> total_attempts = new ArrayList<>();
        List<String> total_correct = new ArrayList<>();


            String rawPerformance = getKeyValueFromResponseWithArray( jsonObj, "strandRows" );
            //Loop1
            IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                
                StrandDescription.add(  SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "cttypeName" ));
                StrandLevel.add(SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "strandLevel" ));
                  
                    
                } );
            
            List<String> newList = StrandDescription.stream().distinct().collect(Collectors.toList());
            List<String> newList2 = StrandLevel.stream().distinct().collect(Collectors.toList());
            Log.message( ""+"************************************************************************************************\n" );
            Log.message( "removed duplicates list: " + newList );
            studentReport.put( "StrandDescription", newList );
            studentReport.put( "StrandLevel", newList2 );
            
            String rawPerformance2 = getKeyValueFromResponseWithArray( jsonObj, "psRows" );
            //Loop1
            IntStream.range( 0, new JSONArray( rawPerformance2 ).length() ).forEach( itr -> {

              

                total_attempts.add(   SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance2 ).get( itr ).toString(), "exercisesAttempts" ));
                total_correct.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance2 ).get( itr ).toString(), "exercisesCorrect" ));
             
                } );
            List<String> newList3 = total_attempts.stream().distinct().collect(Collectors.toList());
            List<String> newList4 = total_correct.stream().distinct().collect(Collectors.toList());
            studentReport.put( "total_attempts", newList3 );
            studentReport.put( "total_correct", newList4 );
            
        Log.message( "Response Reading Data: " + studentReport );
        Log.message( ""+"************************************************************************************************\n" );
        return studentReport;
    }
    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {
            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();
                //return keyValue;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }
    
    
    public HashMap<String, String> SPRdataFromDB( String mathAssignmentUserId ) {
        HashMap<String, String> valuesFromDB = new HashMap<>();

      
        
        String query="Select mst.strand_description as StrandDescription, \r\n"
                + "mams.strand_level as StrandLevel, mams.strand_status as StrandStatus\r\n"
                + "from math_auser_motion_strand mams join math_strand mst \r\n"
                + "on mst.strand_id=mams.strand_id where mams.assignment_user_id='" + mathAssignmentUserId + "'";
        
        String query2 ="Select total_attempts, total_correct from math_assignment_history where assignment_user_id='" + mathAssignmentUserId + "'";
        //query = query.replace("mathAssignmentIds", mathAssignmentIds);
        List<Object[]> rowList = SQLUtil.executeQuery( query );
        List<Object[]> rowList2 = SQLUtil.executeQuery( query2);
       
        Log.message("quer 1 output"+ rowList );
        Log.message("quer 2 output"+ rowList2 );
        
        rowList2.forEach( object -> {
            valuesFromDB.put( "total_attempts", object[0].toString() );
            
            valuesFromDB.put( "total_correct", object[1].toString() );
          
            }
         );
        
        rowList.forEach( object -> {
            valuesFromDB.put( "StrandDescription", object[0].toString() );
            
            valuesFromDB.put( "StrandLevel", object[1].toString() );
            valuesFromDB.put( "StrandStatus", object[2].toString() );
          
            }
         );
       
        Log.message( "Data's from DB method to validate : " + valuesFromDB );
        Log.message( ""+"************************************************************************************************\n" );
        return valuesFromDB;
    }
    
    
    // reading SPR data from DB
    
    public HashMap<String, String> SPRdataFromDBRead( String readAssignmentUserId ) {
        HashMap<String, String> valuesFromDB = new HashMap<>();

      
        
        String query="select \r\n"
                + "c.cttype_name , \r\n"
                + "ras.strand_level,ras.strand_correct,ras.strand_attempts  ,ras.strand_cttype_id,\r\n"
                + "case ras.strand_topped_out\r\n"
                + "when 0 then ras.strand_level::text \r\n"
                + "when 1 then 'TOP'\r\n"
                + "end as Strand_level\r\n"
                + "from school.read_auser_strand ras join\r\n"
                + "successmaker.cttype c on ras.strand_cttype_id = c.cttype_id \r\n"
                + "where ras.assignment_user_id = '" + readAssignmentUserId + "'";
        
        String query2 ="Select total_attempts, total_correct from read_assignment_history where assignment_user_id='" + readAssignmentUserId + "'";
        //query = query.replace("mathAssignmentIds", mathAssignmentIds);
        List<Object[]> rowList = SQLUtil.executeQuery( query );
        List<Object[]> rowList2 = SQLUtil.executeQuery( query2);
       
        Log.message("quer 1 output"+ rowList );
        Log.message("quer 2 output"+ rowList2 );
        
        rowList2.forEach( object -> {
            valuesFromDB.put( "total_attempts", object[0].toString() );
            
            valuesFromDB.put( "total_correct", object[1].toString() );
          
            }
         );
        
        rowList.forEach( object -> {
            valuesFromDB.put( "StrandDescription", object[0].toString() );
            
            valuesFromDB.put( "StrandLevel", object[1].toString() );
          
            }
         );
       
        Log.message( "Data's from DB method to validate : " + valuesFromDB );
        Log.message( ""+"************************************************************************************************\n" );
        return valuesFromDB;
    }
    
    // testing purpose
    public HashMap<String,List<String>> SPRdataFromDBRead2( String readAssignmentUserId ) {
        HashMap<String, String> valuesFromDB = new HashMap<>();
        HashMap<String, List<String>> arrMap = null;
        arrMap = new HashMap<String, List<String>>();
      
        
        String query="select \r\n"
                + "c.cttype_name , \r\n"
                + "ras.strand_level,ras.strand_correct,ras.strand_attempts  ,ras.strand_cttype_id,\r\n"
                + "case ras.strand_topped_out\r\n"
                + "when 0 then ras.strand_level::text \r\n"
                + "when 1 then 'TOP'\r\n"
                + "end as Strand_level\r\n"
                + "from school.read_auser_strand ras join\r\n"
                + "successmaker.cttype c on ras.strand_cttype_id = c.cttype_id \r\n"
                + "where ras.assignment_user_id = '" + readAssignmentUserId + "'";
        
        String query2 ="Select total_attempts, total_correct from read_assignment_history where assignment_user_id='" + readAssignmentUserId + "'";
        //query = query.replace("mathAssignmentIds", mathAssignmentIds);
        List<Object[]> rowList = SQLUtil.executeQuery( query );
        List<Object[]> rowList2 = SQLUtil.executeQuery( query2);
        List<String> StrandDescription = new ArrayList<>();
        List<String> StrandLevel = new ArrayList<>();
        List<String> total_attempts = new ArrayList<>();
        List<String> total_correct = new ArrayList<>();



        Log.message("quer 1 output"+ rowList );
        Log.message("quer 2 output"+ rowList2 );
        
        for ( int i = 0; i < rowList.size(); i++ ) {
            StrandDescription.add(rowList.get( i )[0].toString());
            if(rowList.get( i )[1].toString()==null ||rowList.get( i )[1].toString().isEmpty()  ) {
                StrandLevel.add(rowList.get( i )[1].toString().replace( rowList.get( i )[1].toString(), "null"));
            }
            else {
            StrandLevel.add(rowList.get( i )[1].toString());
            }
        }
        arrMap.put( "StrandDescription", StrandDescription);
        arrMap.put( "StrandLevel", StrandLevel );
        
        for ( int i = 0; i < rowList2.size(); i++ ) {
            total_attempts.add(rowList2.get( i )[0].toString());
            total_correct.add(rowList2.get( i )[1].toString());

        }
        arrMap.put( "total_attempts", total_attempts);
        arrMap.put( "total_correct", total_attempts );
        
       
        Log.message( "Data's from DB method to validate : " + valuesFromDB );
        Log.message( ""+"************************************************************************************************\n" );
        return arrMap;
    }
    
    public boolean mapsAreEqual(Map<String, String> mapA, Map<String, String> mapB) {

        boolean b = mapA.entrySet().stream().filter(value -> mapB.entrySet().stream().anyMatch(value1 -> (value1.getKey() == value.getKey() && value1.getValue() == value.getValue()))).findAny().isPresent();
        return b;
    }
   
    
    
    
    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "35" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }

    }

}
