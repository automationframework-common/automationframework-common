package com.savvas.sm.reports.api.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

public class GetGroupListForSelectedTeachers extends GroupAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String teacherDetails1 = null;
    private String teacherDetails2 = null;
    private String studentDetail = null;
    private String studentDetail2 = null;
    private String studentUsername = null;
    public Boolean result = null;

    //private String teacherDetails3 = null;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String school1 = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String accessToken;
    RBSUtils rbs = new RBSUtils();
    public String userId;
    public String userId1;
    public String userId2;
    public String orgId;
    public String orgId2;
    // public String orgId1;
    public String username;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    //public String courseID;
    public String studentID1;
    public String studentID2;

    public String classId1;
    public String classId2;
    public String class1;
    public String class2;
    public HashMap<String, String> assignmentDetails = new HashMap<>();
    public String createTeacher;
    public String multipleSchoolTeacherID;
    public String multipleSchoolTeacherName;
    HashMap<String, String> assignCourseToTheStudent = new HashMap<String, String>();
    public static String fName;
    public static String mName;
    public static String lName;
    public static String studId;
    public static String uName;
    public static String duplicateClassId;
    List<String> classIds = new ArrayList<>();
    List<String> multiOrgAclassIds = new ArrayList<>();
    List<String> multiOrgBclassIds = new ArrayList<>();

    public String adminToken;

    @BeforeTest
    public void BeforeSuite() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher( school1 );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentDetail2 = RBSDataSetup.getMyStudent( school1, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentID1 = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentID2 = SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USERID_HEADER );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        userId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        orgId = RBSDataSetup.organizationIDs.get( school );
        orgId2 = RBSDataSetup.organizationIDs.get( school1 );
        List<String> schools = new ArrayList<String>();
        List<String> stuIDs = new ArrayList<String>();
        List<String> stuIDs1 = new ArrayList<String>();
        stuIDs.add( studentID1 );
        stuIDs.add( studentID2 );
        HashMap<String, String> userDetails = new HashMap<String, String>();
        String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

        // adminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );

        schools.add( orgId );
        schools.add( orgId2 );
        String listString = "";
        for ( String school : schools ) {
            listString += school.concat( "\",\"" );
        }
        listString = listString.substring( 0, listString.length() - 3 );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
        String createUser = rbs.createUser( userDetails );

        multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
        multipleSchoolTeacherName = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );
        HashMap<String, String> classDetails = new HashMap<>();
        for ( int i = 1; i <= 5; i++ ) {
            String classId = null;
            String className = "Test Class" + System.nanoTime();
            classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            classDetails.put( GroupConstants.GROUP_OWNER_ID, userId );
            classDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            classDetails.put( GroupConstants.GROUP_NAME, className );
            classId = SMUtils.getKeyValueFromResponse( createGroup( smUrl, classDetails, stuIDs ).get( CommonAPIConstants.BODY ), "data,groupId" );
            classIds.add( classId );
        }

        HashMap<String, String> classDetails1 = new HashMap<>();
        accessToken = rbs.getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        for ( int i = 1; i <= 5; i++ ) {
            String classId = null;
            String className = "Test Class OrgA" + System.nanoTime();
            accessToken = rbs.getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            classDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            classDetails1.put( GroupConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
            classDetails1.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            classDetails1.put( GroupConstants.GROUP_NAME, className );
            classId = SMUtils.getKeyValueFromResponse( createGroup( smUrl, classDetails1, stuIDs ).get( CommonAPIConstants.BODY ), "data,groupId" );
            multiOrgAclassIds.add( classId );
        }

        HashMap<String, String> classDetails2 = new HashMap<>();
        for ( int i = 1; i <= 5; i++ ) {
            String classId = null;
            accessToken = rbs.getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            String className = "Test Class OrgB" + System.nanoTime();
            classDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            classDetails2.put( GroupConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
            classDetails2.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId2 );
            classDetails2.put( GroupConstants.GROUP_NAME, className );
            classId = SMUtils.getKeyValueFromResponse( createGroup( smUrl, classDetails2, stuIDs ).get( CommonAPIConstants.BODY ), "data,groupId" );
            multiOrgBclassIds.add( classId );
        }

    }

    @Test ( dataProvider = "validCase", groups = { "SMK-50584", "Admin", "Get Group List for Selected Teacher in the Admin", "P1", "API" } )
    public void tcgetGroupListTest01( String description, String scenario, String statusCode ) throws Exception {
        List<String> teacherIds = new ArrayList<>();
        List<String> Schools = new ArrayList<>();
        List<String> groupId = new ArrayList<>();
        List<String> groupNameFromResponse;
        List<String> groupIdFromResponse;
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> response;
        String accessToken1 = null;
        String adminDetails;
        String adminUserId;
        String adminUserName;
        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                accessToken1 = rbs.getAccessToken( username, password );
                teacherIds.add( userId );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                groupNameFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_NAME );
                groupIdFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_ID );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( GroupConstants.STAFF_ID, userId );
                groupId = getTeacherGroups( userDetails, GroupConstants.GROUP_ID );
                Log.assertThat( groupIdFromResponse.containsAll( groupId ), "Proper Response returned for District Admin", "Failed : Error" );
                break;

            case "SUB_DISTRICT_ADMIN":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                accessToken1 = rbs.getAccessToken( username, password );
                teacherIds.add( userId );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                groupNameFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_NAME );
                groupIdFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_ID );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( GroupConstants.STAFF_ID, userId );
                groupId = getTeacherGroups( userDetails, GroupConstants.GROUP_ID );
                Log.assertThat( groupIdFromResponse.containsAll( groupId ), "Proper Response returned for District Admin", "Failed : Error" );
                break;

            case "SCHOOL_ADMIN":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                accessToken1 = rbs.getAccessToken( username, password );
                teacherIds.add( userId );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                groupNameFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_NAME );
                groupIdFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_ID );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( GroupConstants.STAFF_ID, userId );
                groupId = getTeacherGroups( userDetails, GroupConstants.GROUP_ID );
                Log.assertThat( groupIdFromResponse.containsAll( groupId ), "Proper Response returned for District Admin", "Failed : Error" );
                break;

            case "MULTI_SCHOOL_ADMIN":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                accessToken1 = rbs.getAccessToken( username, password );
                teacherIds.add( userId );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                groupNameFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_NAME );
                groupIdFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_ID );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( GroupConstants.STAFF_ID, userId );
                groupId = getTeacherGroups( userDetails, GroupConstants.GROUP_ID );
                Log.assertThat( groupIdFromResponse.containsAll( groupId ), "Proper Response returned for District Admin", "Failed : Error" );
                break;

            case "TEACHER_PART_OF_TWO_ORGS":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                accessToken1 = rbs.getAccessToken( multipleSchoolTeacherName, password );
                teacherIds.add( multipleSchoolTeacherID );
                Schools.add( orgId );
                Schools.add( orgId2 );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                groupNameFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_NAME );
                groupIdFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_ID );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                List<String> groupIds = getTeacherGroups( userDetails, "groupId" );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId2 );
                userDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                List<String> groupIdsFromAnotherOrg = getTeacherGroups( userDetails, GroupConstants.GROUP_ID );
                groupIds.addAll( groupIdsFromAnotherOrg );
                Log.assertThat( groupIds.containsAll( groupIdFromResponse ), "Groups are Fetched on the From Both the Orgs", "Error: No Fetched As Expected" );

                break;

            case "ORG_FILTER_MULTI_ORG_TEACHER":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                accessToken1 = rbs.getAccessToken( multipleSchoolTeacherName, password );
                teacherIds.add( multipleSchoolTeacherID );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                groupNameFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_NAME );
                groupIdFromResponse = getGroupNameFromResponse( response, GroupConstants.GROUP_ID );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                userDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                groupId = getTeacherGroups( userDetails, GroupConstants.GROUP_ID );
                Log.assertThat( groupId.contains( groupIdFromResponse ), "Groups are Fetched on the basis of Orgs Filtered", "Error: No Fetched As Expected" );
                break;

        }

    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "validCase" )
    public Object[][] getGroupList() {

        Object[][] inputData = { { "Verify the classes being displayed by passing the DIstrict admin", "DISTRICT_ADMIN", "200" }, { "Verify API return all the Groups part of the Single Teacher passed in the teacherIds field", "DISTRICT_ADMIN", "200" },
                { "Verify the classes being displayed by passing the SUB DIstrict admin", "SUB_DISTRICT_ADMIN", "200" }, { "Verify group id field in the response recent Session report", "SUB_DISTRICT_ADMIN", "200" },
                { "Verify groupName field in the response", "SUB_DISTRICT_ADMIN", "200" }, { "Verify the classes being displayed by passing the  School admin", "SCHOOL_ADMIN", "200" },
                { "Verify the classes being displayed by passing the  Multi School admin", "MULTI_SCHOOL_ADMIN", "200" }, { "Verify API return all the Groups part of the Shared Teacher", "MULTI_SCHOOL_ADMIN", "200" },
                { " Verify API return all the Groups for When Multiple Teachers that are given in the teacherIds field", "MULTI_SCHOOL_ADMIN", "200" },
                { "Verify if the teacher is part of multiple orgs and has groups in multiple orgs then it should list all", "TEACHER_PART_OF_TWO_ORGS", "200" },
                { "Verify the Groups are fetched on base of the Org filter", "ORG_FILTER_MULTI_ORG_TEACHER", "200" } };
        return inputData;
    }

    @Test ( dataProvider = "invalidCase", groups = { "SMK-50584", "Admin", "Get Group List for Selected Teacher in the Admin", "P1", "API" } )
    public void tcgetGroupListTest02( String description, String scenario, String statusCode ) throws Exception {
        List<String> teacherIds = new ArrayList<>();
        List<String> Schools = new ArrayList<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> response;
        String exceptionMessage = null;
        JSONObject jsonObject;
        JSONArray array;
        String adminUserName = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        switch ( scenario ) {

            case "INVALID_AUTHORIZATION":
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherIds.add( userId );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
                array = jsonObject.getJSONArray( "errors" );
                exceptionMessage = array.getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( true, "Proper Error Message Thrown for Invalid Authentication", "Failed : Proper Error Message not thrown" );
                break;

            case "INVALID_ADMIN_ID":
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherIds.add( userId );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                try {
                    jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
                    array = jsonObject.getJSONArray( "errors" );
                } catch ( Exception e ) {
                    Log.fail( "For Invalid Admin Getting Response" );
                }
                break;

            case "INVALID_TEACHER_ ID":
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherIds.add( userId + 34 );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                JSONObject jsonObject1 = new JSONObject( response.get( CommonAPIConstants.BODY ) );
                JSONArray array1 = jsonObject1.getJSONArray( "errors" );
                exceptionMessage = array1.getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( exceptionMessage.equals( "400: Bad Request" ), "Proper Error Message Thrown for Invalid Authentication", "Failed : Proper Error Message not thrown" );
                break;

            case "MIXED_OF_INVALID_AND_VALID":
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherIds.add( userId );
                teacherIds.add( userId + 23 );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserId );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
                array = jsonObject.getJSONArray( "errors" );
                String exceptionsMessage2 = array.getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( exceptionsMessage2.equals( "400: Bad Request" ), "Proper Error Message Thrown for Invalid Authentication", "Failed : Proper Error Message not thrown" );
                break;

            case "DELETED_TEACHER":
                accessToken = rbs.getAccessToken( "SmAutoCA_433179880678800", password );
                List<String> toDelete = new ArrayList<>();
                toDelete.add( multipleSchoolTeacherID );
                rbs.deleteUser( toDelete );
                // After Deleting the Student due to Solar indexing requires 3 minutes to reflect the change Bug No : https://jira.savvasdev.com/browse/SMK-58807
                Thread.sleep( 3 * 60000 );
                teacherIds.add( multipleSchoolTeacherID );
                Schools.add( orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.RUMBA_ID, adminUserName );
                response = getGroupListForGivenTeacherIdAdminReports( apiDetails, teacherIds, Schools );
                jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
                array = jsonObject.getJSONArray( "errors" );
                exceptionMessage = array.getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( exceptionMessage.equals( "400: Bad Request" ), "Proper Error Message Thrown for Invalid Authentication", "Failed : Proper Error Message not thrown" );
                break;

        }

    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "invalidCase" )
    public Object[][] getGroupList1() {

        Object[][] inputData = { { "Verify the Response for Invalid Authorization", "INVALID_AUTHORIZATION", "200" }, { "Verify the Response for Invalid admin User id", "INVALID_ADMIN_ID", "200" },
                { "Verify the Response when Invalid teacher id passed in the teacherIds field", "INVALID_TEACHER_ ID", "200" },
                { "Verify the response when Mixture of valid and invalid teacher ids are passed in the field", "MIXED_OF_INVALID_AND_VALID", "200" }, { "Verify the Response When Deleted Teacher id is given as the input", "DELETED_TEACHER", "200" } };
        return inputData;
    }

    // To Get the Group ID and Group Name from the Response
    public List<String> getGroupNameFromResponse( HashMap<String, String> response, String Option ) {
        List<String> gradeIds = new ArrayList<>();
        List<String> gradeNames = new ArrayList<>();
        List<String> groupDetails = new ArrayList<>();
        JSONObject jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
        JSONArray jsonArray = jsonObject.getJSONObject( CommonAPIConstants.DATA ).getJSONObject( "getGroupsList" ).getJSONArray( Constants.MasteryUI.GROUPS );
        for ( int i = 0; i < jsonArray.length(); i++ ) {
            if ( Option.equals( GroupConstants.GROUP_ID ) ) {
                gradeIds.add( jsonArray.getJSONObject( i ).get( GroupConstants.GROUP_ID ).toString() );
                groupDetails = gradeIds;
            } else {
                gradeIds.add( jsonArray.getJSONObject( i ).get( GroupConstants.GROUP_NAME ).toString() );
                groupDetails = gradeNames;
            }
        }
        return groupDetails;
    }

    public List<String> getTeacherGroups( HashMap<String, String> apiDetails, String option ) throws Exception {
        HashMap<String, String> response = getGroupListingForTeacherID( smUrl, apiDetails );
        List<String> actualGrpName = new ArrayList<String>();
        List<String> data = new ArrayList<String>();
        List<String> actualClassId = new ArrayList<String>();
        Boolean response1;
        RBSUtils rbs = new RBSUtils();

        JSONObject jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
        JSONArray array = jsonObject.getJSONArray( CommonAPIConstants.DATA );

        for ( int iter = 0; iter < array.length(); iter++ ) {
            String eachObject = array.getJSONObject( iter ).toString();
            actualGrpName.add( SMUtils.getKeyValueFromResponse( eachObject, GroupConstants.GROUP_NAME ) );
            actualClassId.add( SMUtils.getKeyValueFromResponse( eachObject, GroupConstants.GROUP_ID ) );
        }
        if ( option.equals( GroupConstants.GROUP_NAME ) ) {
            data = actualGrpName;
        } else {
            data = actualClassId;
        }
        return data;

    }

}
