package com.savvas.sm.reports.teacher.ui.tests;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.reports.teacher.ui.pages.CumulativePerformanceReportPage;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import io.restassured.response.Response;

public class CumulativePerformanceReportTeacherMFE extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String teacherDetails;
    private String selectedSchoolId;
    private String studentId;
    private String studentId1;
    private String studentNameAndGrade;
    String organizationId = null;
    String teacherId = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchoolStudentDetails = null;
    private String flexSchoolStudentDetailsSecond = null;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    Response response;
    private String orgId = null;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> contentBaseName = new HashMap<>();
    private static HashMap<String, String> assignmentIds = new HashMap<String, String>();

    private List<String> courseIDs = new ArrayList<>();
    private List<String> schools = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private HashMap<String, String> userDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();

    private String exception = null;
    private boolean status = false;
    private String message = null;
    // other school constants
    private String studentDetail = null;
    private String studentUserID;
    private String studentUsername;
    private String groupID;
    ReportComponents reportComponent;
    ReportFilterComponent reportFilterComponent;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        flexSchoolStudentDetails = RBSDataSetup.getMyStudent( school, username );
        flexSchoolStudentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        organizationId = RBSDataSetup.organizationIDs.get( school );
        orgId = organizationId;
        studentId = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetails, "userId" );
        studentId1 = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetailsSecond, "userId" );
        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        Log.message( "studentdetails"+studentDetail );

        studentRumbaIds.add( studentUserID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );
        HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
        groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Math: Grade 1" );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );

        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );
        String username = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        Log.message( "username:" + username );
        try {
            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
//                        executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );

                        executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
//                        executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );

        } catch ( IOException e ) {
            e.printStackTrace();
        }

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        Log.message( "assignmentDetailsJson" + assignmentDetailsJson );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment IDs - " + assignmentIds );

    }

    @Test ( description = "Verify the Cummulative performance Report Output screen with BFF data - Reading", groups = { "SMK-71934", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPRBFFMFE01() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMCPRBFFMFE01: Verify user able to select the course as math and run the report <small><b><i>[" + browser
                + "]</b></i></small>" );
        String payload = null;
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher( username, password );

            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to cPR Page
            CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents.clickOnCumulativePerformanceReportPage();
            reportFilterComponent = new ReportFilterComponent( driver );

            reportFilterComponent.clickStudentRadioButton();
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );

            int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

            payload = getResponseBody( teacherId, orgId, 1, false, new ArrayList<>(), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );

            HashMap<String, String> headers = new HashMap<>();
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getDataFromResponse( response.getBody().asString() );
            Log.message( "getListOfValuesFromAPIOutput" + exp );

            //validation
            List<String> key = new ArrayList<>( exp.keySet() );
            boolean b = act.get( studentNameAndGrade ).stream().anyMatch( apiValue -> exp.get( key.get( 0 ) ).stream().anyMatch( uiValue -> apiValue.contains( uiValue ) ) );
            Log.assertThat( b, "Report data are same as DB data", "Report data are not same as DB data" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Cummulative performance Report Output screen with BFF data - Reading", groups = { "SMK-71934", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPRBFFMFE02() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMCPRBFFMFE02: Verify user able to view data for a selected student(s) only <small><b><i>[" + browser
                + "]</b></i></small>" );
        Log.testCaseInfo("Verify user able to select the course as READING and run the report");
        
        String payload = null;
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher( username, password );

            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to cPR Page
            CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents.clickOnCumulativePerformanceReportPage();
            reportFilterComponent = new ReportFilterComponent( driver );

            //            reportFilterComponent.clickStudentRadioButton();
            reportFilterComponent.selectSubject( "Reading" );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );
            int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
            payload = getResponseBody( teacherId, orgId, 2, false, new ArrayList<>(), Arrays.asList( studentUserID ), new ArrayList<>() );

            HashMap<String, String> headers = new HashMap<>();
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getDataFromResponse( response.getBody().asString() );
            Log.message( "getListOfValuesFromAPIOutput" + exp );

            exp.keySet();
            List<String> key = new ArrayList<>( exp.keySet() );
            boolean b = exp.get( key.get( 0 ) ).stream().anyMatch( apiValue -> act.get( studentNameAndGrade ).stream().anyMatch( uiValue -> apiValue.contains( uiValue ) ) );
            Log.assertThat( b, "Report data are same as DB data", "Report data are not same as DB data" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    
    @Test ( description = "Verify user able to view on the selected Groups only", groups = { "SMK-71934", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPRBFFMFE03() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMCPRBFFMFE03:Verify user able to select and run report with additional group as \"group\". <small><b><i>[" + browser
                + "]</b></i></small>" );
        Log.testCaseInfo("Verify Teacher able to run the \"Selected date range\" report");
        String payload = null;
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher( username, password );

            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to cPR Page
            CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents.clickOnCumulativePerformanceReportPage();
            reportFilterComponent = new ReportFilterComponent( driver );

            reportFilterComponent.clickStudentRadioButton();
            
//         // DeSelect All checkbox
//            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
//                    Arrays.asList(ReportsUIConstants.ALL));
//
//            List<String> studentsFromUI = reportFilterComponent
//                    .getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN);
//
//            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
//                    Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3)));
            
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            
       reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
      reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Assigned Course Level" );

      

      // Date Range Selected Check
      DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );

      LocalDate from = LocalDate.now().with( TemporalAdjusters.firstDayOfMonth() );
      LocalDate to = LocalDate.now().with( TemporalAdjusters.lastDayOfMonth() );

      String startDate = dateFormat.format( ( from ) );
      String endDate = dateFormat.format( to );

      String[] fromValues = startDate.split( "/" );
      String[] EndValues = endDate.split( "/" );

      CumulativePerformancePage cumulativePerformancePage = new CumulativePerformancePage(driver) ;

      cumulativePerformancePage.clickSelectedDateRangeButton();

//      cumulativePerformancePage.enterCurrentDateInStartAndEndCalendar();
      
      SMUtils.waitForSpinnertoDisapper( driver , 20);
      cumulativePerformancePage.enterCurrentDateInStartCalendar();
      SMUtils.waitForSpinnertoDisapper( driver );
      cumulativePerformancePage.enterCurrentDateInToCalendar();
      
      // Verify mask student field
      Log.assertThat(
              cumulativePerformance.reportComponent.isMaskStudentDisplayDisplayed(
                      ReportsUIConstants.MASK_STUDENT),
              "Mask student field is present in the CPR page",
              "Mask student field is not present in the CPR page");

      cumulativePerformance.reportComponent.checkOrUncheckBoxMaskstudent();
      Log.message("Mask student chekbox clicked");
      
      cumulativePerformancePage.clickAllDatesButton();

            reportFilterComponent.clickRunReportButton();
          

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );

            int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

            payload = getResponseBody( teacherId, orgId, 1, false, new ArrayList<>(), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );

            HashMap<String, String> headers = new HashMap<>();
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getDataFromResponse( response.getBody().asString() );
            Log.message( "getListOfValuesFromAPIOutput" + exp );

            //validation
            List<String> key = new ArrayList<>( exp.keySet() );
            boolean b = act.get( studentNameAndGrade ).stream().anyMatch( apiValue -> exp.get( key.get( 0 ) ).stream().anyMatch( uiValue -> apiValue.contains( uiValue ) ) );
            Log.assertThat( b, "Report data are same as DB data", "Report data are not same as DB data" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }
    
    @Test ( description = "Verify user able to select and run report with additional group as grade", groups = { "SMK-71934", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPRBFFMFE04() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMCPRBFFMFE04: Verify user able to select and run report with additional group with display name as \"student username\".<small><b><i>[" + browser
                + "]</b></i></small>" );
        String payload = null;
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher( username, password );

            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to cPR Page
            CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents.clickOnCumulativePerformanceReportPage();
            reportFilterComponent = new ReportFilterComponent( driver );

//            reportFilterComponent.clickStudentRadioButton();
            
         // DeSelect All checkbox
            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
                    Arrays.asList(ReportsUIConstants.ALL));

            List<String> studentsFromUI = reportFilterComponent
                    .getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
                    Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3)));
            
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
      reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Assigned Course Level" );

            reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );

            int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

            payload = getResponseBody( teacherId, orgId, 1, false, new ArrayList<>(), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );

            HashMap<String, String> headers = new HashMap<>();
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getDataFromResponse( response.getBody().asString() );
            Log.message( "getListOfValuesFromAPIOutput" + exp );

            //validation
            List<String> key = new ArrayList<>( exp.keySet() );
            boolean b = act.get( studentNameAndGrade ).stream().anyMatch( apiValue -> exp.get( key.get( 0 ) ).stream().anyMatch( uiValue -> apiValue.contains( uiValue ) ) );
            Log.assertThat( b, "Report data are same as DB data", "Report data are not same as DB data" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }
    
    @Test ( description = "Verify User can able to run the report option with 'Current course Level' in sort Dropdown with display on CP Report and load the report", groups = { "SMK-71934", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPRBFFMFE05() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMCPRBFFMFE05: Verify User can able to run the report option with \"IP Level\" in sort Dropdown with display on CP Report and load the report <small><b><i>[" + browser
                + "]</b></i></small>" );
        Log.testCaseInfo("Verify user able to select and run report with additional group as NONE");
        String payload = null;
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher( username, password );

            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to cPR Page
            CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents.clickOnCumulativePerformanceReportPage();
            reportFilterComponent = new ReportFilterComponent( driver );

//            reportFilterComponent.clickStudentRadioButton();
            
         // DeSelect All checkbox
            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
                    Arrays.asList(ReportsUIConstants.ALL));

            List<String> studentsFromUI = reportFilterComponent
                    .getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
                    Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3)));
            
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Name" );
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
      reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Percent Correct" );

            reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );

            int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

            payload = getResponseBody( teacherId, orgId, 1, false, new ArrayList<>(), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );

            HashMap<String, String> headers = new HashMap<>();
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getDataFromResponse( response.getBody().asString() );
            Log.message( "getListOfValuesFromAPIOutput" + exp );

            //validation
            List<String> key = new ArrayList<>( exp.keySet() );
            boolean b = act.get( studentNameAndGrade ).stream().anyMatch( apiValue -> exp.get( key.get( 0 ) ).stream().anyMatch( uiValue -> apiValue.contains( uiValue ) ) );
            Log.assertThat( b, "Report data are same as DB data", "Report data are not same as DB data" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }
    
    @Test ( description = "Verify User can able to run the report option with 'Excercises Correct' in sort Dropdown and load the report", groups = { "SMK-71934", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPRBFFMFE06() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMCPRBFFMFE06: Verify Teacher able to run the \"All date\" report <small><b><i>[" + browser
                + "]</b></i></small>" );
        Log.testCaseInfo( "Verify mask student display and verify the report page.");
        Log.testCaseInfo("Verify Admin can select dates to generate CP report, by default All Dates is selected. ");
        String payload = null;
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher( username, password );

            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to cPR Page
            CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents.clickOnCumulativePerformanceReportPage();
            reportFilterComponent = new ReportFilterComponent( driver );

//            reportFilterComponent.clickStudentRadioButton();
            
         // DeSelect All checkbox
            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
                    Arrays.asList(ReportsUIConstants.ALL));

            List<String> studentsFromUI = reportFilterComponent
                    .getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

            reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN,
                    Arrays.asList(studentsFromUI.get(1), studentsFromUI.get(2), studentsFromUI.get(3)));
            
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Name" );
            reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
      reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Percent Correct" );

      

      // Verify mask student field
      Log.assertThat(
              cumulativePerformance.reportComponent.isMaskStudentDisplayDisplayed(
                      ReportsUIConstants.MASK_STUDENT),
              "Mask student field is present in the CPR page",
              "Mask student field is not present in the CPR page");

      cumulativePerformance.reportComponent.checkOrUncheckBoxMaskstudent();
      Log.message("Mask student chekbox clicked");
            reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
            Log.message( "getListOfValuesFromUIOutput" + act );

            // payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( 1233444 ) );

            int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

            payload = getResponseBody( teacherId, orgId, 1, false, new ArrayList<>(), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ) );

            HashMap<String, String> headers = new HashMap<>();
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

            HashMap<String, List<String>> exp = getDataFromResponse( response.getBody().asString() );
            Log.message( "getListOfValuesFromAPIOutput" + exp );

            //validation
            List<String> key = new ArrayList<>( exp.keySet() );
            boolean b = act.get( studentNameAndGrade ).stream().anyMatch( apiValue -> exp.get( key.get( 0 ) ).stream().anyMatch( uiValue -> apiValue.contains( uiValue ) ) );
            Log.assertThat( b, "Report data are same as DB data", "Report data are not same as DB data" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }
    // Get response body
    public String getResponseBody( String userId, String orgId, int subject, boolean isGroupSelected, List<String> groupIds, List<String> studentIds, List<Integer> assignmentIds ) {
        AtomicReference<String> requestBody = new AtomicReference<>();
        try {


            String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report"
                    + File.separator;
            requestBody.set( SMUtils.convertFileToString( basePath + "CPRTeacher_MFE_BFF.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", orgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.teacherId", userId ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.isGroupSelected", isGroupSelected ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.studentIds", studentIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.groupIds", groupIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.assignmentIds", assignmentIds ) );

            Log.message( "Payload : " + requestBody.get() );
            Log.message( "" + "************************************************************************************************\n" );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return requestBody.get();
    }

    public HashMap<String, List<String>> getListOfValuesFromUIOutput( WebDriver driver ) {
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();

        PrescriptiveSchedulingPage prescriptiveSchedulingPage = new PrescriptiveSchedulingPage( driver );
        boolean flag = true;
        while ( flag ) {

            // Data From UI
            String assignmentTitle = driver.findElement( By.tagName( "h3" ) ).getText().trim();
            String grade = prescriptiveSchedulingPage.getGrade();

            // Single Page row count
            int rowCount = driver.findElements( By.xpath( PrescriptiveSchedulingPage.rowCountXpath ) ).size();

            IntStream.rangeClosed( 1, rowCount ).forEach( rowIndex -> {
                List<String> arrayList = new LinkedList<String>();

                arrayList.clear();
                // Getting all the values from single row
                IntStream.rangeClosed( 1, 13 ).forEach( columnIndex -> {
                    String formatted = String.format( PrescriptiveSchedulingPage.studentData, rowIndex, columnIndex );

                    arrayList.add( driver.findElement( By.xpath( formatted ) ).getText().trim() );
                } );

                String assignmentStudentName = assignmentTitle + ":" + arrayList.get( 0 );
                arrayList.remove( 0 );
                studentNameAndGrade = assignmentStudentName + grade;

                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    Log.message( allStudentValuesList + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName + grade ) );
                    allStudentValuesList.put( assignmentStudentName + grade, arrayList );
                } else {
                    allStudentValuesList.put( assignmentStudentName + grade, arrayList );
                }
            } );

            // clicking next button
            flag = prescriptiveSchedulingPage.clickNextButtoninOuputPage();
            SMUtils.nap( 1.5 );
        }
        return allStudentValuesList;
    }

    // Get response for reading data
    public HashMap<String, List<String>> getDataFromResponse( String response ) {

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( response, "data,getCPReportData,cpReportData" );
        Log.message( "Response Data: " + jsonObj );

        //HashMap<String, String> studentReport = new HashMap<>();

        HashMap<String, List<String>> studentReport = null;
        studentReport = new HashMap<String, List<String>>();

        //test
        List<String> StrandDescription = new ArrayList<>();
        List<String> StrandLevel = new ArrayList<>();

        String rawPerformance = getKeyValueFromResponseWithArray( jsonObj, "rows" );
        //Loop1
        IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {

            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "assignedLevel" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "currentCourseLevel" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "ipmEndLevel" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "ipmGain" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalTime" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalSessions" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalExercisesCorrect" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalExercisesAttempted" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalSkillsMastered" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalSkillsCompleted" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "exercisesPercentCorrect" ) );
            StrandLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "skillsPercentMastered" ) );

        } );

        //        List<String> newList = StrandDescription.stream().distinct().collect( Collectors.toList() );
        //        List<String> newList2 = StrandLevel.stream().distinct().collect( Collectors.toList() );
        Log.message( "" + "************************************************************************************************\n" );
        studentReport.put( "StrandLevel", StrandLevel );

        Log.message( "Response Reading Data: " + studentReport );
        Log.message( "" + "************************************************************************************************\n" );
        return studentReport;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {
            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();
                //return keyValue;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "2", "80" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "2", "80" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }

    }
}
