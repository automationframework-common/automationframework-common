package com.savvas.sm.reports.admin.ui.pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;

public class CumulativePerformancePage extends LoadableComponent<CumulativePerformancePage> {

    WebDriver driver;
    boolean isPageLoaded;
    public AdminReportFilterComponent reportFilterComponent;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @IFindBy ( how = How.TAG_NAME, using = "h1", AI = false )
    private WebElement pageTitle;

    @IFindBy ( how = How.CSS, using = "cel-tab-panel.tab-panel", AI = false )
    private WebElement togglebutton;

    @IFindBy ( how = How.CSS, using = "cel-tab-panel.tab-panel-cumulativePerformance", AI = false )
    private WebElement cprAggregatetoggle;

    @IFindBy ( how = How.CSS, using = "performance-dates cel-date-range", AI = false )
    private WebElement dateRangeRoot;

    /******************* Child Elements ******************************/

    private String button = "button";

    /*** Calendar Web Elements ***/
    private String radioButtonRoot = "cel-radio-button-group";
    private String radioButtonChildRoot = "div > div > cel-radio-button:nth-child(%s)";
    private String allDatesCss = "#all";
    private String selectedDateRangeCss = "#dates";
    public static String CALENDER_ICON_ROOT1 = "cel-date-range";
    public static String CALENDER_ICON_FROM_ROOT2 = "cel-date-input.from";
    public static String CALENDER_ICON_TO_ROOT2 = "cel-date-input.to";
    public static String CALENDER_ICON_ROOT3 = "cel-icon-button";
    public static String CALENDER_ICON_ROOT4 = "button > cel-icon";
    private String fromDateroot = "cel-date-input.from";
    private String toDateroot = "cel-date-input.to";
    private String input = "input";
    private String CalendarNavIcon = "document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.date-input.%s.hydrated').shadowRoot.querySelector('cel-date-popup').shadowRoot.querySelector('cel-calendar').shadowRoot.querySelector('div.calendar-header > cel-icon-button:nth-child(%s)').shadowRoot.querySelector('button > cel-icon').shadowRoot.querySelector('div').click()";
    private String datePickedValues = "return document.querySelector('cel-date-range').shadowRoot.querySelector('cel-date-input.date-input.%s.hydrated').shadowRoot.querySelector('#celDateInput').value;";
    private String div = "div";

    public CumulativePerformancePage() {}

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public CumulativePerformancePage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        reportFilterComponent = new AdminReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );
    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "Cumulative Performance Page loaded successfully." );
        } else {
            Log.fail( "Cumulative Performance Page not loaded successfully." );
        }
        elementLayer = new ElementLayer( driver );
    }

    /**
     * navigate To CPA Report
     * 
     */

    public CumulativePerformanceAggregatePage navigateToCPAReport() {
        Log.message( "Clicking on the Cumulative Performance Aggregate element in sub-navigation" );
        SMUtils.getWebElementsDirect( driver, togglebutton, button ).stream().filter( element -> element.getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE_AGGREGATE ) ).forEach( element -> SMUtils.clickJS( driver, element ) );
        return new CumulativePerformanceAggregatePage( driver ).get();
    }

    /**
     * To Click the Run Report button
     * 
     * @return
     */
    public CumulativePerformanceReportViewerPage clickRunReportButton() {
        reportFilterComponent.clickRunReportButton();
        return new CumulativePerformanceReportViewerPage( driver ).get();
    }

    /**
     * click the Radio Button All Dates
     */
    public void clickAllDatesButton() {
        WebElement root = driver.findElement( By.cssSelector( radioButtonRoot ) );
        WebElement element = SMUtils.getWebElementDirect( driver, root, String.format( radioButtonChildRoot, "1" ), allDatesCss );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked radio button : All Dates" );
    }

    /**
     * Click the Radio Button - Selected Date Ranges
     */
    public void clickSelectedDateRangeButton() {
        WebElement root = driver.findElement( By.cssSelector( radioButtonRoot ) );
        WebElement element = SMUtils.getWebElementDirect( driver, root, radioButtonChildRoot.format( radioButtonChildRoot, "2" ), selectedDateRangeCss );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked radio button : Selected Date Range" );
        SMUtils.nap( 5 );
    }

    /**
     * Get the Start Dates and End Dates from the Selected Date Range Fields
     * 
     * @return
     */
    public List<String> getSelectedDatesFromCalendar() {
        List<String> dates = new ArrayList<>();
        dates.add( SMUtils.getWebElementDirect( driver, dateRangeRoot, fromDateroot, input ).getAttribute( "value" ) );
        dates.add( SMUtils.getWebElementDirect( driver, dateRangeRoot, toDateroot, input ).getAttribute( "value" ) );
        return dates;
    }

    /**
     * To click Start Date Text Box in the Selected Date Range - CP Report
     * 
     * @return
     * @throws InterruptedException
     */
    public void enterCurrentDateInStartAndEndCalendar() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 30 );
        Log.message( "Entering current Date field in From Calendar..." );
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDate dateObj = LocalDate.now();
        clickStartDateCalendar();
        Actions action = new Actions( driver );
        action.sendKeys( Keys.ENTER ).build().perform();
        action.sendKeys( Keys.ENTER ).build().perform();
    }

    /**
     * Click Start Calendar Icon
     */
    public void clickStartDateCalendar() {
        WebElement element = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( CALENDER_ICON_ROOT1 ) ), CALENDER_ICON_FROM_ROOT2, CALENDER_ICON_ROOT3, CALENDER_ICON_ROOT4, "div" );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked  Calendare Icon - From" );
        SMUtils.nap( 2 ); // wait for calendar popup to load
    }

    /**
     * Click Calendar Icon End Date
     */
    public void clickEndDateCalender() {
        WebElement element = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( CALENDER_ICON_ROOT1 ) ), CALENDER_ICON_TO_ROOT2, CALENDER_ICON_ROOT3, CALENDER_ICON_ROOT4, "div" );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Clicked  Calendare Icon - To" );
        SMUtils.nap( 2 ); // wait for calendar popup to load
    }

}