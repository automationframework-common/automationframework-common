package com.savvas.sm.reports.ui.tests.admin.afg;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.DemographicFilters;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportSubHeader;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.utils.Constants.Students;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;

import io.restassured.response.Response;

public class AFGReportViewerTest extends EnvProperties {

    private String smUrl;
    private String browser;

    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String organizationName;
    private String studentId;
    private String studentUsername;
    List<String> getSelectedOptioUI;
    private String adminUserId;
    private String teacherUsername;
    private String teacherName;
    private Response afgAdminReportData;
    private String flexSchoolId;
    Map<String, String> headers = new HashMap<>();
    Map<String, String> filters = new HashMap<>();

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host 
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        username = ReportDataCollection.districtAdmin;
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        String districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        studentUsername = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 1, usernameSuffixTest );
        adminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
        RBSUtils rbsUtils = new RBSUtils();
        String studentUserId = rbsUtils.getUserIDByUserName( studentUsername );
        studentId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( rbsUtils.getUserWithUserService( studentUserId ), "userMetaData,externalIds" ), "sisUserId" );
        teacherUsername = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 1, usernameSuffixTest );
        teacherName = "(" + SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( teacherUsername ), RBSDataSetupConstants.FIRSTNAME ) + " "
                + SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( teacherUsername ), RBSDataSetupConstants.LASTNAME ) + ")";
        flexSchoolId = new RBSUtils().getOrganizationIDByName( districtId, organizationName );

    }

    @Test ( description = "tcAFGOptionalFilter001: Verify selected assignments are displayed in AFG report viewer page.", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter001: Verify selected assignments are displayed in AFG report viewer page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
             afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            // Selecting Math subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //Selecting Math assignment
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            SMUtils.logDescriptionTC( "Verify the Run report button after selected organization, Subject and assignments" );
            Log.assertThat( afgPage.isRunButtonEnabled(), "Run report button is enabled after selecting an organization, Subject and assignments", "Run report button is not enabled after selecting an organization, Subject and assignments" );
            Log.testCaseResult();

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with math subject and default Math Assignment alone." );
            Log.assertThat( afgReportViewerPage.isSubHeaderDisplayed() && afgReportViewerPage.getAssignmentName().get( 0 ).equals( ReportsUIConstants.MATH ), "Math assignment is displayed in AFG report viewer page",
                    "Math assignment is not displayed in AFG report viewer page" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( afgReportViewerPage.verifyLegendHeaderAndLabels(), "The Areas Of Growth label values of the legend are displayed Successfully", "The Areas Of Growth label values of the legend not displayed properly" );
            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.assertThat( !afgReportViewerPage.nextButtonIsDisable(), "The report pages are displaying as expected", "The report pages are not displaying properly" );
            Log.testCaseResult();

            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();
            afgPage.reportFilterComponent.expandStudentDemographics();

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 6 ) ) );

            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the Zero state for report viewer page, if the selected organization has no \"Not Mastered\" skills to display" );

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.put( ReportConstants.DemographicFilters.RACE, ReportConstants.DemographicValues.RACE.get( 5 ) );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            String mathAssignmentIPOFF = DataSetupConstants.SETTINGS_COURSE_NAME_MATH.split( "_" )[1];
            String mathAssignmentIPON = DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH.split( "_" )[1];

            //Selecting IP OFF Math assignments
            String assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportDataCollection.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 6 ) ) );

            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Math subject and Custom by setting - IPM off assignment." );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();

            Log.assertThat( afgReportViewerPage.getAssignmentName().stream().allMatch( assignment -> assignment.contains( mathAssignmentIPOFF ) ), "Math custom by setting IP OFF assignment are displayed in AFG report viewer page",
                    "Math custom by setting IP OFF assignment are not displayed in AFG report viewer page" );
            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.mathSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.remove( ReportConstants.DemographicFilters.RACE, ReportConstants.DemographicValues.RACE.get( 5 ) );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.assertThat( !afgReportViewerPage.nextButtonIsDisable(), "The report pages are displaying as expected", "The report pages are not displaying properly" );
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            //Selecting IP ON Math assignments
            assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportDataCollection.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Math subject and Custom by setting - IPM on assignment." );
            Log.assertThat( afgReportViewerPage.getAssignmentName().stream().allMatch( assignment -> assignment.contains( mathAssignmentIPON ) ), "Math custom by setting IP ON assignment are displayed in AFG report viewer page",
                    "Math custom by setting IP ON assignment are not displayed in AFG report viewer page" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.mathSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.assertThat( !afgReportViewerPage.nextButtonIsDisable(), "The report pages are displaying as expected", "The report pages are not displaying properly" );
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            // Selecting Reading subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );

            // Select Reading assignment
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //To click the run report button 
            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Reading subject and default Reading Assignment alone." );
            Log.assertThat( afgReportViewerPage.isSubHeaderDisplayed() && afgReportViewerPage.getAssignmentName().get( 0 ).equals( ReportsUIConstants.READING ), "Reading assignment is displayed in AFG report viewer page",
                    "Reading assignment is not displayed in AFG report viewer page" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( afgReportViewerPage.verifyLegendHeaderAndLabels(), "The Areas Of Growth label values of the legend are displayed Successfully", "The Areas Of Growth label values of the legend not displayed properly" );
            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.READING );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            Response afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );
            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), ReportsUIConstants.READING, ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default reading course", "Skills are not displayed properly for default reading course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), ReportsUIConstants.READING, ReportsUIConstants.READING, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> {
                    List<String> expectedValueFromBFF = studentDetails.get( entry.getKey() );
                    Collections.sort( expectedValueFromBFF );
                    return expectedValueFromBFF.equals( entry.getValue() );
                } ), "All the students are displaying properly for default reading course", "Student details are not displayed properly for default reading course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.assertThat( !afgReportViewerPage.nextButtonIsDisable(), "The report pages are displaying as expected", "The report pages are not displaying properly" );
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            String readingAssignmentIPOFF = DataSetupConstants.SETTINGS_COURSE_NAME_READING.split( "_" )[1];
            String readingAssignmentIPON = DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING.split( "_" )[1];

            //Selecting IP OFF Reading assignments
            assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportDataCollection.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse(
                            null ),
                    "courseDetail,name" ) + " " + teacherName;
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Reading subject and Custom by setting - IPM off assignment." );
            Log.assertThat( afgReportViewerPage.getAssignmentName().stream().allMatch( assignment -> assignment.contains( readingAssignmentIPOFF ) ), "Reading custom by setting IP OFF assignment are displayed in AFG report viewer page",
                    "Reading custom by setting IP OFF assignment are not displayed in AFG report viewer page" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.READING );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.readingSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.assertThat( !afgReportViewerPage.nextButtonIsDisable(), "The report pages are displaying as expected", "The report pages are not displaying properly" );
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            //Selecting IP ON Reading assignments
            assignmentName = SMUtils.getKeyValueFromResponse(
                    ReportDataCollection.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                    "courseDetail,name" ) + " " + teacherName;
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Reading subject and Custom by setting - IPM on assignment." );
            Log.assertThat( afgReportViewerPage.getAssignmentName().stream().allMatch( assignment -> assignment.contains( readingAssignmentIPON ) ), "Reading custom by setting IP ON assignment are displayed in AFG report viewer page",
                    "Reading custom by setting IP ON assignment are not displayed in AFG report viewer page" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.READING );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), assignmentName.replace( teacherName, "" ).trim(), ReportsUIConstants.READING, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.assertThat( !afgReportViewerPage.nextButtonIsDisable(), "The report pages are displaying as expected", "The report pages are not displaying properly" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter002: Verify selected optional filters are displayed in AFG report viewer page.", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter002: Verify selected optional filters are displayed in AFG report viewer page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();

            List<String> teachers = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            List<String> groups = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );
            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with single teacher." );
            SMUtils.nap( 10 );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            List<String> schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            String selectedGroupOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).trim();
            String selectedGradeOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).trim();

            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( selectedGroupOptions ), "Group options are showing correctly for selected option", "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equalsIgnoreCase( selectedGradeOptions ), "Grade options are showing correctly for selected option", "Grade options are not showing properly" );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is displayed in sub-header in report viewer page" );
                Log.assertThat( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ).contains( teachers.get( 0 ) ), "Teacher name is displayed in sub-header in report viewer page",
                        "Teacher name is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();
            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Students.ALL_GRADES.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with one Grade." );
            List<String> selectedOptionsFromGradeDropdown = afgPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            List<String> selectedOptionsFromGroupDropdown = afgPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            SMUtils.nap( 10 );

            //To click the run report button 
            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            String selectedGrade = String.valueOf( selectedOptionsFromGradeDropdown.size() - 1 );
            selectedGroupOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).trim();
            selectedGradeOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", selectedGrade ).trim();

            if ( selectedGrade.equals( "1" ) ) {
                selectedGradeOptions = selectedGradeOptions.replace( "grades", "grade" );
            }
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( selectedGroupOptions ), "Group options are showing correctly for selected option", "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equalsIgnoreCase( selectedGradeOptions ), "Grade options are showing correctly for selected option", "Grade options are not showing properly" );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is displayed in sub-header in report viewer page" );
                Log.assertThat( Students.ALL_GRADES.containsAll( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ) ), "Grade is displayed in sub-header in report viewer page", "Grade is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.put( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();
            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );
            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with single Group." );
            SMUtils.nap( 10 );
            //To click the run report button 
            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            String selectedGroup = String.valueOf( selectedOptionsFromGroupDropdown.size() - 1 );
            selectedGroupOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).replace( "No", selectedGroup ).trim();
            selectedGradeOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).trim();

            if ( selectedGroup.equals( "1" ) ) {
                selectedGroupOptions = selectedGroupOptions.replace( "groups", "group" );
            }
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( selectedGroupOptions ), "Group options are showing correctly for selected option", "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equalsIgnoreCase( selectedGradeOptions ), "Grade options are showing correctly for selected option", "Grade options are not showing properly" );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is displayed in sub-header in report viewer page" );
                Log.assertThat( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ).contains( groups.get( 0 ) ), "Group name is displayed in sub-header in report viewer page", "Group name is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.put( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter003: Verify multiple selected optional filters are displayed in AFG report viewer page.", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter003: Verify multiple selected optional filters are displayed in AFG report viewer page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();

            List<String> teachers = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            List<String> groups = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 2 ) ) );
            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with multiple teachers." );
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            List<String> schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat( Arrays.asList( ReportsUIConstants.MULTIPLE_TEACHERS_SELECTED, ReportsUIConstants.ALL_VALUES ).containsAll( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ) ),
                        "Teacher name is displayed in sub-header in report viewer page", "Teacher name is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            String selectedGroupOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim();
            String selectedGradeOptions = ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim();
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( selectedGroupOptions ), "Group options are showing correctly for selected option", "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( selectedGradeOptions ) || getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.MULTIPLE_GRADES_SELECTED ), "Grade options are showing correctly for selected option",
                    "Grade options are not showing properly" );
            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Students.ALL_GRADES.get( 1 ) ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Students.ALL_GRADES.get( 2 ) ) );

            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with multiple Grades." );
            List<String> selectedOptionsFromGradeDropdown = afgPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );

            //To click the run report button 
            afgPage.clickRunReportButton();

            String selectedGrade = String.valueOf( selectedOptionsFromGradeDropdown.size() - 1 );

            schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat(
                        Arrays.asList( ReportsUIConstants.MULTIPLE_GRADES_SELECTED, ReportsUIConstants.ALL_VALUES ).stream().anyMatch(
                                grade -> afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ).stream().anyMatch( gradeUI -> grade.equals( gradeUI ) ) ),
                        "Grade is displayed in sub-header in report viewer page", "Grade is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", selectedGrade ).trim() ), "Grade options are showing correctly for selected option",
                    "Grade options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.put( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG,01" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Students.ALL_GRADES.get( 6 ) ) );

            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with multiple Grades." );
            selectedOptionsFromGradeDropdown = afgPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );

            //To click the run report button 
            afgPage.clickRunReportButton();

            selectedGrade = String.valueOf( selectedOptionsFromGradeDropdown.size() - 1 );

            schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat(
                        Arrays.asList( ReportsUIConstants.MULTIPLE_GRADES_SELECTED, ReportsUIConstants.ALL_VALUES ).stream().anyMatch(
                                grade -> afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ).stream().anyMatch( gradeUI -> grade.equals( gradeUI ) ) ),
                        "Grade is displayed in sub-header in report viewer page", "Grade is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", selectedGrade ).trim() ), "Grade options are showing correctly for selected option",
                    "Grade options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.put( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG,02" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 6 ) ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify Group subheader in the AFG report viewer page after run the report for an organization with multiple Groups" );
            afgPage.clickRunReportButton();

            List<String> selectedOptionsFromGroupDropdown = afgPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            String selectedGroup = String.valueOf( selectedOptionsFromGroupDropdown.size() - 1 );

            schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat( Arrays.asList( ReportsUIConstants.MULTIPLE_TEACHERS_SELECTED, ReportsUIConstants.ALL_VALUES ).containsAll( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ) ),
                        "Teacher name is displayed in sub-header in report viewer page", "Teacher name is displayed in sub-header in report viewer page" );
                Log.assertThat(
                        Arrays.asList( ReportsUIConstants.MULTIPLE_GRADES_SELECTED, ReportsUIConstants.ALL_VALUES ).stream().anyMatch(
                                grade -> afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ).stream().anyMatch( gradeUI -> grade.equals( gradeUI ) ) ),
                        "Grade is displayed in sub-header in report viewer page", "Grade is displayed in sub-header in report viewer page" );
                Log.assertThat( Arrays.asList( ReportsUIConstants.MULTIPLE_GROUPS_SELECTED, ReportsUIConstants.ALL_VALUES ).containsAll( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ) ),
                        "Group name is displayed in sub-header in report viewer page", "Group name is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).replace( "No", selectedGroup ).trim() ), "Group options are showing correctly for selected option",
                    "Group options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.put( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG,02" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter004: Verify all selected optional filters are displayed in AFG report viewer page.", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter004: Verify all selected optional filters are displayed in AFG report viewer page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();

            List<String> teachers = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            List<String> groups = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with all teachers." );

            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            List<String> schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );

            schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ).stream().anyMatch( teacher -> teacher.equals( ReportsUIConstants.ALL_VALUES ) ), "Teacher name is displayed in sub-header in report viewer page",
                        "Teacher name is displayed in sub-header in report viewer page" );

            } else {
                Log.message( "No data present for given filters." );
            }
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Group options are showing correctly for selected option",
                    "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Grade options are showing correctly for selected option",
                    "Grade options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.remove( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG,02" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();
            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with multiple Grade students." );

            afgPage.clickRunReportButton();

            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();

            schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Grade options are showing correctly for selected option",
                        "Grade options are not showing properly" );

            } else {
                Log.message( "No data present for given filters." );
            }
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Group options are showing correctly for selected option",
                    "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Grade options are showing correctly for selected option",
                    "Grade options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.remove( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG,02" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            SMUtils.logDescriptionTC( "Verify AFG report viewer page after run the report for an organization with All Groups." );

            afgPage.clickRunReportButton();

            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();

            schoolNames = afgReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( schoolNames.contains( organizationName ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ).stream().anyMatch( group -> group.equals( ReportsUIConstants.ALL_VALUES ) ), "Group name is displayed in sub-header in report viewer page",
                        "Group name is not displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            Log.assertThat( getSelectedOptioUI.get( 3 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 3 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Group options are showing correctly for selected option",
                    "Group options are not showing properly" );
            Log.assertThat( getSelectedOptioUI.get( 4 ).trim().equals( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG.get( 4 ).replace( "No", ReportsUIConstants.ALL_VALUES ).trim() ), "Grade options are showing correctly for selected option",
                    "Grade options are not showing properly" );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
            filters.remove( ReportConstants.ReportFilters.GRADE_ID_VALUE, "KG,02" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter005: Verify selected Additional Grouping options are displayed in AFG report viewer page.", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter005: Verify selected Additional Grouping options are displayed in AFG report viewer page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();

            List<String> teachers = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            List<String> groups = afgPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with additional grouping as Grade" );
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            Log.assertThat( Students.ALL_GRADES.stream().anyMatch( grade -> afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ).stream().anyMatch( gradeUI -> grade.contains( gradeUI ) ) ),
                    "Report is displayed based on Grade when Additional Grouping is selected as Grade", "Report is not displayed based on Grade when Additional Grouping is selected as Grade" );

            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 0 ).equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "Additional grouping by Grade options are showing correctly for selected option",
                    "Additional grouping by Grade options are not showing properly" );

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "2" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_NAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();
            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            afgPage.reportFilterComponent.handleStudentPopup();

            //To click the run report button 
            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with additional grouping as Grade and Display as student Id" );
            SMUtils.logDescriptionTC( "Verify the AFG report, if the student is part of multiple group & run the report with additional grouping as Group." );
            Log.assertThat( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ).stream().allMatch( group -> groups.contains( group ) ), "Report is displayed based on Group when Additional Grouping is selected as Group",
                    "Report is not displayed based on Group when Additional Grouping is selected as Group" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 0 ).equals( ReportsUIConstants.ADDITIONAL_GROUPING_GROUP ), "Additional grouping by Grade options are showing correctly for selected option",
                    "Additional grouping by Grade options are not showing properly" );

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "3" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.STUDENT_ID );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();
            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.TEACHER_LABEL );
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with additional grouping as Teacher and Display as student username" );
            SMUtils.logDescriptionTC( "Verify the AFG report for shared student, while the run the report with additional grouping as teacher." );
            SMUtils.logDescriptionTC( "Verify the AFG report, if the student is part of multiple group & run the report with additional grouping as Group." );

            Log.assertThat( afgReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ).stream().allMatch( teacher -> teachers.contains( teacher ) ), "Report is displayed based on Teacher when Additional Grouping is selected as Teacher",
                    "Report is not displayed based on Teacher when Additional Grouping is selected as Teacher" );
            getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();
            Log.assertThat( getSelectedOptioUI.get( 0 ).equals( ReportsUIConstants.ADDITIONAL_GROUPING_TEACHER ), "Additional grouping by Grade options are showing correctly for selected option",
                    "Additional grouping by Grade options are not showing properly" );

            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            filters.put( ReportAdminConstants.SUBJECT, ReportsUIConstants.MATH );
            filters.put( ReportAdminConstants.COURSES, ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
            filters.put( ReportAdminConstants.ORG_ID, ReportDataCollection.orgId );
            filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "1" );

            afgAdminReportData = new ReportAPI().getAFGAdminReportData( headers, filters );
            Log.message( afgAdminReportData.getBody().asString() );

            if ( !afgAdminReportData.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = getSkillsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH );
                Log.assertThat( afgReportViewerPage.getSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse( afgAdminReportData.getBody().asString(), "Math", ReportsUIConstants.MATH, AFGReportConstants.USERNAME );
                Log.assertThat( afgReportViewerPage.getStudentDetails().entrySet().stream().anyMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter006: Verify selected columns are sorted in ascending order in AFG report viewer page.", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter006: Verify selected columns are sorted in ascending order in AFG report viewer page." + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();

            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by strand column while run the report with Sort as strand" );
            SMUtils.logDescriptionTC( "Verify the level column should be highlighted and the report should show the sorted order by level column while run the report with Sort as level" );
            SMUtils.logDescriptionTC( "Verify the \"Skill Description\" column should be highlighted and the report should show the sorted order by \"Skill Description (Skill)\" column while run the report with Sort as Skill Description" );

            IntStream.range( 0, ReportsUIConstants.AFG_SORT.size() ).forEach( itr -> {
                String columnSorted = ReportsUIConstants.AFG_SORT.get( itr );
                afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, columnSorted );

                //To click the run report button 
                AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

                Log.assertThat( afgReportViewerPage.sortAndCompareColumnvalues( columnSorted ), columnSorted + " column is sorted in ascending order", columnSorted + " column is not sorted in ascending order" );

                getSelectedOptioUI = afgReportViewerPage.getSelectedOptionsLegend();

                if ( itr == 0 ) {
                    Log.assertThat( getSelectedOptioUI.get( 1 ).equals( AFGReportConstants.SORT_BY_STRAND ), "Additional grouping by Grade options are showing correctly for selected option",
                            "Additional grouping by Grade options are not showing properly" );
                } else if ( itr == 1 ) {
                    Log.assertThat( getSelectedOptioUI.get( 1 ).equals( AFGReportConstants.SORT_BY_LEVEL ), "Additional grouping by Grade options are showing correctly for selected option", "Additional grouping by Grade options are not showing properly" );

                } else {
                    Log.assertThat( getSelectedOptioUI.get( 1 ).equals( AFGReportConstants.SORT_BY_SKILL_DESCRIPTION ), "Additional grouping by Grade options are showing correctly for selected option",
                            "Additional grouping by Grade options are not showing properly" );

                }
                // Navigating to report filter page
                driver.close();
                driver.switchTo().window( new ArrayList<>( driver.getWindowHandles() ).get( 1 ) );
            } );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter007 Verify demographic filters are applied in AFG report viewer page", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter007 Verify demographic filters are applied in AFG report viewer page" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();
            afgPage.reportFilterComponent.expandStudentDemographics();
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 1 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 24 Weeks and Select any one option in Race filter" );
            SMUtils.nap( 10 );

            // Selecting single values in each demographic filters
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 1 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 0 ) ) ), "Selected demographic values for Race are displayed in report viewer page",
                    "Selected demographic values for Race are not displayed in report viewer page" );

            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 2 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 12 Weeks and Select any one option in disability status filter" );
            SMUtils.nap( 10 );

            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 0 ) ) ),
                    "Selected demographic values for Disability Status are displayed in report viewer page", "Selected demographic values for Disability Status are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 2 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 8 Weeks and Select any one option in English language proficiency filter" );
            SMUtils.nap( 10 );

            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 0 ) ) ),
                    "Selected demographic values for English Language Proficiency are displayed in report viewer page", "Selected demographic values for English Language Proficiency are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 4 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( DemographicFilters.ETHNICITY.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 4 Weeks and Select any one option in Ethnicity filter" );
            SMUtils.nap( 10 );

            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.ETHNICITY, Arrays.asList( DemographicFilters.ETHNICITY.get( 0 ) ) ), "Selected demographic values for Ethnicity are displayed in report viewer page",
                    "Selected demographic values for Ethnicity are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 4 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 4 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 2 Weeks and Select any one option in Migrant status filter" );

            SMUtils.nap( 10 );
            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 0 ) ) ), "Selected demographic values for Migrant Status are displayed in report viewer page",
                    "Selected demographic values for Migrant Status are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 4 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );
            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 5 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 0 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 1 Weeks and Select any one option in Special services filter" );
            SMUtils.nap( 10 );

            afgPage.clickRunReportButton();
            SMUtils.nap( 10 );

            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 5 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 0 ) ) ),
                    "Selected demographic values for Socioeconomic Status are displayed in report viewer page", "Selected demographic values for Socioeconomic Status are not displayed in report viewer page" );
            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 1 ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 6 ) ) );

            SMUtils.logDescriptionTC( "Verify the AFG report viewer page after run the report for an organization with Date at Risk as 1 Weeks and Select any one option in Socioeconomic status filter" );

            afgPage.clickRunReportButton();

            Log.assertThat( afgReportViewerPage.getSelectedOptions().get( 2 ).equalsIgnoreCase( String.format( AFGReportConstants.SHOW_ALL_DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 6 ) ) ),
                    "Select Date At Risk is displayed in AFG report viewer page", "Select Date At Risk is displayed in AFG report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 0 ) ) ),
                    "Selected demographic values for Special Services are displayed in report viewer page", "Selected demographic values for Special Services are not displayed in report viewer page" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcAFGOptionalFilter008 Verify multiple demographic filters are applied in AFG report viewer page", groups = { "SMK-57881,SMK-66773", "AFG Report Output", "AFGReportOptionalFilters" }, priority = 1 )
    public void tcAFGOptionalFilter008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAFGOptionalFilter008 Verify multiple demographic filters are applied in AFG report viewer page" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization, Subject and Assignments
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Expand Optional Filters
            afgPage.reportFilterComponent.expandOptionalFilter();
            afgPage.reportFilterComponent.expandStudentDemographics();

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify the students in AFG report viewer page after run the report for an organization with multiple option in English language proficiency filter and multiple option in Ethnicity filter" );

            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, DemographicFilters.ENGLISH_LANGUAGE ),
                    "Selected demographic values for English Language Proficiency are displayed in report viewer page", "Selected demographic values for English Language Proficiency are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.ETHNICITY, DemographicFilters.ETHNICITY ), "Selected demographic values for Ethnicity are displayed in report viewer page",
                    "Selected demographic values for Ethnicity are not displayed in report viewer page" );

            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify the students in AFG report viewer page after run the report for an organization with multiple option in Special services filter and multiple option in Socioeconomic status filter" );

            afgPage.clickRunReportButton();

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.SOCIOECONOMIC_STATUS, DemographicFilters.SOCIOECONOMIC_STATUS ), "Selected demographic values for Socioeconomic Status are displayed in report viewer page",
                    "Selected demographic values for Socioeconomic Status are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.SPECIAL_SERVICES, DemographicFilters.SPECIAL_SERVICES ), "Selected demographic values for Special Services are displayed in report viewer page",
                    "Selected demographic values for Special Services are not displayed in report viewer page" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            // Selecting multiple values in each demographic filters
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify the students in AFG report viewer page after run the report for an organization with multiple option in Race filter and multiple option in disability status filter" );

            afgPage.clickRunReportButton();

            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.DISABILITY_STATUS, DemographicFilters.DISABILITY_STATUS ), "Selected demographic values for Disability Status are displayed in report viewer page",
                    "Selected demographic values for Disability Status are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.MIGRANT_STATUS, DemographicFilters.MIGRANT_STATUS ), "Selected demographic values for Migrant Status are displayed in report viewer page",
                    "Selected demographic values for Migrant Status are not displayed in report viewer page" );
            Log.assertThat( afgReportViewerPage.verifyDemographicValues( ReportsUIConstants.RACE, DemographicFilters.RACE ), "Selected demographic values for Race are displayed in report viewer page",
                    "Selected demographic values for Race are not displayed in report viewer page" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the skill details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, Map<String, String>> getSkillsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, Map<String, String>> SkillDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                skillDetails.put( AFGReportConstants.STRAND, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_NAME ) );
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                skillDetails.put( AFGReportConstants.TARGETED_LESSON,
                        SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LESSON_NUMBER ) + ". " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LESSON_TITLE ) );
                if ( skillDetails.get( AFGReportConstants.TARGETED_LESSON ).equals( ". " ) ) {
                    skillDetails.put( AFGReportConstants.TARGETED_LESSON, "" );
                }
                SkillDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), skillDetails );
            } );

        } );
        return SkillDetailFromResponse;
    }

    /**
     * To get the student details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, List<String>> getstudentsFromResponse( String response, String assignmentName, String subject, String studentNameOrId ) {

        Map<String, List<String>> studentDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.stream().forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                List<String> students = new ArrayList<>();
                JSONArray stduentArray = new JSONObject( skillDetail.toString() ).getJSONArray( AFGReportConstants.STUDENT_ROWS );
                List<String> studentDetailList = new ArrayList<>();
                IntStream.range( 0, stduentArray.length() ).forEach( itr -> studentDetailList.add( stduentArray.get( itr ).toString() ) );

                studentDetailList.stream().forEach( student -> {
                    String[] dateArray = SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.FAILED_DATE ).substring( 0, 10 ).split( "-" );
                    String dateAtRisk = dateArray[1] + "/" + dateArray[2] + "/" + dateArray[0];
                    students.add( SMUtils.getKeyValueFromResponse( student.toString(), studentNameOrId ) + " - " + dateAtRisk );
                } );

                studentDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), students );
            } );

        } );
        return studentDetailFromResponse;
    }

}