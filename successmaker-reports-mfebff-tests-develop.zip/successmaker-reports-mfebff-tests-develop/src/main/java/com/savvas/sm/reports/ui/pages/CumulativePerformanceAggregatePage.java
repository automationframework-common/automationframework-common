package com.savvas.sm.reports.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

public class CumulativePerformanceAggregatePage extends LoadableComponent<CumulativePerformanceAggregatePage> {
    public static WebDriver driver = null;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    /***************** POM for Page **************************/

    @FindBy ( css = "cel-tab-panel.tab-panel.hydrated.tab-panel-cumulativePerformanceAggregate" )
    WebElement cprAggregatetoggle;

    @FindBy ( css = "saved-report-options label" )
    WebElement savereportOptionLabel;

    @FindBy ( tagName = "h1" )
    WebElement pageTitle;

    @FindBy ( css = "cel-tab-panel.tab-panel" )
    WebElement togglebutton;

    @FindBy ( css = "cel-button" )
    WebElement runReportRoot;
    
    @FindBy ( css = ".optional-filters-wrapper.hydrated" )
    WebElement optionalFilterRoot;
    
    @FindBy ( css = "report-grid tbody td:nth-child(1)" )
    public List<WebElement> outputSchoolName;

    @FindBy ( css = "report-grid tbody td:nth-child(2)" )
    public List<WebElement> outputCurentCourseLevel;

    @FindBy ( css = "report-grid tbody td:nth-child(7)" )
    public List<WebElement> outputExercisesCorrect;

    @FindBy ( css = "report-grid tbody td:nth-child(8)" )
    public List<WebElement> outputExercisesAttempted;

    @FindBy ( css = "report-grid tbody td:nth-child(5)" )
    public List<WebElement> outputTimeSpent;

    @FindBy ( css = "report-grid tbody td:nth-child(6)" )
    public List<WebElement> outputTotalSessions;

    @FindBy ( xpath = "//h2[@class='header']")
    WebElement reportHeader;

    @FindBy ( css = "div.table-container")
    WebElement reportTable;

    /**************** Child Elements *******************/

    private static String cprAggregateChild = "div.tab-container button.selected";

    //child element
    private String button = "button";
    private String accordion="#accordion-button-undefined";
    private String selectedButton = "button.selected";
    private static String runReportChild = "button.button";
    private String headerCSS = "h2.header";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public CumulativePerformanceAggregatePage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "cumulative Aggregate Performance Page loaded successfully." );
        } else {
            Log.fail( "Cumulative Aggregate Performance Page not loaded successfully." );
        }

    }

    /**
     * To verify the sub navigation is selected or not
     * 
     * @return
     */
    public boolean isCPAReportSelected() {
        // TODO Auto-generated method stub
        Log.message( "Verifing Cumulative Performance Aggregate is selected" );
        return SMUtils.getWebElementDirect( driver, cprAggregatetoggle, selectedButton ).getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE_AGGREGATE );

    }

    /**
     * Get text for cpr aggregate
     * 
     * @return
     */
    public String getCPRAggregateHeaderText() {

        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprAggregateChild );
        Log.message( "Get CPR aggregate text" );
        return actualElement.getText().trim();
    }

    /**
     * Get CPR aggregate page
     * 
     * @return
     */
    public boolean isCPAggregateSelected() {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprAggregateChild );
        Log.message( "Verifying Cumulative performance aggregate is present and selected" );
        return SMUtils.isElementPresent( actualElement );

    }
    
    /**
     * Click optional Filter in Report
     */
    public void clickOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, accordion );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }

    /**
     * 
     * @return
     * @throws Exception
     */
    public boolean isCPRAggregateColorDisplay() throws Exception {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprAggregateChild );
        Log.message( "Verifying CPR aggregate color is displaying" );
        return SMUtils.checkColor( actualElement, ReportsUIConstants.COLOR_CPRAGGREGATE );
    }
    /**
     * To Click RunReport Button
     * 
     * @return
     */

    public CPAReportViewerPage clickRunReportButton() {
        try {
            WebElement webElementDirect = SMUtils.getWebElementDirect( driver, runReportRoot, runReportChild );
            SMUtils.clickJS( driver, webElementDirect );
            Log.message( "Clicked Run report Button" );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(0) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Unable to click Here in run report button in CPAggregate Page" );

        }
        return new CPAReportViewerPage( driver ).get();

    }
    
    public boolean checkReportHeaderAfterRun() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( headerCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( headerCSS ) ), 5000 );
            WebElement heading = driver.findElement( By.cssSelector( headerCSS ) );
            return heading.getText().equals( "Cumulative Performance Aggregate" );
        }catch ( Exception e ){
            Log.message( "Header not found" );
        }
        return false;
    }

    public List<String> getOutputSchoolNames( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputSchoolName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputCurentCourseLevel( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputCurentCourseLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputExercisesCorrect( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputExercisesCorrect.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputExercisesAttempted( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputExercisesAttempted.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputTotalSessions( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTotalSessions.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }
    public HashMap<String, HashMap<String, String>> getCPAReportAllDataFromUI( WebDriver driver) throws InterruptedException {
        HashMap<String, HashMap<String, String>> cparDetails = new HashMap<>();
        SMUtils.waitForSpinnertoDisapper(driver, 5);
        Log.message( "Getting Data From output.." );

            List<String> schoolNames = getOutputSchoolNames(driver);
            List<String> currentCourseLevel =  getoutputCurentCourseLevel(driver);
            List<String> exerciseCorrect = getoutputExercisesCorrect(driver);
            List<String> exerciseAttempted =  getoutputExercisesAttempted(driver);
            List<String> totalSessions = getoutputTotalSessions(driver);
            List<String> gradeNames = new ArrayList();
            
            IntStream.range( 0, schoolNames.size() ).forEach( itr -> {
                String name = schoolNames.get( itr );
                if(name.contains( " (K" )) {
                    gradeNames.add( "KG" );
                    
                }else if(name.contains( "(G01" )) {
                    gradeNames.add( "01" );
                    
                }else if(name.contains( "(G02" )) {
                    gradeNames.add( "02" );
                    
                }else if(name.contains( "(G03" )) {
                    gradeNames.add( "03" );
                    
                }else if(name.contains( "(G04" )) {
                    gradeNames.add( "04" );
                    
                }else if(name.contains( "(G05" )) {
                    gradeNames.add( "05" );
                    
                }else if(name.contains( "(G06" )) {
                    gradeNames.add( "06" );
                    
                }else if(name.contains( "(G07" )) {
                    gradeNames.add( "07" );
                    
                }else if(name.contains( "(G08" )) {
                    gradeNames.add( "08" );
                    
                }else if(name.contains( "(G09" )) {
                    gradeNames.add( "09" );
                    
                }else if(name.contains( "(G10" )) {
                    gradeNames.add( "10" );
                    
                }else if(name.contains( "(G11" )) {
                    gradeNames.add( "11" );
                    
                }else if(name.contains( name )) {
                    gradeNames.add( "12" );
                    
                }     
            });
            IntStream.range( 0, currentCourseLevel.size() ).forEach( itr -> {

                HashMap<String, String> values = new HashMap<>();
                
                values.put( "exercisesAttempted", exerciseAttempted.get( itr ).toString() );
                values.put( "exercisesCorrect", exerciseCorrect.get( itr ).toString() );
                values.put( "totalSessions", totalSessions.get( itr ).toString() );
                values.put( "currentCourseLevel", currentCourseLevel.get( itr ).toString() );
                
                cparDetails.put(gradeNames.get( itr ), values );
            });
            Log.message( "Final UI Details: " + cparDetails);
            return cparDetails; 
    }

    public CPAReportViewerPage clickRunBtn() {
        reportFilterComponent.clickRunReportButton();
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Getting issue while change the driver to report output page!!!!" );
        }
        return new CPAReportViewerPage( driver ).get();
    }
}
