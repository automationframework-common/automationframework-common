package com.savvas.sm.reports.reportdatasetup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.ReportDataCreation;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * Data creation for SM Reports
 *
 * @author karthigeyan.bala
 */

public class ReportDataSetupRun extends EnvProperties {

    private String smUrl;
    private String browser;
    private static String school;
    private static String schoolId;

    private HashMap<String, String> teacherDetails = new HashMap<>();
    private static HashMap<String, HashMap<String, String>> teacherStudentDetails = new HashMap<>();
    private static HashMap<String, HashMap<String, String>> courseIds = new HashMap<>();
    private static HashMap<String, HashMap<String, String>> assignmentIds = new HashMap<>();
    private static HashMap<String, HashMap<String, String>> studentUserNames = new HashMap<>();
    private static HashMap<String, HashMap<String, String>> studentRumbaIds = new HashMap<>();
    private static HashMap<String, HashMap<String, String>> courseNames = new HashMap<>();
    private RBSUtils rbsUtils = new RBSUtils();

    @Test
    private void ReportDataCreation() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        school = getSchools( Schools.FLEX_SCHOOL );
        schoolId = RBSDataSetup.organizationIDs.get( school );

        Log.message( "***************** Report data creation started ***************" );

        IntStream.rangeClosed( 1, 2 ).parallel().forEach( iteration -> {
            HashMap<String, String> courseId = new HashMap<>();
            HashMap<String, String> assignmentId = new HashMap<>();
            HashMap<String, String> studentUserName = new HashMap<>();
            HashMap<String, String> studentRumbaId = new HashMap<>();
            HashMap<String, String> courseName = new HashMap<>();
            try {

                Log.message( "***** Creating data for school: " + school + ": " + " *****" );

                String teacherDetail = RBSDataSetup.orgTeacherDetails.get( school ).get( "Teacher" + iteration );
                teacherDetails.put( school, teacherDetail );
                String teacherId = SMUtils.getKeyValueFromResponse( teacherDetail, RBSDataSetupConstants.USERID );
                String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetail, RBSDataSetupConstants.USERNAME );
                Log.message( "Teacher details for " + school + ": " + teacherDetail );

                // Getting Student details
                HashMap<String, String> studentDetails = new HashMap<>();
                if ( Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) >= 5 ) {
                    IntStream.rangeClosed( 1, 5 ).forEach( itr -> {
                        String studentDetail = RBSDataSetup.getMyStudent( school, teacherUsername );
                        studentDetails.put( "Student" + itr, studentDetail );
                        studentUserName.put( Constants.STUDENT_USERNAME + itr, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );
                        studentRumbaId.put( Constants.STUDENT_ID + itr, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
                    } );
                } else {
                    Log.fail( "Minimum 5 Students are requires. Give Student count as 5 or more in config.properties!" );
                }
                studentUserNames.put( "Teacher" + iteration, studentUserName );
                studentRumbaIds.put( "Teacher" + iteration, studentRumbaId );
                teacherStudentDetails.put( "Teacher" + iteration, studentDetails );

                if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) || school.equalsIgnoreCase( getSchools( Schools.MATH_SCHOOL ) ) ) {

                    courseName.put( Constants.MATH, AssignmentAPIConstants.MATH_COURSE );
                    courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime() ) );
                    //courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                    courseName.put( Constants.DELETED_ASSIGNMENT_MATH, Constants.DELETED_ASSIGNMENT_MATH + " - " + System.nanoTime() );
                    courseName.put( Constants.RESTORED_ASSIGNMENT_MATH, Constants.RESTORED_ASSIGNMENT_MATH + " - " + System.nanoTime() );
                    courseName.put( Constants.SHARED_COURSE_MATH, Constants.SHARED_COURSE_MATH + " - " + System.nanoTime() );
                    // Creating Math courses
                    Log.message( "***** Creating Math Custom Courses *****" );
                    if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                        courseName.put( Constants.SM_FOCUS_MATH_GRADE1, Constants.SM_FOCUS_MATH_GRADE1 );
                        courseId.put( Constants.SM_FOCUS_MATH_GRADE1, AssignmentAPIConstants.FOCUS_MATH_1 );
                    }
                    courseId.put( Constants.MATH, AssignmentAPIConstants.MATH );
                    courseId.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                            DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
                    courseId.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH,
                            teacherId, schoolId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
                    //courseId.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                    // DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
                    courseId.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                            DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );

                    if ( iteration == 1 ) {
                        courseId.put( Constants.DELETED_ASSIGNMENT_MATH, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                                DataSetupConstants.SETTINGS, courseName.get( Constants.DELETED_ASSIGNMENT_MATH ) ) );
                        courseId.put( Constants.RESTORED_ASSIGNMENT_MATH, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                                DataSetupConstants.SETTINGS, courseName.get( Constants.RESTORED_ASSIGNMENT_MATH ) ) );
                        courseId.put( Constants.SHARED_COURSE_MATH, new SharedCourses().createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                                DataSetupConstants.SETTINGS, courseName.get( Constants.SHARED_COURSE_MATH ) ) );
                    }

                }

                if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) || school.equalsIgnoreCase( getSchools( Schools.READING_SCHOOL ) ) ) {

                    courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
                    courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );
                    //courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                    courseName.put( Constants.DELETED_ASSIGNMENT_READING, Constants.DELETED_ASSIGNMENT_READING + " - " + System.nanoTime() );
                    courseName.put( Constants.RESTORED_ASSIGNMENT_READING, Constants.RESTORED_ASSIGNMENT_READING + " - " + System.nanoTime() );
                    courseName.put( Constants.SHARED_COURSE_READING, Constants.SHARED_COURSE_READING + " - " + System.nanoTime() );

                    // Creating Reading courses
                    Log.message( "***** Creating Reading Custom Courses *****" );
                    if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                        courseName.put( Constants.SM_FOCUS_READING_GRADE1, Constants.SM_FOCUS_READING_GRADE1 );
                        courseId.put( Constants.SM_FOCUS_READING_GRADE1, AssignmentAPIConstants.FOCUS_READING_1 );
                    }
                    courseId.put( Constants.READING, AssignmentAPIConstants.READING );
                    courseId.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                            DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                    courseId.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING,
                            teacherId, schoolId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
                    //courseId.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                    //DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                    courseId.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                            DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

                    if ( iteration == 1 ) {
                        courseId.put( Constants.DELETED_ASSIGNMENT_READING, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                                DataSetupConstants.SETTINGS, courseName.get( Constants.DELETED_ASSIGNMENT_READING ) ) );
                        courseId.put( Constants.RESTORED_ASSIGNMENT_READING, new CourseAPI().createCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                                DataSetupConstants.SETTINGS, courseName.get( Constants.RESTORED_ASSIGNMENT_READING ) ) );
                        courseId.put( Constants.SHARED_COURSE_READING, new SharedCourses().createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                                DataSetupConstants.SETTINGS, courseName.get( Constants.SHARED_COURSE_READING ) ) );
                    }

                }

                Log.message( "Course details for " + teacherUsername + ": " + courseId );
                courseNames.put( "Teacher" + iteration, courseName );
                courseIds.put( "Teacher" + iteration, courseId );
                studentRumbaIds.put( "Teacher" + iteration, studentRumbaId );

                Log.message( "**** Assigning Assignments ****" );
                HashMap<String, String> staffDetails = new HashMap<>();
                staffDetails.put( AssignmentAPIConstants.ORG_ID, schoolId );
                staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                try {
                    HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, new ArrayList<>( studentRumbaIds.get( "Teacher" + iteration ).values() ),
                            new ArrayList<>( courseIds.get( "Teacher" + iteration ).values() ) );

                    JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
                    JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
                    for ( Object assignment : assignmentList ) {
                        JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                        assignmentId.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
                    }
                } catch ( Exception e ) {
                    Log.message( "Issue on assigning the assignments of Math course" );
                    Log.message( "Course ids- " + courseIds.get( "Teacher" + iteration ) );
                }
                Log.message( "Assignments Id for " + teacherUsername + ": " + assignmentId );
                assignmentIds.put( "Teacher" + iteration, assignmentId );

                courseExecutionForFlexSchool( iteration );

            } catch ( Exception e ) {
                e.printStackTrace();
            }
        } );

        // Creating Shared Group
        String flexSchool = getSchools( Schools.FLEX_SCHOOL );
        String flexteacherOneId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgTeacherDetails.get( flexSchool ).get( "Teacher" + 1 ), RBSDataSetupConstants.USERID );
        String flexteacherTwoId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgTeacherDetails.get( flexSchool ).get( "Teacher" + 2 ), RBSDataSetupConstants.USERID );
        String flexStudentThreeUserId = studentRumbaIds.get( "Teacher1" ).get( Constants.STUDENT_ID + "1" );

        String sharedGroupId = rbsUtils.createClassWithMultipleTeacher( ReportDataCreation.SHARED_GROUP, Arrays.asList( flexteacherOneId, flexteacherTwoId ), Arrays.asList( flexStudentThreeUserId ), schoolId,
                rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgTeacherDetails.get( flexSchool ).get( "Teacher" + 1 ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Created Shared Group - " + sharedGroupId );

        // Adding Product to the Shared Group
        String savvasUserName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String savvasUserId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.USERID );
        String districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        String addProductResponse = rbsUtils.addProductToClassGraphQL( districtId, sharedGroupId, configProperty.getProperty( "flexProduct" ), rbsUtils.getAccessToken( savvasUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ), savvasUserId );
        Log.message( "Added flex product to the Shared Group - " + addProductResponse );

        // Updating a Teacher as multi-org Teacher
        String mathSchool = getSchools( Schools.MATH_SCHOOL );
        String mathSchoolId = RBSDataSetup.organizationIDs.get( mathSchool );
        List<String> mathAndFlexSchoolIds = Arrays.asList( schoolId, mathSchoolId );
        rbsUtils.updateUserOrgId( rbsUtils.getUser( flexteacherTwoId ), "T", mathAndFlexSchoolIds );

        // Updating a Student as multi-org Student
        String mathSchoolTeacherDetail = RBSDataSetup.getMyTeacher( mathSchool );
        String mathSchoolTeacherUsername = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetail, RBSDataSetupConstants.USERNAME );
        String mathSchoolTeacherId = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetail, RBSDataSetupConstants.USERID );
        String mathSchoolStudentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( mathSchool, mathSchoolTeacherUsername ), RBSDataSetupConstants.USERID );

        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, mathSchoolTeacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, mathSchoolId );
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( mathSchoolTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_NAME, ReportDataCreation.SHARED_STUDENT_GROUP );

        String teacherDetails = RBSDataSetup.orgTeacherDetails.get( flexSchool ).get( "Teacher" + 1 );
        String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        try {
            rbsUtils.updateUserOrgId( rbsUtils.getUser( flexStudentThreeUserId ), "S", mathAndFlexSchoolIds );
            new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( flexStudentThreeUserId ) );

            // Creating Group with no Students
            String emptyGroup = new GroupAPI().createEmptyGroup( ReportDataCreation.GROUP_WITH_NO_STUDENTS, teacherId, schoolId, rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            Log.message( "Created a group without student - " + emptyGroup );

            // Creating Group without product
            String groupWithoutProduct = new RBSUtils().CreateClassWithoutSMProdcut( ReportDataCreation.GROUP_WITHOUT_PRODUCT, teacherId, flexStudentThreeUserId, schoolId,
                    rbsUtils.getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            Log.message( "Creadted a group without product - " + groupWithoutProduct );

        } catch ( Exception e ) {
            Log.message( "Issue on updating a student as multi-org student." );
            e.getMessage();
        }

        // Assigning the Share Course to Math school
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID ) );
        headers.put( Constants.ORGID_SM_HEADER, districtId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        String[] orgIds = { mathSchoolId, schoolId };
        new SharedCourses().editShareCourseList( smUrl, headers, orgIds, courseIds.get( "Teacher1" ).get( Constants.SHARED_COURSE_MATH ), "" );
        new SharedCourses().editShareCourseList( smUrl, headers, orgIds, courseIds.get( "Teacher1" ).get( Constants.SHARED_COURSE_READING ), "" );

        // Assigning the Shared Course to the Students of Math school
        HashMap<String, String> mathTeacherDetails = new HashMap<String, String>();
        mathTeacherDetails.put( AssignmentAPIConstants.TEACHER_ID, mathSchoolTeacherId );
        mathTeacherDetails.put( AssignmentAPIConstants.ORG_ID, mathSchoolId );
        mathTeacherDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( mathSchoolTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        new AssignmentAPI().assignMultipleAssignments( smUrl, mathTeacherDetails, Arrays.asList( mathSchoolStudentId ), Arrays.asList( courseIds.get( "Teacher1" ).get( Constants.SHARED_COURSE_MATH ) ) );

        // Deleting the assignment
        HashMap<String, String> assignmentDetails = new HashMap<String, String>();
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        // Delete Math assignment
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseIds.get( "Teacher1" ).get( Constants.DELETED_ASSIGNMENT_MATH ) );
        new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseIds.get( "Teacher1" ).get( Constants.RESTORED_ASSIGNMENT_MATH ) );
        new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

        // Delete Reading assignment
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseIds.get( "Teacher1" ).get( Constants.DELETED_ASSIGNMENT_READING ) );
        new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseIds.get( "Teacher1" ).get( Constants.RESTORED_ASSIGNMENT_READING ) );
        new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

        // Restoring the deleted assignment
        HashMap<String, String> userDetail = new HashMap<>();
        userDetail.put( Constants.USERID_SM_HEADER, savvasUserId );
        userDetail.put( Constants.ORGID_SM_HEADER, districtId );
        userDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( savvasUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        // Restoring Math assignment
        userDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( flexStudentThreeUserId, assignmentIds.get( "Teacher1" ).get( courseNames.get( "Teacher1" ).get( Constants.RESTORED_ASSIGNMENT_MATH ) ) ) );
        new RestoreAssignment().restoreDeletedAssignment( smUrl, userDetail, AssignmentAPIConstants.EXCEPTIONNULL );

        // Restoring Reading assignment
        userDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( flexStudentThreeUserId, assignmentIds.get( "Teacher1" ).get( courseNames.get( "Teacher1" ).get( Constants.RESTORED_ASSIGNMENT_READING ) ) ) );
        new RestoreAssignment().restoreDeletedAssignment( smUrl, userDetail, AssignmentAPIConstants.EXCEPTIONNULL );

        Log.message( "Teacher Details: " + teacherDetails );
        Log.message( "Student Details: " + teacherStudentDetails );
        Log.message( "Course Name Details: " + courseNames );
        Log.message( "Course Id Details: " + courseIds );
        Log.message( "Assignment Id Details: " + assignmentIds );

        Log.message( "Shared Teacher- " + teacherUsername );
        Log.message( "Shared Student- " + studentUserNames.get( Constants.STUDENT_USERNAME + "1" ) );
        Log.message( "Shared Course Math- " + courseNames.get( "Teacher1" ).get( Constants.SHARED_COURSE_MATH ) );
        Log.message( "Shared Course Reading- " + courseNames.get( "Teacher1" ).get( Constants.SHARED_COURSE_READING ) );
        Log.message( "Deleted Math Course- " + courseNames.get( "Teacher1" ).get( Constants.DELETED_ASSIGNMENT_MATH ) );
        Log.message( "Deleted Reading Course- " + courseNames.get( "Teacher1" ).get( Constants.DELETED_ASSIGNMENT_READING ) );
        Log.message( "Restored Math Course- " + courseNames.get( "Teacher1" ).get( Constants.RESTORED_ASSIGNMENT_MATH ) );
        Log.message( "Restored Math Course- " + courseNames.get( "Teacher1" ).get( Constants.RESTORED_ASSIGNMENT_READING ) );

    }

    private void courseExecutionForFlexSchool( int teacherCount ) {

        Log.message( "***** Started Math course execution for Flex licensed school *****" );
        // Getting Student Names
        HashMap<String, String> studentMap = teacherStudentDetails.get( "Teacher" + teacherCount );
        List<String> studentNames = new ArrayList<>();
        studentMap.keySet().stream().forEach( name -> studentNames.add( SMUtils.getKeyValueFromResponse( studentMap.get( name ), Constants.USER_NAME ) ) );
        // Getting Math Course Names
        List<String> mathCourseNameList = new ArrayList<>();
        courseNames.get( "Teacher" + teacherCount ).values().stream().filter( courseName -> courseName.toLowerCase().contains( Constants.MATH.toLowerCase() ) ).forEach( mathCourseNameList::add );

        IntStream.range( 0, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.size() ).parallel().forEach( itr -> {

            IntStream.range( 0, mathCourseNameList.size() ).forEach( iter -> {
                WebDriver driver = WebDriverFactory.get( browser );
                try {
                    LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentNames.get( itr ), RBSDataSetupConstants.DEFAULT_PASSWORD );

                    if ( studentNames.get( itr ).equals( studentNames.get( 0 ) ) || ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "0" ) || ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "10" ) ) {
                        if ( mathCourseNameList.get( iter ).equals( Constants.MATH ) || mathCourseNameList.get( iter ).equals( courseNames.get( "Teacher" + teacherCount ).get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) )
                                || mathCourseNameList.get( iter ).equals( courseNames.get( "Teacher" + teacherCount ).get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) ) {
                            Log.message( studentNames.get( itr ) + " " + mathCourseNameList.get( iter ) );
                            executeCourse( driver, studentNames.get( itr ), mathCourseNameList.get( iter ), true, true, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        } else {
                            Log.message( studentNames.get( itr ) + " " + mathCourseNameList.get( iter ) );

                            executeCourse( driver, studentNames.get( itr ), mathCourseNameList.get( iter ), true, false, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        }
                    } else {
                        Log.message( studentNames.get( itr ) + " " + mathCourseNameList.get( iter ) );

                        executeCourse( driver, studentNames.get( itr ), mathCourseNameList.get( iter ), true, false, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                    }
                } catch ( IOException e ) {
                    e.printStackTrace();
                    driver.close();
                } finally {
                    driver.close();
                }

            } );

        } );
        Log.message( "***** Completed Math course execution for Flex licensed school *****" );

        Log.message( "***** Started Reading course execution for Flex licensed school *****" );
        // Getting Reading Course Names
        List<String> readingCourseNameList = new ArrayList<>();
        courseNames.get( "Teacher" + teacherCount ).values().stream().filter( courseName -> courseName.toLowerCase().contains( Constants.READING.toLowerCase() ) ).forEach( readingCourseNameList::add );

        IntStream.range( 0, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.size() ).parallel().forEach( itr -> {

            IntStream.range( 0, readingCourseNameList.size() ).forEach( iter -> {
                WebDriver driver = WebDriverFactory.get( browser );
                LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentNames.get( itr ), RBSDataSetupConstants.DEFAULT_PASSWORD );

                try {
                    if ( studentNames.get( itr ).equals( studentNames.get( 0 ) ) || ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "0" ) || ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "10" ) ) {
                        if ( readingCourseNameList.get( iter ).equals( Constants.READING ) || readingCourseNameList.get( iter ).equals( courseNames.get( "Teacher" + teacherCount ).get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) )
                                || readingCourseNameList.get( iter ).equals( courseNames.get( "Teacher" + teacherCount ).get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) ) {
                            Log.message( studentNames.get( itr ) + " " + readingCourseNameList.get( iter ) );
                            executeCourse( driver, studentNames.get( itr ), readingCourseNameList.get( iter ), false, true, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        } else {
                            Log.message( studentNames.get( itr ) + " " + readingCourseNameList.get( iter ) );
                            executeCourse( driver, studentNames.get( itr ), readingCourseNameList.get( iter ), false, false, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        }
                    } else {
                        Log.message( studentNames.get( itr ) + " " + readingCourseNameList.get( iter ) );
                        executeCourse( driver, studentNames.get( itr ), readingCourseNameList.get( iter ), false, false, ReportsUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                    }
                } catch ( IOException e ) {
                    e.printStackTrace();
                } finally {
                    driver.close();
                }
            } );

        } );
        Log.message( "***** Completed Reading course execution for Flex licensed school *****" );
    }

    /**
     * To execute Math and Reading courses
     * 
     * @param studentUserName
     * @param courseName
     * @param isMath
     * @param isClearIP
     * @param percentage
     * @throws IOException
     */
    private void executeCourse( WebDriver driver, String studentUserName, String courseName, boolean isMath, boolean isClearIP, String percentage ) throws IOException {

        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        try {
                            if ( percentage.equals( "0" ) ) {
                                studentsPage.executeMathCourse( studentUserName, courseName, percentage, "5", "50" );
                            } else {
                                studentsPage.executeMathCourse( studentUserName, courseName, percentage, "5", "35" );
                            }

                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, percentage, "1", "25" );
                }
                studentsPage.logout();
            } catch ( Exception e ) {
                Log.message( "Simulator  error -" + e );
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 2 ).forEach( value -> {
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, percentage, "3", "35" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, percentage, "1", "1" );
                }
                studentsPage.logout();
            } catch ( Exception e ) {
                Log.message( "Simulator  error -" + e );
            }
        }
    }

    /**
     * To get the school Name
     *
     * @param schoolForTest
     * @return
     */
    private String getSchools( Schools schoolForTest ) {
        try {

            return configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," )[schoolForTest.ordinal()];
        } catch ( Exception e ) {
            Log.message( "Give all the schools required in config.properties! " );
            return null;
        }
    }
}