package com.savvas.sm.report.bff.teacher.tests;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import io.restassured.response.Response;

public class PSRTeacherGraphQLTest extends UserAPI {
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String groupID;
    String teacherDetails;
    String orgId;
    String teacherId;
    String student1;
    String username;
    String studentId;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    int mathAssignmentId;
    HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentIds = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        studentId = SMUtils.getKeyValueFromResponse( student1, "userId" );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );
        groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );

        Log.message( "**** Assigning Assignments ****" );
        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, Arrays.asList( studentId ), Arrays.asList( "1", "2" ) );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment Ids - " + assignmentIds );

        mathAssignmentId = Integer.parseInt( assignmentIds.get( "Math" ) );

    }

    @Test ( dataProvider = "getData", groups = { "SMK-55495 Prescriptive Scheduling Report: Teacher - Create GraphQL API", "API", "smoke_test_case" }, priority = 1 )
    public void testPSRepostAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        Log.testCaseInfo( testcaseName + testcaseDescription );

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

        Map<String, String> queryItem = new HashMap<>();

        String payload = null;
        String query;
        Response response = null;
        switch ( scenarioType ) {
            case "VALID_STUDENT_IDS":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_TEACHER_IDS":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_SUBJECT":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_IS_GROUP_SELECTED":
                payload = getResponseBody( teacherId, orgId, 1, true, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_GROUP_ID":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_LIMIT":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_OFFSET":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_STARTDATE_ENDDATE":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

            case "VALID_LASTSESSION":
                payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentId ), Arrays.asList( mathAssignmentId ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                break;

        }

        Log.message( response.getBody().asString() );
        // Validation
        Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getPSReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        Log.message( "Test Passed" );
        Log.endTestCase();

    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_STUDENT_IDS" },
                { "TC002", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId and subject in request body ", "VALID_SUBJECT" },
                { "TC003", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and limit in request body", "VALID_LIMIT" },
                { "TC004", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and offset in request body", "VALID_OFFSET" },
                { "TC005", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and isGroupSelected in request body", "VALID_IS_GROUP_SELECTED" },
                { "TC006", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and  valid lastSession  in request body", "VALID_LASTSESSION" },
                { "TC007", "200", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and  valid startDate and endDate  in request body", "VALID_STARTDATE_ENDDATE" },
                { "TC008", "200", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and  valid groupIds  in request body", "VALID_GROUP_ID" }, };
    }

    @Test ( dataProvider = "getDataAllScenario", groups = { "SMK-55495 Prescriptive Scheduling Report: Teacher - Create GraphQL API", "API" }, priority = 1 )
    public void testPSRepostAPIAllScenario( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        Date date = new Date();
        String targetDate = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );

        String payload = getPayloadAllScenario();
        String query;
        Response response = null;
        String responseStatusCode = "";
        switch ( scenarioType ) {
            case "VALID_SCENARIO":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, ReportAPIConstants.BACK_SLASH + targetDate + ReportAPIConstants.BACK_SLASH );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                System.out.println( payload );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_TOKEN":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_ORG_ID_HEADER":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_USER_ID_HEADER":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_ORG_ID":
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_USER_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SUBJECT_MATH":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.SUBJECT, "1" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SUBJECT_READING":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.SUBJECT, "2" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_TARGET_DATE":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_GROUP_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.GROUP_ID, ReportAPIConstants.INVALID_GROUP_IDS );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_LIMIT":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.LIMIT, ReportAPIConstants.INVALID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_LIMIT_ZERO":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.LIMIT, "0" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
            case "INVALID_OFFSET":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.OFFSET, ReportAPIConstants.INVALID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_IS_GROUP_SELECTED":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, ReportAPIConstants.INVALID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADEK":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "K", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE1":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "1", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE2":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "2", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE3":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "3", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE4":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "4", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE5":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "5", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE6":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "6", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE7":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "7", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE8":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "8", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE9":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "9", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE10":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "10", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE11":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "11", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE12":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "12", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataAllScenario() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_SCENARIO" },
                { "TC002", "401", "Verify the status code 401 for response body for not providing token in header", "WITHOUT_TOKEN" },
                { "TC003", "400", "Verify the status code 400 for response body for not providing orgId in request body", "WITHOUT_ORG_ID" },
                { "TC004", "400", "Verify the status code 400 for response body for not providing userId in request body", "WITHOUT_USER_ID" },
                { "TC005", "UNAUTHENTICATED", "Verify the status code 400 for response body for not providing orgId in header", "WITHOUT_ORG_ID_HEADER" },
                { "TC006", "UNAUTHENTICATED", "Verify the status code 400 for response body for not providing userId in header", "WITHOUT_USER_ID_HEADER" },
                { "TC007", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_MATH" },
                { "TC008", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_READING" },
                { "TC009", "400", "Verify the status code 400 for response body for not providing target date in request body", "WITHOUT_TARGET_DATE" },
                { "TC010", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and  invalid groupIds  in request body", "INVALID_GROUP_ID" },
                { "TC011", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald limit in request body", "INVALID_LIMIT" },
                { "TC012", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald limit (0) in request body", "INVALID_LIMIT_ZERO" },
                { "TC013", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald offset in request body", "INVALID_OFFSET" },
                { "TC014", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invalid isGroupSelected  in request body", "INVALID_IS_GROUP_SELECTED" },
                { "TC015", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid gradek in request body", "GRADEK" },
                { "TC016", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade1 in request body", "GRADE1" },
                { "TC017", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade2 in request body", "GRADE2" },
                { "TC018", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade3 in request body", "GRADE3" },
                { "TC019", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade4 in request body", "GRADE4" },
                { "TC020", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade5 in request body", "GRADE5" },
                { "TC021", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade6 in request body", "GRADE6" },
                { "TC022", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade7 in request body", "GRADE7" },
                { "TC023", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade8 in request body", "GRADE8" },
                { "TC024", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade9 in request body", "GRADE9" },
                { "TC025", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade10 in request body", "GRADE10" },
                { "TC026", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade11 in request body", "GRADE11" },
                { "TC027", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade11 in request body", "GRADE12" },

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "PSRGraphQLRequestBody" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getPayloadAllScenario() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "PSReportTeacherRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getResponseBody( String userId, String orgId, int subject, boolean isGroupSelected, List<String> groupIds, List<String> studentIds, List<Integer> assignmentIds ) {
        AtomicReference<String> requestBody = new AtomicReference<>();
        try {
            LocalDate now = LocalDate.now();
            Date date = new Date();
            LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.MONDAY ) );
            String thisWeekStartDay = firstMonday.toString();
            String thisWeekEndDay = new SimpleDateFormat( "MM-dd-yyyy" ).format( date );

            // getting randon number for grade
            Random random = new Random();
            int rand = 0;
            while ( true ) {
                rand = random.nextInt( 8 );
                if ( rand != 0 )
                    break;
            }
            // Generate Payload
            String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report"
                    + File.separator;
            requestBody.set( SMUtils.convertFileToString( basePath + "PSRGraphQLRequestBody.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.teacherId", userId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", orgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.isGroupSelected", isGroupSelected ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.assignmentIds", assignmentIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.groupIds", groupIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.studentIds", studentIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.targetDate", thisWeekEndDay ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.gradeK", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade1", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade2", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade3", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade4", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade5", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade6", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade8", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade9", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade10", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade11", random.nextInt( 8 ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.grade12", random.nextInt( 8 ) ) );

            Log.message( "Payload : " + requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return requestBody.get();
    }

    // Get response for reading data
    public HashMap<String, HashMap<String, String>> getDataFromResponse( String response ) {

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( response, "data,getPSReportData,psReportResponse" );
        Log.message( "Response Data: " + jsonObj );
        String userData = getKeyValueFromResponseWithArray( jsonObj, "rows" );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();
        //HashMap<String, String> studentReport = new HashMap<>();

        IntStream.range( 0, new JSONArray( userData ).length() ).forEach( iter -> {

            HashMap<String, String> studentReport = new HashMap<>();
            String studentName = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "firstName" ) + " " + SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "lastName" );
            studentReport.put( "currentCourseLevel", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedCurrentLevel" ) );
            studentReport.put( "ipmLevel", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedIpmLevel" ) );
            studentReport.put( "timeSinceIp", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedTimeSinceIp" ) );
            studentReport.put( "percentSkillsMastered", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "percentSkillsMastered" ) );
            studentReport.put( "sessionLength", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedSessionLength" ) );
            studentReport.put( "averageMinPerDay", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedAverageMinPerDay" ) );
            studentReport.put( "currentLearningRate", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "currentLearningRate" ) );
            studentReport.put( "projectedAdditionalTimeToEndDate", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedProjectedAdditionalTimeToEndDate" ) );
            studentReport.put( "projectedEndLevel", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "projectedEndLevelDisplay" ) );
            studentReport.put( "additionalSessionsToReachTarget", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "additionalSessionsToReachTarget" ) );
            studentReport.put( "additionalTimeToReachTarget", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedAdditionalTimeToReachTarget" ) );
            studentReport.put( "additionalMinutesPerDayToReachTarget", SMUtils.getKeyValueFromResponseWithArray( new JSONArray( userData ).get( iter ).toString(), "formattedAdditionalMinutesPerDayToReachTarget" ) );
            studentReportDetails.put( studentName, studentReport );
        } );
        Log.message( "Response Data: " + studentReportDetails );
        return studentReportDetails;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {
            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();
                //return keyValue;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }

}
