package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CPAggregateReportOptions extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    }

    @Test ( description = "Verify the selected Additional grouping field and Sort Option field is displaying in the Selected Option", groups = { "SMK-61283", "CPAggregateReportOption", "CPAggregate" }, priority = 1 )
    public void tcCPRAggregateReportOption_001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateReportOption_001: Verify the selected Additional grouping field and Sort Option field is displaying in the Selected Option. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin(username , password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReportViewerPage outputPage = new CPAReportViewerPage( driver );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"School\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"IP Level\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 2 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 2 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Time Spent\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 4 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 4 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Exercises Percent Correct\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 8 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 8 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Skills Assessed\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 9 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 9 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Skills Percent Mastered\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 11 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 11 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"None\" is selected in Additional grouping and \"Skills Percent Mastered\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 0 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 11 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Current Course Level\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 1 ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 2 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 1 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Gain\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 3 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 3 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Total Sessions\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 5 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 5 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Exercises Attempted\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 7 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 7 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Skills Mastered\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 10 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 10 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when \"Grade\" is selected in Additional grouping and \"Percent Students With AP\" is selected in Sort options" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_CPAR.get( 12 ) );

            outputPage.clickRunReportButton();


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 12 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics is displaying in the Selected Option", groups = { "SMK-61283", "CPAggregateReportOption", "CPAggregate" }, priority = 1 )
    public void tcCPRAggregateReportOption_002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateReportOption_002: Verify the Student demographics is displaying in the Selected Option. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReportViewerPage outputPage = new CPAReportViewerPage( driver );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Disability Status-All'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown ), "The Selected Disability Status values are displaying successfully ", "The Selected Disability Status values are not displaying properly " );

            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Disability Status:Yes'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            List<String> selectedOptions =  CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions ), "The Selected Disability Status values are displaying successfully ", "The Selected Disability Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Disability Status:No'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList(  ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            List<String> selectedOptions1 =  CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions1 ), "The Selected Disability Status values are displaying successfully ", "The Selected Disability Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Disability Status:Not Specified'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 3 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 3 ) ) );
            List<String> selectedOptions2 =  CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions2 ), "The Selected Disability Status values are displaying successfully ", "The Selected Disability Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'English Language Proficiency: All'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 0 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown1 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown1 ), "The Selected English Language Proficiency values are displaying successfully ", "The Selected English Language Proficiency values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'English Language Proficiency: English'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 0 ) ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ),  ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 )  ) );
            List<String> selectedOptionsFromMultiSelectDropdown3 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown3 ), "The Selected English Language Proficiency values are displaying successfully ", "The Selected English Language Proficiency values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'English Language Proficiency: English Language Learner'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ),  ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 )  ) );
            List<String> selectedOptionsFromMultiSelectDropdown4 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown4 ), "The Selected English Language Proficiency values are displaying successfully ", "The Selected English Language Proficiency values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'English Language Proficiency:Not Specified'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ) ,  ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 3 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown5 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown5 ), "The Selected English Language Proficiency values are displaying successfully ", "The Selected English Language Proficiency values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Migrant Status: All'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown2 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown2 ), "The Selected Migrant Status values are displaying successfully ", "The Selected Migrant Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Migrant Status: Migrant'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList(   ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList(   ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown6 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown6 ), "The Selected Migrant Status values are displaying successfully ", "The Selected Migrant Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Migrant Status: Not Migrant'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList(  ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 )  ) );
            List<String> selectedOptionsFromMultiSelectDropdown7 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown7 ), "The Selected Migrant Status values are displaying successfully ", "The Selected Migrant Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Migrant Status: Not Specified'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList(  ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 3 )  ) );
            List<String> selectedOptionsFromMultiSelectDropdown8 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown8 ), "The Selected Migrant Status values are displaying successfully ", "The Selected Migrant Status values are not displaying properly " );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics is displaying in the Selected Option", groups = { "SMK-61283", "CPAggregateReportOption", "CPAggregate" }, priority = 1 )
    public void tcCPRAggregateReportOption_003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateReportOption_003: Verify the Student demographics is displaying in the Selected Option. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin(username , password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReportViewerPage outputPage = new CPAReportViewerPage( driver );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: All'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: White'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ),  ReportsUIConstants.RACE_OPTIONS.get( 1 )  ) );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: Black or African American'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList(  ReportsUIConstants.RACE_OPTIONS.get( 2 )  ) );
            List<String> selectedOptions = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );


            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: Asian'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList(   ReportsUIConstants.RACE_OPTIONS.get( 3 )  ) );
            List<String> selectedOptions1 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions1 ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: American Native or Alaskan Native'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList(  ReportsUIConstants.RACE_OPTIONS.get( 4 )  ) );
            List<String> selectedOptions2 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions2 ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: Native Hawaiian or Pacific Islander'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ),  ReportsUIConstants.RACE_OPTIONS.get( 5 )  ) );
            List<String> selectedOptions3 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions3 ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity: Hispanic/Latino'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ),  ReportsUIConstants.RACE_OPTIONS.get( 6 )  ) );
            List<String> selectedOptions4 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions4 ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity:Unknown'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ) ,  ReportsUIConstants.RACE_OPTIONS.get( 7 ) ) );
            List<String> selectedOptions5 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions5 ), "The Selected Race values are displaying successfully ", "The Selected Race values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Race / Ethnicity:Not Specified'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ),  ReportsUIConstants.RACE_OPTIONS.get( 8 )  ) );
            List<String> selectedOptions6 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions6 ), "The Selected Disability Race are displaying successfully ", "The Selected Race values are not displaying properly " );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics is displaying in the Selected Option", groups = { "SMK-61283", "CPAggregateReportOption", "CPAggregate" }, priority = 1 )
    public void tcCPRAggregateReportOption_004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateReportOption_004: Verify the Student demographics is displaying in the Selected Option. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin(username , password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReportViewerPage outputPage = new CPAReportViewerPage( driver );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Special Services:All'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown ), "The Selected Special Services values are displaying successfully ", "The Selected Special Services values are not displaying properly " );

            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Special Services:Gifted/Talented'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList(  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 )  ) );
            List<String> selecetdOptions = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown(  ReportsUIConstants.SPECIAL_SERVICES );
            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selecetdOptions ), "The Selected Special Services values are displaying successfully ", "The Selected Special Services values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Special Services:IEP'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList(  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 3 )  ) );
            List<String> selecetdOptions1 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown(  ReportsUIConstants.SPECIAL_SERVICES );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selecetdOptions1 ), "The Selected Special Services values are displaying successfully ", "The Selected Special Services values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Special Services:Other'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 0 ) ,  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 4 ) ) );
            List<String> selectedOptions2 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown(  ReportsUIConstants.SPECIAL_SERVICES );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions2 ), "The Selected Special Services values are displaying successfully ", "The Selected Special Services values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Special Services:Not Specified'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList(  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 6 )  ) );
            List<String> selectedOptions3 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown(  ReportsUIConstants.SPECIAL_SERVICES );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions3 ), "The Selected Special Services values are displaying successfully ", "The Selected Special Services values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Socioeconomic status:All'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 0 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown1 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown1 ), "The Selected Socioeconomic Status values are displaying successfully ", "The Selected Socioeconomic Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Socioeconomic status:Economically disadvantaged'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 )  ) );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown1 ), "The Selected Socioeconomic Status values are displaying successfully ", "The Selected Socioeconomic Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Socioeconomic status:Not Economically disadvantaged'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList(  ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 )  ) );
            List<String> selectedOptions = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions ), "The Selected Socioeconomic Status values are displaying successfully ", "The Selected Socioeconomic Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Socioeconomic status:Not Specified'" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 3 ) ) );
            List<String> selectedOptions1 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions1 ), "The Selected Socioeconomic Status values are displaying successfully ", "The Selected Socioeconomic Status values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Ethnicity: All '" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 0 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 0 ) ) );
            List<String> selectedOptionsFromMultiSelectDropdown2 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY );


            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptionsFromMultiSelectDropdown2 ), "The Selected Ethnicity values are displaying successfully ", "The Selected Ethnicity values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Ethnicity: Hispanic or Latino '" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            List<String> selectedOptions4 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions4 ), "The Selected Ethnicity values are displaying successfully ", "The Selected Ethnicity values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Ethnicity: Not Hispanic or Latino '" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            List<String> selectedOptions5 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions5 ), "The Selected Ethnicity values are displaying successfully ", "The Selected Ethnicity values are not displaying properly " );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated CPR aggregate report when Filter Students by Demographics is selected as 'Ethnicity: Not Specified '" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 3 ) ) );
            List<String> selectedOptions6 = CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );

            outputPage.clickRunReportButton();
            SMUtils.waitForSpinnertoDisapper( driver, 10 );

            Log.assertThat( outputPage.getSelectedAdditionalGrouping().equals( ReportsUIConstants.ADDITIONAL_GROUPING_NONE ), "The selected additional grouping option is displaying successfully",
                    "The selected additional grouping option is not displaying properly" );
            Log.assertThat( outputPage.getSelectedSortOption( ReportsUIConstants.SORT_CPAR.get( 0 ) ), "The selected sort option is displaying successfully", "The selected sort option is not displaying properly" );
            Log.assertThat( outputPage.selectedOptionDemographic().equals( ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED ), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly" );
            Log.assertThat( outputPage.assignedGradeLevels(), "The assigned grade levels is displaying successfully", "The assigned grade levels is not displaying properly" );
            Log.assertThat( outputPage.verifyDemographicValues( selectedOptions6 ), "The Selected Ethnicity values are displaying successfully ", "The Selected Ethnicity values are not displaying properly " );


        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
