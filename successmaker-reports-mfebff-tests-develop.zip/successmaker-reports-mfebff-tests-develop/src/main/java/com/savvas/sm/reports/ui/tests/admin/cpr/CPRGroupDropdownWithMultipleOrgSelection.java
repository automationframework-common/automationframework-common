package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.admin.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.Constants.ReportDataCreation;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class CPRGroupDropdownWithMultipleOrgSelection extends EnvProperties {

    private String adminUsername;
    private String password;
    private String smUrl;
    private String browser;
    private String flexSchool;
    private String mathSchool;
    private String usernameSuffixTest;
    List<String> flexSchoolGroup = new ArrayList<>();
    List<String> mathSchoolGroup = new ArrayList<>();
    private String sharedGroup;
    private String flexTeachername;
    private String mathSchoolTeacher;

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        adminUsername = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        mathSchoolTeacher = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 2, usernameSuffixTest );

        String flexSchoolTeacher = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 1, usernameSuffixTest );

        String flexUserId = new RBSUtils().getUserIDByUserName( mathSchoolTeacher );
        String flexTeacherDetails = new RBSUtils().getUser( flexUserId );
        String flexTeacherFirstName = SMUtils.getKeyValueFromResponse( flexTeacherDetails, "firstName" );
        String flexTeacherLastName = SMUtils.getKeyValueFromResponse( flexTeacherDetails, "lastName" );

        flexTeachername = flexTeacherFirstName + " " + flexTeacherLastName;

        Log.message( "Teacher name" + flexTeacherLastName );

        mathSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( mathSchoolTeacher ) ).get( 0 ).toString(), "groupName" ) );
        mathSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( mathSchoolTeacher ) ).get( 1 ).toString(), "groupName" ) );

        if ( mathSchoolGroup.contains( ReportDataCreation.GROUP_WITH_NO_STUDENTS ) ) {
            mathSchoolGroup.remove( ReportDataCreation.GROUP_WITH_NO_STUDENTS );
            mathSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( mathSchoolTeacher ) ).get( 2 ).toString(), "groupName" ) );

        } else if ( mathSchoolGroup.contains( ReportDataCreation.SHARED_GROUP ) ) {
            mathSchoolGroup.remove( ReportDataCreation.SHARED_GROUP );
            mathSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( mathSchoolTeacher ) ).get( 2 ).toString(), "groupName" ) );

        }

        flexSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( flexSchoolTeacher ) ).get( 0 ).toString(), "groupName" ) );
        flexSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( flexSchoolTeacher ) ).get( 1 ).toString(), "groupName" ) );

        if ( flexSchoolGroup.contains( ReportDataCreation.GROUP_WITH_NO_STUDENTS ) ) {
            flexSchoolGroup.remove( ReportDataCreation.GROUP_WITH_NO_STUDENTS );
            flexSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( mathSchoolTeacher ) ).get( 2 ).toString(), "groupName" ) );

        } else if ( flexSchoolGroup.contains( ReportDataCreation.SHARED_GROUP ) ) {
            flexSchoolGroup.remove( ReportDataCreation.SHARED_GROUP );
            flexSchoolGroup.add( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( mathSchoolTeacher ) ).get( 2 ).toString(), "groupName" ) );
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown under optional filter is loaded with all the groups for the selected school" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection001() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection001 - Verify group dropdown under optional filter is loaded with all the groups for the selected school" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );
            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Log.message( "Groups list UI : " + groupDropdownValues );

            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown under optional filter is loaded with all the groups for the selected teachers under the selected school" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection002() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection002 - Verify group dropdown under optional filter is loaded with all the groups for the selected teachers under the selected school" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( flexTeachername + " (" + flexSchool + ")" ) );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown is reloaded with correct groups when teacher is deselected in teacher dropdown" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection003() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection003 - Verify group dropdown is reloaded with correct groups when teacher is deselected in teacher dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            SMUtils.nap( 5 );

            cprPage.reportFilterComponent.expandOptionalFilter();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown is reloaded with correct groups when teacher is selected additionally in teacher dropdown" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection004() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection004 - Verify group dropdown is reloaded with correct groups when teacher is selected additionally in teacher dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection",
            "smoke_test_case" }, description = "Verify group dropdown is reloaded with all the groups under the selected schools when all the teachers are deselected in teacher dropdown" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection005() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection005 - Verify group dropdown is reloaded with all the groups under the selected schools when all the teachers are deselected in teacher dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should reload when org is selected additionally" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection006() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection006 - Verify group dropdown should reload when org is selected additionally" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( ReportsUIConstants.SM_GROUP_ONE + " (" + flexSchool + ")", ReportsUIConstants.SM_GROUP_TWO + " (" + flexSchool + ")" ) ),
                    "Group dropdown is loaded with all groups for selected school", "Group dropdown is not loaded with all groups for selected school" );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            SMUtils.nap( 5 );
            groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( mathSchoolGroup.get( 0 ) + " (" + mathSchool + ")", mathSchoolGroup.get( 1 ) + " (" + mathSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should reload when few orgs are deselected" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection007() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection007 - Verify group dropdown should reload when few orgs are deselected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.assertThat( !groupDropdownValues.containsAll( Arrays.asList( mathSchoolGroup.get( 0 ) + " (" + mathSchool + ")", mathSchoolGroup.get( 1 ) + " (" + mathSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should not show the group without product association" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection008() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection007 - Verify group dropdown should not show the group without product association" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( !groupDropdownValues.containsAll( Arrays.asList( ReportDataCreation.GROUP_WITHOUT_PRODUCT + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should show the duplicate groups under same teacher" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection009() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection008 - Verify group dropdown should show the duplicate groups under same teacher" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should not show the group without any students" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection010() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection009 - Verify group dropdown should not show the group without any students" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );

            Log.assertThat( !groupDropdownValues.containsAll( Arrays.asList( ReportDataCreation.GROUP_WITH_NO_STUDENTS + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should show the duplicate groups under different teacher" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection011() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection010 - Verify group dropdown should show the duplicate groups under different teacher" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify group dropdown should show the duplicate groups under different orgs" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection012() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection011 - Verify group dropdown should show the duplicate groups under different orgs" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( mathSchoolGroup.get( 0 ) + " (" + mathSchool + ")", mathSchoolGroup.get( 1 ) + " (" + mathSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection",
            "smoke_test_case" }, description = "Verify group dropdown should retain saved report option with multiple orgs groups when multiple organization is selected and all the groups are selected" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection013() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection012 - Verify group dropdown should retain saved report option with multiple orgs groups when multiple organization is selected and all the groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            SaveReportFilterPopup saveReportOptionPopup = cprPage.reportFilterComponent.clickSaveReportOptionButton();

            String filterName = "SpecficFilter" + System.nanoTime();
            Log.message( "Filter Name: " + filterName );
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            saveReportOptionPopup.clickSaveButton();
            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.clickResetButton();
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL, filterName );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69729", "Groups - Multi Org Selection",
            "smoke_test_case" }, description = "Verify group dropdown should retain saved report option with multiple orgs groups for the selected teachers  when multiple organization and teacher is selected and all the groups are selected" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection014() throws Exception {

        Log.testCaseInfo(
                "tcCPRGroupDropdownWithMultipleOrgSelection013 - Verify group dropdown should retain saved report option with multiple orgs groups for the selected teachers  when multiple organization and teacher is selected and all the groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.MATH );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            SaveReportFilterPopup saveReportOptionPopup = cprPage.reportFilterComponent.clickSaveReportOptionButton();

            String filterName = "SpecficFilter" + System.nanoTime();
            Log.message( "Filter Name: " + filterName );
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            saveReportOptionPopup.clickSaveButton();
            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.clickResetButton();

            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL, filterName );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( mathSchoolGroup.get( 0 ) + " (" + mathSchool + ")", mathSchoolGroup.get( 1 ) + " (" + mathSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify the organization name after the group name, If the group has no students" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection015() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection014 - Verify the organization name after the group name, If the group has no students" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );

            Log.assertThat( !groupDropdownValues.containsAll( Arrays.asList( ReportDataCreation.GROUP_WITH_NO_STUDENTS + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection",
            "smoke_test_case" }, description = "Verify the organization name in the groups dropdown after the group name. if user selects single organization in organization dropdown" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection016() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection015 - Verify the organization name in the groups dropdown after the group name. if user selects single organization in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection",
            "smoke_test_case" }, description = "Verify the organization name in the groups dropdown after the group name. if user selects multiple organizations in organization dropdown" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection017() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection016 - Verify the organization name in the groups dropdown after the group name. if user selects multiple organizations in organization dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( mathSchoolGroup.get( 0 ) + " (" + mathSchool + ")", mathSchoolGroup.get( 1 ) + " (" + mathSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify the organization name in the groups dropdown if the selected organization has two or more group in same name" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection018() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection017 - Verify the organization name in the groups dropdown if the selected organization has two or more group in same name" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( flexSchoolGroup.get( 0 ) + " (" + flexSchool + ")", flexSchoolGroup.get( 1 ) + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( mathSchoolGroup.get( 0 ) + " (" + mathSchool + ")", mathSchoolGroup.get( 1 ) + " (" + mathSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify the organization name in the groups dropdown if the selected organization has shared group" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection019() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection018 - Verify the organization name in the groups dropdown if the selected organization has shared group" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );
            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( ReportDataCreation.SHARED_GROUP + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection",
            "smoke_test_case" }, description = "Verify the organization name in the groups dropdown if the selected organization has shared group and the user selected one teacher in teacher dropdown" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection020() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection019 - Verify the organization name in the groups dropdown if the selected organization has shared group and the user selected one teacher in teacher dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( flexTeachername ) );

            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );

            Log.assertThat( groupDropdownValues.containsAll( Arrays.asList( ReportDataCreation.SHARED_GROUP + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-70083", "Groups - Multi Org Selection", "smoke_test_case" }, description = "Verify the organization name in the groups dropdown if the group's product has removed" )
    public void tcCPRGroupDropdownWithMultipleOrgSelection021() throws Exception {

        Log.testCaseInfo( "tcCPRGroupDropdownWithMultipleOrgSelection019 - Verify the organization name in the groups dropdown if the group's product has removed" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            SMUtils.nap( 5 );

            List<String> groupDropdownValues = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Groups list UI : " + groupDropdownValues );

            Log.assertThat( !groupDropdownValues.containsAll( Arrays.asList( ReportDataCreation.GROUP_WITHOUT_PRODUCT + " (" + flexSchool + ")" ) ), "Group dropdown is loaded with all groups for selected school",
                    "Group dropdown is not loaded with all groups for selected school" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
