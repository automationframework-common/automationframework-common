package com.savvas.sm.reports.smoke.admin.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindAll;
import LSTFAI.customfactories.IFindBy;

public class ReportsViewerPage extends LoadableComponent<ReportsViewerPage> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.CSS, using = "h2[class='header']", AI = false )
    public WebElement fldReportHeader;

    @IFindBy ( how = How.XPATH, using = "//span[text()='Report viewer']", AI = false )
    public WebElement txtReportViewer;

    @IFindBy ( how = How.CSS, using = "dl.detail-row.ml-3 dt", AI = false )
    public WebElement txtReportRunLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' School: ']", AI = false )
    public WebElement txtSchoolLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' Teacher: ']", AI = false )
    public WebElement txtTeacherLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' Grade: ']", AI = false )
    public WebElement txtGradeLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' Group: ']", AI = false )
    public WebElement txtGroupLabel;

    @IFindBy ( how = How.CSS, using = "span.list-head.ml-2", AI = false )
    public WebElement txtSelectedOptionsLabel;

    @IFindBy ( how = How.XPATH, using = "//span[@class='list-head']", AI = false )
    public WebElement txtLegendLabel;

    List<String> listAFGExpectedColumnList = new ArrayList<String>( Arrays.asList( "Strand", "Level", "Skill Description", "", "", "Student", "Date at Risk", "Targeted Lesson" ) );
    List<String> listCPRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Level Data", "Usage", "Instructional Performance", "Mastery", "", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent",
            "Total Sessions minimum of 1 assignment", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );
    List<String> listCPRAggregateExpectedColumnList = new ArrayList<String>( Arrays.asList( "School (Grade - # of Students)", "Level Data Mean", "Usage Mean", "Instructional Performance Mean", "Mastery Mean", "", "Current Course Level", "IP Level",
            "Gain", "Time Spent", "Total Sessions minimum of 1 assignment", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "Percent Students with AP" ) );
    List<String> listLSRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Level", "Raw Performance", "Usage", "", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Help Used",
            "Time Spent", "Total Sessions minimum of 1 assignment", "Session Date" ) );
    List<String> listPSRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Performance Data", "Current Rate", "Current Forecast", "Prescription", "", "Current Course Level", "IP Level", "Time Since IP", "Skills Percent Mastered",
            "Session Length Setting", "Average Min/Day", "Current Learning Rate", "Time", "Level", "Add'l Sessions to Target", "Add'l Time to Target", "Add'l Min/Day to Target" ) );
    List<String> listPSRAggregateExpectedColumnList = new ArrayList<String>(
            Arrays.asList( "Teacher", "Population", "Performance Data", "Current Forecast", "Prescription", "", "Students Included", "Students Not Included", "Current Course Level Mean", "IP Level Mean", "Time Since IP Mean", "Percent Students with AP",
                    "Percent Students at Target Level", "Projected End Level Mean", "Percent Students to Achieve Target Level", "Average Additional Min/Day to Target Students Projected Below Target" ) );
    List<String> listSEUExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Student Information", "Enrollment & Time Spent", "Usage", "", "Username (login)", "Student ID", "SM Math", "Custom Courses", "Total Time Spent",
            "Total Sessions minimum of 1 assignment", "Average Session Time", "Last Session Date" ) );

    /**
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */
    public ReportsViewerPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    public ReportsViewerPage() {}

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, fldReportHeader );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, fldReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author sathish.suresh Verify report page
     * @param driver
     */
    public void verifyReportPage( WebDriver driver ) {

        List<String> windowHandles = new ArrayList<String>( driver.getWindowHandles() ); // switch window to report
        driver.switchTo().window( windowHandles.get( windowHandles.size() - 1 ) );
        boolean isDisplayedReportViewerText = SMUtils.waitForElement( driver, txtReportViewer );
        Log.softAssertThat( isDisplayedReportViewerText, "Navigate to 'Report Viewer' page Successfully ", "Failed to navigate 'Report Viewer' page" );
    }

    /**
     * @author sathish.suresh Validate report columns
     * @param driver
     * @throws InterruptedException
     */
    public void validateReportOutputColumns( WebDriver driver ) throws InterruptedException {
        ReportsBrowserActions.waitForSpinnerToBeVisible( driver, 30 );
        ReportsBrowserActions.waitForSpinnerToBeInvisible( driver );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 45 ) );
        wait.until( ExpectedConditions.visibilityOf( driver.findElement( By.cssSelector( "report-grid" ) ) ) );
        List<WebElement> table = driver.findElements( By.cssSelector( "report-grid thead tr th" ) );
        List<String> columnsList = SMUtils.getAllTextFromWebElementList( table );
        String txtReportName = fldReportHeader.getText();
        switch ( txtReportName ) {
            case "Areas For Growth":
                Log.assertThat( columnsList.equals( listAFGExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Cumulative Performance":
            	System.out.println(columnsList);
            	System.out.println(listCPRExpectedColumnList);
            	
                Log.assertThat( columnsList.equals( listCPRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                
                break;
            case "Cumulative Performance Aggregate":
                Log.assertThat( columnsList.equals( listCPRAggregateExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Last Session":
                Log.assertThat( columnsList.equals( listLSRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Prescriptive Scheduling":
                Log.assertThat( columnsList.equals( listPSRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Prescriptive Scheduling Aggregate":
                Log.assertThat( columnsList.equals( listPSRAggregateExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Student Performance":
                List<WebElement> lstColumns = driver.findElements( By.cssSelector( "h2.rectangle" ) );
                boolean columnsListstatus = lstColumns.size() == 3;
                Log.assertThat( columnsListstatus, txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "System Enrollment and Usage":
                Log.assertThat( columnsList.equals( listSEUExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            default:
                break;
        }
    }

}
