package com.savvas.sm.reports.smoke.teacher.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class CumulativePerformanceReport extends LoadableComponent<CumulativePerformanceReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    Random random = new Random();
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Cumulative Performance Report']", AI = false )
    public WebElement txtCumulativePerformanceReportHeader;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/
    public String txtStudentPerformanceDates[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group').shadowRoot.querySelector('span')" };
    public String rdBtnAllDates[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group').shadowRoot.querySelector('div > div > cel-radio-button:nth-child(1)').shadowRoot.querySelector('#all')" };
    public String rdBtnSelectedDateRange[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group').shadowRoot.querySelector('div > div > cel-radio-button:nth-child(2)').shadowRoot.querySelector('#dates')" };
    public String txtAllDates[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group').shadowRoot.querySelector('div > div > cel-radio-button:nth-child(1)').shadowRoot.querySelector('label')" };
    public String txtSelectedDateRange[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group').shadowRoot.querySelector('div > div > cel-radio-button:nth-child(2)').shadowRoot.querySelector('label')" };
    public String eleCumulativePerformanceAggregate[] = { "cel-tab-panel", "document.querySelector('cel-tab-panel').shadowRoot.querySelector('#\\\\31')" };
    public String btnCumulativePerformanceAggregate[] = { "cel-tab-panel", "document.querySelector('cel-tab-panel').shadowRoot.querySelector('button[id = \"1\"]')" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };

    /* Text */
    public String studentPerformanceDates = "STUDENT PERFORMANCE DATES";
    public String allDates = "All Dates";
    public String selectedDateRange = "Selected Date Range";
    public String txtCumulativePerformanceAggregate = "Cumulative Performance Aggregate";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtCumulativePerformanceReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public CumulativePerformanceReport() {}

    public CumulativePerformanceReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas Validate Student Performance Dates Element &
     *         Text
     * @throws InterruptedException
     */
    public void validateTxtStudentPerformanceDates( WebDriver driver ) throws InterruptedException {
        WebElement txtStudentPerformanceDates = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtStudentPerformanceDates[0], this.txtStudentPerformanceDates[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtStudentPerformanceDates, "student Performance Dates Element" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtStudentPerformanceDates, studentPerformanceDates, "Text : student Performance Dates" );
    }

    /**
     * @author aravindan.srinivas Validate All Dates Element & Text
     * @throws InterruptedException
     */
    public void validateTxtAllDates( WebDriver driver ) throws InterruptedException {
        WebElement txtAllDates = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtAllDates[0], this.txtAllDates[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtAllDates, "All Dates Element" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtAllDates, allDates, "Text : All Dates" );
    }

    /**
     * @author aravindan.srinivas Validate Selected DateRange Element & Text
     * @throws InterruptedException
     */
    public void validateTxtSelectedDateRange( WebDriver driver ) throws InterruptedException {
        WebElement txtSelectedDateRange = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtSelectedDateRange[0], this.txtSelectedDateRange[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSelectedDateRange, "Selected DateRange" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSelectedDateRange, selectedDateRange, "Text : Selected DateRange" );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button All Dates
     * @throws InterruptedException
     */
    public void validateRdBtnAllDates( WebDriver driver ) throws InterruptedException {
        WebElement rdBtnAllDates = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdBtnAllDates[0], this.rdBtnAllDates[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdBtnAllDates, "All Dates Radio Button " );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button Selected Date Range
     * @throws InterruptedException
     */
    public void validateRdBtnSelectedDateRange( WebDriver driver ) throws InterruptedException {
        WebElement rdBtnSelectedDateRange = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdBtnSelectedDateRange[0], this.rdBtnSelectedDateRange[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdBtnSelectedDateRange, "Selected Date Range " );
    }

    /**
     * @author aravindan.srinivas Validate all the fields and headers present in
     *         the Cumulative Performance Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInCumulativePerformanceReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtCumulativePerformanceReportHeader.getText();

        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        // groups & Students - text
        // groups text & drop down
        // students text and drop down 
        reportsFilterUtils.verifyTextGroupsAndStudents( driver );
        reportsFilterUtils.verifyTextGroupsHeader( driver );
        reportsFilterUtils.validateGroupsDrpdwnField( driver );

        reportsFilterUtils.verifyTextStudentsHeader( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        //Assignment text & drop down
        reportsFilterUtils.verifyTextAssignmentsHeader( driver );
        reportsFilterUtils.validateAssignmentsDrpdwnField( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );

        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );
        SMUtils.click( driver, txtOptionalFilter );

        reportsFilterUtils.verifyTextAdditionalGrouping( driver );
        reportsFilterUtils.validateAdditionalGroupingDrpdwnField( driver );

        reportsFilterUtils.verifyTextDisplay( driver );
        reportsFilterUtils.validateDisplayDrpdwnField( driver );

        reportsFilterUtils.validateMaskCheckBoxField( driver );

        reportsFilterUtils.verifyTextSortInAdditionalGrouping( driver );
        reportsFilterUtils.validateSortDrpdwnField( driver, currentReportName );

        validateTxtStudentPerformanceDates( driver );

        validateRdBtnAllDates( driver );
        validateTxtAllDates( driver );

        validateRdBtnSelectedDateRange( driver );
        validateTxtSelectedDateRange( driver );

    }

    /**
     * @author sathish.suresh Validate CPR run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateCPRRunReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds());
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "organization", expgroupNames.get(0));
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author raseem.mohamed CPR saved report Validation
     * @param driver
     * @throws InterruptedException
     */
    public void validateCPRSavedReports( WebDriver driver ) throws InterruptedException {
        String savedReportName = "Automation Teacher SavedReport " + random.nextInt(); // Generating Random Name For Saved
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Thread.sleep( 2000 );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Cumulative Performance Report" ), "User Landed On Cumulative Performance Report", "User Not Landed On Cumulative Performance Report" );
        List<String> expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds());
        List<String> groups = new ArrayList<String>( Arrays.asList( expgroupNames.get(0) ) );
        reportsFilterUtils.selectGroupsDropdwn( driver, groups );
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public CumulativePerformanceReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtCumulativePerformanceReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to expand optional filters
     * 
     * @param driver
     * @return
     */
    public CumulativePerformanceReport clickOptionalFilters( WebDriver driver ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtCumulativePerformanceReportHeader );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        SMUtils.click( driver, txtOptionalFilter );
        return this;

    }

    /**
     * @author sathish.suresh Validate Teacher CPR run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateCPRTeacherRunReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        reportsFilterUtils.selectStudentRadioBtn( driver );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sakthi.sasi Used to verify the Groups in UI matches the Group
     *         fetched from RBS
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public CumulativePerformanceReport verifyGroup( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds() );
        List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getTeacherGroupNames();
        Collections.sort( expgroupNames );
        Collections.sort( allValuesFromGroupsDropdown );
        Log.softAssertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
        return this;
    }

    /**
     * @author sakthi.sasi
     *  Used to verify the assignments
     * @param driver
     * @param username
     * @param smUrl
     * @param teacherDetails
     * @param assignmentType
     * @return
     * @throws Exception
     */
    public CumulativePerformanceReport verifyAssignments( WebDriver driver, String username, String smUrl, String teacherDetails, String assignmentType ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> assignmentsFromUI = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.ASSIGNMENTS );
        List<String> assignmentList = reportsFilterUtils.getAssignmentDetails( smUrl, username, teacherDetails, assignmentType );
        Log.softAssertThat( assignmentList.containsAll( assignmentsFromUI ), "All assignments displayed properly in the assignment dropdown!", "Assignments not displayed properly in thes assignment dropdown" );
        return this;
    }

    /**
     * @author sakthi.sasi
     * Used to verify the students
     * @param driver
     * @param schoolName
     * @param username
     * @return
     * @throws Exception
     */
    public CumulativePerformanceReport verifyStudents( WebDriver driver, String schoolName, String username ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        reportsFilterUtils.selectStudentRadioBtn( driver );
        // get WebElements of dropdown option checkboxes
        List<String> allStudentsFromUI = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.Teacher_Students );
        List<String> studentNames = reportsFilterUtils.getStudentsList( username, schoolName );
        Log.softAssertThat( studentNames.containsAll( allStudentsFromUI ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );
        return this;
    }


}
