package com.savvas.sm.reports.ui.tests.teacher.cpr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.teacher.ui.pages.ReportNavigation;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class CPReportSaveReportOptions extends EnvProperties {

    private String smUrl;
    private String browser;
    private String sessionCookie;
    private String username;
    private String username1;
    String userId;
    String userId1;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String teacherDetails1;
    private String studentLastName;
    private String CourseId;

    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    ReportComponents reportComponents;

    ReportNavigation reportnav;
    String teacherUsername;
    String orgId;
    String endPoint;
    String teacherStaffId;
    String studentDetailsSchool1;
    String courseId;
    String studentDetails;
    String studentIdOne;
    String studentIdTwo;
    HashMap<String, String> assignmentDetails = new HashMap<>();
    String districtId;
    String studentThreeDetails;
    String studentFourDetails;
    String studentFiveDetails;
    String studentIdThree;
    String studentIdFour;
    String studentIdFive;
    String studentTwoDetail;
    List<String> studentRumbaIds = new ArrayList<>();
    List<String> studentRumbaIds2 = new ArrayList<>();
    List<String> studentRumbaIds1 = new ArrayList<>();
    Map<String, String> courseIDs = new HashMap<>();
    Map<String, String> contentBase = new HashMap<>();
    HashMap<String, String> courseName = new HashMap<>();
    String assignmentId;
    String firstMathAssignmentUserId;
    String secondMathAssignmentUserId;
    List<String> mathAssignmentUserId = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();

    @BeforeClass
    public void initTest() throws Exception, IOException {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        districtId = configProperty.getProperty( "district_ID" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "userName" );
        userId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentIdOne = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );

        studentTwoDetail = RBSDataSetup.getMyStudent( school, username );
        studentIdTwo = SMUtils.getKeyValueFromResponse( studentTwoDetail, "userId" );

        studentThreeDetails = RBSDataSetup.getMyStudent( school, username );
        studentIdThree = SMUtils.getKeyValueFromResponse( studentThreeDetails, "userId" );

        studentFourDetails = RBSDataSetup.getMyStudent( school, username1 );
        studentIdFour = SMUtils.getKeyValueFromResponse( studentFourDetails, "userId" );

        studentFiveDetails = RBSDataSetup.getMyStudent( school, username1 );
        studentIdFive = SMUtils.getKeyValueFromResponse( studentFiveDetails, "userId" );

        orgId = new RBSUtils().getOrganizationIDByName( districtId, school );

        studentRumbaIds.add( studentIdOne );
        studentRumbaIds.add( studentIdTwo );
        studentRumbaIds.add( studentIdThree );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

        courseIDs.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIDs.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS,
                courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId,
                courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD,
                courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL,
                courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

        HashMap<String, String> mathAssignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentRumbaIds.get( 0 ) ), new ArrayList<>( courseIDs.values() ) );

        Log.message( mathAssignmentResponse.get( "body" ) );

        studentRumbaIds2.add( studentIdOne );
        studentRumbaIds2.add( studentIdTwo );
        studentRumbaIds2.add( studentIdThree );

        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

        courseIDs.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId,
                DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId,
                courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId,
                DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId, DataSetupConstants.SKILL,
                courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

        HashMap<String, String> readingAssignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds2, new ArrayList<>( courseIDs.values() ) );

        Log.message( readingAssignmentResponse.get( "body" ) );

        studentRumbaIds1.add( studentIdFour );
        studentRumbaIds1.add( studentIdFive );

        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

        courseIDs.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1, orgId,
                DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1,
                orgId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1, orgId,
                DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1, orgId, DataSetupConstants.SKILL,
                courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId1 );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username1, password ) );

        HashMap<String, String> readingAssignmentResponse1 = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds1, new ArrayList<>( courseIDs.values() ) );

        Log.message( readingAssignmentResponse1.get( "body" ) );

    }

    @Test ( description = "Verify the functionality of Save Report Option for Cumulative Performance Report", groups = { "SMK-66744", "Teacher Dashboard", "Reports", "Cumulative Performance Report" }, priority = 1 )
    public void tcCPRSaveReportOptions01( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the functionality of Save Report Option for Cumulative Performance Report<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( username, password );
            CumulativePerformancePage cumulativePerformancePage = areaForGrowthPage.reportFilterComponent.clickOnCumulativePerformancePage();

            Log.testCaseInfo( "Verify Saved Report Option label is displayed in the Cumulative Performance Report Page" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ), "The Cumulative Performance Save Report Option label is displayed and it is verified",
                    "Cumulative Performance Report Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "Cumulative Performance Report Save Report Option label text is displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "Cumulative Performance Report Save Report Option label text is not displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify Saved Report Option drop down is displayed in the Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "Cumulative Performance Report Save Report Option drop down is displayed and it is verified", "Cumulative Performance Report Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            String savedReport = "SavedReport" + System.nanoTime();
            SaveReportFilterPopup saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( savedReport );
            saveReportOptionPopup.clickSaveButton();
            Log.testCaseInfo( "Verify the default text in the displayed in the Saved Report Option drop down" );
            Log.message( cumulativePerformancePage.reportFilterComponent.getWatermarkTextForSaveReportDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ) );
            Log.assertThat(
                    cumulativePerformancePage.reportFilterComponent.getWatermarkTextForSaveReportDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).equals(
                            ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER ),
                    "Cumulative Performance Report Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER,
                    "Cumulative Performance Report Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ),
                    "The Cumulative Performance Save Report Option drop down arrow is displayed and it is verified", "The Cumulative Performance Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ),
                    "The arrow is in downward direction when it is collapsed", "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Saved Report option drop down is listed with saved report options" );
            cumulativePerformancePage.reportFilterComponent.expandSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Saved report option name is displayed when it is selected" );

            Log.testCaseInfo( "Verify user can click the 'Save Report Option' button in Cumulative Performance report page" );
            Log.testCaseInfo( "Verify all available fields in 'Save Report Option Popup." );
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();
            driver.navigate().refresh();
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            Log.testCaseInfo( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify user can able to cancel the in 'Save Report Option ' Popup on Cumulative Performance report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to save the report option with new name." );
            Log.testCaseInfo( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "SavedReport" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            String filterName2 = "SavedReport" + System.nanoTime();
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName2 );
            saveReportOptionPopup.clickSaveButton();
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify If User enter more than 50 characters in new custom report configuration text box." );
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            Log.testCaseInfo( "Verify User can able to click the close button in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            driver.navigate().refresh();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to single select Aditional Grouping" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.SELECTED_ADDITIONAL_OPTION );

            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ADDITIONAL_OPTION ),
                    "User is able to single select Aditional Grouping as Group", "Additional Grouping is not selected as a Group" );

            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to single select Sort" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.GAIN );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SORT_LABEL ).equalsIgnoreCase( ReportsUIConstants.GAIN ), "User is able to single select Sort as Gain",
                    "Sort is not selected as Gain" );

            Log.testCaseResult();
            Log.testCaseInfo( "Verify that after save report options, all the values saved before are getting retained for Math" );
            List<String> beforeSubjectValues = Arrays.asList( ReportsUIConstants.MATH );
            List<String> beforeAssignmentValues = Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION );
            List<String> beforeAdditionalGroupValues = Arrays.asList( ReportsUIConstants.GROUP );
            List<String> beforeSortValues = Arrays.asList( ReportsUIConstants.GAIN );
            List<String> beforeDisplayValues = Arrays.asList( ReportsUIConstants.STUDENT_NAME );

            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( ReportsUIConstants.SUBJECT_LABEL, beforeSubjectValues );
            beforeSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, beforeAssignmentValues );
            beforeSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, beforeAdditionalGroupValues );
            beforeSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, beforeSortValues );
            beforeSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, beforeDisplayValues );

            Log.message( "beforeSavedFilterValues: " + beforeSavedFilterValues );

            String savedReport1 = "SavedReport" + System.nanoTime();
            saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( savedReport1 );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( savedReport1 ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            List<String> subjectValues = Arrays.asList( ReportsUIConstants.MATH );
            List<String> assignmentValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL ) );
            List<String> adtlGroupingValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ) );
            List<String> sortValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SORT_LABEL ) );
            List<String> displayValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DISPLAY_LABEL ) );

            HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
            afterSavedFilterValues.put( ReportsUIConstants.SUBJECT_LABEL, subjectValues );
            afterSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, assignmentValues );
            afterSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, adtlGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, sortValues );
            afterSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, displayValues );

            Log.message( "afterSavedFilterValues: " + afterSavedFilterValues );

            Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                    "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that after save report options, all the values saved before are getting retained for Reading", groups = { "SMK-66744", "Teacher Dashboard", "Reports", "Cumulative Performance Report" }, priority = 1 )
    public void tcCPRSaveReportOptions02( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify that after save report options, all the values saved before are getting retained for Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( username, password );
            CumulativePerformancePage cumulativePerformancePage = areaForGrowthPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.chooseSubject( driver, ReportsUIConstants.READING );

            // Verify Reading Subject is selected
            Log.assertThat( cumulativePerformancePage.chooseSubject( driver, ReportsUIConstants.READING ), "The 'Reading' subject is selected", "The 'Reading' subject is not selected" );

            Log.testCaseInfo( "Verify User can able to single select Aditional Grouping" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP );

            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ADDITIONAL_OPTION ),
                    "User is able to single select Aditional Grouping as Group", "Additional Grouping is not selected as a Group" );

            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to single select Sort" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.GAIN );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SORT_LABEL ).equalsIgnoreCase( ReportsUIConstants.GAIN ), "User is able to single select Sort as Gain",
                    "Sort is not selected as Gain" );

            Log.testCaseResult();

            List<String> beforeSubjectValues = Arrays.asList( ReportsUIConstants.READING );
            List<String> beforeAssignmentValues = Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION );
            List<String> beforeAdditionalGroupValues = Arrays.asList( ReportsUIConstants.GROUP );
            List<String> beforeSortValues = Arrays.asList( ReportsUIConstants.GAIN );
            List<String> beforeDisplayValues = Arrays.asList( ReportsUIConstants.STUDENT_NAME );

            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( ReportsUIConstants.SUBJECT_LABEL, beforeSubjectValues );
            beforeSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, beforeAssignmentValues );
            beforeSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, beforeAdditionalGroupValues );
            beforeSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, beforeSortValues );
            beforeSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, beforeDisplayValues );

            Log.message( "beforeSavedFilterValues: " + beforeSavedFilterValues );

            String savedReport = "SavedReport" + System.nanoTime();
            SaveReportFilterPopup saveReportOptionPopup = cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( savedReport );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( savedReport ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
            Log.testCaseInfo( "Verify that after save report options, all the values saved before are getting retained" );
            List<String> subjectValues = Arrays.asList( ReportsUIConstants.READING );
            List<String> assignmentValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL ) );
            List<String> adtlGroupingValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ) );
            List<String> sortValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SORT_LABEL ) );
            List<String> displayValues = Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DISPLAY_LABEL ) );

            HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
            afterSavedFilterValues.put( ReportsUIConstants.SUBJECT_LABEL, subjectValues );
            afterSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, assignmentValues );
            afterSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, adtlGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, sortValues );
            afterSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, displayValues );

            Log.message( "afterSavedFilterValues: " + afterSavedFilterValues );

            Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                    "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "SMK-66744", "Teacher Dashboard", "Reports", "Cumulative Performance Report" }, priority = 1 )
    public void tcCPRSaveReportOptions03( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( username1, password );
            CumulativePerformancePage cumulativePerformancePage = areaForGrowthPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.chooseSubject( driver, "Reading" );

            // Verify Reading Subject is selected
            Log.assertThat( cumulativePerformancePage.chooseSubject( driver, "Reading" ), "The 'Reading' subject is selected", "The 'Reading' subject is not selected" );
            SMUtils.logDescriptionTC( "Verify the Existing custom report configuration dropdown if the user does not have already saved options" );

            cumulativePerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup( driver );

            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not  disabled if the user does not have already saved options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}