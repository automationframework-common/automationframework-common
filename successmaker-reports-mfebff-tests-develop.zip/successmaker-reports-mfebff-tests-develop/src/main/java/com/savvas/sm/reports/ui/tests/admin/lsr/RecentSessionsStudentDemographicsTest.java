package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class RecentSessionsStudentDemographicsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the Student demographics availbility & Disability status dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics001: Verify the Student demographics availbility & Disability status dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify Student demographics Option label is displayed in the Recent Sessions Page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getStudentDemographicsLabel().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly",
                    "Student demographics label not displayed properly. Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -" + recentSessionPage.reportFilterComponent.getStudentDemographicsLabel() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click accordion button is displayed in left side of Student demographics" );
            //Expand student demographics 
            Log.assertThat( recentSessionPage.reportFilterComponent.expandStudentDemographics(), "User able to expande the studen demographics accordion", "Issue in expand the Student demographics accordion!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Disability status option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly", "Issue in display th Disability status dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Disability status dropdown and check dropdown option are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Disability status dropdown" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).containsAll( ReportsUIConstants.DISABILITY_STATUS_OPTIONS ),
                    "ALL options are displayed properly in disability status dropdown", "Issue in displaying the options in disability status dropdown! Expected - " + ReportsUIConstants.DISABILITY_STATUS_OPTIONS + " Actual - "
                            + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
            Log.testCaseResult();

            //Selecting single option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the Disability status available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Disability status available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in disability status dropdown!", "Issue in deselecting all the option in disability status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the Disability status available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            Log.assertThat(
                    recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the  Student demographics availbility for sub-district admin and  Gender dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics002: Verify the  Student demographics availbility for sub-district admin and  Gender dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify the  Student demographics Option is displayed for Sub-district admin" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getStudentDemographicsLabel().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly for sub-district admin",
                    "Student demographics label not displayed properly for sub-district admin Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -" + recentSessionPage.reportFilterComponent.getStudentDemographicsLabel() );
            Log.testCaseResult();

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify the Gender option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GENDER ), "Gender dropdown label is displayed properly", "Issue in display the gender dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Gender dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in gender drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).containsAll( ReportsUIConstants.GENDER_OPTIONS ), "ALL options are displayed properly in Gender dropdown",
                    "Issue in displaying the options in Gender dropdown! Expected - " + ReportsUIConstants.GENDER_OPTIONS + " Actual - " + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ) );
            Log.testCaseResult();

            //Selecting single option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the Gender available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.GENDER );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) ), "User able to select the single option in Gender dropdown",
                    "Issue in selecting the option in Gender dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the gender available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ), "User able to deselect all the option in Gender dropdown!",
                    "Issue in deselecting all the option in Gender dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the Gender available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ), ReportsUIConstants.GENDER_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.GENDER );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ), ReportsUIConstants.GENDER_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in gender dropdown", "Issue in selecting the option in gender dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the  Student demographics availbility for sub-district admin and Race dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics003: Verify the  Student demographics availbility for sub-district admin and Race dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "Verify the  Student demographics Option is displayed for school admin" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getStudentDemographicsLabel().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly for school admin",
                    "Student demographics label not displayed properly for school admin. Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -" + recentSessionPage.reportFilterComponent.getStudentDemographicsLabel() );
            Log.testCaseResult();

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify Race option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display the race dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Race dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Race drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).containsAll( ReportsUIConstants.RACE_OPTIONS ), "ALL options are displayed properly in race dropdown",
                    "Issue in displaying the options in race dropdown! Expected - " + ReportsUIConstants.RACE_OPTIONS + " Actual - " + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
            Log.testCaseResult();

            //Selecting single option in Race dropdown
            SMUtils.logDescriptionTC( "Verify the Race available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) ), "User able to select the single option in race dropdown",
                    "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Race available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ), "User able to deselect all the option in Race dropdown!",
                    "Issue in deselecting all the option in Race dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in race dropdown
            SMUtils.logDescriptionTC( "Verify the Race available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in race dropdown", "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SocioEconomic Status dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics004: Verify the SocioEconomic Status dropdown<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify SocioEconomic Status option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly", "Issue in display the SocioEconomic Status dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the SocioEconomic Status dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Socioeconomic Status drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS ),
                    "ALL options are displayed properly in SocioEconomic Status dropdown", "Issue in displaying the options in SocioEconomic Status dropdown! Expected - " + ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS + " Actual - "
                            + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );
            Log.testCaseResult();

            //Selecting single option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in special services dropdown!", "Issue in deselecting all the option in Special services dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            Log.assertThat(
                    recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the English langauge proficiency dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics005: Verify the English langauge proficiency Status  dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify English langauge proficiency Status option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English langauge proficiency Status  dropdown label is displayed properly",
                    "Issue in display the English langauge proficiency Status  dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the English langauge proficiency dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in English langauge proficiency drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS ),
                    "ALL options are displayed properly in English langauge proficiency Status dropdown", "Issue in displaying the options in English langauge proficiency Status dropdown! Expected - "
                            + ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS + " Actual - " + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
            Log.testCaseResult();

            //Selecting single option in English langauge proficiency Status dropdown
            SMUtils.logDescriptionTC( "Verify the English langauge proficiency available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in English langauge proficiency Status dropdown", "Issue in selecting the option in English langauge proficiency Status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the English langauge proficiency available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in English langauge proficiency status dropdown!", "Issue in deselecting all the option in English langauge proficiency status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in race dropdown
            SMUtils.logDescriptionTC( "Verify the English langauge proficiency available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.assertThat(
                    recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals(
                            Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in English langauge proficiency Status dropdown", "Issue in selecting the option in English langauge proficiency Status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the migrant status dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics006: Verify the  migrant status dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify migrant Status option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), " Migrant status dropdown label is displayed properly", "Issue in display the  migrant status dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the migrant Status dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Migrant drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).containsAll( ReportsUIConstants.MIGRANT_STATUS_OPTIONS ),
                    "ALL options are displayed properly in  migrant status dropdown", "Issue in displaying the options in  migrant status dropdown! Expected - " + ReportsUIConstants.MIGRANT_STATUS_OPTIONS + " Actual - "
                            + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
            Log.testCaseResult();

            //Selecting single option in  migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the Migrant available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in  migrant status dropdown", "Issue in selecting the option in  migrant status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Migrant available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in migrant status dropdown!", "Issue in deselecting all the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in  migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the Migrant available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in  migrant status dropdown", "Issue in selecting the option in  migrant status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Ethnicity dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics007: Verify the Ethnicity dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify Ethnicity option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Ethnicity dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Ethnicity drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).containsAll( ReportsUIConstants.ETHNICITY_OPTIONS ), "ALL options are displayed properly in Ethnicity dropdown",
                    "Issue in displaying the options in Ethnicity dropdown! Expected - " + ReportsUIConstants.ETHNICITY_OPTIONS + " Actual - " + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
            Log.testCaseResult();

            //Selecting single option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the Ethnicity available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Ethnicity available drop down option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ), "User able to deselect all the option in Ethnicity dropdown!",
                    "Issue in deselecting all the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the Ethnicity available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Special Services dropdown", groups = {"Smoke", "SMK-57814", "recentSessionReports", "studentDemographics" }, priority = 1 )
    public void tcRecentSessionStudentDemographics008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSessionStudentDemographics008: Verify the Special Services dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            //Expand student demographics 
            recentSessionPage.reportFilterComponent.expandStudentDemographics();
            SMUtils.logDescriptionTC( "Verify Special Services option name is displayed in the Student demographics" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special Services dropdown label is displayed properly", "Issue in display the Special Services dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Special Services dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Special Services drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS ),
                    "ALL options are displayed properly in Special Services dropdown", "Issue in displaying the options in Special Services dropdown! Expected - " + ReportsUIConstants.SPECIAL_SERVICES_OPTIONS + " Actual - "
                            + recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );
            Log.testCaseResult();

            //Selecting single option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the Special Services dropdown option is expandable when it is clicked and the select the single field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equals( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Special Services available drop down option when it is expandable and the deselect all the field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in Special service dropdown!", "Issue in deselecting all the option in Special service dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the Special Services available drop down option is expandable when it is clicked and the select the multiple field" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );
            recentSessionPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            Log.assertThat(
                    recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equals( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
