package com.savvas.sm.reports.reportdatasetup;

import com.savvas.sm.data.ReportDataCollection;

public class ReportData extends ReportDataCollection {}