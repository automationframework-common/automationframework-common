package com.savvas.sm.reports.ui.tests.admin.spr;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.admin.ui.pages.LastSessionReportPage;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.LSAdminReportDBQuery;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.SPReport;
import com.savvas.sm.reports.bff.admin.tests.LSRReportAdminGraphQLTest;
import com.savvas.sm.reports.bff.admin.tests.SPReportAdminGrphQLTest;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicValues;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

import io.restassured.response.Response;

public class SPRAdminIntegrateBFFWithMFETest extends EnvProperties {

    private String browser;
    public SPReportAdminGrphQLTest SPRObject = new SPReportAdminGrphQLTest();
    CourseAPI coursesMethod = new CourseAPI();
    RBSUtils rbsUtils = new RBSUtils();
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolUnderSubDistrict;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String orgNameUnderSchool;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String firstTeacherName;
    String secondTeacherName;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    //    String secondStudentId;
    String firstStudentId;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String firstTeacherOrgID;
    String orgName;

    @BeforeClass(alwaysRun = true)
    public void initTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        // Teacher UserNames
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        //Selected School Name
        firstTeacherOrgID =ReportData.orgId;

        //Teacher User ID's
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );

        //Teacher Names (FirstName LastName)
        firstTeacherName = SMUtils.getKeyValueFromResponse(  rbsUtils.getUser( firstTeacherId ), "firstAndLastName" );
        secondTeacherName = SMUtils.getKeyValueFromResponse(  rbsUtils.getUser( secondTeacherId ), "firstAndLastName" );
        Log.message( "firstTeacherName: " + firstTeacherName + " secondTeacherName: " + secondTeacherName );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        //Filter By Values - OrgId
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );
        schoolUnderSubDistrict = SMUtils.getKeyValueFromResponse( rbsUtils.getOrg( subDistId ), "displayName" );
        Log.message( "schoolUnderSubDistrict: " + schoolUnderSubDistrict );

        //School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );
        orgNameUnderSchool = SMUtils.getKeyValueFromResponse(rbsUtils.getOrg(adminSchoolId), "name") ;


        //Assignment Details
        Map<String, Map<String, String>> mathAssignDetails = ReportData.defaultMathAssignmentDetails;
        Map<String, Map<String, String>> readAssignDetails = ReportData.defaultReadingAssignmentDetails;
        Map<String, Map<String, String>> mathSetOnAssignDetails = ReportData.mathSettingIPMONAssignmentDetails;
        Map<String, Map<String, String>> readSetOnAssignDetails = ReportData.readingSettingIPMONAssignmentDetails;

        Log.message( "mathAssignDetails: "  + mathAssignDetails);
        Log.message( "readAssignDetails: "  + readAssignDetails);
        Log.message( "mathSetOnAssignDetails: "  + mathSetOnAssignDetails);
        Log.message( "readSetOnAssignDetails: "  + readSetOnAssignDetails);

    }


    @Test(description = " Verify and compare report output with BFF response for Distrcit Admin user with default options(Math)", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, List<String>> outputValues = new HashMap<>();
        HashMap<String, String> filterByValues = new HashMap<>();
        String courseList = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE001: Verify and compare report output with BFF response for Distrcit Admin user <small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            Log.message( "CourseList: " + courseList );

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().toString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage(); 
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
                SPReport.reportFilterComponent.clickRunReportButton();

                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(  ReportTypes.STUDENT_PERFORMANCE  ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                SMUtils.waitForSpinnertoDisapper(driver, 20);

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test(description = " Verify and compare report output with BFF response for Distrcit Admin user with default options(Reading)", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, List<String>> outputValues = new HashMap<>();
        HashMap<String, String> filterByValues = new HashMap<>();
        String courseList = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = false;
        List<String> courses;
        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE002: Verify and compare report output with BFF response for Distrcit Admin user(Reading) <small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.READING, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getReadingDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.READING));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
                SPReport.reportFilterComponent.clickRunReportButton();

                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper( driver, 10 );

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUIReading( driver ));

                //Verify and Compare the both values
                Log.assertThat( spMethod.validateBFFResponseWithMFE( dataFromBFF, outputValues ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = " Verify and compare report output with BFF response for Sub-District Admin user with default options", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String courseList = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE003: Verify and compare report output with BFF response for Sub-District Admin user <small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, schoolUnderSubDistrictId, studentUserID, Constants.MATH, filterByValues );
            String bffResponse = response.getBody().asString() ;
            Log.message( "BFFResponse: " + bffResponse );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(subDistAdminUserName, password);
                Log.message( "Login with subDistAdminUserName: " + subDistAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolUnderSubDistrict);
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
                SPReport.reportFilterComponent.clickRunReportButton();

                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = " Verify and compare report output with BFF response for School Admin user with default options", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        Map<String,List< String>> outputValues =  new HashMap<>();
        String courseList = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE004: Verify and compare report output with BFF response for School Admin user <small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(schoolAdminUserName, password);
                Log.message( "Login with schoolAdminUserName: " + schoolAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
                SPReport.reportFilterComponent.clickRunReportButton();

                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = " Verify and compare report output with BFF response for District Admin user with All options", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String courseList = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE005: Verify and compare report output with BFF response for District Admin user with All options <small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            Log.message("CourseList: " + courseList);
            filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
            filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02" );
            filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
            filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
            filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
            filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
            filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
            filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
            filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            String bffResponse = response.getBody().asString();
            Log.message( "BFFResponse: " + bffResponse );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );


            if ( !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );

                SPReport.clickStudentDemographics();
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,  ReportsUIConstants.DISABILITY_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE,  ReportsUIConstants.RACE_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,  ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,  ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,  ReportsUIConstants.MIGRANT_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY,  ReportsUIConstants.ETHNICITY_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS );

                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( firstTeacherName ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.GRADE_OPTION_SEC ) );

                SPReport.reportFilterComponent.clickRunReportButton();
                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                //                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                //                        "MFE Values are not matched with BFF value, Test Failed:(" );

                Log.assertThat( dataFromBFF.entrySet().stream().anyMatch( entry -> outputValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = "Verify and compare report output with BFF response for District Admin user For Math-Custom By Settings", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String assignmentTitle = null;
        String courseList = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE006: Verify and compare report output with BFF response for District Admin user For Math-Custom By Settings <small><b><i>[" + browser + "]</b></i></small>");
        try {
            courseList = ReportData.mathSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.mathSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            assignmentTitle = ReportData.mathSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "courseDetail,name" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"courseDetail,name" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "assignmentTitle: " + assignmentTitle );

            String assignmentName = spMethod.getAssignmentNameWithTeacherName( assignmentTitle );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );


            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                Log.message( "courses: " + courses );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( assignmentName ) );

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
                SPReport.reportFilterComponent.clickRunReportButton();
                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = "Verify and compare report output with BFF response for District Admin user For Read-Custom By Settings", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        String courseList = null;
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String assignmentTitle = null;
        boolean isSkillStandardCourse = false;
        boolean isMath = false;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE007: Verify and compare report output with BFF response for District Admin user For Read-Custom By Settings<small><b><i>[" + browser + "]</b></i></small>");

        Log.testCaseInfo( "Verify and compare report output with BFF response for District Admin user with single option in Filter By values" );
        try {
            courseList = ReportData.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );
            Log.message("CourseList: " + courseList);

            assignmentTitle = ReportData.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "courseDetail,name" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"courseDetail,name" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "assignmentTitle: " + assignmentTitle );

            String assignmentName = spMethod.getAssignmentNameWithTeacherName( assignmentTitle );

            String studentUserID = ReportData.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.READING, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getReadingDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                Log.message( "courses: " + courses );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(assignmentName));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );

                SPReport.clickStudentDemographics();
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,  Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 3 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE,  Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 8 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,  Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 3 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,  Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 3 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,  Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 3 ) ));
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY,  Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get(3) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,  Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 6 ) ) );

                SPReport.reportFilterComponent.clickRunReportButton();
                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper(driver, 5);

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUIReading( driver ));

                //Verify and Compare the both values
                Log.assertThat( spMethod.validateBFFResponseWithMFE( dataFromBFF, outputValues ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );
            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = "Verify and compare report output with BFF response for District Admin user pass the required filters with migrant status  as 'migrant' (single option)", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        String courseList = null;
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String assignmentTitle = null;
        boolean isSkillStandardCourse = true;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE008: Verify and compare report output with BFF response for District Admin user pass the required filters with migrant status  as 'migrant' (single option)" +"<small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.get( 0 ) );
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );

                SPReport.clickStudentDemographics();
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,  ReportsUIConstants.DISABILITY_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE,  ReportsUIConstants.RACE_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,  ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,  ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,  Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY,  ReportsUIConstants.ETHNICITY_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS );
                SPReport.reportFilterComponent.clickRunReportButton();
                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper(driver, 5);

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



    @Test(description = "Verify and compare report output with BFF response for District Admin while pass the required filters with socioeconomic status  as 'Economically Disadvantaged'(Single option)", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        String courseList = null;
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String assignmentTitle = null;
        boolean isSkillStandardCourse = true;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("tcSPRIntegrateBFFWithMFE009: Verify and compare report output with BFF response for District Admin while pass the required filters with socioeconomic status  as 'Economically Disadvantaged'(Single option)" +"<small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.get( 0 ) );
            filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
            filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if (  !jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SMUtils.nap( 10 );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );

                SPReport.clickStudentDemographics();
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,  ReportsUIConstants.DISABILITY_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE,  ReportsUIConstants.RACE_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,  Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 0 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,  ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,  ReportsUIConstants.MIGRANT_STATUS_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY,  ReportsUIConstants.ETHNICITY_OPTIONS );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,  ReportsUIConstants.SPECIAL_SERVICES_OPTIONS );
                SPReport.reportFilterComponent.clickRunReportButton();

                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper(driver, 5);

                while ( !outputPage.getStudentUserName().equalsIgnoreCase( studentUserName ) ) {
                    outputPage.clickNextBtn();

                    Log.message( "Student username is not matched! Expected-> " + studentUserName +" , Clicking Next Button!!" );
                }
                outputValues.putAll(spMethod.getDataFromOutputUI( driver ));

                //Verify and Compare the both values
                Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                        "MFE Values are not matched with BFF value, Test Failed:(" );

            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test(description = "Verify and compare report output with BFF response for District Admin for Zero state", groups = {
            "SMK-66777", "AdminDashboard", "Reports", "Student Performance","Smoke" }, priority = 1)
    public void tcSPRIntegrateBFFWithMFE0010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);
        StudentPerformancePage spMethod = new StudentPerformancePage(driver);
        HashMap<String, String> filterByValues = new HashMap<>();
        String courseList = null;
        HashMap<String, List<String>> outputValues = new HashMap<>();
        String assignmentTitle = null;
        boolean isSkillStandardCourse = true;
        boolean isMath = true;
        List<String> courses;

        Log.testCaseInfo("Verify and compare report output with BFF response for District Admin for Zero state" +"<small><b><i>[" + browser + "]</b></i></small>");

        try {
            courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            filterByValues.put( "{courseList}", courseList.toString() );
            filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.get( 2 ) ); //ASIAN
            filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.get( 0 ) ); //HISPANIC_OR_LATINO
            filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.get( 2 ) ); //IEP
            filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.get( 0 ) ); //YES
            filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.get( 0 ) ); //ECONOMICALLY_DISADVANTAGED
            filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.get( 1 ) ); //ENGLISH_LANGUAGE_LEARNER
            filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.get( 1 ) );//NON_MIGRANT
            Log.message("CourseList: " + courseList);

            String studentUserID = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse(  assignment, "studentDetail,studentId" ) )&& ( SMUtils.getKeyValueFromResponse(  assignment, "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail,"studentDetail,studentId" );
            } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
            Log.message( "studentUserID: " + studentUserID );

            String studentUserName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( studentUserID ), "userName" );
            Log.message( "studentUserName: " + studentUserName );

            response = SPRObject.getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, studentUserID, Constants.MATH, filterByValues );
            Log.message( "BFFResponse: " + response.getBody().asString() );

            String jsonObj = SPRObject.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" );

            if ( jsonObj.toString().equals("[]") ) {
                Map<String, List<String>> dataFromBFF = spMethod.getDataFromResponse(  response.getBody().asString() );
                Log.message( "dataFromBFF: " + dataFromBFF );

                AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
                AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports(distAdminUserName, password);
                Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
                StudentPerformancePage SPReport = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
                SMUtils.waitForSpinnertoDisapper( driver ,10 );

                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH);
                courses = SPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL);
                SMUtils.nap( 10 );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH));

                SPReport.reportFilterComponent.expandOptionalFilter();
                SPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );

                SPReport.clickStudentDemographics();
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,  Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE,  Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 3 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,  Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,  Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS,  Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY,  Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
                SPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,  Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 3 ) ) );
                SPReport.reportFilterComponent.clickRunReportButton();
                
                ReportOutputComponent outputPage =  new ReportOutputComponent( driver );
                SMUtils.switchWindow(driver);
                SMUtils.waitForPageLoad(driver);
                SMUtils.waitForSpinnertoDisapper(driver , 10);
                SMUtils.nap( 20 );

                Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.STUDENT_PERFORMANCE ),"Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
                SMUtils.waitForSpinnertoDisapper(driver, 5);

                Log.assertThat( SPReport.verifyZeroState(driver), "Test Passed:)", "Test Failed:(");


            }else {
                Log.message( "No Report data found for the given inputs!!" );
            }

            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
