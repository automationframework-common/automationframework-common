package com.savvas.sm.reports.api.report;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.restassured.response.Response;

public class PSReportTeacherGraphQLTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String teacherDetails;
    private String selectedSchoolId;
    private String studentId;
    private String studentId1;
    String organizationId = null;
    String teacherId = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchoolStudentDetails = null;
    private String flexSchoolStudentDetailsSecond = null;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    Response response;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        flexSchoolStudentDetails = RBSDataSetup.getMyStudent( school, username );
        flexSchoolStudentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        organizationId = RBSDataSetup.organizationIDs.get( school );
        studentId = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetails, "userId" );
        studentId1 = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetailsSecond, "userId" );

    }

    @Test ( dataProvider = "getData", groups = { "SMK-55495 Prescriptive Scheduling Report: Teacher - Create GraphQL API", "API", "SmokeTest" }, priority = 1 )
    public void testPSRepostAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        Date date = new Date();
        String targetDate = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );

        String payload = getPayload();
        String query;
        Response response = null;
        String responseStatusCode = "";
        switch ( scenarioType ) {
            case "VALID_SCENARIO":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, ReportAPIConstants.BACK_SLASH + targetDate + ReportAPIConstants.BACK_SLASH );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                System.out.println( payload );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_TOKEN":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_ORG_ID_HEADER":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_USER_ID_HEADER":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_ORG_ID":
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_USER_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SUBJECT_MATH":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.SUBJECT, "1" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SUBJECT_READING":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.SUBJECT, "2" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_TARGET_DATE":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "VALID_GROUP_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.GROUP_ID, "\\[\"2060cbd8f4c546c9837c83db7068beec\"]\\" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_GROUP_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.GROUP_ID, ReportAPIConstants.INVALID_GROUP_IDS );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "VALID_LIMIT":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.LIMIT, "10" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_LIMIT":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.LIMIT, ReportAPIConstants.INVALID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_LIMIT_ZERO":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.LIMIT, "0" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
            case "VALID_OFFSET":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.OFFSET, "0" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_OFFSET":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.OFFSET, ReportAPIConstants.INVALID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "INVALID_IS_GROUP_SELECTED":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, ReportAPIConstants.INVALID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "VALID_IS_GROUP_SELECTED":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.FALSE.toString() );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADEK":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "K", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE1":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "1", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE2":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "2", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE3":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "3", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE4":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "4", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE5":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "5", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE6":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "6", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE7":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "7", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE8":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "8", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE9":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "9", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE10":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "10", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE11":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "11", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GRADE12":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + organizationId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
                queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
                queryItem.put( ReportAPIConstants.GRADE + "12", "8.95" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, organizationId );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_SCENARIO" },
                { "TC002", "401", "Verify the status code 401 for response body for not providing token in header", "WITHOUT_TOKEN" },
                { "TC003", "400", "Verify the status code 400 for response body for not providing orgId in request body", "WITHOUT_ORG_ID" },
                { "TC004", "400", "Verify the status code 400 for response body for not providing userId in request body", "WITHOUT_USER_ID" },
                { "TC005", "UNAUTHENTICATED", "Verify the status code 400 for response body for not providing orgId in header", "WITHOUT_ORG_ID_HEADER" },
                { "TC006", "UNAUTHENTICATED", "Verify the status code 400 for response body for not providing userId in header", "WITHOUT_USER_ID_HEADER" },
                { "TC007", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_MATH" },
                { "TC008", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_READING" },
                { "TC009", "400", "Verify the status code 400 for response body for not providing target date in request body", "WITHOUT_TARGET_DATE" },
                { "TC010", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and  valid groupIds  in request body", "VALID_GROUP_ID" },
                { "TC011", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and  invalid groupIds  in request body", "INVALID_GROUP_ID" },
                { "TC012", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and limit in request body", "VALID_LIMIT" },
                { "TC013", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald limit in request body", "INVALID_LIMIT" },
                { "TC014", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald limit (0) in request body", "INVALID_LIMIT_ZERO" },
                { "TC015", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and offset in request body", "VALID_OFFSET" },
                { "TC016", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald offset in request body", "INVALID_OFFSET" },
                { "TC017", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and isGroupSelected in request body", "VALID_IS_GROUP_SELECTED" },
                { "TC018", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invalid isGroupSelected  in request body", "INVALID_IS_GROUP_SELECTED" },
                { "TC019", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid gradek in request body", "GRADEK" },
                { "TC020", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade1 in request body", "GRADE1" },
                { "TC021", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade2 in request body", "GRADE2" },
                { "TC022", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade3 in request body", "GRADE3" },
                { "TC023", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade4 in request body", "GRADE4" },
                { "TC024", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade5 in request body", "GRADE5" },
                { "TC025", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade6 in request body", "GRADE6" },
                { "TC026", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade7 in request body", "GRADE7" },
                { "TC027", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade8 in request body", "GRADE8" },
                { "TC028", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade9 in request body", "GRADE9" },
                { "TC029", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade10 in request body", "GRADE10" },
                { "TC030", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade11 in request body", "GRADE11" },
                { "TC031", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and valid grade11 in request body", "GRADE12" },

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "PSReportTeacherRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }
}