package com.savvas.sm.reports.ui.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.StudentIDWarningPopupPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

/**
 * WarningModelReportsTest class is executed for verifying warning popup model
 * with empty student ID
 * 
 * @author athithya.melavasal
 *
 */

public class StudentIDWarningPopupTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String teacherUsername;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify All Reports:Admin - Input UI:Warning modal for students with empty student ID ", groups = { "SMK-65093", "AdminReports", "Warning modal for students with empty student ID" }, priority = 1 )
    public void tcStudentIdWarningPopup001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.AREAS_FOR_GROWTH ), "The Area for growth is displayed in Report MFE sub-navigation",
                    "The Area for growth is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Admin - Area for Growth report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            SMUtils.waitForSpinnertoDisapper( driver );
            dashBoardPage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            StudentIDWarningPopupPage popup = new StudentIDWarningPopupPage( driver );
            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Admin - Area for Growth report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Admin -Area for Growth report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //cumulative performance report
            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Admin - cumulative performance report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.CUMULATIVE_PERFORMANCE ), "The cumulative performance report is displayed in Report MFE sub-navigation",
                    "The cumulative performance report is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            dashBoardPage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );

            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Admin - cumulative performance report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Admin - cumulative performance report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //LAST SESSION
            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Admin - Last Session report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.LAST_SESSION ), "The last session is displayed in Report MFE sub-navigation", "The last Sessions is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            dashBoardPage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );

            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Admin - Last session report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Admin -last session report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //student performance report
            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Admin -student performance report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.STUDENT_PERFORMANCE ), "The student performance report is displayed in Report MFE sub-navigation",
                    "The student performance report is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            dashBoardPage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );

            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Admin -student performance report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Admin -student performance report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //Prescriptive Scheduling
            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Admin -Prescriptive Scheduling report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.PRESCRIPTIVE_SCHEDULING ), "The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
                    "The Prescriptive Scheduling is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            dashBoardPage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in admin  - Prescriptive scheduling report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Admin - Prescriptive scheduling  report filter page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify All Reports: Teacher - Input UI: Warning modal for students with empty student ID", groups = { "SMK-65093", "TeacherReports", "Warning modal for students with empty student ID" }, priority = 1 )
    public void tcStudentIdWarningPopup002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher( teacherUsername, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.AREAS_FOR_GROWTH ), "The area for growth is displayed in Report MFE sub-navigation",
                    "The area for growth is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Teacher - Area for Growth" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );

            StudentIDWarningPopupPage popup = new StudentIDWarningPopupPage( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Teacher - Area for Growth report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Teacher -Area for Growth report filter page" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //cumulative performance
            SMUtils.logDescriptionTC( "Verify the Display Student ID  modal popup in Teacher -cumulative performance report filter page" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.CUMULATIVE_PERFORMANCE ), "The cumulative performance is displayed in Report MFE sub-navigation",
                    "The cumulative performance is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );

            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Teacher - cumulative performance report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Teacher - cumulative performance report filter page" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //LAST SESSION
            SMUtils.logDescriptionTC( "Verify the Display Student ID  modal popup in Teacher - Last Session report filter page" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.LAST_SESSION ), "The Last Sessions is displayed in Report MFE sub-navigation", "The Last Sessions is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Teacher - Last Session report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID  modal popup in Teacher - Last Session report filter page" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //student performance report
            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Teacher - Student performance report filter page" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.STUDENT_PERFORMANCE ), "The student performance is displayed in Report MFE sub-navigation",
                    "The student performance is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID  modal popup in Teacher - Student performance report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Teacher -Student performance  report filter page" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

            //Prescriptive Scheduling
            SMUtils.logDescriptionTC( "Verify the Display Student ID modal popup in Teacher - Prescriptive scheduling report filter page" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.PRESCRIPTIVE_SCHEDULING ), "The Prescriptive Scheduling is displayed in Report MFE sub-navigation",
                    "The Prescriptive Scheduling is displayed in Report MFE sub-navigation" );
            dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();

            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            Log.assertThat( popup.verifywarningmodel().equals( ReportsUIConstants.WARNING_MODEL_POPUP ), "display student ID is displayed", "display student ID is not displayed" );
            Log.assertThat( popup.verifydisplaystudenttext().equals( ReportsUIConstants.TEXT_STUDENT_ID ), "text is printed", "text is not printed" );
            Log.message( popup.verifydisplaystudenttext() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button in Display Student ID modal popup in Teacher  - Prescriptive scheduling report filter page" );
            popup.clickCloseButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon in Display Student ID modal popup in Teacher - Prescriptive scheduling  report filter page" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );
            popup.clickIconbutton();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
