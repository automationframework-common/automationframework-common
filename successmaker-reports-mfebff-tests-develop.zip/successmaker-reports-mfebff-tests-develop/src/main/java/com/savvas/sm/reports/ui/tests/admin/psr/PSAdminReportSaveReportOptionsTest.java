package com.savvas.sm.reports.ui.tests.admin.psr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class PSAdminReportSaveReportOptionsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String subDistrictUsername;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> orgNames = new ArrayList<String>();
    private String org;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        String subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        username = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
        subDistrictUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    }

    @Test ( dataProvider = "AdminData", groups = { "SMK-58006", "prescriptiveSchedulingReports", "savedReport" }, priority = 1 )
    public void tcPrescriptiveSchedulingSavedReport001( String description, String username ) throws Exception {
        Log.testCaseInfo( description );
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( username );
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeader(), "Prescriptive Scheduling Page is displayed", "Prescriptive Scheduling Page is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify that admin can be able to see Saved Report Options header above the Dropdown." );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.getSavedReportOptionLabel().equalsIgnoreCase( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "Saved Report Option label displayed properly",
                    "Saved Report Option label not displayed properly. Expected - " + ReportsUIConstants.SAVED_REPORT_OPTIONS + " Actual -" + prescriptiveSchedulingPage.reportFilterComponent.getSavedReportOptionLabel() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'Save Report Options' button is displaying in the bottom of the Prescriptive Scheduling Report screen" );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in PS report",
                    "The save report option is not displayed in PS report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'Save Report Options' button in disable mode" );
            Log.assertThat( !prescriptiveSchedulingPage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();
            //Selecting organization from Organization dropdown
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            // Selecting All Options from Courses dropdown
            courses = prescriptiveSchedulingPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            //Collapse Courses dropdown
            prescriptiveSchedulingPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            SMUtils.logDescriptionTC( "Verify if the Save report is enable by setting grade level atleast any one of the Grade" );
            SMUtils.logDescriptionTC( "Verify if the Save report is disabled for not setting any Grade Target Level in PSR" );
            Log.assertThat( !prescriptiveSchedulingPage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report is disabled for not setting any Grade Target Level", "Save report is not disabled for not setting any Grade Target Level" );
            prescriptiveSchedulingPage.fillTargetLevels( "5" );
            SMUtils.logDescriptionTC( "Verify 'Save Report Options' button in active mode" );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is active", "Save report option button is not active" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can click the 'Save Report Option' button in PS report page" );
            SMUtils.logDescriptionTC( "Verify all available fields in 'Save Report Option Popup." );
            SaveReportFilterPopup saveReportOptionPopup = prescriptiveSchedulingPage.reportFilterComponent.clickSaveReportOptionButton();
            SMUtils.logDescriptionTC( "Verify 'Save Report Options' popup is displaying" );
            SMUtils.logDescriptionTC( "Verify 'Save Report Options' popup is displaying all available fields" );
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "Existing Report configuration label is displayed properly",
                    "Existing Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            SMUtils.logDescriptionTC( "Verify Existing custom report configuration dropdown, if the user does not have already saved options" );
            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled", "Existing custom report configuration dropdown is not disabled" );
            Log.testCaseResult();

            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with empty Name in 'Save Report Option' Popup" );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to cancel the in 'Save Report Option ' Popup on PS report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with new name." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = prescriptiveSchedulingPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            SMUtils.logDescriptionTC( " Verify all the previously saved Reports are Listed properly in the dropdown." );
            prescriptiveSchedulingPage.reportFilterComponent.expandSingleSelectOrgDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            prescriptiveSchedulingPage.reportFilterComponent.collapseSingleSelectOrgDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();

            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            // Selecting All Options from Courses dropdown
            courses = prescriptiveSchedulingPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            //Collapse Courses dropdown
            prescriptiveSchedulingPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            prescriptiveSchedulingPage.fillTargetLevels( "5" );
            saveReportOptionPopup = prescriptiveSchedulingPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getSaveErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            SMUtils.logDescriptionTC( "Verify User can able to click the cancel in save report option" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();
            saveReportOptionPopup = prescriptiveSchedulingPage.reportFilterComponent.clickSaveReportOptionButton();
            SMUtils.logDescriptionTC( "Verify User can able to click the close button(X icon) in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            SMUtils.logDescriptionTC( "Verify user can able to select one option in Existing custom report configuration dropdown" );
            saveReportOptionPopup = prescriptiveSchedulingPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "AdminData" )
    public Object[][] getAdminData() {

        Object[][] inputData = { { "Verify the District admin can be able to see the Saved Report Options.", RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ) },
                { "Verify the School admin can be able to see the Saved Report Options.", RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ) }, };

        return inputData;
    }

}
