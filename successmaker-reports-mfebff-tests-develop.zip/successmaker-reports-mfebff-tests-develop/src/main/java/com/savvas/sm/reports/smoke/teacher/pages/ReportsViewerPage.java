package com.savvas.sm.reports.smoke.teacher.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;

public class ReportsViewerPage extends LoadableComponent<ReportsViewerPage> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.CSS, using = "h2[class='header']", AI = false )
    public WebElement fldReportHeader;

    @IFindBy ( how = How.XPATH, using = "//span[text()='Report viewer']", AI = false )
    public WebElement txtReportViewer;

    @IFindBy ( how = How.CSS, using = "dl.detail-row.ml-3 dt", AI = false )
    public WebElement txtReportRunLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' School: ']", AI = false )
    public WebElement txtSchoolLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' Teacher: ']", AI = false )
    public WebElement txtTeacherLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' Grade: ']", AI = false )
    public WebElement txtGradeLabel;

    @IFindBy ( how = How.XPATH, using = "//dt[text()=' Group: ']", AI = false )
    public WebElement txtGroupLabel;

    @IFindBy ( how = How.CSS, using = "span.list-head.ml-2", AI = false )
    public WebElement txtSelectedOptionsLabel;

    @IFindBy ( how = How.XPATH, using = "//span[@class='list-head']", AI = false )
    public WebElement txtLegendLabel;

    @IFindBy ( how = How.CSS, using = "cel-modal.export-pdf-modal", AI = false )
    WebElement exportPDF;

    @IFindBy ( how = How.CSS, using = "div.export-data-wrapper p", AI = false )
    WebElement pageText;

    @IFindBy ( how = How.CSS, using = "div.export-data-wrapper cel-radio-button-group", AI = false )
    WebElement allPages;

    @IFindBy ( how = How.CSS, using = "cel-modal-window.hydrated", AI = false )
    WebElement successMessegeText;

    @IFindBy ( how = How.CSS, using = "cel-modal-window[class='hydrated']", AI = false )
    WebElement crossCancel;

    @IFindBy ( how = How.CSS, using = "div.error p.header", AI = false )
    WebElement errorMessage;
    
    @FindBy ( css = "export-pdf-modal cel-modal.export-pdf-modal" )
    WebElement exportPDFs;
    
    @FindBy ( css = "export-data-modal cel-modal.export-data-modal" )
    WebElement exportCSV;

    //**********************Child Element**************************
    public static String childPDF = "cel-button";
    public static String gChildPDF = "cel-icon";
    public static String gGrandChildPDF = "svg";
    public static String pdftext = "span";
    public static String pdfPopUpText = "h1.header";
    public static String gChildAllPage = "cel-radio-button:nth-child(1)";
    public static String gChildCurrentPage = "cel-radio-button:nth-child(2)";
    public static String childAllPages = "label";
    public static String gchildCancel = "cel-button.cancel-button";
    public static String childCancel = "button span";
    public static String gchildOK = "cel-button.ok-button";
    public static String childButton = "button";
    public static String grandChildCrossIcon = "cel-icon-button.close-button";
    public static String gChildCrossIcon = "button.icon-button cel-icon";
    public static String ChildCrossIcon = "div.icon-inner svg.cel-icon";
    public static String childText = "div.context span";
    public static String gChildClose = "div.button-container cel-button";
    public static String pdfPopUpTextSuccess = "h2.header";
    public static String pdfChild = ".close-button.focusable-element.first-interactive.last-interactive.hydrated";

    List<String> listAFGExpectedColumnList = new ArrayList<String>( Arrays.asList( "Strand", "Level", "Skill Description", "", "", "Student", "Date at Risk", "Targeted Lesson" ) );
    List<String> listCPRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Level Data", "Usage", "Instructional Performance", "Mastery", "", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent",
            "Total Sessions\nminimum of 1 assignment", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );
    List<String> listCPRAggregateExpectedColumnList = new ArrayList<String>( Arrays.asList( "School\n(Grade - # of Students)", "Level Data\nMean", "Usage\nMean", "Instructional Performance\nMean", "Mastery\nMean", "", "Current Course Level", "IP Level",
            "Gain", "Time Spent", "Total Sessions\nminimum of 1 assignment", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "Percent Students with AP" ) );
    List<String> listLSRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Level", "Raw Performance", "Usage", "", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Help Used",
            "Time Spent", "Total Sessions\nminimum of 1 assignment", "Session Date" ) );
    List<String> listPSRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Performance Data", "Current Rate", "Current Forecast", "Prescription", "", "Current Course Level", "IP Level", "Time Since IP", "Skills Percent Mastered",
            "Session Length Setting", "Average Min/Day", "Current Learning Rate", "Time", "Level", "Add'l Sessions to Target", "Add'l Time to Target", "Add'l Min/Day to Target" ) );
    List<String> listPSRAggregateExpectedColumnList = new ArrayList<String>(
            Arrays.asList( "Teacher", "Population", "Performance Data", "Current Forecast", "Prescription", "", "Students Included", "Students Not Included", "Current Course Level\nMean", "IP Level\nMean", "Time Since IP\nMean", "Percent Students with AP",
                    "Percent Students at Target Level", "Projected End Level\nMean", "Percent Students to Achieve Target Level", "Average Additional Min/Day to Target\nStudents Projected Below Target" ) );
    List<String> listSEUExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Student Information", "Enrollment & Time Spent", "Usage", "", "Username\n(login)", "Student ID", "SM Math", "Custom Courses", "Total Time Spent",
            "Total Sessions\nminimum of 1 assignment", "Average Session Time", "Last Session Date" ) );

    /**
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */
    public ReportsViewerPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    public ReportsViewerPage() {}

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, fldReportHeader );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, fldReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author sathish.suresh Verify report page
     * @param driver
     */
    public void verifyReportPage( WebDriver driver ) {

        List<String> windowHandles = new ArrayList<String>( driver.getWindowHandles() ); // switch window to report
        driver.switchTo().window( windowHandles.get( windowHandles.size() - 1 ) );
        boolean isDisplayedReportViewerText = SMUtils.waitForElement( driver, txtReportViewer );
        Log.softAssertThat( isDisplayedReportViewerText, "Navigate to 'Report Viewer' page Successfully ", "Failed to navigate 'Report Viewer' page" );
    }

    /**
     * @author sathish.suresh Validate report columns
     * @param driver
     * @throws InterruptedException
     */
    public void validateReportOutputColumns( WebDriver driver ) throws InterruptedException {
        ReportsBrowserActions.waitForSpinnerToBeVisible( driver, 30 );
        ReportsBrowserActions.waitForSpinnerToBeInvisible( driver );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 45 ) );
        wait.until( ExpectedConditions.visibilityOf( driver.findElement( By.xpath( "//thead" ) ) ) );
        List<WebElement> table = driver.findElements( By.xpath( "//thead" ) );
        List<String> columnsList = new ArrayList<String>();
        for ( int i = 1; i <= table.size(); i++ ) {
            //wait.until( ExpectedConditions.visibilityOf( table.get( i ).findElement( By.xpath( "//tbody" ) ) ) );
            List<WebElement> headers = driver.findElements( By.xpath( "//thead[" + i + "] /tr /th" ) );

            for ( WebElement header : headers ) {
                columnsList.add( header.getText() );
            }
        }
        String txtReportName = fldReportHeader.getText();
        switch ( txtReportName ) {
            case "Areas For Growth":
                Log.assertThat( columnsList.equals( listAFGExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Cumulative Performance":
                Log.assertThat( columnsList.equals( listCPRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Cumulative Performance Aggregate":
                Log.assertThat( columnsList.equals( listCPRAggregateExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Last Session":
                Log.assertThat( columnsList.equals( listLSRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Prescriptive Scheduling":
                Log.assertThat( columnsList.equals( listPSRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Prescriptive Scheduling Aggregate":
                Log.assertThat( columnsList.equals( listPSRAggregateExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "Student Performance":
                List<WebElement> lstColumns = driver.findElements( By.cssSelector( "h2.rectangle" ) );
                boolean columnsListstatus = lstColumns.size() == 3;
                Log.assertThat( columnsListstatus, txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            case "System Enrollment and Usage":
                Log.assertThat( columnsList.equals( listSEUExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );
                break;
            default:
                break;
        }
    }

    /**
     * Validate PDF icon
     * 
     * @return
     */
    public Boolean validatePDFIcon() {
     // This wait is required to load the output page
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, childPDF );
        WebElement gchildElement = SMUtils.getWebElement( driver, childElement, gChildPDF );
        WebElement actualElement = SMUtils.getWebElement( driver, gchildElement, gGrandChildPDF );
        Log.message( "Verifying pDF icon displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * Click on PDF
     */
    public void clickOnPDF() {
        SMUtils.nap( 3 ); // This wait is required to load the output page
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, childPDF );
        WebElement gchildElement = SMUtils.getWebElement( driver, childElement, gChildPDF );
        WebElement actualElement = SMUtils.getWebElement( driver, gchildElement, gGrandChildPDF );
        Log.message( "Click on PDF icon" );
        SMUtils.click( driver, actualElement );

    }

    /**
     * Get PDF text
     * 
     * @return
     */
    public String getPDFText() {
     // This wait is required to load the output page
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, childPDF );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, pdftext );
        Log.message( "Getting text for PDF" );
        return actualElement.getText().trim();
    }

    /**
     * Get Text Export PDF Pop up Text
     * 
     * @return
     */
    public String validateExportPDFPopUPText() {

        SMUtils.waitForElement( driver, exportPDF );
        WebElement actualElement = SMUtils.getWebElement( driver, exportPDF, pdfPopUpText );
        Log.message( "Getting text for Export PDF pop Up" );
        return actualElement.getText().trim();
    }

    /**
     * Get the pages PDF text
     * 
     * @return
     */
    public String validatePageText() {

        SMUtils.waitForElement( driver, pageText );
        Log.message( "Getting text fo Pages on export PDF" );
        return pageText.getText().trim();
    }

    /**
     * 
     * @return
     */
    public String validateAllPageText() {

        SMUtils.waitForElement( driver, allPages );
        WebElement childElement = SMUtils.getWebElement( driver, allPages, gChildAllPage );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childAllPages );
        Log.message( "Getting All Pages text" );
        return actualElement.getText().trim();
    }

    /**
     * 
     * @return
     */
    public String validateCurrentPageText() {

        SMUtils.waitForElement( driver, allPages );
        WebElement childElement = SMUtils.getWebElement( driver, allPages, gChildCurrentPage );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childAllPages );
        Log.message( "Getting All Pages text" );
        return actualElement.getText().trim();
    }

    /**
     * 
     * @return
     */
    public String validateCancelButton() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildCancel );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childCancel );
        Log.message( "Getting text for Can cancel button" );
        return actualElement.getText().trim();
    }

    /**
     * 
     * @return
     */
    public String validateOKButton() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildOK );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childCancel );
        Log.message( "Getting text for Can OK button" );
        return actualElement.getText().trim();
    }

    /**
     * Clicked on OK Button
     */
    public void clickOkButton() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildOK );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
        Log.message( "Clicking on OK Button" );
        SMUtils.click( driver, actualElement );

    }

    /**
     * Clicked on Cancel Button
     */
    public void clickCancelButton() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildCancel );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
        Log.message( "Clicking on Cancel Button" );
        SMUtils.click( driver, actualElement );

    }

    /**
     * Clicked on cross icon
     */
    public void clickCrossIcon() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement gchildElement = SMUtils.getWebElement( driver, exportPDF, grandChildCrossIcon );
        WebElement childElement = SMUtils.getWebElement( driver, gchildElement, gChildCrossIcon );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, ChildCrossIcon );
        Log.message( "Clicking on Cross icon" );
        SMUtils.click( driver, actualElement );

    }

    /**
     * Clicked on cross icon
     */
    public void clickCrossButton() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement parentCross = SMUtils.getWebElement( driver, crossCancel, pdfChild );
        Log.message( "Clicking on Cross icon" );
        SMUtils.click( driver, parentCross );

    }

    /**
     * Clicked on cross icon
     */
    public Boolean isCrossButtonDisable() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement parentCross = SMUtils.getWebElement( driver, crossCancel, pdfChild );
        Log.message( "Corss icon is displaying with disbale mode" );
        return parentCross.isEnabled();

    }

    /**
     * Clicked on cross icon
     */
    public Boolean isCrossIconDisplayed() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement gchildElement = SMUtils.getWebElement( driver, exportPDF, grandChildCrossIcon );
        WebElement childElement = SMUtils.getWebElement( driver, gchildElement, gChildCrossIcon );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, ChildCrossIcon );
        Log.message( "Corss icon is displaying" );
        return actualElement.isDisplayed();

    }

    /**
     * Getting text of success Message
     * 
     * @return
     */
    public String getSuccessMessage() {
        SMUtils.waitForElement( driver, successMessegeText );
        WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, childText );
        Log.message( "Getting text of success message" );
        return childElement.getText().trim();
    }

    /**
     * Close button validation
     * 
     * @return
     */
    public Boolean validateCloseButton() {
        SMUtils.waitForElement( driver, successMessegeText );
        WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, gChildClose );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
        Log.message( "Validate close button displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * Close button
     * 
     * @return
     */
    public void clickCloseButton() {
        SMUtils.waitForElement( driver, successMessegeText );
        WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, gChildClose );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
        Log.message( "Clicked on close button" );
        SMUtils.click( driver, actualElement );
    }

    /**
     * Get Text Export PDF Pop up Text after downloading the file
     * 
     * @return
     */
    public String validateExportPDFPopUPTextForSucces() {
        SMUtils.waitForElement( driver, successMessegeText );
        WebElement actualElement = SMUtils.getWebElement( driver, successMessegeText, pdfPopUpTextSuccess );
        Log.message( "Getting text for Export PDF pop Up for sucessfull file" );
        return actualElement.getText().trim();
    }

    /**
     * Close button validation
     * 
     * @return
     */
    public Boolean verifyCloseButtonEnableOrDisable() {
        SMUtils.waitForElement( driver, successMessegeText );
        WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, gChildClose );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
        Log.message( "Validation close button is disable" );
        return actualElement.isEnabled();

    }

    /**
     * Clicked on cross icon
     */
    public Boolean isCrossIconDisable() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement gchildElement = SMUtils.getWebElement( driver, exportPDF, grandChildCrossIcon );
        WebElement childElement = SMUtils.getWebElement( driver, gchildElement, gChildCrossIcon );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, ChildCrossIcon );
        Log.message( "Corss icon is displaying with disbale mode" );
        return actualElement.isEnabled();

    }

    /**
     * To check whether the file is downloaded or not
     * 
     * @param driver
     * @return
     */
    public boolean isPDFFileDownloaded( WebDriver driver ) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int itr = 0;
        do {
            try {
                if ( (boolean) jse.executeScript( "browserstack_executor: {\"action\": \"fileExists\"}" ) ) {
                    Log.message( "PDF file is downloaded successfully!!!" );
                    SMUtils.nap( 10 );
                    return true;
                }
            } catch ( Exception e ) {
                Log.fail( "PDF file is not downloaded..Retrying!!!" );
                SMUtils.nap( 15 );
                itr++;
            }

        } while ( itr < 3 );
        return false;
    }

    /**
     * To get the downloaded file name
     * 
     * @param driver
     * @return
     */
    public String getPdfFileNameFromBS( WebDriver driver ) {
        String fileName = null;
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int itr = 0;
        do {
            try {
                Map<String, String> properties = (Map<String, String>) jse.executeScript( "browserstack_executor: {\"action\": \"getFileProperties\"}" );
                Log.message( properties.toString() );
                fileName = properties.get( "file_name" );
            } catch ( Exception e ) {
                e.getMessage();
                Log.message( "Issue on reading the file. Retrying...." );
                //Waiting for file downloading
                SMUtils.nap( 15 );
            }
            itr++;
        } while ( Objects.isNull( fileName ) && itr < 3 );
        return fileName;
    }

    /**
     * To get the downloaded file name
     * 
     * @param driver
     * @return
     */
    public long getPdfFileSizeFromBS( WebDriver driver ) {
        String fileSizeStr = null;
        long fileSize = 0;
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int itr = 0;
        do {
            try {
                Map<String, Object> properties = (Map<String, Object>) jse.executeScript( "browserstack_executor: {\"action\": \"getFileProperties\"}" );
                Log.message( properties.toString() );
                fileSizeStr = properties.get( "size" ).toString();
                if ( !Objects.isNull( fileSizeStr ) && !fileSizeStr.isEmpty() ) {
                    fileSize = Long.parseLong( fileSizeStr );
                }

            } catch ( Exception e ) {
                e.getMessage();
                Log.message( "Issue on reading the file. Retrying...." );
                //Waiting for file downloading
                SMUtils.nap( 15 );
            }
            itr++;
        } while ( Objects.isNull( fileSizeStr ) && itr < 3 );
        return fileSize;
    }


    /**
     * Get current URL for report viewer page
     * 
     * @return
     */
    public String getReportViewerURL() {

        String URL = driver.getCurrentUrl();
        String actualURL = URL + System.nanoTime();
        Log.message( "Getting URL for report viewr page" );
        return actualURL;
    }

    /**
     * Launching report viewr page again
     */
    public void launchURLWithWrongRequestID() {
        
        SMUtils.nap( 2 );// This wait is required to load report viewr page
        String launchingURL = getReportViewerURL();
        Log.message( "Launching URL again after adding wrong request ID in URL" );
        driver.navigate().to( launchingURL );
        SMUtils.nap( 2 );// This wait is required to load report viewr page

    }

    /**
     * Getting status of PDF button when error message pops up
     * 
     * @return
     */
    public String getPDFButtonDisabled() {

        SMUtils.waitForElement( driver, exportPDFs );
        String attributeValue = exportPDFs.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;
    }
    
  

    /**
     * Clicked on current page radio Button
     */
    public void clickCurrentPageRadioButton() {
        SMUtils.waitForElement( driver, exportPDF );
        WebElement childElement = SMUtils.getWebElement( driver, allPages, gChildCurrentPage );
        WebElement actualElement = SMUtils.getWebElement( driver, childElement, childAllPages );
        Log.message( "Clicking on radio Button" );
        SMUtils.click( driver, actualElement );

    }

}
