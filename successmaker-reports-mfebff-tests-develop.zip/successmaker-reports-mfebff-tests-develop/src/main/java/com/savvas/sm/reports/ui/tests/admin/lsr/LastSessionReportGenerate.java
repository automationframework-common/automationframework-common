package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.LastSessionConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.Groups;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

public class LastSessionReportGenerate extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtAdminUsername;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String districtAdminUserId;
    private String districtId;
    private String teacherId;
    private String teacherUsername;
    private String teacherName;
    private String flexSchool;
    private String flexSchoolId;
    private String groupId;
    private String groupName;
    RBSUtils rbsUtils = new RBSUtils();

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        districtId = configProperty.getProperty( "district_ID" ).trim();
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        flexSchoolId = rbsUtils.getOrganizationIDByName( districtId, flexSchool );

        districtAdminUsername = ReportDataCollection.districtAdmin;
        districtAdminUserId = rbsUtils.getUserIDByUserName( districtAdminUsername );

        teacherUsername = ReportDataCollection.teacherDetails.keySet().toArray()[1].toString();
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );
        teacherName = SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( teacherUsername ), "firstAndLastName" );

        groupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsername ) ).get( 0 ).toString(), "groupId" );
        groupName = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsername ) ).get( 0 ).toString(), "groupName" );

    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation with mandatory field for Math subject." )
    public void tcAdminLastSessionReportGenerate001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate001 - Verify the LSR Report generation with mandatory field for Math subject." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the LSR Report generation with mandatory field." );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with Student ID option in Display" );
        SMUtils.logDescriptionTC( "Verify the available columns in LSR." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getMathGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();
            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getMathResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_NAME, students, true, Constants.MATH );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ), "Students last session data are same as expected for Math subject",
                    "Students last session data are not same as expected for Math subject" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation with mandatory field for Reading subject." )
    public void tcAdminLastSessionReportGenerate002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate002 - Verify the LSR Report generation with mandatory field for Reading subject.." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify 'the LSR Report generation with Student Username option in Display" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.READING );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            // Choosing optional filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getReadingGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();

            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.READING, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getReadingResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_USERNAME, students, true, Constants.READING );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ), "Students last session data are same as expected for Reading subject",
                    "Students last session data are not same as expected for Reading subject" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation by selecting multiple values in Optional Filters." )
    public void tcAdminLastSessionReportGenerate003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate003 - Verify the LSR Report generation by selecting multiple values in Optional Filters." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the LSR Report generation with Student ID option in Display" );
        SMUtils.logDescriptionTC( "Verify report generation with Teacher in optional field." );
        SMUtils.logDescriptionTC( "Verify report generation with Grade in optional field." );
        SMUtils.logDescriptionTC( "Verify report generation with Group in optional field." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Choosing optional filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Groups.GRADE_NOT_SPECIFIED ) );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groupName ) );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAYNAME.get( 1 ) );
            lastSessionsPage.reportFilterComponent.handleStudentPopup();

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getMathGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();
            filterByValues.put( ReportFilters.TEACHER_ID_VALUE, teacherId );
            filterByValues.put( ReportFilters.GROUP_ID_VALUE, groupId );

            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getMathResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_ID, students, true, Constants.MATH );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ),
                    "Students last session data are same as expected when selecting multiple values in Optional Filters", "Students last session data are not same as expected when selecting multiple values in Optional Filters" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation by selecting All values in Optional Filters." )
    public void tcAdminLastSessionReportGenerate004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate004 - Verify the LSR Report generation by selecting All values in Optional Filters." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify report generation with multiple Teacher in optional field." );
        SMUtils.logDescriptionTC( "Verify report generation with multiple Group in optional field." );
        SMUtils.logDescriptionTC( "Verify report generation with multiple Grade in optional field." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Choosing optional filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getMathGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();
            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getMathResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_NAME, students, true, Constants.MATH );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ), "Students last session data are same as expected when selecting All values in Optional Filters",
                    "Students last session data are not same as expected when selecting All values in Optional Filters" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation with Teacher option in Additional grouping." )
    public void tcAdminLastSessionReportGenerate005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate005 - Verify the LSR Report generation with Teacher option in Additional grouping." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the LSR Report generation with Teacher option in Additional grouping." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Choosing optional filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.TEACHER_LABEL );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getMathGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();
            filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getMathResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_NAME, students, true, Constants.MATH );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ), "Students last session data are same as expected when Additional Grouping is selected as Teacher",
                    "Students last session data are not same as expected when Additional Grouping is selected as Teacher" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation with Grade option in Additional grouping." )
    public void tcAdminLastSessionReportGenerate006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate006 - Verify the LSR Report generation with Grade option in Additional grouping." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the LSR Report generation with Grade option in Additional grouping." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Choosing optional filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getMathGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();
            filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getMathResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_NAME, students, true, Constants.MATH );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ),
                    "Students last session data are not same as expected when Additional Grouping is selected as Grade", "Students last session data are not same as expected when Additional Grouping is selected as Grade" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation with Group option in Additional grouping." )
    public void tcAdminLastSessionReportGenerate007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate007 - Verify the LSR Report generation with Group option in Additional grouping." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the LSR Report generation with Group option in Additional grouping." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Choosing optional filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            // Getting data from UI
            Map<String, Map<String, String>> dataFromUI = lastSessionOutpage.getMathGridValues();

            // Getting data from graphQL
            HashMap<String, String> filterByValues = new HashMap<>();
            filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

            String lastSessionReportGrapgql = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
            Log.message( "Graphql response - " + lastSessionReportGrapgql );

            List<String> students = new ArrayList<String>( dataFromUI.keySet() );
            Map<String, Map<String, String>> dataDromResponse = getMathResponseData( lastSessionReportGrapgql, ReportAPIConstants.STUDENT_NAME, students, true, Constants.MATH );

            Log.assertThat( students.stream().allMatch( student -> SMUtils.compareTwoHashMap( dataDromResponse.get( student ), dataFromUI.get( student ) ) ),
                    "Students last session data are not same as expected when Additional Grouping is selected as Group", "Students last session data are not same as expected when Additional Grouping is selected as Group" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report sorting functionality." )
    public void tcAdminLastSessionReportGenerate008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate008 - Verify the LSR Report sorting functionality." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Student' option in Sort'" );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Current Course Level' option in Sort'" );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Exercise correct' option in Sort." );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Exercise Attempted' option in Sort." );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Exercise Percent Correct' option in Sort." );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Help Used' option in Sort" );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Time Spent' option in Sort." );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Total Sessions' option in Sort." );
        SMUtils.logDescriptionTC( "Verify the LSR Report generation with 'Session Date' option in Sort." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Expanding Optional Filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.clickMaskStudentCheckBox();

            IntStream.range( 0, LastSessionConstants.SORT.size() ).forEach( itr -> {
                String columnSorted = LastSessionConstants.SORT.get( itr );
                lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, columnSorted );

                //To click the run report button 
                RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

                Log.assertThat( lastSessionOutpage.sortAndCompareColumnvalues( columnSorted ), columnSorted + " column is sorted in ascending order", columnSorted + " column is not sorted in ascending order" );

                // Navigating to report filter page
                String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
                driver.close();
                driver.switchTo().window( reportFiterPage );
            } );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-57820", "SMK-66768", "Admin LS Generate Report", "smoke_test_case" }, description = "Verify the LSR Report generation when Mask Student Display is selected." )
    public void tcAdminLastSessionReportGenerate009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLastSessionReportGenerate009 - Verify the LSR Report generation when Mask Student Display is selected." + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "Verify the 'Mask Student Display' check box in LSR Page." );
        SMUtils.logDescriptionTC( "Verify the 'Mask Student Display' check box in LSR Page with 'Student Id' option in Display." );
        SMUtils.logDescriptionTC( "Verify the 'Mask Student Display' check box in LSR Page with 'Student Username' option in Display." );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( districtAdminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, flexSchool );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            // Expanding Optional Filters
            lastSessionsPage.reportFilterComponent.expandOptionalFilters();
            lastSessionsPage.clickMaskStudentCheckBox();

            IntStream.rangeClosed( 0, 2 ).forEach( itr -> {

                lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAYNAME.get( itr ) );

                //To click the run report button 
                RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

                List<String> students = lastSessionOutpage.getStudentRowValues();

                Log.assertThat( IntStream.range( 0, students.size() ).allMatch( count -> students.get( count ).equals( "Student " + ( count + 1 ) ) ),
                        "Student counts are displayed when Mask Student Display is selected wiht " + ReportsUIConstants.DISPLAYNAME.get( itr ),
                        "Student counts are not displayed when Mask Student Display is selected with " + ReportsUIConstants.DISPLAYNAME.get( itr ) );

                // Navigating to report filter page
                String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
                driver.close();
                driver.switchTo().window( reportFiterPage );
            } );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    private Map<String, Map<String, String>> getMathResponseData( String response, String studentKey, List<String> studentList, boolean isIPOnCourse, String assignment ) {
        Map<String, Map<String, String>> dataList = new HashMap<>();
        studentList.stream().forEach( student -> {
            Map<String, String> map = getValuesFromLSResponse( response, studentKey, student, assignment, adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS );
            if ( isIPOnCourse ) {
                map.put( "currentCourseLevel", map.get( "currentCourseLevel" ).equals( "-1" ) ? "In IP" : map.get( "currentCourseLevel" ) );
            } else {
                map.put( "currentCourseLevel", "NA" );
            }
            map.put( "timeSpent", convertTimeSpent( map.get( "timeSpent" ) ) );
            map.put( "sessionDate", convertDate( map.get( "sessionDate" ) ) );
            map.put( "exercisesPercentCorrect", Math.round( ( Float.valueOf( map.get( "exercisesCorrect" ) ) / Float.valueOf( map.get( "exercisesAttempted" ) ) * 100 ) ) + "%" );

            dataList.put( student, map );
        } );
        Log.message( "GraphQL Data: " + dataList );
        return dataList;
    }

    private Map<String, Map<String, String>> getReadingResponseData( String response, String studentKey, List<String> studentList, boolean isIPOnCourse, String assignment ) {
        Map<String, Map<String, String>> dataList = new HashMap<>();
        studentList.stream().forEach( student -> {
            Map<String, String> map = getValuesFromLSResponse( response, studentKey, student, assignment, adminLSRConstants.LAST_SESSION_READING_REPORT_FIELDS );
            if ( isIPOnCourse ) {
                map.put( "currentCourseLevel", map.get( "currentCourseLevel" ).equals( "-1" ) ? "In IP" : map.get( "currentCourseLevel" ) );
            } else {
                map.put( "currentCourseLevel", "NA" );
            }
            map.put( "exercisesCorrect", String.valueOf( Integer.parseInt( map.get( "instructionalCorrect" ) ) + Integer.parseInt( map.get( "independentPracticeCorrect" ) ) + Integer.parseInt( map.get( "remediationCorrect" ) ) ) );
            map.put( "exercisesAttempted", String.valueOf( Integer.parseInt( map.get( "instructionalAttempted" ) ) + Integer.parseInt( map.get( "independentPracticeAttempted" ) ) + Integer.parseInt( map.get( "remediationAttempted" ) ) ) );
            map.put( "exercisesPercentCorrect", Math.round( ( Float.valueOf( map.get( "exercisesCorrect" ) ) / Float.valueOf( map.get( "exercisesAttempted" ) ) * 100 ) ) + "%" );

            map.put( "timeSpent", convertTimeSpent( map.get( "timeSpent" ) ) );
            map.put( "sessionDate", convertDate( map.get( "sessionDate" ) ) );

            // Mapping the data for Reading course
            Map<String, String> readingData = new HashMap<>();

            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 0 ), map.get( "currentCourseLevel" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 1 ), map.get( "exercisesCorrect" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 2 ), map.get( "exercisesAttempted" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 3 ), map.get( "exercisesPercentCorrect" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 4 ),
                    ( map.get( "instructionalCorrect" ).equals( "0" ) ? "--" : map.get( "instructionalCorrect" ) ) + "/" + ( map.get( "instructionalAttempted" ).equals( "0" ) ? "--" : map.get( "instructionalAttempted" ) ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 5 ),
                    ( map.get( "independentPracticeCorrect" ).equals( "0" ) ? "--" : map.get( "independentPracticeCorrect" ) ) + "/" + ( map.get( "independentPracticeAttempted" ).equals( "0" ) ? "--" : map.get( "independentPracticeAttempted" ) ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 6 ),
                    ( map.get( "remediationCorrect" ).equals( "0" ) ? "--" : map.get( "remediationCorrect" ) ) + "/" + ( map.get( "remediationAttempted" ).equals( "0" ) ? "--" : map.get( "remediationAttempted" ) ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 7 ), map.get( "helpUsed" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 8 ), map.get( "timeSpent" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 9 ), map.get( "totalSessions" ) );
            readingData.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 10 ), map.get( "sessionDate" ) );

            dataList.put( student, readingData );
        } );
        Log.message( "GraphQL Data: " + dataList );
        return dataList;
    }

    private String convertTimeSpent( String time ) {
        String convertedTime = null;
        String[] split = time.split( ":" );
        if ( split[1].length() == 1 ) {
            convertedTime = "00:0" + split[1] + "*";
        } else {
            convertedTime = "00:" + split[1] + "*";
        }
        return convertedTime;
    }

    private String convertDate( String date ) {
        String[] split = date.split( "T" );
        String[] dateSplit = split[0].split( "-" );
        return dateSplit[1] + "/" + dateSplit[2] + "/" + dateSplit[0];
    }

    private static Map<String, String> getValuesFromLSResponse( String response, String studentKey, String studentValue, String assignmentName, List<String> values ) {
        Map<String, String> valueList = new HashMap<>();

        try {
            String fromResponse = SMUtils.getKeyValueFromResponse( response, "data" );
            JSONArray jsonArray = new JSONObject( fromResponse ).getJSONArray( "getLSAdminReportData" );

            IntStream.range( 0, jsonArray.length() ).forEach( itr -> {
                JSONObject jObj = jsonArray.getJSONObject( itr );
                if ( jObj.get( studentKey ).toString().equals( studentValue ) && jObj.get( "assignmentTitle" ).toString().equals( assignmentName ) ) {
                    values.stream().forEach( value -> {
                        if ( new JSONObject( jObj.toString() ).get( "rawPerformance" ).toString().contains( value ) ) {
                            valueList.put( value, SMUtils.getKeyValueFromResponse( new JSONObject( jObj.toString() ).get( "rawPerformance" ).toString(), value ) );

                        } else if ( new JSONObject( jObj.toString() ).get( "usage" ).toString().contains( value ) ) {
                            valueList.put( value, SMUtils.getKeyValueFromResponse( new JSONObject( jObj.toString() ).get( "usage" ).toString(), value ) );

                        } else if ( new JSONObject( jObj.toString() ).get( "exercisesCorrectedAttempted" ).toString().contains( value ) ) {
                            valueList.put( value, SMUtils.getKeyValueFromResponse( new JSONObject( jObj.toString() ).get( "exercisesCorrectedAttempted" ).toString(), value ) );

                        } else {
                            valueList.put( value, jObj.get( value ).toString() );

                        }
                    } );
                }
            } );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return valueList;
    }

}
