package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class RecentSessionsOutputTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String userNameDistrictAdmin;
    private String userNameSubDistrictAdmin;
    private String userNameSchoolAdmin;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        userNameDistrictAdmin = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        userNameSubDistrictAdmin = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        userNameSchoolAdmin = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );

    }

    @Test ( description = "Verify Recent Sessions Report output page is accessible for district admin", groups = {"Smoke", "SMK-57825", "ReportOutputPage", "RecentSessions" }, priority = 1 )
    public void tcRSROutputPage001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRSROutputPage001: Verify Recent Sessions Report output page is accessible for district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( userNameDistrictAdmin, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            // Load output page
            RecentSessionsOutputPage recentSessionsOutputPage = recentSessionPage.clickRunBtn();

            SMUtils.logDescriptionTC( "Verify the Recent Session report viewer page is displayed for District admin" );
            SMUtils.logDescriptionTC( "Verify Recent sessions header in the recent session report viewer." );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.getReportPageTitle().equals( ReportsUIConstants.RSR_PAGE_TITLE ), "Recent Sessions page title is displayed successfully!!!", "Recent Sessions page title is not displayed properly" );

            SMUtils.logDescriptionTC( "Verify the Page numbers in the Recent Session report viewer page." );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.verifyPaginationText(), "The Page numbers in the Recent Session report viewer page is displayed as expected", "The Page number in the Recent Session report viewer page is displayed wrongly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can enter the page number in the 'Go to' text box" );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.goToPage( 3 ), "Page number is entered and navigated to that page", "Unable to enter or navigate to the given page number" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Recent Sessions Report output page is accessible for sub-district admin", groups = {"Smoke", "SMK-57825", "ReportOutputPage", "RecentSessions" }, priority = 1 )
    public void tcRSROutputPage002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRSROutputPage002: Verify Recent Sessions Report output page is accessible for sub-district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( userNameSubDistrictAdmin, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            // Load output page
            RecentSessionsOutputPage recentSessionsOutputPage = recentSessionPage.clickRunBtn();

            SMUtils.logDescriptionTC( "Verify the Recent Session report viewer page is accessible for Sub-district admin" );
            
            SMUtils.logDescriptionTC( "Verify the next button in the recent session report vieiwer" );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.isNextBtnDisplayed() && recentSessionsOutputPage.reportOutputComponent.clickNextBtn(), "Next button is displayed and clickable in Recent Sessions report vieiwer page", "Next button is not displayed in Recent Sessions report vieiwer page" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify the Back button nearer to the page number in the recent session report vieiwer" );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.isBackBtnDisplayed() && recentSessionsOutputPage.reportOutputComponent.clickBackBtn(), "Back button is displayed and clickable in Recent Sessions report vieiwer page", "Back button is not displayed in Recent Sessions report vieiwer page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Subject name in the Recent Session report Viewer" );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.isAssignmentNameDisplyed(), "Assignment name field is displayed in Recent Sessions report vieiwer page", "Assignment name field is not displayed in Recent Sessions report vieiwer page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the report run field in the Recent Session report Viewer" );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.getReportRunHeader().equals( ReportsUIConstants.REPORT_RUN_LABEL ), "The report run field is displayed in the Recent Session report Viewer",
                    "The report run field is not displayed properly in the Recent Session report Viewer" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Recent Sessions Report output page is accessible for school admin", groups = {"Smoke", "SMK-57825", "ReportOutputPage", "RecentSessions" }, priority = 1 )
    public void tcRSROutputPage003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRSROutputPage003: Verify Recent Sessions Report output page is accessible for school admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( userNameSchoolAdmin, password );

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            // Load output page
            RecentSessionsOutputPage recentSessionsOutputPage = recentSessionPage.clickRunBtn();

            SMUtils.logDescriptionTC( "Verify the school name in the Recent Session report Viewer" );
            SMUtils.logDescriptionTC( "Verify Teacher name in the Recent Session report Viewer" );
            SMUtils.logDescriptionTC( "Verify Grade field in the Recent Session report Viewer" );
            SMUtils.logDescriptionTC( "Verify Group name in the Recent Session report Viewer" );

            List<String> infoHeaders = recentSessionsOutputPage.reportOutputComponent.getInfoHeader();
            IntStream.range( 0, infoHeaders.size() ).forEach( itr -> {
                Log.assertThat( infoHeaders.get( itr ).equals( ReportsUIConstants.INFO_LABELS.get( itr ) ), infoHeaders.get( itr ) + " is displayed in the Recent Session report Viewer",
                        ReportsUIConstants.INFO_LABELS.get( itr ) + " is not displayed in the Recent Session report Viewer" );
                Log.testCaseResult();
            } );

            SMUtils.logDescriptionTC( "Verify selected options field in the Recent Session report viewer." );
            Log.assertThat( recentSessionsOutputPage.reportOutputComponent.getSelectedOptionHeader().equals( ReportsUIConstants.SELECTED_OPTION_HEADER ) || recentSessionsOutputPage.reportOutputComponent.getSelectedOptionValues().size() == 6,
                    "Selected options field is displayed as expected in the Recent Session report viewer", "Selected options field is not displayed as expected in the Recent Session report viewer" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Legend in the Recent Session report viewer page." );
            Log.assertThat( recentSessionsOutputPage.verifyLegendHeaderAndLabels(), "Legend header and its values are displayed as expected in the Recent Session report viewer page",
                    "Legend header and its values are not displayed as expected in the Recent Session report viewer page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
