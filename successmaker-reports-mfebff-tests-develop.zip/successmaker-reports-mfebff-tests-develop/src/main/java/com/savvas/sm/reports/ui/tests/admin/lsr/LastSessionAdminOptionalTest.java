package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class LastSessionAdminOptionalTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String org;
    private List<String> courses;

    @BeforeTest
   public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
       password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    
    
    @Test ( description = "Verify the LS Report generation with 'Student Name' option in Display, None option in Additional Grouping Dropdown and Student from sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
            "Last Session" }, priority = 1 )
    public void tcLastSession001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLastSession001: Verify the LS Report generation with Default 'Student Name' option in Display, None option in Additional Grouping Dropdown and Student in sort <small><b><i>[" + browser + "]</b></i></small>" );

        
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:01 Verify the LS Report generation with Default 'Student Name' option in Display" );
            SMUtils.logDescriptionTC( "TC:02 Verify the LS Report generation with Default 'None' option in Additional Grouping" );
            SMUtils.logDescriptionTC( "TC:03 Verify the LS Report generation with Default  'Student' option in sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "The LS Report generation with 'Student Name' option in Display, 'None' option in Additional Grouping Dropdown and 'Student' in sort ",
                    "The LS Report not generation with 'Student Name' option in Display, 'None' option in Additional Grouping Dropdown and 'Student' in sort" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the LS Report generation with 'Student Username' option in Display, 'Teacher' option in Additional Grouping Dropdown and 'Current Course Level' in sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
            "Last Session" }, priority = 1 )
    public void tcLastSession002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcLastSession002: Verify the LS Report generation with 'Student Username' option in Display, 'Teacher' option in Additional Grouping Dropdown and 'Current Course Level' in sort <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:04 Verify the LS Report generation with 'Student Username' option in Display" );
            SMUtils.logDescriptionTC( "TC:05 Verify the LS Report generation with 'Teacher' option in Additional Grouping" );
            SMUtils.logDescriptionTC( "TC:06 Verify the LS Report generation with 'Current Course Level' option in sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the LS Report generation with 'Student ID' option in Display, 'Grade' option in Additional Grouping Dropdown and 'Current Course Level' in sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )
    
    public void tcLastSession003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLastSession003:Verify the LS Report generation with 'Student ID' option in Display, 'Grade' option in Additional Grouping Dropdown and 'Current Course Level' in sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:07 Verify the CP Report generation with 'Student ID' option in Display" );
            SMUtils.logDescriptionTC( "TC:08 Verify the CP Report generation with 'Grade' option in Additional Grouping" );
            SMUtils.logDescriptionTC( "TC:09 Verify the CP Report generation with 'Exercises Correct' option in sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();
            
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );
            RecentSessionsPage.reportFilterComponent.handleStudentPopup();
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the LS Report generation with 'Group' option in Additional Grouping Dropdown and 'Exercises Attempted' in sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )
    
    public void tcLastSession004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLastSession004:Verify the LS Report generation with 'Group' option in Additional Grouping Dropdown and 'IP Level' in sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:10 Verify the LS Report generation with 'Group' option in Additional Grouping Dropdown" );
            SMUtils.logDescriptionTC( "TC:11 Verify the LS Report generation with 'Exercises Attempted' option in sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Group" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Attempted" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the LS Report generation with 'Percent Correct' option in Sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )
    
    public void tcLastSession005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLastSession005:Verify the LS Report generation with 'Percent Correct' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:12 Verify the LS Report generation with 'Percent Correct' option in Sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Percent Correct" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    @Test ( description = "Verify the LS Report generation with 'Help Used' option in Sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )
    
    public void tcLastSession006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLastSession006:Verify the LS Report generation with 'Help Used' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:13 Verify the LS Report generation with 'Help Used' option in Sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Help Used" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    @Test ( description = "Verify the LS Report generation with 'Time Spent' option in Sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )
    
    public void tcLastSession007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLastSession007:Verify the LS Report generation with 'Time Spent' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:14 Verify the LS Report generation with 'Time Spent' option in Sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    @Test ( description = "Verify the LS Report generation with 'Total Sessions' option in Sort", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )
    
    public void tcLastSession008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser ); 

        Log.testCaseInfo( "tcLastSession008:Verify the LS Report generation with 'Total Sessions' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:15 Verify the LS Report generation with 'Total Sessions' option in Sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Total Sessions" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    @Test ( description = "Verify the LS Report generation with 'Session Date' option in Sort", groups = { "SMK-57820", "AdminDashboard", "Reports","Last Session" }, priority = 1 )
    
    public void tcLastSession009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser ); 

        Log.testCaseInfo( "tcLastSession009:Verify the LS Report generation with 'Session Date' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:16 Verify the LS Report generation with 'Session Date' option in Sort" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Session Date" );

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    @Test ( description = "Verify the LS Report generation for All Teachers under Teacher dropdown in optional Filter Dropdown under SELECT STUDENTS BY", groups = { "SMK-57820", "AdminDashboard", "Reports",
    "Last Session" }, priority = 1 )

public void tcLastSession010() throws Exception {
// Get driver
final WebDriver driver = WebDriverFactory.get( browser );

String headerText = "";

Log.testCaseInfo(
        "tcLastSession010: Verify the LS Report generation for All Teachers under Teacher dropdown in optional Filter Dropdown under SELECT STUDENTS BY <small><b><i>[" + browser + "]</b></i></small>" );
try {
    AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
    AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
    RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();
    
    SMUtils.logDescriptionTC( "TC:17 Verify the LS Report generation for All Teachers under Teacher dropdown in optional Filter Dropdown under SELECT STUDENTS BY" );

    RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
    courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

    RecentSessionsPage.reportFilterComponent.expandOptionalFilter();
    
    headerText = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).get( 0 );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( headerText ) );
    Log.message( RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) );
    Log.assertThat( RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( "(All) Selected" ), "Selected Teacher is displaying",
            "Selected Teacher is not displaying" );

    RecentSessionsPage.reportFilterComponent.clickRunReportButton();
    SMUtils.switchWindow( driver );
    SMUtils.waitForPageLoad( driver );
    SMUtils.waitForSpinnertoDisapper( driver );
    Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
    Log.testCaseResult();

} catch ( Exception e ) {
    Log.exception( e, driver );
} finally {
    Log.endTestCase();
    driver.quit();
}

}

@Test ( description = "Verify the LS Report generation for All Grade Students under Grades dropdown in optional Filter Dropdown under SELECT STUDENTS BY", groups = { "SMK-57820", "AdminDashboard", "Reports", "Last Session" }, priority = 1 )
public void tcLastSession011() throws Exception {
//Get driver
final WebDriver driver = WebDriverFactory.get( browser );

String headerText = "";

Log.testCaseInfo( "tcLastSession011: Verify the LS Report generation for All Grade Students under Grades dropdown in optional Filter Dropdown under SELECT STUDENTS BY <small><b><i>[" + browser + "]</b></i></small>" );
try {
    AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
    AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
    RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();
    
    SMUtils.logDescriptionTC( "TC:18 Verify the LS Report generation with All Grades in Grade Dropdown " );

    RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
    courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

    RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

    headerText = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).get( 0 );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( headerText ) );
    Log.message( RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ) );
    Log.assertThat( RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equalsIgnoreCase( "(All) Selected" ), "Selected Grades are displaying",
            "Selected Grades are not displaying" );

    RecentSessionsPage.reportFilterComponent.clickRunReportButton();
    SMUtils.switchWindow( driver );
    SMUtils.waitForPageLoad( driver );
    SMUtils.waitForSpinnertoDisapper( driver );
    Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
    Log.testCaseResult();

} catch ( Exception e ) {
    Log.exception( e, driver );
} finally {
    Log.endTestCase();
    driver.quit();
}

}

@Test ( description = "Verify the LS Report generation for All Groups under Group dropdown in optional Filter Dropdown under SELECT STUDENTS BY", groups = { "SMK-57820", "AdminDashboard", "Reports", "Last Session" }, priority = 1 )
public void tcLastSession012() throws Exception {
//Get driver
final WebDriver driver = WebDriverFactory.get( browser );

String headerText = "";

Log.testCaseInfo( "tcLastSession012: Verify the LS Report generation for All Group Students under Group dropdown in optional Filter Dropdown under SELECT STUDENTS BY <small><b><i>[" + browser + "]</b></i></small>" );
try {
    AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
    AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
    RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

    SMUtils.logDescriptionTC( "TC:19 Verify the CP Report generation with All Groups in Group Dropdown " );

    RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
    courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

    RecentSessionsPage.reportFilterComponent.expandOptionalFilter();

    headerText = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL ).get( 0 );
    RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL, Arrays.asList( headerText ) );
    Log.message( RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL ) );
    Log.assertThat( RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL ).equalsIgnoreCase( "(All) Selected" ), "Selected Groups are displaying",
            "Selected Groups are not displaying" );

    RecentSessionsPage.reportFilterComponent.clickRunReportButton();
    
    SMUtils.switchWindow( driver );
    SMUtils.waitForPageLoad( driver );
    SMUtils.waitForSpinnertoDisapper( driver );
    Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
    Log.testCaseResult();

} catch ( Exception e ) {
    Log.exception( e, driver );
} finally {
    Log.endTestCase();
    driver.quit();
}

}

    
    @Test(description = "Verify the LS Report generation with 'Select All' option in Student Demographic", groups = { "SMK-57820", "AdminDashboard", "Reports","Last Session" }, priority = 1 )
    public void tcLastSession013() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);

        Log.testCaseInfo("tcLastSession010:Verify the LS Report generation with 'Select All' option in Student Demographic <small><b><i>[" + browser + "]</b></i></small>");

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:17 Verify the LS Report generation with 'Select All' option in Student Demographic" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();
            RecentSessionsPage.reportFilterComponent.expandStudentDemographics();
            
            List<String> availableOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS);
            List<String> selectedOptions = Arrays.asList(availableOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS, selectedOptions);
            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all disablity options", "Selected disablity options are not checked");
            Log.testCaseResult();

            // Get English Proficiency List and Select multiple options from drop-down

            List<String> availableEnglishProficiencyOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY);
            Log.message(availableEnglishProficiencyOptionList.toString());
            List<String> selectedEnglishProficiencyOptions = Arrays.asList(availableEnglishProficiencyOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, selectedEnglishProficiencyOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all english language proficiency options", "Selected english language proficiency options are not checked");
            Log.testCaseResult();

            // Get Ethnicity List and Select multiple options from drop-down
            List<String> EthnicityOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY);
            List<String> selectedEthnicityOptions = Arrays.asList(EthnicityOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY, selectedEthnicityOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all ethnicity options", "Selected ethnicity options are not checked");
            Log.testCaseResult();

            // Get Migrant Status List and Select multiple options from drop-down
            List<String> MigrantStatusOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS);
            List<String> selectedMigrantStatusOptions = Arrays.asList(MigrantStatusOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS, selectedMigrantStatusOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all migrant status options", "Selected migrant status options are not checked");
            Log.testCaseResult();

            // Get Race List and Select multiple options from drop-down
            List<String> raceOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE);
            List<String> selectedRaceOptions = Arrays.asList(raceOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE, selectedRaceOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.RACE).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all race options", "Selected race options are not checked");
            Log.testCaseResult();

            // Get Special Services List and Select multiple options from drop-down
            List<String> specialServicesOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES);
            List<String> selectedSpecialServicesOptions = Arrays.asList(specialServicesOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES, selectedSpecialServicesOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all special services options", "Selected special services are not displaying");
            Log.testCaseResult();

            // Get Socioeconomic Status List and Select multiple options from drop-down
            List<String> socioeconomicStatusOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS);
            List<String> selectedSocioeconomicStatusOptions = Arrays.asList(socioeconomicStatusOptionList.get(0));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS, selectedSocioeconomicStatusOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_ALL_OPTION),
                    "Selected all socioeconomic status options", "Selected socioeconomic status are not displaying");
            Log.testCaseResult();

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed", "Last Session Report data not displayed" );
            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    // Check selecting "Single" option and Run Report in Demographics

    @Test(description = "Verify the CP Report generation with 'Only One' option Selected in Student Demographic", groups = {
            "SMK-57820", "AdminDashboard", "Reports", "Last Session" }, priority = 1)
    public void tcLastSession014() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);

        Log.testCaseInfo("tcLastSession014:Verify the CP Report generation with 'Only One' option Selected in Student Demographic <small><b><i>[" + browser + "]</b></i></small>");

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:18 Verify the CP Report generation with 'Only One' option Selected in Student Demographic " );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();
            RecentSessionsPage.reportFilterComponent.expandStudentDemographics();
            
            List<String> availableOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS);
            List<String> selectedOptions = Arrays.asList(availableOptionList.get(1));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS, selectedOptions);
            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_DISABLITY_OPTION),
                            "Selected only one disablity options", "Selected disablity options are not checked");
            Log.testCaseResult();

            // Get English Proficiency List and Select multiple options from drop-down

            List<String> availableEnglishProficiencyOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY);
            List<String> selectedEnglishProficiencyOptions = Arrays.asList(availableEnglishProficiencyOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, selectedEnglishProficiencyOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY).equalsIgnoreCase(ReportsUIConstants.SELECTED_ENGLISH_PROFICIENCY_OPTION),
                            "Selected only one english language proficiency options", "Selected english language proficiency options are not checked");
            Log.testCaseResult();

            // Get Ethnicity List and Select multiple options from drop-down
            List<String> EthnicityOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY);
            List<String> selectedEthnicityOptions = Arrays.asList(EthnicityOptionList.get(1));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY, selectedEthnicityOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY).equalsIgnoreCase(ReportsUIConstants.SELECTED_ETHNICITY_OPTION),
                            "Selected only ethnicity options", "Selected ethnicity options are not checked");
            Log.testCaseResult();

            // Get Migrant Status List and Select multiple options from drop-down
            List<String> MigrantStatusOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS);
            List<String> selectedMigrantStatusOptions = Arrays.asList(MigrantStatusOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS, selectedMigrantStatusOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_MIGRANT_STATUS_OPTION),
                            "Selected only migrant status options", "Selected migrant status options are not checked");
            Log.testCaseResult();

            // Get Race List and Select multiple options from drop-down
            List<String> raceOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE);
            List<String> selectedRaceOptions = Arrays.asList(raceOptionList.get(1));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE, selectedRaceOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.RACE).equalsIgnoreCase(ReportsUIConstants.SELECTED_RACE_OPTION),
                            "Selected only one race options", "Selected race options are not checked");
            Log.testCaseResult();

            // Get Special Services List and Select multiple options from drop-down
            List<String> specialServicesOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES);
            List<String> selectedSpecialServicesOptions = Arrays.asList(specialServicesOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES, selectedSpecialServicesOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES).equalsIgnoreCase(ReportsUIConstants.SELECTED_SPECIAL_SERVICES),
                            "Selected only one special services options", "Selected special services are not displaying");
            Log.testCaseResult();

            // Get Socioeconomic Status List and Select multiple options from drop-down
            List<String> socioeconomicStatusOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS);
            List<String> selectedSocioeconomicStatusOptions = Arrays.asList(socioeconomicStatusOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS, selectedSocioeconomicStatusOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_SOCIOECONOMIC_STATUS),
                            "Selected only one socioeconomic status options", "Selected socioeconomic status are not displaying");
            Log.testCaseResult();

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);
            Log.assertThat(RecentSessionsPage.checkReportHeaderAfterRun(),
                    "Admin Cumulative Performance Report displayed", "Cumulative Performance Report data not displayed");
            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test(description = "Verify the LS Report generation with 'Multiple Checkbox' option in Student Demographic", groups = {
            "SMK-57820", "AdminDashboard", "Reports", "Last Session" }, priority = 1)
    public void tcLastSession015() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get(browser);

        Log.testCaseInfo("tcLastSession015:Verify the LS Report generation with 'Multiple Checkbox' option in Student Demographic <small><b><i>[" + browser + "]</b></i></small>");

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "TC:19 Verify the LS Report generation with 'Multiple Checkbox' option in Student Demographic" );

            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            RecentSessionsPage.reportFilterComponent.expandOptionalFilter();
            RecentSessionsPage.reportFilterComponent.expandStudentDemographics();
            
            // Get Disability Status List and Select multiple options from drop-down

            List<String> availableOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS);
            List<String> selectedOptions = Arrays.asList(availableOptionList.get(1), availableOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS, selectedOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                            "Selected multiple disablity options", "Selected disablity options are not checked");
            Log.testCaseResult();

            // Get English Proficiency List and Select multiple options from drop-down

            List<String> availableEnglishProficiencyOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY);
            List<String> selectedEnglishProficiencyOptions = Arrays.asList(availableEnglishProficiencyOptionList.get(1),availableEnglishProficiencyOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, selectedEnglishProficiencyOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                            "Selected multiple english language proficiency options", "Selected english language proficiency options are not checked");
            Log.testCaseResult();

            // Get Ethnicity List and Select multiple options from drop-down
            List<String> EthnicityOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY);
            List<String> selectedEthnicityOptions = Arrays.asList(EthnicityOptionList.get(1),EthnicityOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY, selectedEthnicityOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                            "Selected multiple ethnicity options", "Selected ethnicity options are not checked");
            Log.testCaseResult();

            // Get Migrant Status List and Select multiple options from drop-down
            List<String> MigrantStatusOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS);
            List<String> selectedMigrantStatusOptions = Arrays.asList(MigrantStatusOptionList.get(1),MigrantStatusOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS, selectedMigrantStatusOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                    "Selected multiple migrant status options", "Selected migrant status options are not checked");
            Log.testCaseResult();

            // Get Race List and Select multiple options from drop-down
            List<String> raceOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE);
            List<String> selectedRaceOptions = Arrays.asList(raceOptionList.get(1), raceOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE, selectedRaceOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.RACE).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                    "Selected multiple race options", "Selected race options are not checked");
            Log.testCaseResult();

            // Get Special Services List and Select multiple options from drop-down
            List<String> specialServicesOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES);
            List<String> selectedSpecialServicesOptions = Arrays.asList(specialServicesOptionList.get(1),specialServicesOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES, selectedSpecialServicesOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                    "Selected multiple special services options", "Selected special services are not displaying");
            Log.testCaseResult();

            // Get Socioeconomic Status List and Select multiple options from drop-down
            List<String> socioeconomicStatusOptionList = RecentSessionsPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS);
            List<String> selectedSocioeconomicStatusOptions = Arrays.asList(socioeconomicStatusOptionList.get(1),socioeconomicStatusOptionList.get(2));
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS, selectedSocioeconomicStatusOptions);

            Log.assertThat(RecentSessionsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS).equalsIgnoreCase(ReportsUIConstants.SELECTED_OPTION),
                    "Selected multiple socioeconomic status options", "Selected socioeconomic status are not displaying");
            Log.testCaseResult();

            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);
            Log.assertThat(RecentSessionsPage.checkReportHeaderAfterRun(),
                    "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed");
            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }



   

} 


