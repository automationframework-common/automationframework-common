package com.savvas.sm.reports.ui.tests.admin.spr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class StudentPerformanceReportSavedOptionsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( dataProvider = "AdminData", description = "district admin", groups = {"Smoke", "SMK-57942", "studentPerformanceReports", "savedReport" }, priority = 1 )
    public void tcStudentPerformanceSavedReport001( String description, String username ) throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( description );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            //Navigating to the recent session report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            SMUtils.logDescriptionTC( "Verify that admin can be able to see Saved Report Options header above the Dropdown." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getSavedReportOptionLabelForStudentPerformance().equalsIgnoreCase( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "Saved Report Option label displayed properly",
                    "Saved Report Option label not displayed properly. Expected - " + ReportsUIConstants.SAVED_REPORT_OPTIONS + " Actual -" + studentPerformancePage.reportFilterComponent.getSavedReportOptionLabelForStudentPerformance() );
            Log.testCaseResult();
            Log.assertThat( studentPerformancePage.reportFilterComponent.isMultiSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization drop down is displayed", "The Organization drop down is not displayed" );
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            // Selecting All Option from Organization dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( "ALL" ) );
            List<String> allOptionsFromOrganizationDropdown = studentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            allOptionsFromOrganizationDropdown.remove( "ALL" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll( allOptionsFromOrganizationDropdown ), "All options are selected",
                    "All options are not selected" );
            //Collapse Organization dropdown
            studentPerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            //Selecting Math from Subject dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //Collapse Subject dropdown
            studentPerformancePage.reportFilterComponent.collapseSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL );

            // Selecting All Options from Courses dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "ALL" ) );

            allOptionsFromOrganizationDropdown = studentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            allOptionsFromOrganizationDropdown.remove( "ALL" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).containsAll( allOptionsFromOrganizationDropdown ), "All options are selected",
                    "All options are not selected" );
            //Collapse Courses dropdown
            studentPerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );

            // Expanding Optional Filter Dropdown
            studentPerformancePage.reportFilterComponent.expandOptionalFilter();

            // Expanding Optional DemoGraphics Dropdown
            studentPerformancePage.reportFilterComponent.expandStudentDemographics();

            // Selecting the Demographic dropdown values
            studentPerformancePage.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.STUDENT_GENDER_OPTIONS.get( 1 ) ) );

            //Selecting multiple Values
            List<String> dropdownSelectedValues = Arrays.asList( ReportsUIConstants.STUDENT_GENDER_OPTIONS.get( 1 ) );

            //Click Save Report Options button 
            studentPerformancePage.reportFilterComponent.clickSaveReportButton();
            String savedReportTitle = "SavedReport" + System.nanoTime();
            //Enter name for Saved Report
            studentPerformancePage.reportFilterComponent.enterNameForSaveReport( savedReportTitle );
            //Click Save button
            studentPerformancePage.reportFilterComponent.clickSaveButton();
            driver.navigate().refresh();
            SMUtils.logDescriptionTC( "Verify that admin able to see light grey text \"Choose from your list of saved options\" in the dropdown field." );
            Log.assertThat(
                    studentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK ),
                    "The Student Performance Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK,
                    "The Student Performance Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK );
            //Verifying the dropdown placeholder text color
            Log.assertThat( studentPerformancePage.reportFilterComponent.getPlaceHolderTextColorForSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "The Student Performance Save Report Option text is displayed in light grey color", "The Student Performance Save Report Option text is not displayed in light grey color" );
            //Expand the SAVED REPORT OPTIONS dropdown          
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );

            SMUtils.logDescriptionTC( "Verify once admin clicked, dropdown should be expanded." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.isSingleSelectDropdownExpanded( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "Saved Report Option is DropDown is Expanded ",
                    "Saved report Option Dropdown not Expanded" );

            SMUtils.logDescriptionTC( " Verify all the previously saved Reports are Listed properly in the dropdown." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.message( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).toString() );
            String selectingOption = savedReportTitle;
            //selecting the recently saved option from saved report dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL, selectingOption );

            String savedReportWaterMarkText = studentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );

            SMUtils.logDescriptionTC( "As a Admin I can able to select only one report from the Dropdown." );
            SMUtils.logDescriptionTC( " Verify all the previously saved Reports are Listed properly in the dropdown." );
            Log.assertThat( savedReportWaterMarkText.equals( selectingOption ), "The selected option is displayed in the drop down text", "The selected option is not displayed in the drop down text" );

            // Expanding Optional Filter Dropdown
            studentPerformancePage.reportFilterComponent.expandOptionalFilter();

            // Expanding Optional DemoGraphics Dropdown
            studentPerformancePage.reportFilterComponent.expandStudentDemographics();

            // Get Selected Option
            List<String> selectedOptionsFromMultiSelectDropdown = studentPerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER );

            SMUtils.logDescriptionTC( "Verify the dimographics values are being retained" );
            SMUtils.logDescriptionTC( " Verify the Options selected is same after user saved the reports." );

            // Demographic Values are not retained : Open Rework --> SMK-60718
            Log.softAssertThat( selectedOptionsFromMultiSelectDropdown.contains( dropdownSelectedValues ), "DemoGraphic Values are Retained Successfully", "Demographic Values not retained Successfully" );

            //Click Save Report Options button 
            studentPerformancePage.reportFilterComponent.clickSaveReportButton();
            //Enter name for Saved Report
            String updatedReportTitle = "UpdatedReport" + System.nanoTime();
            studentPerformancePage.reportFilterComponent.enterNameForSaveReport( updatedReportTitle );
            //Click Save button
            studentPerformancePage.reportFilterComponent.clickSaveButton();

            //Expand the SAVED REPORT OPTIONS dropdown
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.message( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).toString() );
            selectingOption = updatedReportTitle;
            //selecting the recently saved option from saved report dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL, selectingOption );
            Log.message( selectingOption );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @DataProvider ( name = "AdminData" )
    public Object[][] getAdminData() {

        Object[][] inputData = { { "Verify the District admin can be able to see the Saved Report Options.", RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ) },
                { "Verify the District admin can be able to see the Saved Report Options.", RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ) },
                { "Verify the District admin can be able to see the Saved Report Options.", RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) },
                { "Verify the District admin can be able to see the Saved Report Options.", RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) }, };

        return inputData;
    }

}
