package com.savvas.sm.reports.api.teacher.exportPDF;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.RestAssuredAPI;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.teacher.pages.CumulativePerformanceReport;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import io.restassured.response.Response;

public class TeacherStudentPerformanceExportPDFAPITest extends EnvProperties {

    AreaForGrowthPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    CumulativePerformanceReport cprPage;
    AreasForGrowthReport areasForGrowthReport;
    ReportsViewerPage reportViewerPage;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    String groupID;
    String teacherDetails;
    String browser;
    String username;
    String orgId;
    String teacherId;
    String student1;
    String studentUserName;
    String studentId;
    HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    HashMap<String, String> assignmentIds = new HashMap<>();
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    List<String> valuesAssignment;
    String assigmentIdDetaials;
    Map<String, String> accessTokenHeaders = new HashMap<>();
    JSONObject responseContent = null;
    static Map<String, String> usersAccessToken = new HashMap<>();
    String accessToken = null;
    String castgcToken = null;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        studentId = SMUtils.getKeyValueFromResponse( student1, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( student1, "userName" );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );

        groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        } catch ( Exception e1 ) {
            Log.message( "Issue in getting access token!!!.Retrying" );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        }

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentId ), Arrays.asList( "1" ) );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        valuesAssignment = assignmentIds.values().stream().collect( Collectors.toList() );
        assigmentIdDetaials = valuesAssignment.toString();

        WebDriver driver = WebDriverFactory.get( browser );
        try {
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeMathCourse( studentUserName, "Math", "90", "1", "5" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.message( "Error occured while run the simulator!!!" );
        } finally {
            driver.quit();
        }

    }

    @Test ( dataProvider = "positiveScenarios", groups = { "SMK-66277/SMK-69992", "Export-PDF -SPR", "P1", "smoke_test_case" }, priority = 1 )
    public void teacherSPRCPRExportPDFAPIPositiveCases( String tcId, String description, String statusCode, String scenario ) throws IOException {
        String requestIDs;
        String profileCastGC;
        String accessTokeForTeacher;
        Response responses = null;
        switch ( scenario ) {
            case "VALID_REQUEST":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, requestIDs, "student-Performance", username, password, Boolean.TRUE, 0 );

                Log.assertThat( responses.getStatusCode() == 200, "Getting the 200 satus code for export pdf", "Not Getting the 200 satus code for export pdf" );

                //Schema Validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "Schema_PDF", statusCode, responses.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "PDFL_LINK_FALSE":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, requestIDs, "student-Performance", username, password, Boolean.TRUE, 0 );

                Log.assertThat( responses.getStatusCode() == 200, "Getting the 200 satus code for export pdf", "Not Getting the 200 satus code for export pdf" );

                break;

            case "ZERO_STATE":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );
                Log.message( requestIDs );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, requestIDs, "student-Performance", username, password, Boolean.TRUE, 0 );

                Log.assertThat( responses.getStatusCode() == 200, "Getting the 200 satus code for export pdf", "Not Getting the 200 satus code for export pdf" );

                //Schema Validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "Schema_PDF", statusCode, responses.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "CURRENTPAGE_VALID":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );
                Log.message( requestIDs );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, requestIDs, "student-Performance", username, password, Boolean.TRUE, 1 );

                Log.assertThat( responses.getStatusCode() == 200, "Getting the 200 satus code for export pdf", "Not Getting the 200 satus code for export pdf" );

                //Schema Validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "Schema_PDF", statusCode, responses.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

        }

    }

    /**
     * Data provider for positive scenario
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarios" )
    public Object[][] positiveScenarios() {

        Object[][] inputData = { { "tc_teacherSPRPDFV001", "Verify Generate/Export PDF return 200 response for CPR for Teacher", CommonAPIConstants.STATUS_CODE_OK, "VALID_REQUEST" },
                { "tc_teacherSPRPDFV002", "Verify Generate/Export PDF return 200 response for CPR for Teacher", CommonAPIConstants.STATUS_CODE_OK, "PDFL_LINK_FALSE" },
                { "tc_teacherSPRPDFV003", "Verify 200 response code for zero state of report", CommonAPIConstants.STATUS_CODE_OK, "ZERO_STATE" },
                { "tc_teacherSPRPDFV004", "Verify 200 response code when user passed current page in request body", CommonAPIConstants.STATUS_CODE_OK, "CURRENTPAGE_VALID" } };
        return inputData;
    }

    @Test ( dataProvider = "negativeScenarios", groups = { "SMK-66277/SMK-69992", "Export-PDF - SPR", "P1" }, priority = 2 )
    public void teacherSPRExportPDFAPINegativeTests( String tcId, String description, String statusCode, String scenario ) throws IOException {
        String requestIDs;
        String profileCastGC;
        String accessTokeForTeacher;
        Response responses = null;
        switch ( scenario ) {
            case "INVALID_USER":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );
                Log.message( requestIDs );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, "ffffffff6c002fd18026s", orgId, requestIDs, "cumulative-performance", username, password, Boolean.TRUE, 0 );

                Log.assertThat( responses.getStatusCode() == 401, "Getting the 401 satus code for export pdf", "Not Getting the 401 satus code for export pdf" );
                break;
            case "WRONG_RID":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, "34-4366", "cumulative-performance", username, password, Boolean.TRUE, 0 );

                Log.assertThat( responses.getStatusCode() == 400, "Getting the 400 satus code for export pdf", "Not Getting the 400 satus code for export pdf" );

                break;
            case "WRONG_TOKEN":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDFNegative( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, requestIDs, "cumulative-performance", username, password, ReportAPIConstants.RUN_REPORT_TIME_VALUE );

                Log.assertThat( responses.getStatusCode() == 401, "Getting the 401 satus code for export pdf", "Not Getting the 401 satus code for export pdf" );
                break;

            case "WRONG_CASTGC":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDFNegative( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, requestIDs, "cumulative-performance", username, password, ReportAPIConstants.RUN_REPORT_TIME_VALUE );

                Log.assertThat( responses.getStatusCode() == 401, "Getting the 401 satus code for export pdf", "Not Getting the 401 satus code for export pdf" );
                break;

            case "WRONG_BODY":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, "34-4366", "cumulative-performance", username, password, Boolean.TRUE, 0 );

                Log.assertThat( responses.getStatusCode() == 400, "Getting the 400 satus code for export pdf", "Not Getting the 400 satus code for export pdf" );

                break;

            case "RRQUESTID_MISSING":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, orgId, "", "cumulative-performance", username, password, Boolean.TRUE, 0 );
                Log.message( String.valueOf( responses.getStatusCode() ) );
                Log.message( responses.getBody().asString() );
                Log.assertThat( responses.getStatusCode() == 400, "Getting the 400 satus code for export pdf", "Not Getting the 400 satus code for export pdf" );

                break;

            case "ORGID_MISSING":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, "", "requestIDs", "cumulative-performance", username, password, Boolean.TRUE, 0 );
                Log.message( String.valueOf( responses.getStatusCode() ) );
                Log.message( responses.getBody().asString() );

                Log.assertThat( responses.getStatusCode() == 400, "Getting the 400 satus code for export pdf", "Not Getting the 400 satus code for export pdf" );

                break;

            case "WRONG_CURRENTPAGE":

                requestIDs = getRequestID( teacherId, orgId, username, studentId, groupID, assigmentIdDetaials );

                responses = postSPRExportPDF( ReportAPIConstants.GRAPG_QL_BASE_URL, teacherId, "", "requestIDs", "cumulative-performance", username, password, Boolean.TRUE, 4 );
                Log.message( String.valueOf( responses.getStatusCode() ) );
                Log.message( responses.getBody().asString() );

                Log.assertThat( responses.getStatusCode() == 400, "Getting the 400 satus code for export pdf", "Not Getting the 400 satus code for export pdf" );

                break;

        }
    }

    /**
     * Data provider for positive scenario
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarios" )
    public Object[][] negativeScenarios() {

        Object[][] inputData = { { "tc_teacherSPRPDFV005", "Verify response  401 when invalid user-id passed in headers.", CommonAPIConstants.STATUS_CODE_OK, "INVALID_USER" },
                { "tc_teacherSPRPDFV006", "Verify response  400 when invalid request id (or) castgc passed in request body.", CommonAPIConstants.STATUS_CODE_OK, "WRONG_RID" },
                { "tc_teacherSPRPDFV007", "Verify response 401 when user pass wrong bearer  token in body", CommonAPIConstants.STATUS_CODE_OK, "WRONG_TOKEN" },
                { "tc_teacherSPRPDFV008", "Verify response 401 when user pass wrong Castgc token in body", CommonAPIConstants.STATUS_CODE_OK, "WRONG_CASTGC" },
                { "tc_teacherSPRPDFV009", "Verify response 400 when user pass wrong body", CommonAPIConstants.STATUS_CODE_OK, "WRONG_BODY" },
                { "tc_teacherSPRPDFV010", "Verify response  400 when request id (or) reportType (or) castgc missing in request body.", CommonAPIConstants.STATUS_CODE_OK, "RRQUESTID_MISSING" },
                { "tc_teacherSPRPDFV011", "Verify response  401 when request id (or) reportType (or) castgc missing in request body.", CommonAPIConstants.STATUS_CODE_OK, "ORGID_MISSING" },
                { "tc_teacherSPRPDFV012", "Verify response  400 when wrong current page number  in request body.", CommonAPIConstants.STATUS_CODE_OK, "WRONG_CURRENTPAGE" } };
        return inputData;
    }

    /**
     * To get the request id for request body
     * 
     * @param userId
     * @param orgId
     * @param teacherUsername
     * @param StudentIDs
     * @param groupsId
     * @param assignmentIDs
     * @return
     * @throws IOException
     */
    public String getRequestID( String userId, String orgId, String teacherUsername, String StudentIDs, String groupsId, String assignmentIDs ) throws IOException {

        String payload = "";
        Map<String, String> header = new HashMap<>();

        String query;
        Response response = null;
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        //headers for authorization
        header.put( ReportAPIConstants.USER_IDs, userId );
        header.put( ReportAPIConstants.ORG_IDs, orgId );

        String teacherAccessToken = null;
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        header.put( Constants.AUTHORIZATION, Constants.BEARER + teacherAccessToken );

        String reportParamPayload = ReportAPIConstants.REPORT_PARAMETER_PAYLOAD_SPR;
        reportParamPayload = reportParamPayload.replace( ReportAPIConstants.GROUPS_ID, groupsId );
        reportParamPayload = reportParamPayload.replace( ReportAPIConstants.STUDENT_IDD, StudentIDs );
        reportParamPayload = reportParamPayload.replace( ReportAPIConstants.ASSIGNMNET_ID, assignmentIDs.replace( "]", "" ).replace( "[", "" ) );
        reportParamPayload = reportParamPayload.replace( ReportAPIConstants.USERSID, userId );
        reportParamPayload = reportParamPayload.replace( ReportAPIConstants.ORGS_ID, orgId );
        reportParamPayload = reportParamPayload.replace( ReportAPIConstants.FILTER_NAMES, "saveReportSPR" + System.nanoTime() );

        response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, header, reportParamPayload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
        Log.message( response.getBody().asString() );
        String saveReportOptions = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "saveReportOption" );
        String requestId = SMUtils.getKeyValueFromResponse( saveReportOptions, "requestId" );

        Log.message( "Request-Id -" + requestId.trim() );

        return requestId;
    }

    /**
     * To get request body, header and validation with access token and castgc
     * 
     * @param smUrl
     * @param userIds
     * @param orgId
     * @param requestID
     * @param reportType
     * @param userId
     * @param password
     * @param pdfLink
     * @return
     */
    public Response postSPRExportPDF( String smUrl, String userIds, String orgId, String requestID, String reportType, String userId, String password, Boolean pdfLink, int currentPage ) {

        String endPoint = "/pdf-export";
        Map<String, Object> requestBody = new HashMap<>();
        Map<String, String> headers = new HashMap<>();

        try {
            String rbsLoginURL = configProperty.getProperty( "rbsLoginURL" );
            String castGCEndpoint = configProperty.getProperty( "castGCEndpoint" );
            String tokenURL = configProperty.getProperty( "rbsLoginURL" );
            String tokenEndpoint = configProperty.getProperty( "tokenEndpoint" );

            Log.event( "Username - " + userId );
            accessToken = "";
            castgcToken = "";
            Map<String, String> accessTokenHeaders = new HashMap<>();
            Map<String, String> inputData = new HashMap<>();
            accessTokenHeaders.put( "Content-Type", "application/json" );
            String body = "\n" + "{\n" + "  \"username\": \"" + userId + "\",\n" + "  \"password\": \"" + password + "\"\n" + "}";
            JSONObject responseContent = null;

            try {

                Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );
                Log.event( "Response: " + postResponseMap.getBody().asString() + "Status code : " + postResponseMap.getStatusCode() );
                //castgcToken = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( postResponseMap.getBody().asString(), "cookies" ), "CASTGC" );
                responseContent = new JSONObject( postResponseMap.getBody().asString() );
                castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );

            } catch ( Exception e ) {
                try {
                    Log.event( "Expection in generating castgc for (Retrying for same user after 30 sec) " + body );
                    Thread.sleep( 30000 );
                    accessToken = "";
                    Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );

                    responseContent = new JSONObject( postResponseMap.getBody().asString() );
                    castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );
                } catch ( Exception e1 ) {
                    Log.event( "Getting issue while get the CASTGC!!!!. Might be username or password is invalid. " + body );
                }

            }

            accessTokenHeaders.put( "Authorization", configProperty.getProperty( "CASTGC_auth" ) );
            accessTokenHeaders.put( "Content-Type", "application/json" );
            JSONObject postBody = new JSONObject();
            postBody.put( "scope", ReportAPIConstants.RBSS );
            postBody.put( "userId", userIds );
            postBody.put( "clientId", ReportAPIConstants.CLIENT_ID );
            postBody.put( "grant_type", ReportAPIConstants.GRANT_TYPE );
            accessTokenHeaders.put( "castgc", castgcToken );

            try {
                Response postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
                responseContent = new JSONObject( postResponseMap.getBody().asString() );
                accessToken = (String) responseContent.get( "access_token" );

            } catch ( Exception e ) {
                try {
                    Thread.sleep( 3000 );
                    Response postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
                    responseContent = new JSONObject( postResponseMap.getBody().asString() );
                    accessToken = (String) responseContent.get( "access_token" );

                } catch ( Exception e1 ) {
                    Log.event( "Getting issue while get the accesstoken!!!!" );

                }
            }

        } catch ( Exception ex ) {
            ex.printStackTrace();
            Log.event( "No valid username or password found" );

        }

        //headers for authorization
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + accessToken );
        headers.put( ReportAPIConstants.USER_IDs, userIds );
        headers.put( ReportAPIConstants.ORG_IDs, orgId );
        headers.put( "Content-Type", "application/json" );

        if ( currentPage == 0 ) {
            requestBody.put( ReportAPIConstants.CAST_GC, castgcToken );
            requestBody.put( ReportAPIConstants.REQUEST_ID, requestID );
            requestBody.put( ReportAPIConstants.REPORT_TYP, reportType );
            requestBody.put( ReportAPIConstants.RUN_REPORT_TIME, "2022-12-23 06.04 PM" );
            requestBody.put( ReportAPIConstants.PDF_LINKREPORT_TYP, pdfLink );
        } else {
            requestBody.put( ReportAPIConstants.CAST_GC, castgcToken );
            requestBody.put( ReportAPIConstants.REQUEST_ID, requestID );
            requestBody.put( ReportAPIConstants.REPORT_TYP, reportType );
            requestBody.put( ReportAPIConstants.RUN_REPORT_TIME, "2022-12-23 06.04 PM" );
            requestBody.put( ReportAPIConstants.PDF_LINKREPORT_TYP, pdfLink );
            requestBody.put( ReportAPIConstants.PDF_CURRENT_PAGE, currentPage );

        }

        return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody, endPoint );

    }

    /**
     * To check the accesstoken is already present for the given user
     * 
     * @param userId
     */
    public String isAccessTokenPresentForUser( String userName ) {
        if ( usersAccessToken.containsKey( userName ) ) {
            Log.message( "Access Token is exist for the given user. - " + userName + ". so, validating the existing token" );
            if ( validateAccessToken( usersAccessToken.get( userName ) ) ) {
                return usersAccessToken.get( userName );
            }
        }
        return null;
    }

    /**
     * To validate then access token
     * 
     * @param accesstoken
     * @return
     */
    public boolean validateAccessToken( String accesstoken ) {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( "access_token", accesstoken );

        String rbsLoginURL = configProperty.getProperty( "rbsLoginURL" );
        String tokenEndPoint = configProperty.getProperty( "tokenValidEndpoint" );
        try {
            Response response = RestAssuredAPIUtil.PUT( rbsLoginURL + tokenEndPoint, headers );
            return response.getStatusCode() == 200;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To get access token, cast gc and body with header for negative validation
     * 
     * @param smUrl
     * @param userIds
     * @param orgId
     * @param requestID
     * @param reportType
     * @param userId
     * @param password
     * @param runReportTimeData
     * @return
     */
    public Response postSPRExportPDFNegative( String smUrl, String userIds, String orgId, String requestID, String reportType, String userId, String password, String runReportTimeData ) {

        String endPoint = "/pdf-export";
        String accessToken = null;
        String castgcToken = null;
        Map<String, Object> requestBody = new HashMap<>();
        Map<String, String> headers = new HashMap<>();

        try {
            String rbsLoginURL = configProperty.getProperty( "rbsLoginURL" );
            String castGCEndpoint = configProperty.getProperty( "castGCEndpoint" );
            String tokenURL = configProperty.getProperty( "rbsLoginURL" );
            String tokenEndpoint = configProperty.getProperty( "tokenEndpoint" );

            Log.event( "Username - " + userId );

            Map<String, String> accessTokenHeaders = new HashMap<>();
            Map<String, String> inputData = new HashMap<>();
            accessTokenHeaders.put( "Content-Type", "application/json" );
            String body = "\n" + "{\n" + "  \"username\": \"" + userId + "\",\n" + "  \"password\": \"" + password + "\"\n" + "}";
            JSONObject responseContent = null;

            try {

                Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );

                responseContent = new JSONObject( postResponseMap.getBody().asString() );
                castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );

            } catch ( Exception e ) {
                try {
                    Log.event( "Expection in generating castgc for (Retrying for same user after 30 sec) " + body );
                    Thread.sleep( 30000 );
                    Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );

                    responseContent = new JSONObject( postResponseMap.getBody().asString() );
                    castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );
                } catch ( Exception e1 ) {
                    Log.event( "Getting issue while get the CASTGC!!!!. Might be username or password is invalid. " + body );
                }

            }

            accessTokenHeaders.put( "Authorization", configProperty.getProperty( "CASTGC_auth" ) );
            JSONObject postBody = new JSONObject();
            postBody.put( "scope", "test" );
            postBody.put( "userId", responseContent.get( "identityId" ) );
            postBody.put( "clientId", configProperty.getProperty( "clientID" ) );
            postBody.put( "grant_type", "custom_castgc" );
            accessTokenHeaders.put( "Castgc", castgcToken );

            try {
                Response postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
                responseContent = new JSONObject( postResponseMap.getBody().asString() );
                accessToken = (String) responseContent.get( "access_token" );

            } catch ( Exception e ) {
                try {
                    Thread.sleep( 3000 );
                    Response postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
                    responseContent = new JSONObject( postResponseMap.getBody().asString() );
                    accessToken = (String) responseContent.get( "access_token" );

                } catch ( Exception e1 ) {
                    Log.event( "Getting issue while get the accesstoken!!!!" );

                }
            }

        } catch ( Exception ex ) {
            ex.printStackTrace();
            Log.event( "No valid username or password found" );
        }
        //headers for authorization
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + accessToken + "1" );
        headers.put( ReportAPIConstants.USER_IDs, userIds );
        headers.put( ReportAPIConstants.ORG_IDs, orgId );
        headers.put( "Content-Type", "application/json" );

        requestBody.put( ReportAPIConstants.CAST_GC, castgcToken + "b" );
        requestBody.put( ReportAPIConstants.REQUEST_ID_REPORT, requestID );
        requestBody.put( ReportAPIConstants.REPORT_TYP, reportType );
        //requestBody.put( "returnPdfLinks", pdfLink.t );
        requestBody.put( ReportAPIConstants.RUN_REPORT_TIME, runReportTimeData );

        return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody, endPoint );

    }

}
