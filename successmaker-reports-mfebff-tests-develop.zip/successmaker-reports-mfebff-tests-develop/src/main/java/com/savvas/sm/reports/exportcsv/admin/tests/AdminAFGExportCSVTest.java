package com.savvas.sm.reports.exportcsv.admin.tests;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.reports.util.JSONParserUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import io.restassured.response.Response;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminAFGExportCSVTest extends EnvProperties {
    private static String smUrl;
    private static String browser;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String districtAdminDetails;
    List<String> CUSTOM_READING_SELECTED_FILTERS;
    List<String> CUSTOM_MATH_SELECTED_FILTERS;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        distId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        //District Admin
        districtAdminDetails = ReportDataCollection.districtAdminDetails;
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        distAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        distAdminuserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        selectedSchoolId = ReportDataCollection.orgId;

    }

    @Test ( dataProvider = "getData", groups = { "Admin_Dashboard", "SMK-65518", "Admin dashboard Area For Growth Export CSV", "API" }, priority = 1 )
    public void adminARGExportCSVTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        Map<String, Object> payload = JSONParserUtils.getJsonMapFromFile( "report/adminARGExportCSV.json" );
        Response response = null;
        String requestId = null;
        Map<String, Object> saveReportOptionalFilters = new HashMap<>();
        Map<String, Object> optionalFilter = new HashMap<>();
        String exportType = "default";
        Response saveAdminAFGReportOptionResponse = null;
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( distAdminUserName, password ) );
        headers.put( UserConstants.ORGID, distId );
        headers.put( UserConstants.USERID, distAdminuserId );
        Reports report = new Reports();
        AdminReportCsv exportCsv = new AdminReportCsv();

        switch ( scenarioType ) {
            case "DEFAULT_MATH":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = report.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "DEFAULT_READING":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "CUSTOM_MATH":
                exportType = "custom";
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.MATH, CUSTOM_MATH_SELECTED_FILTERS, optionalFilter );
                break;
            case "CUSTOM_READING":
                exportType = "custom";
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, CUSTOM_READING_SELECTED_FILTERS, optionalFilter );
                break;
            case "GROUPING_TEACHER":
                saveReportOptionalFilters.put( "datesAtRisk", "16" );
                saveReportOptionalFilters.put( "additionalGrouping", "TEACHER" );
                optionalFilter.put( "datesAtRisk", 16 );
                optionalFilter.put( "additionalGrouping", 1 );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "GROUPING_GRADE":
                saveReportOptionalFilters.put( "datesAtRisk", "1" );
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                optionalFilter.put( "datesAtRisk", 1 );
                optionalFilter.put( "additionalGrouping", 2 );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "GROUPING_TEACHER_12_WEEK":
                saveReportOptionalFilters.put( "datesAtRisk", "12" );
                saveReportOptionalFilters.put( "additionalGrouping", "TEACHER" );
                optionalFilter.put( "datesAtRisk", 12 );
                optionalFilter.put( "additionalGrouping", 1 );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "GROUPING_GRADE_24_WEEK":
                saveReportOptionalFilters.put( "datesAtRisk", "24" );
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                optionalFilter.put( "datesAtRisk", 24 );
                optionalFilter.put( "additionalGrouping", 2 );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "DISABILITY_STATUS_YES":
                saveReportOptionalFilters.put( "datesAtRisk", "24" );
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                saveReportOptionalFilters.put( "disabilityStatus", Arrays.asList( "YES" ) );
                optionalFilter.put( "datesAtRisk", 24 );
                optionalFilter.put( "additionalGrouping", 2 );
                optionalFilter.put( "disabilityStatus", Arrays.asList( "YES" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "DISABILITY_STATUS_YES_NS":
                saveReportOptionalFilters.put( "datesAtRisk", "24" );
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                saveReportOptionalFilters.put( "disabilityStatus", Arrays.asList( "YES", "NOT_SPECIFIED" ) );
                optionalFilter.put( "datesAtRisk", 24 );
                optionalFilter.put( "additionalGrouping", 2 );
                optionalFilter.put( "disabilityStatus", Arrays.asList( "YES", "NOT_SPECIFIED" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "ENGLISH_YES_NS":
                saveReportOptionalFilters.put( "datesAtRisk", "24" );
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                saveReportOptionalFilters.put( "englishLanguageProficiency", Arrays.asList( "ENGLISH", "NOT_SPECIFIED" ) );
                optionalFilter.put( "datesAtRisk", 24 );
                optionalFilter.put( "additionalGrouping", 2 );
                optionalFilter.put( "englishLanguageProficiency", Arrays.asList( "ENGLISH", "NOT_SPECIFIED" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "ENGLISH_YES":
                saveReportOptionalFilters.put( "englishLanguageProficiency", Arrays.asList( "ENGLISH" ) );
                optionalFilter.put( "englishLanguageProficiency", Arrays.asList( "ENGLISH" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "MIGRANT_YES":
                saveReportOptionalFilters.put( "migrantStatus", Arrays.asList( "MIGRANT" ) );
                optionalFilter.put( "migrantStatus", Arrays.asList( "MIGRANT" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "MIGRANT_MULTIPLE":
                saveReportOptionalFilters.put( "migrantStatus", Arrays.asList( "NON_MIGRANT", "NOT_SPECIFIED" ) );
                optionalFilter.put( "migrantStatus", Arrays.asList( "NON_MIGRANT", "NOT_SPECIFIED" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "ECONOMICAL_DISADVANTAGE":
                saveReportOptionalFilters.put( "socioeconomicStatus", Arrays.asList( "ECONOMICALLY_DISADVANTAGED" ) );
                optionalFilter.put( "socioeconomicStatus", Arrays.asList( "ECONOMICALLY_DISADVANTAGED" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "NON_ED_NS":
                saveReportOptionalFilters.put( "socioeconomicStatus", Arrays.asList( "NOT_ECONOMICALLY_DISADVANTAGED", "NOT_SPECIFIED" ) );
                optionalFilter.put( "socioeconomicStatus", Arrays.asList( "NOT_ECONOMICALLY_DISADVANTAGED", "NOT_SPECIFIED" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "SPECIAL_SERVICE_504":
                saveReportOptionalFilters.put( "specialServices", Arrays.asList( "PLAN_504" ) );
                optionalFilter.put( "specialServices", Arrays.asList( "PLAN_504" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "SPECIAL_SERVICE_MULTIPLE":
                saveReportOptionalFilters.put( "specialServices", Arrays.asList( "PLAN_504", "GIFTED_TALENTED", "IEP", "NO_SPECIAL_SERVICES" ) );
                optionalFilter.put( "specialServices", Arrays.asList( "PLAN_504", "GIFTED_TALENTED", "IEP", "NO_SPECIAL_SERVICES" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "ZERO_STATE":
                saveReportOptionalFilters.put( "specialServices", Arrays.asList( "PLAN_504", "GIFTED_TALENTED", "IEP", "NO_SPECIAL_SERVICES" ) );
                optionalFilter.put( "specialServices", Arrays.asList( "PLAN_504", "GIFTED_TALENTED", "IEP", "NO_SPECIAL_SERVICES" ) );
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "INVALID_USER_ID":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                headers.putIfAbsent( Constants.USERID_SM_HEADER, "ffffffff6595" );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "INVALID_ORG_ID":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                headers.putIfAbsent( Constants.ORGID_SM_HEADER, "8a72071d7e51ae88017e7aef43" );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "EMPTY_ORG_ID":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                headers.putIfAbsent( Constants.ORGID_SM_HEADER, "" );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "EMPTY_USER_ID":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                headers.putIfAbsent( Constants.USERID_SM_HEADER, "" );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "EMPTY_FILTER_SCHOOL":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );

                break;
            case "NO_REPORT_HEADER":
                exportType = "custom";
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "MATH_PASSING_SINGLE_ORG":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "READING_PASSING_SINGLE_ORG":
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "CUSTOM_MATH_PASSING_SINGLE_ORG":
                exportType = "custom";
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.MATH, CUSTOM_MATH_SELECTED_FILTERS, optionalFilter );
                break;
            case "CUSTOM_READING_PASSING_SINGLE_ORG":
                exportType = "custom";
                saveAdminAFGReportOptionResponse = report.saveAdminAFGReportOption( headers, selectedSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminAFGReportOptionResponse.getBody().asString() );
                response = exportCsv.postAFGExportCSVAPI( headers, selectedSchoolId, exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, CUSTOM_READING_SELECTED_FILTERS, optionalFilter );
                break;
        }

        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        if ( !scenarioType.equals( "NO_REPORT_HEADER" ) ) {
            //Verifying Request Id in the upload url and signed Url
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );

            //To get the CSV File
            String csvDataFromBS = null;
            // Get driver
            final WebDriver driver = WebDriverFactory.get( browser );
            try {
                driver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            } catch ( Exception e ) {
                Log.message( "Getting Exception while download the csv file!!!!!" );
            } finally {
                driver.quit();
            }

            Log.assertThat( DevToolsUtils.countLines( csvDataFromBS ) > 0, "Record count is greater than zero", "Record count is zero" );
            Log.assertThat( checkHeader( csvDataFromBS, exportType ), "Expected Header is present", "Expected Header is not present" );
            Log.assertThat( countColumn( csvDataFromBS ) > 0, "Column count is " + countColumn( response.getBody().toString() ), "Expected column is not present" );
        }
    }

    @DataProvider
    public Object[][] getData() {
        Object[][] data = { { "TC:01", "200", "Verify 200 status code and response in case of Default math", "DEFAULT_MATH" }, { "TC:02", "200", "Verify 200 status code and response in case of Default Reading", "DEFAULT_READING" },
                { "TC:03", "200", "Verify 200 status code and response in case of Custom Export Course with data - Math", "CUSTOM_MATH" },
                { "TC:04", "200", "Verify 200 status code and response in case of Custom Export Course with data - READING", "CUSTOM_READING" },
                { "TC:05", "200", "Verify 200 status code and response in case of Custom Export Course with data - Grouping by Teacher", "GROUPING_TEACHER" },
                { "TC:06", "200", "Verify 200 status code and response in case of Custom Export Course with data - Grouping by grade", "GROUPING_GRADE" },
                { "TC:07", "200", "Verify 200 status code and response in case of Custom Export Course with data - Grouping by Teacher and 12 week", "GROUPING_TEACHER_12_WEEK" },
                { "TC:08", "200", "Verify 200 status code and response in case of Custom Export Course with data - Grouping by grade and 24 week", "GROUPING_GRADE_24_WEEK" },
                { "TC:09", "200", "Verify 200 status code and response in case of Custom Export Course with data - Disability Status yes", "DISABILITY_STATUS_YES" },
                { "TC:10", "200", "Verify 200 status code and response in case of Custom Export Course with data - Disability Status yes and not specified", "DISABILITY_STATUS_YES_NS" },
                { "TC:11", "200", "Verify 200 status code and response in case of Course with data - English with Yes and  not specified", "ENGLISH_YES_NS" },
                { "TC:12", "200", "Verify 200 status code and response in case of Course with data - English with yes", "ENGLISH_YES" },
                { "TC:13", "200", "Verify 200 status code and response in case of Course with data - Migrant with Yes value", "MIGRANT_YES" },
                { "TC:14", "200", "Verify 200 status code and response in case of Course with data - Migrant with multiple value", "MIGRANT_MULTIPLE" },
                { "TC:15", "200", "Verify 200 status code and response in case of Course with data - Social Status Economical Disadvantaged", "ECONOMICAL_DISADVANTAGE" },
                { "TC:16", "200", "Verify 200 status code and response in case of Course with data - Social status with non economical disadvantaged and not specified", "NON_ED_NS" },
                { "TC:17", "200", "Verify 200 status code and response in case of Course with data - Special Service with plan 504", "SPECIAL_SERVICE_504" },
                { "TC:18", "200", "Verify 200 status code and response in case of Course with data - Special service with multiple value", "SPECIAL_SERVICE_MULTIPLE" },
                { "TC:19", "200", "Verify 200 status code and response in case of Course with data - Zero state", "ZERO_STATE" }, { "TC:20", "200", "Verify 200 status code and response in case of Course with data - Invalid userId", "INVALID_USER_ID" },
                { "TC:21", "200", "Verify 200 status code and response in case of Course with data - Invalid organizationId", "INVALID_ORG_ID" },
                { "TC:22", "200", "Verify 200 status code and response in case of Course with data - Empty organizationId", "EMPTY_ORG_ID" },
                { "TC:23", "200", "Verify 200 status code and response in case of Course with data - Empty userId", "EMPTY_USER_ID" },
                { "TC:24", "200", "Verify 200 status code and response in case of Course with data - Empty School Filter", "EMPTY_FILTER_SCHOOL" },
                { "TC:25", "500", "Verify 500 status code and response in case of No report header pass in payload", "NO_REPORT_HEADER" },
                { "TC:26", "200", "Verify the area for growth report export Bff response for Math subject , if pass single organization and exportType as default", "MATH_PASSING_SINGLE_ORG" },
                { "TC:26", "200", "Verify the area for growth report export Bff response for Reading subject , if pass single organization and exportType as default", "READING_PASSING_SINGLE_ORG" },
                { "TC:27", "200", "Verify the area for growth report export Bff response for Math subject , if pass single organization and exportType as custom", "CUSTOM_MATH_PASSING_SINGLE_ORG" },
                { "TC:28", "200", "Verify the area for growth report export Bff response for Reading subject , if pass single organization and exportType as custom", "CUSTOM_READING_PASSING_SINGLE_ORG" },

        };
        return data;
    }

    public boolean checkHeader( String str, String exportType ) {
        if ( exportType.equals( "default" ) ) {
            return str.contains( "School" );
        } else {
            return str.contains( "organizationName" );
        }
    }

    public int countColumn( String str ) {
        String[] lines = str.split( "\r\n|\r|\n" );
        return lines[0].split( "," ).length;
    }

}
