package com.savvas.sm.reports.exportcsv.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPRExportCsv;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;

public class AdminCPReportExportCsvTest extends EnvProperties {

	private String smUrl;
    private String browser;
    private String districtAdminUsername;
    private String districtAdminUserId;
    private String districtId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String schoolName;
    private String orgId;
    Map<String, String> headers = new HashMap<>();
    private List<String> teacherUsernames;
    private Map<String, String> teacherUserIds = new HashMap<>();
    List<String> gradeIds = new ArrayList<>();
    private Map<String, String> teacherNames = new HashMap<>();
    Map<String, String> groupDetail = new HashMap<>();
    String[] studentGrades;

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
       
        //To fetch the admin details from Report data
       try {
            districtAdminUsername = ReportDataCollection.districtAdmin;
            districtAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
            districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        } catch ( Exception e ) {
            Log.failsoft( "Getting issue while fetch the admin details from Report data" );
        }
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = ReportDataCollection.orgId;

        //To get teacher Details
        teacherUsernames = new ArrayList<>( ReportDataCollection.teacherDetails.keySet() );
        teacherUsernames.stream().forEach( userName -> teacherUserIds.put( userName, SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), Constants.USERID ) ) );
        teacherUsernames.stream().forEach( userName -> teacherNames.put( userName,
                SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), "firstName" ) + " " + SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), "lastName" ) ) );

        //To get group Detail
        IntStream.range( 0, 2 ).forEach( itr -> groupDetail.put( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( itr ).toString(), "groupId" ),
                SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( itr ).toString(), "groupName" ) ) );

        //To get gradeIds
        studentGrades = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( 0 ).toString(), "studentGradeIds" ).replace( "[", "" ).replace( "]", "" ).split( "," );
        for ( String grade : studentGrades ) {
            if ( grade.length() > 1 ) {
                gradeIds.add( grade );
            } else if ( grade.equals( "k" ) ) {
                gradeIds.add( "KG" );
            } else {
                gradeIds.add( "0" + grade );
            }

        }

    }

    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify Export Report Export Report CSV link appears on top right corner of the report ouput screen" )
    public void tcAdminCPRExportCsv001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv001 - (Admin CPR)Verify Export Report Export Report CSV link appears on top right corner of the report ouput screen" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);

            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.MATH_CPR_COURSE);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH_CPR_COURSE_SELECT) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            SMUtils.logDescriptionTC( "tc001 - (Admin CPR)Verify Export Report CSV link appears on top right corner of the report ouput screen" );
            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();

            SMUtils.logDescriptionTC( "tc002 - (Admin CPR)Verify Export Report CSV popup appears after user click on Export Report CSV link" );
            //Verifying the Export Report CSV popup header
            Log.assertThat( exportPopup.getExportReportCsvPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORT_DATA_HEADER ), "Export Report CSV popup loaded properly after clicked the ecport CSV button",
                    "Export Report CSV popup not loaded properly after clicked the ecport CSV button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc003 - (Admin CPR)Verify the fields available in the Export Report CSV popup" );
            Log.assertThat( exportPopup.getExportTypeLabels().containsAll( Arrays.asList( ReportsUIConstants.EXPORT_DEFAULT, ReportsUIConstants.CUSTOMIZE_EXPORT ) ), "Both Default and custom export labels are present in Export Report CSV popup",
                    " Default and custom export labels are not displaying in Export Report CSV popup. Expected - " + Arrays.asList( ReportsUIConstants.EXPORT_DEFAULT, ReportsUIConstants.CUSTOMIZE_EXPORT ) + ". Actual -"
                            + exportPopup.getExportTypeLabels() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc004 - (Admin CPR)Verify the option selected by default in Export Report CSV popup" );
            Log.assertThat( exportPopup.isDefaultExportRadioButtonSelected(), "Default export radio button is selected by default", "Default export radio button is not selected by default" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc005 - (Admin CPR)Verify clicking on Cancel button button will close the Export Report CSV popup" );
            exportPopup.clickCancelButtonInExportReportCSVPopup();
            Log.assertThat( !exportPopup.isCloseButtonDisplayedInExportReportCSVPopup(), "The Export Report CSV popup closed after clicked the cancel button", "The Export Report CSV popup not closed after clicked the cancel button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc006 - (Admin-CPR) Verify CSV gets Download after user completed their column selection and click OK" );
            exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();
            Log.assertThat( ExportCsvUtils.isCsvFileDownloaded( driver ), "CSV file downloaded properly after clicked the ok Button", "CSV file not downloaded properly after clicked the ok Button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc007 - (Admin CPR)Verify the file name of the downloaded csv for Reading subject" );
            Log.assertThat( ExportCsvUtils.getCsvFileNameFromBS( driver ).contains( "Cumulative Performance" ), "The exported csv file has proper file name.", "The exported csv has not contain Cumulative Performance name." );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify Export Report Export Report CSV link appears when zero state report is generated" )
    public void tcAdminCPRExportCsv002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv002 - (Admin CPR)Verify Export Report CSV link appears when zero state report is generated" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password);

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);

            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.READING_CPR_COURSE );
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING_CPR_COURSE_SELECT ) );
            
            //To Expand optional filter
            cpreportpage.reportFilterComponent.expandOptionalFilters();
            //To select the Grade
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Not Specified" ) );
            
            //Click Run Report button
            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            SMUtils.logDescriptionTC( "tc008 - (Admin-CPR) Verify the delay message popup appears after user clicked OK button in the Export Data popup" );
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );
            Log.testCaseResult();
            
            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc009 - (Admin CPR)Verify Export Report CSV link appears when zero state report is generated" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Log.assertThat( exportedCSVFromUI.isEmpty(), "CSV downloaded properly for zero state", "CSV is not downloaded properly for zero state" );
            Log.testCaseResult();

        }
        catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify the columns available in exported csv for math assignments" )
    public void tcAdminCPRExportCsv003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv003 - (Admin CPR)Verify the columns available in exported csv for math assignments" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password);

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);

            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,  ReportsUIConstants.MATH_CPR_COURSE);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH_CPR_COURSE_SELECT ) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );

            SMUtils.logDescriptionTC( "tc009 - (Admin CPR)Verify the columns available in exported csv for math assignments" );
            Log.assertThat( columnsFromResponse.containsAll( CPRExportCsv.DEFAULT_MATH_HEADERS ), "All colum headers are fetched properly for Math Assignment",
                    "All colum headers are not fetched properly for Math Assignment. Expected -" + CPRExportCsv.DEFAULT_MATH_HEADERS + ".Actual - " + columnsFromResponse );


        }catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
}
    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify the columns available in exported csv for Reading assignments" )
    public void tcAdminCPRExportCsv004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv004 - (Admin CPR)Verify the columns available in exported csv for Reading assignments" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);

            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,  ReportsUIConstants.READING);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );

            SMUtils.logDescriptionTC( "tc010 - (Admin CPR)Verify the columns available in exported csv for reading assignments" );
            Log.assertThat( columnsFromResponse.containsAll( CPRExportCsv.DEFAULT_READING_HEADERS ), "All colum headers are fetched properly for Reading Assignment",
                    "All colum headers are not fetched properly for Reading Assignment. Expected -" + CPRExportCsv.DEFAULT_READING_HEADERS + ".Actual - " + columnsFromResponse );

        }catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
}
    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report")
    public void tcAdminCPRExportCsv005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv005 - Admin CPR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);


            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,  ReportsUIConstants.MATH_CPR_COURSE);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH_CPR_COURSE_SELECT ) );

            //To Expand optional filter
            cpreportpage.reportFilterComponent.expandOptionalFilters();
            //To select the Teachers
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ) ) );
            //To select the Groups
            String groupId = groupDetail.keySet().toArray()[0].toString();
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groupDetail.get( groupId ) ) );
            //To select the Grade
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.GRADE_LABEL + " " + ( studentGrades[0].equals( "13" ) ? studentGrades[1] : studentGrades[0] ) ) );

            //Click Run Report button
            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in Cumulative performance output page!!!", "Export csv icon is not displaying properly in Cumulative performance output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( ExportCsvUtils.isCsvFileDownloaded( driver ), "CSV file downloaded properly after clicked the ok Button", "CSV file not downloaded properly after clicked the ok Button" );
            
            SMUtils.logDescriptionTC( "(Admin CPR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report" );
            String studentName = cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.STUDENT );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Map<String, String> data = new HashMap<>();
            for(Map<String, String> dt : exportedCSVFromUI){
                if(dt.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ).equals( studentName )){
                    data = dt;
                    break;
                }
            }
            Log.message( data.toString() );
            Log.assertThat( studentName.equals( data.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ) ),
                    "Student Name matched in UI and CSV Data", "Student Name not matched in UI and CSV Data" );
            
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL ) ),
                    "Assigned Course Level matched in UI and CSV Data", "Assigned Course Level not matched in UI and CSV Data" );
            Log.testCaseResult();
            
        }catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
}
    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin-CPR) Verify the exported csv when user selected multiple teacher, grade and group in optional filter is used for fetching report")
    public void tcAdminCPRExportCsv006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv006 - Admin CPR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
          //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);


            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,  ReportsUIConstants.MATH_CPR_COURSE);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH_CPR_COURSE_SELECT ) );

            //To Expand optional filter
            cpreportpage.reportFilterComponent.expandOptionalFilters();
            //To select the Teachers
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );
            //To select the Groups
            String groupId = groupDetail.keySet().toArray()[0].toString();
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groupDetail.get( groupId ) ) );
            //To select the Grade
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.GRADE_LABEL + " " + ( studentGrades[0].equals( "13" ) ? studentGrades[1] : studentGrades[0] ) ) );

            //Click Run Report button
            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( ExportCsvUtils.isCsvFileDownloaded( driver ), "CSV file downloaded properly after clicked the ok Button", "CSV file not downloaded properly after clicked the ok Button" );
            
            SMUtils.logDescriptionTC( "(Admin-CPR) Verify the exported csv when user selected multiple teacher, grade and group in optional filter is used for fetching report" );
            String studentName = cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.STUDENT );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Map<String, String> data = new HashMap<>();
            for(Map<String, String> dt : exportedCSVFromUI){
                if(dt.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ).equals( studentName )){
                    data = dt;
                    break;
                }
            }
            Log.message( data.toString() );
            Log.assertThat( studentName.equals( data.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ) ),
                    "Student Name matched in UI and CSV Data", "Student Name not matched in UI and CSV Data" );
            
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL ) ),
                    "Assigned Course Level matched in UI and CSV Data", "Assigned Course Level not matched in UI and CSV Data" );
            Log.testCaseResult();
            
        }catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
}
    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin-CPR) Verify the exported csv when user selected additional grouping option as \"Teacher\" in optional filter is used for fetching report")
    public void tcAdminCPRExportCsv007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv007 - (Admin-CPR) Verify the exported csv when user selected additional grouping option as \"Teacher\" in optional filter is used for fetching report" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);


            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,  ReportsUIConstants.MATH_CPR_COURSE);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH_CPR_COURSE_SELECT ) );

            //To Expand optional filter
            cpreportpage.reportFilterComponent.expandOptionalFilters();

          //To select the teacher option in Additional Grouping
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.TEACHER_LABEL );

            //Click Run Report button
            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            Log.assertThat( ExportCsvUtils.isCsvFileDownloaded( driver ), "CSV file downloaded properly after clicked the ok Button", "CSV file not downloaded properly after clicked the ok Button" );
            
            SMUtils.logDescriptionTC( "(Admin-CPR) Verify the exported csv when user selected additional grouping option as \\\"Teacher\\\" in optional filter is used for fetching report" );
            String studentName = cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.STUDENT );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Map<String, String> data = new HashMap<>();
            for(Map<String, String> dt : exportedCSVFromUI){
                if(dt.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ).equals( studentName )){
                    data = dt;
                    break;
                }
            }
            Log.message( data.toString() );
            Log.assertThat( studentName.equals( data.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ) ),
                    "Student Name matched in UI and CSV Data", "Student Name not matched in UI and CSV Data" );
            
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL ) ),
                    "Assigned Course Level matched in UI and CSV Data", "Assigned Course Level not matched in UI and CSV Data" );
            Log.testCaseResult();
            
        }catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
}
    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify the fields available in the available columns custom export" )
    public void tcAdminCPRExportCsv008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv008 - (Admin CPR)Verify the fields available in the available columns for - Custom Export" + browser + "]</b></i></small>" );

        try {
        	//Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM(districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);


            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,ReportsUIConstants.READING);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING) );

            //Click Run Report button
            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            SMUtils.logDescriptionTC( "tc014 -(Admin-CPR) Verify Popup page is closing by clicking the Close (X) icon" );
            exportPopup.clickCloseButtonInCsvExportPopup();
            Log.assertThat(cpoutputpage.reportOutputComponent.getReportPageTitle().equals("Cumulative Performance"),"Export CSv popup page closed successfully", "Exported csv not able to close");
            
            //Click Export Csv
            cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickCustomizeExportRadioButton();
            
            SMUtils.logDescriptionTC( "tc015 -(Admin CPR)Verify the fields available in the available columns for custom export" );
            List<String> availableColumnsFromUI = exportPopup.getAllAvailableColumns();
            Log.message( availableColumnsFromUI.toString() );
            Log.assertThat( availableColumnsFromUI.containsAll( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS ), "All the custom fields are available for reading",
                    "custom fields are not displaying properly for reading.Expected - " + CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS + ".Actual -" + availableColumnsFromUI );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "tc016-(Admin-CPR) Verify Right double arrow (>>)is active (blue color) when user nothing is selected from the available columns" );
            Log.assertThat( exportPopup.isChevronDoubleRightButtonEnabled(), "Chevron double - right arrow is enabled by default", "Chevron double - right arrow is disabled by default" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "tc017 -(Admin-CPR) Verfiy the user able to selects Single select and mulit select in the Available columns");
            exportPopup.selectAvailableColumns( Arrays.asList(CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 )));
            Log.assertThat( exportPopup.getCheckedAvailableColumns().containsAll( Arrays.asList( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) ),
                    "User able to select the options in available columns", "Getting issue while select the available columns!!!" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "tc018 -(Admin-CPR) Verify the user can transfer selected single values from available columns to selected columns by clicking the Chevoron-right button");
            exportPopup.selectAvailableColumns( Arrays.asList(CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 )));
            exportPopup.clickChevronRightButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 0 ).equals( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ), "Selected field is transffered to selected columns from available columns",
                    "Selected fields is not transffered to selected columns from available columns!!!");
            Log.testCaseResult();
            
            exportPopup.clickChevronDoubleLeftButton();
            SMUtils.logDescriptionTC("tc019- (Admin-CPR) Verify the user can transfer the selected columns values to available columns by clicking the Chevorons-left button");
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.selectSelectedColumns( Arrays.asList( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ) );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( !exportPopup.getAllSelectedColumns().contains( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ), "Single Selected field is transffered to availble columns from selected columns",
                    "Single Selected fields is not transffered to available columns from selected columns!!!");
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("tc020- (Admin-CPR) Verify the user can transfer selected multiple values from selected columns values to available columns by clicking the Chevoron-left button");
            exportPopup.selectSelectedColumns( Arrays.asList( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ), CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( !exportPopup.getAllSelectedColumns().containsAll( Arrays.asList( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ), CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) ),
                    "Multiple Selected field is transffered to availble columns from selected columns", "Multiple Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "tc021 -(Admin-CPR) Verify the user can transfer selected all values from selected columns values to available columns by clicking the Chevoron-left button" );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.selectSelectedColumns( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().isEmpty(), "All Selected field is transffered to available columns from selected columns",
                    "All Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "tc022 -(Admin CPR)Verify the user can move the selected values upwords by clicking Cheron-up in Selected columns" );
            exportPopup.selectAvailableColumns( Arrays.asList( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.selectSelectedColumns( Arrays.asList( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronUpButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 0 ).equals( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ), "user able to move the selected fields upwards by clicking chevron up button",
                    "user unable to move the selected fields upwards by clicking chevron up button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc023 -(Admin CPR)Verify the user can move the selected values downwords by clicking Chevron-down in Selected columns" );
            exportPopup.clickChevronDownButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 1 ).equals( CPRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ), "user able to move the selected fields upwards by clicking chevron down button",
                    "user unable to move the selected fields upwards by clicking chevron down button" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();
            
        }
        catch( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66712", "CPR - Export csv", "smoke_test_case" }, description = "(Admin CPR)Verify Export Report Export Report CSV data with UI" )
    public void tcAdminCPRExportCsv009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv009 - (Admin CPR)Verify Export Report Export Report CSV data with UI - Student" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM(districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            //Expand organization dropdown
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName);

            //Selecting required fields - selecting organization
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL,  Arrays.asList(schoolName) );
            //To select the Subject
            cpreportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpreportpage.reportFilterComponent.expandMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL);
            cpreportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL,  ReportsUIConstants.MATH_CPR_COURSE);
            cpreportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList(ReportsUIConstants.MATH_CPR_COURSE_SELECT) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpreportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc009 - (Admin CPR)Verify Export Report Export Report CSV data with UI" );
            String studentName = cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.STUDENT );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Map<String, String> data = new HashMap<>();
            for(Map<String, String> dt : exportedCSVFromUI){
                if(dt.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ).equals( studentName )){
                    data = dt;
                    break;
                }
            }
            Log.message( data.toString() );
            Log.assertThat( studentName.equals( data.get( "\"" + ReportsUIConstants.CPReportConstant.STUDENT + "\"" ) ),
                    "Student Name matched in UI and CSV Data", "Student Name not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL ) ),
                    "Assigned Course Level matched in UI and CSV Data", "Assigned Course Level not matched in UI and CSV Data" );
            Log.assertThat( compareValues(data.get( "\"" + ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL )),
                    "Current Course Level matched in UI and CSV Data", "Current Course Level not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.IP_LEVEL + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.IP_LEVEL )),
                    "IP Level matched in UI and CSV Data", "IP Level not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.GAIN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.GAIN ) ),
                    "Gain matched in UI and CSV Data", "Gain not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TIME_SPENT + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.TIME_SPENT ) ),
                    "Time Spent matched in UI and CSV Data", "Time Spent not matched in UI and CSV Data" );
            
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS ) ),
                    "Total Sessions matched in UI and CSV Data", "Total Sessions not matched in UI and CSV Data" );
					
			Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + "\""),  cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT )),
                    "Exercises Correct matched in UI and CSV Data", "Exercises Correct not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED ) ),
                    "Exercises Attempted matched in UI and CSV Data", "Exercises Attempted not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + "\"" ),  cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT )),
                    "Exercises Percent Correct matched in UI and CSV Data", "Exercises Percent Correct not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + "\"" ),  cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED )),
                    "Skills Assessed matched in UI and CSV Data", "Skills Assessed not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + "\"" ),  cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_MASTERED )),
                    "Skills Mastered matched in UI and CSV Data", "Skills Mastered not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED  + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED ) ),
                    "Skills Percent Mastered matched in UI and CSV Data", "Skills Percent Mastered not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Assigned Course Level - Mean matched in UI and CSV Data", "Assigned Course Level - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Current Course Level - Mean matched in UI and CSV Data", "Current Course Level - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.MEAN + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "IP Level - Mean matched in UI and CSV Data", "IP Level - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.MEAN + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Gain - Mean matched in UI and CSV Data", "Gain - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Time Spent - Mean matched in UI and CSV Data", "Time Spent - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Total Sessions - Mean matched in UI and CSV Data", "Total Sessions - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Exercises Correct - Mean matched in UI and CSV Data", "Exercises Correct - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Exercises Attempted - Mean matched in UI and CSV Data", "Exercises Attempted - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Exercises Percent Correct - Mean matched in UI and CSV Data", "Exercises Percent Correct - Mean not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Skills Assessed - Mean matched in UI and CSV Data", "Skills Assessed - Mean not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Skills Mastered - Mean matched in UI and CSV Data", "Skills Mastered - Mean not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.MEAN + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.MEAN ) ),
                    "Skills Percent Mastered - Mean matched in UI and CSV Data", "Skills Percent Mastered - Mean not matched in UI and CSV Data" );
					/*
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Assigned Course Level - SD matched in UI and CSV Data", "Assigned Course Level - SD not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Current Course Level - SD matched in UI and CSV Data", "Current Course Level - SD not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "IP Level - SD matched in UI and CSV Data", "IP Level - SD not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION +"\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Gain - SD matched in UI and CSV Data", "Gain - SD not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Time Spent - SD matched in UI and CSV Data", "Time Spent - SD not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Total Sessions - SD matched in UI and CSV Data", "Total Sessions - SD not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\""), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Exercises Correct - SD matched in UI and CSV Data", "Exercises Correct - SD not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Exercises Attempted - SD matched in UI and CSV Data", "Exercises Attempted - SD not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Exercises Percent Correct - SD matched in UI and CSV Data", "Exercises Percent Correct - SD not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Skills Assessed - SD matched in UI and CSV Data", "Skills Assessed - SD not matched in UI and CSV Data" );
					
					Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Skills Mastered - SD matched in UI and CSV Data", "Skills Mastered - SD not matched in UI and CSV Data" );
					
					 Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ), cpoutputpage.getValueOfColumn( ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ),
                    "Skills Percent Mastered - SD matched in UI and CSV Data", "Skills Percent Mastered - SD not matched in UI and CSV Data" );
*/

            Log.testCaseResult();

        }
        catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    public static boolean compareValues(String csvData, String uiData){
        if(csvData.contains( "NA" )){
            if(uiData.equalsIgnoreCase( csvData )){
                return true;
            }else{
                Integer uiDataNumeric = Integer.parseInt( uiData.replaceAll( "[^0-9]", "" ) );
                if(uiDataNumeric==0){
                    return true;
                }else{
                    return false;
                }
            }
        }else{
            return csvData.equalsIgnoreCase( uiData );
        }
    }
}
