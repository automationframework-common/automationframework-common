package com.savvas.sm.reports.admin.ui.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;

public class AdminReportOutputComponent {

    WebDriver driver;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    // ********* SuccessMaker Report Page Elements ***************

    @IFindBy ( how = How.CSS, using = "report-viewer-header h2", AI = false )
    WebElement pageTitle;

    @IFindBy ( how = How.CSS, using = "cel-button.back-btn", AI = false )
    WebElement btnBackRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.next-btn", AI = false )
    WebElement btnNextRoot;

    @IFindBy ( how = How.CSS, using = "h3.assignment-name", AI = false )
    WebElement assignmentName;

    @FindBy ( css = "report-sub-header dl.info dd" )
    List<WebElement> selectedFields;

    @IFindBy ( how = How.CSS, using = "dl.ml-3 dt", AI = false )
    WebElement headerReportRun;

    @FindBy ( css = "dl.info dt" )
    List<WebElement> headersRowInfo;

    @IFindBy ( how = How.CSS, using = "span.ml-2", AI = false )
    WebElement headerSelectedOptions;

    @IFindBy ( how = How.CSS, using = "input.pagination-text-field", AI = false )
    WebElement currentPageNumber;

    @IFindBy ( how = How.CSS, using = "span.error-message", AI = false )
    WebElement noPageNumber;

    @IFindBy ( how = How.CSS, using = "report-viewer-header .pagination-text-suffix", AI = false )
    WebElement totalNumberOfPages;

    @IFindBy ( how = How.CSS, using = "export-data-modal cel-modal.export-data-modal", AI = false )
    WebElement btnExportCSVGrantRoot;

    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> valuesSelectedOptions;

    @FindBy ( css = "div.header-pagination span" )
    List<WebElement> paginationText;

    @FindBy ( css = "demographic-details dl" )
    List<WebElement> selectedDemographics;

    // ****Child Elements****
    private String button = "button.button";
    private String btnExportCSVRoot = "cel-button";
    private String btnExportCSV = "button";

    public BooleanSupplier isNextPagePresent = () -> {
        try {
            if ( isNextBtnEnabled() ) {
                clickNextButton();
                return true;
            }
        } catch ( InterruptedException e ) {
            e.printStackTrace();
        }
        return false;
    };

    /**
     * Constructor to invoke the report component
     * 
     * @param driver
     */
    public AdminReportOutputComponent( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * To get Recent Sessions Report page header
     * 
     * @return
     */
    public String getReportPageTitle() {
        Log.message( "Getting Report Title in Report Output Page " );
        SMUtils.waitForElement( driver, pageTitle );
        return pageTitle.getText().trim();
    }

    /**
     * To check the presence of Back button
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isBackBtnDisplayed() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        Log.message( "Verifying Back button in the Report viewer page" );
        SMUtils.waitForElement( driver, btnBackRoot );
        return SMUtils.isElementPresent( SMUtils.getWebElementDirect( driver, btnBackRoot, button ) );
    }

    /**
     * To check the presence of Next button
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isNextBtnDisplayed() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        Log.message( "Verifying Next button in the Report viewer page" );
        SMUtils.waitForElement( driver, btnNextRoot );
        return SMUtils.isElementPresent( SMUtils.getWebElementDirect( driver, btnNextRoot, button ) );
    }

    /**
     * To verify the next Button
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isNextBtnEnabled() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        if ( isNextBtnDisplayed() ) {
            SMUtils.waitForElement( driver, btnNextRoot );
            return SMUtils.getWebElementDirect( driver, btnNextRoot, button ).isEnabled();
        } else {
            Log.message( "Getting issue while verify the next button!!!" );
            return false;
        }
    }

    /**
     * To verify the Back Button
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isBackBtnEnabled() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        if ( isBackBtnDisplayed() ) {
            SMUtils.waitForElement( driver, btnBackRoot );
            return SMUtils.getWebElementDirect( driver, btnBackRoot, button ).isEnabled();
        } else {
            Log.message( "Getting issue while verify the back button!!!" );
            return false;
        }
    }

    /**
     * To Click the next button
     */
    public void clickNextButton() {
        try {
            SMUtils.waitForElement( driver, btnNextRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnNextRoot, button ) );
            Log.message( "Clicked Next Button..." );
        } catch ( Exception e ) {
            SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnNextRoot, button ) );
            Log.message( "Clicked Next Button..." );
        }
    }

    /**
     * To Click the back button
     */
    public void clickBackButton() {
        try {
            SMUtils.waitForElement( driver, btnNextRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnBackRoot, button ) );
            Log.message( "Clicked Back Button..." );
        } catch ( Exception e ) {
            SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnBackRoot, button ) );
            Log.message( "Clicked Back Button..." );
        }
    }

    /**
     * To get current page number
     * 
     * @return
     */
    public String getCurrentPageNumber() {
        SMUtils.waitForElement( driver, currentPageNumber );
        Log.message( "Current page number = " + currentPageNumber.getAttribute( "value" ) );
        return currentPageNumber.getAttribute( "value" );
    }

    /**
     * To get the total number of pages
     * 
     * @return
     */
    public String getTotalPageNo() {
        SMUtils.waitForElement( driver, currentPageNumber );
        String totalPage = SMUtils.getTextOfWebElement( paginationText.get( 1 ), driver ).split( " " )[1];
        Log.message( "Total Page number - " + totalPage );
        return totalPage;
    }

    /**
     * To verify the pagination text
     * 
     * @return
     */
    public boolean verifyPaginationText() {
        Log.message( "Verifying pagination text" );
        SMUtils.waitForElement( driver, currentPageNumber );
        String totalPage = SMUtils.getTextOfWebElement( paginationText.get( 1 ), driver ).split( " " )[1];
        String prefix = SMUtils.getTextOfWebElement( paginationText.get( 0 ), driver );
        String suffix = SMUtils.getTextOfWebElement( paginationText.get( 1 ), driver );
        return String.format( ReportsUIConstants.PAGINATION_TEXT, totalPage ).equals( prefix + suffix );
    }

    /**
     * This method is used to enter the page number and navigate to that page
     * 
     * @param pageNumber
     * @return
     */
    public boolean goToPage( String pageNumber ) {
        Log.message( "Navigating to the given page number" );
        SMUtils.waitForElement( driver, currentPageNumber );
        currentPageNumber.clear();
        currentPageNumber.sendKeys( pageNumber + Keys.ENTER );
        currentPageNumber.sendKeys( Keys.ENTER );
        return getCurrentPageNumber().equals( pageNumber );
    }

    /**
     * To get the name of an assignment
     * 
     * @return
     */
    public boolean isAssignmentNameDisplayed() {
        Log.message( "Verifying the presence of an assignment name" );
        SMUtils.waitForElement( driver, assignmentName );
        return SMUtils.isElementPresent( assignmentName );
    }

    /**
     * To get the name of an assignment
     * 
     * @return
     */
    public String getAssignmentName() {
        Log.message( "Getting an assignment name" );
        SMUtils.waitForElement( driver, assignmentName );
        return SMUtils.getTextOfWebElement( assignmentName, driver );
    }

    /**
     * To get the selected organization name in Report viewer Page
     * 
     * @throws InterruptedException
     * 
     */
    public String getOrganizationName() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        Log.message( "Getting an organization name" );
        SMUtils.waitForElement( driver, assignmentName );
        return SMUtils.getTextOfWebElement( selectedFields.get( 0 ), driver );
    }

    /**
     * To get the header of Report Run
     * 
     * @return
     */
    public String getReportRunHeader() {
        Log.message( "Getting Report Run header" );
        SMUtils.waitForElement( driver, headerReportRun );
        return SMUtils.getTextOfWebElement( headerReportRun, driver );
    }

    /**
     * To get the info row header
     * 
     * @return
     */
    public List<String> getInfoHeader() {
        Log.message( "Getting the headers of School, Teacher, Grade and Group" );
        SMUtils.waitForElement( driver, headerReportRun );
        return headersRowInfo.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get the header of Selected Options
     * 
     * @return
     */
    public String getSelectedOptionHeader() {
        Log.message( "Getting Selected Options header" );
        SMUtils.waitForElement( driver, headerSelectedOptions );
        return SMUtils.getTextOfWebElement( headerSelectedOptions, driver );
    }

    /**
     * To get the values of Selected Options
     * 
     * @return
     */
    public List<String> getSelectedOptionValues() {
        Log.message( "Getting the values of Selected Options" );
        SMUtils.waitForElement( driver, headerReportRun );
        return valuesSelectedOptions.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To click the Export csv button
     * 
     * @return
     */
    public ExportPopupComponent clickExportCSVButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e2 ) {
            Log.message( "Issue in Spinner loading" );
        }
        SMUtils.waitForElement( driver, btnExportCSVGrantRoot, 30 );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ) );
        ExportPopupComponent exportPopupComponent = null;
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 50 );
            SMUtils.waitForElement( driver, btnExportCSVGrantRoot, 30 );
            SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ) );
            exportPopupComponent = new ExportPopupComponent( driver ).get();
        } catch ( Exception e ) {
            try {
                Log.message( "Getting issue while clicking the csv button...Retrying!!!" + e );
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ) );
                exportPopupComponent = new ExportPopupComponent( driver ).get();
            } catch ( Exception e1 ) {
                Log.fail( "Getting issue while clicking the csv button..." + e1 );
            }
        }
        return exportPopupComponent;
    }

    /**
     * To check the Export csv button is visible or not
     * 
     * @return
     */
    public boolean isExportCSVIconVisible() {
        SMUtils.waitForElement( driver, btnExportCSVGrantRoot, 30 );
        return SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ).isDisplayed();
    }

    /**
     * To get the selected demographics in report ouput page
     * 
     * @throws InterruptedException
     * 
     */
    public Map<String, List<String>> getSelectedDemographics() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        Map<String, List<String>> selectedDemographic = new HashMap<>();
        try {
            SMUtils.waitForElement( driver, headerReportRun );
            selectedDemographics.forEach(
                    parentElement -> selectedDemographic.put( parentElement.findElement( By.cssSelector( "dt" ) ).getText().replace( ":", "" ).trim(), Arrays.asList( parentElement.findElement( By.cssSelector( "dd" ) ).getText().trim().split( ", " ) ) ) );
        } catch ( Exception e ) {
            Log.message( "Getting issue while fetch the selected demographics in output page" );
        }
        return selectedDemographic;
    }

    /**
     * To get the teacher names from Report viewer page
     * 
     * @throws InterruptedException
     */
    public Map<String, List<String>> getAllTeachersFromOutPutPage() throws InterruptedException {
        Map<String, List<String>> teachers = new HashMap<>();
        Log.message( "Getting teachers name in report viewer page" );
        try {
            do {
                SMUtils.waitForSpinnertoDisapper( driver, 60 );
                SMUtils.waitForElement( driver, assignmentName );
                if ( Objects.isNull( teachers.get( selectedFields.get( 0 ).getText().trim() ) ) ) {
                    teachers.put( selectedFields.get( 0 ).getText().trim(), Arrays.asList( selectedFields.get( 1 ).getText().trim() ) );
                } else {

                    List<String> teacherList = new ArrayList<>( teachers.get( selectedFields.get( 0 ).getText().trim() ) );
                    teacherList.add( selectedFields.get( 1 ).getText().trim() );
                    teachers.put( selectedFields.get( 0 ).getText().trim(), teacherList );
                }
            } while ( isNextPagePresent.getAsBoolean() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while fetching the teacher name in Report viewer page" );
        }
        return teachers;

    }

    /**
     * To get the group names from Report viewer page
     * 
     * @throws InterruptedException
     */
    public Map<String, List<String>> getAllGroupsFromOutPutPage() throws InterruptedException {
        Map<String, List<String>> groups = new HashMap<>();
        Log.message( "Getting teachers name in report viewer page" );
        try {
            do {
                SMUtils.waitForSpinnertoDisapper( driver, 60 );
                SMUtils.waitForElement( driver, assignmentName );
                if ( Objects.isNull( groups.get( selectedFields.get( 0 ).getText().trim() ) ) ) {
                    groups.put( selectedFields.get( 0 ).getText().trim(), Arrays.asList( selectedFields.get( 3 ).getText().trim() ) );
                } else {
                    List<String> groupList = new ArrayList<>( groups.get( selectedFields.get( 0 ).getText().trim() ) );
                    groupList.add( selectedFields.get( 3 ).getText().trim() );
                    groups.put( selectedFields.get( 0 ).getText().trim(), groupList );
                }
            } while ( isNextPagePresent.getAsBoolean() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while fetching the groups name in Report viewer page" );
        }
        return groups;

    }

}
