package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.LastSessionConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class LastSessionReportGrid extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String organizationName;
    private String mathIPCompleted;
    private String mathIPNotCompleted;
    private String mathSettingIPOnCompleted;
    private String mathSettingIPOnNotCompleted;
    private String mathSettingIPOff;
    private String mathSkill;
    private String mathStandard;
    private String readingIPCompleted;
    private String readingIPNotCompleted;
    private String readingSettingIPOnCompleted;
    private String readingSettingIPOnNotCompleted;
    private String readingSettingIPOff;
    private String readingSkill;
    private String readingStandard;
    private String firstStudent;
    private String secondStudent;
    private String teacherUserName;
    private String mathSettingIPOnCourse;
    private String mathSettingIPOffCourse;
    private String mathSkillCourse;
    private String mathStandardCourse;
    private String readingSettingIPOnCourse;
    private String readingSettingIPOffCourse;
    private String readingSkillCourse;
    private String readingStandardCourse;
    private String firstStudentID;
    private String secondStudentID;

    @BeforeClass
    public void initTest() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String envUrl = smUrl.substring( 8 ); // To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        // Getting District admin username and password
        username = String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        // Getting student username
        teacherUserName = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 1, usernameSuffixTest );
        firstStudent = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 1, usernameSuffixTest );
        secondStudent = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 3, usernameSuffixTest );

        RBSUtils rbsUtils = new RBSUtils();

        // Getting studentID
        firstStudentID = rbsUtils.getUserIDByUserName( firstStudent );
        secondStudentID = rbsUtils.getUserIDByUserName( secondStudent );

        // Getting Math course name
        mathSettingIPOnCourse = SMUtils.getKeyValueFromResponse( ReportData.mathSettingIPMONAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );
        mathSettingIPOffCourse = SMUtils.getKeyValueFromResponse( ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );
        mathSkillCourse = SMUtils.getKeyValueFromResponse( ReportData.mathSkillAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );
        mathStandardCourse = SMUtils.getKeyValueFromResponse( ReportData.mathStandardAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );

        // Getting Reading course name
        readingSettingIPOnCourse = SMUtils.getKeyValueFromResponse( ReportData.readingSettingIPMONAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );
        readingSettingIPOffCourse = SMUtils.getKeyValueFromResponse( ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );
        readingSkillCourse = SMUtils.getKeyValueFromResponse( ReportData.readingSkillAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );
        readingStandardCourse = SMUtils.getKeyValueFromResponse( ReportData.readingStandardAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "courseDetail,name" );

        // Getting Math Student assignment ID
        mathIPCompleted = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "studentAssignmentId" );
        mathIPNotCompleted = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        mathSettingIPOnCompleted = SMUtils.getKeyValueFromResponse( ReportData.mathSettingIPMONAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "studentAssignmentId" );
        mathSettingIPOnNotCompleted = SMUtils.getKeyValueFromResponse( ReportData.mathSettingIPMONAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        mathSettingIPOff = SMUtils.getKeyValueFromResponse( ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        mathSkill = SMUtils.getKeyValueFromResponse( ReportData.mathSkillAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        mathStandard = SMUtils.getKeyValueFromResponse( ReportData.mathStandardAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );

        // Getting Reading Student assignment ID
        readingIPCompleted = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "studentAssignmentId" );
        readingIPNotCompleted = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        readingSettingIPOnCompleted = SMUtils.getKeyValueFromResponse( ReportData.readingSettingIPMONAssignmentDetails.get( teacherUserName ).get( firstStudentID ), "studentAssignmentId" );
        readingSettingIPOnNotCompleted = SMUtils.getKeyValueFromResponse( ReportData.readingSettingIPMONAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        readingSettingIPOff = SMUtils.getKeyValueFromResponse( ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        readingSkill = SMUtils.getKeyValueFromResponse( ReportData.readingSkillAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );
        readingStandard = SMUtils.getKeyValueFromResponse( ReportData.readingStandardAssignmentDetails.get( teacherUserName ).get( secondStudentID ), "studentAssignmentId" );

    }

    @Test ( description = "Verify Current Course Level and Raw Performance for Math course ", groups = { "SMK-61284", "Last Session", "Data Grid" }, priority = 1 )
    public void smLSReportGrid_001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smLSReportGrid_001: Verify Current Course Level and Raw Performance for Default Math course. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Get the values form DB
            SqlHelperCourses dbQuery = new SqlHelperCourses();

            RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for Default Math course when student is not completed 'IP' " );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            lastSession.reportFilterComponent.expandOptionalFilter();
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            outputPage.clickRunReportButton();

            float exercisesCorrect = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 1 ) );
            float exercisesAttempted = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 2 ) );
            String dateFormat = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 5 ) );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( ReportsUIConstants.LastSessionConstants.NO_DATA.get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect, exercisesAttempted ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathIPNotCompleted ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dateFormat ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            SMUtils.logDescriptionTC( "Verify Mean by Calculate avarage of the total values in a columns" );

            Log.assertThat( outputPage.totalColumnvaluesCompareMeanValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 1 ) ), "The Exercises Correct mean value is displaying successfully",
                    "The Exercises Correct mean value is not displaying properly" );
            Log.assertThat( outputPage.totalColumnvaluesCompareMeanValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 2 ) ), "The Exercises Attempted mean value is displaying successfully",
                    "The Exercises Attempted mean value is not displaying properly" );
            Log.assertThat( outputPage.totalColumnvaluesCompareMeanValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 4 ) ), "The Help Used mean value is displaying successfully", "The Help Used mean value is not displaying properly" );
            Log.assertThat( outputPage.totalColumnvaluesCompareMeanValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 6 ) ), "The Total Sessions mean value is displaying successfully",
                    "The Total Sessions mean value is not displaying properly" );

            SMUtils.logDescriptionTC( "Verify Standard Deviation by calculate standard deviation of all the columns" );

            Log.assertThat( outputPage.totalColumnvaluesCompareStandardDeviationValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 1 ) ), "The Exercises Correct Standard Deviation value is displaying successfully",
                    "The Exercises Correct Standard Deviation value is not displaying properly" );
            Log.assertThat( outputPage.totalColumnvaluesCompareStandardDeviationValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 2 ) ), "The Exercises Attempted Standard Deviation value is displaying successfully",
                    "The Exercises Attempted Standard Deviation value is not displaying properly" );
            Log.assertThat( outputPage.totalColumnvaluesCompareStandardDeviationValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 4 ) ), "The Help Used Standard Deviation value is displaying successfully",
                    "The Help Used Standard Deviation value is not displaying properly" );
            Log.assertThat( outputPage.totalColumnvaluesCompareStandardDeviationValue( ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.get( 6 ) ), "The Total Sessions Standard Deviation value is displaying successfully",
                    "The Total Sessions Standard Deviation value is not displaying properly" );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for Default Math course when student is completed 'IP'" );
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for Default Math course when student is completed few sessions after 'IP' completion" );
            float exercisesCorrect1 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 1 ) );
            float exercisesAttempted1 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 2 ) );
            String dateFormat1 = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 5 ) );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 0 ).equals( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect1, exercisesAttempted1 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathIPCompleted ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 7 ).equals( dateFormat1 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );
            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting -Math(IP-off) when student is not completed IP" );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( mathSettingIPOffCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect2 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 1 ) );
            float exercisesAttempted2 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 2 ) );
            String dateFormat4 = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 5 ) );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect2, exercisesAttempted2 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOff ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dateFormat4 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting -Math(IP-on) course when student is completed 'IP'" );
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting -Math(IP-on) course when student is completed few sessions after 'IP' completion" );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( mathSettingIPOnCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect3 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 1 ) );
            float exercisesAttempted3 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 2 ) );
            String dateFormat2 = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 5 ) );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 0 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect3, exercisesAttempted3 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnCompleted ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( firstStudent ).get( 7 ).equals( dateFormat2 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting -Math(IP-on) when student is not completed 'IP'" );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( mathSettingIPOnCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect4 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 1 ) );
            float exercisesAttempted4 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 2 ) );
            String dateFormat3 = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 5 ) );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 2 ) ),
                    "The Exercises Attempted values are displaying successfully ", "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect4, exercisesAttempted4 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathSettingIPOnNotCompleted ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dateFormat3 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by Skill Math when student is not completed \"IP\"" );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( mathSkillCourse ) );

            outputPage.clickRunReportButton();
            float exercisesCorrect5 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 1 ) );
            float exercisesAttempted5 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 2 ) );
            String dateFormat5 = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 5 ) );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 1 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect5, exercisesAttempted5 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathSkill ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dateFormat5 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );
            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by Standard Math when student is not completed \"IP\" " );

            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( mathStandardCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect6 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 1 ) );
            float exercisesAttempted6 = Float.parseFloat( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 2 ) );
            String dateFormat6 = outputPage.dateFormat( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 5 ) );

            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 1 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect6, exercisesAttempted6 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 3 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( dbQuery.getLastSessionMathGridValues( mathStandard ).get( 6 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getMathCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dateFormat6 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Current Course Level and Raw Performance for reading course ", groups = { "SMK-61284", "Last Session", "Data Grid" }, priority = 1 )
    public void smLSReportGrid_002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smLSReportGrid_002: Verify Current Course Level and Raw Performance for reading course. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Getting values from DB
            SqlHelperCourses dbQuery = new SqlHelperCourses();

            RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

            // Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for Default Reading course when student is not completed 'IP'" );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );
            lastSession.reportFilterComponent.expandOptionalFilter();
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            outputPage.clickRunReportButton();

            float exercisesCorrect = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 1 ) );
            float exercisesAttempted = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 2 ) );
            String dateFormat = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 11 ) );
            String instructional = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 4 ) );
            String independentPractice = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 6 ) );
            String remediation = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 2 ) ),
                    "The Exercises Attempted values are displaying successfully ", "The Exercises Attempted values are not displaying properly" );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect, exercisesAttempted ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( instructional ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 5 ).equals( independentPractice ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( remediation ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 9 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPNotCompleted ).get( 12 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 10 ).equals( dateFormat ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for Default Reading course when student is completed  'IP'" );
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for Default Reading course when student is completed few sessions after 'IP' completion" );

            float exercisesCorrect1 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 1 ) );
            float exercisesAttempted1 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 2 ) );
            String dateFormat1 = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 11 ) );
            String instructional1 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 4 ) );
            String independentPractice1 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 6 ) );
            String remediation1 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 0 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect1, exercisesAttempted1 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 4 ).equals( instructional1 ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 5 ).equals( independentPractice1 ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 6 ).equals( remediation1 ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 9 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingIPCompleted ).get( 12 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 10 ).equals( dateFormat1 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );
            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting Reading(IP-on) course when student is completed \"IP\"" );
            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting Reading(IP-on) when student is completed few sessions after 'IP' completion" );

            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( readingSettingIPOnCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect2 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 1 ) );
            float exercisesAttempted2 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 2 ) );
            String dateFormat2 = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 11 ) );
            String instructional2 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 4 ) );
            String independentPractice2 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 6 ) );
            String remediation2 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 0 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 0 ) ),
                    "The current course level values are displaying successfully ", "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 1 ) ),
                    "The Exercises Correct values are displaying successfully ", "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 2 ) ),
                    "The Exercises Attempted values are displaying successfully ", "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect2, exercisesAttempted2 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 4 ).equals( instructional2 ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 5 ).equals( independentPractice2 ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 6 ).equals( remediation2 ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 9 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnCompleted ).get( 12 ) ),
                    "The Total Session values are displaying successfully ", "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( firstStudent ).get( 10 ).equals( dateFormat2 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting Reading(IP-off) when student is not completed \"IP\"" );

            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( readingSettingIPOffCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect3 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 1 ) );
            float exercisesAttempted3 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 2 ) );
            String dateFormat3 = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 11 ) );
            String instructional3 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 4 ) );
            String independentPractice3 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 6 ) );
            String remediation3 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 0 ) ),
                    "The current course level values are displaying successfully ", "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect3, exercisesAttempted3 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( instructional3 ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 5 ).equals( independentPractice3 ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( remediation3 ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 9 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOff ).get( 12 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 10 ).equals( dateFormat3 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by skill Reading when student is not completed \"IP\" " );

            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( readingSkillCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect4 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 1 ) );
            float exercisesAttempted4 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 2 ) );
            String dateFormat4 = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 11 ) );
            String instructional4 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 4 ) );
            String independentPractice4 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 6 ) );
            String remediation4 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 1 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect4, exercisesAttempted4 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( instructional4 ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 5 ).equals( independentPractice4 ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( remediation4 ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 9 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingSkill ).get( 12 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 10 ).equals( dateFormat4 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by Standard Reading when student is not completed \"IP\" " );

            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( readingStandardCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect5 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 1 ) );
            float exercisesAttempted5 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 2 ) );
            String dateFormat5 = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 11 ) );
            String instructional5 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 4 ) );
            String independentPractice5 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 6 ) );
            String remediation5 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 1 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 1 ) ), "The Exercises Correct values are displaying successfully ",
                    "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 2 ) ), "The Exercises Attempted values are displaying successfully ",
                    "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect5, exercisesAttempted5 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( instructional5 ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 5 ).equals( independentPractice5 ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( remediation5 ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 9 ) ), "The Help used values are displaying successfully ",
                    "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingStandard ).get( 12 ) ), "The Total Session values are displaying successfully ",
                    "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 10 ).equals( dateFormat5 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );

            SMUtils.logDescriptionTC( "Verify Current Course Level and Raw Performance for custom by setting Reading(IP-on) course when student is not completed \\\"IP\\\"" );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( readingSettingIPOnCourse ) );

            outputPage.clickRunReportButton();

            float exercisesCorrect6 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 1 ) );
            float exercisesAttempted6 = Float.parseFloat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 2 ) );
            String dateFormat6 = outputPage.dateFormat( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 11 ) );
            String instructional6 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 3 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 4 ) );
            String independentPractice6 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 5 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 6 ) );
            String remediation6 = outputPage.exercisesCorrectAndAttempted( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 7 ), dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 8 ) );

            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 0 ).equals( LastSessionConstants.NO_DATA.get( 0 ) ), "The current course level values are displaying successfully ",
                    "The current course level values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 1 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 1 ) ),
                    "The Exercises Correct values are displaying successfully ", "The Exercises Correct values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 2 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 2 ) ),
                    "The Exercises Attempted values are displaying successfully ", "The Exercises Attempted values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 3 ).equals( outputPage.totalPercentange( exercisesCorrect6, exercisesAttempted6 ) ), "The Total percent correct value is displaying successfully",
                    "The Total percent correct value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 4 ).equals( instructional6 ), "The instructional value is displaying successfully", "The instructional value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( "Fausto Frami" ).get( 5 ).equals( independentPractice6 ), "The independent practice value is displaying successfully",
                    "The independent practice value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 6 ).equals( remediation6 ), "The remediation value is displaying successfully", "The remediation value is not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 7 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 9 ) ),
                    "The Help used values are displaying successfully ", "The Help used values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 9 ).equals( dbQuery.getLastSessionReadingGridValues( readingSettingIPOnNotCompleted ).get( 12 ) ),
                    "The Total Session values are displaying successfully ", "The Total Sessions values are not displaying properly" );
            Log.assertThat( outputPage.getReadingCurrentCourseLevelAndRawPerformance( secondStudent ).get( 10 ).equals( dateFormat6 ), "The Session Date values are displaying successfully ", "The Session Date values are not displaying properly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}