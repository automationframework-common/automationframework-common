package com.savvas.sm.reports.ui.tests.teacher;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.reports.util.JSONParserUtils;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.LastSessionConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.ReportConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.response.Response;

public class LastSessionReportOutputMFEIntegrateWithBFF extends EnvProperties {

	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String teacherDetails;
	String orgId;
	String teacherId;
	String student1;
	String username;
	String studentId;
	String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	int mathAssignmentId;
	int mathCustomAssignmentId;
	int readingAssignmentId;
	int readingCustomAssignmentId;
	HashMap<String, String> groupDetails = new HashMap<>();
	HashMap<String, String> assignmentIds = new HashMap<>();
	HashMap<String, String> newAssignmentIds = new HashMap<>();
	HashMap<String, String> newGroupDetails = new HashMap<>();

	private String smUrl;
	private String browser;

	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();
	private List<String> courseIDs = new ArrayList<>();

	private String studentDetail = null;
	private String studentUsername;
	private String newGroupID;

	private static List<String> studentRumbaIds = new ArrayList<>();
	static String TEACHER_LSR_PAYLOAD = "{\"operationName\":\"GetLSReportData\",\"variables\":{\"teacherId\":\"{teacherId}\",\"organizationId\":\"{organizationId}\",\"subject\":{subjectId},\"isGroupSelected\":{groupSelected},\"studentIds\":[\"{studentId}\"]}}";

	String payload = null;
	String query;
	Response response = null;

	@BeforeClass(alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		orgId = RBSDataSetup.organizationIDs.get(school);

		// Teacher Details
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		// Student Details
		studentDetail = RBSDataSetup.getMyStudent(school, username);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetail, Constants.USER_NAME);
		studentId = SMUtils.getKeyValueFromResponse(studentDetail, "userId");

		studentRumbaIds.add(studentId);

		studentRumbaIds.add(
				SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student1"), "userId"));
		studentRumbaIds.add(
				SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student2"), "userId"));
		String token = new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		newGroupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, "userName"), RBSDataSetupConstants.DEFAULT_PASSWORD));
		newGroupDetails.put(GroupConstants.GROUP_OWNER_ID, teacherId);
		newGroupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, orgId);
		newGroupDetails.put(GroupConstants.GROUP_NAME, "groupName");

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, "userName"), RBSDataSetupConstants.DEFAULT_PASSWORD));

		Log.message("Created Group" + new GroupAPI().createGroup(smUrl, newGroupDetails, studentRumbaIds));
		HashMap<String, String> groupDetailNew = new GroupAPI().createGroup(smUrl, newGroupDetails, studentRumbaIds);
		newGroupID = SMUtils.getKeyValueFromResponse(groupDetailNew.get(Constants.REPORT_BODY), "data,groupId");

		contentBaseName.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE);
		contentBaseName.put(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime()));

		contentBaseName.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE);
		contentBaseName.put(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime()));

		Log.message("contentbasename: " + contentBaseName);

		contentBase.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH);
		contentBase.put(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				new CourseAPI().createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
						orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName
								.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));

		contentBase.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING);
		contentBase.put(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				new CourseAPI().createCourse(smUrl, token, DataSetupConstants.READING, teacherId.toString(),
						orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName
								.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));

		courseIDs.add(contentBase.get(AssignmentAPIConstants.MATH_COURSE));
		courseIDs.add(contentBase.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE));

		courseIDs.add(contentBase.get(AssignmentAPIConstants.READING_COURSE));
		courseIDs.add(contentBase.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE));

		Log.message("Assigning assignment...");

		HashMap<String, String> assignmentResponseNew = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, studentRumbaIds, courseIDs);
		Log.message("Assignment Details" + assignmentResponseNew);
		String string = assignmentResponseNew.get(4);
		Log.message("readingcustomsetting " + string);

		JSONObject assignmentDetailsJson = new JSONObject(assignmentResponseNew.get(Constants.REPORT_BODY));
		JSONArray assignmentList = assignmentDetailsJson.getJSONArray(Constants.DATA);
		for (Object assignment : assignmentList) {
			JSONObject assignmentInfo = new JSONObject(assignment.toString());
			assignmentIds.put(assignmentInfo.get("assignmentName").toString(),
					assignmentInfo.get("assignmentId").toString());
		}
		Log.message("Assignment Ids - " + assignmentIds);
		mathAssignmentId = Integer.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));
		mathCustomAssignmentId = Integer.parseInt(assignmentIds
				.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));
		readingAssignmentId = Integer
				.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.READING_COURSE)));
		readingCustomAssignmentId = Integer.parseInt(assignmentIds.get(
				contentBaseName.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));
		try {
			executeCourse(studentUsername, contentBaseName.get(AssignmentAPIConstants.MATH_COURSE), true);
			executeCourse(studentUsername,
					contentBaseName.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE),
					true);

			executeCourse(studentUsername, contentBaseName.get(AssignmentAPIConstants.READING_COURSE), false);
			executeCourse(studentUsername,
					contentBaseName.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE),
					false);
		} catch (IOException e) {
			e.printStackTrace();
		}

		JSONObject assignmentDetailsJsonNew = new JSONObject(assignmentResponseNew.get(Constants.REPORT_BODY));
		Log.message("assignmentDetailsJsonNew" + assignmentDetailsJsonNew);
		JSONArray assignmentListNew = assignmentDetailsJsonNew.getJSONArray(Constants.DATA);

		for (Object assignmentNew : assignmentListNew) {
			JSONObject assignmentInfoNew = new JSONObject(assignmentNew.toString());
			newAssignmentIds.put(assignmentInfoNew.get("assignmentName").toString(),
					assignmentInfoNew.get("assignmentId").toString());
		}
		Log.message("Assignment IDs - " + newAssignmentIds);

	}

	@Test(description = "Verify Last session header option should present under the Reports menu.", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF01(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"Verify Last session Assignment name, school, teacher, grade, group option should present under the Reports menu.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();

			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Last session Course name, school, teacher, grade, group option should present under the Reports menu", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF02(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Last session header option should present under the Reports menu.<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			// Verify the Assignment name is getting displayed in the Last session Report
			Log.assertThat(outputPage.isAssignmentNameDisplayed(), "Assignment Name is getting displayed successfully",
					"Assignment Name is not getting displayed");
			// Verify the Date and time is getting displayed in a prescribed format under
			// report run in the LSR
			Log.assertThat(outputPage.validateRunReportDate(), "Report Run Date is in correct format",
					"Report Run Date is not in correct format");

			// Verify the School name, Teacher Name , Grade level.& Group name is getting
			// displayed in the LSR
			Log.assertThat(outputPage.isInfoHeaderValuesDisplaying(), "Info Header values are getting displayed",
					"Info Header values are not getting displayed");
			List<String> infoHeaders = outputPage.reportOutputComponent.getInfoHeader();
			IntStream.range(0, infoHeaders.size()).forEach(itr -> {
				Log.assertThat(infoHeaders.get(itr).equals(ReportsUIConstants.INFO_LABELS.get(itr)),
						infoHeaders.get(itr) + " is displayed in the LSR report Viewer",
						ReportsUIConstants.INFO_LABELS.get(itr) + " is not displayed in the LSR report Viewer");

			});

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Last session selected options text should present under the Reports menu.", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF03(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"Verify Last session selected options text should present under the Reports menu.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			// Verify the selected options are getting displayed in a Prescribed Format in
			Log.assertThat(
					outputPage.reportOutputComponent.getSelectedOptionHeader()
							.equals(ReportsUIConstants.SELECTED_OPTION_HEADER2),
					"Selected Options is getting displayed successfully", "Selected Options is not getting displayed");
			Log.assertThat(
					outputPage.reportOutputComponent.getSelectedOptionValues().containsAll(
							outputPage.defaultSelectedOptions()),
					"Selected options is getting displayed properly",
					"Selected options is not getting displayed properly");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Last session \"Legends\" should present under the Reports menu.", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF04(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify Last session \"Legends\" should present under the Reports menu.<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			// Verify the legends are displayed in the AFG Output UI
			Log.assertThat(outputPage.verifyLegendHeaderAndLabelsChecking(),
					"Legend Header and Labels are getting displayed properly",
					"Legend Header and Labels are not getting displayed properly");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Last session \"Notes\" option and text should present under the Reports menu.", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF05(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"Verify Last session \\\"Notes\\\" option and text should present under the Reports menu.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			// Verify the selected options are getting displayed in a Prescribed Format in
			Log.assertThat(outputPage.verifyNotesLabelChecking(), "Notes Labels are getting displayed properly",
					"Notes Labels are not getting displayed properly");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Validate all colum data grid values for Math assignment", groups = { "SMK-68047",
			"Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF06(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Validate all colum data grid values for Math assignment<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			Log.message("Uncheck all checkbox");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));
			Log.message("check Math only");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADER, Arrays.asList("Math"));
			recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.DISPLAY_DROPDOWN, ReportsUIConstants.STUDENT_USERNAME);
			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			Log.testCaseInfo("Verify the \"Student\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Current Course Level (Level)\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Exercises Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Attempted (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Percent Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Help used (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Time Spent (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Total Sessions (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Session Date (Usage)\" column,the given input page data reflected to the output  ");

			// Getting data from UI
			Map<String, Map<String, String>> dataFromUI = outputPage.getMathGridValues();
			dataFromUI.remove(adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get(3));
			dataFromUI.remove(adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get(7));
			String stringOldDate = dataFromUI.get(studentUsername).get("sessionDate");
			Log.message("String old: " + stringOldDate);

			String datenew = dateFormatMethod(stringOldDate);
			Log.message("String new: " + datenew.toString());

			String timespent;
			timespent = dataFromUI.get(studentUsername).get("timeSpent");
			Log.message("old timespent: " + timespent.toString());

			String value = null;
			if (timespent.contains("*")) {
				String timeSpentreplace = timespent.replace("*", "");
				Log.message("new timespent: " + timeSpentreplace);
				value = roundoffValue(timeSpentreplace);
			} else {
				Log.message("new timespent: " + timespent);
				value = roundoffValue(timespent);

			}
			String exercisesPercentCorrect = dataFromUI.get(studentUsername).get("exercisesPercentCorrect");
			String replacePercent = exercisesPercentCorrect.replace("%", ".00%");
			Log.message(replacePercent);

			// Getting data from Graphql
			HashMap<String, String> headers = new HashMap<>();
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.USERID_SM_HEADER, teacherId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			headers.put(Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(username, password));

			payload = getResponseBody(teacherId, orgId, 1, false, Arrays.asList(newGroupID), Arrays.asList(studentId),
					Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			String asString = response.getBody().asString();

			HashMap<String, String> dataFromGraphql = getDataFromResponse(asString,
					contentBaseName.get(AssignmentAPIConstants.MATH_COURSE));
			Log.message("Graphql response - " + dataFromGraphql.toString());

			// validate values
			Log.assertThat(
					dataFromUI.get(studentUsername).get("exercisesAttempted")
							.equals(dataFromGraphql.get("exercisesAttempted")),
					"exercisesAttempted is expected", "exercisesAttempted is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("totalSessions").equals(dataFromGraphql.get("totalSessions")),
					"totalSessions is expected", "totalSessions is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("exercisesCorrect")
							.equals(dataFromGraphql.get("exercisesCorrect")),
					"exercisesCorrect is expected", "exercisesCorrect is not expected");
			Log.assertThat(dataFromUI.get(studentUsername).get("helpUsed").equals(dataFromGraphql.get("helpUsed")),
					"helpUsed is expected", "helpUsed is not expected");
			Log.assertThat(datenew.equals(dataFromGraphql.get("sessionStartDate")), "sessionStartDate is expected",
					"sessionStartDate is not expected");
			Log.assertThat(replacePercent.equals(dataFromGraphql.get("exercisesPercentCorrect")),
					"exercisesPercentCorrect is expected", "exercisesPercentCorrect is not expected");
			Log.assertThat(value.equals(dataFromGraphql.get("timeSpent")), "timeSpent is expected",
					"timeSpent is not expected");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Validate all colum data grid values for Reading assignment", groups = { "SMK-68047",
			"Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF07(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Validate all colum data grid values for Reading assignment<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.READING);

			Log.message("Uncheck all checkbox");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));
			Log.message("check Reading only");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADER, Arrays.asList("Reading"));

			recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.DISPLAY_DROPDOWN, ReportsUIConstants.STUDENT_USERNAME);
			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			Log.testCaseInfo("Verify the \"Student\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Current Course Level (Level)\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Exercises Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Attempted (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Percent Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Help used (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Time Spent (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Total Sessions (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Session Date (Usage)\" column,the given input page data reflected to the output  ");

			// Getting data from UI
			Map<String, Map<String, String>> dataFromUI = outputPage.getReadingGridValues();

			String stringOldDate = dataFromUI.get(studentUsername).get("Session Date");
			Log.message("String old: " + stringOldDate);

			String datenew = dateFormatMethod(stringOldDate);
			Log.message("String new: " + datenew.toString());

			String timespent;
			timespent = dataFromUI.get(studentUsername).get("Time Spent");
			Log.message("old timespent: " + timespent.toString());

			String value = null;
			if (timespent.contains("*")) {
				String timeSpentreplace = timespent.replace("*", "");
				Log.message("new timespent: " + timeSpentreplace);
				value = roundoffValue(timeSpentreplace);
			} else {
				Log.message("new timespent: " + timespent);
				value = roundoffValue(timespent);

			}
			String exercisesPercentCorrect = dataFromUI.get(studentUsername).get("Exercises Percent Correct");
			String replacePercent = exercisesPercentCorrect.replace("%", ".00%");
			Log.message(replacePercent);

			// Getting data from Graphql
			HashMap<String, String> headers = new HashMap<>();
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.USERID_SM_HEADER, teacherId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			headers.put(Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(username, password));

			payload = getResponseBody(teacherId, orgId, 2, false, Arrays.asList(newGroupID), Arrays.asList(studentId),
					Arrays.asList(readingAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			String asString = response.getBody().asString();

			HashMap<String, String> dataFromGraphql = getDataFromResponseReading(asString,
					contentBaseName.get(AssignmentAPIConstants.READING_COURSE));
			Log.message("Graphql response - " + dataFromGraphql.toString());

			// validate values
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Exercises Attempted")
							.equals(dataFromGraphql.get("exercisesAttempted")),
					"exercisesAttempted is expected", "exercisesAttempted is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Total Sessions").equals(dataFromGraphql.get("totalSessions")),
					"totalSessions is expected", "totalSessions is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Exercises Correct")
							.equals(dataFromGraphql.get("exercisesCorrect")),
					"exercisesCorrect is expected", "exercisesCorrect is not expected");
			Log.assertThat(dataFromUI.get(studentUsername).get("Help Used").equals(dataFromGraphql.get("helpUsed")),
					"helpUsed is expected", "helpUsed is not expected");
			Log.assertThat(datenew.equals(dataFromGraphql.get("sessionStartDate")), "sessionStartDate is expected",
					"sessionStartDate is not expected");
			Log.assertThat(replacePercent.equals(dataFromGraphql.get("exercisesPercentCorrect")),
					"exercisesPercentCorrect is expected", "exercisesPercentCorrect is not expected");
			Log.assertThat(value.equals(dataFromGraphql.get("timeSpent")), "timeSpent is expected",
					"timeSpent is not expected");

			Log.assertThat(
					dataFromUI.get(studentUsername).get("Instructional")
							.equals(outputPage.exercisesCorrectAndAttempted(dataFromGraphql.get("totalCorrect"),
									dataFromGraphql.get("totalAttempts"))),
					"Instructional is expected", "Instructional is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Independent Practice")
							.equals(outputPage.exercisesCorrectAndAttempted(dataFromGraphql.get("sessionIpAttempts"),
									dataFromGraphql.get("sessionIpCorrect"))),
					"Independent Practice is expected", "Independent Practice is not expected");
			Log.assertThat(dataFromUI.get(studentUsername).get("Remediation")
					.equals(outputPage.exercisesCorrectAndAttempted(dataFromGraphql.get("sessionPrerequisiteAttempts"),
							dataFromGraphql.get("sessionPrerequisiteCorrect"))),
					"Remediation is expected", "Remediation is not expected");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Validate all colum data grid values for Math-Custom by settings assignment", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF08(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Validate all colum data grid values for Math-Custom by settings assignment<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			Log.message("Uncheck all checkbox");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));
			Log.message("check Math-Settings only");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADER, Arrays.asList(contentBaseName
							.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));
			recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.DISPLAY_DROPDOWN, ReportsUIConstants.STUDENT_USERNAME);
			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			Log.testCaseInfo("Verify the \"Student\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Current Course Level (Level)\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Exercises Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Attempted (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Percent Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Help used (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Time Spent (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Total Sessions (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Session Date (Usage)\" column,the given input page data reflected to the output  ");
			// Getting data from UI
			Map<String, Map<String, String>> dataFromUI = outputPage.getMathGridValues();
			String stringOldDate = dataFromUI.get(studentUsername).get("sessionDate");
			Log.message("String old: " + stringOldDate);

			String datenew = dateFormatMethod(stringOldDate);
			Log.message("String new: " + datenew.toString());

			String timespent;
			timespent = dataFromUI.get(studentUsername).get("timeSpent");
			Log.message("old timespent: " + timespent.toString());

			String value;
			if (timespent.contains("*")) {
				String timeSpentreplace = timespent.replace("*", "");
				Log.message("new timespent: " + timeSpentreplace);
				value = roundoffValue(timeSpentreplace).toString();
			} else {
				Log.message("new timespent: " + timespent);
				value = roundoffValue(timespent).toString();

			}
			String exercisesPercentCorrect = dataFromUI.get(studentUsername).get("exercisesPercentCorrect");
			String replacePercent = exercisesPercentCorrect.replace("%", ".00%");
			Log.message(replacePercent);

			// Getting data from Graphql
			HashMap<String, String> headers = new HashMap<>();
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.USERID_SM_HEADER, teacherId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			headers.put(Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(username, password));

			payload = getResponseBody(teacherId, orgId, 1, false, Arrays.asList(newGroupID), Arrays.asList(studentId),
					Arrays.asList(mathCustomAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			String asString = response.getBody().asString();

			HashMap<String, String> dataFromGraphql = getDataFromResponse(asString,
					contentBaseName.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE));
			Log.message("Graphql response - " + dataFromGraphql.toString());

			// validate values
			Log.assertThat(
					dataFromUI.get(studentUsername).get("exercisesAttempted")
							.equals(dataFromGraphql.get("exercisesAttempted")),
					"exercisesAttempted is expected", "exercisesAttempted is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("totalSessions").equals(dataFromGraphql.get("totalSessions")),
					"totalSessions is expected", "totalSessions is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("exercisesCorrect")
							.equals(dataFromGraphql.get("exercisesCorrect")),
					"exercisesCorrect is expected", "exercisesCorrect is not expected");
			Log.assertThat(dataFromUI.get(studentUsername).get("helpUsed").equals(dataFromGraphql.get("helpUsed")),
					"helpUsed is expected", "helpUsed is not expected");
			Log.assertThat(datenew.equals(dataFromGraphql.get("sessionStartDate")), "sessionStartDate is expected",
					"sessionStartDate is not expected");
			Log.assertThat(replacePercent.equals(dataFromGraphql.get("exercisesPercentCorrect")),
					"exercisesPercentCorrect is expected", "exercisesPercentCorrect is not expected");
			Log.assertThat(value.equals(dataFromGraphql.get("timeSpent")), "timeSpent is expected",
					"timeSpent is not expected");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Validate all colum data grid values for Reading- Custom by settings assignment", groups = {
			"SMK-68047", "Teacher Dashboard", "Reportviewer", "Last Session Report" }, priority = 1)
	public void tcLastSessionReportOutputIntegrateWithBFF09(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Validate all colum data grid values for Reading-Custom by settings assignment<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher(username, password);
			RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();
			RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage(driver);

			recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.READING);

			Log.message("Uncheck all checkbox");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));
			Log.message("check Reading-standard only");
			recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADER, Arrays.asList(contentBaseName
							.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));
			recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.DISPLAY_DROPDOWN, ReportsUIConstants.STUDENT_USERNAME);
			recentSessionsPage.reportFilterComponent.clickRunReportButton();
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(recentSessionsPage.checkReportHeaderAfterRun(), "Last Session Report data displayed",
					"Last Session Report data not displayed");

			Log.testCaseInfo("Verify the \"Student\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Current Course Level (Level)\" column,the given input page data reflected to the output");
			Log.testCaseInfo(
					"Verify the \"Exercises Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Attempted (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Exercises Percent Correct (Raw performance)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Help used (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Time Spent (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Total Sessions (Usage)\" column,the given input page data reflected to the output ");
			Log.testCaseInfo(
					"Verify the \"Session Date (Usage)\" column,the given input page data reflected to the output  ");

			// Getting data from UI
			Map<String, Map<String, String>> dataFromUI = outputPage.getReadingGridValues();

			String stringOldDate = dataFromUI.get(studentUsername).get("Session Date");
			Log.message("String old: " + stringOldDate);

			String datenew = dateFormatMethod(stringOldDate);
			Log.message("String new: " + datenew.toString());

			String timespent;
			timespent = dataFromUI.get(studentUsername).get("Time Spent");
			Log.message("old timespent: " + timespent.toString());

			String value = null;
			if (timespent.contains("*")) {
				String timeSpentreplace = timespent.replace("*", "");
				Log.message("new timespent: " + timeSpentreplace);
				value = roundoffValue(timeSpentreplace);
			} else {
				Log.message("new timespent: " + timespent);
				value = roundoffValue(timespent);

			}
			String exercisesPercentCorrect = dataFromUI.get(studentUsername).get("Exercises Percent Correct");
			String replacePercent = exercisesPercentCorrect.replace("%", ".00%");
			Log.message(replacePercent);

			// Getting data from Graphql
			HashMap<String, String> headers = new HashMap<>();
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.USERID_SM_HEADER, teacherId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			headers.put(Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(username, password));

			payload = getResponseBody(teacherId, orgId, 2, false, Arrays.asList(newGroupID), Arrays.asList(studentId),
					Arrays.asList(readingCustomAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			String asString = response.getBody().asString();

			HashMap<String, String> dataFromGraphql = getDataFromResponseReading(asString, contentBaseName
					.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE));
			Log.message("Graphql response - " + dataFromGraphql.toString());

			// validate values
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Exercises Attempted")
							.equals(dataFromGraphql.get("exercisesAttempted")),
					"exercisesAttempted is expected", "exercisesAttempted is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Total Sessions").equals(dataFromGraphql.get("totalSessions")),
					"totalSessions is expected", "totalSessions is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Exercises Correct")
							.equals(dataFromGraphql.get("exercisesCorrect")),
					"exercisesCorrect is expected", "exercisesCorrect is not expected");
			Log.assertThat(dataFromUI.get(studentUsername).get("Help Used").equals(dataFromGraphql.get("helpUsed")),
					"helpUsed is expected", "helpUsed is not expected");
			Log.assertThat(datenew.equals(dataFromGraphql.get("sessionStartDate")), "sessionStartDate is expected",
					"sessionStartDate is not expected");
			Log.assertThat(replacePercent.equals(dataFromGraphql.get("exercisesPercentCorrect")),
					"exercisesPercentCorrect is expected", "exercisesPercentCorrect is not expected");
			Log.assertThat(value.equals(dataFromGraphql.get("timeSpent")), "timeSpent is expected",
					"timeSpent is not expected");

			Log.assertThat(
					dataFromUI.get(studentUsername).get("Instructional")
							.equals(outputPage.exercisesCorrectAndAttempted(dataFromGraphql.get("totalCorrect"),
									dataFromGraphql.get("totalAttempts"))),
					"Instructional is expected", "Instructional is not expected");
			Log.assertThat(
					dataFromUI.get(studentUsername).get("Independent Practice")
							.equals(outputPage.exercisesCorrectAndAttempted(dataFromGraphql.get("sessionIpAttempts"),
									dataFromGraphql.get("sessionIpCorrect"))),
					"Independent Practice is expected", "Independent Practice is not expected");
			Log.assertThat(dataFromUI.get(studentUsername).get("Remediation")
					.equals(outputPage.exercisesCorrectAndAttempted(dataFromGraphql.get("sessionPrerequisiteAttempts"),
							dataFromGraphql.get("sessionPrerequisiteCorrect"))),
					"Remediation is expected", "Remediation is not expected");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	/**
	 * To execute the course
	 * 
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void executeCourse(String studentUserName, String courseName, boolean isMath) throws IOException {
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.message("Student username " + studentUserName);
		LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUserName,
				RBSDataSetupConstants.DEFAULT_PASSWORD);
		StudentDashboardPage studentsPage = new StudentDashboardPage(driver);

		if (isMath) {
			try {
				studentsPage.executeMathCourse(studentUserName, courseName, "100", "1", "10");
				studentsPage.logout();
				driver.close();
			} catch (Exception e) {
				driver.close();
			}
		} else {
			try {
				studentsPage.executeReadingCourse(studentUserName, courseName, "100", "1", "20");
				studentsPage.logout();
				driver.close();
			} catch (Exception e) {
				driver.close();
			}
		}

	}

	public String getResponseBody(String userId, String orgId, int subject, boolean isGroupSelected,
			List<String> groupIds, List<String> studentIds, List<Integer> assignmentIds) {
		AtomicReference<String> requestBody = new AtomicReference<>();
		try {

			// Generate Payload
			String basePath = (new File(".")).getCanonicalPath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson"
					+ File.separator + "report" + File.separator;
			requestBody.set(SMUtils.convertFileToString(basePath + "LSRGraphQLRequestBody.json"));

			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.teacherId", userId));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.organizationId", orgId));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.subject", subject));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.isGroupSelected", isGroupSelected));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.groupIds", groupIds));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.studentIds", studentIds));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.assignmentIds", assignmentIds));

			Log.message("Payload : " + requestBody.get());
		} catch (Exception e) {
			Log.message(e.getMessage());
		}
		return requestBody.get();
	}

	public HashMap<String, String> getDataFromResponseReading(String response, String courseName) {

		// Getting data from response
		String jsonObj = getKeyValueFromResponseWithArray(response, "data,getLSReportData,lsReportResponse");
		Log.message("Response Data: " + jsonObj);

		HashMap<String, String> studentReport = new HashMap<>();
		String rawPerformance = getKeyValueFromResponseWithArray(jsonObj, "rows");

		// Loop1
		IntStream.range(0, new JSONArray(rawPerformance).length()).forEach(itr -> {

			String graphqlStudentUsername = SMUtils
					.getKeyValueFromResponseWithArray(new JSONArray(rawPerformance).get(itr).toString(), "userName");
			String graphqAssignmentTitle = SMUtils.getKeyValueFromResponseWithArray(
					new JSONArray(rawPerformance).get(itr).toString(), "assignmentTitle");

			if (graphqlStudentUsername.trim().equals(studentUsername.trim())
					&& graphqAssignmentTitle.trim().equals(courseName)) {

				String currentCourseLevel = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "currentCourseLevel");
				String totalCorrect = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalCorrect");
				String totalAttempts = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalAttempts");
				String sessionHelpCount = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionHelpCount");
				String timeSpent = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "timeSpent");
				String totalSessions = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalSessions");
				String usernameGrid = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "userName");
				String sessionStartDate = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionStartDate");
				String exercisesPercentCorrect = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "exercisesPercentCorrect");

				String instructional1 = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalCorrect");
				String instructional2 = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalAttempts");

				String indipendentPractise1 = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionIpAttempts");
				String indipendentPractise2 = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionIpCorrect");

				String remediation1 = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionPrerequisiteAttempts");
				String remediation2 = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionPrerequisiteCorrect");

				String hour;
				String min;
				String star;
				if (timeSpent.length() == 5) {
					hour = timeSpent.substring(0, 2);
					min = timeSpent.substring(3);
				} else {
					hour = timeSpent.substring(0, 1);
					min = timeSpent.substring(2);
				}
				int hourInt = Integer.parseInt(hour);
				int minInt = Integer.parseInt(min);
				int timeSpentValue = hourInt * 60 + minInt;

				float courseLvlFloat = Float.parseFloat(currentCourseLevel);
				int courseLvl = (int) courseLvlFloat;
				currentCourseLevel = String.valueOf(courseLvl);

				studentReport.put("exercisesCorrect", totalCorrect);
				studentReport.put("exercisesAttempted", totalAttempts);
				studentReport.put("helpUsed", sessionHelpCount);
				studentReport.put("timeSpent", String.valueOf(timeSpentValue));
				studentReport.put("totalSessions", totalSessions);
				studentReport.put("userName", usernameGrid);
				studentReport.put("sessionStartDate", sessionStartDate.substring(0, 10));
				studentReport.put("exercisesPercentCorrect", exercisesPercentCorrect);

				studentReport.put("totalCorrect", instructional1);
				studentReport.put("totalAttempts", instructional2);
				studentReport.put("sessionIpAttempts", indipendentPractise1);
				studentReport.put("sessionIpCorrect", indipendentPractise2);
				studentReport.put("sessionPrerequisiteAttempts", remediation1);
				studentReport.put("sessionPrerequisiteCorrect", remediation2);
				Log.message("StudentReportDetails: " + studentReport);
			}
		});
		return studentReport;
	}

	public HashMap<String, String> getDataFromResponse(String response, String courseName) {

		// Getting data from response
		String jsonObj = getKeyValueFromResponseWithArray(response, "data,getLSReportData,lsReportResponse");
		Log.message("Response Data: " + jsonObj);

		HashMap<String, String> studentReport = new HashMap<>();
		String rawPerformance = getKeyValueFromResponseWithArray(jsonObj, "rows");

		// Loop1
		IntStream.range(0, new JSONArray(rawPerformance).length()).forEach(itr -> {

			String graphqlStudentUsername = SMUtils
					.getKeyValueFromResponseWithArray(new JSONArray(rawPerformance).get(itr).toString(), "userName");
			String graphqAssignmentTitle = SMUtils.getKeyValueFromResponseWithArray(
					new JSONArray(rawPerformance).get(itr).toString(), "assignmentTitle");

			if (graphqlStudentUsername.trim().equals(studentUsername.trim())
					&& graphqAssignmentTitle.trim().equals(courseName)) {

				String currentCourseLevel = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "currentCourseLevel");
				String totalCorrect = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalCorrect");
				String totalAttempts = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalAttempts");
				String sessionHelpCount = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionHelpCount");
				String timeSpent = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "timeSpent");
				String totalSessions = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "totalSessions");
				String usernameGrid = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "userName");
				String sessionStartDate = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "sessionStartDate");
				String exercisesPercentCorrect = SMUtils.getKeyValueFromResponseWithArray(
						new JSONArray(rawPerformance).get(itr).toString(), "exercisesPercentCorrect");

				String hour;
				String min;
				String star;
				if (timeSpent.length() == 5) {
					hour = timeSpent.substring(0, 2);
					min = timeSpent.substring(3);
				} else {
					hour = timeSpent.substring(0, 1);
					min = timeSpent.substring(2);
				}
				int hourInt = Integer.parseInt(hour);
				int minInt = Integer.parseInt(min);
				int timeSpentValue = hourInt * 60 + minInt;

				float courseLvlFloat = Float.parseFloat(currentCourseLevel);
				int courseLvl = (int) courseLvlFloat;
				currentCourseLevel = String.valueOf(courseLvl);

				studentReport.put("exercisesCorrect", totalCorrect);
				studentReport.put("exercisesAttempted", totalAttempts);
				studentReport.put("helpUsed", sessionHelpCount);
				studentReport.put("timeSpent", String.valueOf(timeSpentValue));
				studentReport.put("totalSessions", totalSessions);
				studentReport.put("userName", usernameGrid);
				studentReport.put("sessionStartDate", sessionStartDate.substring(0, 10));
				studentReport.put("exercisesPercentCorrect", exercisesPercentCorrect);
				Log.message("StudentReportDetails: " + studentReport);
			}
		});
		return studentReport;
	}

	public static String getKeyValueFromResponseWithArray(String response, String path) {
		String[] json_Array = path.split(",");
		String keyValue = null;
		try {
			if (json_Array.length <= 1) {
				JSONObject jsonObj = new JSONObject(response);
				String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
				return JsonArrayValue;
			} else if (json_Array.length == 2) {
				JSONObject jsonObj = new JSONObject(response);
				String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
				JSONObject jsonObj1 = new JSONObject(JsonArrayValue);
				keyValue = jsonObj1.get(json_Array[1]).toString();
				return keyValue;
			} else if (json_Array.length == 3) {
				JSONObject jsonObj = new JSONObject(response);
				String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
				JSONObject jsonObj1 = new JSONObject(JsonArrayValue);
				String JsonArrayValue2 = jsonObj1.get(json_Array[1]).toString();
				JSONObject jsonObj2 = new JSONObject(JsonArrayValue2);
				keyValue = jsonObj2.get(json_Array[2]).toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return keyValue;
		}
		return keyValue;
	}

	public String dateFormatMethod(String stringOldDate) throws ParseException {
		String oldformat = "MM/dd/yyyy";
		String newformat = "yyyy-MM-dd";

		String newString;
		SimpleDateFormat sdf = new SimpleDateFormat(oldformat);
		Date d = sdf.parse(stringOldDate);
		sdf.applyPattern(newformat);
		newString = sdf.format(d);
		Log.message("checking: " + newString);
		return newString;

	}

	@Test
	public String roundoffValue(String str) {
		int parseInt = Integer.parseInt(str.split(":")[1]);
		Log.message(parseInt + "");
		return parseInt + "";

	}
}