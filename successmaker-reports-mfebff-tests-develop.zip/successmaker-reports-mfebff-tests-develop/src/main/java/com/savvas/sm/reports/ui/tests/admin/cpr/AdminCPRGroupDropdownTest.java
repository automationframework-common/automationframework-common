package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class AdminCPRGroupDropdownTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String adminUsername;
    private String password;
    private String flexSchool;
    private String mathSchool;
    private List<String> courses;
    private String reportBFF;
    private String endPoint = "/graphql";
    private String orgId;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = "Windows_10_Chrome_100";
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        reportBFF = configProperty.getProperty( "AdminReportBFF" );
        adminUsername = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        flexSchool = "SM Auto School SME187 - Hunters";
        orgId = ReportDataCollection.orgId;
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown and it's placeholder text when no groups are selected" )
    public void tcCPRGroupDrodpownTest001() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown and it's placeholder text when no groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-001: Verify Group dropdown and it's placeholder text when no groups are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_GROUPS ),
                    "Placeholder is displaying properly when no groups are not selected", "Placeholder is not displaying properly when no groups are not selected. Actual - "
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ) + ".Expected -" + ReportsUIConstants.GROUP_LABEL );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when one group is selected" )
    public void tcCPRGroupDrodpownTest002() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when one group is selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-002: Verify Group dropdown when one group is selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ).replace( ".", "" ) ) );

            //To get the selected groups in the groups dropdown
            List<String> selectedGroups = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            if ( selectedGroups.size() <= 2 ) {
                Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).contains( groups.get( 1 ).replace( ".", "" ) ), "Placeholder is displaying properly when one group is selected",
                        "Placeholder is not displaying properly when one group is selected. Actual - " + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ) + ".Expected -" + groups.get( 1 ) );
            } else {
                Log.assertThat(
                        cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase(
                                ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( selectedGroups.size() - 1 ) ) ),
                        "Placeholder is displaying properly when two or more group is selected",
                        "Placeholder is not displaying properly when two or more group is selected. Actual - " + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ) + ".Expected -"
                                + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( selectedGroups.size() - 1 ) ) );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when two or more groups is selected" )
    public void tcCPRGroupDrodpownTest003() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when two or more groups is selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-003: Verify Group dropdown when two or more groups is selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To get all the groups in the dropdown
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To select the groups in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ), groups.get( 2 ) ) );

            //To get the selected groups in the groups dropdown
            cprPage.reportFilterComponent.clearTextInSearchBar( ReportsUIConstants.GROUP_LABEL );
            List<String> selectedGroups = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Log.message( selectedGroups.toString() );
            Log.assertThat(
                    cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase(
                            ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( selectedGroups.size() - 1 ) ) ),
                    "Placeholder is displaying properly when two or more group is selected",
                    "Placeholder is not displaying properly when two or more group is selected. Actual - " + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ) + ".Expected -"
                            + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( selectedGroups.size() - 1 ) ) );
            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when exactly 1000 groups is selected" )
    public void tcCPRGroupDrodpownTest004() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when exactly 1000 groups is selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-004: Verify Group dropdown when exactly 1000 groups is selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ), groups.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 group is selected", "Placeholder is displaying properly when 1000 group is selected" + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL )
                            + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );
            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when more than 1000 groups are selected" )
    public void tcCPRGroupDrodpownTest005() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when more than 1000 groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-005: Verify Group dropdown when more than 1000 groups are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is  displaying properly after selected more than 1000 group selected", "Error Message is not displaying properly after selected more than 1000 group selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when Select All check box is selected in Group dropdown" )
    public void tcCPRGroupDrodpownTest006() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when Select All check box is selected in Group dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-006: Verify Group dropdown when Select All check box is selected in Group dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            Log.assertThat( !cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ), "Error Message is not displaying properly as Expected after selected 'Select ALL'",
                    "Error Message is displaying properly as Expected after selected 'Select ALL'" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when choosing \"Select All\" then deselect some groups and the group count > 1000" )
    public void tcCPRGroupDrodpownTest007() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when choosing \"Select All\" then deselect some groups and the group count > 1000" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-007: Verify Group dropdown when more than 1000 groups are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 group selected", "Error Message is not displaying properly after selected more than 1000 group selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when more than 1000 groups are selected and collapse the Group dropdown" )
    public void tcCPRGroupDrodpownTest008() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when more than 1000 groups are selected and collapse the Group dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-008: Verify Group dropdown when more than 1000 groups are selected and collapse the Group dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            //To Collapse the multi select dropdown
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            Log.assertThat( cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 group selected", "Error Message is not displaying properly after selected more than 1000 group selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when single organization, single Teacher and 1000 above groups are selected" )
    public void tcCPRGroupDrodpownTest009() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when single organization, single Teacher and 1000 above groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-009: Verify Group dropdown when single organization, single Teacher and 1000 above groups are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To get all the teacher from dropdown 
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Group_List_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );

            //To select teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying after selected more than 1000 group selected", "Error Message is not displaying after selected more than 1000 group selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify Group dropdown when multiple organization, multiple Teacher and 1000 above groups are selected" )
    public void tcCPRGroupDrodpownTest010() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when multiple organization, multiple Teacher and 1000 above groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        String responseJson;
        DevTools devTool;
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-010: Verify Group dropdown when multiple organization, multiple Teacher and 1000 above groups are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To get all the teacher from dropdown 
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To select the teachers in the dropdown
            if ( teachers.size() > 2 ) {
                cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );

                responseJson = DevToolsUtils.readJsonResponse( "Group_List_SMK-69825.json" ).replace( "{orgId}", orgId );
                devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

                cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 2 ) ) );

            } else {
                responseJson = DevToolsUtils.readJsonResponse( "Group_List_SMK-69825.json" ).replace( "{orgId}", orgId );
                devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

                cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );
            }

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying after selected more than 1000 group selected", "Error Message is not displaying properly after selected more than 1000 group selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify saved report options loading with 1000 groups" )
    public void tcCPRGroupDrodpownTest011() throws Exception {
        Log.testCaseInfo( "Verify Group dropdown when exactly 1000 groups is selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-011: Verify saved report options loading with 1000 groups" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ), groups.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.isSaveReportOptionButtonEnabled(), "Save report button is enabled as expected while selecting 1000 groups", "Save report button is disabled while selecting 1000 groups. It should be enabled." );

            DevToolsUtils.closeMock( devTool );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69825", "Organization- muliselect", "smoke_test_case" }, description = "Verify saved report options by adding one more group in Saved report option which contains 1000 groups" )
    public void tcCPRGroupDrodpownTest012() throws Exception {
        Log.testCaseInfo( "Verify saved report options by adding one more group in Saved report option which contains 1000 groups" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-012: Verify saved report options by adding one more group in Saved report option which contains 1000 groups" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the groups in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the groups in the dropdown (1002 groups)
            List<String> groups = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To unselect the two group in the groups dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            Log.assertThat( !cprPage.reportFilterComponent.isSaveReportOptionButtonEnabled(), "Save report button is disabled as expected while selecting more than 1000 groups",
                    "Save report button is enabled wehile selecting more than 1000 groups. It should be disabled." );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify saved report options by adding one more group in Saved report option which contains 1000 groups" )
    public void tcCPRCourseDropdown001() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown and it's placeholder text when no groups are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-013: Verify Course dropdown and it's placeholder text when no groups are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_COURSES ),
                    "Placeholder is displaying properly when no courses are not selected", "Placeholder is not displaying properly when no courses are not selected. Actual - "
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ) + ".Expected -" + ReportsUIConstants.ZERO_STATE_COURSES );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when one course is selected" )
    public void tcCPRCourseDropdown002() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when one course is selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-014: Verify Course dropdown when one course is selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Math_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            //To get the selected courses in the courses dropdown
            List<String> selectedCourses = cprPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            if ( selectedCourses.size() <= 2 ) {
                Log.assertThat( courses.get( 1 ).contains( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ).replace( ".", "" ).trim() ),
                        "Placeholder is displaying properly when one group is selected",
                        "Placeholder is not displaying properly when one group is selected. Actual - " + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ) + ".Expected -" + courses.get( 1 ) );
            } else {
                Log.assertThat(
                        cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase(
                                ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( selectedCourses.size() - 1 ) ) ),
                        "Placeholder is displaying properly when two or more courses are selected",
                        "Placeholder is not displaying properly when two or more courses are selected. Actual - " + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ) + ".Expected -"
                                + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( selectedCourses.size() - 1 ) ) );
            }

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when two or more Courses are selected" )
    public void tcCPRCourseDropdown003() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when two or more Courses are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-015: Verify Course dropdown when two or more Courses are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Math_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ), courses.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( 2 ) ) ),
                    "Placeholder is displaying properly when two or more courses are selected", "Placeholder is not displaying properly when two or more courses are selected. Actual - "
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", String.valueOf( 2 ) ) );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when exactly 1000 courses are selected" )
    public void tcCPRCourseDropdown004() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when exactly 1000 courses are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-016: Verify Course dropdown when exactly 1000 courses are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Math_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ), courses.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 courses are selected", "Placeholder is displaying properly when 1000 courses is selected"
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when more than 1000 courses are selected for Math subject" )
    public void tcCPRCourseDropdown005() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when more than 1000 courses are selected for Math subject" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-017: Verify Course dropdown when more than 1000 courses are selected for Math subject" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Math_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            Log.assertThat(
                    cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 course selected", "Error Message is not displaying properly after selected more than 1000 course selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when more than 1000 courses are selected for Reading subject" )
    public void tcCPRCourseDropdown006() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when more than 1000 courses are selected for Reading subject" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-018: Verify Course dropdown when more than 1000 courses are selected for Reading subject" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Reading_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            Log.assertThat(
                    cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 course selected", "Error Message is not displaying properly after selected more than 1000 course selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when Select All check box is selected in Course dropdown" )
    public void tcCPRCourseDropdown007() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when Select All check box is selected in Course dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-019: Verify Course dropdown when Select All check box is selected in Course dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Reading_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            Log.assertThat( !cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ), "Error Message is not displaying properly as Expected after selected 'Select ALL'",
                    "Error Message is displaying properly as Expected after selected 'Select ALL'" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when choosing \"Select All\" then deselect some courses and the course count > 1000" )
    public void tcCPRCourseDropdown008() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when choosing \"Select All\" then deselect some courses and the course count > 1000" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-019: Verify Course dropdown when choosing \"Select All\" then deselect some courses and the course count > 1000" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Reading_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            Log.assertThat(
                    cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 course selected", "Error Message is not displaying properly after selected more than 1000 course selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when more than 1000 courses are selected and collapse the Course dropdown" )
    public void tcCPRCourseDropdown009() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when more than 1000 courses are selected and collapse the Course dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-020 - Verify Course dropdown when more than 1000 courses are selected and collapse the Course dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Reading_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat(
                    cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 course selected", "Error Message is not displaying properly after selected more than 1000 course selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when single organization, single Teacher and above 1000 courses are selected" )
    public void tcCPRCourseDropdown010() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when single organization, single Teacher and above 1000 courses are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-021 - Verify Course dropdown when single organization, single Teacher and above 1000 courses are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To select the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Reading_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat(
                    cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 course selected", "Error Message is not displaying properly after selected more than 1000 course selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69828", "Organization- muliselect", "smoke_test_case" }, description = "Verify Course dropdown when multiple organization, multiple Teachers and above 1000 courses are selected" )
    public void tcCPRCourseDropdown011() throws Exception {
        Log.testCaseInfo( "Verify Course dropdown when multiple organization, multiple Teachers and above 1000 courses are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-022 -Verify Course dropdown when multiple organization, multiple Teachers and above 1000 courses are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            cprPage.reportFilterComponent.expandOptionalFilter();
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To select the teachers in the dropdown
            if ( teachers.size() > 2 ) {
                cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );

            } else {
                cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );
            }

            String responseJson = DevToolsUtils.readJsonResponse( "Course_List_Reading_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select Subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            List<String> courses = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            //To select all courses
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To deselect the courses in the courses dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );

            Log.assertThat(
                    cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.CPR_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is displaying properly after selected more than 1000 course selected", "Error Message is not displaying properly after selected more than 1000 course selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when exactly 1000 teachers are selected" )
    public void tcCPRTeacherDrodpownTest001() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when exactly 1000 teachers are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-023: Verify Teachers dropdown when exactly 1000 teachers are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the teachers in the dropdown (1002 teachers)
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To unselect the two teacher in the teachers dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 teacher is selected", "Placeholder is displaying properly when 1000 teacher is selected"
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );
            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when more than 1000 teachers are selected" )
    public void tcCPRTeacherDrodpownTest002() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when more than 1000 teachers are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-024: Verify Teachers dropdown when more than 1000 teachers are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the teachers in the dropdown (1002 teachers)
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To unselect the two teacher in the teachers dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.TEACHER_LABEL ) && cprPage.reportFilterComponent.getErrorMessage( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.ERROR_MESSAGE ),
                    "Error Message is  displaying properly after selected more than 1000 teachers selected", "Error Message is not displaying properly after selected more than 1000 teachers selected" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when Select All check box is selected in Teacher dropdown" )
    public void tcCPRTeacherDrodpownTest003() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when Select All check box is selected in Teacher dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-025: Verify Teachers dropdown when Select All check box is selected in Teacher dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            Log.assertThat( !cprPage.reportFilterComponent.isErrorMessageDisplayed( ReportsUIConstants.GROUP_LABEL ), "Error Message is not displaying properly as Expected after selected 'Select ALL'",
                    "Error Message is displaying properly as Expected after selected 'Select ALL'" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when choosing \"Select All\" then deselect some teachers and the teacher count > 1000" )
    public void tcCPRTeacherDrodpownTest004() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when choosing \"Select All\" then deselect some teachers and the teacher count > 1000" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-026: Verify Teachers dropdown when choosing \"Select All\" then deselect some teachers and the teacher count > 1000" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the teachers in the dropdown (1002 teachers)
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To unselect the two teacher in the teachers dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 teacher is selected", "Placeholder is displaying properly when 1000 teacher is selected"
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when more than 1000 teachers are selected and collapse the Teacher dropdown" )
    public void tcCPRTeacherDrodpownTest005() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when more than 1000 teachers are selected and collapse the Teacher dropdown" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-027:Verify Teachers dropdown when more than 1000 teachers are selected and collapse the Teacher dropdown" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the teachers in the dropdown (1002 teachers)
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To unselect the two teacher in the teachers dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 teacher is selected", "Placeholder is displaying properly when 1000 teacher is selected"
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when single organization and 1000 above Teachers are selected" )
    public void tcCPRTeacherDrodpownTest006() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when single organization and 1000 above Teachers are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "tc-028:Verify Teachers dropdown when single organization and 1000 above Teachers are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To select the single organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the teachers in the dropdown (1002 teachers)
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To unselect the two teacher in the teachers dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 teacher is selected", "Placeholder is displaying properly when 1000 teacher is selected"
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-69826", "Organization- muliselect", "smoke_test_case" }, description = "Verify Teachers dropdown when multiple organization 1000 above Teachers are selected" )
    public void tcCPRTeacherDrodpownTest007() throws Exception {
        Log.testCaseInfo( "Verify Teachers dropdown when multiple organization 1000 above Teachers are selected" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify Teachers dropdown when multiple organization 1000 above Teachers are selected" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To select the single organization
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool, mathSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            String responseJson = DevToolsUtils.readJsonResponse( "CPR_OptionalFilter_SMK-69825.json" ).replace( "{orgId}", orgId );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To expand the optional filter
            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select all the teachers in the dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To get all the teachers in the dropdown (1002 teachers)
            List<String> teachers = cprPage.reportFilterComponent.getOptionsTooltipFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To unselect the two teacher in the teachers dropdown
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );

            Log.assertThat( cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) ),
                    "Placeholder is displaying properly when 1000 teacher is selected", "Placeholder is displaying properly when 1000 teacher is selected"
                            + cprPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) + ".Expected -" + ReportsUIConstants.SELECTED_ALL_GROUPS2.replace( "{selected_count}", "1000" ) );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
