package com.savvas.sm.reports.smoke.admin.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.smoke.admin.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.admin.pages.CumulativePerformanceAggregateReport;
import com.savvas.sm.reports.smoke.admin.pages.CumulativePerformanceReport;
import com.savvas.sm.reports.smoke.admin.pages.ReportsViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CumulativePerformanceAggregateReportsValidations extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String adminUsername;
    private String subDistrictschoolName;
    private String flexSchoolName;
    private String schoolAdmin;
    private String flexSchoolId;
    private String mathSchool;
    private String mathschoolId;
    private String districtId;
    private String mathFlexAdmin;
    private String flexSchoolAdmin;
    private List<String> expgroupNames = new ArrayList<String>();
    private List<String> expteacherNames = new ArrayList<String>();
    private List<String> teacherIds = new ArrayList<String>();
    private List<String> groupIds = new ArrayList<String>();
    public static String[] schools;

    @BeforeTest ( alwaysRun = true )
    public void init( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        adminUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        subDistrictschoolName = configProperty.getProperty( "Rumba_subDistrictSchool" );
        schoolAdmin = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
        schools = configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," );

        // FLEX SCHOOL ADMIN CREATE
        flexSchoolName = schools[4];
        flexSchoolId = new RBSUtils().getOrganizationIDByName( districtId, flexSchoolName );
        flexSchoolAdmin = "flexschooladmin7686" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) == null ) {
            HashMap<String, String> adminDetails = new HashMap<>();
            adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, flexSchoolName );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, flexSchoolId );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
            adminDetails.put( RBSDataSetupConstants.USERNAME, flexSchoolAdmin );
            boolean createCAUserWithAccess = new RBSUtils().createCAUserWithAccess( adminDetails, true );
        }

        new RBSUtils().resetPassword( flexSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) );

        // ADMIN CREATE OF MATH AND READING 
        mathSchool = schools[0];
        mathschoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), mathSchool );
        mathFlexAdmin = "mathFlexadmin1234" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( mathFlexAdmin ) == null ) {
            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, mathFlexAdmin );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, mathschoolId + "\"," + "\"" + flexSchoolId );
            String admin = new RBSUtils().createUser( userDetails );
            new RBSUtils().resetPassword( mathschoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( admin, RBSDataSetupConstants.USERID ) );
        }
    }

    @Test ( description = "Validation Cumulative Performance Aggregate - All Fields Validations", groups = { "smoke_test_case", "reports", "cumulative_performance_aggregate"}, priority = 1 )
    public void tc001CPAggregateFieldValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Cumulative Performance Aggregate Report Field Validations" + browser + "]</b></i></small>" );
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport =  smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformanceReport cpr = (CumulativePerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Cumulative Performance" );
            CumulativePerformanceAggregateReport cpar = cpr.navigateToCumulativePerformanceAggregateReport( driver );
            cpar.validateAllFieldsInCumulativePerformanceAggregateReport( driver );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test (description = "Validation Cumulative Performance Aggregate - 'Saved Report' Value Is Retaining ", groups = { "smoke_test_case", "reports", "cumulative_performance_aggregate"}, priority = 2 )
    public void tc002CPAggregateSavedReportsValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation Cumulative Performance Aggregate - 'Saved Report' Value Is Retaining " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport =  smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformanceReport cumulativePerformanceReport = (CumulativePerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Cumulative Performance" );
            CumulativePerformanceAggregateReport cumulativePerformanceAggregateReport = cumulativePerformanceReport.clickCumulativePerformanceAggregateReport( driver );
            cumulativePerformanceAggregateReport.validateCPAggregateSavedReports( driver , flexSchoolId );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Cumulative performance aggregate run Report Validation", groups = { "smoke_test_case", "reports", "cumulative_performance_aggregate"}, priority = 3 )
    public void tc003CPAggregateRunReportValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Cumulative performance aggregate run Report Validation" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport =  smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformanceReport cumulativePerformanceReport = (CumulativePerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Cumulative Performance" );
            CumulativePerformanceAggregateReport cumulativePerformanceAggregateReport = cumulativePerformanceReport.clickCumulativePerformanceAggregateReport( driver );
            ReportsViewerPage reportsViewerPage = cumulativePerformanceAggregateReport.validateCPAggregateRunReport( driver, flexSchoolId );
            reportsViewerPage.verifyReportPage( driver );
            reportsViewerPage.validateReportOutputColumns( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
            Log.endTestCase();
            Log.testCaseResult();
        }
    }

    @Test ( description = "Validation of Cumulative Performance Aggregate Report Field Validations - All Drop down validations", groups = { "smoke_test_case", "reports", "cumulative_performance_aggregate"}, priority = 4 )
    public void tc004SCumulativePerformanceReportsValidationAggregateValidationReading() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation of Cumulative Performance Report Field Validations" + browser + "]</b></i></small>" );
        List<String> orgId = new ArrayList<String>();
        orgId.add( flexSchoolId );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformanceReport cumulativePerformanceReport = (CumulativePerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Cumulative Performance" );
            CumulativePerformanceAggregateReport cumulativePerformanceAggregateReport = cumulativePerformanceReport.clickCumulativePerformanceAggregateReport( driver );
            cumulativePerformanceAggregateReport.verifyOrgIds( driver, Admins.DISTRICT_ADMIN, smUrl );
            cumulativePerformanceAggregateReport.chooseOrganization( driver, flexSchoolId );
            cumulativePerformanceAggregateReport.chooseSubject( driver, "Reading" );
            cumulativePerformanceAggregateReport.verifyCourses( driver, Admins.DISTRICT_ADMIN, orgId, "Reading" );
            cumulativePerformanceReport.clickOptionalFilters( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validation of Cumulative Performance Aggregate Report Field Validations - All Drop down validations", groups = { "smoke_test_case", "reports", "cumulative_performance_aggregate"}, priority = 5 )
    public void tc005SCumulativePerformanceReportsValidationAggregateValidationMath() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation of Cumulative Performance Report Field Validations" + browser + "]</b></i></small>" );
        List<String> orgId = new ArrayList<String>();
        orgId.add( flexSchoolId );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            CumulativePerformanceReport cumulativePerformanceReport = (CumulativePerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Cumulative Performance" );
            CumulativePerformanceAggregateReport cumulativePerformanceAggregateReport = cumulativePerformanceReport.clickCumulativePerformanceAggregateReport( driver );
            cumulativePerformanceAggregateReport.verifyOrgIds( driver, Admins.DISTRICT_ADMIN, smUrl );
            cumulativePerformanceAggregateReport.chooseOrganization( driver, flexSchoolId );
            cumulativePerformanceAggregateReport.chooseSubject( driver, "Math" );
            cumulativePerformanceAggregateReport.verifyCourses( driver, Admins.DISTRICT_ADMIN, orgId, "Math" );
            cumulativePerformanceReport.clickOptionalFilters( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
