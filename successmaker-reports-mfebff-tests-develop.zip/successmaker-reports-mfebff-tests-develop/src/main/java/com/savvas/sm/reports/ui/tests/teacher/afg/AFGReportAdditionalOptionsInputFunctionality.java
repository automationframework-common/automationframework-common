package com.savvas.sm.reports.ui.tests.teacher.afg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class AFGReportAdditionalOptionsInputFunctionality extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String teacherDetails;
    WebDriver driver;

    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify Groups are selected by default under Areas for Growth Difficulty sub-nav", groups = { "SMK-57296", "Smoke" }, priority = 1 )
    public void tc_AFG_1() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );

        Log.testCaseInfo( "tc_AFG_1: Verify Groups are selected by default under Areas for Growth Difficulty sub-nav<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();

            SMUtils.nap( 5 );
            Log.assertThat( areaForGrowthPage.verifyGroupsBtnSelected(), "Groups are selected", "Groups are not selected" );
            Log.testCaseInfo( "tc002: Verify teacher can able to select one or more groups in AFG input filter <small><b><i>[" + browser + "]</b></i></small>" );

            List<String> options = new ArrayList<>();
            options.add( "Select All" );
            options.add( "Successmaker Group 1" );
            ;
            System.out.println( options );
            reportFilterComponent.selectOptionsFromMultiSelectGroupDropdown( "Groups", options );
            List<String> selectedOptions = reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownWithInput( "Groups" );
            Collections.sort( options );
            Collections.sort( selectedOptions );

            Log.assertThat( selectedOptions.equals( options ), "Selected Groups options Successfully", "Groups Options not selected" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher can able to select one or more students per requirement", groups = { "SMK-57296" }, priority = 2 )
    public void tc_AFG_2() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        Log.testCaseInfo( "tc_AFG_2: Verify teacher can able to select one or more students per requirement <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            leftNavBar.clickOnAreaForGrowthPage();
            // Click on Areas For Growth Report
            reportFilterComponent.checkStudntRadioBtn();
            List<String> options = new ArrayList<>();
            options.add( "Select All" );

            reportFilterComponent.expandMultiSelectDropdown( "Students" );
            SMUtils.nap( 5 );
            options.add( "ae student2" );
            reportFilterComponent.selectOptionsFromMultiSelectDropdown( "Students", options );

            List<String> selectedOptions = reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( "Students" );
            Collections.sort( selectedOptions );
            Collections.sort( options );

            Log.assertThat( selectedOptions.equals( options ), "teacher can able to select Students", "teacher can not able to select Students" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher able to view search view box is present once clicked groups dropdown", groups = { "SMK-57296", "Smoke" }, priority = 3 )
    public void tc_AFG_3() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        SaveReportFilterPopup saveReportPopup;

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();
            Log.testCaseInfo( "tc004: Verify teacher able to view search view box is present once clicked groups dropdown <small><b><i>[" + browser + "]</b></i></small>" );
            areaForGrowthPage.verifyGroupsMultiSelect();
            SMUtils.nap( 5 );
            Log.assertThat( areaForGrowthPage.verifyGroupsSearchBox(), "Groups search view box is present", "Groups search view box is not present" );

            Log.testCaseInfo( "tc005: Verify teacher able to view search view box is present once clicked Studdents dropdown <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterComponent.checkStudntRadioBtn();
            areaForGrowthPage.verifyStudentMultiSelect();
            // reportFilterComponent.expandMultiSelectDropdown("Students");
            // SMUtils.nap(10);
            // Log.assertThat((reportFilterComponent.isSearchBarDisplay("Students")),
            // "search view box is present!", "search view box is not present");

            Log.testCaseInfo( "tc006: Verify Save Report Options are enabled once fliters are get selected (Groups/Students, Subject, Assignment) <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isSaveReportButtonEnabled(), " Save Report Options are enabled", " Save Report Options are disabled" );

            Log.testCaseInfo( "tc007: Verify teacher able to save the desired report by clicking Save Report Options and ensure 'Report options saved successfully' popup should appear <small><b><i>[" + browser + "]</b></i></small>" );
            saveReportPopup = reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportPopup.isSaveButtonDisplayed(), "Save Report Option Popup Displayed", "Save Report Option Popup is not Displayed" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Area For Growth Header in the Bold format", groups = { "SMK-57296", "Smoke" }, priority = 4 )
    public void tc_AFG_4() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();

            Log.testCaseInfo( "tc14: Verify Area For Growth Header in the Bold format <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.getReportTitle().equalsIgnoreCase( "Areas For Growth Report" ), "Area For Growth Header is present", "Area For Growth Header is not present" );

            Log.testCaseInfo( "tc15: Verify help icon \"question\" mark symbol beside the Areas For Growth <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isHelpIconDisplayed(), "Help Icon is present", "Help Icon is not present" );

            Log.testCaseInfo( "tc16: Verify Reset  option is present at the bottom <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isResetButtonDisplayed(), " Reset  option is present at the bottom", " Reset  option is not present at the bottom" );

            Log.testCaseInfo( "tc17: Verify the Run Report at the bottom <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isRunReportButtonDisplayed(), " Run Report option is present at the bottom", " Run Report option is not present at the bottom" );

            Log.testCaseInfo( "tc18: Verify Optional Filters below the Groups and Students Row <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isOptionalFilterDisplaying(), "Optional Filters Displayed", "Optional Filters Not Displayed" );

            Log.testCaseInfo( "tc019: Verify Besides the Optional Filter, There should be a Filled Arrow to maximize and minimize highlighted in blue color <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isOptionalFilterFilledArrowDisplaying(), "Optional Filters Filled Arrow Displayed", "Optional Filters Filled Arrow Not Displayed" );

            Log.testCaseInfo( "tc020: Verify there should be four drop downs <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.verifyOptionalFilterDropdownsCount() == 4, "Optional Filters Dropdowns Count Displayed Correct", "Optional Filters Dropdowns Count Not Displayed Correct" );

            Log.testCaseInfo( "tc021: Verify Default Value of the Additional Grouping should be None <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.verifyAdditionalGroupingValue().equals( ReportsUIConstants.DEFAULT_ADDITIONAL_GROUPING ), "Default Value of the Additional Grouping Verified", "Default Value of the Additional Grouping Not Verified" );

            Log.testCaseInfo( "tc022: Verify Default Value for the Display should be Student Name <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.verifyDisplayDropdownValue().equals( ReportsUIConstants.DEFAULT_DISPLAY ), "Default Value of the Display Verified", "Default Value of the Display Not Verified" );

            Log.testCaseInfo( "tc023: Verify Default Value for the Sort Should be Strand <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.verifySortDropdownValue().equals( ReportsUIConstants.DEFAULT_SORT ), "Default Value of the Sort Verified", "Default Value of the Sort Not Verified" );

            Log.testCaseInfo( "tc024: Verify Default Value for the Dates at Risk should  be Since IP <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.verifyDateAtRiskDropdownValue().equals( ReportsUIConstants.DEFAULT_DATE_AT_RISK ), "Default Value of the Date At Risk Verified", "Default Value of the Date At Risk Not Verified" );

            // Log.testCaseInfo( "tc025: Verify All four drop downs should contain filled
            // arrows pointing downward Direction <small><b><i>[" + browser +
            // "]</b></i></small>" );
            // reportFilterComponent.verifyDropdownArrowDirection();

            Log.testCaseInfo( "tc026: Verify the Check box with the Text Mask Student Display <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.verifyCheckboxWithMaskStudent().equals( "Mask Student Display" ), "Check box with the Text Mask Student Display verified", "Check box with the Text Mask Student Display Not Verified" );

            Log.testCaseInfo(
                    "tc027: Verify the Text 'The Areas For Growth (AFG) Report lists the Math and Reading skills with which the selected students are having difficulty. The report groups students by these skills to allow teachers to determine which students require assistance and/or intervention.'  <small><b><i>["
                            + browser + "]</b></i></small>" );
            String expectedDescription = "The Areas For Growth (AFG) Report lists the Math and Reading skills with which the selected students are having difficulty. The report groups students by these skills to allow teachers to determine which students require assistance and/or intervention.";
            Log.assertThat( reportFilterComponent.getReportDescription().equals( expectedDescription ), "Page Description Displaying As Expected", "Page Description Not Displaying As Expected" );

            Log.testCaseInfo( "tc029: Verify Assignment dropdowns are listed in all the reports Areas For Growth by clicking it <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterComponent.isDropdownDisplyed( ReportsUIConstants.ASSIGNMENTS_LBL ), "Assignments Dropdown is Displayed", "Assignemnts Dropdown is Not Displayed" );

            Log.testCaseInfo( "tc031: Verify Assignement dropdown has search viewbox present <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL );
            Log.assertThat( reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.ASSIGNMENTS_LBL ), "Assignement dropdown search viewbox present", "Assignement dropdown search viewbox not present" );

            leftNavBar.clickOnCumulativePerformancePage();
            SMUtils.waitForPageLoad( driver );
            leftNavBar.clickOnAreaForGrowthPage();
            SMUtils.waitForPageLoad( driver );

            Log.testCaseInfo( "tc32: Verify teacher can able to get assignment by searching in the viewbox <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL );
            reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ASSIGNMENTS_LBL, ReportsUIConstants.MATH );
            List<String> options = new ArrayList<>();
            options = reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL );
            Log.assertThat( options.size() != 0, "teacher is able to get assignment by searching in viewbox", "teacher is not able to get assignment by searching in viewbox" );

            leftNavBar.clickOnCumulativePerformancePage();
            SMUtils.waitForPageLoad( driver );
            leftNavBar.clickOnAreaForGrowthPage();
            SMUtils.waitForPageLoad( driver );

            //				Log.testCaseInfo(" tc30: Verify assignement dropdown has All Assignments as default<small><b><i>[\" + browser + \"]</b></i></small>\"");
            //			    Log.assertThat(areaForGrowthPage.isAssignmentDefaultSelected(),"All Assignments are selected as default in Area of Growth", "All Assignments are not selected as default in in Area of Growth");
            //			    leftNavBar.clickOnCumulativePerformancePage();
            //			    Log.assertThat(areaForGrowthPage.isAssignmentDefaultSelected(),"All Assignments are selected as default in Cumulative Perfomance", "All Assignments are not selected as default in in Cumulative Perfomance");
            //			    leftNavBar.clickOnRecentSessionsPage();
            //			    Log.assertThat(areaForGrowthPage.isAssignmentDefaultSelected(),"All Assignments are selected as default in Last Session", "All Assignments are not selected as default in in Last Session");
            //			    leftNavBar.clickOnStudentPerformancePage();
            //			    Log.assertThat(areaForGrowthPage.isAssignmentDefaultSelected(),"All Assignments are selected as default in Studnet Perfomance", "All Assignments are not selected as default in in Studnet Perfomance");
            //			       
            //			    leftNavBar.clickOnCumulativePerformancePage();
            //				SMUtils.waitForPageLoad(driver);
            //				leftNavBar.clickOnAreaForGrowthPage();
            //				SMUtils.waitForPageLoad(driver);
            //				
            Log.testCaseInfo( "tc35: Verify the Course Selection Header " );
            String courseSelection = areaForGrowthPage.getCourseSelectionHeader();
            boolean expectedHeaderCourse = courseSelection.matches( "COURSE SELECTION" );
            Log.assertThat( expectedHeaderCourse, "Course Selection Header displayed Sucessfuly", "Course Selection Header not displayed Sucessfuly" );

            Log.testCaseInfo( "tc36: Verify Course Selection Drop down the Math Default Value" );
            String defaultDropdownSubject = areaForGrowthPage.getSubjectDefaultSelected();
            boolean subjectDefault = defaultDropdownSubject.matches( "Math" );
            Log.assertThat( subjectDefault, "Math displayed Sucessfuly", "Math not displayed Sucessfuly" );

            Log.testCaseInfo( "tc37: Verify the Additional Grouping Dropdown has two more options" );
            System.out.println( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ) );
            Log.assertThat( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONGROUP ), "All Addition Dropdown Values are displayed",
                    "All A Dropdown Values are not displayed" );

            Log.testCaseInfo( "tc42: Verify the Display Drop Down has two more options" );
            System.out.println( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ) );
            Log.assertThat( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAYNAME ), "All Display Dropdown Values are displayed",
                    "All Display Dropdown Values are not displayed" );

            Log.testCaseInfo( " tc43: Verify the Sort Drop Down has two more options" );
            System.out.println( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ) );
            Log.assertThat( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).containsAll( ReportsUIConstants.SORTNAME ), "All Sort Dropdown Values are displayed",
                    "All Sort Dropdown Values are not displayed" );

            Log.testCaseInfo( " tc44: Verify the Dates At Risk Contains the Weeks " );
            System.out.println( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ) );
            Log.assertThat( reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ).containsAll( ReportsUIConstants.DATESATRISK ), "All Dates Dropdown Values are displayed",
                    "All Dates Dropdown Values are not displayed" );

            Log.testCaseInfo( "tc37: Verify the All Groups as the default Value for the Group" );
            String defaultDropdownGroup = areaForGrowthPage.getGroupDefaultSelected().trim();
            boolean groupDefault = defaultDropdownGroup.contains( "(All) Selected" );
            Log.assertThat( groupDefault, "Group Default displayed Sucessfuly", "Group Default not displayed Sucessfuly" );

            Log.testCaseInfo( "tc38: Verify All Students as the Default Value for the Students Drop Down" );
            areaForGrowthPage.checkStudntRadioBtn();
            String defaultDropdownStudent = areaForGrowthPage.getGroupDefaultSelected().trim();
            boolean studentDefault = defaultDropdownStudent.contains( "(All) Selected" );
            Log.assertThat( studentDefault, "Student Default displayed Sucessfuly", "Student Default not displayed Sucessfuly" );

            Log.testCaseInfo( "tc40: Verify Upon clicking the \"?\" symbol help page should be obtained" );
            areaForGrowthPage.clickHelpIcon();
            SMUtils.nap( 5 );
            ArrayList<String> tabs2 = new ArrayList<String>( driver.getWindowHandles() );
            driver.switchTo().window( tabs2.get( 1 ) );
            String helpIconTitle = driver.getTitle();
            System.out.println( helpIconTitle );
            Log.assertThat( helpIconTitle.matches( "Areas For Growth Report" ), "Help Icon Page displayed Sucessfuly", "Help Icon Page not displayed Sucessfuly" );
            driver.close();
            SMUtils.nap( 5 );
            driver.switchTo().window( tabs2.get( 0 ) );
            SMUtils.nap( 5 );
            driver.switchTo().frame( "reportsIFrame" );
            reportFilterComponent.clickSaveReportOptionButton();

            Log.testCaseInfo( "tc51: Verify \"question mark\" icon beside the Save Report Options Header" );
            boolean saveQuestionMark = areaForGrowthPage.isdisplayedQuestionmark();
            Log.assertThat( saveQuestionMark, "Save Question Mark displayed Sucessfuly", "Save Question Mark not displayed Sucessfuly" );

            Log.testCaseInfo( "tc65: Verify on clicking the question mark help page related to save report options should be obtained" );
            areaForGrowthPage.clickQuestionIcon();
            ArrayList<String> tabs3 = new ArrayList<String>( driver.getWindowHandles() );
            driver.switchTo().window( tabs3.get( 1 ) );

            String saveIconTitle = driver.getTitle();
            System.out.println( saveIconTitle );
            Log.assertThat( saveIconTitle.matches( "Save Report Options" ), "Save Report Options Page displayed Sucessfuly", "Save Report Options Page not displayed Sucessfuly" );
            driver.close();
            driver.switchTo().window( tabs3.get( 0 ) );
            driver.switchTo().frame( "reportsIFrame" );
            SaveReportFilterPopup saveReport = new SaveReportFilterPopup( driver );
            saveReport.clickCancelButton();

            Log.testCaseInfo( "TC_10 Verify the previously saved reports are listed in saved report options dropdown " );
            List<String> savedReport = reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( savedReport.size() != 0, "Saved Report Dropdown Value displayed Sucessfuly", "Saved Report Dropdown Value is not  displayed Sucessfuly" );

            Log.testCaseInfo( "TC_11 Verify Teacher able to view the custom combinations of fliter by selecting the saved reports " );

            // reportFilterComponent.selectOptionsFromSingleSelectSaveReportDropdown("SAVED
            // REPORT OPTIONS", "SaveReport_02");
            SMUtils.nap( 3 );
            String defaultDropdownSubjectreport = areaForGrowthPage.getReadingSubjectDefaultSelected();
            System.out.println( defaultDropdownSubjectreport );
            boolean subjectDefaultreport = defaultDropdownSubjectreport.matches( "Reading" );
            Log.assertThat( subjectDefaultreport, "Reading displayed Sucessfuly", "Reading  not displayed Sucessfuly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify assignment dropdown , teacher can select one or more selection", groups = { "SMK-57296", "Smoke" }, priority = 5 )
    public void tc_AFG_5() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        Log.testCaseInfo( "tc_AFG_5: Verify assignment dropdown , teacher can select one or more selection <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );
            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();

            List<String> options = new ArrayList<>();
            // options.add("Select All");
            // options.add("Math");
            // options.add("Copy of Math");
            List<String> allOptions = reportFilterComponent.getAllOptionsFromAssignmentMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL );
            for ( int i = 0; i < 3; i++ ) {
                options.add( allOptions.get( i ) );
            }
            // reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
            // options);
            reportFilterComponent.selectOptionsFromMultiSelectAssignmentDropdown( ReportsUIConstants.ASSIGNMENTS_LBL, options );
            Log.message( "Clicked on Provided Options" );
            // List<String> SelectedOptions =
            // reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);
            List<String> selectedOptions = reportFilterComponent.getSelectedOptionsFromAssignmentMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL );
            Log.message( selectedOptions.toString() );
            Collections.sort( options );

            Collections.sort( selectedOptions );
            Log.assertThat( selectedOptions.equals( options ), "Teacher has selected the given options", "Teacher has not selected the given options" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Run Report, Save Report Options, and Reset are disabled  when Assignment are not Selected", groups = { "SMK-57296" }, priority = 6 )
    public void tc_AFG_6() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        Log.testCaseInfo( "tc_AFG_6: Verify the Run Report, Save Report Options, and Reset are disabled  when Assignment are not Selected <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> options = new ArrayList<>();
            options.add( "Select All" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();
            reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL, options );
            Log.message( "Clicked on Select All Option" );

            Log.assertThat( ( !reportFilterComponent.isRunReportButtonEnabled() ), "Run Report Option is disabled", "Run Report Option is not disabled" );
            Log.assertThat( ( !reportFilterComponent.isSaveReportButtonEnabled() ), "Save Report Options are disabled", "Save Report Options are not disabled" );
            Log.assertThat( ( !reportFilterComponent.isResetButtonEnabled() ), "Reset Option is disabled", "Reset Options is not disabled" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that when the Reset option is clicked then all options are Reset", groups = { "SMK-57296", "Smoke" }, priority = 7 )
    public void tc_AFG_7() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        Log.testCaseInfo( "tc_AFG_7: Verify that when the Reset option is clicked then all options are Reset <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();
            SMUtils.waitForPageLoad( driver );

            reportFilterComponent.checkStudntRadioBtn();
            reportFilterComponent.clickResetButton();
            areaForGrowthPage.verifyGroupsBtnSelected();

            Log.testCaseInfo( "tc46: Verify that when the Reset option is clicked then all options are Reset <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( areaForGrowthPage.verifyGroupsBtnSelected(), "All options are Reset", "All options are Not Resett" );

            //				Log.testCaseInfo( "tc047 & tc039: Verify the Saved Report Options have \"Choose from your list of Saved Options\" as the Default option <small><b><i>[" + browser + "]</b></i></small>" );
            //				String expectedText = "Choose from your list of saved options";
            //				String actualText = reportFilterComponent.getSavedReportOptionsText();
            //				Log.assertThat((actualText.equals(expectedText)), "Text Displays Properly!", "Text Is Not Matching With Expected");

            Log.testCaseInfo( "tc48: Verify the \"No Saved report options[...]\" text is scene when no reports are saved <small><b><i>[" + browser + "]</b></i></small>" );
            String TextExpected = "No Saved report options [...]";
            String TextActual = reportFilterComponent.getSavedReportOptionsText();
            Log.assertThat( ( TextActual.equals( TextExpected ) ), "Text Displays Properly!", "Text Is Not Matching With Expected" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify \"Save Report Options\" header is present", groups = { "SMK-57296", "Smoke" }, priority = 8 )
    public void tc_AFG_8() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        SaveReportFilterPopup reportFilterPopup;
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();

            Log.testCaseInfo( "tc049: Verify On clicking the Saved Report Options a \"Dialog box\" Should appear <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( reportFilterPopup.getReportPopupHeaderText().equals( "Save Report Options" ), "Save Report Options Dialog Box Displayed", "Save Report Options Dialog Box Not Displayed" );

            Log.testCaseInfo( "tc050: Verify \"Save Report Options\" header is present <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterPopup.getReportPopupHeaderText().equals( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "Save Report Options Header Is Present", "Save Report Options Header Is Not Present" );

            Log.testCaseInfo( "tc050: Verify \"Save Report Options\" header is present <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterPopup.getReportPopupHeaderText().equals( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "Save Report Options Header Is Present", "Save Report Options Header Is Not Present" );

            Log.testCaseInfo( "tc052: Verify the \"X\" is clickable and Closes the Save report Option <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup.clickCloseIcon();

            Log.testCaseInfo( "tc053:Verify the text \"Name and save this new custom report configuration.\" is present Save Report options dialog box <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( reportFilterPopup.getLabelForNewCustomReportConfiguration().equals( "Name and save this new custom report configuration." ), "Expected text is present Save Report options dialog box",
                    "Expected text is Not Present in Save Report options dialog box" );

            Log.testCaseInfo( "tc054:Verify the text \"Name and save this new custom report configuration.\" is present Save Report options dialog box <small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterPopup.verifyTextFromNewReportFilterConfigurationTextBox( "Name new custom report configuration" ), "Expected text is present Save Report options dialog box",
                    "Expected text is Not Present in Save Report options dialog box" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = false, description = "Verify below the textbox a horizontal line with the text \"Or\" is present such a way that the text \"Or\" breaks the line into two halves", groups = { "SMK-57296" }, priority = 9 )
    public void tc_AFG_9() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage( driver );
        LeftNavigationBar leftNavBar = new LeftNavigationBar( driver );
        ReportFilterComponent reportFilterComponent = new ReportFilterComponent( driver );
        SaveReportFilterPopup reportFilterPopup;
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to reports page
            areaForGrowthPage.navigateToReports();
            driver.switchTo().frame( ReportsUIConstants.REPORTS_IFRAME );
            // Click on Areas For Growth Report
            leftNavBar.clickOnAreaForGrowthPage();

            Log.testCaseInfo( "tc057: Verify below the textbox a horizontal line with the text \"Or\" is present such a way that the text \"Or\" breaks the line into two halves <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( reportFilterPopup.verifyHorizontalLineWithTextOR( "Or" ), "Horizontal line with text 'Or' is present Save Report options dialog box", "Horizontal line with text 'Or' is not present Save Report options dialog box" );

            Log.testCaseInfo( "tc058: Verify the text \"Select an existing custom report configuration to be replaced/updated.\" exists below the horizontal line small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterPopup.getLabelForExistingReportConfiguration().equals( "Select an existing custom report configuration to be replaced/updated." ), "Expected text is present Save Report options dialog box",
                    "Expected text is Not Present in Save Report options dialog box" );

            Log.testCaseInfo( "tc059: Verify the dropdown with the label \"Select existing custom report configuration\" is present  small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterPopup.isExistingReportOptionDropdownDisplayed(), "Existing Custom Reports Dropdown Is Present", "Existing Custom Reports Dropdown Is Present" );

            Log.testCaseInfo( "tc061: Verify the Cancel button is present and in blue color upon clicking close the dialog box small><b><i>[" + browser + "]</b></i></small>" );
            Log.assertThat( reportFilterPopup.isCancelButtonDisplayed(), "Cancel button is present", "Cancel button is not present" );
            Log.assertThat( reportFilterPopup.verifyCancleButtonColor().equals( "#006be0" ), "Cancel button Blue Color Verified", "Cancel button is not present" );
            reportFilterPopup.clickCancelButton();

            Log.testCaseInfo( "tc056 & tc057 :When the character count of the name of the report exceed 50 then a warning symbol (!) exceeds maximum length appears below the text box with red color  small><b><i>[" + browser + "]</b></i></small>" );
            String TextWithFiftyPlusChar = "SaveReportSaveReportSaveReportSaveReportSaveReportS";
            String ExpectedText = "Exceeds maximum length.";
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            reportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( TextWithFiftyPlusChar );
            Log.assertThat( reportFilterPopup.verifyErrorMessage().equals( ExpectedText ), "Verified the error message successfully after entering more than 50 chars", "Error message not Verified" );
            reportFilterPopup.clickCancelButton();

            Log.testCaseInfo( "tc062 : Verify the Save button is disabled when the name is not provided small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( !reportFilterPopup.isSaveButtonEnabled(), "Save button is Disabled", "Save button is Enabled" );
            reportFilterPopup.clickCancelButton();

            Log.testCaseInfo( "tc063 : Upon providing the name the save button enables in the blue color small><b><i>[" + browser + "]</b></i></small>" );
            String EnterText = "SaveReport" + System.nanoTime();
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            reportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( EnterText );
            Log.assertThat( reportFilterPopup.isSaveButtonEnabled(), "Save button is Enabled", "Save button is Disabled" );

            Log.testCaseInfo( "tc064 : Verify upon clicking the save then the report is saved on the areas for growth at Save Report Options small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            reportFilterPopup.enterTextInNewReportFilterConfigurationTextBox( EnterText );
            reportFilterPopup.clickSaveButton();

            SMUtils.nap( 5 );
            Log.testCaseInfo( "tc060: Verify the dropdown contains the names <small><b><i>[" + browser + "]</b></i></small>" );
            reportFilterPopup = reportFilterComponent.clickSaveReportOptionButton();
            reportFilterPopup.expandExistingReportOptionDropdown();
            int SavedOptionsListSize = reportFilterPopup.getExistingReportOptionFromDropdown().size();
            Log.assertThat( SavedOptionsListSize != 0, "dropdown contains the names", "dropdown is empty" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
