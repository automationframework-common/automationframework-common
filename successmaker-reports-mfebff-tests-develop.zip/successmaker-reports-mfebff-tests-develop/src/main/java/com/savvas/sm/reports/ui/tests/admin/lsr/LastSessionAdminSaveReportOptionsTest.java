package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class LastSessionAdminSaveReportOptionsTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> courses;
    private List<String> teachers;
    private List<String> grade;
    private List<String> group;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        username = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify 'Save Report Option'  button in LS report page", groups = { "SMK-57811", "SaveReportOption", "LSSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLSSaveReportOptions001: Verify the user can navigates to Last Session Report page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            RecentSessionsPage LastSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "TC001 Verify 'Save Report Option'  button in LS report page" );
            Log.assertThat( LastSessionPage.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in LS report",
                    "The save report option is not displayed in SPR report" );
            Log.assertThat( !LastSessionPage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();

            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "TC002 Verify user can click the 'Save Report Option' button in LS report page" );
            SMUtils.logDescriptionTC( "Verify all available fields in 'Save Report Option Popup." );
            SaveReportFilterPopup saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC003 Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC004 Verify user can able to cancel the in 'Save Report Option ' Popup on SPR report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( LastSessionPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC005 Verify User can able to save the report option with new name." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            String filterName2 = "Filter" + System.nanoTime();
            saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName2 );
            saveReportOptionPopup.clickSaveButton();
            saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( LastSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC006 Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC007 Verify If User enter more than 50 characters in new custom report configuration text box." );
            saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            SMUtils.logDescriptionTC( "TC008 Verify User can able to click the close button in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( LastSessionPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC009 Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( LastSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)", groups = { "SMK-57811", "SaveReportOption", "LSSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcLSSaveReportOptions010: Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            RecentSessionsPage LastSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );

            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'since ip' in date at risk Dropdown with Select multiple options in student demographics dropdowns and load the report" );
            LastSessionPage.reportFilterComponent.expandOptionalFilter();

            SMUtils.logDescriptionTC( "TC011 Verify User can able to multi-select Teacher option" );
            teachers = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( LastSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equals( ReportsUIConstants.SELECTED_ALL_OPTION ), "User is able to Multiple Teachers",
                    "Multiple Teacher is not selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC012 Verify User can able to multi-select Grade option" );
            grade = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( LastSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equals( ReportsUIConstants.SELECTED_ALL_OPTION ), "User is able to Multiple Grade options",
                    "Multiple Grade is not selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC013 Verify User can able to multi-select Group option" );
            group = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( LastSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equals( ReportsUIConstants.SELECTED_ALL_OPTION ), "User is able to Multiple Group options",
                    "Sort is not selected as a Username (login)" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC014 Verify User can able to single select Aditional Grouping" );
            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            Log.assertThat( LastSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).equals( ReportsUIConstants.SELECTED_ADDITIONAL_OPTION ),
                    "User is able to single select Aditional Grouping as Teacher", "Additional Grouping is not selected as a Teacher" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC015 Verify User can able to single select Sort" );
            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Student" );
            Log.assertThat( LastSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).equals( "Student" ), "User is able to single select Sort as Username (login)",
                    "Sort is not selected as a Username (login)" );

            Log.testCaseResult();

            SaveReportFilterPopup saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( LastSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report", groups = { "SMK-57946", "SaveReportOption",
            "LSSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "TC016 Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            RecentSessionsPage LastSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            orgName = LastSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );

            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( " TC017 Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report" );
            LastSessionPage.reportFilterComponent.expandOptionalFilter();

            LastSessionPage.reportFilterComponent.expandStudentDemographics();
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( LastSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "SMK-57946", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "TC018 Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            RecentSessionsPage LastSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            SMUtils.logDescriptionTC( "TC019 Verify the Existing custom report configuration dropdown if the user does not have already saved options" );

            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "Again Motion Test - Flex" );
            LastSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = LastSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            LastSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = LastSessionPage.reportFilterComponent.clickSaveReportOptionButton();

            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not  disabled if the user does not have already saved options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
