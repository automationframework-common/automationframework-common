package com.savvas.sm.reports.ui.tests.admin.cpr;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

public class CumulativePerfomanceReportAdminTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        username = "demo_sm_admin01";

    }

    @Test ( enabled = true, description = "Cumulative Performance Admin Test", groups = { "Smoke", "SMK-57939", "Cumulative Perfomance Report", "CPR" }, priority = 1 )
    public void tcSMCumulativePerfomanceTest001() throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( cumulativePerformancePage.selectOrganization(), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();

            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( cumulativePerformancePage.selectSubject( "Math" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.COURSES );
            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.COURSES, coursesName );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            cumulativePerformancePage.clickOptionalFilter();

            Log.testCaseInfo( "Verify the Teacher list" );
            List<String> teacherNames = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.TEACHERS );
            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.TEACHERS, teacherNames );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !teacherNames.isEmpty(), "Teacher dropdown have value and teacher is selected", "Teacher dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Grade list" );
            List<String> grades = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.GRADES );
            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.GRADES, grades );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !grades.isEmpty(), "Grade dropdown have value and grade is selected", "Grade dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Group list" );
            List<String> groups = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.GROUPS );
            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.GROUPS, grades );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !groups.isEmpty(), "Groups dropdown have value and group is selected", "Group dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( cumulativePerformancePage.checkReportHeaderAfterRun(), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.assertThat( cumulativePerformancePage.checkTeacherAll(), "Cumulative Performance Report Teacher data is correct", "Cumulative Performance Report Teacher data is not correct" );
            Log.assertThat( cumulativePerformancePage.checkGroupAll(), "Cumulative Performance Report Group data is correct", "Cumulative Performance Report Group data is not correct" );
            Log.assertThat( cumulativePerformancePage.checkSessionDateAll(), "Cumulative Performance Report Session date data is correct", "Cumulative Performance Report Session date data is not correct" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
