package com.savvas.sm.reports.admin.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;

public class StudentPerformanceReportViewerPage extends LoadableComponent<StudentPerformanceReportViewerPage> {

    WebDriver driver;
    boolean isPageLoaded;
    public AdminReportOutputComponent reportOutputComponent;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @FindBy ( css = "h2.header" )
    WebElement reportHeader;

    @IFindBy ( how = How.CSS, using = "div h3.assignment-name", AI = false )
    WebElement assignmentName;

    /******************* Child Elements ******************************/

    public StudentPerformanceReportViewerPage() {}

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public StudentPerformanceReportViewerPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        reportOutputComponent = new AdminReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, assignmentName );
    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, assignmentName, 30 ) ) {
            Log.message( "Cumulative Performance Report viewer Page loaded successfully." );
        } else {
            Log.fail( "Cumulative Performance Page viewer Page not loaded successfully." );
        }
        elementLayer = new ElementLayer( driver );
    }

}
