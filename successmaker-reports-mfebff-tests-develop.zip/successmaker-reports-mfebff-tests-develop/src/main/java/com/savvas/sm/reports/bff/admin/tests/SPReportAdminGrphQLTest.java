package com.savvas.sm.reports.bff.admin.tests;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.mongodb.connection.Stream;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class SPReportAdminGrphQLTest extends EnvProperties {

    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstStudentId;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String secondStudentId;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String flexSchool;
    String firstStudentGrade;
    String secondStudentGrade;
    ArrayList<String> firstGrades;
    ArrayList<String> secondGrades;
    ArrayList<String> firstStudenets;
    ArrayList<String> secondStudents;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( secondTeacherUserName ) ).get( 1 ).toString(), "groupId" );
        secondStudentId = ReportData.defaultMathAssignmentDetails.get( secondTeacherUserName ).keySet().toArray()[0].toString();
        firstStudentId = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[0].toString();
        studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );
        studentAssignmentIdReading = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );
        firstStudentGrade = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "studentGradeIds" );
        secondStudentGrade = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( secondTeacherUserName ) ).get( 1 ).toString(), "studentGradeIds" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );

        // School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    }

    @DataProvider ( name = "PositiveScenarios" )
    public Object[][] testScenario() {

        Object[][] inputData = {

                { "tc_SPR_BFF_001", "Verify the 200 status code and valid response for the district admin credentia", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },
                { "tc_SPR_BFF_002", "Verify the 200 status code and valid response for the subdistrict admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT_ADMIN" },
                { "tc_SPR_BFF_003", "Verify the 200 status code and valid response for the school admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },
                { "tc_SPR_BFF_004", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with single Teacher, Grade and Group", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_VALUE" },
                { "tc_SPR_BFF_005", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with multiple Teachers, Grades and Groups", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_VALUE" },

                { "tc_SPR_BFF_006", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with single Teacher, Grade and Group", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_VALUE_READ" },
                { "tc_SPR_BFF_007", "Verify the 200 Status code and response data when passing an organization Id with Reading subject ", CommonAPIConstants.STATUS_CODE_OK, "READING" },
                { "tc_SPR_BFF_008", "Verify the 200 Status code and response data when passing an organization Id with Reading IP OFF subject ", CommonAPIConstants.STATUS_CODE_OK, "READING_SETTINGS" }, };

        return inputData;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, List<String>> getDataFromResponse( String responseBody ) {

        List<String> level = new ArrayList<>();
        List<String> name = new ArrayList<>();
        List<String> appName = new ArrayList<>();
        List<String> appLevel = new ArrayList<>();
        List<String> exerciseCorrect = new ArrayList<>();
        List<String> exerciseAttempt = new ArrayList<>();

        HashMap<String, List<String>> studentReport = new HashMap<String, List<String>>();

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( responseBody, "data,getSPReportData,students" );
        Log.message( "JSON Object:" + jsonObj.toString() );
        // Loop1
        IntStream.range( 0, new JSONArray( jsonObj ).length() ).forEach( iter -> {

            String rawPerformance = getKeyValueFromResponseWithArray( new JSONArray( jsonObj ).get( iter ).toString(), "courses" );
            // Loop2
            IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {

                String computationStrands = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,computationStrands" );
                // Loop3
                IntStream.range( 0, new JSONArray( computationStrands ).length() ).forEach( itr2 -> {

                    name.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( computationStrands ).get( itr2 ).toString(), "name" ) );
                    level.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( computationStrands ).get( itr2 ).toString(), "level" ) );

                } );

                String applicationStrands = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,applicationStrands" );
                // Loop4
                IntStream.range( 0, new JSONArray( applicationStrands ).length() ).forEach( itr3 -> {
                    appName.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( applicationStrands ).get( itr3 ).toString(), "name" ) );
                    appLevel.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( applicationStrands ).get( itr3 ).toString(), "level" ) );

                } );

                exerciseCorrect.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,exerCorrect" ) );
                exerciseAttempt.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,exerAttempted" ) );
                List<String> newList = name.stream().distinct().collect( Collectors.toList() );
                List<String> newList2 = level.stream().distinct().collect( Collectors.toList() );
                List<String> newList3 = appName.stream().distinct().collect( Collectors.toList() );
                List<String> newList4 = appLevel.stream().distinct().collect( Collectors.toList() );
                List<String> newList5 = exerciseCorrect.stream().distinct().collect( Collectors.toList() );
                List<String> newList6 = exerciseAttempt.stream().distinct().collect( Collectors.toList() );
                newList.addAll( newList3 );
                newList2.addAll( newList4 );

                studentReport.put( "name", newList );
                studentReport.put( "level", newList2 );
                studentReport.put( "exerciseCorrect", newList5 );
                studentReport.put( "exerciseAttempt", newList6 );
            } );

        } );

        Log.message( "Response Data: " + studentReport );
        return studentReport;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, List<String>> getReadingDataFromResponse( String responseBody ) {

        List<String> level = new ArrayList<>();
        List<String> name = new ArrayList<>();
        List<String> appName = new ArrayList<>();
        List<String> appLevel = new ArrayList<>();
        List<String> exerciseCorrect = new ArrayList<>();
        List<String> exerciseAttempt = new ArrayList<>();

        HashMap<String, List<String>> studentReport = new HashMap<String, List<String>>();

        // Getting data from response
        String jsonObj = getKeyValueFromResponseWithArray( responseBody, "data,getSPReportData,students" );
        Log.message( "JSON Object:" + jsonObj.toString() );
        // Loop1
        IntStream.range( 0, new JSONArray( jsonObj ).length() ).forEach( iter -> {

            String rawPerformance = getKeyValueFromResponseWithArray( new JSONArray( jsonObj ).get( iter ).toString(), "courses" );
            // Loop2
            if ( !rawPerformance.contains( "\"skillsDelayed\":null" ) ) {

                IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {

                    String skillDelayed = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,skillsDelayed" );

                    IntStream.range( 0, new JSONArray( skillDelayed ).length() ).forEach( itr2 -> {
                        name.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillDelayed ).get( itr2 ).toString(), "strand" ) );
                        level.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( skillDelayed ).get( itr2 ).toString(), "level" ) );
                    } );
                } );
            } else {
                IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {
                    exerciseAttempt.add( SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "course,exerAttempted" ) );
                } );
            }
            List<String> newList = name.stream().distinct().collect( Collectors.toList() );
            List<String> newList2 = level.stream().distinct().collect( Collectors.toList() );
            List<String> newList6 = exerciseAttempt.stream().distinct().collect( Collectors.toList() );

            studentReport.put( "StrandDescription", newList );
            studentReport.put( "StrandLevel", newList2 );
            studentReport.put( "total_attempts", newList6 );

        } );

        Log.message( "Response Data: " + studentReport );
        return studentReport;

    }

    // test purpose
    public boolean validateResponseDataWithDB( String responseBody, String stdId, String assignmentUserId, boolean isMath ) {
        Boolean validation = false;
        if ( responseBody.contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
            Log.message( ReportAPIConstants.NO_DATA_FOUND_MESSAGE );
            validation = true;
        } else {
            HashMap<String, List<String>> dataFromResponse;
            HashMap<String, List<String>> spRdataFromDB = new HashMap<>();
            ;
            if ( isMath ) {
                // Get data from response
                dataFromResponse = getDataFromResponse( responseBody );
                Log.message( "Datas to validate from response : " + dataFromResponse );
                // Get data from DB
                spRdataFromDB = SPRdataFromDB( assignmentUserId, isMath );
                Log.message( "SPR Response From The DB " + spRdataFromDB );
            } else {
                // Get data from response
                dataFromResponse = getReadingDataFromResponse( responseBody );
                Log.message( "Datas to validate from response : " + dataFromResponse );
                // Get data from DB
                spRdataFromDB = SPRdataFromDBRead( assignmentUserId );
                Log.message( "SPR Response From The DB " + spRdataFromDB );

            }

            validation = spRdataFromDB.entrySet().stream().anyMatch( value -> dataFromResponse.get( value.getKey() ).containsAll( value.getValue() ) );

        }
        return validation;
    }

    public HashMap<String, List<String>> SPRdataFromDB( String assignmentUserId, boolean isMath ) {
        HashMap<String, List<String>> valuesFromDB = new HashMap<>();

        String query = "";
        String query2 = "";
        if ( isMath ) {
            query = "select mams.assignment_user_id, mst.strand_description," + "        case mams.strand_status\r\n" + "        when 0 then '--'\r\n" + "        when 1 then mams.strand_level::text\r\n" + "        when 2 then 'TOP'\r\n"
                    + "        when 3 then 'in IP'\r\n" + "        end as c_strand_leve\r\n" + "        from math_auser_motion_strand mams\r\n" + "        join math_strand mst on mst.strand_id=mams.strand_id\r\n"
                    + "        where mams.assignment_user_id = " + assignmentUserId + "\r\n";

            query2 = "Select total_attempts, total_correct from math_assignment_history where assignment_user_id='" + assignmentUserId + "'";

        } else {
            query = "select \r\n" + "ras.assignment_user_id,c.cttype_name , \r\n" + "ras.strand_level,ras.strand_correct,ras.strand_attempts  ,ras.strand_cttype_id,\r\n" + "case ras.strand_topped_out\r\n" + "when 0 then ras.strand_level::text \r\n"
                    + "when 1 then 'TOP'\r\n" + "end as Strand_level\r\n" + "from school.read_auser_strand ras join\r\n" + "successmaker.cttype c on ras.strand_cttype_id = c.cttype_id \r\n" + "where ras.assignment_user_id =" + assignmentUserId + "\r\n";

            query2 = "Select total_attempts, total_correct from read_assignment_history where assignment_user_id='" + assignmentUserId + "'";

        }

        List<String> name = new ArrayList<>();
        List<String> level = new ArrayList<>();
        List<String> exercise_attempts = new ArrayList<>();
        List<String> exercise_correct = new ArrayList<>();

        List<Object[]> rowList = SQLUtil.executeQuery( query );
        List<Object[]> rowList2 = SQLUtil.executeQuery( query2 );
        for ( int i = 0; i < rowList.size(); i++ ) {
            name.add( rowList.get( i )[1].toString() );
            if ( rowList.get( i )[2].toString() == null || rowList.get( i )[2].toString().isEmpty() ) {
                level.add( rowList.get( i )[2].toString().replace( rowList.get( i )[2].toString(), "null" ) );
            } else {
                level.add( rowList.get( i )[2].toString() );
            }
        }
        valuesFromDB.put( "name ", name );
        valuesFromDB.put( "level ", level );

        for ( int j = 0; j < rowList2.size(); j++ ) {
            exercise_correct.add( rowList2.get( j )[1].toString() );
            exercise_attempts.add( rowList2.get( j )[0].toString() );
        }

        valuesFromDB.put( "exerciseCorrect", exercise_correct );
        valuesFromDB.put( "exerciseAttempt", exercise_attempts );

        Log.message( "Data's from DB to validate : " + valuesFromDB );
        return valuesFromDB;
    }

    public HashMap<String, List<String>> SPRdataFromDBRead( String readAssignmentUserId ) {
        HashMap<String, String> valuesFromDB = new HashMap<>();
        HashMap<String, List<String>> arrMap = null;
        arrMap = new HashMap<String, List<String>>();

        String query = "select \r\n" + "c.cttype_name , \r\n" + "ras.strand_level,ras.strand_correct,ras.strand_attempts  ,ras.strand_cttype_id,\r\n" + "case ras.strand_topped_out\r\n" + "when 0 then ras.strand_level::text \r\n" + "when 1 then 'TOP'\r\n"
                + "end as Strand_level\r\n" + "from school.read_auser_strand ras join\r\n" + "successmaker.cttype c on ras.strand_cttype_id = c.cttype_id \r\n" + "where ras.assignment_user_id = '" + readAssignmentUserId + "'";

        String query2 = "Select total_attempts, total_correct from read_assignment_history where assignment_user_id='" + readAssignmentUserId + "'";
        // query = query.replace("mathAssignmentIds", mathAssignmentIds);
        List<Object[]> rowList = SQLUtil.executeQuery( query );
        List<Object[]> rowList2 = SQLUtil.executeQuery( query2 );
        List<String> StrandDescription = new ArrayList<>();
        List<String> StrandLevel = new ArrayList<>();
        List<String> total_attempts = new ArrayList<>();
        List<String> total_correct = new ArrayList<>();

        for ( int i = 0; i < rowList.size(); i++ ) {
            StrandDescription.add( rowList.get( i )[0].toString() );
            if ( rowList.get( i )[1].toString() == null || rowList.get( i )[1].toString().isEmpty() ) {
                StrandLevel.add( rowList.get( i )[1].toString().replace( rowList.get( i )[1].toString(), "null" ) );
            } else {
                StrandLevel.add( rowList.get( i )[1].toString() );
            }
        }
        arrMap.put( "StrandDescription", StrandDescription );
        arrMap.put( "StrandLevel", StrandLevel );

        for ( int i = 0; i < rowList2.size(); i++ ) {
            total_attempts.add( rowList2.get( i )[0].toString() );
            total_correct.add( rowList2.get( i )[1].toString() );

        }
        arrMap.put( "total_attempts", total_attempts );
        arrMap.put( "total_correct", total_attempts );

        Log.message( "************************************************************************************************\n" );
        return arrMap;
    }

    /**
     * This method is used to get values from DB
     * 
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromDB( String studentRumbaId, String mathAssignmentUserId, String readingAssignmentUserId ) {

        // Executing queries to get SEU report data from DB
        List<Object[]> mathTimeSpentQuery = SQLUtil.executeQuery( "select total_session_min as Time_Spent from math_assignment_history where assignment_user_id in (" + mathAssignmentUserId + ")" );
        List<Object[]> mathCustomTimeSpentQuery = SQLUtil.executeQuery(
                "select sum(total_session_min) as Time_Spent from math_assignment_history where assignment_user_id in  ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> mathTotalSessionQuery = SQLUtil.executeQuery(
                "select sum(session_presented_count) as Total_Sessions from math_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> readTimeSpentQuery = SQLUtil.executeQuery( "select total_session_min as Time_Spent from read_assignment_history where assignment_user_id in (" + readingAssignmentUserId + ")" );
        List<Object[]> readCustomTimeSpentQuery = SQLUtil.executeQuery(
                "select sum(total_session_min) as Time_Spent from read_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> readTotalSessionQuery = SQLUtil.executeQuery(
                "select sum(session_presented_count) as Total_Sessions from read_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );

        HashMap<String, HashMap<String, String>> dataFromDB = new HashMap<>();
        HashMap<String, String> data = new HashMap<>();
        // Get Time Spent and Total Session
        int mathCustomTime = Integer.parseInt( mathCustomTimeSpentQuery.stream().findFirst().get()[0].toString() ) - Integer.parseInt( mathTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int readCustomTime = Integer.parseInt( readCustomTimeSpentQuery.stream().findFirst().get()[0].toString() ) - Integer.parseInt( readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int totalTime = mathCustomTime + readCustomTime + Integer.parseInt( mathTimeSpentQuery.stream().findFirst().get()[0].toString() ) + Integer.parseInt( readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int totalSession = Integer.parseInt( mathTotalSessionQuery.stream().findFirst().get()[0].toString() ) + Integer.parseInt( readTotalSessionQuery.stream().findFirst().get()[0].toString() );

        data.put( "sumDefaultMathTime", mathTimeSpentQuery.stream().findFirst().get()[0].toString() );
        data.put( "sumDefaultReadingTime", readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        data.put( "sumCustomTotalTime", String.valueOf( mathCustomTime + readCustomTime ) );
        data.put( "sumTotalTime", String.valueOf( totalTime ) );
        data.put( "sumTotalSessions", String.valueOf( totalSession ) );
        data.put( "avgTotalTimePerSession", String.valueOf( new DecimalFormat( "#" ).format( (Double) ( totalTime / 10.0 ) / ( totalSession / 10.0 ) ) ) );

        dataFromDB.put( studentRumbaId, data );
        Log.message( "DB Data: " + dataFromDB );
        return dataFromDB;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {
            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }

    /**
     * This method used to fetch report data from SEU grapphql
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues - pass the optional filter values in HashMap
     * @return
     * @throws Exception
     */
    public static Response getSPReport( String username, String password, String userId, String userOrgId, String schoolId, String studentId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generted Bearer Token : " + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generted Org Id : " + userOrgId );
        Log.message( "Generted User Id : " + userId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload
        String SPRPayload = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getSPReportData(\\n    studentId: {studentId}\\n    language: \\\"en\\\"\\n    subject: \\\"%s\\\"\\n    courseList: [{courseList}]\\n    includePerformanceSummary: true\\n    includePerformanceByStrand: true\\n    includeAreasOfDifficulty: true\\n    includeRecentHistoryData: 10400\\n    filterBySchool: [\\\"%s\\\"]\\n    filterByTeacher: [{teacherId}]\\n    filterByGrade: [{grade}]\\n    filterByGroup: [{groupId}]\\n  ) {\\n    students {\\n      studentId\\n      studentFirstName\\n      studentMiddleName\\n      studentLastName\\n      studenName\\n      courses {\\n        course {\\n          name\\n          school\\n          teacher\\n          grade\\n          group\\n          assignedCourseLevel\\n          currentCourseLevel\\n          ipLevel\\n          gain\\n          exerCorrect\\n          exerAttempted\\n          cri\\n          skillsMastered\\n          skillsAssessed\\n          helpUsed\\n          audioRepeatsUsed\\n          reportCardViews\\n          glossaryUsed\\n          timeSpent\\n          totalSessions\\n          averageSessionTime\\n          computationStrands {\\n            name\\n            level\\n            skillsMastered\\n            skillsAssessed\\n          }\\n          applicationStrands {\\n            name\\n            level\\n            skillsMastered\\n            skillsAssessed\\n          }\\n          skillsDelayed {\\n            strand\\n            level\\n            description\\n          }\\n          skillsNotMastered {\\n            strand\\n            level\\n            description\\n          }\\n        }\\n      }\\n    }\\n  }\\n}\\n\"}";
        String payLoad = "";
        if ( subject.equals( Constants.MATH ) ) {
            payLoad = String.format( SPRPayload, "math", schoolId );
        } else if ( subject.equals( Constants.READING ) ) {
            payLoad = String.format( SPRPayload, "reading", schoolId );
        }
        //        String payLoad = String.format( SPRPayload, "math", schoolId );

        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().equals( ReportFilters.ADDITIONAL_GROUP_ID_VALUE ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in
            }
        }

        payLoad = payLoad.replace( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "0" ).replace( ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( ReportFilters.GROUP_ID_VALUE, "" ).replace( ReportFilters.ASSIGNMENT_ID,
                "" ).replace( DemographicFilters.DISABILITY_STATUS, "" ).replace( DemographicFilters.ENGLISH_PROFICIENCY, "" ).replace( DemographicFilters.GENDER, "" ).replace( DemographicFilters.MIGRANT_STATUS, "" ).replace( DemographicFilters.RACE,
                        "" ).replace( DemographicFilters.ETHNICITY, "" ).replace( DemographicFilters.SOCIO_STATUS, "" ).replace( DemographicFilters.SPECIAL_SERVICES, "" ).replace( "{courseList}", "" ).replace( "{studentId}", "\\\"\\\"" );
        ;
        Log.message( "Payload: " + payLoad );
        Log.message( "Headers :" + headers );
        // Getting SPR report response

        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin SPR Report Graphql", "SMK-58038", "P1" } )
    public void getAdminSPReport_Positive( String tcId, String description, String statusCode, String scenario ) throws Exception {

        String courseList;
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();
        switch ( scenario ) {
            case "DISTRICT_ADMIN":
                // filterByValues.put( "{studentId}", firstStudentId );
                response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" ) ).get( 0 ).toString(), "courses" );
                Log.message( "Subject Fetched From Response : " + subjectName );
                Log.assertThat( subjectName.contains( Constants.MATH ), "Subject is displayed as Math For District Admin", "Subject is not displayed as Math For District Admin" );
                break;

            case "SUB_DISTRICT_ADMIN":
                // filterByValues.put( "{studentId}", firstStudentId );
                response = getSPReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" ) ).get( 0 ).toString(), "courses" );
                Log.message( "Subject Fetched From Response : " + subjectName );
                Log.assertThat( subjectName.contains( Constants.MATH ), "Subject is displayed as Math For Sub District Admin", "Subject is not displayed as Math For Sub District Admin" );
                break;

            case "SCHOOL_ADMIN":
                // filterByValues.put( "{studentId}", firstStudentId );
                response = getSPReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSPReportData,students" ) ).get( 0 ).toString(), "courses" );
                Log.assertThat( subjectName.contains( Constants.MATH ), "Subject is displayed as Reading For School Admin", "Subject is not displayed as Reading For School Admin" );
                break;

            case "FILTER_BY_SINGLE_VALUE":
                // filterByValues.put( "{studentId}", firstStudentId );
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];
                filterByValues.put( "{courseList}", courseList );
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                String studentAssignmentIdMath2 = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );

                response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), firstStudentId, studentAssignmentIdMath2, true ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_VALUE":
                // filterByValues.put( "{studentId}", firstStudentId );
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];
                filterByValues.put( "{courseList}", courseList );
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                String studentAssignmentIdMath3 = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );

                response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), firstStudentId, studentAssignmentIdMath3, true ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;
            case "FILTER_BY_SINGLE_VALUE_READ":
                // filterByValues.put( "{studentId}", firstStudentId );
                courseList = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];
                filterByValues.put( "{courseList}", courseList );
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                String studentAssignmentIdReading = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );

                response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.READING, filterByValues );

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), firstStudentId, studentAssignmentIdReading, false ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;
            case "READING":

                String readAssignmentId = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];

                filterByValues.put( "{courseList}", readAssignmentId );
                response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.READING, filterByValues );

                String readAssignmentUserId = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), firstStudentId, readAssignmentUserId, false ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "READING_SETTINGS":

                String readSettingIPOnAssignmentId = ReportData.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];

                filterByValues.put( "{courseList}", readSettingIPOnAssignmentId );
                response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.READING, filterByValues );

                String readSettingsIPOnAssignmentUserId = SMUtils.getKeyValueFromResponse( ReportData.readingSettingIPMONAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), firstStudentId, readSettingsIPOnAssignmentUserId, false ), "Report data are same as DB data", "Report data are not same as DB data" );

                break;

        }

        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin SPR Report Graphql", "SMK-58038", "P1", "API", "smoke_test_case", "Schema" } )

    public void getAdminSPRReport_SchemaValidation( String tcId, String description, String statusCode, String scenario ) throws Exception {

        String[] courseList;
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        try {
            switch ( scenario ) {
                case "DISTRICT_ADMIN":

                    response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "SPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "SUB_DISTRICT_ADMIN":
                    response = getSPReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getSPReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "SPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "SCHOOL_ADMIN":
                    response = getSPReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getSPReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "SPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "FILTER_BY_SINGLE_VALUE":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );
                    studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02" );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );

                    response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "SPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "FILTER_BY_MULTI_VALUE":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );
                    studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( firstStudentId ), "studentAssignmentId" );
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01,02" );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                    response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getSPReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, firstStudentId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "SPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;
            }
        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( response, "SPR" );
        }

        Log.testCaseResult();
    }

    @Test ( priority = 2, dataProvider = "NegativeScenarios", groups = { "Admin SPR Report Graphql", "SMK-58038", "P2" } )
    public void getAdminSPRReport_Negative( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();
        String[] courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );
        for ( String courses : courseList ) {
            Log.message( "Course : " + courses );
        }

        switch ( scenario ) {

            case "INVALID_ACCESS_TOKEN":

                response = getSPReport( distAdminUserName + "INVALID", password, distAdminuserId, distId, selectedSchoolId, firstStudentId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "INVALID_ORG_ID":

                response = getSPReport( distAdminUserName, password, distAdminuserId, distId + "INVALID", selectedSchoolId, firstStudentId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "INVALID_USER_ID":

                response = getSPReport( distAdminUserName, password, distAdminuserId + "INVALID", distId, selectedSchoolId, firstStudentId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "EMPTY_ORG_ID":

                response = getSPReport( distAdminUserName, password, distAdminuserId, "", selectedSchoolId, firstStudentId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "EMPTY_USER_ID":

                response = getSPReport( distAdminUserName, password, "", distId, selectedSchoolId, firstStudentId, ReportAPIConstants.BOTH, filterByValues );
                break;
        }

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message not displayed as expected" );
        } else {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message not displayed as expected" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "NegativeScenarios" )
    public Object[][] testNegativeScenario() {
        Object[][] inputData = { { "tc_SPR_BFF_009", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SPR_BFF_010", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SPR_BFF_011", "Verify  401: UnAuthorized  and response when invalid userId is given in the query ", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SPR_BFF_012", "Verify the message in the response when organizationId passed as empty array. ", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SPR_BFF_013", "Verify the message in the response when invalid subject type passed in the query.", "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

}