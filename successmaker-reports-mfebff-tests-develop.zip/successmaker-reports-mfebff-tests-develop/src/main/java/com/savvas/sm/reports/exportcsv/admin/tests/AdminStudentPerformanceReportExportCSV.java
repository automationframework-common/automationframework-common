package com.savvas.sm.reports.exportcsv.admin.tests;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.SPRExportCSVConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import io.restassured.response.Response;

/**
 * To verify the export csv API for Admin - SPR Report
 * 
 * @author bharathi.murugan
 */
public class AdminStudentPerformanceReportExportCSV extends EnvProperties {

    private static List<String> teacherUsernames;
    private static Map<String, String> teacherUserIds = new HashMap<>();
    private static String districtAdminUsername;
    private static String districtAdminUserId;
    private static String districtId;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static String orgId;
    private static String reportRun = "06-12-2022";
    private static String browser;
    DecimalFormat df = new DecimalFormat( "0.00" );
    private Map<String, Object> saveReportOptionalFilters = new HashMap<>();
    Reports report = new Reports();
    AdminReportCsv exportCsv = new AdminReportCsv();

    @BeforeClass ( alwaysRun = true )
    public void init() {

        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        //To fetch the admin details from Report data
        try {
            districtAdminUsername = ReportDataCollection.districtAdmin;
            districtAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
            districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        } catch ( Exception e ) {
            Log.failsoft( "Getting issue while fetch the admin details from Report data" );
        }

        try {
            orgId = ReportDataCollection.orgId;

            //To fetch the teacher Details from Report Data
            teacherUsernames = new ArrayList<>( ReportDataCollection.teacherDetails.keySet() );
            teacherUsernames.stream().forEach( userName -> teacherUserIds.put( userName, SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), Constants.USERID ) ) );
        } catch ( Exception e ) {
            Log.failsoft( "Getting issue while fetch the teacher details from Report data" );
        }
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv headers (column name) in the response, for Export Default columns - Math Subject", priority = 1 )
    public void tcSPRAdminExportCSV001() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV001 - (Admin Export - SPR - default) Verify the status code and csv headers (column name) in the response, for Export Default columns - Math Subject" );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );
        Log.message( "Response : " + csvResponse.getBody().asString() );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //To verify the headers for Math - Default Export
        List<String> headersFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( getCsvValues( csvResponse ) );
        List<String> defaultMathHeaders = new ArrayList<>( SPRExportCSVConstants.DEFAULT_MATH_HEADERS );
        defaultMathHeaders.remove( 2 );
        Log.assertThat( headersFromResponse.containsAll( defaultMathHeaders ), "Export csv response fetched all the headers for Math- Default export",
                "Export csv reponse is not fetching all the headers for Math- Default export.Expected -" + SPRExportCSVConstants.DEFAULT_MATH_HEADERS + ".Actual -" + headersFromResponse );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv headers (column name) in the response, for Export Default columns - Reading Subject", priority = 1 )
    public void tcSPRAdminExportCSV002() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV002 - (Admin Export - SPR - default) Verify the status code and csv headers (column name) in the response, for Export Default columns - Reading Subject" );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "2", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );
        Log.message( "Response : " + csvResponse.getBody().asString() );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //To verify the headers for Reading - Default Export
        List<String> headersFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( getCsvValues( csvResponse ) );
        List<String> defaultMathHeaders = new ArrayList<>( SPRExportCSVConstants.DEFAULT_READING_HEADERS );
        defaultMathHeaders.remove( 2 );
        Log.assertThat( headersFromResponse.containsAll( defaultMathHeaders ), "Export csv response fetched all the headers for Reading- Default export",
                "Export csv reponse is not fetching all the headers for Reading- Default export.Expected -" + SPRExportCSVConstants.DEFAULT_READING_HEADERS + ".Actual -" + headersFromResponse );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Math Subject and for the student who has completed the IPM.", priority = 1 )
    public void tcSPRAdminExportCSV003() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV003 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Math Subject and for the student who has completed the IPM." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math who has cleared the IP",
                "The export csv api is not fetching the proper details for default-Math who has cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Reading Subject and for the student who has completed the IPM.", priority = 1 )
    public void tcSPRAdminExportCSV004() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV004 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Reading Subject and for the student who has completed the IPM." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "2", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "reading", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", false, "Reading", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"IP Level Summary\"" );
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Reading who has cleared the IP",
                "The export csv api is not fetching the proper details for default-Reading who has cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Math Subject and for the student who has not completed the IPM.", priority = 1 )
    public void tcSPRAdminExportCSV005() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV005 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Math Subject and for the student who has not completed the IPM." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "2", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math who has not cleared the IP",
                "The export csv api is not fetching the proper details for default-Math who has not cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Reading Subject and for the student who has not completed the IPM.", priority = 1 )
    public void tcSPRAdminExportCSV006() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV006 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Reading Subject and for the student who has not completed the IPM." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "2", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "reading", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "2", false, "Reading", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"IP Level Summary\"" );
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Reading who has not cleared the IP",
                "The export csv api is not fetching the proper details for default-Reading who has not cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Math - IPM on course.", priority = 1 )
    public void tcSPRAdminExportCSV007() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV007 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Math Subject and for the student who has not completed the IPM." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.mathSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "MathCustomSettings", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for Custom Setting Math - IPM on course who has cleared the IP",
                "The export csv api is not fetching the proper details for Custom Setting Math - IPM on course who has cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Math - IPM off course.", priority = 1 )
    public void tcSPRAdminExportCSV008() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV008 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Math - IPM off course." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.mathSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "1", true, "MathCustomSettings", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for Custom Setting Math - IPM off course",
                "The export csv api is not fetching the proper details for Custom Setting Math - IPM off course. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Reading - IPM on course.", priority = 1 )
    public void tcSPRAdminExportCSV009() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV009 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Reading - IPM on course." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "2", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "reading", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", false, "ReadingCustomSettings", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        actualExportedCsv.remove( "\"IP Level Summary\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for Custom Setting Reading - IPM on course who has cleared the IP",
                "The export csv api is not fetching the proper details for Custom Setting Reading - IPM on course who has cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Reading - IPM off course.", priority = 1 )
    public void tcSPRAdminExportCSV010() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV010 - (Admin Export - SPR - default) Verify the status code and csv values in the response, for Export Default columns - Custom by Setting Reading - IPM off course." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.readingSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "2", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "reading", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "1", false, "ReadingCustomSettings", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        actualExportedCsv.remove( "\"IP Level Summary\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for Custom Setting Reading - IPM off course",
                "The export csv api is not fetching the proper details for Custom Setting Reading - IPM off course. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - custom) Verify the status code and csv headers (column name) in the response, for custom Export - Math Subject", priority = 1 )
    public void tcSPRAdminExportCSV011() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV011 - (Admin Export - SPR - custom) Verify the status code and csv headers (column name) in the response, for custom Export - Math Subject" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, true, "en", false, true, true, true,
                SPRExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS, requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", false );
        expectedData.remove( "\"group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"studentUsername\"" ).equalsIgnoreCase( expectedData.get( "\"studentUsername\"" ) )
                && exportcsvDetail.get( "\"courseName\"" ).equalsIgnoreCase( expectedData.get( "\"courseName\"" ) ) ).findFirst().orElse( null );

        //To verify the columns headers
        List<String> headersFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( getCsvValues( csvResponse ) );
        Log.assertThat( headersFromResponse.containsAll( SPRExportCSVConstants.CUSTOM_MATH_HEADERS ), "Custom Export csv response fetched all the headers for Math export",
                "Custom Export csv reponse is not fetching all the headers for Math export.Expected -" + SPRExportCSVConstants.CUSTOM_MATH_HEADERS + ".Actual -" + headersFromResponse );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The custom export csv api fetches the proper details for default-Math who has cleared the IP",
                "The custom export csv api is not fetching the proper details for default-Math who has cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - custom) Verify the status code and csv headers (column name) in the response, for custom Export - Reading Subject", priority = 1 )
    public void tcSPRAdminExportCSV012() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV012 - (Admin Export - SPR - custom) Verify the status code and csv headers (column name) in the response, for custom Export - Reading Subject" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "2", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, true, "en", false, true, true, true,
                SPRExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS, requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "reading", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", false, "Reading", false );
        expectedData.remove( "\"group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"studentUsername\"" ).equalsIgnoreCase( expectedData.get( "\"studentUsername\"" ) )
                && exportcsvDetail.get( "\"courseName\"" ).equalsIgnoreCase( expectedData.get( "\"courseName\"" ) ) ).findFirst().orElse( null );

        //To verify the columns headers
        List<String> headersFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvResponse.getBody().asString() );
        Log.assertThat( headersFromResponse.containsAll( SPRExportCSVConstants.CUSTOM_READING_HEADERS ), "Custom Export csv response fetched all the headers for Math export",
                "Custom Export csv reponse is not fetching all the headers for Math export.Expected -" + SPRExportCSVConstants.CUSTOM_READING_HEADERS + ".Actual -" + headersFromResponse );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The custom export csv api fetches the proper details for default-Math who has cleared the IP",
                "The custom export csv api is not fetching the proper details for default-Reading who has cleared the IP. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - custom) Verify the status code and csv headers (column name) , If pass the Multiple custom fields.", priority = 1 )
    public void tcSPRAdminExportCSV013() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV013 - (Admin Export - SPR - custom) Verify the status code and csv headers (column name) , If pass the Multiple custom fields." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, true, "en", false, true, true, true,
                Arrays.asList( "studentId", "studenName", "courses.exerCorrectPercent" ), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //To verify the columns headers
        List<String> headersFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( getCsvValues( csvResponse ) );
        Log.assertThat( headersFromResponse.containsAll( Arrays.asList( "\"studentId\"", "\"studentName\"", "\"exerCorrectPercent\"" ) ), "Custom Export csv response fetched all the headers for Math export",
                "Custom Export csv reponse is not fetching all the headers for Math export.Expected -" + Arrays.asList( "studentId", "studentName", "exerCorrectPercent" ) + ".Actual -" + headersFromResponse );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - custom) Verify the status code and csv headers (column name) , If pass  one custom fields on request body.", priority = 1 )
    public void tcSPRAdminExportCSV014() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV014 - (Admin Export - SPR - custom) Verify the status code and csv headers (column name) , If pass the Multiple custom fields." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, true, "en", false, true, true, true,
                Arrays.asList( "courses.exerCorrectPercent" ), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //To verify the columns headers
        List<String> headersFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( getCsvValues( csvResponse ) );
        Log.assertThat( headersFromResponse.containsAll( Arrays.asList( "\"exerCorrectPercent\"" ) ), "Custom Export csv response fetched all the headers for Math export",
                "Custom Export csv reponse is not fetching all the headers for Math export.Expected -" + Arrays.asList( "exerCorrectPercent" ) + ".Actual -" + headersFromResponse );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the Mask Student display as true.", priority = 1 )
    public void tcSPRAdminExportCSV015() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV015 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the Mask Student display as true." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", true, true, true, true,
                new ArrayList<>(), requestId );
        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        Log.assertThat( exportcsvDetails.get( 0 ).get( "\"Student Name\"" ).contains( "Student " ), "The export csv api fetches the proper details for default-Math while pass the Mask student display as true",
                "The export csv api is not fetching the proper details for default-Math while pass the Mask student display as true. Expected - " + "\"Student 1\" for student username" + ".Actual -" + exportcsvDetails.get( 0 ).get( "Student Name" ) );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the language as \"es\"", priority = 1 )
    public void tcSPRAdminExportCSV016() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV016 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the language as \"es\"" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "language", "SPANISH" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "es", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the language as spanish (es)",
                "The export csv api is not fetching the proper details for default-Math while pass the language as spanish (es). Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the teacher ids in the teacher filter", priority = 1 )
    public void tcSPRAdminExportCSV017() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV017 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the teacher ids in the teacher filter" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        List<String> teacherIds = teacherUserIds.entrySet().stream().map( entry -> entry.getValue() ).collect( Collectors.toList() );
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), teacherIds, new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );
        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the teacher Ids in the filter",
                "The export csv api is not fetching the proper details for default-Math  teacher Ids in the filter. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the grade ids in the grade filter", priority = 1 )
    public void tcSPRAdminExportCSV018() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV018 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the grade ids in the grade filter" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        //To hit the SPR export csv API 
        List<String> gradeIds = Arrays.asList( "KG", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "grades", gradeIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), gradeIds, assignmentIds, 10400, false, "en", false, true, true, true, new ArrayList<>(),
                requestId );
        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the gradeIds in the filter",
                "The export csv api is not fetching the proper details for default-Math while pass the gradeIds in the filter. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the group ids in the group filter", priority = 1 )
    public void tcSPRAdminExportCSV019() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV019 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the group ids in the group filter" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        //To hit the SPR export csv API 
        List<String> groupIds = new ArrayList<>();
        IntStream.range( 0, 2 ).forEach(
                itr -> ReportDataCollection.teacherGroupDetails.entrySet().stream().forEach( groupDetails -> groupIds.add( SMUtils.getKeyValueFromResponse( new JSONArray( groupDetails.getValue() ).get( itr ).toString(), "groupId" ) ) ) );
        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "groups", groupIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), groupIds, new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, true, new ArrayList<>(),
                requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the groupIds in the filter",
                "The export csv api is not fetching the proper details for default-Math while pass the groupIds in the filter. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case",
            "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the teacher Ids, Grade Id and group ids in the tecaher, grade and group filter", priority = 1 )
    public void tcSPRAdminExportCSV020() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV020 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the teacher Ids, Grade Id and group ids in the tecaher, grade and group filter" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        //To hit the SPR export csv API 
        List<String> teacherIds = teacherUserIds.entrySet().stream().map( entry -> entry.getValue() ).collect( Collectors.toList() );
        List<String> gradeIds = Arrays.asList( "KG", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" );
        List<String> groupIds = new ArrayList<>();
        IntStream.range( 0, 2 ).forEach(
                itr -> ReportDataCollection.teacherGroupDetails.entrySet().stream().forEach( groupDetails -> groupIds.add( SMUtils.getKeyValueFromResponse( new JSONArray( groupDetails.getValue() ).get( itr ).toString(), "groupId" ) ) ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "grades", gradeIds );
        saveReportOptionalFilters.put( "groups", groupIds );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), teacherIds, groupIds, gradeIds, assignmentIds, 10400, false, "en", false, true, true, true, new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the teacherIds, groupIds and gradeIds in the filter",
                "The export csv api is not fetching the proper details for default-Math while pass the teacherIds, groupIds and gradeIds in the filter. Expected - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the includePerformanceSummary as false in request body.", priority = 1 )
    public void tcSPRAdminExportCSV021() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV021 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the includePerformanceSummary as false in request body." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "includePerformanceSummary", "no" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, false, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the includePerformanceBySummary as false",
                "The export csv api is not fetching the proper details for default-Math while pass the includePerformanceBySummary as false - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the includePerformanceByStrand as false in request body.", priority = 1 )
    public void tcSPRAdminExportCSV022() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV022 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the includePerformanceByStrand as false in request body." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "includePerformanceByStrand", "no" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, false, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the includePerformanceByStrand as false",
                "The export csv api is not fetching the proper details for default-Math while pass the includePerformanceByStrand as false - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the includeAreasOfDifficulty as false in request body.", priority = 1 )
    public void tcSPRAdminExportCSV023() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV023 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the includeAreasOfDifficulty as false in request body." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "includeAreasOfGrowth", "no" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 10400, false, "en", false, true, true, false,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the includeAreasOfDifficulty as false",
                "The export csv api is not fetching the proper details for default-Math while pass the includeAreasOfDifficulty as false - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default) Verify the status code and csv values, If pass the includeRecentHistoryData as 2 Weeks in request body.", priority = 1 )
    public void tcSPRAdminExportCSV024() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV024 - (Admin Export - SPR - default) Verify the status code and csv values, If pass the includeRecentHistoryData as 2 Weeks in request body." );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "datesAtRisk", "2" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 2, false, "en", false, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 200, "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 200 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        List<Map<String, String>> exportcsvDetails = ExportCsvUtils.splitCSVData( getCsvValues( csvResponse ) );

        //To get the Report BFF response
        Map<String, String> filters = new HashMap<>();
        filters.put( "{assignmentId}", assignmentIds.toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ) );
        Response responseBFF = ReportAPI.getSPRReportBFF( districtAdminUsername, password, districtAdminUserId, districtId, orgId, "math", filters );
        Map<String, String> expectedData = getStudentReportDetail( responseBFF.getBody().asString(), "3", true, "Math", true );
        expectedData.remove( "\"Group\"" );

        //To get the student detail from the response who cleared the IP
        Map<String, String> actualExportedCsv = exportcsvDetails.stream().filter( exportcsvDetail -> exportcsvDetail.get( "\"Student Username\"" ).equalsIgnoreCase( expectedData.get( "\"Student Username\"" ) )
                && exportcsvDetail.get( "\"Assignment Name\"" ).equalsIgnoreCase( expectedData.get( "\"Assignment Name\"" ) ) ).findFirst().orElse( null );

        //To verify the Exported csv data with BFF response
        actualExportedCsv.remove( "\"Group\"" );
        Log.assertThat( SMUtils.compareTwoHashMap( actualExportedCsv, expectedData ), "The export csv api fetches the proper details for default-Math while pass the includeRecentHistoryData as 2 weeks",
                "The export csv api is not fetching the proper details for default-Math while pass the includeRecentHistoryData as 2 weeks - " + expectedData.toString() + ".Actual -" + actualExportedCsv.toString() );
    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default)  Verify the response and staus code, id pass the invalid or empty org-id in headers", priority = 1 )
    public void tcSPRAdminExportCSV025() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV025 - (Admin Export - SPR - default)  Verify the response and staus code, id pass the invalid or empty org-id in headers" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "datesAtRisk", "2" );
        saveReportOptionalFilters.put( "maskStudentDisplay", "true" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //Empty org Id
        headers.put( UserConstants.ORGID, "" );
        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 2, false, "en", true, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 400, "The Status code is expected " + 400 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 400 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //Error message validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( csvResponse.getBody().asString(), "message" ).equalsIgnoreCase( "Invalid value passed for org-id" ), "Error Message Verified successfully!",
                "Issue in displaying Message! Expected - Invalid value passed for org-id. Actual -" + SMUtils.getKeyValueFromResponse( csvResponse.getBody().asString(), "message" ) );

    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default)  Verify the response and staus code, id pass the invalid or empty user-id in headers", priority = 1 )
    public void tcSPRAdminExportCSV026() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV026 - (Admin Export - SPR - default)  Verify the response and staus code, id pass the invalid or empty user-id in headers" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "datesAtRisk", "2" );
        saveReportOptionalFilters.put( "maskStudentDisplay", "true" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );

        //Empty user Id
        headers.put( UserConstants.USERID, "" );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 2, false, "en", true, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 400, "The Status code is expected " + 400 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 400 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //Error message validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( csvResponse.getBody().asString(), "message" ).equalsIgnoreCase( "Invalid value passed for user-id" ), "Error Message Verified successfully!",
                "Issue in displaying Message! Expected - Invalid value passed for user-id. Actual -" + SMUtils.getKeyValueFromResponse( csvResponse.getBody().asString(), "message" ) );

    }

    @Test ( enabled = true, groups = { "SMK-68196", "smoke_test_case", "SPR-ExportCSV" }, description = "(Admin Export - SPR - default)  Verify the response and staus code, id pass the invalid or empty -authorization in headers", priority = 1 )
    public void tcSPRAdminExportCSV027() throws Exception {

        Log.testCaseInfo( "tcSPRAdminExportCSV027 - (Admin Export - SPR - default)  Verify the response and staus code, id pass the invalid or empty -authorization in headers" );

        //To get the assignment Ids
        List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() );

        Log.message( "Assignment Ids :" + assignmentIds.toString() );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, districtAdminUserId );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        saveReportOptionalFilters.put( "courses", assignmentIds );
        saveReportOptionalFilters.put( "datesAtRisk", "2" );
        saveReportOptionalFilters.put( "maskStudentDisplay", "true" );

        Response saveResponse = report.saveAdminSPReportOption( headers, orgId, "1", saveReportOptionalFilters, false, "" );
        String requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
        //Invalid access token
        headers.put( Constants.AUTHORIZATION, "Bearer Invalid" );

        //To hit the SPR export csv API 
        Response csvResponse = exportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( orgId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), assignmentIds, 2, false, "en", true, true, true, true,
                new ArrayList<>(), requestId );

        // status code Validation
        Log.assertThat( csvResponse.getStatusCode() == 401, "The Status code is expected " + 401 + " and actual " + csvResponse.getStatusCode() + " Verified",
                "The Status code is expected " + 401 + " and actual " + csvResponse.getStatusCode() + "is not Verified" );

        //Error message validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( csvResponse.getBody().asString(), "message" ).equalsIgnoreCase( "Unauthorized" ), "Error Message Verified successfully!",
                "Issue in displaying Message! Expected - Unauthorized. Actual -" + SMUtils.getKeyValueFromResponse( csvResponse.getBody().asString(), "message" ) );

    }

    /**
     * To Split the Report BFF response into Hashmap
     * 
     * @param responseBFF
     * @param ipmStatusId
     * @param isMath
     * @param subjectName
     * @param isDefaultExport
     * @return
     */
    public Map<String, String> getStudentReportDetail( String responseBFF, String ipmStatusId, boolean isMath, String subjectName, boolean isDefaultExport ) {

        Map<String, String> ReportBFFDetails = new HashMap<>();
        JSONObject jsonObject = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( responseBFF, "data" ), "getSPReportData" ) );
        JSONArray allStudents = jsonObject.getJSONArray( "students" );

        String courseDetail = null;
        for ( int itr = 0; itr < allStudents.length(); itr++ ) {
            JSONArray courses = new JSONObject( allStudents.get( itr ).toString() ).getJSONArray( "courses" );
            for ( int iteration = 0; iteration < courses.length(); iteration++ ) {
                JSONObject course = new JSONObject( courses.get( iteration ).toString() ).getJSONObject( "course" );
                if ( course.getString( "ipmStatusID" ).equals( ipmStatusId ) && course.getString( "name" ).contains( subjectName ) ) {
                    if ( isDefaultExport ) {
                        ReportBFFDetails.put( "\"Report Run\"", reportRun );
                        ReportBFFDetails.put( "\"Student Id\"", new JSONObject( allStudents.get( itr ).toString() ).getString( "studentId" ) );
                        ReportBFFDetails.put( "\"Student Name\"", new JSONObject( allStudents.get( itr ).toString() ).getString( "studenName" ) );
                        ReportBFFDetails.put( "\"Student Username\"", new JSONObject( allStudents.get( itr ).toString() ).getString( "studentUsername" ) );
                    } else {
                        ReportBFFDetails.put( "\"reportRun\"", reportRun );
                        ReportBFFDetails.put( "\"studentId\"", new JSONObject( allStudents.get( itr ).toString() ).getString( "studentId" ) );
                        ReportBFFDetails.put( "\"studentName\"", new JSONObject( allStudents.get( itr ).toString() ).getString( "studenName" ) );
                        ReportBFFDetails.put( "\"studentUsername\"", new JSONObject( allStudents.get( itr ).toString() ).getString( "studentUsername" ) );
                    }
                    courseDetail = course.toString();
                    break;
                }
            }
            if ( Objects.nonNull( courseDetail ) ) {
                break;
            }
        }
        List<String> selectedFilters;
        if ( isMath ) {
            if ( isDefaultExport ) {
                selectedFilters = SPRExportCSVConstants.DEFAULT_MATH_SELECTED_FILTERS;
            } else {
                selectedFilters = SPRExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS;
            }
        } else {
            if ( isDefaultExport ) {
                selectedFilters = SPRExportCSVConstants.DEFAULT_READING_SELECTED_FILTERS;
            } else {
                selectedFilters = SPRExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS;
            }
        }
        if ( isDefaultExport ) {
            for ( String filters : selectedFilters ) {
                if ( filters.contains( "courses." ) ) {
                    String filter = filters.replace( "courses.", "" ).replace( "IPMPercent", "IPPercent" );
                    String[] fieldName = filter.split( "[.]", 0 );
                    String value = courseDetail;
                    if ( filter.equals( "exerCorrectPercent" ) ) {
                        if ( ipmStatusId.equals( "1" ) ) {
                            try {
                                ReportBFFDetails.put( "\"Exercises Percent Correct\"",
                                        String.valueOf( Math.round( ( ( Double.valueOf( ReportBFFDetails.get( "\"Exercises Correct\"" ) ) ) * 100 ) / ( Double.valueOf( ReportBFFDetails.get( "\"Exercises Attempted\"" ) ) ) ) ) + "%" );
                            } catch ( NumberFormatException e ) {
                                ReportBFFDetails.put( "\"Exercises Percent Correct\"", "--" );
                            }
                        } else {
                            ReportBFFDetails.put( "\"Exercises Percent Correct\"", String.valueOf( Math.round( ( ( Double.valueOf( ReportBFFDetails.get( "\"Exercises Correct\"" ) ) - Double.valueOf( ReportBFFDetails.get( "\"IP Correct\"" ) ) ) * 100 )
                                    / ( Double.valueOf( ReportBFFDetails.get( "\"Exercises Attempted\"" ) ) - Double.valueOf( ReportBFFDetails.get( "\"IP Attempted\"" ) ) ) ) ) + "%" );
                        }
                    } else if ( filter.equals( "skillsMasteredPercent" ) ) {
                        try {
                            ReportBFFDetails.put( "\"Skills Percent Mastered\"",
                                    String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"Skills Mastered\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"Skills Assessed\"" ) ) ) ) + "%" );
                        } catch ( NumberFormatException e ) {
                            ReportBFFDetails.put( "\"Skills Percent Mastered\"", "--" );
                        }
                    } else if ( filter.equals( "\"IPMCorrect\"" ) && !ipmStatusId.equals( "1" ) ) {
                        ReportBFFDetails.put( "\"IP Correct\"", String.valueOf( ( new JSONObject( value ).get( "IPMCorrect" ).toString().equals( "null" ) ? 0 : Integer.valueOf( new JSONObject( value ).get( "IPMCorrect" ).toString() ) )
                                + ( new JSONObject( value ).get( "k2IpmTotalCorrect" ).toString().equals( "null" ) ? 0 : Integer.valueOf( new JSONObject( value ).get( "k2IpmTotalCorrect" ).toString() ) ) ) );
                    } else if ( filter.equals( "IPMAttempted" ) && !ipmStatusId.equals( "1" ) ) {
                        ReportBFFDetails.put( "\"IP Attempted\"", String.valueOf( ( new JSONObject( value ).get( "IPMAttempted" ).toString().equals( "null" ) ? 0 : Integer.valueOf( new JSONObject( value ).get( "IPMAttempted" ).toString() ) )
                                + ( new JSONObject( value ).get( "k2IpmTotalAttempts" ).toString().equals( "null" ) ? 0 : Integer.valueOf( new JSONObject( value ).get( "k2IpmTotalAttempts" ).toString() ) ) ) );
                    } else if ( filter.equals( "IPPercent" ) && !ipmStatusId.equals( "1" ) ) {
                        ReportBFFDetails.put( "\"IP Percent Correct\"", String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"IP Correct\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"IP Attempted\"" ) ) ) ) + "%" );
                    } else if ( filter.equals( "otherPerformance.IndependentPractice.exerCorrectPercent" ) ) {
                        if ( Objects.isNull( ReportBFFDetails.get( "\"Independent Practice Exercises Attempted\"" ) ) || ReportBFFDetails.get( "\"Independent Practice Exercises Attempted\"" ).equals( "0" )
                                || ReportBFFDetails.get( "\"Independent Practice Exercises Attempted\"" ).equals( "null" ) || ipmStatusId.equals( "2" ) ) {
                            ReportBFFDetails.put( "\"Independent Practice Exercises Attempted\"", "--" );
                            ReportBFFDetails.put( "\"Independent Practice Exercises Correct\"", "--" );
                            ReportBFFDetails.put( "\"Independent Practice Exercises Percent Correct\"", "--" );
                        } else {
                            ReportBFFDetails.put( "\"Independent Practice Exercises Percent Correct\"",
                                    String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"Independent Practice Exercises Correct\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"Independent Practice Exercises Attempted\"" ) ) ) )
                                            + "%" );
                        }
                    } else if ( filter.equals( "otherPerformance.Remediation.exerCorrectPercent" ) ) {
                        if ( Objects.isNull( ReportBFFDetails.get( "\"Remediation Exercises Attempted\"" ) ) || ReportBFFDetails.get( "\"Remediation Exercises Attempted\"" ).equals( "0" )
                                || ReportBFFDetails.get( "\"Remediation Exercises Attempted\"" ).equals( "null" ) || ipmStatusId.equals( "2" ) ) {
                            ReportBFFDetails.put( "\"Remediation Exercises Attempted\"", "--" );
                            ReportBFFDetails.put( "\"Remediation Exercises Correct\"", "--" );
                            ReportBFFDetails.put( "\"Remediation Exercises Percent Correct\"", "--" );
                        } else {
                            ReportBFFDetails.put( "\"Remediation Exercises Percent Correct\"",
                                    String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"Remediation Exercises Correct\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"Remediation Exercises Attempted\"" ) ) ) ) + "%" );
                        }
                    } else if ( filter.equals( "ipLevelSummary" ) ) {

                    } else if ( filter.equals( "gain" ) && ipmStatusId.equals( "3" ) ) {

                        Double gain = Double.valueOf( ReportBFFDetails.get( "\"Current Course Level\"" ) ) - Double.valueOf( ReportBFFDetails.get( "\"IP Level\"" ) );
                        ReportBFFDetails.put( "\"Gain\"", gain >= 0 ? df.format( gain ) : "0.00" );

                    } else {
                        for ( int itr = 0; itr < fieldName.length; itr++ ) {
                            try {
                                value = new JSONObject( value ).get( fieldName[itr] ).toString();
                            } catch ( Exception e ) {
                                value = "null";
                            }
                        }
                        if ( isMath ) {
                            ReportBFFDetails.put( SPRExportCSVConstants.DEFAULT_MATH_HEADERS.get( selectedFilters.indexOf( filters ) ), value );
                        } else {
                            ReportBFFDetails.put( SPRExportCSVConstants.DEFAULT_READING_HEADERS.get( selectedFilters.indexOf( filters ) ), value );
                        }
                    }
                }
            }

            if ( !ipmStatusId.equals( "2" ) ) {
                if ( ipmStatusId.equals( "1" ) ) {
                    ReportBFFDetails.put( "\"IP Correct\"", "NA" );
                    ReportBFFDetails.put( "\"IP Attempted\"", "NA" );
                    ReportBFFDetails.put( "\"IP Percent Correct\"", "NA" );
                    ReportBFFDetails.put( "\"IP Level\"", "NA" );
                    ReportBFFDetails.put( "\"Gain\"", "NA" );
                    ReportBFFDetails.put( "\"Placed\"", "NA" );
                    ReportBFFDetails.put( "\"IP Time Spent\"", "NA" );
                } else {
                    ReportBFFDetails.put( "\"IP Level\"", df.format( Double.valueOf( ReportBFFDetails.get( "\"IP Level\"" ) ) ) );
                    ReportBFFDetails.put( "\"Gain\"", df.format( Double.valueOf( ReportBFFDetails.get( "\"Gain\"" ) ) ) );
                    SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yy" );
                    try {
                        Date dt = sdf.parse( ReportBFFDetails.get( "\"Placed\"" ) );
                        sdf = new SimpleDateFormat( "MM/dd/yyyy" );
                        ReportBFFDetails.put( "\"Placed\"", sdf.format( dt ) );
                    } catch ( ParseException e ) {
                        Log.message( "Getting issue while convert minutes into hh:mm format" );
                        e.printStackTrace();
                    }

                    ReportBFFDetails.put( "\"Exercises Correct\"", String.valueOf( Integer.valueOf( ReportBFFDetails.get( "\"Exercises Correct\"" ) ) - Integer.valueOf( ReportBFFDetails.get( "\"IP Correct\"" ) ) ) );
                    ReportBFFDetails.put( "\"Exercises Attempted\"", String.valueOf( Integer.valueOf( ReportBFFDetails.get( "\"Exercises Attempted\"" ) ) - Integer.valueOf( ReportBFFDetails.get( "\"IP Attempted\"" ) ) ) );
                    ReportBFFDetails.put( "\"IP Time Spent\"", convertMinutesIntohours( ReportBFFDetails.get( "\"IP Time Spent\"" ) ) );
                }
                ReportBFFDetails.put( "\"Current Course Level\"", df.format( Double.valueOf( ReportBFFDetails.get( "\"Current Course Level\"" ) ) ) );
                ReportBFFDetails.put( "\"Assigned Course Level\"", df.format( Double.valueOf( ReportBFFDetails.get( "\"Assigned Course Level\"" ) ) ) );
                if ( ReportBFFDetails.get( "\"Skills Assessed\"" ).equals( "0" ) ) {
                    ReportBFFDetails.put( "\"Skills Assessed\"", "--" );
                    ReportBFFDetails.put( "\"Skills Mastered\"", "--" );
                    ReportBFFDetails.put( "\"Skills Percent Mastered\"", "--" );
                }

                if ( ReportBFFDetails.get( "\"Exercises Attempted\"" ).equals( "0" ) ) {
                    ReportBFFDetails.put( "\"Exercises Attempted\"", "--" );
                    ReportBFFDetails.put( "\"Exercises Correct\"", "--" );
                    ReportBFFDetails.put( "\"Exercises Percent Correct\"", "--" );
                } else if ( ReportBFFDetails.get( "\"Exercises Correct\"" ).equals( "0" ) ) {
                    ReportBFFDetails.put( "\"Exercises Correct\"", "--" );
                    ReportBFFDetails.put( "\"Exercises Percent Correct\"", "--" );
                }

                if ( isMath ) {
                    if ( ReportBFFDetails.get( "\"Computation Retention Index (CRI)\"" ).equals( "0" ) ) {
                        ReportBFFDetails.put( "\"Computation Retention Index (CRI)\"", "NA" );
                    } else {
                        ReportBFFDetails.put( "\"Computation Retention Index (CRI)\"", ReportBFFDetails.get( "\"Computation Retention Index (CRI)\"" ) + "%" );
                    }
                } else {
                    if ( ReportBFFDetails.get( "\"Retention Index (RI)\"" ).equals( "0" ) ) {
                        ReportBFFDetails.put( "\"Retention Index (RI)\"", "NA" );
                    } else {
                        ReportBFFDetails.put( "\'Retention Index (RI)\"", ReportBFFDetails.get( "\"Computation Retention Index (CRI)\"" ) + "%" );
                    }
                }
            } else {

                ReportBFFDetails.put( "\"IP Correct\"", ReportBFFDetails.get( "\"Exercises Correct\"" ) );
                ReportBFFDetails.put( "\"IP Attempted\"", ReportBFFDetails.get( "\"Exercises Attempted\"" ) );
                ReportBFFDetails.put( "\"IP Percent Correct\"", String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"IP Correct\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"IP Attempted\"" ) ) ) ) + "%" );
                ReportBFFDetails.put( "\"IP Level\"", "In IP" );
                ReportBFFDetails.put( "\"Placed\"", "NA" );
                ReportBFFDetails.put( "\"Assigned Course Level\"", df.format( Double.valueOf( ReportBFFDetails.get( "\"Assigned Course Level\"" ) ) ) );
                ReportBFFDetails.put( "\"Current Course Level\"", "In IP" );
                ReportBFFDetails.put( "\"Gain\"", "In IP" );
                ReportBFFDetails.put( "\"Exercises Correct\"", "In IP" );
                ReportBFFDetails.put( "\"Exercises Attempted\"", "In IP" );
                ReportBFFDetails.put( "\"Exercises Percent Correct\"", "In IP" );
                ReportBFFDetails.put( "\"Skills Mastered\"", "In IP" );
                ReportBFFDetails.put( "\"Skills Assessed\"", "In IP" );
                ReportBFFDetails.put( "\"Skills Percent Mastered\"", "In IP" );
                ReportBFFDetails.put( "\"IP Time Spent\"", convertMinutesIntohours( ReportBFFDetails.get( "\"IP Time Spent\"" ).equals( "null" ) ? "0" : ReportBFFDetails.get( "\"IP Time Spent\"" ) ) );

                if ( isMath ) {
                    ReportBFFDetails.put( "\"Computation Retention Index (CRI)\"", "In IP" );
                } else {
                    ReportBFFDetails.put( "\"Retention Index (RI)\"", "In IP" );
                }
            }
            try {
                ReportBFFDetails.put( "\"Grade Level\"", ReportBFFDetails.get( "\"Grade Level\"" ).equals( "KG" ) ? "K" : Integer.valueOf( ReportBFFDetails.get( "\"Grade Level\"" ) ).toString() );
            } catch ( NumberFormatException e ) {
                Log.failsoft( "Getting issue while fetch the student grade!!" );
            }
            ReportBFFDetails.put( "\"Average Session Time\"",
                    convertMinutesIntohours( String.valueOf( Math.round( Double.valueOf( ReportBFFDetails.get( "\"Time Spent\"" ) ) / Double.valueOf( ReportBFFDetails.get( "\"Total Sessions - minimum of 1 assignment\"" ) ) ) ) ) );
            ReportBFFDetails.put( "\"Time Spent\"", convertMinutesIntohours( ReportBFFDetails.get( "\"Time Spent\"" ) ) );
            if ( ReportBFFDetails.get( "\"IP Percent Correct\"" ).equals( "0%" ) ) {
                ReportBFFDetails.put( "\"IP Percent Correct\"", "NA" );
            }
        } else {
            for ( String filters : selectedFilters ) {
                if ( filters.contains( "courses." ) ) {
                    String filter = filters.replace( "courses.", "" ).replace( "IPMPercent", "IPPercent" );
                    String[] fieldName = filter.split( "[.]", 0 );
                    String value = courseDetail;
                    for ( int itr = 0; itr < fieldName.length; itr++ ) {
                        try {
                            value = new JSONObject( value ).get( fieldName[itr] ).toString().equals( "null" ) ? "" : new JSONObject( value ).get( fieldName[itr] ).toString();
                        } catch ( Exception e ) {
                            value = "";
                        }
                    }
                    if ( isMath ) {
                        ReportBFFDetails.put( SPRExportCSVConstants.CUSTOM_MATH_HEADERS.get( selectedFilters.indexOf( filters ) ), value );
                    } else {
                        ReportBFFDetails.put( SPRExportCSVConstants.CUSTOM_READING_HEADERS.get( selectedFilters.indexOf( filters ) ), value );
                    }
                }
            }
            ReportBFFDetails.put( "\"ipPercent\"", ReportBFFDetails.get( "\"ipmAttempted\"" ).equals( "0" ) || ReportBFFDetails.get( "\"ipmAttempted\"" ).equals( "" ) ? "0"
                    : String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"ipmCorrect\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"ipmAttempted\"" ) ) ) ) );
            ReportBFFDetails.put( "\"exerCorrectPercent\"", ReportBFFDetails.get( "\"exerAttempted\"" ).equals( "0" ) || ReportBFFDetails.get( "\"exerAttempted\"" ).equals( "" ) ? "0"
                    : String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"exerCorrect\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"exerAttempted\"" ) ) ) ) );
            ReportBFFDetails.put( "\"skillsMasteredPercent\"", ReportBFFDetails.get( "\"skillsAssessed\"" ).equals( "0" ) || ReportBFFDetails.get( "\"skillsAssessed\"" ).equals( "" ) ? "0"
                    : String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"skillsMastered\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"skillsAssessed\"" ) ) ) ) );
            if ( !isMath ) {
                ReportBFFDetails.put( "\"otherPerformanceIndependentPracticeExerCorrectPercent\"",
                        ReportBFFDetails.get( "\"otherPerformanceIndependentPracticeExerAttempted\"" ).equals( "0" ) || ReportBFFDetails.get( "\"otherPerformanceIndependentPracticeExerAttempted\"" ).equals( "" ) ? "0" : String.valueOf(
                                Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"otherPerformanceIndependentPracticeExerCorrect\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"otherPerformanceIndependentPracticeExerAttempted\"" ) ) ) ) );
                ReportBFFDetails.put( "\"otherPerformanceRemediationExerCorrectPercent\"",
                        ReportBFFDetails.get( "\"otherPerformanceRemediationExerAttempted\"" ).equals( "0" ) || ReportBFFDetails.get( "\"otherPerformanceRemediationExerAttempted\"" ).equals( "" ) ? "0"
                                : String.valueOf( Math.round( ( Double.valueOf( ReportBFFDetails.get( "\"otherPerformanceRemediationExerCorrect\"" ) ) * 100 ) / Double.valueOf( ReportBFFDetails.get( "\"otherPerformanceRemediationExerAttempted\"" ) ) ) ) );

            }
            ReportBFFDetails.put( "\"averageSessionTime\"", convertMinutesIntohours( String.valueOf( Math.round( Double.valueOf( ReportBFFDetails.get( "\"timeSpent\"" ) ) / Double.valueOf( ReportBFFDetails.get( "\"totalSessions\"" ) ) ) ) ) );
            ReportBFFDetails.put( "\"ipLevel\"", df.format( Double.valueOf( ReportBFFDetails.get( "\"ipLevel\"" ) ) ) );
        }
        return ReportBFFDetails;
    }

    /**
     * To convert hours into hh:mm format
     * 
     * @param minutes
     * @return
     */
    public static String convertMinutesIntohours( String minutes ) {
        SimpleDateFormat sdf = new SimpleDateFormat( "mm" );
        try {
            Date dt = sdf.parse( minutes );
            sdf = new SimpleDateFormat( "HH:mm" );
            return sdf.format( dt );
        } catch ( ParseException e ) {
            Log.message( "Getting issue while convert minutes into hh:mm format" );
            e.printStackTrace();
            return null;
        }
    }

    public String getCsvValues( Response csv ) {
        String csvDataFromBS = null;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            driver.get( SMUtils.getKeyValueFromResponse( csv.getBody().asString(), "signedUrl" ) );
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            driver.quit();
        }
        return csvDataFromBS;
    }

}
