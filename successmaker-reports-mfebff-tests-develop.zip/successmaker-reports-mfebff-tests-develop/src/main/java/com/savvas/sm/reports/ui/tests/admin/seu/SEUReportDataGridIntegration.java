package com.savvas.sm.reports.ui.tests.admin.seu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.DemographicFilters;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportSubHeader;
import com.savvas.sm.reports.constants.ReportsUIConstants.SEUReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.SEUReportSelectedOptions;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.SystemEnrollmentAndUsagePage;
import com.savvas.sm.reports.ui.pages.SystemEnrollmentAndUsageReportViewerPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.Students;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;

import io.restassured.response.Response;

public class SEUReportDataGridIntegration extends EnvProperties {

    private String smUrl;
    private String browser;

    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String distId;
    String organizationName;
    String organizationNameId;
    String subDistAdminUserName;
    String schoolUnderSubDistrict;
    String schoolAdminUserName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String firstGroupName;
    String secondGroupId;
    String secondGroupName;

    List<String> teachers;
    List<String> groups;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        
        RBSUtils rbsUtils = new RBSUtils();

        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        organizationNameId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );

        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 1 ).toString(), "groupId" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        schoolUnderSubDistrict = configProperty.getProperty( "Rumba_subDistrictSchool" );

        //School admin details
        schoolAdminUserName = ReportData.schoolAdmin;

    }

    @Test ( description = "Verify the sub-headers in SEU report viewer page", groups = { "SMK-58044", "SEU Report Output", "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid001: Verify the Subject name, Report run, School, Teacher, Grade and Group System Enrollment and Usage report Viewer" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the Subject name, Report run, School, Teacher, Grade and Group System Enrollment and Usage report Viewer" );
            SMUtils.logDescriptionTC( "Verify the user able to login with the district admin credential." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report page, when select an organization with All course subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while the student belongs to multiple Groups" );
            Log.assertThat( seuReportViewerPage.verifySubHeaderIsDisplayed(), "Sub headers are displayed in System Enrollment and Usage report viewer page", "Sub headers are not displayed in System Enrollment and Usage report viewer page" );

            if ( !seuReportViewerPage.isZeroStateMessageDisplayed() ) {
                // Get student report data from graphQL response
                Response response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, organizationNameId, ReportAPIConstants.BOTH, new HashMap<>() );

                // Get student report data from graphQL response
                HashMap<String, HashMap<String, String>> studentReportDetailFromGrapgql = getDataFromResponse( response.getBody().asString(), ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

                Map<String, Map<String, String>> gridvalues = seuReportViewerPage.getGridvalues();
                List<String> keys = gridvalues.entrySet().stream().map( x -> x.getKey() ).collect( Collectors.toList() );
                Log.assertThat(
                        keys.equals( studentReportDetailFromGrapgql.entrySet().stream().map( x -> x.getKey() ).collect( Collectors.toList() ) )
                                || IntStream.range( 0, keys.size() ).allMatch( itr -> SMUtils.compareTwoHashMap( studentReportDetailFromGrapgql.get( keys.get( itr ) ), gridvalues.get( keys.get( itr ) ) ) ),
                        "Student SEU data are same as excepted for Math course", "Student SEU data are not same as excepted for Math course" );
            }
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the System Enrollment and Usage report when selecting an organization with Math/Reading subject along with single Teacher, Grade and Group", groups = { "SMK-58044", "SEU Report Output",
            "SEUUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid002: Verify the System Enrollment and Usage report when selecting an organization with Math/Reading subject along with single Teacher, Grade and Group" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();

            teachers = systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            groups = systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Students.ALL_GRADES.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with one Teacher, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with one Grade, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with one Group, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with Math/Reading subject. along with single Teacher, Grade and Group" );

            List<String> schoolNames = seuReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( !schoolNames.contains( Constants.NA ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is displayed in sub-header in report viewer page" );
                Log.assertThat( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ).contains( teachers.get( 0 ) ), "Teacher name is displayed in sub-header in report viewer page",
                        "Teacher name is displayed in sub-header in report viewer page" );
                Log.assertThat( Students.ALL_GRADES.containsAll( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ) ), "Grade is displayed in sub-header in report viewer page", "Grade is displayed in sub-header in report viewer page" );
                Log.assertThat( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ).contains( groups.get( 0 ) ), "Group name is displayed in sub-header in report viewer page", "Group name is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the System Enrollment and Usage report when selecting an organization with Math/Reading subject along with two or morw Teachers, Grades and Groups", groups = { "SMK-58044", "SEU Report Output",
            "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid003: Verify the System Enrollment and Usage report when selecting an organization with Math/Reading subject along with two or morw Teachers, Grades and Groups" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();

            teachers = systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            groups = systemEnrollmentAndUsageReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Students.ALL_GRADES.get( 0 ), Students.ALL_GRADES.get( 1 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ), groups.get( 2 ) ) );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with two or more Teacher, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with with two or more Grade, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with with two or more Group, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while the student belongs to multiple Groups" );

            List<String> schoolNames = seuReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( !schoolNames.contains( Constants.NA ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is displayed in sub-header in report viewer page" );
                Log.assertThat( Arrays.asList( ReportsUIConstants.MULTIPLE_TEACHERS_SELECTED, ReportsUIConstants.ALL_VALUES ).containsAll( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ) ),
                        "Teacher name is displayed in sub-header in report viewer page", "Teacher name is displayed in sub-header in report viewer page" );
                Log.assertThat( Arrays.asList( ReportsUIConstants.MULTIPLE_GRADES_SELECTED, ReportsUIConstants.ALL_VALUES ).containsAll( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ) ),
                        "Grade is displayed in sub-header in report viewer page", "Grade is displayed in sub-header in report viewer page" );
                Log.assertThat( Arrays.asList( ReportsUIConstants.MULTIPLE_GROUPS_SELECTED, ReportsUIConstants.ALL_VALUES ).containsAll( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ) ),
                        "Group name is displayed in sub-header in report viewer page", "Group name is displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the System Enrollment and Usage report when selecting an organization with Math/Reading subject along with all Teachers, Grades and Groups", groups = { "SMK-58044", "SEU Report Output",
            "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid004: Verify the System Enrollment and Usage report when selecting an organization with Math/Reading subject along with all Teachers, Grades and Groups" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with all Teacher, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with all Grade, Math/Reading subject." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with all Group, Math/Reading subject." );

            List<String> schoolNames = seuReportViewerPage.getSubHeaderValues( ReportSubHeader.School );
            if ( !schoolNames.contains( Constants.NA ) ) {
                Log.assertThat( schoolNames.stream().allMatch( school -> school.equals( organizationName ) ), "School name is displayed in sub-header in report viewer page", "School name is not displayed in sub-header in report viewer page" );
                Log.assertThat( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Teacher ).stream().allMatch( teacher -> teacher.equals( ReportsUIConstants.ALL_VALUES ) ), "Teacher name is displayed in sub-header in report viewer page",
                        "Teacher name is displayed in sub-header in report viewer page" );
                Log.assertThat( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Grade ).stream().allMatch( grade -> grade.equals( ReportsUIConstants.ALL_VALUES ) ), "Grade is displayed in sub-header in report viewer page",
                        "Grade is not displayed in sub-header in report viewer page" );
                Log.assertThat( seuReportViewerPage.getSubHeaderValues( ReportSubHeader.Group ).stream().allMatch( group -> group.equals( ReportsUIConstants.ALL_VALUES ) ), "Group name is displayed in sub-header in report viewer page",
                        "Group name is not displayed in sub-header in report viewer page" );
            } else {
                Log.message( "No data present for given filters." );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Subject name, Report run, School, Teacher, Grade and Group System Enrollment and Usage report Viewer", groups = { "SMK-58044", "SEU Report Output", "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid005: Verify the Subject name, Report run, School, Teacher, Grade and Group System Enrollment and Usage report Viewer" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            Log.assertThat( seuReportViewerPage.getSelectedOptions( SEUReportSelectedOptions.Additional_Grouping ).equals( String.format( SEUReportConstants.SELECTED_OPTION_ADDITIONAL_GROUPING, ReportsUIConstants.GRADE_LABEL ) ),
                    "Additional Grouping is selected as Grade", "Additional Grouping is not selected as Grade" );

            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report, while selecting an organization with all Groups, Math/Reading subject and Group in additional grouping." );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();
            Log.assertThat( seuReportViewerPage.getSelectedOptions( SEUReportSelectedOptions.Additional_Grouping ).equals( String.format( SEUReportConstants.SELECTED_OPTION_ADDITIONAL_GROUPING, ReportsUIConstants.GROUP_LABEL ) ),
                    "Additional Grouping is selected as Group", "Additional Grouping is not selected as Group" );

            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( reportFiterPage );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.TEACHER_LABEL );
            seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();
            Log.assertThat( seuReportViewerPage.getSelectedOptions( SEUReportSelectedOptions.Additional_Grouping ).equals( String.format( SEUReportConstants.SELECTED_OPTION_ADDITIONAL_GROUPING, ReportsUIConstants.TEACHER_LABEL ) ),
                    "Additional Grouping is selected as Teacher", "Additional Grouping is not selected as Teacher" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify each columns are sorted in ascending order in SEU report viewer page", groups = { "SMK-58044", "SEU Report Output", "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid006: Verify each columns are sorted in ascending order in SEU report viewer page" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();

            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Student column while run the report with Sort as student" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by username column while run the report with Sort as username(login)" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by studentId column while run the report with Sort as studentId" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Time spent - SM Math column while run the report with Sort as Time spent - SM Math" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Time spent - SM Reading column while run the report with Sort as Time spent - SM Reading" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Time spent -Custom course column while run the report with Sort as Time Spent - Custom course" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Total Session column while run the report with Sort as Total Session" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Last Session date column while run the report with Sort as Last Session date" );
            SMUtils.logDescriptionTC( "Verify the strand column should be highlighted and the report should show the sorted order by Average Session time column while run the report with Sort as Average Session time" );

            IntStream.range( 0, SEUReportConstants.SORT.size() ).forEach( itr -> {
                String columnSorted = SEUReportConstants.SORT.get( itr );
                systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, columnSorted );

                //To click the run report button 
                SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

                Log.assertThat( seuReportViewerPage.sortAndCompareColumnvalues( columnSorted ), columnSorted + " column is sorted in ascending order", columnSorted + " column is not sorted in ascending order" );

                // Navigating to report filter page
                String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
                driver.close();
                driver.switchTo().window( reportFiterPage );
            } );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify demographic filters are applied in SEU report viewer page", groups = { "SMK-58044", "SEU Report Output", "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid007: Verify demographic filters are applied in SEU report viewer page" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, "Auto AFG School 2" );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandStudentDemographics();

            // Selecting single values in each demographic filters
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( DemographicFilters.ETHNICITY.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 0 ) ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 0 ) ) );

            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the students in SEU report viewer page after run the report for an organization with multiple option in English language proficiency filter and multiple option in Ethnicity filter" );
            SMUtils.logDescriptionTC( "Verify the students in SEU report viewer page after run the report for an organization with multiple option in Special services filter and multiple option in Socioeconomic status filter" );
            SMUtils.logDescriptionTC( "Verify the students in SEU report viewer page after run the report for an organization with multiple option in Race filter and multiple option in disability status filter" );
            SMUtils.logDescriptionTC( "Verify the students in SEU report viewer page after run the report for an organization with anyone option in English language proficiency filter and anyone option in Ethnicity filter" );
            SMUtils.logDescriptionTC( "Verify the students in SEU report viewer page after run the report for an organization with anyone option in Special services filter and anyone option in Socioeconomic status filter" );
            SMUtils.logDescriptionTC( "Verify the students in SEU report viewer page after run the report for an organization with anyone option in Race filter and anyone option in disability status filter" );

            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 0 ) ) ),
                    "Selected demographic values for Disability Status are displayed in report viewer page", "Selected demographic values for Disability Status are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 0 ) ) ),
                    "Selected demographic values for English Language Proficiency are displayed in report viewer page", "Selected demographic values for English Language Proficiency are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 0 ) ) ), "Selected demographic values for Migrant Status are displayed in report viewer page",
                    "Selected demographic values for Migrant Status are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 0 ) ) ), "Selected demographic values for Race are displayed in report viewer page",
                    "Selected demographic values for Race are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.ETHNICITY, Arrays.asList( DemographicFilters.ETHNICITY.get( 0 ) ) ), "Selected demographic values for Ethnicity are displayed in report viewer page",
                    "Selected demographic values for Ethnicity are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 0 ) ) ),
                    "Selected demographic values for Socioeconomic Status are displayed in report viewer page", "Selected demographic values for Socioeconomic Status are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 0 ) ) ),
                    "Selected demographic values for Special Services are displayed in report viewer page", "Selected demographic values for Special Services are not displayed in report viewer page" );

            // Navigating to report filter page
            String reportFiterPage = new ArrayList<>( driver.getWindowHandles() ).get( 1 );
            driver.close();
            driver.switchTo().window( reportFiterPage );

            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickResetButton();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_READING );

            // Selecting multiple values in each demographic filters
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            systemEnrollmentAndUsageReportPage.clickRunReportButton();

            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.DISABILITY_STATUS, DemographicFilters.DISABILITY_STATUS ), "Selected demographic values for Disability Status are displayed in report viewer page",
                    "Selected demographic values for Disability Status are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, DemographicFilters.ENGLISH_LANGUAGE ),
                    "Selected demographic values for English Language Proficiency are displayed in report viewer page", "Selected demographic values for English Language Proficiency are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.MIGRANT_STATUS, DemographicFilters.MIGRANT_STATUS ), "Selected demographic values for Migrant Status are displayed in report viewer page",
                    "Selected demographic values for Migrant Status are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.RACE, DemographicFilters.RACE ), "Selected demographic values for Race are displayed in report viewer page",
                    "Selected demographic values for Race are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.ETHNICITY, DemographicFilters.ETHNICITY ), "Selected demographic values for Ethnicity are displayed in report viewer page",
                    "Selected demographic values for Ethnicity are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.SOCIOECONOMIC_STATUS, DemographicFilters.SOCIOECONOMIC_STATUS ), "Selected demographic values for Socioeconomic Status are displayed in report viewer page",
                    "Selected demographic values for Socioeconomic Status are not displayed in report viewer page" );
            Log.assertThat( seuReportViewerPage.verifyDemographicValues( ReportsUIConstants.SPECIAL_SERVICES, DemographicFilters.SPECIAL_SERVICES ), "Selected demographic values for Special Services are displayed in report viewer page",
                    "Selected demographic values for Special Services are not displayed in report viewer page" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub district admin able to access System Enrollment and Usage report", groups = { "SMK-58044", "SEU Report Output", "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid008: Verify sub district admin able to access System Enrollment and Usage report" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( subDistAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, schoolUnderSubDistrict );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the user able to login with the sub district admin credential." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report page, when select an organization with Math subject" );
            Log.assertThat( seuReportViewerPage.verifySubHeaderIsDisplayed(), "Sub headers are displayed in System Enrollment and Usage report viewer page", "Sub headers are not displayed in System Enrollment and Usage report viewer page" );

            if ( !seuReportViewerPage.isZeroStateMessageDisplayed() ) {
                Response response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, organizationNameId, Constants.MATH, new HashMap<>() );

                // Get student report data from graphQL response
                HashMap<String, HashMap<String, String>> studentReportDetailFromGrapgql = getDataFromResponse( response.getBody().asString(), ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );

                Map<String, Map<String, String>> gridvalues = seuReportViewerPage.getGridvaluesForMath();
                List<String> keys = gridvalues.entrySet().stream().map( x -> x.getKey() ).collect( Collectors.toList() );
                Log.assertThat(
                        keys.equals( studentReportDetailFromGrapgql.entrySet().stream().map( x -> x.getKey() ).collect( Collectors.toList() ) )
                                || IntStream.range( 0, keys.size() ).allMatch( itr -> SMUtils.compareTwoHashMap( studentReportDetailFromGrapgql.get( keys.get( itr ) ), gridvalues.get( keys.get( itr ) ) ) ),
                        "Student SEU data are same as excepted for Math course", "Student SEU data are not same as excepted for Math course" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify school admin able to access System Enrollment and Usage report", groups = { "SMK-58044", "SEU Report Output", "SEUGridIntegration" }, priority = 1 )
    public void tcSEUDataGrid009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSEUDataGrid009: Verify school admin able to access System Enrollment and Usage report" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( schoolAdminUserName, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();

            //To select the organization in the organization dropdown
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_READING_WITH_CUSTOM );

            //To click the run report button 
            SystemEnrollmentAndUsageReportViewerPage seuReportViewerPage = systemEnrollmentAndUsageReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the user able to login with the sub district admin credential." );
            SMUtils.logDescriptionTC( "Verify the System Enrollment and Usage report page, when select an organization with Reading subject" );

            Log.assertThat( seuReportViewerPage.verifySubHeaderIsDisplayed(), "Sub headers are displayed in System Enrollment and Usage report viewer page", "Sub headers are not displayed in System Enrollment and Usage report viewer page" );

            if ( !seuReportViewerPage.isZeroStateMessageDisplayed() ) {
                Response response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, organizationNameId, Constants.READING, new HashMap<>() );

                // Get student report data from graphQL response
                HashMap<String, HashMap<String, String>> studentReportDetailFromGrapgql = getDataFromResponse( response.getBody().asString(), ReportsUIConstants.SEU_ALL_READING_WITH_CUSTOM );

                Map<String, Map<String, String>> gridvalues = seuReportViewerPage.getGridvaluesForReading();
                List<String> keys = gridvalues.entrySet().stream().map( x -> x.getKey() ).collect( Collectors.toList() );
                Log.assertThat(
                        keys.equals( studentReportDetailFromGrapgql.entrySet().stream().map( x -> x.getKey() ).collect( Collectors.toList() ) )
                                || IntStream.range( 0, keys.size() ).allMatch( itr -> SMUtils.compareTwoHashMap( studentReportDetailFromGrapgql.get( keys.get( itr ) ), gridvalues.get( keys.get( itr ) ) ) ),
                        "Student SEU data are same as excepted for Math course", "Student SEU data are not same as excepted for Math course" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     * @throws Exception
     */
    public HashMap<String, HashMap<String, String>> getDataFromResponse( String responseBody, String subject ) throws Exception {

        //Response responseBody = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, new HashMap<>() );

        // Getting data from response
        String jsonObj = SMUtils.getKeyValueFromResponseWithArray( responseBody, "data,getSEUAdminReportData" );
        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();

        IntStream.range( 0, new JSONArray( jsonObj ).length() ).forEach( iter -> {
            String student = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( jsonObj ).get( iter ).toString(), "students" );

            IntStream.range( 0, new JSONArray( student ).length() ).forEach( itr -> {

                String studentDetails = new JSONArray( student ).get( itr ).toString();
                JSONObject stdJson = new JSONObject( studentDetails );

                HashMap<String, String> studentReport = new HashMap<>();
                studentReport.put( "Student Name", stdJson.get( "studentName" ).toString() );
                studentReport.put( SEUReportConstants.SUB_HEADERS.get( 2 ), stdJson.get( "studentID" ).toString() );
                if ( subject.equals( ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM ) || subject.equals( ReportsUIConstants.SEU_ALL_MATH_WITH_READING ) ) {
                    studentReport.put( SEUReportConstants.SUB_HEADERS.get( 3 ), stdJson.get( "sumDefaultMathTime" ).toString() );
                }
                if ( subject.equals( ReportsUIConstants.SEU_ALL_READING_WITH_CUSTOM ) || subject.equals( ReportsUIConstants.SEU_ALL_MATH_WITH_READING ) ) {
                    studentReport.put( SEUReportConstants.SUB_HEADERS.get( 4 ), stdJson.get( "sumDefaultReadingTime" ).toString() );
                }
                studentReport.put( SEUReportConstants.SUB_HEADERS.get( 5 ), stdJson.get( "sumCustomTotalTime" ).toString() );
                studentReport.put( SEUReportConstants.SUB_HEADERS.get( 6 ), stdJson.get( "sumTotalTime" ).toString() );
                studentReport.put( SEUReportConstants.SUB_HEADERS.get( 7 ), stdJson.get( "sumTotalSessions" ).toString() );
                studentReport.put( SEUReportConstants.SUB_HEADERS.get( 8 ), String.valueOf( Math.round( Double.parseDouble( stdJson.get( "avgTotalTimePerSession" ).toString() ) ) ) );
                studentReport.put( SEUReportConstants.SUB_HEADERS.get( 9 ), stdJson.get( "maxLastSessionDate" ).toString().split( "T" )[0] );

                studentReportDetails.put( stdJson.get( "studentUsername" ).toString(), studentReport );
            } );
        } );
        Log.message( "Response Data: " + studentReportDetails );
        return studentReportDetails;
    }

}
