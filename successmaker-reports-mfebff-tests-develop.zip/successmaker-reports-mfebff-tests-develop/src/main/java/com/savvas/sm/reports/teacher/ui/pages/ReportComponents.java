package com.savvas.sm.reports.teacher.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsBrowserActions;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.IFindBy;

public class ReportComponents extends ReportNavigation {

    private final WebDriver driver;
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    WebElement shadowTree = null;

    // ********* SuccessMaker Report Page Elements ***************
    @IFindBy ( how = How.CSS, using = "section.page-title div h1", AI = false )
    public WebElement reportHeader;
    
    @FindBy ( css = "cel-modal-window" )
    WebElement studentIDPopupparent;

    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportButtonRoot;
    
    @FindBy ( css = "#display" )
    WebElement displaylbl;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    WebElement maskStudentlblRoot;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    WebElement maskStudentCheckboxParent;

    @FindBy ( css = "div label" )
    List<WebElement> lblStaticDropdownHeading;

    @IFindBy ( how = How.CSS, using = "p.description", AI = false )
    public WebElement txtReportDescription;

    @IFindBy ( how = How.CSS, using = ".col-md-2 cel-multi-check-dropdown.ng-cel-multi-check-dropdown", AI = false )
    public WebElement lblSubjectDropdown;

    @IFindBy ( how = How.CSS, using = "div.step2 .pr-md-5 label", AI = false )
    public WebElement lblAssignemntDropdownHeader;

    @IFindBy ( how = How.CSS, using = ".col-md-6 cel-multi-check-dropdown.ng-cel-multi-check-dropdown", AI = false )
    public WebElement lblAssignemntDropdown;

    @IFindBy ( how = How.CSS, using = "report-filters cel-accordion-grid div button[aria-expanded='false']", AI = false )
    public WebElement btnExpandFilter;

    @IFindBy ( how = How.CSS, using = "report-filters cel-accordion-grid div button[aria-expanded='true']", AI = false )
    public WebElement btnCollapseFilter;

    @FindBy ( css = "div.row  div.d-flex" )
    List<WebElement> rbGroupAndStudentDropdownParent;

    @IFindBy ( how = How.CSS, using = "save-report-options cel-radio-button div input[value='new']", AI = false )
    public WebElement rbNewSaveReportOption;

    @IFindBy ( how = How.CSS, using = "save-report-options cel-radio-button div input[value='update']", AI = false )
    public WebElement rbReplaceReportOption;

    @IFindBy ( how = How.CSS, using = "form div >div > input", AI = false )
    public WebElement txtFilterName;

    @FindBy ( css = "div.report-body-wrapper student-performance cel-accordion-item" )
    WebElement optionalFilterRootStudentPerformance;

    @IFindBy ( how = How.CSS, using = "#existingReportName div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandFilterOption;

    @FindBy ( css = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(1)" )
    WebElement includePerformanceSummarylblRoot;

    @FindBy ( css = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(2)" )
    WebElement includePerformanceStrandlblRoot;

    @FindBy ( css = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(3)" )
    WebElement includeAreasOfGrowthlblRoot;
    
    @FindBy(css = "cel-single-select.disabled.hydrated")
	WebElement zeroStateSavedReportParentElement;

	@FindBy(css = "multi-select[id='assignments'] cel-multi-select")
	WebElement zerostateParentElement;

    @FindBy ( css = "div label" )
    List<WebElement> lblGroupAndStudentsDropdown;

    @IFindBy ( how = How.CSS, using = "single-select[formcontrolname='subject']", AI = false )
    public WebElement shadowRootSubjectsDropdown;

    @IFindBy ( how = How.CSS, using = "multi-select[formcontrolname='assignments']", AI = false )
    public WebElement shadowRootAssignmentsDropdown;

    @IFindBy ( how = How.CSS, using = "multi-select[formcontrolname='groups']", AI = false )
    public WebElement shadowRootGroupAndStudentsDropdown;

    @IFindBy ( how = How.CSS, using = "#savedOptions", AI = false )
    public WebElement msSaveOptionDropdown;

    @IFindBy ( how = How.CSS, using = "#additionalGrouping", AI = false )
    public WebElement msAdditionalGroupingDropdown;

    @IFindBy ( how = How.CSS, using = "#display", AI = false )
    public WebElement msDisplayDropdown;

    @IFindBy ( how = How.CSS, using = "#existingReportName button", AI = false )
    public WebElement existingReportDropdown;

    @IFindBy ( how = How.CSS, using = "#sort", AI = false )
    public WebElement msSortDropdown;

    @IFindBy ( how = How.CSS, using = "#dateAtRisk", AI = false )
    public WebElement msDateAtRiskDropdown;

    @FindBy ( css = " div cel-checkbox" )
    List<WebElement> chbxMaskStudentDisplayAndRemovePageBreaksRoot;

    @IFindBy ( how = How.CSS, using = "div.form-actions cel-button.run-button.hydrated", AI = false )
    public WebElement btnRunReportRoot;

    @IFindBy ( how = How.CSS, using = "cel-modal.save-report-modal.hydratedbutton.button.button--text.center", AI = false )
    public WebElement btnSaveReportRoot;

    @IFindBy ( how = How.CSS, using = "#savedOptions div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandSaveOptionDropdown;

    @IFindBy ( how = How.CSS, using = "#additionalGrouping div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandAdditionalGroupingDropdown;

    @FindBy ( css = "select.primary-style-select.false" )
    public WebElement expandDisplayDropdown;

    @IFindBy ( how = How.CSS, using = "#sort div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandSortDropdown;

    @IFindBy ( how = How.CSS, using = "#dateAtRisk div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandDateAtRiskDropdown;

    @IFindBy ( how = How.CSS, using = "#savedOptions div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']", AI = false )
    public WebElement collapseSaveOptionDropdown;

    @IFindBy ( how = How.CSS, using = "#additionalGrouping div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']", AI = false )
    public WebElement collapseAdditionalGroupingDropdown;

    @IFindBy ( how = How.CSS, using = "#display div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']", AI = false )
    public WebElement collapseDisplayDropdown;

    @IFindBy ( how = How.CSS, using = "#sort div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']", AI = false )
    public WebElement collapseSortDropdown;

    @FindBy ( css = "div.report-body-wrapper cel-accordion-item" )
    WebElement optionalFilterRoot;

    @FindBy ( css = "#additionalGrouping div div ul li" )
    List<WebElement> listAdditionalGrouping;

    @FindBy ( css = "section.additional-filters-section cel-single-select.hydrated" )
    List<WebElement> optionalFiltersDropdownItems;

    @FindBy ( css = "#display div div li" )
    List<WebElement> listdisplay;

    @FindBy ( css = "#sort div div ul li" )
    List<WebElement> listSort;

    @FindBy ( css = "#dateAtRisk div ul li" )
    List<WebElement> listDateAtRisk;

    @FindBy ( css = "#savedOptions div div ul li" )
    List<WebElement> listSavedOptions;

    @IFindBy ( how = How.CSS, using = "div.spinner-container", AI = false )
    public WebElement Spinner;

    @IFindBy ( how = How.CSS, using = "#existingReportName div div ul", AI = false )
    public WebElement listFilterOptions;

    @IFindBy ( how = How.CSS, using = "#existingReportName div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandReplaceExistingDropdown;

    @IFindBy ( how = How.CSS, using = "cel-button.button.save-button.hydrated", AI = false )
    public WebElement btnSavereportPopupOptionRoot;

    @IFindBy ( how = How.CSS, using = "span.error-message span", AI = false )
    public WebElement errorMessage;

    @FindBy ( css = "input[value='students']" )
    public WebElement rdBtnStudent;

    @FindBy ( css = "#language div div ul li" )
    List<WebElement> listLanguage;

    @IFindBy ( how = How.CSS, using = "#dateAtRisk div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expanddateAtRiskDropdown;

    @IFindBy ( how = How.CSS, using = "#language div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement expandlanguageDropdown;

    @FindBy ( css = "cel-accordion-item.optional-filters-wrapper.hydrated" )
    WebElement lblFilterAndReportOptionsHeading;

    @FindBy ( css = "h3.title2" )
    List<WebElement> lblRefineSearchAndGroupOrStudentHeading;

    @FindBy ( css = "cel-modal.save-report-modal" )
    WebElement hostElement;

    @FindBy ( css = "cel-text-field.hydrated" )
    WebElement saveReportNewFieldParentRoot;

    @FindBy ( css = "div label" )
    List<WebElement> lblMSDropdownHeader;

    @IFindBy ( how = How.CSS, using = "report-options div.form-group div.col-md-3 label", AI = false )
    public WebElement lblSavedOptionHeading;

    @IFindBy ( how = How.CSS, using = "#additionalGrouping span.dropdown-select-label", AI = false )
    public WebElement lblSelectedOptionForAdditionalGrouping;

    @IFindBy ( how = How.CSS, using = "#display span.dropdown-select-label", AI = false )
    public WebElement lblSelectedOptionForDisplay;

    @IFindBy ( how = How.CSS, using = "#sort span.dropdown-select-label", AI = false )
    public WebElement lblSelectedOptionForSort;

    @IFindBy ( how = How.CSS, using = "#dateAtRisk span.dropdown-select-label", AI = false )
    public WebElement lblSelectedOptionForDateAtRiskt;

    @IFindBy ( how = How.CSS, using = "#language span.dropdown-select-label", AI = false )
    public WebElement lblSelectedOptionForLanguage;

    @FindBy ( css = "div.d-flex span span" )
    List<WebElement> countOfSelectedFilters;

    @IFindBy ( how = How.CSS, using = "div h1", AI = false )
    public WebElement saveReportPopUpTextHeader;

    @FindBy ( css = "cel-modal.save-report-modal" )
    WebElement saveReportParentRoot;

    @FindBy ( css = "div label" )
    List<WebElement> dropdownLabels;

    @FindBy ( css = "label.label-title" )
    List<WebElement> saveReportPopupDropdownHeaders;

    @IFindBy ( how = How.CSS, using = "cel-button.cancel-button", AI = false )
    public WebElement cancelBtnSaveReportPopUpRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.button.save-button.hydrated", AI = false )
    public WebElement saveBtnOnSaveReportPopUpRoot;

    @IFindBy ( how = How.CSS, using = ".ml-1", AI = false )
    public WebElement errorMsgSaveReport;

    @IFindBy ( how = How.CSS, using = "#savedOptions span span", AI = false )
    public WebElement savedOptionSelectedValue;

    @FindBy ( css = "#existingReportName ul li span" )
    List<WebElement> existingReportValues;

    @IFindBy ( how = How.CSS, using = "save-report-options cel-radio-button div input[value='update']", AI = false )
    public WebElement rbLoadReportOption;

    @FindBy ( css = "#additionalGrouping a.dropdown-option-link" )
    List<WebElement> additionalGroupingDropdownValues;

    @FindBy ( css = "#display a.dropdown-option-link" )
    List<WebElement> displayDropdownValues;

    @FindBy ( css = "#sort a.dropdown-option-link" )
    List<WebElement> sortDropdownValues;

    @FindBy ( css = "#date-at-risk" )
    WebElement dateAtRisklbl;

    @FindBy ( css = "#dateAtRisk > div > div > ul > li > a" )
    List<WebElement> dateAtRiskDropdownValues;

    @FindBy ( css = "#language > div > div > ul > li > a" )
    List<WebElement> languagekDropdownValues;

    @FindBy ( css = "cel-multi-select.hydrated" )
    public WebElement test;

    @FindBy ( css = "cel-modal.save-report-modal.hydrated" )
    public WebElement cancelHostElement;

    @IFindBy ( how = How.CSS, using = "cel-multi-check-dropdown.disabled", AI = false )
    public WebElement zeroStateRoot;

    @IFindBy ( how = How.CSS, using = "h3.header", AI = false )
    public WebElement headerTextZeroState;

    @FindBy (css = "span.message")
    public WebElement zeroStateDescription;

    @IFindBy ( how = How.CSS, using = "span.pad-left", AI = false )
    public WebElement collapsedFiltertext;

    @IFindBy ( how = How.CSS, using = "cel-dialog-header cel-icon", AI = false )
    public WebElement popupHelpIconRoot;

    @FindBy ( css = "div option" )
    public WebElement option;

    @FindBy ( css = "#language" )
    WebElement languagelbl;

    @IFindBy ( how = How.CSS, using = "div#contentBody h1", AI = false )
    public WebElement headerForHelpContent;

    @IFindBy ( how = How.CSS, using = "button[class='accordion-header clickable']", AI = false )
    public WebElement btnFilter;

    @FindBy ( tagName = "h1" )
    WebElement PageTitle;

    @FindBy ( css = "groups-students-filter div label.section-main-title.text-uppercase.d-block" )
    WebElement lblRefineSearchAndGroupOrStudentHeading2;

    @FindBy ( css = "div.row div.row" )
    List<WebElement> radioGropsandStudentsHeading;

    @FindBy ( css = "div.section-main-title.mt-3.text-uppercase" )
    WebElement courseSelection;

    @FindBy ( css = "label.label.label-semi-bold.d-block" )
    List<WebElement> courseselectionTxt;

    @FindBy ( css = "cel-accordion-item > section > section > div:nth-child(1) > single-select > div > label" )
    WebElement optionalFilteAdditionalGroupingTxt;

    @FindBy ( css = "section.additional-filters-section > div:nth-child(1) > div > single-select > div > label" )
    WebElement optionalFilteDisplayTxt;

    @FindBy ( css = "cel-accordion-item > section > section > div:nth-child(2) > single-select:nth-child(1) > div > label" )
    WebElement optionalFilteSortTxt;

    @FindBy ( css = "cel-radio-button-group" )
    WebElement StudentPerformanceDatesRoot;

    @FindBy ( css = "input.ng-valid.ng-dirty.ng-touched" )
    List<WebElement> radioBtnGroupsAndStudent;

    @FindBy ( css = "#radioStudents" )
    WebElement radioBtnStudent;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    List<WebElement> chbxMaskStudentDisplayRoot;

    @FindBy ( css = " section.row.mt-3 cel-radio-button-group" )
    WebElement selectedDateRangeRoot;

    @FindBy ( css = "section > section.row.mt-3 > performance-dates > div > cel-date-range" )
    WebElement datePickerFromRoot;

    @FindBy ( css = "div > teacher-cumulative-performance > cel-accordion-item > section > section.row.mt-3 > performance-dates > div > cel-date-range" )
    public WebElement startDateRoot;

    @FindBy ( css = "save-report-options cel-modal" )
    WebElement saveReportButtonParent;

    @FindBy ( css = "input#radioStudents" )
    WebElement studentRadioBtn;

    // ********* Child Elements **********

    //  String shadowRootGroupAndStudentsDropdown = "multi-select[formcontrolname='groups']";

    public static String ORGANIZATIONS = "#organization > div > cel-single-select";
    public static String SUBJECT = "#subject > div > cel-single-select";
    public static String ADDITIONAL_GROUPING = "#additional-grouping";
    public static String DISPLAY = "#display";
    public static String SORT = "#sort";
    public static String LABEL = "label";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1 = "#dropdown > cel-single-select-item";
    public static String DROPDOWN_GRADNPARENT = "%s > cel-multi-select";
    public static String DROPDOWN_LIST_Root1 = "#dropdown > cel-multi-checkbox.multi-checkbox.hydrated";
    public static String DROPDOWN_PARENT1 = "div button cel-icon";
    public static String DROPDOWN_LIST_Root2 = "div > div.bottom-container div";
    public static String DIV = "div";
    public static String TEACHERS = "#teachers";
    public static String ASSIGNMENTS = "#assignments";
    public static String GROUPS = "#groups";
    public static String DATE_AT_RISK = "div.row.filter > single-select:nth-child(1)";
    private String grandChildCheckBoxLabel = "span.checkbox-label";

    private String inputCheckbox = "input";
    private String cancelParentElement = "cel-button.cancel-button.hydrated";
    private String cancelChildElement = "button span";

    // Child Elements
    private String multiSelectDropdownRoot = "cel-multi-select.hydrated";
    private String button = "button";

    private String saveReportChildRoot = "h1.header";

    private String span = "span";
    private String optionalFilterValuesChild = "div.single-container>button>span";
    private String optionalFilterDropdownArrowChild = "div.single-container>button>cel-icon[data-name='caret-down']";
    private String maskStudentCheckboxChild = "label>span.checkbox-label";

    public String btnSavedReportOptionsShadowDOM[] = { "cel-modal.save-report-modal.hydrated",
            "document.querySelector('cel-modal.save-report-modal.hydrated').shadowRoot.querySelector('cel-button').shadowRoot.querySelector('button[aria-disabled=\"false\"]')" };

    public String drpDwnDisplayshadowDOM[] = { "cel-single-select", "document.querySelector('#display').shadowRoot.querySelector('#dropdown')" };

    public static String SELECT_ALL_ROOT2 = "div > div.header-container.item-container.border-bottom > cel-checkbox-item";
    public static String SELECT_ALL_ROOT3 = "label > input[type=checkbox]";
    public static String SELECT_ALL_PARTIAL_SELECT = "label > input.indeterminate";

    String parentElement = "cel-button.ok-button.last-interactive.hydrated";

    private String childMultiCheckBox = "cel-multi-checkbox";

    String txtGroupAndStudentDropdown = "div.d-block label";
    String popupHelpIconChild = "img";
    private String optionalFilter = "span.item-heading";

    String multiSelectHostElement = "multi-select[formcontrolname=%s] cel-multi-select";

    String multiSelectGrandParent = "cel-multi-checkbox.multi-checkbox.hydrated";

    String multiSelectParent = "cel-checkbox-item.header-checkbox.hydrated";
  
    private String studnetIDPopup = "cel-button.hydrated";

    String input = "input";

    String collapseMsDropdown = "button#multiselect-btn.multi.row-between";

    String secondary_button = ".secondary_button";

    String childElement = "button span";

    public static String selectAllCheckBoxColor = "#006be0";

    String expandMsDropdown = "span.label";

    String shadowRootSelectDropDownMS = "cel-single-select.hydrated";// List<WebElement>

    public String txtDropDownMSValue = "span.label";

    String valuesFromMSDropdown = "label.dropdown-label";

    String primary_button = ".primary_button";

    String saveReportFieldChildRoot = "label.text-field-label";

    public static List<String> SINGLE_SELECT_DROPDOWNS = new ArrayList<String>( Arrays.asList( ORGANIZATIONS, SUBJECT, ADDITIONAL_GROUPING, DISPLAY, SORT, DATE_AT_RISK ) );

    public String txtGroupDrpdwn = "STUDENT_NAME";

    String reportOption = "li:nth-child(%s)";

    String chbxSelectALLParentRoot = "cel-multi-select.hydrated";

    private String childMultiCheckBoxItems = "cel-checkbox-item";

    String chbxDropdownMS = "label.checkbox__container input[type='checkbox']";

    String txtInsideMsDropdown = "span.head-label";

    String chbxSelectALL = "input[type=checkbox]";

    String dropdownBtnChild = "button.dropdown-head";

    String lblRemovePageBreakAndMaskStudentDiplayText = "label.checkbox__label";

    String chbxRemovePageBreakAndMaskStudentDiplay = "label.checkbox__container input[type='checkbox']";

    String rbGroupAndStudentDropdown = "cel-radio-button input[type='radio']";

    String zeroStateChild = "button.dropdown-no-data span span";

    String assignmentszeroState = "span.head-label";

    String rbGroupAndStudentDropDownDisplay = "cel-multi-check-dropdown";

    // Teacher - Shadow DOM Elements
    String subjectDropdownValues = "label.checkbox__label";

    String lblOptionalFilters = "span.item-heading";

    // Optional Filters
    private String includePerformanceSummaryStudent = ".header";
    private String yesBtnRoot = "div:nth-child(1) > div:nth-child(2) > cel-radio-button:nth-child(1)";
    private String noBtnRoot = "div:nth-child(1) > div:nth-child(2) > cel-radio-button:nth-child(2)";
    private String yesBtnChild = "#yes";
    private String noBtnChild = "#no";
    private String optionalFieldPlaceHolder = ".label";

    // Teacher - Shadow DOM Elements
    public String drpdwnGroupShadowDOM[] = { "multi-select", "document.querySelector('multi-select[formcontrolname=\"groups\"] > cel-multi-select').shadowRoot.querySelector('button[aria-expanded=\"false\"]')" };
    public String drpdwnStudentShadowDOM[] = { "multi-select", "document.querySelector('multi-select[formcontrolname=\"students\"] > cel-multi-select').shadowRoot.querySelector('button[aria-expanded=\"false\"]')" };
    public String drpdwnAssignmentShadowDOM[] = { "cel-multi-select", "document.querySelector('#assignments > cel-multi-select').shadowRoot.querySelector('#multiselect-btn')" };
    public String drpdwnStudentSelectAllShadowDOM[] = { "cel-multi-select",
            "document.querySelector('div:nth-child(2)> div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };
    public String drpdwnGroupSelectAllShadowDOM[] = { "cel-multi-select",
            "document.querySelector('div:nth-child(1) > div:nth-child(2) multi-select cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };
    public String drpdwnAssignmentSelectAllShadowDOM[] = { "cel-multi-select",
            "document.querySelector('#assignments cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.header-container cel-checkbox-item').shadowRoot.querySelector('span')" };

    // private String dropdownplaceHolder = "label.dropdown-label";
    private String dropdownplaceHolder = "span.label";
    private String dropdownplaceHolder1 = "select#dropdown";
    private String singleSelectDropdownRoot = "cel-single-select.hydrated";
    private String singleDropdownDropdownItem = "option";
    private String organizationOption = "option[value='%s']";

    /**
     * Validate student dropdown heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isMSDropdownHeadingPresent( String dropdownName ) throws InterruptedException {
        boolean isHeaderPresent = false;
        for ( WebElement lbldropdownHeader : lblMSDropdownHeader ) {
            if ( lbldropdownHeader.getText().trim().equals( dropdownName ) ) {
                isHeaderPresent = true;
                break;
            }
        }
        Log.message( "Verified " + dropdownName + " dropdown header" );
        return isHeaderPresent;
    }

    String StudentPerformanceDatesChild = "span";
    String MaskStudentDiplayText = "span.checkbox-label";
    String selectedDateRangeParent = "div > div > cel-radio-button:nth-child(2)";
    String selectedDateRangeChild = "label";
    String startDateToParent = "cel-date-input.to.hydrated";
    String startDateToChild = "label";

    String startDateParent = "cel-date-input.from.hydrated";
    String startDateChild = "label.date-input-label";

    String datePickerFromParent = "cel-date-input.from.hydrated";
    String datePickerFromChild = "#cel-date-input-1";

    private String celbutton = "cel-button";

    public ReportComponents( WebDriver driver ) {
        super( driver );
        this.driver = driver;
    }

    /***
     * Click on Students Radio Btn
     * 
     * @return
     */
    public void checkStudntRadioBtn() {
        SMUtils.waitForElement( driver, studentRadioBtn );
        SMUtils.clickJS( driver, studentRadioBtn );
        Log.message( "Clicked Studnets Radio Button" );

    }

    /**
     * To verify the save report option button is enabled
     * 
     * @return
     */
    public boolean isSaveReportButtonEnabled() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        return SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ).isEnabled();
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandDropDownMS() throws InterruptedException {
        SMUtils.nap( 0.5 );// It Is required because after saving the report,need
                           // time to load all dropdwon
        if ( isDropDownMSCollapsed() ) {
            WebElement btnDropDownExpand = SMUtils.getWebElement( driver, test, expandMsDropdown );
            try {
                SMUtils.clickJS( driver, btnDropDownExpand );
            } catch ( Exception e ) {
                btnDropDownExpand.click();
            }
        }
        Log.assertThat( isDropDownMSExpanded(), "DropDown Expanded-Successful", "DropDown Expanded-Not Successful" );
    }

    /***
     * Set the multi-select dropdown
     *
     * @param ms_dropdown
     */
    public void setDropDownMS( String ms_dropdown ) {
        if ( ms_dropdown.equalsIgnoreCase( "groups" ) || ms_dropdown.toLowerCase().equalsIgnoreCase( "students" ) ) {
            for ( WebElement lblDropdown : lblGroupAndStudentsDropdown ) {
                if ( lblDropdown.getText().trim().contains( ms_dropdown ) ) {
                    //                  shadowTree = lblDropdown.findElement(By.cssSelector(shadowRootGroupAndStudentsDropdown));
                    shadowTree = shadowRootGroupAndStudentsDropdown;
                }
            }
            // select group radio button
            checkGroupsOrStudentRB( ms_dropdown );
        } else if ( ms_dropdown.toLowerCase().equals( "assignments" ) ) {
            shadowTree = shadowRootAssignmentsDropdown;
        } else if ( ms_dropdown.toLowerCase().equals( "subject" ) )
            shadowTree = shadowRootSubjectsDropdown;
        // scroll the respective drop down into the view
        // SMUtils.scrollWebElementToView( driver, shadowTree );
    }

    /***
     * Checks the Students Radio button
     *
     * @param dropdownName
     */
    public void checkGroupsOrStudentRB( String dropdownName ) {
        if ( !isGroupsOrStudentRBChecked( dropdownName ) ) {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().contains( dropdownName ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
                    rbGroupOrStudent.click();
                    Log.message( "Clicked " + dropdownName + " radio button." );
                    break;
                }
            }
        }
    }

    /***
     * Checks whether students radio button is selected or not
     *
     * @param dropdownName
     * @return
     */
    public boolean isGroupsOrStudentRBChecked( String dropdownName ) {
        boolean isChecked = false;
        try {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().equals( dropdownName ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
                    isChecked = rbGroupOrStudent.isSelected();
                    Log.message( "Verified radio button for " + dropdownName );
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "Getting error while verifying student radio button!" );
        }
        return isChecked;
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromDropDownMS() throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        if ( Objects.isNull( shadowTree ) ) {
            throw new Exception( "Set DropdownMS value first" );
        }

        // expand ms drop down
        expandDropDownMS();

        // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, option, shadowRootSelectDropDownMS );
        for ( WebElement value : msValuesList ) {
            WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, valuesFromMSDropdown );
            msDropDownValues.add( txtGroupStudents.getText() );
        }
        Log.message( "Got all options from MS Dropdown!" );
        return msDropDownValues;
    }

    public List<String> getAllValuesFromDropdown( String dropdown ) {
        final List<String> values = new ArrayList<String>();
        WebElement rootElement = null;
        WebElement parent = null;
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }

        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> elements = SMUtils.getWebElementsDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
            values.addAll( elements.stream().map( element -> SMUtils.getWebElementDirect( driver, element, LABEL ).getAttribute( "data-label" ).trim() ).collect( Collectors.toList() ) );

        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            SMUtils.nap( 2 );
            List<WebElement> element = SMUtils.getWebElementsDirect( driver, parent, DROPDOWN_LIST_Root2 );
            values.addAll( element.stream().map( ddElement -> ddElement.getText().trim() ).collect( Collectors.toList() ) );
        }
        closeDropdown( dropdown );
        return values;
    }

    /**
     * Expand Dropdown
     * 
     * @author aravindan.srinivas
     * @param dropdownName
     */
    public void expanDropdown( String dropdownName ) {
        if ( !isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
            SMUtils.nap( 2 ); // wait for dropdown load

            Log.message( "Dropdown expanded: " + dropdownName );
        } else {
            Log.message( dropdownName + " Dropdown already expanded" );
        }
    }

    /**
     * Close dropdown Element
     * 
     * @author aravindan.srinivas
     * @param dropdownName
     */
    public void closeDropdown( String dropdownName ) {
        if ( isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
        } else {
            Log.message( dropdownName + " Dropdown already closed" );
        }

        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }

    }

    /**
     * @author aravindan.srinivas Wait for the spinner to Load and Wait for
     *         disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }

    /**
     * Return true if the Dropdown is expanded
     * 
     * @author aravindan.srinivas
     * @param dropdown
     * @return
     */
    public boolean isDropdownExpanded( String dropdown ) {
        WebElement rootElement = null;
        WebElement lisRoot = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_SINGLE_SELECT_Root1 );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
        }
        return lisRoot != null ? true : false;
    }

    /***
     * Checks and return the Collapsed state as boolean for Multi-Select drop
     * down
     *
     * @return
     */
    public boolean isDropDownMSCollapsed() {
        Log.message( "Verifying MS dropdown collapsed or not!" );
        boolean isDropDownMSCollapsed = false;
        List<WebElement> dropDownMS_Expanded = SMUtils.getWebElements( driver, test, expandMsDropdown );
        isDropDownMSCollapsed = dropDownMS_Expanded.size() > 0;
        Log.message( "DropDown is Collapsed" );
        return isDropDownMSCollapsed;
    }

    /***
     * Checks and return the Expanded state as boolean for Multi-Select drop
     * down
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isDropDownMSExpanded() throws InterruptedException {
        SMUtils.nap( 0.2 );// This will need to load filter after save report
        Log.message( "Verifying MS dropdown Expanded or not!" );
        boolean isDropDownMSExpanded = false;
        List<WebElement> dropDownMS_Collapsed = SMUtils.getWebElements( driver, test, collapseMsDropdown );
        isDropDownMSExpanded = dropDownMS_Collapsed.size() > 0;
        return isDropDownMSExpanded;
    }

    /**
     * Validate Filter heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isFilterAndReportOptionsHeadingPresent( String title ) throws InterruptedException {
        Log.message( "Verifying " + title + " heading!" );

        SMUtils.getWebElementsDirect( driver, lblFilterAndReportOptionsHeading, lblOptionalFilters );
        Log.message( "Verified " + title + " Header is present." );

        return true;
    }

    /**
     * Validate "Select Student or Group" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isRefineSearchAndGroupsOrStudentsHeadingPresent( String title ) throws InterruptedException {
        Log.message( "Verifying " + title + " heading!" );
        for ( WebElement lblTitle : lblRefineSearchAndGroupOrStudentHeading ) {
            if ( lblTitle.getText().trim().equals( title ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Validate Additional Grouping dropdown heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isStaticDropdownHeadingPresent( String dropdownName ) throws InterruptedException {
        Log.message( "Verifying " + dropdownName + " Dropdown header!" );
        for ( WebElement staticDropdownHeader : lblStaticDropdownHeading ) {
            if ( staticDropdownHeader.getText().trim().equals( dropdownName ) )
                return true;
        }
        return false;
    }

    /***
     * Checks and return the boolean for Select All Checkbox checked or not.
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSelectALLChecked( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );
        expandDropDownMS();
        WebElement chbxSelectAllRoot = SMUtils.getWebElementDirect( driver, shadowTree, chbxSelectALLParentRoot );
        Log.message( "Verified select all check box in " + dropdownName + " dropdown!" );
        return SMUtils.getWebElement( driver, chbxSelectAllRoot, chbxSelectALL ).isSelected();
    }

    /**
     * Click select all checkbox for Multi-Select Dropdown
     *
     * @param dropdownName
     */
    public void clickSelectALLFromMSDropdownwithJS( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );

        // Expand multi-select Dropdown Expanded
        if ( isDropDownMSCollapsed() ) {
            expandDropDownMSWithJS();
        }
        WebElement hostElement = driver.findElement( By.cssSelector( String.format( multiSelectHostElement, dropdownName.toLowerCase() ) ) );
        SMUtils.waitForElement( driver, hostElement );
        SMUtils.nap( 5 );
        WebElement grandParentElement = SMUtils.getWebElementDirect( driver, hostElement, multiSelectParent );
        WebElement parentElement = SMUtils.getWebElementDirect( driver, grandParentElement, multiSelectParent );
        WebElement element = SMUtils.getWebElementDirect( driver, parentElement, input );
        SMUtils.clickJS( driver, element );
        Log.message( "SELECT ALL check box clicked successfully" );
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandDropDownMSWithJS() throws InterruptedException {
        if ( isDropDownMSCollapsed() ) {
            WebElement btnDropDownExpand = SMUtils.getWebElement( driver, test, expandMsDropdown );
            SMUtils.clickJS( driver, btnDropDownExpand );
            Log.message( "Expands Multi select dropdown" );
        }
        Log.assertThat( isDropDownMSExpanded(), "DropDown Expanded-Successful", "DropDown Expanded-Not Successful" );
    }

    /**
     * To Select DropdownMs Options
     *
     * @param optionNames
     * @throws Exception
     */
    public void selectDropdownMSOptions( String dropdownName, List<String> optionNames ) throws Exception {
        setDropDownMS( dropdownName );
        SMUtils.nap( 1 ); // required for option selection
        List<WebElement> chbxForDropdownMS = getWebElementsForMSDropdownOptions( dropdownName );
        List<String> optionsFromDropdownMS = getValuesFromDropDownMS();
        for ( int optionCount = 0; optionCount < optionsFromDropdownMS.size(); optionCount++ ) {
            if ( optionNames.contains( optionsFromDropdownMS.get( optionCount ) ) ) {
                WebElement checkedElement = chbxForDropdownMS.get( optionCount );
                SMUtils.clickJS( driver, checkedElement );
            }
        }
        SMUtils.nap( 1 ); // Required for dorpdown option loading
        Log.message( "List of options are selected in " + dropdownName + " Dropdown" );
    }

    /**
     * Get Check boxes for Multi-Select Dropdown
     *
     * @param dropdownName
     * @return
     */
    public List<WebElement> getWebElementsForMSDropdownOptions( String dropdownName ) throws InterruptedException {
        Log.message( "getting elements for " + dropdownName + " dropdown" );
        setDropDownMS( dropdownName );
        expandDropDownMS();
        List<WebElement> chbxMSDropdownsRoot = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );
        List<WebElement> chbxMSDropdown = new ArrayList<>();
        // get values from ms drop down
        for ( WebElement chbxMSDropdownRoot : chbxMSDropdownsRoot ) {
            chbxMSDropdown.add( SMUtils.getWebElement( driver, chbxMSDropdownRoot, txtDropDownMSValue ) );
        }
        return chbxMSDropdown;
    }

    /**
     * To get the place holder in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder ).getText().trim();
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromStaticDropDownMS( String dropDownName ) throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        do {
            expandStaticDropDownMS( dropDownName );
            // Get values from ms drop down
            List<WebElement> msValuesList = selectStaticDropDown( dropDownName );
            for ( WebElement value : msValuesList ) {
                msDropDownValues.add( value.getText() );
            }
        } while ( msDropDownValues.isEmpty() );
        Log.message( "Got all options from " + dropDownName + " Dropdown!" );
        return msDropDownValues;
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandStaticDropDownMS( String dropDownName ) throws InterruptedException {
        if ( dropDownName.toLowerCase().equals( ReportsUIConstants.ADDITIONAL_GROUPING_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandAdditionalGroupingDropdown );
            Log.message( "Expanded additional grouping dropdown" );
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.SORT_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandSortDropdown );
            Log.message( "Expanded Sort dropdown" );
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.DISPLAY_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandDisplayDropdown );
            Log.message( "Expanded Display dropdown" );
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.DATE_AT_RISK_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandDateAtRiskDropdown );
            Log.message( "Expanded Date at Risk dropdown" );
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.SPR_LANGUAGE_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandlanguageDropdown );
            Log.message( "Expanded Language dropdown" );
        }
    }

    /**
     * Selecting the static dropdown
     *
     * @param dropDownName
     * @return
     */
    public List<WebElement> selectStaticDropDown( String dropDownName ) {
        List<WebElement> values = null;
        Log.message( "Getting Parent root for " + dropDownName + " Dropdown!" );
        if ( dropDownName.toLowerCase().equals( ReportsUIConstants.ADDITIONAL_GROUPING_DROPDOWN.toLowerCase() ) ) {
            values = listAdditionalGrouping;
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.DISPLAY_DROPDOWN.toLowerCase() ) ) {
            values = listdisplay;
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.SORT_DROPDOWN.toLowerCase() ) ) {
            values = listSort;
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.DATE_AT_RISK_DROPDOWN.toLowerCase() ) ) {
            values = listDateAtRisk;
        } else if ( dropDownName.toLowerCase().equals( ReportsUIConstants.SPR_LANGUAGE_DROPDOWN.toLowerCase() ) ) {
            values = listLanguage;
        }
        return values;
    }

    /***
     * Get values from Multi-Select drop down For Clicking Using ClickJS
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromDropDownMultiSelect() throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        if ( Objects.isNull( shadowTree ) )
            throw new Exception( "Set DropdownMS value first" ); // expand ms drop
        // down
        expandDropDownMSWithJS(); // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );
        for ( WebElement value : msValuesList ) {
            WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, valuesFromMSDropdown );

            msDropDownValues.add( txtGroupStudents.getText() );

        }
        Log.message( "Got all options from MS Dropdown!" );
        return msDropDownValues;
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromStaticDropDown( String dropDownName ) throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        do {
            expandStaticDropDownMS( dropDownName );
            // get values from ms drop down
            List<WebElement> msValuesList = selectStaticDropDown( dropDownName );
            for ( WebElement value : msValuesList ) {
                msDropDownValues.add( value.getText().toLowerCase().trim() );
            }
            expandStaticDropDownMS( dropDownName );
        } while ( msDropDownValues.isEmpty() );
        Log.message( "Got all options from " + dropDownName + " Dropdown!" );
        return msDropDownValues;
    }

    /**
     * Click on Cancel button on save report option pop up
     *
     */
    public boolean isCancelBtnDisplayedOnSaveReport() {
        SMUtils.waitForElement( driver, cancelBtnSaveReportPopUpRoot );
        Log.message( "Validate cancel button is displaying" );

        WebElement element = SMUtils.getWebElementDirect( driver, cancelHostElement, cancelParentElement, cancelChildElement );
        return element.isDisplayed();
    }

    /**
     * Click Save Button on Save Report option window pop up
     */
    public boolean isSaveBtnDisplayedOnSaveReportPopUp() {
        SMUtils.waitForElement( driver, hostElement );
        Log.message( "Validate save button is displaying" );

        WebElement element = SMUtils.getWebElementDirect( driver, hostElement, parentElement, childElement );

        return element.isDisplayed();
    }

    /**
     * Get Save Report option Window pop up new header Text
     */
    public String saveReportOptionReplaceExistingFieldHeader() {
        Log.message( "Returning Replace Existing Report header " );
        return saveReportPopupDropdownHeaders.get( 0 ).getText();
    }

    /**
     * Get Save Report option Window pop up new header Text
     */
    public String saveReportOptionNewFieldHeader() {
        Log.message( "Returning New text header on Save Report option " );
        WebElement element = SMUtils.getWebElementDirect( driver, saveReportNewFieldParentRoot, saveReportFieldChildRoot );
        return element.getText();
    }

    /**
     * Get Save Report option Window pop up header Text
     *
     * @Return
     */
    public String getSaveReportPopUpTextHeader() {
        Log.message( "getting Save Report Popup header." );
        WebElement element = SMUtils.getWebElementDirect( driver, saveReportParentRoot, saveReportChildRoot );
        return element.getText();
    }

    /**
     * Clicking the save report option.
     */
    public void clickSaveReportOption() {
        SMUtils.nap( 3 );// It Will take time to load page for Report saving link
        WebElement clickSaveReport = SMUtils.getWebElement( driver, btnSaveReportRoot, secondary_button );
        try {
            SMUtils.clickJS( driver, clickSaveReport );
        } catch ( Exception e ) {
            clickSaveReport.click();
        }
        Log.message( "Clicked Save Report option button!" );
        SMUtils.nap( 3 );// After Saving report, It will take time to load
    }

    /**
     * @author sathish.suresh validate Display dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public boolean validateDisplayDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnDisplayshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnDisplayshadowDOM[0], this.drpDwnDisplayshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnDisplayshadowDOM, "Display Drop Down Field" );
        String attributeValue = drpDwnDisplayshadowDOM.getAttribute( "data-selected" );
        Log.softAssertThat( attributeValue.equals( txtGroupDrpdwn ), "Selected '" + attributeValue + "' as default value in Group Drpdwn Field", "'" + attributeValue + "' is not a default value in Group Drpdwn Field" );
        return true;
    }

    /**
     * @author raseem.mohamed
     * @param driver
     */
    public void clickSavedReportOptionsButton( WebDriver driver ) {
        try {
            WebElement btnSavedReportOptions = ShadowDOMUtils.getWebElement( driver, btnSavedReportOptionsShadowDOM[0], btnSavedReportOptionsShadowDOM[1] );
            SMUtils.click( driver, btnSavedReportOptions );
            Log.message( "User Clicked On Saved Report Options Button " );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

    }

    /**
     * select groups from group dropdown
     * 
     * @param driver
     * @param listGroups
     * @return
     * @throws InterruptedException
     */
    public boolean selectGroupsDropdwn( WebDriver driver, List<String> listGroups ) throws InterruptedException {
        boolean value = false;
        WebElement elementSelectAllOption = null;
        //click to open teacher dropdown
        WebElement elementDropdwn = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnGroupShadowDOM[0], drpdwnGroupShadowDOM[1] );
        SMUtils.click( driver, elementDropdwn );

        //Deselect 'Select All' option
        elementSelectAllOption = ShadowDOMUtils.retryAndGetWebElement( driver, drpdwnGroupSelectAllShadowDOM[0], drpdwnGroupSelectAllShadowDOM[1] );
        SMUtils.click( driver, elementSelectAllOption );

        //checking the dropdown value 
        for ( int j = 0; j < listGroups.size(); j++ ) {
            int count = 1;
            for ( int i = 1; i <= count; i++ ) {
                String optionShadowDom[] = { "multi-select", "document.querySelector('cel-multi-select').shadowRoot.querySelector('#dropdown cel-multi-checkbox').shadowRoot.querySelector('div.bottom-container div:nth-child(" + i + ")')" };
                WebElement elementOption = ShadowDOMUtils.retryAndGetWebElement( driver, optionShadowDom[0], optionShadowDom[1] );
                if ( elementOption.getText().equals( listGroups.get( j ).trim() ) ) {
                    SMUtils.click( driver, elementOption );
                    value = true;
                    break;
                } else {
                    count++;
                }
            }

            Log.softAssertThat( value, "'" + listGroups.get( j ) + "' Is Selected On Groups dropdown field Successfully", "Failed to Select' " + listGroups.get( j ) + "' On Groups dropdown field" );
        }
        //close groups dropdown
        SMUtils.click( driver, elementDropdwn );
        return value;
    }

    /**
     * Click Select all options in the Dropdown
     * 
     * @author sathish.suresh
     */
    public boolean clickSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( !SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
            if ( !verifySelectAllCheckBoxColor( dropdownName ) ) {
                SMUtils.click( driver, element );
            } else {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
            }
            Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
            closeDropdown( dropdownName );
        }
        return true;
    }

    public boolean unclickSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( !SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
            if ( !verifySelectAllCheckBoxColor( dropdownName ) ) {
                SMUtils.click( driver, element );
            } else {
                SMUtils.click( driver, element );
            }
            Log.message( "Clicked and Unclicked Select ALL for " + dropdownName + "Dropdown" );

        }
        return true;
    }

    public List<WebElement> getDropdownElement( String dropdownName ) {
        String query = "var root = document.querySelector('#" + dropdownName + " > div > cel-single-select').shadowRoot.querySelectorAll('#dropdown > li > label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    public boolean selectGroup( String name ) {
        expanDropdown( GROUPS );
        List<WebElement> ddElements = getDropdownElement( "groups" );
        for ( WebElement element : ddElements ) {
            if ( element.getAttribute( "data-label" ).equals( name ) ) {
                SMUtils.clickJS( driver, element );
                break;
            }
        }
        closeDropdown( GROUPS );
        return true;
    }

    /**
     * Return true if the checkBox is selected
     * 
     * @param dropdownName
     * @return
     */
    public boolean verifySelectAllCheckBoxColor( String dropdownName ) {
        WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_ROOT3 );
        String color = Color.fromString( element.getCssValue( "background-color" ) ).asHex();
        return ( color.equals( selectAllCheckBoxColor ) ) ? true : false;
    }

    /**
     * To get the place holder in Single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromSingleSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        String orgId = SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder1 ).getAttribute( "value" );
        RBSUtils rbsUtils = new RBSUtils();
        String orgNameFromId = rbsUtils.getOrg( orgId );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder ).getText().trim();

    }

    /**
     * To get available options in single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAvailableOptionsFromSingleSelectDropdown( String dropdownName ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );

    }

    /**
     * To click the Save Report options button
     * 
     * @return
     */
    public String getLabelFromSaveReportOptionButton() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        return SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ).getText().trim();
    }

    /**
     * Expand the single-select drop-down
     * 
     * @param dropdownName
     */
    public void expandSingleSelectDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded" + dropdownName + "drop-down" );

        }
    }

    /**
     * To verify the single-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * To select options in single-select dropdown
     * 
     * @param dropdownName
     */
    public void selectOptionsFromSingleSelectDropdown( String dropdownName, String options ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement optionElement;

        if ( dropdownName.equals( ReportsUIConstants.ORGANIZATIONS_LABEL ) ) {
            RBSUtils rbsUtils = new RBSUtils();
            String selectedOrgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), options );
            if ( Objects.isNull( selectedOrgId ) ) {
                String subDistrictOrgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1] );
                optionElement = SMUtils.getWebElementDirect( driver, parentRoot, String.format( organizationOption, rbsUtils.getOrganizationIDByName( subDistrictOrgId, options ) ) );
            } else {
                optionElement = SMUtils.getWebElementDirect( driver, parentRoot, String.format( organizationOption, selectedOrgId ) );
            }
        } else {
            optionElement = SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().filter( element -> options.equalsIgnoreCase( element.getText().trim() ) ).findFirst().orElse( null );
        }

        if ( !Objects.isNull( optionElement ) ) {
            SMUtils.click( driver, optionElement );
            Log.message( "Selected Option in " + dropdownName + " - " + options );
        } else {
            Log.fail( "The Selected option " + options + " is not presented under " + dropdownName + "dropdown!!!" );
        }
    }

    /**
     * To get the root Element for single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelectDropdown( String dropdownName ) {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            SMUtils.waitForElement( driver, optionalFilterRoot );
            return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );

        } catch ( InterruptedException e ) {
            Log.message( "Getting Issue while get the Organization dropdown root element!!!" );
            return null;
        }
    }

    /**
     * To get the student demographic drop-down labels for
     * 
     * @return
     */
    public List<String> getDropdownLabels() {
        Log.message( "Getting drodown labels!" );
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify the single-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownCollapsedForStudentPerformance( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdownStudentPerformance( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * Click Yes Radio button
     * 
     * @param dropDownName
     */
    public void clickYesRadioButton( String type ) {
        WebElement yesParentElement;
        if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ) ) {
            SMUtils.waitForElement( driver, includePerformanceSummarylblRoot );
            yesParentElement = SMUtils.getWebElement( driver, includePerformanceSummarylblRoot, yesBtnRoot );
        } else if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ) ) {
            SMUtils.waitForElement( driver, includePerformanceStrandlblRoot );
            yesParentElement = SMUtils.getWebElement( driver, includePerformanceStrandlblRoot, yesBtnRoot );
        } else {
            SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
            yesParentElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, yesBtnRoot );
        }

        WebElement atualElement = SMUtils.getWebElement( driver, yesParentElement, yesBtnChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked Yes Radio Button" );

    }

    /**
     * Click No Radio button
     * 
     * @param dropDownName
     */
    public void clickNoRadioButton( String type ) {
        WebElement noParentElement;
        if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ) ) {
            SMUtils.waitForElement( driver, includePerformanceSummarylblRoot );
            noParentElement = SMUtils.getWebElement( driver, includePerformanceSummarylblRoot, noBtnRoot );
        } else if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ) ) {
            SMUtils.waitForElement( driver, includePerformanceStrandlblRoot );
            noParentElement = SMUtils.getWebElement( driver, includePerformanceStrandlblRoot, noBtnRoot );
        } else {
            SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
            noParentElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, noBtnRoot );
        }

        WebElement atualElement = SMUtils.getWebElement( driver, noParentElement, noBtnChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked No Radio Button" );

    }

    /**
     * To get the root Element for single-select dropdown for Student
     * Performance
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelectDropdownStudentPerformance( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRootStudentPerformance );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );

    }

    /**
     * Verify Default Value of Date At Risk Dropdown
     * 
     * @return
     */
    public String verifyDateAtRiskDropdownValue() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFiltersDropdownItems.get( 0 ), optionalFilterValuesChild );
        Log.message( "Verify Default Value of Date At Risk Dropdown" );
        return actualElement.getText().trim();
    }

    /**
     * Expand the single-select drop-down for student performance optional
     * filter
     * 
     * @param dropdownName
     */
    public void expandSingleSelectDropdownForStudentPerformance( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsedForStudentPerformance( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdownStudentPerformance( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get the root Element for multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./../.." ) ).findElement( By.cssSelector( multiSelectDropdownRoot ) );
    }

    /**
     * To verify the multi-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * To get available options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getAvailableOptionsFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 40 );
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.waitForElement( driver, parentRoot );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().map(
                element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * Expand the multi-select drop-down
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void expandMultiSelectDropdown( String dropdownName ) {
        if ( isMultiSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.waitForElementToBeClickable( parentRoot, driver );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            SMUtils.nap( 5 );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * select student radio button
     * 
     * @param driver
     * @throws InterruptedException
     */
    public void selectStudentRadioBtn( WebDriver driver ) throws InterruptedException {
        SMUtils.click( driver, rdBtnStudent );
    }

    /**
     * To select options in multi-select dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public boolean selectOptionsFromMultiSelectDropdown( String dropdownName, List<String> options ) throws InterruptedException {
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> options.contains( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    SMUtils.nap( 5 );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                } );
        return true;
    }

    /**
     * To get the selected options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getSelectedOptionsFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputCheckbox ).isSelected() && !SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim().equalsIgnoreCase( ReportsUIConstants.ALL_OPTION ) ).map(
                        element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get the default items in single select dropdown optional filters
     * 
     * @param type
     */
    public String getDefaultItemsForOptionalReport( String type ) {
        WebElement textElement;
        if ( type.equals( ReportsUIConstants.DISPLAY_LABEL ) ) {
            SMUtils.waitForElement( driver, displaylbl );
            textElement = SMUtils.getWebElement( driver, displaylbl, optionalFieldPlaceHolder );
        } else if ( type.equals( ReportsUIConstants.LANGUAGE ) ) {
            SMUtils.waitForElement( driver, languagelbl );
            textElement = SMUtils.getWebElement( driver, languagelbl, optionalFieldPlaceHolder );
        } else {
            SMUtils.waitForElement( driver, dateAtRisklbl );
            textElement = SMUtils.getWebElement( driver, dateAtRisklbl, optionalFieldPlaceHolder );
        }
        Log.message( textElement.getText() );
        return textElement.getText();
    }

    /**
     * Verify the Check box with the Text Mask Student Display
     * 
     * @return
     */
    public String verifyCheckboxWithMaskStudent() {
        SMUtils.waitForElement( driver, maskStudentCheckboxParent );
        WebElement actualElement = SMUtils.getWebElement( driver, maskStudentCheckboxParent, maskStudentCheckboxChild );
        Log.message( "Verify the Check box with the Text Mask Student Display" );
        return actualElement.getText().trim();
    }

    // Student Performance Optional Fields Methods
    /**
     * Get mask student label for Student Performance
     * 
     * @return
     */
    public String getMaskStudentDisplaylbl() {
        SMUtils.waitForElement( driver, maskStudentlblRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, maskStudentlblRoot, grandChildCheckBoxLabel );
        Log.message( "Getting Mask student display text" );
        return actualElement.getText().trim();
    }

    /**
     * Verify Optional Filters is displaying for Student Performance
     * 
     * @return
     */
    public Boolean isOptionalFilterDisplayingForStudentPerformance() {
        SMUtils.waitForElement( driver, optionalFilterRootStudentPerformance );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterRootStudentPerformance, optionalFilter );
        Log.message( "Optional filter is displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * Get Include Areas of Growth Label
     * 
     * @return
     */
    public String getIncludeAreasOfGrowthlbl() {
        SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, includePerformanceSummaryStudent );
        Log.message( "Getting Include Areas of Growth text" );
        return actualElement.getText().trim();

    }

    /**
     * To verify the Report title is displaying or not
     * 
     * @return
     */
    public boolean isCPRReportTitleDisplayed() {

        Log.message( "Verifing Cumulative Performance Report Title is displayed" );

        SMUtils.waitForElement( driver, PageTitle );
        return PageTitle.isDisplayed();
    }

    /**
     * Validate "Select Student or Group" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isGroupsAndStudentsHeadingPresent( String title ) throws InterruptedException {
        SMUtils.waitForElement( driver, lblRefineSearchAndGroupOrStudentHeading2 );
        Log.message( "Verifying " + title + " heading!" );
        Log.message( lblRefineSearchAndGroupOrStudentHeading2.getText() );
        return lblRefineSearchAndGroupOrStudentHeading2.getText().trim().equals( title );
    }

    /**
     * Validate radio button heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean radioGropsandStudentsHeadingPresent( String buttons ) throws InterruptedException {
        boolean isHeaderPresent = false;
        for ( WebElement radioButton : radioGropsandStudentsHeading ) {
            if ( radioButton.getText().trim().equals( buttons ) ) {
                isHeaderPresent = true;
                break;
            }
        }
        Log.message( "Verified " + buttons + " dropdown header" );
        return isHeaderPresent;
    }

    /**
     * Validate "Course Selection" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isCourseSelectionHeadingPresent( String title ) throws InterruptedException {
        SMUtils.waitForElement( driver, lblRefineSearchAndGroupOrStudentHeading2 );
        Log.message( "Verifying " + title + " heading!" );
        Log.message( courseSelection.getText() );
        return courseSelection.getText().trim().equals( title );
    }

    /**
     * Validate dropdown
     *
     * @return
     * @throws InterruptedException
     */
    public boolean courseSelectionDropdownHeadingPresent( String selection ) throws InterruptedException {
        boolean isHeaderPresent = false;
        for ( WebElement select : courseselectionTxt ) {
            Log.message( select.getText() );
            if ( select.getText().trim().equals( selection ) ) {
                isHeaderPresent = true;
                break;
            }
        }
        Log.message( "Verified " + selection + " dropdown header" );
        return isHeaderPresent;
    }

    /**
     * Validate "Additional Grouping" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isAdditionalGroupingHeadingPresent( String title ) throws InterruptedException {
        SMUtils.waitForElement( driver, optionalFilteAdditionalGroupingTxt );
        Log.message( "Verifying " + title + " heading!" );
        Log.message( optionalFilteAdditionalGroupingTxt.getText() );
        return optionalFilteAdditionalGroupingTxt.getText().trim().equals( title );
    }

    /**
     * Validate "Display" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isDisplayHeadingPresent( String title ) throws InterruptedException {
        SMUtils.waitForElement( driver, optionalFilteDisplayTxt );
        Log.message( "Verifying " + title + " heading!" );
        Log.message( optionalFilteDisplayTxt.getText() );
        return optionalFilteDisplayTxt.getText().trim().equals( title );
    }

    /**
     * Validate "Sort" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isSortHeadingPresent( String title ) throws InterruptedException {
        SMUtils.waitForElement( driver, optionalFilteSortTxt );
        Log.message( "Verifying " + title + " heading!" );
        Log.message( optionalFilteSortTxt.getText() );
        return optionalFilteSortTxt.getText().trim().equals( title );
    }

    /**
     * Validate "Display" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isStudentPerformanceDatesPresent( String title ) throws InterruptedException {
        SMUtils.waitForElement( driver, StudentPerformanceDatesRoot );
        Log.message( "Verifying " + title + " heading!" );
        WebElement performanceDates = SMUtils.getWebElement( driver, StudentPerformanceDatesRoot, StudentPerformanceDatesChild );
        Log.message( performanceDates.getText() );
        return performanceDates.getText().trim().equals( title );
    }

    /**
     * Validate Mask Student Display in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isMaskStudentDisplayDisplayed( String field ) throws InterruptedException {
        Log.message( "Verifying -" + field );
        for ( WebElement maskstudent : chbxMaskStudentDisplayRoot ) {
            WebElement maskStudentchild = SMUtils.getWebElement( driver, maskstudent, MaskStudentDiplayText );
            Log.message( maskStudentchild.getText().trim() );
            if ( maskStudentchild.getText().trim().equals( field ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check or uncheck the Mask Student Display
     *
     */
    public void checkOrUncheckBoxMaskstudent() throws InterruptedException {
        for ( WebElement parentRoot : chbxMaskStudentDisplayRoot ) {
            //         WebElement lblRemovePageBreak = SMUtils.getWebElement( driver, parentRoot, MaskStudentDiplayText );
            //     if ( parentRoot.getText().trim().equals( Constants.Reports.MASK_STUDENT_DISPLAY ) ) {
            //         WebElement chbxRemovePageBreak = SMUtils.getWebElement( driver, parentRoot, chbxRemovePageBreakAndMaskStudentDiplay );
            SMUtils.clickJS( driver, parentRoot );
            //        }
        }
        Log.message( "clicked & Unclicked checkbox!" );
    }

    public void clickStudentRadioButton() {
        SMUtils.waitForElement( driver, radioBtnStudent );
        SMUtils.click( driver, radioBtnStudent );
    }

    /**
     * Click Range fields in CPR Page
     *
     * @param dateHeader
     * @return
     * @throws InterruptedException
     */
    public boolean clickSelectedDateRangesPresent( String dateHeader ) throws InterruptedException {
        Log.message( "Verifying " + dateHeader + " Heading!" );
        WebElement dateRangeText1 = SMUtils.getWebElement( driver, selectedDateRangeRoot, selectedDateRangeParent );
        WebElement dateRangeText2 = SMUtils.getWebElement( driver, dateRangeText1, selectedDateRangeChild );
        SMUtils.clickJS( driver, dateRangeText2 );
        return dateRangeText2.getText().trim().equals( dateHeader );
    }

    /**
     * Validate From Date under "From Date" in CPR Page
     *
     * @param textBoxName
     * @return
     * @throws InterruptedException
     */
    public boolean isFromDateHeaderPresent( String textBoxName ) throws InterruptedException {
        Log.message( "Verifying " + textBoxName + " text box header!" );
        //       WebElement parent = SMUtils.getWebElement(driver, startDateRoot, startDateGrandParent);
        WebElement child1 = SMUtils.getWebElementDirect( driver, startDateRoot, startDateParent );
        WebElement child2 = SMUtils.getWebElementDirect( driver, child1, startDateChild );
        child2.getText().trim().equals( textBoxName );
        return true;
    }

    /**
     * Validate From Date under "From Date" in CPR Page
     *
     * @param textBoxName
     * @return
     * @throws InterruptedException
     */
    public boolean isToHeaderPresent( String textBoxName ) throws InterruptedException {
        Log.message( "Verifying " + textBoxName + " text box header!" );
        //      WebElement parent = SMUtils.getWebElement(driver, startDateRoot, startDateGrandParent);
        WebElement child1 = SMUtils.getWebElement( driver, startDateRoot, startDateToParent );
        WebElement child2 = SMUtils.getWebElement( driver, child1, startDateToChild );
        child2.getText().trim().equals( textBoxName );
        return true;
    }

    /**
     * Validate date picker for from date in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isDatePickerDisplayedForFomDAte() throws InterruptedException {
        Log.message( "Verifying Date picker for From date text box." );
        WebElement datePicker1 = SMUtils.getWebElement( driver, datePickerFromRoot, datePickerFromParent );
        WebElement datePicker2 = SMUtils.getWebElement( driver, datePickerFromRoot, datePickerFromChild );
        Log.message( "datapicker is present" );
        //    return SMUtils.isElementPresent(datePicker2  );
        return true;
    }

    /**
     * To click the Save Report options button
     * 
     */
    public SaveReportFilterPopup clickSaveReportOptionButton() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ) );
        return new SaveReportFilterPopup( driver ).get();
    }
    
	public String verifyZeroStateAssignment() {
		SMUtils.nap(4);
		WebElement webElementDirect = SMUtils.getWebElementDirect(driver, zerostateParentElement, dropdownplaceHolder);
		String message = webElementDirect.getText().trim();
		return message;
	}

	public String verifyZeroStateSaveReportOption() {

		WebElement webElementDirect = SMUtils.getWebElementDirect(driver, zeroStateSavedReportParentElement,
				singleDropdownDropdownItem);
		String message = webElementDirect.getText().trim();
		return message;
	}

	public String verifyZeroStateMessage() {
		SMUtils.waitForElement(driver, zeroStateDescription);
		String message = zeroStateDescription.getText().trim();
		return message;
	}
	
	 /**
     * To Click Run Report Button
     */
    public boolean clickRunReportButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, runReportButtonRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, runReportButtonRoot, button ) );
            Log.message( "Clicked Run Report Button!" );
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Clicked Run Report Button Failed" );
            return false;
        }
    }
	
    public void handleStudentPopup() {
        SMUtils.waitForElement( driver, studentIDPopupparent );
        SMUtils.getWebElementDirect( driver, studentIDPopupparent, studnetIDPopup, button );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentIDPopupparent, studnetIDPopup, button ) );

    }
    
}
