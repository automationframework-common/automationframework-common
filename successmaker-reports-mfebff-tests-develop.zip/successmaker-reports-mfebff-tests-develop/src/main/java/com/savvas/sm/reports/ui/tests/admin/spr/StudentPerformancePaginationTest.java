package com.savvas.sm.reports.ui.tests.admin.spr;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentPerformancePaginationTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        username = "auto_savvas_districtadmin";

    }

    @Test ( enabled = true, description = "Student Performance Pagination Test", groups = { "SMK-61331", "Student Performance - Pagination Test", "SPR" }, priority = 1 )
    public void tcSMStudentPerformancePaginatonTest001(  ) throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, RBSDataSetupConstants.PASSWORD+1 );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();


            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( studentPerformancePage.selectOrganization("SM Regression Auto School 7" ), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();


            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( studentPerformancePage.selectSubject( "Reading" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.COURSES );
            studentPerformancePage
                    .setValuesForDropdown( studentPerformancePage.COURSES, coursesName.stream()
                            .filter( c->(c.contains( "Miller Rivera" ) ) ).collect( Collectors.toList()) );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            studentPerformancePage.clickOptionalFilter();


            studentPerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(studentPerformancePage.checkReportHeaderAfterRun(), "Student Performance Report data displayed",
                    "Student Performance Report data not displayed" );
            List<String> studentCourseLst = new ArrayList<>();
            int totalPage = studentPerformancePage.countPage();


            Log.assertThat(totalPage==1, "Single Report Page is displayed",
                    "Multiple page is displayed" );
            Log.assertThat(Boolean.FALSE.equals( studentPerformancePage.isBackButtonEnable() ), "Back Button Disable",
                    "Back Button Not Disable" );
            Log.assertThat(Boolean.FALSE.equals( studentPerformancePage.isNextButtonEnable() ), "Next Button Disable",
                    "Next Button Not Disable" );


           Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, description = "Student Performance Pagination Test", groups = { "SMK-61331", "Student Performance - Pagination Test", "SPR" }, priority = 2 )
    public void tcSMStudentPerformancePaginatonTest002(  ) throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, RBSDataSetupConstants.PASSWORD+1 );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();


            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( studentPerformancePage.selectOrganization("SM Regression Auto School 7" ), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();


            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( studentPerformancePage.selectSubject( "Reading" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.COURSES );
            studentPerformancePage
                    .setValuesForDropdown( studentPerformancePage.COURSES, coursesName );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            studentPerformancePage.clickOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );
            studentPerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(studentPerformancePage.checkReportHeaderAfterRun(), "Student Performance Report data displayed",
                    "Student Performance Report data not displayed" );
            int totalPage = studentPerformancePage.countPage();
            Log.assertThat(totalPage>1, "Multiple Report page present",
                    "Multiple report page not present" );
            studentPerformancePage.clickNextButton();
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(Boolean.TRUE.equals( studentPerformancePage.isBackButtonEnable() ), "Back Button Disable",
                    "Back Button Not Disable" );
            Log.assertThat(Boolean.TRUE.equals( studentPerformancePage.isNextButtonEnable() ), "Next Button Disable",
                    "Next Button Not Disable" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, description = "Student Performance Pagination Test", groups = { "SMK-61331", "Student Performance - Pagination Test", "SPR" }, priority = 3 )
    public void tcSMStudentPerformancePaginatonTest003(  ) throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, RBSDataSetupConstants.PASSWORD+1 );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();


            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( studentPerformancePage.selectOrganization("SM Regression Auto School 7" ), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();


            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( studentPerformancePage.selectSubject( "Reading" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.COURSES );
            studentPerformancePage
                    .setValuesForDropdown( studentPerformancePage.COURSES, coursesName );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            studentPerformancePage.clickOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );
            studentPerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(studentPerformancePage.checkReportHeaderAfterRun(), "Student Performance Report data displayed",
                    "Student Performance Report data not displayed" );
            int totalPage = studentPerformancePage.countPage();
            for(int i=1 ; i<=totalPage; i++){
                studentPerformancePage.clickNextButton();
                try {
                    SMUtils.waitForSpinnertoDisapper( driver);
                } catch ( InterruptedException e ) {
                    e.printStackTrace();
                }
            }
            Log.assertThat(totalPage>1, "Multiple Report page present",
                    "Multiple report page not present" );
            Log.assertThat(Boolean.TRUE.equals( studentPerformancePage.isBackButtonEnable() ), "Back Button Disable",
                    "Back Button Not Disable" );
            Log.assertThat(Boolean.FALSE.equals( studentPerformancePage.isNextButtonEnable() ), "Next Button Disable",
                    "Next Button Not Disable" );


            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


}
