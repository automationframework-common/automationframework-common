package com.savvas.sm.report.bff.teacher.tests;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import io.restassured.response.Response;

public class AFGTeacherReportGraphQLTest extends UserAPI {
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String groupID;
    String teacherDetails;
    String browser;
    String username;
    String orgId;
    String teacherId;
    String student1;
    String studentUserName;
    String studentId;
    HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        studentId = SMUtils.getKeyValueFromResponse( student1, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( student1, "userName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        } catch ( Exception e1 ) {
            Log.message( "Issue in getting access token!!!.Retrying" );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        }

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentId ), Arrays.asList( "1", "2" ) );
        Log.message( "Assignment Details" + assignmentResponse );

        WebDriver driver = WebDriverFactory.get( browser );
        try {
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeMathCourse( studentUserName, "Math", "0", "5", "50" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.message( "Error occured while run the simulator!!!" );
        } finally {
            driver.quit();
        }
        driver = WebDriverFactory.get( browser );
        try {
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeReadingCourse( studentUserName, "Reading", "0", "3", "35" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.message( "Error occured while run the simulator!!!" );
        } finally {
            driver.quit();
        }

    }

    @Test ( dataProvider = "getData", groups = { "SMK-55497  GraphQL API for AFG report", "API", "smoke_test_case" }, priority = 1 )
    public void testAFGReportAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + " " + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        String payload = getPayload();
        Response response = null;
        String responseStatusCode = "";
        GroupAPI group = new GroupAPI();
        HashMap<String, String> apiDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        apiDetails.put( "groupOwnerOrgId", orgId );
        apiDetails.put( "staffId", teacherId );
        HashMap<String, String> responsea = group.getGroupListingForTeacherID( smUrl, apiDetails );
        System.out.println( response );
        List<String> groupIda = SMUtils.getAllKeyValueFromJsonArray( responsea.get( Constants.REPORT_BODY ), "groupId" );
        groupID = groupIda.get( 0 );

        switch ( scenarioType ) {

            case "VALID_INPUT_QUERY_PARAMS":
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "false" ).replace( "{studentId}", studentId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "TEACHER_DONT_HAVE_AFG_REPORT":
                payload = getPayloadWithGroup();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "INVALID_TOKEN":
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "false" ).replace( "{studentId}", studentId );
                headers.put( Constants.AUTHORIZATION, "Bearer 1234$" );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "INVALID_SUBJECT_ID":
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "3" ).replace( "{status}", "false" ).replace( "{studentId}", studentId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VERIFY_MATH_RESPONSE":
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "false" ).replace( "{studentId}", studentId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VERIFY_READING_RESPONSE":
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{status}", "false" ).replace( "{studentId}", studentId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "STUDENT_ID IS [-1]":
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "false" ).replace( "{studentId}", "-1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME_AFG, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "IS_GROUP_SELECTED_NOT_PROVIDED":
                payload = getPayloadWithoutIsGroupSelected();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{studentId}", studentId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "GROUP_ID IS [-1]":
                payload = getPayloadWithGroup();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "GROUP_ID PROVIDED":
                payload = getPayloadWithGroup();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "true" ).replace( "{groupId}", groupID );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "ASSIGNMENT_ID NOT PROVIDED":
                payload = getPayloadWithGroup();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "1" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "SORT_BY_SKILL-DESCRIPTION":
                payload = getPayloadWithOrderBy();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" ).replace( "{orderBy}", "SKILL_DESCRIPTION" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "DATE_AT_RISK_NOT_PROVIDED":
                payload = getPayloadWithOrderBy();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" ).replace( "{orderBy}", "SKILL_DESCRIPTION" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "DATE_AT_RISK_PROVIDED":
                payload = getPayloadWithDateAtRisk();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" ).replace( "{orderBy}", "SKILL_DESCRIPTION" ).replace( "{datesAtRisk}",
                        "1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITH_SINGLE_SET_QUERY":
                payload = getPayloadWithGroup();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITH_MULTIPLE_SET_QUERY":
                payload = getPayloadWithGroup();
                payload = payload.replace( "{orgId}", orgId ).replace( "{teacherId}", teacherId ).replace( "{subjectId}", "2" ).replace( "{status}", "true" ).replace( "{groupId}", "-1" );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( "user-id", teacherId );
                headers.put( "org-id", orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        if ( !scenarioType.equalsIgnoreCase( "TEACHER_DONT_HAVE_AFG_REPORT" ) && !scenarioType.equalsIgnoreCase( "INVALID_TOKEN" ) && !scenarioType.equalsIgnoreCase( "INVALID_SUBJECT_ID" ) && !scenarioType.equalsIgnoreCase( "STUDENT_ID IS [-1]" ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "afgteacherReportSchema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }

        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] {

                { "TC001", "200", "Verfiy graphQL is obtaining predictable response when valid headers and 'mandatory input query params' are provided for getAOGReportData", "VALID_INPUT_QUERY_PARAMS" },

                { "TC002", "200", "Verfiy 200 'Report details not found' when valid headers and irrelavant student id given in query params for getAOGReportData", "TEACHER_DONT_HAVE_AFG_REPORT" },

                { "TC003", "200", "Verify 401 UnAuthorized message in response body when invalid Bearer token is given ", "INVALID_TOKEN" },

                { "TC004", "200", "Verify \"400: Bad Request\" and 'Invalid value passed for Subject Id' message in the  response body when invalid query has been given", "INVALID_SUBJECT_ID" },

                { "TC005", "200", "Verify graphQL is obtaining predictable response when single set query is given for getAOGReportData query", "WITH_SINGLE_SET_QUERY" },

                { "TC006", "200", "Verify graphQL is obtaining predictable response when multiple set query is given for getAOGReportData query", "WITH_MULTIPLE_SET_QUERY" },

                { "TC007", "200", "Verify Math related response is fetched in the response body when subject Id 1 is provided in the input query param", "VERIFY_MATH_RESPONSE" },

                { "TC008", "200", "Verify Reading related response is fetched in the response body when subject Id 2 is provided in the input query param", "VERIFY_READING_RESPONSE" },

                { "TC009", "200", "Verify the passed studentIds are fetched by default in the response body when 'isGroupSelected' is not provided in the input query param", "IS_GROUP_SELECTED_NOT_PROVIDED" },

                { "TC010", "200", "Verify all students reports are fetched in the response when default studentId [-1] is provided in the input request query param with IsGroupSelected as false", "STUDENT_ID IS [-1]" },

                { "TC011", "200", "Verify all groups id's are fetched in the response when default groupIds[-1] is provided in the input request query param with IsGroupSelected as true", "GROUP_ID IS [-1]" },

                { "TC012", "200", "Verify the passed groupIds are fetched in the response body when groupIds[] is provided in the input request query param with IsGroupSelected as true", "GROUP_ID PROVIDED" },

                { "TC013", "200", "Verify graphql is obtaining all the assignments data in the response body when assignment Id is not provided in the request param", "ASSIGNMENT_ID NOT PROVIDED" },

                { "TC015", "200", "Verify graphql is obtaining reports is sorted based on the 'orderBy' value passed in the query param(STRAND, LEVEL, SKILL_DESCRIPTION)", "SORT_BY_SKILL-DESCRIPTION" },

                { "TC016", "200", "Verify graphql is obtaining reports for 10400 weeks by default when 'datesAtRisk' is not provided in the request param", "DATE_AT_RISK_NOT_PROVIDED" },

                { "TC017", "200", "Verify graphql is obtaining reports based on the 'datesAtRisk' value passed in the query param(10400,24, 20, 16, 12, 8, 4, 2, 1)", "DATE_AT_RISK_PROVIDED" },

        };
    }

    public String getPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "AFGReportRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getPayloadWithGroup() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "AFGReportRequest_2" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getPayloadWithOrderBy() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "AFGReportRequest_3" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getPayloadWithAssignmentId() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "AFGReportRequest_4" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getPayloadWithDateAtRisk() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "AFGReportRequest_5" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

    public String getPayloadWithoutIsGroupSelected() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "AFGReportRequest_6" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }
}
