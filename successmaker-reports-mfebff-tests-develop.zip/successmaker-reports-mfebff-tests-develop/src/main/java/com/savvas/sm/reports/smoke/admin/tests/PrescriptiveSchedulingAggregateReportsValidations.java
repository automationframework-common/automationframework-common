package com.savvas.sm.reports.smoke.admin.tests;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.PSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.smoke.admin.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.admin.pages.PerspectiveSchedulingAggregateReport;
import com.savvas.sm.reports.smoke.admin.pages.PerspectiveSchedulingReport;
import com.savvas.sm.reports.smoke.admin.pages.ReportsViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PrescriptiveSchedulingAggregateReportsValidations extends EnvProperties {

    private String browser;
    CourseAPI coursesMethod = new CourseAPI();
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String flexSchoolId;
    private String mathId;
    private String readingId;
    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String studentId;
    String studentId1;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String firstTeacherOrgID;
    String orgName;
    List<String> courses;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        RBSUtils rbsUtils = new RBSUtils();
        
        mathId = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

        readingId = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

       

        // Teacher UserNames
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        //Selected School Name
        firstTeacherOrgID = ReportData.orgId;
        //orgName = SMUtils.getKeyValueFromResponse( rbsUtils.getOrg( firstTeacherOrgID ), "name" );
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        //Teacher User ID's
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );

        //Group ID's
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 1 ).toString(), "groupId" );


        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        //Filter By Values - OrgId
        flexSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        //School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );
    }

  

    @Test ( description = "Verify Prescriptive Scheduling Aggregate  Report without filter Test", groups = { "SMK-66764", "Prescriptive Scheduling Aggregate  Report", "PSAR" }, priority = 1 )
    public void tcSMPrescriptiveSchedulingAggergateTest001() throws Exception {
        Log.message( "Login in with Admin: " + distAdminUserName );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = smLoginPage.loginToSMPSReportAdmin( distAdminUserName, password );

            prescriptiveSchedulingPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            prescriptiveSchedulingPage.navigateToPSAReport();
            
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );

            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );

            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            prescriptiveSchedulingPage.reportFilterComponent.setCoursesDropdownSelectAll();

            // Setting Grade Level 
            List<Float> targetLevelArray = new ArrayList<>( Arrays.asList( 2f, 4f, 4f, 4f, 6f, 6f, 7f, 8f, 8.95f, 8.95f, 8.95f, 8.95f, 8.95f ) );


            IntStream.range( 0, targetLevelArray.size() ).forEach( index -> {
                prescriptiveSchedulingPage.setTargetLevelForGrade( prescriptiveSchedulingPage.GradeLevels.get( index ), targetLevelArray.get( index ) );
            } );

            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate2();

            prescriptiveSchedulingPage.clickIncrementGrade( prescriptiveSchedulingPage.GradeLevels.get( 0 ) );
            prescriptiveSchedulingPage.clickDecrementGrade( prescriptiveSchedulingPage.GradeLevels.get( 0 ) );

            prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            // Setting date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
            LocalDate date = LocalDate.now();
            String targetDate = formatter.format( date );

            //            String subject = Subject;

            List<String> teacherIdList = new ArrayList<>( Arrays.asList() );
            List<String> groupIdList = new ArrayList<>( Arrays.asList() );
            int additionalGrouping = PSRConstants.GROUP_BY_GRADE;

            HashMap<String, String> headers = new HashMap<>();
            String adminDetails = new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( distAdminUserName ) );
            JsonPath jsonPathEvaluator = new JsonPath( adminDetails );
            String adminId = jsonPathEvaluator.getString( Constants.USERID );
            String adminOrgId = jsonPathEvaluator.getString( "affiliationInfo[0]." + Constants.ORGANIZATION_ID );

            List<String> assignmentIds = new ArrayList<>( Arrays.asList() );
            String payload = getBody( flexSchoolId, "math", Arrays.asList( mathId ), targetDate, targetLevelArray );
            
            //Headers
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( distAdminUserName, password ) );
            headers.put( Constants.USERID_SM_HEADER, adminId );
            headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

                        HashMap<String, List<String>> exp = getListOfValuesFromAPIOutput( response );
                        Log.message( "Moving to UI verification" );
                        HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
                        Log.message( "getListOfValuesFromAPIOutput:"+exp );
                        Log.message( "getListOfValuesFromUIOutput"+act);

            // Verification
                        SoftAssert softassert = new SoftAssert();
                        act.keySet().forEach( key -> {
                            softassert.assertEquals( act.get( key ), exp.get( key ), "The value is not Matched for " + key + "\nActual:" + act.get( key ) + "\nExpected:" + exp.get( key ) );
                        } );

                        softassert.assertAll();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Prescriptive Scheduling Aggregate Report without filter Test", groups = { "SMK-66764", "Prescriptive Scheduling Aggregate  Report", "PSAR" }, priority = 1 )
    public void tcSMPrescriptiveSchedulingAggergateTest002() throws Exception {
        Log.message( "Login in with Admin: " + distAdminUserName );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = smLoginPage.loginToSMPSReportAdmin( distAdminUserName, password );

            prescriptiveSchedulingPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            prescriptiveSchedulingPage.navigateToPSAReport();
            
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );


            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );

            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            prescriptiveSchedulingPage.reportFilterComponent.setCoursesDropdownSelectAll();

            // Setting Grade Level 
            List<Float> targetLevelArray = new ArrayList<>( Arrays.asList( 2f, 4f, 4f, 4f, 6f, 6f, 7f, 8f, 8.95f, 8.95f, 8.95f, 8.95f, 8.95f ) );


            IntStream.range( 0, targetLevelArray.size() ).forEach( index -> {
                prescriptiveSchedulingPage.setTargetLevelForGrade( prescriptiveSchedulingPage.GradeLevels.get( index ), targetLevelArray.get( index ) );
            } );

            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate2();

            prescriptiveSchedulingPage.clickIncrementGrade( prescriptiveSchedulingPage.GradeLevels.get( 0 ) );
            prescriptiveSchedulingPage.clickDecrementGrade( prescriptiveSchedulingPage.GradeLevels.get( 0 ) );

            prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            prescriptiveSchedulingPage.reportFilterComponent.waitForSpinnerToLoadAndDisppear();

            // Setting date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
            LocalDate date = LocalDate.now();
            String targetDate = formatter.format( date );

            //            String subject = Subject;

            List<String> teacherIdList = new ArrayList<>( Arrays.asList() );
            List<String> groupIdList = new ArrayList<>( Arrays.asList() );
            int additionalGrouping = PSRConstants.GROUP_BY_GRADE;

            HashMap<String, String> headers = new HashMap<>();
            String adminDetails = new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( distAdminUserName ) );
            JsonPath jsonPathEvaluator = new JsonPath( adminDetails );
            String adminId = jsonPathEvaluator.getString( Constants.USERID );
            String adminOrgId = jsonPathEvaluator.getString( "affiliationInfo[0]." + Constants.ORGANIZATION_ID );

            List<String> assignmentIds = new ArrayList<>( Arrays.asList() );
            String payload = getBody( flexSchoolId, "reading", Arrays.asList( readingId ), targetDate, targetLevelArray );
//            String payload = getBody( "8a7201258288a1040182a74f6a0f0098", "math", Arrays.asList( "78683,219980,103505" ), targetDate, targetLevelArray );
            
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( distAdminUserName, password ) );
            headers.put( Constants.USERID_SM_HEADER, adminId );
            headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Getting api response

            Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );

            Log.message( "\n The respone is " + "\n" + response.getBody().asString() );

                        HashMap<String, List<String>> exp = getListOfValuesFromAPIOutput( response );
                        Log.message( "Moving to UI verification" );
                        HashMap<String, List<String>> act = getListOfValuesFromUIOutput( driver );
                        Log.message( "getListOfValuesFromAPIOutput:"+exp );
                        Log.message( "getListOfValuesFromUIOutput"+act);

            // Verification
                        SoftAssert softassert = new SoftAssert();
                        act.keySet().forEach( key -> {
                            softassert.assertEquals( act.get( key ), exp.get( key ), "The value is not Matched for " + key + "\nActual:" + act.get( key ) + "\nExpected:" + exp.get( key ) );
                        } );

                        softassert.assertAll();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    public String getBody( String orgId, String subject, List<String> assignmentIds, String targetDate,

            List<Float> targetLevelArray ) throws IOException {

        JSONObject variableBody = new JSONObject();

        JSONObject psrResponsBody = new JSONObject();
        //        JSONArray jsonarray = new JSONArray( teacherIdList );

        psrResponsBody.put( PSRConstants.SUBJECT, subject );
        psrResponsBody.put( PSRConstants.TARGET_DATE, targetDate );
        //        psrResponsBody.put( PSRConstants.ADDITIONAL_GROUPING, additionalGrouping );

        // course list
        JSONArray courseList = new JSONArray();
        assignmentIds.stream().forEach( value -> courseList.put( value ) );
        psrResponsBody.put( PSRConstants.COURSE_LIST, courseList );


        // target level list
        JSONArray targetLevel = new JSONArray();
        targetLevelArray.stream().forEach( value -> targetLevel.put( value ) );
        psrResponsBody.put( PSRConstants.TARGET_LEVEL_ARRAY, targetLevel );

        // filter by school list
        JSONArray orgJson = new JSONArray();
        new ArrayList<>( Arrays.asList( orgId ) ).stream().forEach( value -> orgJson.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_SCHOOL, orgJson );


        JSONObject demoJSON = new JSONObject();

        demoJSON.put( PSRConstants.DISABILLITY_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.ENGLISH_LANGUGAGE_PROFICIENCY, new JSONArray() );
        demoJSON.put( PSRConstants.GENDER, new JSONArray() );
        demoJSON.put( PSRConstants.RACE, new JSONArray() );
        demoJSON.put( PSRConstants.ETHINICITY, new JSONArray() );
        demoJSON.put( PSRConstants.SOCIO_ECONOMIC_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.MIGRANT_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.SPECIAL_SERVICES, new JSONArray() );

        psrResponsBody.put( PSRConstants.DEMOGRAPHICS_INPUT, demoJSON );
        variableBody.put( PSRConstants.PSA_REPORT_REQUEST, psrResponsBody );

        Log.message( "\nGraphQL Variable:\n" + variableBody.toString() );
        String requestBody = SMUtils.convertFileToString( new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator
                + "report" + File.separator + "PSARRequestBody.json" );
        String formatted = requestBody.format( requestBody, subject, courseList.toString(), targetDate, targetLevel.toString(), orgJson.toString() );
        Log.message( "PayLoad:\n" + formatted.toString() );
        return formatted;
    }
    
    public HashMap<String, List<String>> getListOfValuesFromUIOutput( WebDriver driver ) {
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();

        PrescriptiveSchedulingPage prescriptiveSchedulingPage = new PrescriptiveSchedulingPage( driver );
        boolean flag = true;
        while ( flag ) {

            // Data From UI
            String assignmentTitle = driver.findElement( By.tagName( "h3" ) ).getText().trim();
            String grade =prescriptiveSchedulingPage.getGrade();
           
            // Single Page row count
            int rowCount = driver.findElements( By.xpath( PrescriptiveSchedulingPage.rowCountXpath ) ).size();


            IntStream.rangeClosed( 1, rowCount ).forEach( rowIndex -> {
                List<String> arrayList = new LinkedList<String>();

                arrayList.clear();
                // Getting all the values from single row
                IntStream.rangeClosed( 1, 11 ).forEach( columnIndex -> {
                    String formatted = String.format( PrescriptiveSchedulingPage.studentData, rowIndex, columnIndex );

                    arrayList.add( driver.findElement( By.xpath( formatted ) ).getText().trim() );
                } );

                String assignmentStudentName = assignmentTitle + ":" + arrayList.get( 0 );
                arrayList.remove( 0 );

                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    Log.message( allStudentValuesList + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName+grade ) );
                    allStudentValuesList.put( assignmentStudentName+grade, arrayList );
                } else {
                    allStudentValuesList.put( assignmentStudentName+grade, arrayList );
                }
            } );

            // clicking next button
            flag = prescriptiveSchedulingPage.clickNextButtoninOuputPage();
            SMUtils.nap( 1.5 );
        }
        return allStudentValuesList;
    }
    
    public HashMap<String, List<String>> getListOfValuesFromAPIOutput( Response response ) {

        // Storing values
        HashMap<String, List<String>> allStudentValuesList = new LinkedHashMap<>();

        List<Object> assignments = response.then().extract().path( "data.getAdminPSAReportData.psaAssignments" );
        

        JSONArray assignmentList = new JSONArray( assignments );
        System.out.println( "Assignment Length: " + assignmentList.length() );

        int i = 0;
        // Iterating each Assignment Data
        for ( Object oneAssignment : assignmentList ) {

            JSONObject singleAssignment = new JSONObject( oneAssignment.toString() );
            String assignmentTitle = (String) singleAssignment.get( "assignmentTitle" );
            //testing
            String grade= singleAssignment.get( "grade" ).toString();

            JSONArray assignmentStudents = new JSONArray( singleAssignment.get( "teacherRows" ).toString() );
            int endRange=assignmentStudents.length();
            

                IntStream.range( 0, endRange ).forEach( index -> {

                List<String> singleStudentData = new LinkedList<>();
                
                String stuName = (String) assignmentStudents.query( "/" + index + "/teacherName" );

                String assignmentStudentName = assignmentTitle + ":" + stuName;
                
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPopulation/studentsIncluded" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPopulation/studentsNotIncluded" ) );

                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPerformanceData/currentCourseLevelMean" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPerformanceData/ipLevelMean" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPerformanceData/timeSinceIPMean" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPerformanceData/percentStudentsWithAP" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPerformanceData/percentStudentsAtTargetLevel" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaCurrentForecast/projectedEndLevelMean" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaCurrentForecast/percentStudentsToAchieveTargetLevel" ) );
                singleStudentData.add( (String) assignmentStudents.query( "/" + index + "/psaPrescription/averageAddlMinDayToTarget" ) );
                
                
                if ( allStudentValuesList.containsKey( assignmentStudentName ) ) {
                    allStudentValuesList.put( assignmentStudentName+grade, singleStudentData );
                   
                } else {
                    allStudentValuesList.put( assignmentStudentName+grade, singleStudentData );
                }
                System.out.println( assignmentStudentName + "<:Key is already present" + "value is:" + allStudentValuesList.get( assignmentStudentName+grade ) );
            } );

        }
        return allStudentValuesList;
    }

}
