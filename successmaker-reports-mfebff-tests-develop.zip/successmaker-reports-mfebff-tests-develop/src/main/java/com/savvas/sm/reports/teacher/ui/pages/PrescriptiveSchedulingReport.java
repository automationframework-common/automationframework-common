package com.savvas.sm.reports.teacher.ui.pages;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.report.bff.teacher.tests.PSRTeacherGraphQLTest;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.PSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.PSUIConstants;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsBrowserActions;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;
import io.restassured.response.Response;

public class PrescriptiveSchedulingReport extends LoadableComponent<PrescriptiveSchedulingReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    Random random = new Random();
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Prescriptive Scheduling Report']", AI = false )
    public WebElement txtPrescriptiveSchedulingReportHeader;

    @IFindBy ( how = How.CSS, using = "input#gradek", AI = false )
    public WebElement fldGradeK;

    @IFindBy ( how = How.CSS, using = "input#grade1", AI = false )
    public WebElement fldGrade1;

    @IFindBy ( how = How.CSS, using = "input#grade2", AI = false )
    public WebElement fldGrade2;

    @IFindBy ( how = How.CSS, using = "input#grade3", AI = false )
    public WebElement fldGrade3;

    @IFindBy ( how = How.CSS, using = "input#grade4", AI = false )
    public WebElement fldGrade4;

    @IFindBy ( how = How.CSS, using = "input#grade5", AI = false )
    public WebElement fldGrade5;

    @IFindBy ( how = How.CSS, using = "input#grade6", AI = false )
    public WebElement fldGrade6;

    @IFindBy ( how = How.CSS, using = "input#grade7", AI = false )
    public WebElement fldGrade7;

    @IFindBy ( how = How.CSS, using = "input#grade8", AI = false )
    public WebElement fldGrade8;

    @IFindBy ( how = How.CSS, using = "input#grade9", AI = false )
    public WebElement fldGrade9;

    @IFindBy ( how = How.CSS, using = "input#grade10", AI = false )
    public WebElement fldGrade10;

    @IFindBy ( how = How.CSS, using = "input#grade11", AI = false )
    public WebElement fldGrade11;

    @IFindBy ( how = How.CSS, using = "input#grade12", AI = false )
    public WebElement fldGrade12;

    @IFindBy ( how = How.XPATH, using = "//label[text()=' SET TARGET DATE ']", AI = false )
    public WebElement txtSetTargetDate;

    @IFindBy ( how = How.CSS, using = "div.col.date-container", AI = false )
    public WebElement eleDateContainer;

    @IFindBy ( how = How.XPATH, using = "//*[text()=' SET TARGET LEVEL PER GRADE ']", AI = false )
    public WebElement txtSetTargetLevelPerGrade;

    @IFindBy ( how = How.CSS, using = "cel-date-input[value='reportService.reportForm.value.targetDate']", AI = false )
    public WebElement targetDateRoot;

    @IFindBy ( how = How.CSS, using = "cel-date-input", AI = false )
    public WebElement childInpdate;

    @IFindBy ( how = How.XPATH, using = "//cel-button[@data-icon-type='right'] ", AI = false )
    public WebElement rightNextButton;

    @IFindBy ( how = How.XPATH, using = "//cel-button[@data-icon-type='left'] ", AI = false )
    public WebElement leftBackButton;

    @IFindBy ( how = How.CSS, using = "table.areas-for-growth", AI = false )
    public WebElement reportTable;

    @IFindBy ( how = How.CSS, using = "h2.header", AI = false )
    public WebElement reportHeader;

    @FindBy ( css = "report-grid tbody td:nth-child(1)" )
    public List<WebElement> outputStudentName;

    @FindBy ( css = "report-grid tbody td:nth-child(2)" )
    public List<WebElement> outputCurentCourseLevel;

    @FindBy ( css = "report-grid tbody td:nth-child(3)" )
    public List<WebElement> outputIpLevel;

    @FindBy ( css = "report-grid tbody td:nth-child(4)" )
    public List<WebElement> outputTimeSinceIp;

    @FindBy ( css = "report-grid tbody td:nth-child(5)" )
    public List<WebElement> outputPercentSkillsMastered;

    @FindBy ( css = "report-grid tbody td:nth-child(6)" )
    public List<WebElement> outputSessionLength;

    @FindBy ( css = "report-grid tbody td:nth-child(7)" )
    public List<WebElement> outputAverageMinPerDay;

    @FindBy ( css = "report-grid tbody td:nth-child(8)" )
    public List<WebElement> outputCurrentLearningRate;

    @FindBy ( css = "report-grid tbody td:nth-child(9)" )
    public List<WebElement> outputProjectedAdditionalTimeToEndDate;

    @FindBy ( css = "report-grid tbody td:nth-child(10)" )
    public List<WebElement> outputProjectedEndLevel;

    @FindBy ( css = "report-grid tbody td:nth-child(11)" )
    public List<WebElement> outputAdditionalSessionsToReachTarget;

    @FindBy ( css = "report-grid tbody td:nth-child(12)" )
    public List<WebElement> outputAdditionalTimeToReachTarget;

    @FindBy ( css = "report-grid tbody td:nth-child(13)" )
    public List<WebElement> outputAdditionalMinutesPerDayToReachTarget;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String calDateInput[] = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('input#cel-date-input-1')" };
    public String iconDatePicker[] = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('div > cel-icon-button').shadowRoot.querySelector('button > cel-icon')" };
    String inpDateOpt = ".date-input";
    public String drpDwnAdditionalGroupingshadowDOM[] = { "cel-single-select", "document.querySelector('#additional-grouping').shadowRoot.querySelector('#dropdown')" };
    public String elePrescriptiveSchedulingAggregateReportshadowDOM[] = { "cel-tab-panel", "document.querySelector('cel-tab-panel').shadowRoot.querySelector('#\\\\31')" };

    public String btnPrescriptiveSchedulingAggregate[] = { "cel-tab-panel", "document.querySelector('cel-tab-panel').shadowRoot.querySelector('button[id = \"1\"]')" };
    public String[] targetDateElement = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('#cel-date-input-1');" };
    public String[] btnCalendarIcon = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('cel-icon-button').shadowRoot.querySelector('button')" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };
    public String highlightedDate[] = { "cel-date-input", "document.querySelector('.cel-calendar-component').shadowRoot.querySelector('table tbody td.today')" };
    List<String> expectedGrades = new ArrayList<String>( Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12" ) );
    public List<String> listPSRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Performance Data", "Current Rate", "Current Forecast", "Prescription", "", "Current Course Level", "IP Level", "Time Since IP", "Skills Percent Mastered",
            "Session Length Setting", "Average Min/Day", "Current Learning Rate", "Time", "Level", "Add'l Sessions to Target", "Add'l Time to Target", "Add'l Min/Day to Target" ) );
    public static List<String> GradeLevels = Arrays.asList( "k", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" );
    /* String used for List of Elements inside Methods */

    public String grades = "//label[contains(text(),' Grade ')]";
    public String targetDate = " SET TARGET DATE ";
    public String targetLevelPerGrade = " SET TARGET LEVEL PER GRADE ";

    public String txtAdditionalGroupingDrpdwn = "grade";
    public String txtPrescriptiveSchedulingAggregate = "Prescriptive Scheduling Aggregate";
    public String childHighDate = ".cel-calendar-component";
    public String gChildHighDate = "table tbody td.today";
    String gradeTarget = "document.querySelector('#grade%s').value";
    private static String gradeIncrementor = "#grade%s%sncrementor > cel-icon";
    private static String gradeDecrementor = "#grade%s%secrement%sr > cel-icon";
    public static String studentData = "//tbody//child::tr[%s]//td[%s]";
    public static String rowCountXpath = "//tbody//child::tr";
    public ReportFilterComponent reportFilterComponent;

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtPrescriptiveSchedulingReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public PrescriptiveSchedulingReport() {}

    public PrescriptiveSchedulingReport( WebDriver driver ) {
        this.driver = driver;
        reportFilterComponent = new ReportFilterComponent( driver );
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas Validate Calendar Date Input Field
     * @throws InterruptedException
     */
    public void validateCalendarDateInputField( WebDriver driver ) throws InterruptedException {
        WebElement calDateInput = ShadowDOMUtils.retryAndGetWebElement( driver, this.calDateInput[0], this.calDateInput[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, calDateInput, "Calendar Date Input" );
    }

    /**
     * @author aravindan.srinivas Validate Icon Date Picker
     * @throws InterruptedException
     */
    public void validateIconDatePicker( WebDriver driver ) throws InterruptedException {
        WebElement iconDatePicker = ShadowDOMUtils.retryAndGetWebElement( driver, this.iconDatePicker[0], this.iconDatePicker[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, iconDatePicker, "Icon Date Picker" );
    }

    /**
     * @author aravindan.srinivas verify the text Set Target Date is Displayed
     *         in the web page.
     * @param driver
     */
    public void verifyTextSetTargetDate( WebDriver driver ) {
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSetTargetDate, targetDate, "Set Target Date" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSetTargetDate, "Set Target Date Element" );
    }

    /**
     * @author aravindan.srinivas verify the Set Target Level PerGrade is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSetTargetLevelPerGrade( WebDriver driver ) {
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSetTargetLevelPerGrade, targetLevelPerGrade, "Set Target Level PerGrade" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSetTargetLevelPerGrade, "Set Target Level PerGrade Element" );
    }

    /**
     * @author aravindan.srinivas verify the Date Container is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyDateContainer( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, eleDateContainer, "Date Container Element" );
    }

    /**
     * @author aravindan.srinivas Validate Grade from K to 12
     */
    public void validateGrades( WebDriver driver ) {
        List<WebElement> elements = driver.findElements( By.xpath( grades ) );

        List<String> actualGrades = new ArrayList<String>();
        for ( WebElement ele : elements ) {
            actualGrades.add( ele.getText().trim() );
        }
        Log.assertThat( actualGrades.equals( expectedGrades ), "Grades Matched", "Grades MisMatched!!" );

    }

    /**
     * @author aravindan.srinivas verify the Elements Grade is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyElementGrades( WebDriver driver ) {

        List<WebElement> gradeElement = driver.findElements( By.cssSelector( "input[id*='grade']" ) );

        for ( int i = 0; i < gradeElement.size(); i++ ) {
            String attributeID = gradeElement.get( i ).getAttribute( "id" );
            ReportsBrowserActions.verifyElementIsDisplayed( driver, gradeElement.get( i ), attributeID );
        }
        Log.assertThat( gradeElement.size() == 13, "Grades Count :" + gradeElement.size() + "Is Matched", "Grades Count :" + gradeElement.size() + "Is MisMatched" );
    }

    /**
     * @author aravindan.srinivas validate Additional Grouping drop down Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAdditionalGroupingDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnAdditionalGroupingshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnAdditionalGroupingshadowDOM[0], this.drpDwnAdditionalGroupingshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnAdditionalGroupingshadowDOM, "Additional Grouping Drop Down Field" );
        String attributeValue = drpDwnAdditionalGroupingshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equalsIgnoreCase( txtAdditionalGroupingDrpdwn ), "Selected '" + attributeValue + "' as default value in Additional Grouping Drpdwn Field",
                "'" + attributeValue + "' is not a default value in Additional Grouping Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas Validate all the fields and headers present in
     *         the Perspective Scheduling Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInPrescriptiveSchedulingReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        //        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtPrescriptiveSchedulingReportHeader.getText();
        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        // groups & Students - text
        // groups text & drop down
        // students text and drop down 
        reportsFilterUtils.verifyTextGroupsAndStudents( driver );
        reportsFilterUtils.verifyTextGroupsHeader( driver );
        reportsFilterUtils.validateGroupsDrpdwnField( driver );

        reportsFilterUtils.verifyTextStudentsHeader( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        //Assignment text & drop down
        reportsFilterUtils.verifyTextAssignmentsHeader( driver );
        reportsFilterUtils.validateAssignmentsDrpdwnField( driver );

        verifyTextSetTargetDate( driver );
        verifyDateContainer( driver );
        validateCalendarDateInputField( driver );
        validateIconDatePicker( driver );
        verifyTextSetTargetLevelPerGrade( driver );
        // validateGrades( driver );
        // verifyElementGrades( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );

        // Option Filter
        //        SMUtils.click( driver, txtOptionalFilter );
        //        SMUtils.click( driver, txtOptionalFilter );

        reportsFilterUtils.verifyTextAdditionalGrouping( driver );
        validateAdditionalGroupingDrpdwnField( driver );

        reportsFilterUtils.verifyTextDisplay( driver );
        reportsFilterUtils.validateDisplayDrpdwnField( driver );

        reportsFilterUtils.validateMaskCheckBoxField( driver );

        reportsFilterUtils.verifyTextSortInAdditionalGrouping( driver );
        reportsFilterUtils.validateSortDrpdwnField( driver, currentReportName );
    }

    /**
     * This method is dynamically working to select the grade in Prescriptive
     * Scheduling page by giving the inputs of grade and value
     * 
     * @author raseem.mohamed
     * @param driver
     * @param gradeToSelect
     * @param value
     *
     */
    public void enterGrade( WebDriver driver, String gradeToEnter, String gradeValueToEnter ) {
        String gradeValue = null;
        try {
            float rawValue2 = Float.valueOf( gradeValueToEnter ).floatValue();
            gradeValue = String.valueOf( rawValue2 );
            WebElement grades = driver.findElement( By.xpath( "//input[@id='grade" + gradeToEnter + "']" ) );
            // Click on the respective grade and clear the field before entering the value
            Actions action = new Actions( driver );
            action.moveToElement( grades ).doubleClick().click().sendKeys( Keys.BACK_SPACE ).perform();
            action.moveToElement( grades ).click().sendKeys( gradeValue ).perform();
            Log.message( "'" + gradeValue + "'Value Entered Successfully On Grade " + gradeToEnter );
        } catch ( Exception e ) {
            Log.message( "Failed : '" + gradeValue + "'Value Not Entered Successfully On Grade " + gradeToEnter );
            e.printStackTrace();
        }

    }

    /**
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public void SelectGradeAndEnterTheGrade( WebDriver driver ) throws InterruptedException {
        enterGrade( driver, ReportsUIConstants.GRADE_K, "2" );
    }

    /**
     * @author raseem.mohamed Description - This method used to verify that user
     *         once apply saved reports option we verifying the same value is
     *         retained in saved report drop down or not
     */
    public void validatePSRSavedReports( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Thread.sleep( 2000 );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Prescriptive Scheduling Report" ), "User Landed On Prescriptive Scheduling", "User Not Landed On Prescriptive Scheduling" );
        List<String> expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds() );
        List<String> groups = new ArrayList<String>( Arrays.asList( expgroupNames.get( 0 ) ) );
        //        reportsFilterUtils.selectGroupsDropdwn( driver, groups );
        reportFilterComponent.selectOptionsFromMultiSelectGroupDropdown( "Groups", groups );
        //Handle Date
        selectTargetDateAsCurrentDate();
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        String savedReportName = "Automation Teacher SavedReport " + random.nextInt(); // Generating Random Name For Saved
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author sathish.suresh
     * @param driver
     * @param futureDateCount
     * @throws InterruptedException
     */
    public void selectTargetDate( WebDriver driver, int futureDateCount ) throws InterruptedException {
        SMUtils.nap( 3 );
        SMUtils.waitForElement( driver, targetDateRoot );

        WebElement childDate = SMUtils.getWebElement( driver, targetDateRoot, inpDateOpt );
        SMUtils.click( driver, childDate );
        SMUtils.nap( 3 );
        WebElement childDate1 = SMUtils.getWebElement( driver, targetDateRoot, childHighDate );
        WebElement actualDate = SMUtils.getWebElement( driver, childDate1, gChildHighDate );

        actualDate.click();
        Log.message( "Date Selected" );
    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public PrescriptiveSchedulingReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtPrescriptiveSchedulingReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to expand optional filters
     * 
     * @param driver
     * @return
     */
    public PrescriptiveSchedulingReport clickOptionalFilters( WebDriver driver ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtPrescriptiveSchedulingReportHeader );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        SMUtils.click( driver, txtOptionalFilter );
        return this;

    }

    /**
     * @author sathish.suresh Validate Teacher AFG run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validatePSRTeacherRunReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        reportsFilterUtils.selectStudentRadioBtn( driver );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        PrescriptiveSchedulingReport perspectiveSchedulingReport = new PrescriptiveSchedulingReport( driver );
        perspectiveSchedulingReport.selectTargetDate( driver, 3 );
        perspectiveSchedulingReport.SelectGradeAndEnterTheGrade( driver );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sakthi.sasi Used to verify the Groups in UI matches the Group
     *         fetched from RBS
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public PrescriptiveSchedulingReport verifyGroup( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds() );
        List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getTeacherGroupNames();
        Collections.sort( expgroupNames );
        Collections.sort( allValuesFromGroupsDropdown );
        Log.softAssertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the assignments
     * @param driver
     * @param username
     * @param smUrl
     * @param teacherDetails
     * @param assignmentType
     * @return
     * @throws Exception
     */
    public PrescriptiveSchedulingReport verifyAssignments( WebDriver driver, String username, String smUrl, String teacherDetails, String assignmentType ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> assignmentsFromUI = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.ASSIGNMENTS );
        List<String> assignmentList = reportsFilterUtils.getAssignmentDetails( smUrl, username, teacherDetails, assignmentType );
        Log.softAssertThat( assignmentList.containsAll( assignmentsFromUI ), "All assignments displayed properly in the assignment dropdown!", "Assignments not displayed properly in thes assignment dropdown" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the students
     * @param driver
     * @param schoolName
     * @param username
     * @return
     * @throws Exception
     */
    public PrescriptiveSchedulingReport verifyStudents( WebDriver driver, String schoolName, String username ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        reportsFilterUtils.selectStudentRadioBtn( driver );
        // get WebElements of dropdown option checkboxes
        List<String> allStudentsFromUI = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.Teacher_Students );
        List<String> studentNames = reportsFilterUtils.getStudentsList( username, schoolName );
        Log.softAssertThat( studentNames.contains( allStudentsFromUI ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );
        return this;
    }

    public void selectTargetDateField( WebDriver driver, int futureDateCount ) throws InterruptedException {
        SMUtils.nap( 3 );
        SMUtils.waitForElement( driver, targetDateRoot );
        WebElement inpDate = ShadowDOMUtils.retryAndGetWebElement( driver, targetDateElement[0], targetDateElement[1] );
        SMUtils.scrollDownIntoViewElement( driver, inpDate );
        Calendar calendar = Calendar.getInstance();
        calendar.add( Calendar.DATE, futureDateCount );
        Date futureDate = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy" );
        String formattedDate = sdf.format( futureDate );
        inpDate.clear();
        inpDate.sendKeys( formattedDate );
        inpDate.click();
        Log.message( "Date Selected" );
    }

    public boolean selectTargetDateAsCurrentDate() {
        boolean flag = false;
        try {
            SMUtils.nap( 10 );
            SMUtils.waitForElement( driver, targetDateRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, targetDateRoot, "#cel-date-input-1" ) );
            SMUtils.waitForElement( driver, targetDateRoot );
            WebElement cal = SMUtils.getWebElement( driver, targetDateRoot, ".cel-calendar-component.hydrated" );
            SMUtils.waitForElement( driver, cal );
            WebElement currentDate = SMUtils.getWebElement( driver, cal, ".day-circle.today" );
            SMUtils.nap( 10 );
            SMUtils.clickJS( driver, currentDate );
            //date.sendKeys( dateStr );
            Log.message( "Date Selected" );
            flag = true;
        } catch ( Exception e ) {
            Log.message( "User is unable to select the current date" );
        }
        return flag;
    }

    /**
     * Set Target Level for the Grde
     * 
     * @param Grade
     * @param value
     */
    public void setTargetLevelForGrade( String Grade, double value ) {
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript( gradeTarget.format( gradeTarget, Grade ) + "='" + String.valueOf( new DecimalFormat( "#.00" ).format( value ) ) + "';" );
    }

    /**
     * Click Incrementor For Grade
     * 
     * @param GradelLevel
     */
    public void clickIncrementGrade( String GradelLevel ) {
        String formated;
        if ( GradelLevel.equalsIgnoreCase( "k" ) ) {
            formated = gradeIncrementor.format( gradeIncrementor, GradelLevel, "I" );
        } else {
            formated = gradeIncrementor.format( gradeIncrementor, GradelLevel, "i" );
        }

        WebElement parent = driver.findElement( By.cssSelector( formated ) );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, parent, "div" ) );
        Log.message( "Clikced Incrementor for Grade: " + GradelLevel );

    }

    /**
     * Click Decrement for Grade Level
     * 
     * @param GradelLevel
     */
    public void clickDecrementGrade( String GradelLevel ) {
        String formated;
        if ( GradelLevel.equalsIgnoreCase( "k" ) ) {
            formated = gradeIncrementor.format( gradeDecrementor, GradelLevel, "D", "e" );
        } else {
            formated = gradeIncrementor.format( gradeDecrementor, GradelLevel, "d", "o" );
        }

        WebElement parent = driver.findElement( By.cssSelector( formated ) );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, parent, "div" ) );
        Log.message( "Clikced Decrementor for Grade: " + GradelLevel );

    }

    /**
     * click Next Button in in Output Page
     * 
     * @return
     */
    public boolean clickNextButtoninOuputPage() {
        WebElement button = SMUtils.getWebElementDirect( driver, rightNextButton, "button" );
        if ( button.getAttribute( "aria-disabled" ).equals( "false" ) ) {
            SMUtils.clickJS( driver, button );
            return true;
        } else {
            Log.message( "Last Page is reached" );
            return false;
        }
    }

    public List<String> getOutputStudentNames( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputStudentName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputCurentCourseLevel( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputCurentCourseLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputIpLevel( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputIpLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputTimeSinceIp( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTimeSinceIp.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputPercentSkillsMastered( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputPercentSkillsMastered.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputSessionLength( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputSessionLength.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputAverageMinPerDay( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputAverageMinPerDay.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputCurrentLearningRate( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputCurrentLearningRate.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputProjectedAdditionalTimeToEndDate( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputProjectedAdditionalTimeToEndDate.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputProjectedEndLevel( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputProjectedEndLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputAdditionalSessionsToReachTarget( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputAdditionalSessionsToReachTarget.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputAdditionalTimeToReachTarget( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputAdditionalTimeToReachTarget.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputAdditionalMinutesPerDayToReachTarget( WebDriver driver ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputAdditionalMinutesPerDayToReachTarget.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public HashMap<String, HashMap<String, String>> getValuesFromUI( WebDriver driver ) throws InterruptedException {
        HashMap<String, HashMap<String, String>> psrDetails = new HashMap<>();
        SMUtils.waitForSpinnertoDisapper( driver, 5 );
        Log.message( "Getting Data From output.." );

        List<String> studentNames = getOutputStudentNames( driver );
        List<String> currentCourseLevel = getoutputCurentCourseLevel( driver );
        List<String> ipLevel = getoutputIpLevel( driver );
        List<String> timeSinceIp = getoutputTimeSinceIp( driver );
        List<String> percentSkillsMastered = getoutputPercentSkillsMastered( driver );
        List<String> sessionLength = getoutputSessionLength( driver );
        List<String> averageMinPerDay = getoutputAverageMinPerDay( driver );
        List<String> currentLearningRate = getoutputCurrentLearningRate( driver );
        List<String> projectedAdditionalTimeToEndDate = getoutputProjectedAdditionalTimeToEndDate( driver );
        List<String> projectedEndLevel = getoutputProjectedEndLevel( driver );
        List<String> additionalSessionsToReachTarget = getoutputAdditionalSessionsToReachTarget( driver );
        List<String> additionalTimeToReachTarget = getoutputAdditionalTimeToReachTarget( driver );
        List<String> additionalMinutesPerDayToReachTarget = getoutputAdditionalMinutesPerDayToReachTarget( driver );
        List<String> finalStudentNames = new ArrayList();

        for ( String name : studentNames ) {
            String[] names = name.split( " " );
            String finalName = names[0] + " " + names[names.length - 1];
            finalStudentNames.add( finalName );

        }
        IntStream.range( 0, currentCourseLevel.size() ).forEach( itr -> {

            HashMap<String, String> values = new HashMap<>();

            values.put( "ipmLevel", ipLevel.get( itr ).toString() );
            values.put( "currentCourseLevel", currentCourseLevel.get( itr ).toString() );
            values.put( "timeSinceIp", timeSinceIp.get( itr ).toString() );
            values.put( "percentSkillsMastered", percentSkillsMastered.get( itr ).toString() );
            values.put( "sessionLength", sessionLength.get( itr ).toString() );
            values.put( "averageMinPerDay", averageMinPerDay.get( itr ).toString() );
            values.put( "currentLearningRate", currentLearningRate.get( itr ).toString() );
            values.put( "projectedAdditionalTimeToEndDate", projectedAdditionalTimeToEndDate.get( itr ).toString() );
            values.put( "projectedEndLevel", projectedEndLevel.get( itr ).toString() );
            values.put( "additionalSessionsToReachTarget", additionalSessionsToReachTarget.get( itr ).toString() );
            values.put( "additionalTimeToReachTarget", additionalTimeToReachTarget.get( itr ).toString() );
            values.put( "additionalMinutesPerDayToReachTarget", additionalMinutesPerDayToReachTarget.get( itr ).toString() );
            psrDetails.put( finalStudentNames.get( itr ), values );
        } );
        Log.message( "Final UI Details: " + psrDetails );
        return psrDetails;
    }

    public HashMap<String, HashMap<String, String>> getDataFromBFF( String username, String password, String orgId, String teacherId, String subject ) throws IOException {
        PSRTeacherGraphQLTest PSRTeacher = new PSRTeacherGraphQLTest();
        HashMap<String, String> headers = new HashMap<>();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();
        Date date = new Date();
        String targetDate = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );

        String payload = PSRTeacher.getPayloadAllScenario();
        queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
        queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
        queryItem.put( ReportAPIConstants.TARGET_DATE, "\\\"" + targetDate + "\\\"" );
        if ( subject.equalsIgnoreCase( "math" ) ) {
            queryItem.put( ReportAPIConstants.SUBJECT, "1" );
        } else {
            queryItem.put( ReportAPIConstants.SUBJECT, "2" );
        }

        String query = PSRTeacher.constructQueryItems( queryItem );
        payload = payload.replace( ReportAPIConstants.PS_QUERY, query );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
        String responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
        HashMap<String, HashMap<String, String>> dataFromBFF = PSRTeacher.getDataFromResponse( response.asString() );
        Log.message( "Data from BFF :" + dataFromBFF );
        return dataFromBFF;

    }

}
