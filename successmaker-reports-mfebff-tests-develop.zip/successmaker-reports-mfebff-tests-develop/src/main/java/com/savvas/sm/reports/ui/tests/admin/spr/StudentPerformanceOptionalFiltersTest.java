package com.savvas.sm.reports.ui.tests.admin.spr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class StudentPerformanceOptionalFiltersTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    LeftNavigationBar dashBoardPage;
    AdminLauncherPage smLoginPage;
    RecentSessionsPage studentPerformancePage;
    private List<String> orgIds;
    private List<String> orgNames;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify all field available under Optional Filters field.", groups = { "Smoke", "SMK-58855", "StudentPerformanceReport", "OptionalFilters" }, priority = 1 )
    public void tcSMStudentPerformanceOptionalFilter001() throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentPerformanceOptionalFilter001: Verify all field available under Optional Filters field. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Student Perfomance Report page" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.isOptionalFilterDisplayingForStudentPerformance(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "Verify Optional Fiters should expandble and collapse field" );
            studentPerformancePage.clickOptionalFilter();
            SMUtils.logDescriptionTC( "Verify 'SELECT STUDENTS BY' text under Optional Filters " );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying", "Select student by is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Teacher Dropdown should display under Recent Session Report" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.TEACHER_LABEL ), "Teacher label is displaying", "Teacher label is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Grade Dropdown should display under Recent Session Report" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GRADE_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Group Dropdown should display under Recent Session Report" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Display Dropdown should display under Recent Session Report" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Display header is displaying", "Display header is not displaying" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDefaultItemsForOptionalReport( ReportsUIConstants.DISPLAY_LABEL ).equalsIgnoreCase( ReportsUIConstants.DEFAULT_DISPLAY ), "Default option displayed correctly",
                    "Default option not displayed correctly" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Mask Student Dispaly should be display ." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getMaskStudentDisplaylbl().equals( ReportsUIConstants.MASK_STUDENT_DISPLAY ), "Mask Student is displaying", "Mask Student is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Include Performance Summary should be display ." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying", "Mask Student is not displaying" );
            studentPerformancePage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );
            studentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Include Performance By Strand should be display ." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying", "Mask Student is not displaying" );
            studentPerformancePage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );
            studentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Include Areas of Growth should be display ." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying", "Mask Student is not displaying" );
            studentPerformancePage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );
            studentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Date At Risk should be display ." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DATE_AT_RISK ), "Date at Risk is displaying", "Mask Student is not displaying" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDefaultItemsForOptionalReport( ReportsUIConstants.DATE_AT_RISK ).equalsIgnoreCase( ReportsUIConstants.DEFAULT_DATE_AT_RISK ), "Default option displayed correctly",
                    "Default option not displayed correctly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Language should be display ." );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.LANGUAGE ), "Language is displaying", "Mask Student is not displaying" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDefaultItemsForOptionalReport( ReportsUIConstants.LANGUAGE ).equalsIgnoreCase( ReportsUIConstants.DEFAULT_LANGUAGE ), "Default option displayed correctly",
                    "Default option not displayed correctly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify ALL Checkbox should be dislayed for Teacher dropdown" );
            SMUtils.logDescriptionTC( "Verify SearchBar should be display under Teacher dropdown" );
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.assertThat( studentPerformancePage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.TEACHER_LABEL ), "Search Bar is displaying for Teacher", "Search Bar is not displaying for teacher" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Teacher dropdown",
                    "All is not displaying for Teacher dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify ALL Checkbox should be dislayed for Grade dropdown" );
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Grade dropdown",
                    "All is not displaying for Grade dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify ALL Checkbox should be dislayed for Group dropdown" );
            SMUtils.logDescriptionTC( "Verify SearchBar should be display under Group dropdown" );
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Log.assertThat( studentPerformancePage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.GROUP_LABEL ), "Search Bar is displaying for Group", "Search Bar is not displaying for Group" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Group dropdown",
                    "All is not displaying for Group dropdown" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all option available for Display dropdown", groups = { "SMK-58855", "StudentPerformanceReport", "OptionalFilters" }, priority = 1 )
    public void tcSMStudentPerformanceOptionalFilter002() throws Exception {
        // Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentPerformanceOptionalFilter002:Verify all field available under addition grouping and Display dropdown<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.logDescriptionTC( "Verify all field available under Display dropdown" );
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdownForStudentPerformance( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the Display option are displaying",
                    "Display option are not displaying" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify all field available under Language dropdown" );
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdownForStudentPerformance( ReportsUIConstants.LANGUAGE );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE ).containsAll( ReportsUIConstants.LANGUAGE_OPTIONS ), "All the Language option are displaying",
                    "Language option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify all field available under Date At Risk dropdown" );
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdownForStudentPerformance( ReportsUIConstants.DATE_AT_RISK );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ).containsAll( ReportsUIConstants.DATE_AT_RISK_OPTIONS ), "All the Date at Risk option are displaying",
                    "Date at Risk option are not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify zero state message when no option slected for multi selet dropdown ", groups = { "SMK-58855", "StudentPerformanceReport", "OptionalFilters" }, priority = 1 )
    public void tcSMStudentPerformanceOptionalFilter003() throws Exception {
        // Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentPerformanceOptionalFilter004: Verify message when no option slected for multi selet dropdown <small><b><i>[" + browser + "]</b></i></small>" );
        SMUtils.logDescriptionTC( "Verify the Optional fields is displayed for School admin" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.logDescriptionTC( "Verify message when no teacher has selected under Teacher dropdown" );
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_TEACHER ), "Zero state is displaying for teacher",
                    "Zero state is not displaying for teacher" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when no grade has selected under Grade dropdown" );
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_GRADES ), "Zero state is displaying for Grades",
                    "Zero state is not displaying for Grades" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when no group has selected under Group dropdown" );
            studentPerformancePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.ZERO_STATE_GROUPS ), "Zero state is displaying for Groups",
                    "Zero state is not displaying for Groups" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify when single option selected for multi select dropdown", groups = { "SMK-58855", "StudentPerformanceReport", "OptionalFilters" }, priority = 1 )
    public void tcSMStudentPerformanceOptionalFilter004() throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentPerformanceOptionalFilter005:Verify when single option selected for multi select dropdown <small><b><i>[" + browser + "]</b></i></small>" );
        SMUtils.logDescriptionTC( "Verify the Optional fields is displayed for Sub-district admin" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            orgIds = studentPerformancePage.getOrganizationIds();
            orgNames = studentPerformancePage.getOrganizationNames();
            studentPerformancePage.setOrganizationsValue( orgNames.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify message when one teacher has selected under Teacher dropdown" );
            studentPerformancePage.clickOptionalFilter();

            List<String> value = studentPerformancePage.getTeacherUserNames();
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.TEACHERS, Arrays.asList( value.get( 1 ) ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.TEACHERS ).get( 0 ).equalsIgnoreCase( value.get( 1 ) ), "Selected Teacher is displaying", "Selected Teacher is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when one grade has selected under Grade dropdown" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GRADES, Arrays.asList( ReportsUIConstants.GRADE_OPTION ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GRADES ).equals( Arrays.asList( ReportsUIConstants.GRADE_OPTION ) ), "Selected Grade is displaying", "Selected Grade is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when one group has selected under Group dropdown" );
            List<String> groupNames = studentPerformancePage.getGroupNames();
            String groupName = groupNames.get( 4 );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GROUPS, Arrays.asList( groupName ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GROUPS ).containsAll( new ArrayList<String>( Arrays.asList( ( groupName ) ) ) ), "Selected Group is displaying", "Selected Group is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify when multiple option selected for multi select dropdown", groups = { "SMK-58855", "StudentPerformanceReport", "OptionalFilters" }, priority = 1 )
    public void tcSMStudentPerformanceOptionalFilter005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentPerformanceOptionalFilter006: Verify when multiple option selected for multi select dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            orgIds = studentPerformancePage.getOrganizationIds();
            orgNames = studentPerformancePage.getOrganizationNames();
            studentPerformancePage.setOrganizationsValue( orgNames.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify message when multilple teacher has selected under Teacher dropdown" );
            studentPerformancePage.clickOptionalFilter();

            List<String> actualTeacherNames = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.TEACHERS );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.TEACHERS, actualTeacherNames.subList( 0, 2 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.TEACHERS ).equals( actualTeacherNames.subList( 0, 2 ) ), "Multiple teacher has selected", "Selected Teacher is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when multiple group has selected under Teacher dropdown" );

            List<String> groupNames = studentPerformancePage.getGroupNames();
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GROUPS, groupNames.subList( 0, 2 ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GROUPS ).containsAll( groupNames.subList( 0, 2 ) ), "Selected Group is displaying", "Selected Group is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify message when multiple  has selected under Teacher dropdown" );
            List<String> grades = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.GRADES );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GRADES, grades.subList( 0, 2 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GRADES ).equals( grades.subList( 0, 2 ) ), "The Grade Values is matched", "The Grade Values is not matched" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
