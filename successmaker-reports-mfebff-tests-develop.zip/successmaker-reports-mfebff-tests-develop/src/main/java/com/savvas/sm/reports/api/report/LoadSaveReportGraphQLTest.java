package com.savvas.sm.reports.api.report;

import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class LoadSaveReportGraphQLTest extends UserAPI {



    @Test ( dataProvider = "getDataforSaveReport", groups = { "SMK-57301", "GraphQL API to load/save report options", "API" }, priority = 1 )
    public void testSaveReportAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType, String reportType, String filterName, String userType,String reportParameters ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        String payload = getPayload();
        String query ;
        Response response = null;

        switch ( scenarioType ) {
            case "VALID_DATA":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "PEARSON_TRUE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "PEARSON_TRUE_WITHOUT_FILTER_NAME":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response="+response.getBody().asString() );
                break;
            case "INVALID_AUTHORIZATION":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.INVALID, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_REQUEST":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.LIMIT, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_PEARSON":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, reportType);
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_ORG_IT":
                queryItem.put( ReportAPIConstants.ORG_ID, "" );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_USER_IT":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, "");
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_REPORT_TYPE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, "");
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_PEARSON":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, "");
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_FILTER_NAME":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, "" );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_USER_TYPE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, "" );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_REPORT_PARAMETERS":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, "" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "LS_REPORT":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "CP_REPORT":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "ISP_REPORT":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "MASTERY_REPORT":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID);
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType);
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString());
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.USER_TYPE, userType );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        String responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : "No Response Code";
        // Validation

        if(statusCode.equalsIgnoreCase("200"))
        {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        }
        else if (response.getBody().asString().contains( statusCode ))
        {
            Log.assertThat( response.getBody().asString().contains( statusCode ), "The Status code is expected " + statusCode + " and actual " + statusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " is not Verified" );
        }
        else
        {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        }

        //Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataforSaveReport() {
        return new Object[][]{
                {"TC001", "200", "Verify the 200 code graphql response is obtaining the predictable result for all query params for Save Report option and requestId as output field for SaveReportOptionResponse", "VALID_DATA", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\""},
                {"TC002", "200", "Verify the 200 code graphql response is obtaining the predictable result when personReport is provided as \"true\" with filtername value for Save Report option and requestId as output field for SaveReportOptionResponse", "PEARSON_TRUE", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC003", "400", "Verify the 400 code graphql response is obtaining the predictable result when personReport is provided as \"true\" without filtername for Save Report option and requestId as output field for SaveReportOptionResponse", "PEARSON_TRUE_WITHOUT_FILTER_NAME", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC004", "401", "Verify \"401: UnAuthorized\" message in response when invalid Bearer token is given", "INVALID_AUTHORIZATION", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC005", "400", "Verify \"400: Bad Request\" in the error message of the response body when invalid query has been given", "INVALID_REQUEST", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC006", "400", "Verify 400 code in the error message of the response body when invalid personReport is given in the query", "INVALID_PEARSON", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC007", "400", "Verify 400 code and validation error in the graphql response when empty orgId is provided in the query input params", "EMPTY_ORG_IT", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC008", "400", "Verify 400 code and validation error in the graphql response when empty userId is provided in the query input params", "EMPTY_USER_IT", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC009", "400", "Verify 400 code and validation error in the graphql response when empty reportType is provided in the query input params", "EMPTY_REPORT_TYPE", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC010", "400", "Verify 400 code and validation error in the graphql response when empty personReport is provided in the query input params", "EMPTY_PEARSON", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC011", "400", "Verify 400 code and validation error in the graphql response when empty filterName is provided in the query input params", "EMPTY_FILTER_NAME", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC012", "400", "Verify 400 code and validation error in the graphql response when empty userType is provided in the query input params", "EMPTY_USER_TYPE", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC013", "400", "Verify 400 code and validation error in the graphql response when empty reportParameters is provided in the query input params", "EMPTY_REPORT_PARAMETERS", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC017", "200", "Verify the 200 code graphql response is obtaining the predictable result for all query params with reportType as \"LS\" and corresponding LS reportParameters", "LS_REPORT", "\\\"LS\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC018", "200", "Verify the 200 code graphql response is obtaining the predictable result for all query params with reportType as \"CP\" and corresponding CP reportParameters", "CP_REPORT", "\\\"CP\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC019", "200", "Verify the 200 code graphql response is obtaining the predictable result for all query params with reportType as \"ISP\" and corresponding ISP reportParameters", "ISP_REPORT", "\\\"ISP\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
                {"TC020", "200", "Verify the 200 code graphql response is obtaining the predictable result for all query params with reportType as \"MASTERY\" and corresponding MASTERY reportParameters", "MASTERY_REPORT", "\\\"MASTERY\\\"", "\\\"TestFilter\\\"", "\\\"teacher\\\"", "\\\"{}\\\"" },
        };
    }



    @Test ( dataProvider = "getDataforLoadReport", groups = { "SMK-57301", "GraphQL API to load/save report options", "API","SmokeTest" }, priority = 1 )
    public void testLoadReportAPI ( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();


        String payload = getLoadPayload();
        String query ;
        Response response = null;
        Log.testCaseInfo( "payload=" + payload );

        switch ( scenarioType ) {
            case "VALID_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_TEACHER_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_AUTHORIZATION":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.INVALID, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "INVALID_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, "" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, "" );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
            case "EMPTY_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, "");
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_REQUEST_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.LOAD_QUERY , query);
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( response.getBody().asString() );
                break;
        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        String responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : "No Response Code";
        // Validation

        if(statusCode.equalsIgnoreCase("200"))
        {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        }
        else if (response.getBody().asString().contains( statusCode ))
        {
            Log.assertThat( response.getBody().asString().contains( statusCode ), "The Status code is expected " + statusCode + " and actual " + statusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " is not Verified" );
        }
        else
        {
            Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                    "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        }

        //Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataforLoadReport() {
        return new Object[][]{
                {"TC021", "200", "Verify the 200 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when valid Request ID is given for Get Report Option Api", "VALID_REQUEST_ID"},
                {"TC022", "400", "Verify the 400 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when invalid Request ID is given for Get Report Option Api", "INVALID_REQUEST_ID"},
                {"TC023", "401", "Verify the 401 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when valid Request ID and invalid Bearer token is given for Get Report Option Api", "INVALID_AUTHORIZATION"},
                {"TC024", "404", "Verify the 404 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when valid Request ID and invalid orgid is given for Get Report Option Api", "INVALID_ORG_ID"},
                {"TC025", "404", "Verify the 404 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when valid Request ID and invalid userid is given for Get Report Option Api", "INVALID_USER_ID"},
                {"TC026", "400", "Verify the 400 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when empty Request ID is given for Get Report Option Api", "EMPTY_REQUEST_ID"},
                {"TC027", "400", "Verify the 400 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when valid Request ID and empty userid is given for Get Report Option Api", "EMPTY_USER_ID"},
                {"TC028", "400", "Verify the 400 code graphql response is obtaining the predictable result with all the fields in the GetReportOptionResponse when valid Request ID and empty orgid is given for Get Report Option Api", "EMPTY_ORG_ID"},

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet()
                .stream()
                .map(e -> e.getKey()+":"+e.getValue())
                .collect( Collectors.joining(" \\n ") );
    }

    public String getPayload() throws IOException {
        String basePath = (new File(".")).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator +  "report" + File.separator +"SaveReportRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader(file))
        {
            char[] chars  = new char[(int)file.length()];
            int offset = 0;
            while (offset < chars.length)
            {
                int result = fr.read(chars, offset, chars.length - offset);
                if (result == -1) {
                    break;
                }
                offset += result;
            }
            return new String(chars);
        }
    }

    public String getLoadPayload() throws IOException {
        String basePath = (new File(".")).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator +  "report" + File.separator +"LoadReportRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader(file))
        {
            char[] chars  = new char[(int)file.length()];
            int offset = 0;
            while (offset < chars.length)
            {
                int result = fr.read(chars, offset, chars.length - offset);
                if (result == -1) {
                    break;
                }
                offset += result;
            }
            return new String(chars);
        }
    }

}