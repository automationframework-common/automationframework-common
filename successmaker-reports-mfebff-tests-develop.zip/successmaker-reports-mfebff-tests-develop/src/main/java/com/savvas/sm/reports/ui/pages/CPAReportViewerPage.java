package com.savvas.sm.reports.ui.pages;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.restassured.response.Response;
import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPAPayload;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPAReport;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;

import LSTFAI.customfactories.IFindBy;
import io.restassured.response.Response;

public class CPAReportViewerPage extends LoadableComponent<CPAReportViewerPage> {
    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;
    public ReportOutputComponent reportOutputComponent;
    // ********* SuccessMaker Launcher/Login Page Elements ***************

    @FindBy ( css = "h2.header" )
    WebElement reportHeader;

    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement mathTxt;
    
    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportButtonRoot;
    
    @FindBy ( xpath = "//dd" )
    WebElement dateTxt;

    @FindBy ( css = "dl.detail-row.info dt:nth-child(1)" )
    WebElement districtTxt;

    @FindBy ( css = "span.list-head.ml-2" )
    WebElement selectedOptionTxt;

    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> selectedOptions;
    
    @FindBy (css ="dd.label-value")
    WebElement selectedOptionsDemographic;
    
    @FindBy ( css ="ul li" )
    List<WebElement> selectedOptionField;

    @FindBy ( css = "dl.detail-row.legends" )
    List<WebElement> legendOptions;

    @FindBy ( css = "tr.header th" )
    List<WebElement> columnHeaders;

    @FindBy ( css = "tr.sub-header th" )
    List<WebElement> columnSubHeaders;

    @FindBy ( css = " tbody tr " )
    List<WebElement> gridValues;

    @FindBy ( css = "dl.detail-row.info dt:nth-child(3)" )
    WebElement gradeTxt;
    
    @FindBy ( css = "dl.detail-row.legends dt" )
    List<WebElement> legendKeys;

    @FindBy ( css = "dl.detail-row.legends dd" )
    List<WebElement> LegendValues;

    @FindBy ( css = "div.header-pagination span" )
    List<WebElement> paginationText;

    @FindBy ( css = "dl.detail-row.info dd:nth-child(2)" )
    WebElement districtName;

    @FindBy ( css = "table tbody tr" )
    List<WebElement> rowValues;

    @FindBy ( css = "span.pagination-text-suffix" )
    WebElement totalPageCount;

    @FindBy ( css = "dl.detail-row.info dd:nth-child(4)" )
    WebElement gradeValue;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement nextBtnRoot;

    @FindBy ( css = "div.error p.header" )
    WebElement zeroStateMessage;

    @IFindBy ( how = How.CSS, using = "div.error p.header", AI = false )
    WebElement errorMessage;

    @FindBy ( css = "export-pdf-modal cel-modal.export-pdf-modal" )
    WebElement exportPDFs;
    
    @FindBy ( css = "export-data-modal cel-modal.export-data-modal" )
    WebElement exportCSV;
    
    /************************** Child Elements *******************************/

    String tabledata = "td";
    private String runButton="button";

    String columnValue = "td:nth-of-type(%s)";
    String button = "button.button";

    @FindBy ( id = "table" )
    WebElement table;

    String tableColumnData = "tbody tr:nth-of-type(%s) td:nth-of-type(%s) div.cell-data";
    String tableFooterData = "tfoot tr:nth-of-type(%s) td:nth-of-type(%s) div.cell-data span";


    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public CPAReportViewerPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
        reportOutputComponent = new ReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, reportHeader );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, reportHeader, 30 ) ) {
            Log.message( "Report viewer Page loaded successfully." );
        } else {
            Log.fail( "Report viewer Page Page not loaded successfully." );
        }

    }

    public String getSubjectLabel() {
        SMUtils.waitForElement( driver, mathTxt, 30 );
        String reportWebElement = SMUtils.getTextOfWebElement( mathTxt, driver );
        return reportWebElement;
    }

    public String getDateLabel() {
        String timeZoneWebElement = SMUtils.getTextOfWebElement( dateTxt, driver ).substring( 0, 8 );
        return timeZoneWebElement;
    }

    public String getDistrictLabel() {
        String districtWebElement = SMUtils.getTextOfWebElement( districtTxt, driver );
        return districtWebElement;
    }

    public String getSelectedOptionLabel() {
        String textOfWebElement = SMUtils.getTextOfWebElement( selectedOptionTxt, driver );
        return textOfWebElement;
    }

    public List<String> getSelectedOptionsLegend() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Log.message( "Getting the all the selectced options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( selectedOptions );
        return allTextFromWebElementList;

    }

    public List<String> getLegendOptions() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( legendOptions ) );
        Log.message( "Getting the all the legend options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( legendOptions );
        return allTextFromWebElementList;
    }

    /**
     * To get the column headers
     *
     * @return
     */
    public List<String> getColumnHeaders() {

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );

        wait.until( ExpectedConditions.visibilityOfAllElements( columnHeaders ) );
        Log.message( "Getting all the column headers..." );
        return SMUtils.getAllTextFromWebElementList( columnHeaders );
    }

    /**
     * To get the column sub-headers
     *
     * @return
     */
    public List<String> getColumnSubHeaders() {

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );

        wait.until( ExpectedConditions.visibilityOfAllElements( columnSubHeaders ) );
        Log.message( "Getting all the column headers..." );
        return SMUtils.getAllTextFromWebElementList( columnSubHeaders );
    }

    /**
     * To get CPAggregate Report selected option Additional Grouping field 
     * 
     * @return
     * @throws InterruptedException 
     */
    public String getSelectedAdditionalGrouping() throws InterruptedException {
    	SMUtils.nap(10);
    	SMUtils.waitForElement(driver, selectedOptionField.get(0));
    	Log.message( "Getting Recent Session Report Additional Grouping field" );
        return selectedOptionField.get(0).getText().trim();
    }
    
    /**
     * To get CPAggregate Report selected option Sort field 
     * @return 
     */
    public boolean getSelectedSortOption(String sortOption) {
    	new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );       
    		String sortOptionFormat;	
    	if(sortOption.contains("(Mean)")) {
			String selectedSortOption = sortOption.replace("(Mean)", "");
			sortOptionFormat = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,selectedSortOption);
		}
    	else {
    		sortOptionFormat=String.format(ReportsUIConstants.SELECTED_OPTION_SORT,sortOption);
		}
    			return sortOptionFormat.trim().equalsIgnoreCase(selectedOptionField.get(1).getText().trim());
    }
    
    /**
     * To get CPAggregate Report selected option Student Demographic field 
     * 
     * @return
     */
    public String selectedOptionDemographic() {
        Log.message( "Getting Recent Session Report Student Demographic field" );
        return selectedOptionField.get(3).getText().trim();
    }
    
    /**
     * To get CPAggregate Report selected option Student Demographic field 
     * 
     * @return
     */
    public boolean assignedGradeLevels() {
        Log.message( "Getting Recent Session Report Student Demographic field" );
        return selectedOptions.get(2).getText().trim().equals(ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get(2));
    }
    
    /**
     * Verify the CPAggregate Report selected Student Demographic value 
     * 
     * @return
     */
    public boolean getDemographicValue(String selectedDemographic) {
        return selectedDemographic.trim().contains(selectedOptionsDemographic.getText().trim());	
    }
    
    
    /**
     * Verify the CPAggregate Report selected Student Demographic value 
     * 
     * @return
     */
    public boolean verifyDemographicValues(List<String> selectedDemographic) {
        if ( selectedDemographic.contains(  "Select All"  ) ) {
            selectedDemographic.remove( "Select All" );
            Log.message( "Removed 'Select All' option from SelectedDemographicsList" );
            Log.message( "selectedDemographic1: " + selectedDemographic );
            Log.message( "Actual Demographics1: " + selectedOptionsDemographic.getText().trim() );
            return selectedDemographic.toString().trim().contains(selectedOptionsDemographic.getText().trim());    
        } else {
            Log.message( "selectedDemographic2: " + selectedDemographic );
            Log.message( "Actual Demographics2: " + selectedOptionsDemographic.getText().trim() );
            return selectedDemographic.toString().trim().contains(selectedOptionsDemographic.getText().trim());  
        }
    }
    
    /**
     * To Click Run Report Button
     */
    public void clickRunReportButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, runReportButtonRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, runReportButtonRoot, runButton ) );
            Log.message( "Clicked Run Report Button!" );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
            
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Clicked Run Report Button Failed" );
            
        }
    }
    
    /**
     * To get the skill details
     * 
     * @return
     */
    public Map<String, Map<String, String>> getSkillsDetails() {
        Map<String, Map<String, String>> allGridValues = new HashMap<>();
        Map<String, String> gridValue = new HashMap<>();
        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            gridValue.put( "School", columnData.get( 0 ).getText().trim() );
            gridValue.put( "Current Course Level", columnData.get( 1 ).getText().trim() );
            gridValue.put( "IP Level", columnData.get( 2 ).getText().trim() );
            gridValue.put( "Gain", columnData.get( 3 ).getText().trim() );
            gridValue.put( "Time Spent", columnData.get( 4 ).getText().trim() );
            gridValue.put( "Total Sessions", columnData.get( 5 ).getText().trim() );
            gridValue.put( "Exercises Correct", columnData.get( 6 ).getText().trim() );
            gridValue.put( "Exercises Attempted", columnData.get( 7 ).getText().trim() );
            gridValue.put( "Exercises Percent Correct", columnData.get( 8 ).getText().trim() );
            gridValue.put( "Skills Assessed", columnData.get( 9 ).getText().trim() );
            gridValue.put( "Skills Mastered", columnData.get( 10 ).getText().trim() );
            gridValue.put( "Skills Percent Mastered", columnData.get( 11 ).getText().trim() );
            gridValue.put( "Percent Students with AP", columnData.get( 12 ).getText().trim() );
            allGridValues.put( gridValue.get( "School" ), gridValue );
        } );
        return allGridValues;
    }

    /**
     * To get UI grid values
     * 
     * @return
     */
    public Map<String, Map<String, String>> getGridvalues() {
        SMUtils.waitForElement( driver, reportHeader );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();
            String school = columnData.get( 0 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 0 ).getText().trim();
            gridValue.put( "currentCourseLevel", columnData.get( 1 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 1 ).getText().trim() );
            gridValue.put( "ipLevel", columnData.get( 2 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 2 ).getText().trim() );
            gridValue.put( "gain", columnData.get( 3 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 3 ).getText().trim() );
            int min = 0;
            if ( !columnData.get( 4 ).getText().trim().equals( "NA" ) ) {
                min = ( Integer.parseInt( columnData.get( 4 ).getText().trim().split( ":" )[0] ) * 60 ) + Integer.parseInt( columnData.get( 4 ).getText().trim().split( ":" )[1] );
            }
            gridValue.put( "timeSpent", columnData.get( 4 ).getText().trim().equals( "NA" ) ? "null" : String.valueOf( min ) );
            gridValue.put( "totalSessions", columnData.get( 5 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 5 ).getText().trim() );
            gridValue.put( "exercisesCorrect", columnData.get( 6 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 6 ).getText().trim() );
            gridValue.put( "exercisesAttempted", columnData.get( 7 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 7 ).getText().trim() );
            gridValue.put( "exercisesPercentCorrect", columnData.get( 8 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 8 ).getText().trim().replace( "%", "" ) );
            gridValue.put( "skillsAssessed", columnData.get( 9 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 9 ).getText().trim() );
            gridValue.put( "skillsMastered", columnData.get( 10 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 10 ).getText().trim() );
            gridValue.put( "skillsPercentMastered", columnData.get( 11 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 11 ).getText().trim().replace( "%", "" ) );
            gridValue.put( "percentStudentsWithAP", columnData.get( 12 ).getText().trim().equals( "NA" ) ? "null" : columnData.get( 12 ).getText().trim().replace( "%", "" ) );

            allGridValues.put( school, gridValue );

        } );
        return allGridValues;
    }

    public boolean validDateFormat() throws java.text.ParseException {
        SMUtils.waitForElement( driver, dateTxt );
        String actualDateFormat1 = SMUtils.getTextOfWebElement( dateTxt, driver );
        Log.message( "Actual Date Format is:" + actualDateFormat1 );
        DateFormat formatter = new SimpleDateFormat( "dd/MM/yyyy" );
        formatter.setLenient( false );
        try {
            Date date = formatter.parse( actualDateFormat1 );
        } catch ( ParseException e ) {
            Log.message( "The Date format is not as expected" + e );
        }
        return true;
    }

    /**
     * To get Date and Time
     * 
     * @return
     */
    public String dateAndTime() {
        SimpleDateFormat formatter = new SimpleDateFormat( "MM/dd/yy" );
        Date date = new Date();
        return formatter.format( date );

    }

    /**
     * To get BFF headers and filters Details
     * 
     * @param headers
     * @param filtersData
     * @return
     */
    public Response getBFFReport( Map<String, String> headers, Map<String, String> filtersData ) {
        String payloadValues = CPAPayload.PAYLOAD_VALUES;
        for ( String filter : CPAPayload.CPA_FILTERS ) {
            if ( !Objects.isNull( filtersData.get( filter ) ) ) {
                payloadValues = payloadValues.replace( filter, filtersData.get( filter ) );
            } else {

                payloadValues = payloadValues.replace( "\\\"" + filter + "\\\"", "" );
            }
        }
        Log.message( payloadValues );
        return RestAssuredAPIUtil.POSTGraphQl( "https://sm-reports-bff-srv-stack-stage.smdemo.info", headers, payloadValues, AdminConstants.GRAPHQL_ENDPOINT );

    }

    /**
     * To get BFF response details
     * 
     * @param response
     * @return
     */
    public Map<String, Map<String, String>> getCPARResponseDetails( String response ) {
        String allgradeDetails = SMUtils.getKeyValueFromResponse( response, "data" );
        JSONArray jsonArray = new JSONObject( allgradeDetails ).getJSONArray( "getCPAAdminReportData" );
        Map<String, Map<String, String>> cparDetails = new HashMap<>();
        IntStream.range( 0, CPAPayload.grades.size() ).forEach( count -> {
            int itr = -1;
            for ( int i = 0; i < jsonArray.length(); i++ ) {
                String dataRow = new JSONObject( jsonArray.get( i ).toString() ).getJSONArray( "dataRows" ).get( 0 ).toString();
                String grade = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "organizationName" ) + " ("
                        + ( SMUtils.getKeyValueFromResponse( jsonArray.get( i ).toString(), "grade" ).equals( "KG" ) ? "K" : "G" + Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonArray.get( i ).toString(), "grade" ) ) ) + " - "
                        + ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "numberOfStudents" ).equals( "null" ) ? "0"
                                : SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "numberOfStudents" ) )
                        + ")";
                if ( String.format( CPAPayload.grades.get( count ), SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "organizationName" ),
                        ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "numberOfStudents" ).equals( "null" ) ? "0"
                                : SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "numberOfStudents" ) ) ).equals( grade ) ) {
                    itr = i;
                    break;
                }
            }

            Map<String, String> cprDetail = new HashMap<>();
            if ( itr >= 0 ) {
                String dataRow = new JSONObject( jsonArray.get( itr ).toString() ).getJSONArray( "dataRows" ).get( 0 ).toString();

                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String currentCourseLevel = "";
                if ( !SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "levelDataMean" ), "currentCourseLevel" ).equals( "null" ) ) {
                    currentCourseLevel = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "levelDataMean" ), "currentCourseLevel" ) ) );
                } else {
                    currentCourseLevel = "null";
                }
                cprDetail.put( "currentCourseLevel", currentCourseLevel );

                String iplevel = "";
                if ( !SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "levelDataMean" ), "ipLevel" ).equals( "null" ) ) {
                    iplevel = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "levelDataMean" ), "ipLevel" ) ) );
                } else {
                    iplevel = "null";
                }
                cprDetail.put( "ipLevel", iplevel );
                String gain = "";
                if ( !SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "levelDataMean" ), "gain" ).equals( "null" ) ) {
                    gain = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "levelDataMean" ), "gain" ) ) );
                } else {
                    gain = "null";

                }

                cprDetail.put( "gain", gain );
                cprDetail.put( "timeSpent", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "usageMean" ), "timeSpent" ) );
                cprDetail.put( "totalSessions", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "usageMean" ), "totalSessions" ) );
                cprDetail.put( "exercisesCorrect", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "instructionalPerformanceMean" ), "exercisesCorrect" ) );
                cprDetail.put( "exercisesAttempted", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "instructionalPerformanceMean" ), "exercisesAttempted" ) );

                String exercisesPercentCorrect = "";
                if ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "instructionalPerformanceMean" ), "exercisesPercentCorrect" ).equals( "0" ) ) {
                    exercisesPercentCorrect = ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "instructionalPerformanceMean" ), "exercisesPercentCorrect" ).replace( "0", "null" ) );
                } else {
                    exercisesPercentCorrect = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "instructionalPerformanceMean" ), "exercisesPercentCorrect" );
                }
                cprDetail.put( "exercisesPercentCorrect", exercisesPercentCorrect );

                cprDetail.put( "skillsAssessed", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "masteryMean" ), "skillsAssessed" ) );
                cprDetail.put( "skillsMastered", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "masteryMean" ), "skillsMastered" ) );
                cprDetail.put( "skillsPercentMastered", SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "masteryMean" ), "skillsPercentMastered" ) );

                String percentStudentsWithAP = "";
                if ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "masteryMean" ), "percentStudentsWithAP" ).equals( "0" ) ) {
                    percentStudentsWithAP = ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "masteryMean" ), "percentStudentsWithAP" ).replace( "0", "null" ) );
                } else {
                    percentStudentsWithAP = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "masteryMean" ), "percentStudentsWithAP" );
                }
                cprDetail.put( "percentStudentsWithAP", percentStudentsWithAP );

                String keyValue = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "organizationName" ) + " ("
                        + ( SMUtils.getKeyValueFromResponse( jsonArray.get( itr ).toString(), "grade" ).equals( "KG" ) ? "K" : "G" + Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonArray.get( itr ).toString(), "grade" ) ) ) + " - "
                        + ( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "numberOfStudents" ).equals( "null" ) ? "0"
                                : SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "numberOfStudents" ) )
                        + ")";
                cparDetails.put( keyValue, cprDetail );
            } else {
                cprDetail.put( "currentCourseLevel", "null" );
                cprDetail.put( "ipLevel", "null" );
                cprDetail.put( "gain", "null" );
                cprDetail.put( "timeSpent", "null" );
                cprDetail.put( "totalSessions", "null" );
                cprDetail.put( "exercisesCorrect", "null" );
                cprDetail.put( "exercisesAttempted", "null" );
                cprDetail.put( "exercisesPercentCorrect", "null" );
                cprDetail.put( "skillsAssessed", "null" );
                cprDetail.put( "skillsMastered", "null" );
                cprDetail.put( "skillsPercentMastered", "null" );
                cprDetail.put( "percentStudentsWithAP", "null" );
                String dataRow = new JSONObject( jsonArray.get( 0 ).toString() ).getJSONArray( "dataRows" ).get( 0 ).toString();
                cparDetails.put( String.format( CPAPayload.grades.get( count ), SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( dataRow, "orgData" ), "organizationName" ), "0" ), cprDetail );

            }
        } );
        Log.message( cparDetails.toString() );
        return cparDetails;

    }

    public String getReportPageTitle() {
        Log.message( "Getting Cumulative performance aggregate Report page Title" );
        SMUtils.waitForElement( driver, reportHeader );
        return reportHeader.getText().trim();
    }

    public String getGradeLabel() {

        String districtWebElement = SMUtils.getTextOfWebElement( gradeTxt, driver );
        return districtWebElement;
    }

    /**
     * To get District name
     * 
     * @return
     * @throws InterruptedException
     */
    public String getDistrictName() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, districtName );
        return districtName.getText().trim();
    }

    /**
     * To verify the Legend values
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean verifyLegend() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader );
        return legendKeys.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ).equals( CPAReport.LEGEND_KEYS )
                && LegendValues.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ).equals( CPAReport.LEGEND_VALUES );
    }

    /**
     * To verify the pagination
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean verifyPagination() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader );
        List<String> list = paginationText.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
        return ( list.get( 0 ) + list.get( 1 ) ).equals( String.format( ReportsUIConstants.PAGINATION_TEXT, "1" ) );
    }

    /**
     * To get UI grid values
     * 
     * @return
     */
    public boolean sortAndCompareColumnvalues( String columnName ) {
        SMUtils.waitForElement( driver, reportHeader );
        List<String> columnValueList = new ArrayList<>();

        rowValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.SORT_CPAR.indexOf( columnName ) + 1 ) ) );
            IntStream.range( 0, columnData.size() ).forEach( itr -> {
                if ( !columnData.get( itr ).getText().trim().equals( "NA" ) ) {
                    columnValueList.add( columnData.get( itr ).getText().trim() );
                }
            } );
        } );

        if ( columnName.equals( ReportsUIConstants.SORT_CPAR.get( 0 ) ) ) {
            List<String> expList = new ArrayList<>();
            columnValueList.stream().filter( txt -> txt.contains( "K - " ) ).forEach( value -> expList.add( value ) );
            IntStream.rangeClosed( 1, columnValueList.size() ).forEach( itr -> {
                columnValueList.stream().filter( text -> text.contains( "G" + itr + " " ) ).forEach( value -> expList.add( value ) );
            } );
            return columnValueList.equals( expList );
        } else {
            return columnValueList.stream().sorted( String.CASE_INSENSITIVE_ORDER ).collect( Collectors.toList() ).equals( columnValueList );
        }
    }

    /**
     * To get all the values from report table
     * 
     * @return
     * @throws InterruptedException
     */
    public List<String> getGradeValues() throws InterruptedException {

        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, nextBtnRoot );
        List<String> subHeaderValues = new ArrayList<>();
        if ( !getZeroStateMessage() ) {
            IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
                subHeaderValues.add( gradeValue.getText().trim() );
                WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
                if ( nextBtn.isEnabled() ) {
                    SMUtils.click( driver, nextBtn );
                }
            } );
        }
        return subHeaderValues;
    }

    /**
     * To get the zero state message
     * 
     * @return
     */
    public boolean getZeroStateMessage() {
        try {
            SMUtils.waitForElement( driver, zeroStateMessage );
            return zeroStateMessage.getText().trim().equals( ReportsUIConstants.NO_DATA_TO_DISPLAY );
        } catch ( Exception e ) {
            return false;
        }
    }
    
    /**
     * Get current URL for report viewer page
     * 
     * @return
     */
    public String getReportViewerURL() {

        String URL = driver.getCurrentUrl();
        String actualURL = URL + System.nanoTime();
        Log.message( "Getting URL for report viewr page" );
        return actualURL;
    }

    /**
     * Launching report viewr page again
     */
    public void launchURLWithWrongRequestID() {

        SMUtils.nap( 2 );// This wait is required to load report viewr page
        String launchingURL = getReportViewerURL();
        Log.message( "Launching URL again after adding wrong request ID in URL" );
        driver.navigate().to( launchingURL );

    }

    /**
     * Getting status of PDF button when error message pops up
     * 
     * @return
     */
    public String getPDFButtonDisabled() {

        SMUtils.waitForElement( driver, exportPDFs );
        String attributeValue = exportPDFs.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }
    
    /**
     * Getting status of CSV button when error message pops up
     * 
     * @return
     */
    public String getCSVButtonDisabled() {

        SMUtils.waitForElement( driver, exportCSV );
        String attributeValue = exportCSV.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }

    /**
     * To get Date and Time
     * 
     * @return
     */
    public String getDateAndTime() {
        SimpleDateFormat formatter = new SimpleDateFormat( "MM/dd/yy" );
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = new Date();
        return formatter.format( date );

    }

    public String getValueOfColumn( String columnName ) {
        String value = "";
        String cssValue = "";
        switch ( columnName ) {
            case ReportsUIConstants.CPReportConstant.STUDENT:
                cssValue = String.format( tableColumnData, "1", "1" );
                break;
            case ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL:
                cssValue = String.format( tableColumnData, "1", "2" );
                break;
            case ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL:
                cssValue = String.format( tableColumnData, "1", "3" );
                break;
            case ReportsUIConstants.CPReportConstant.IP_LEVEL:
                cssValue = String.format( tableColumnData, "1", "4" );
                break;
            case ReportsUIConstants.CPReportConstant.GAIN:
                cssValue = String.format( tableColumnData, "1", "5" );
                break;
            case ReportsUIConstants.CPReportConstant.TIME_SPENT:
                cssValue = String.format( tableColumnData, "1", "6" );
                break;
            case ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS:
                cssValue = String.format( tableColumnData, "1", "7" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT:
                cssValue = String.format( tableColumnData, "1", "8" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED:
                cssValue = String.format( tableColumnData, "1", "9" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT:
                cssValue = String.format( tableColumnData, "1", "10" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED:
                cssValue = String.format( tableColumnData, "1", "11" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_MASTERED:
                cssValue = String.format( tableColumnData, "1", "12" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED:
                cssValue = String.format( tableColumnData, "1", "13" );
                break;
            case ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "2" );
                break;
            case ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "3" );
                break;
            case ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "4" );
                break;
            case ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "5" );
                break;
            case ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "6" );
                break;
            case ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "7" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "8" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "9" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "10" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "11" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "12" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "13" );
                break;
            case ReportsUIConstants.CPReportConstant.ASSIGNED_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "2" );
                break;
            case ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "3" );
                break;
            case ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "4" );
                break;
            case ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "5" );
                break;
            case ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "6" );
                break;
            case ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "7" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "8" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "9" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "10" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "11" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "12" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "13" );
                break;
        }
        Log.message( cssValue );
        WebElement data = table.findElement( By.cssSelector( cssValue ) );
        if ( data != null )
            value = data.getText().trim();
        Log.message( value );
        return value;
    }

    public String getValueOfColumnCPAR( String columnName ) {
        String value = "";
        String cssValue = "";
        switch ( columnName ) {
            case ReportsUIConstants.CPReportConstant.SCHOOL:
                cssValue = String.format( tableColumnData, "1", "1" );
                break;
            case ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL:
                cssValue = String.format( tableColumnData, "1", "2" );
                break;
            case ReportsUIConstants.CPReportConstant.IP_LEVEL:
                cssValue = String.format( tableColumnData, "1", "3" );
                break;
            case ReportsUIConstants.CPReportConstant.GAIN:
                cssValue = String.format( tableColumnData, "1", "4" );
                break;
            case ReportsUIConstants.CPReportConstant.TIME_SPENT:
                cssValue = String.format( tableColumnData, "1", "5" );
                break;
            case ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR:
                cssValue = String.format( tableColumnData, "1", "6" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT:
                cssValue = String.format( tableColumnData, "1", "7" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED:
                cssValue = String.format( tableColumnData, "1", "8" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT:
                cssValue = String.format( tableColumnData, "1", "9" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED:
                cssValue = String.format( tableColumnData, "1", "10" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_MASTERED:
                cssValue = String.format( tableColumnData, "1", "11" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED:
                cssValue = String.format( tableColumnData, "1", "12" );
                break;
            case ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP:
                cssValue = String.format( tableColumnData, "1", "13" );
                break;
            case ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "2" );
                break;
            case ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "3" );
                break;
            case ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "4" );
                break;
            case ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "5" );
                break;
            case ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "6" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "7" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "8" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "9" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "10" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "11" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "12" );
                break;
            case ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + ReportsUIConstants.CPReportConstant.MEAN:
                cssValue = String.format( tableFooterData, "1", "13" );
                break;
            case ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "2" );
                break;
            case ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "3" );
                break;
            case ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "4" );
                break;
            case ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "5" );
                break;
            case ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "6" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "7" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "8" );
                break;
            case ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "9" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "10" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "11" );
                break;
            case ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "12" );
                break;
            case ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION:
                cssValue = String.format( tableFooterData, "2", "13" );
                break;
        }
        Log.message( cssValue );
        WebElement data = table.findElement( By.cssSelector( cssValue ) );
        if ( data != null )
            value = data.getText().trim();
        Log.message( value );
        return value;
    }
}
