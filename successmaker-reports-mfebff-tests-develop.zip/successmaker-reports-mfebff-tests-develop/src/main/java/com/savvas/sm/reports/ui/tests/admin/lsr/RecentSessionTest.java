package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class RecentSessionTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Recent Session Page title and description", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMLeftNav001: Verify Recent Session Page title and description <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the Recent Sessions menu is displayed in the sub-navigation of Reports Page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.RECENT_SESSIONS ), "The Recent Sessions is displayed in Report MFE sub-navigation", "The Recent Sessions is displayed in Report MFE sub-navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Recent Sessions menu in the sub-navigation of Reports Page is clickable" );
            SMUtils.logDescriptionTC( "Verify the click function on Recent Sessions menu navigates the user to the Recent Session Page" );
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            Log.assertThat( recentSessionPage.isRecentSessionSubNavigationSelected(), "The Recent Session in sub navigation is selected and it is verified", "The Recent Session in sub navigation is not selected and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the title of Recent Sessions page is displayed" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isReportTitleDisplayed(), "The Recent Session title is displayed and it is verified", "The Recent Session title is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.RECENT_SESSION_PAGE_TITLE ), "The Recent Session title text is displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE,
                    "The Recent Session title text is not displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the help icon (?) is displayed along with the title of the Recent Session Page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isHelpIconDisplayed(), "The Recent Session help icon is displayed and it is verified", "The Recent Session help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the page description is displayed below the title of the Recent Session Page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isReportDescriptionDisplayed(), "The Recent Session description is displayed and it is verified", "The Recent Session description is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getReportDescription().equals( ReportsUIConstants.RECENT_SESSION_PAGE_DESCRIPTION ),
                    "The Recent Session description text is displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_DESCRIPTION, "The Recent Session description text is not displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_DESCRIPTION );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the functionality of Save Report Option drop down", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession002: Verify the functionality of Save Report Option drop down <small><b><i>[" + browser + "]</b></i></small>" );
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify Saved Report Option label is displayed in the Recent Sessions Page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The Recent Session Save Report Option label is displayed and it is verified",
                    "The Recent Session Save Report Option label is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "The Recent Session Save Report Option label text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "The Recent Session Save Report Option label text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Saved Report Option drop down is displayed in the Recent sessions page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The Recent Session Save Report Option drop down is displayed and it is verified",
                    "The Recent Session Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default text in the displayed in the Saved Report Option drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK ),
                    "The Recent Session Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK,
                    "The Recent Session Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The Recent Session Save Report Option drop down arrow is displayed and it is verified",
                    "The Recent Session Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Saved Report option drop down is listed with saved report options" );
            recentSessionPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed in the Saved Report Option drop down is expanded" );
            recentSessionPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).equals( "Up" ), "The arrow is in Upward direction when it is expanded",
                    "The arrow is in downward direction when it is expanded" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Saved report option name is displayed when it is selected" );
            String selectingOption = recentSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).get( 1 );
            recentSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL, selectingOption );
            Log.message( selectingOption );
            String savedReportWaterMarkText = recentSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.message( savedReportWaterMarkText );
            Log.testCaseResult();

            Log.assertThat( savedReportWaterMarkText.equals( selectingOption ), "The selected option is displayed in the drop down text", "The selected option is not displayed in the drop down text" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the functionality of Organizations drop down", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession003: Verify the functionality of Organizations drop down <small><b><i>[" + browser + "]</b></i></small>" );
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Organizations label is displayed in the Recent Sessions page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization label is displayed", "The Organization label is not displayed" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization label is displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    "The Organization label is not displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Organizations drop down is displayed in the Recent Sessions page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isMultiSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization drop down is displayed", "The Organization drop down is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verfify the default text in the displayed in the Organizations drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK ),
                    "The Organization drop down water mark text is not verified as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK,
                    "The Organization drop down water mark text is verified as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed when the Organization drop down is collapsed" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isMultiSelectDropDownArrowDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Recent Session Organizations drop down arrow is displayed and it is verified",
                    "The Recent Session Organizations drop down arrow is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getMultiSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Organizations drop down is expandable when it is clicked" );
            recentSessionPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.assertThat( recentSessionPage.reportFilterComponent.getMultiSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( "Up" ), "The arrow is in Upward direction when it is Expanded",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Search box is displayed in the Organizations drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Recent Session Organizations drop down search box is displayed and it is verified",
                    "The Recent Session Organizations drop down search box is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default text in the search box of Organizations drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getMultiSelectSearchPlaceHolder( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK ),
                    "The water mark of search box is verified as" + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK,
                    "The water mark of search box is not verified as" + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search icon is displayed in the search box of Organizations drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSearchIconDisplayedForMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The search icon in the search box is displayed",
                    "The search icon in the search box is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify All option is displayed with check box in the Organizations drop down" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( "ALL" ) );
            List<String> allOptionsFromOrganizationDropdown = recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            allOptionsFromOrganizationDropdown.remove( "ALL" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll( allOptionsFromOrganizationDropdown ), "All options are selected",
                    "All options are not selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify when All is unchecked all the values in the Organizations drop down is selected" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( "ALL" ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).isEmpty(), "All options are unselected", "All options are selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify only one Organization is selected the default text displays the organization name in the drop down" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    Arrays.asList( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ) ) );
            Log.assertThat(
                    recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll(
                            Arrays.asList( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ) ) ),
                    "All options are selected", "All options are not selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify more than one Organization is selected the default text displays the organization name in the drop down" );
            recentSessionPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    Arrays.asList( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 2 ),
                            recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 3 ) ) );
            Log.assertThat(
                    recentSessionPage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll(
                            Arrays.asList( recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ),
                                    recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 2 ),
                                    recentSessionPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 3 ) ) ),
                    "All given options are selected", "All given options are not selected" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Course Selection label is displayed in the Recect Sessions report page", groups = { "Smoke", "SMK-51098", "AdminDashboard", "LeftNavigation" }, priority = 1 )
    public void tcRecentSession004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession004: Verify the Course Selection label is displayed in the Recect Sessions report page <small><b><i>[" + browser + "]</b></i></small>" );
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Course Selection label is displayed in the Recect Sessions report page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.RECENT_SESSION_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Subject label and drop down", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession005: Verify the Subject label and drop down <small><b><i>[" + browser + "]</b></i></small>" );
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Subject label is displayed in the Recent Sessions report page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Subject drop down is displayed in the Recent Sessions report Page" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default text is displayed in the subject drop down" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK ),
                    "The Subject drop down default text is verified", "The Subject drop down default text is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the drop down values of the Subject drop down values" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).containsAll( ReportsUIConstants.SUBJECTS ), "The Subject drop down values are verified",
                    "The Subject drop down values are not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Subject drop down is a single select drop down" );
            SMUtils.logDescriptionTC( "Verify the tick symbol is displayed when any of the subject drop down values are selecred" );
            recentSessionPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            recentSessionPage.reportFilterComponent.collapseSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL );
            Log.message( recentSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ) );
            Log.assertThat( recentSessionPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.MATH ), "The given value is selected in Subject drop down",
                    "The given value is not selected in Subject drop down" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Courses label and drop down", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession006: Verify the Courses label and drop down <small><b><i>[" + browser + "]</b></i></small>" );
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Course(s) label is displayed in the Recent Sessions drop down" );
            SMUtils.logDescriptionTC( "Verify the Courses drop down is displayed and disabled by default" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses label is displayed", "The Courses label is not displayed" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses label is verifed and displayed as " + ReportsUIConstants.RECENT_SESSION_COURSES_LABEL,
                    "The Courses label is not verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isMultiSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses drop down is displayed", "The Courses drop down is not displayed" );
            Log.assertThat( !recentSessionPage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses drop down is disabled", "The Courses drop down is not disabled" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Recent Session page is displayed for District admin", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession007: Verify the Recent Session page is displayed for District admin. <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Recent Session page is displayed for District admin" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isReportTitleDisplayed(), "The Recent Session title is displayed and it is verified", "The Recent Session title is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.RECENT_SESSION_PAGE_TITLE ), "The Recent Session title text is displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE,
                    "The Recent Session title text is not displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Recent Session page is displayed for Sub-district admin", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession008: Verify the Recent Session page is displayed for Sub-district admin <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Recent Session page is displayed for Sub-district admin" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isReportTitleDisplayed(), "The Recent Session title is displayed and it is verified", "The Recent Session title is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.RECENT_SESSION_PAGE_TITLE ), "The Recent Session title text is displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE,
                    "The Recent Session title text is not displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Recent Session page is displayed for School admin", groups = { "Smoke", "SMK-57812", "AdminDashboard", "Reports", "Recent Sessions" }, priority = 1 )
    public void tcRecentSession009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRecentSession009: Verify the Recent Session page is displayed for School admin <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

        try {
            SMUtils.logDescriptionTC( "Verify the Recent Session page is displayed for School admin" );
            Log.assertThat( recentSessionPage.reportFilterComponent.isReportTitleDisplayed(), "The Recent Session title is displayed and it is verified", "The Recent Session title is not displayed and it is verified" );
            Log.assertThat( recentSessionPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.RECENT_SESSION_PAGE_TITLE ), "The Recent Session title text is displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE,
                    "The Recent Session title text is not displayed as " + ReportsUIConstants.RECENT_SESSION_PAGE_TITLE );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
