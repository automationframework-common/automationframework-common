package com.savvas.sm.reports.ui.tests.admin.spr;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.reports.ui.pages.StudentPerformanceOutputPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;

public class StudentPerformanceReportAdminGraphQLTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        //username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        username = "warriors_customer";
        password = "password1";
    }

    @Test ( description = "TC001_Verification of Admin SPR Report Output Page for IP levels for Math", groups = { "SMK-57949", "AdminStudentPerformanceReport", "AdminSPROutputPage" }, priority = 1 )
    public void tcSMAdminSPR001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminSPR001: TC001_Verification of Admin SPR Report Output Page for IP levels<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            ReportOutputComponent reportOutputComponent = new ReportOutputComponent( driver );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.setOrganizationsValue( "Warriors School 2022" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.selectOptionsFromSubjectDropdown( "Math" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickSelectAll( StudentPerformancePage.COURSES );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickRunReport();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.message( "Verify the admin can able to see the next and back button when the report has more then 1 page." );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.message( "Verify the report title displayed on top of the result Page." );
            Log.softAssertThat( reportOutputComponent.getReportPageTitle().trim().equals( "Student Performance" ), "Student Performance Page tile is as expected", "Student Performance Page tile is not as expected" );
            Log.message( "Verify the Back button disabled when the user in 1st page." );
            Log.message( "Verify the report landing on 1 st page of the report when the report has multiple pages." );
            Log.softAssertThat( reportOutputComponent.getCurrentPageNumber().equals( "1" ), "Report landing on 1st page of the report when the report has multiple pages",
                    "Report is not landing on 1st page of the report when the report has multiple pages" );
            Log.softAssertThat( Boolean.FALSE.equals( reportOutputComponent.getTheBackButtonStatus() ), "Back button is disabled", "Back button is not disabled" );
            reportOutputComponent.clickNextBtn();
            Log.softAssertThat( reportOutputComponent.isBackBtnDisplayed(), "Back button is displayed", "Back button is not displayed" );
            Log.softAssertThat( reportOutputComponent.isNextBtnDisplayed(), "Next button is displayed", "Next button is not displayed" );
            Log.softAssertThat( Boolean.TRUE.equals( reportOutputComponent.goToPage( Integer.parseInt( reportOutputComponent.getLastPage() ) - 1 ) ), "Teacher able to traverse to second last page successfully",
                    "Teacher is unable to traverse to second last page successfully" );
            reportOutputComponent.clickNextBtn();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.softAssertThat( Boolean.FALSE.equals( reportOutputComponent.getThNextButtonStatus() ), "Next button is disabled", "Next button is enabled" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Math default course  when the  student cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Math default course  when the  student not cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Math custom by settings IP ON course  when the  student cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Math custom by settings IP ON course  when the  student not cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level as NA, IP Correct as NA ,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Math custom by settings IP OFF course  " );
            Log.message( "" );

            //TODO - Will be doing assertions once the Automation of Admin SPR API call is ready
            Map<String, String> map = reportOutputComponent.getIpLevels();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC002_Verification of Admin SPR Report Output Page for IP levels for Reading", groups = { "SMK-57949", "AdminStudentPerformanceReport", "AdminSPROutputPage" }, priority = 1 )
    public void tcSMAdminSPR002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminSPR002: TC002_Verification of Admin SPR Report Output Page for IP levels<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            ReportOutputComponent reportOutputComponent = new ReportOutputComponent( driver );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.setOrganizationsValue( "Warriors School 2022" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.selectOptionsFromSubjectDropdown( "Reading" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickSelectAll( StudentPerformancePage.COURSES );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickRunReport();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.message( "Verify the admin can able to see the next and back button when the report has more then 1 page." );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.message( "Verify the report title displayed on top of the result Page." );
            Log.softAssertThat( reportOutputComponent.getReportPageTitle().trim().equals( "Student Performance" ), "Student Performance Page tile is as expected", "Student Performance Page tile is not as expected" );
            Log.message( "Verify the Back button disabled when the user in 1st page." );
            Log.message( "Verify the report landing on 1 st page of the report when the report has multiple pages." );
            Log.softAssertThat( reportOutputComponent.getCurrentPageNumber().equals( "1" ), "Report landing on 1st page of the report when the report has multiple pages",
                    "Report is not landing on 1st page of the report when the report has multiple pages" );
            Log.softAssertThat( Boolean.FALSE.equals( reportOutputComponent.getTheBackButtonStatus() ), "Back button is disabled", "Back button is not disabled" );
            reportOutputComponent.clickNextBtn();
            Log.softAssertThat( reportOutputComponent.isBackBtnDisplayed(), "Back button is displayed", "Back button is not displayed" );
            Log.softAssertThat( reportOutputComponent.isNextBtnDisplayed(), "Next button is displayed", "Next button is not displayed" );
            Log.softAssertThat( Boolean.TRUE.equals( reportOutputComponent.goToPage( Integer.parseInt( reportOutputComponent.getLastPage() ) - 1 ) ), "Teacher able to traverse to second last page successfully",
                    "Teacher is unable to traverse to second last page successfully" );
            reportOutputComponent.clickNextBtn();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.softAssertThat( Boolean.FALSE.equals( reportOutputComponent.getThNextButtonStatus() ), "Next button is disabled", "Next button is enabled" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Reading default course  when the  student cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Reading default course  when the  student not cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Reading custom by settings IP ON course  when the  student cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level, IP Correct,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Reading custom by settings IP ON course  when the  student not cleared the IP." );
            Log.message( "Verify the Initial Placement data has IP Level as NA, IP Correct as NA ,IP Attempted, IP Percent Correct, IP Time Spent, Placed date for the Reading custom by settings IP OFF course  " );

            //TODO - Will be doing assertions once the Automation of Admin SPR API call is ready
            Map<String, String> map = reportOutputComponent.getIpLevels();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC003_Verification of Admin SPR Report Output Page for the zero state", groups = { "SMK-57949", "AdminStudentPerformanceReport", "AdminSPROutputPage" }, priority = 2 )
    public void tcSMAdminSPR003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminSPR003: TC003_Verification of Admin SPR Report Output Page for the zero state <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            username = "hb_district_admin_01";
            password = "testing123$";
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            ReportOutputComponent reportOutputComponent = new ReportOutputComponent( driver );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.setOrganizationsValue( "HB_MATH_SCHOOL_SEP" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.selectOptionsFromSubjectDropdown( "Math" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickSelectAll( StudentPerformancePage.COURSES );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickRunReport();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            Log.message( "Verify the admin can able to see the next and back button when the report has more then 1 page." );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.message( "Verify the report title displayed on top of the result Page." );
            Log.softAssertThat( reportOutputComponent.getReportPageTitle().trim().equals( "Student Performance" ), "Student Performance Page tile is as expected", "Student Performance Page tile is not as expected" );
            Log.softAssertThat( Boolean.TRUE.equals( reportOutputComponent.getTheZeroStateOfSPR() ), "Zero state for Admin SPR is as expected", "Zero state for Admin SPR is not as expected" );

            //TODO - Will be doing assertions once the Automation of Admin SPR API call is ready
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC004_Verification of Admin SP for Performance by Strand - Cumulative and Areas For Growth - Since IP section", groups = { "SMK-57949", "AdminStudentPerformanceReport", "AdminSPROutputPage" }, priority = 1 )
    public void tcSMAdminSPR004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminSPR004: TC004_Verification of Admin SP for Performance by Strand - Cumulative and Areas For Growth - Since IP section<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            username = "hb_district_admin_01";
            password = "testing123$";
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            ReportOutputComponent reportOutputComponent = new ReportOutputComponent( driver );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.setOrganizationsValue( "Warriors School 2022" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.selectOptionsFromSubjectDropdown( "Math" );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickSelectAll( StudentPerformancePage.COURSES );
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.clickRunReport();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.message( "Verify the admin can able to see the next and back button when the report has more then 1 page." );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.message( "Verify the report title displayed on top of the result Page." );
            Log.softAssertThat( reportOutputComponent.getReportPageTitle().trim().equals( "Student Performance" ), "Student Performance Page tile is as expected", "Student Performance Page tile is not as expected" );
            Log.softAssertThat( Boolean.TRUE.equals( reportOutputComponent.goToPage( 4 ) ), "Teacher is able to successfully traverse to the desired page", "Teacher is unable to traverse to the desired page" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.message( "Verify the admin can able to see the Performance by Strand - Cumulative data when the student mastered in computation strand for math courses" );
            Log.message( "Verify the admin can able to see the Performance by Strand - Cumulative data when the student mastered in application strand. for Math courses" );
            Log.message( "Verify the Areas of Growth having stand name in strand field , course level in Level field, Skill Description" );
            Log.message( "Verify the 'Performance by Strand-Cumulative' table grid in the 'Student Performance' report for Default Math Assignment" );
            Log.message( "Verify the 'Performance by Strand-Cumulative' table grid in the 'Student Performance' report for 'Custom course by Settings' - Math Assignment" );
            Log.message( "Verify the fields displayed in 'Strand' section" );
            Log.message( "Verify the values displayed with two decimal in the 'Strand Level' section" );
            Log.message( "Verify the values displayed in the 'Skills Mastered' section" );
            Log.message( "Verify the values displayed in the 'Skill Assessed' section" );
            Log.message( "Verify the values displayed in the percentage for 'Percent Skills Mastered' section" );
            Log.message( "Verify the values displayed in the 'Totals' section" );

            Log.softAssertThat( Boolean.TRUE.equals( reportOutputComponent.isPerformanceByStrandCumulativeTitleAsExpected() ), "Title for Performance by Strand is as expected", "Title for Performance by Strand is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidatePerformanceByStrandSection( ReportsUIConstants.COMPUTATION_STRANDS, reportOutputComponent.getperformanceByStrandReportSubHeaderChild() ) == 5, "Size is as expected",
                    "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidatePerformanceByStrandSection( ReportsUIConstants.APPLICATION_STRANDS, reportOutputComponent.getperformanceByStrandReportSubHeaderChild() ) == 5, "Size is as expected",
                    "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.isAreasForGrowthTitleAsExpected(), "The Areas For Growth Title is as expected", "The Areas For Growth Title is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidateAreaForGrowthSection( ReportsUIConstants.SKILLS_IN_DELAYED_PRESENTATION, reportOutputComponent.getAreaForGrowthReportSubHeaderChild() ) == 4, "Size is as expected",
                    "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidateAreaForGrowthSection( ReportsUIConstants.SKILLS_NOT_MASTERED, reportOutputComponent.getAreaForGrowthReportSubHeaderChild() ) == 4, "Size is as expected", "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidateAreaForGrowthSection( ReportsUIConstants.SKILLS_IN_DELAYED_PRESENTATION, reportOutputComponent.buildTableDataLocator( "1" ) ) > 0, "Size is as expected", "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidateAreaForGrowthSection( ReportsUIConstants.SKILLS_IN_DELAYED_PRESENTATION, reportOutputComponent.buildTableDataLocator( "2" ) ) > 0, "Size is as expected", "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidateAreaForGrowthSection( ReportsUIConstants.SKILLS_NOT_MASTERED, reportOutputComponent.buildTableDataLocator( "1" ) ) > 0, "Size is as expected", "Size is not as expected" );
            Log.softAssertThat( reportOutputComponent.toValidateAreaForGrowthSection( ReportsUIConstants.SKILLS_NOT_MASTERED, reportOutputComponent.buildTableDataLocator( "2" ) ) > 0, "Size is as expected", "Size is not as expected" );

            //TODO - Will be doing assertions once the Automation of Admin SPR API call is ready
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC005_Verify the Performance Summary section in 'Student Performance' report", groups = { "SMK-57949", "AdminStudentPerformanceReport", "AdminSPROutputPage" }, priority = 1 )
    public void tcSMAdminSPR005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminSPR005: TC005_Verify the Performance Summary section in 'Student Performance' report<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            username = "hb_district_admin_01";
            password = "testing123$";
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.setOrganizationsValue( "Again Motion Test - Flex" );
            studentPerformancePage.selectOptionsFromSubjectDropdown( "Math" );
            studentPerformancePage.clickSelectAll( studentPerformancePage.COURSES );
            studentPerformancePage.clickRunReport();
            StudentPerformanceOutputPage studentperformanceOutputPage = studentPerformancePage.clickRunBtn();
            SMUtils.nap( 30 );

            SMUtils.logDescriptionTC( "Verify the Performance Summary section in 'Student Performance' report" );
            Log.assertThat( studentperformanceOutputPage.getSectionHeaders().contains( "Performance Summary" ), "Performance Summary Section header is present", "Performance Summary Section header is not present" );
            Log.assertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Level Data" ), "Level Data sub header is present", "Level Data sub header is not present" );
            Log.assertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Instructional Performance" ), "Instructional Performance sub header is present", "Instructional Performance sub header is not present" );
            Log.assertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Mastery" ), "Mastery sub header is present", "Mastery sub header is not present" );
            Log.assertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Support" ), "Support sub header is present", "Support sub header is not present" );
            Log.assertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Usage" ), "Usage sub header is present", "Usage sub header is not present" );

            SMUtils.logDescriptionTC( "Verify the Data in the table displays 'since IP' even though what Date at Risk inputs" );
            Log.assertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Cumulative - Since IP" ), "Cumulative - Since IP text is present", "Cumulative - Since IP text is not present" );

            SMUtils.logDescriptionTC( "Verify the fields displayed in 'Level Data' section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Assigned Course Level" ), "Assigned Course Level field is present under Level data Section", "Assigned Course Level field is not present under Level data Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Current Course Level" ), "Current Course Level field is present under Level data Section", "Current Course Level field is not present under Level data Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "IP Level" ), "IP Level field is present under Level data Section", "IP Level field is not present under Level data Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Gain" ), "Gain field is present under Level data Section", "Gain field is not present under Level data Section" );

            SMUtils.logDescriptionTC( "Verify the values displayed with two decimal in the 'Level Data' section" );
            Log.assertThat( studentperformanceOutputPage.decimal.matcher( studentperformanceOutputPage.getAssignedCourseLevelFieldValues() ).matches(), "Assigned Course Level field values is in Decimal",
                    "Assigned Course Level field values is not in Decimal" );
            Log.assertThat( studentperformanceOutputPage.verifyCurrentCourseLevelFieldValues(), "Current Course Level field values is in Decimal", "Current Course Level field values is not in Decimal" );
            Log.assertThat( studentperformanceOutputPage.verifyIPLevelFieldValues(), "IP Level field values is in Decimal", "IP Level field values is not in Decimal" );
            Log.assertThat( studentperformanceOutputPage.verifyGainFieldValues(), "Gain field values is in Decimal", "Gain field values is not in Decimal" );

            SMUtils.logDescriptionTC( "Verify the fields displayed in 'Instructional Performance' section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Exercises Correct" ), "Exercises Correct field is present under Instructional Performance Section",
                    "Exercises Correct field is not present under Instructional Performance Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Exercises Attempted" ), "Exercises Attempted field is present under Instructional Performance Section",
                    "Exercises Attempted field is not present under Instructional Performance Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Exercises Percent Correct" ), "Exercises Percent Correct field is present under Instructional Performance Section",
                    "Exercises Percent Correct field is not present under Instructional Performance Section" );

            SMUtils.logDescriptionTC( "Verify the values displayed with whole number in 'Instructional Performance' section" );
            Log.assertThat( studentperformanceOutputPage.verifyExercisesCorrectValues(), "Exercises Correct field values is a whole number", "Exercises Correct field values is not a whole number" );
            Log.assertThat( studentperformanceOutputPage.verifyExercisesAttemptedValues(), "Exercises Attempted values is a whole number", "Exercises Attempted field values is not a whole number" );
            Log.assertThat( studentperformanceOutputPage.verifyExercisesPercentCorrectValues(), "Exercises Percent Correct field values is in percentage", "Exercises Percent Correct field values is not in percentage" );

            SMUtils.logDescriptionTC( "Verify the fields displayed in 'Mastery' section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Computation Retention Index (CRI)" ), "Computation Retention Index (CRI) field is present under Mastery Section",
                    "Computation Retention Index (CRI) field is not present under Mastery Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Skills Mastered" ), "Skills Mastered field is present under Mastery Section", "Skills Mastered field is not present under Mastery Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Skills Assessed" ), "Skills Assessed is present under Mastery Section", "Skills Assessed field is not present under Mastery Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Skills Percent Mastered" ), "Skills Percent Mastered field is present under Mastery Section", "Skills Percent Mastered field is not present under Mastery Section" );

            SMUtils.logDescriptionTC( "Verify the values displayed with whole number in 'Mastery' section" );
            Log.assertThat( studentperformanceOutputPage.verifyCRIValues(), "CRI field values is in percentage", "CRI values is not in percentage" );
            Log.assertThat( studentperformanceOutputPage.verifySkillsMasteredValues(), "Skills Mastered field values is a whole number", "Skills Mastered field values is not a whole number" );
            Log.assertThat( studentperformanceOutputPage.verifySkillsAssessedValues(), "Skills Assessed field values is a whole number", "Skills Assessed field values is not a whole number" );
            Log.assertThat( studentperformanceOutputPage.verifySkillsPercentMasteredValues(), "Skills Percent Mastered field values is in percentage", "Skills Percent Mastered field values is not in percentage" );

            SMUtils.logDescriptionTC( "Verify the fields displayed in 'Support' section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Help Used" ), "Help Used field is present under Support Section", "Help Used field is not present under Support Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Audio Repeats Used" ), "Audio Repeats Used field is present under Support Section", "Audio Repeats Used field is not present under Support Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Report Card Views" ), "Report Card Views is present under Support Section", "Report Card Views field is not present under Support Section" );
            Log.assertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Glossary Used" ), "Glossary Used field is present under Support Section", "Glossary Used field is not present under Support Section" );

            SMUtils.logDescriptionTC( "Verify the values displayed with whole number in 'Support' section" );
            Log.assertThat( studentperformanceOutputPage.verifyHelpUsedValues(), "Help Used field values is a whole number", "Help Used values is not a whole number" );
            Log.assertThat( studentperformanceOutputPage.verifyAudioRepeatsUsedValues(), "Audio Repeats Used field values is a whole number", "Audio Repeats Used field values is not a whole number" );
            Log.softAssertThat( studentperformanceOutputPage.verifyReportCardViewsValues(), "Report Card Views field values is a whole number", "Report Card Views field values is not a whole number" );
            Log.assertThat( studentperformanceOutputPage.verifyGlossaryUsedValues(), "Glossary Used field values is a whole number", "Glossary Used field values is not a whole number" );

            SMUtils.logDescriptionTC( "Verify the fields displayed in 'Usage' section" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Time Spent" ), "Time Spent field is present under Usage Section", "Time Spent field is not present under Usage Section" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Total Sessions - minimum of 1 assignment" ), "Total Sessions Used field is present under Usage Section", "Total Sessions field is not present under Usage Section" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPS().contains( "Average Session Time" ), "Average Session Time is present under Usage Section", "Average Session Time field is not present under Usage Section" );

            SMUtils.logDescriptionTC( "Verify the format of the values displayed in 'Usage' section" );
            Log.softAssertThat( studentperformanceOutputPage.verifyTimeSpentFieldValues(), "Time Spent field values is in time format", "Time Spent values is not in time format" );
            Log.softAssertThat( studentperformanceOutputPage.verifyTotalSessionsValues(), "Total Sessions field values is a whole number", "Total Sessions field values is not a whole number" );
            Log.softAssertThat( studentperformanceOutputPage.verifyAverageSessionTimeFieldValues(), "Average Session Time field values is in time format", "Average Session Time field values is not in time format" );

            SMUtils.logDescriptionTC( "Verify the text 'Cumulative - Since IP' displays next to Level Data, Instructional Performance & Mastery sections" );
            Log.softAssertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Cumulative - Since IP" ), "Cumulative - Since IP text is present", "Cumulative - Since IP text is not present" );

            SMUtils.logDescriptionTC( "Verify the text 'Cumulative - Including IP' displays next to Support & Usage sections" );
            Log.softAssertThat( studentperformanceOutputPage.getSPRPSSubTitle().contains( "Cumulative - Including IP" ), "Cumulative - Including IP text is present", "Cumulative - Including IP text is not present" );

            SMUtils.logDescriptionTC( "Verify the admin can able to see the Student full Name in the report header" );
            Log.softAssertThat( !studentperformanceOutputPage.getStudentName().isEmpty(), "Student's Full Name is displayed", "Student's Full Name is not displayed" );
            Log.softAssertThat( !studentperformanceOutputPage.getAssignmentName().isEmpty(), "Assignment Name is displayed", "Assignment Name is not displayed" );
            Log.softAssertThat( studentperformanceOutputPage.verifyReportRunDate(), "Report Run date is in given format", "Report run date is not in given format" );
            Log.softAssertThat( studentperformanceOutputPage.verifyReportInfoText(), "Report Info Text are present", "Report Info Text are not present" );

            SMUtils.logDescriptionTC( "Verify the admin can able to see the Group value as All when the admin did not selected any specific group." );
            Log.softAssertThat( studentperformanceOutputPage.getGroupValue().equalsIgnoreCase( "ALL" ), "Group is dispalyed as All", "Group is not dispalyed as All" );

            SMUtils.logDescriptionTC( "Verify the admin can able to see the number of pages in pagination (top right corner) when the report has mulatiple pages." );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.verifyPaginationText(), "Paginations are present in report output page", "Paginations are not present in report output page" );

            //TODO - Will be doing assertions once the Automation of Admin SPR API call is ready
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC006_Verify the Performance Summary section in 'Student Performance' report", groups = { "SMK-57949", "AdminStudentPerformanceReport", "AdminSPROutputPage" }, priority = 1 )
    public void tcSMAdminSPR006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminSPR006: TC006_Verify the Performance Summary section in 'Student Performance' report<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            username = "hb_district_admin_01";
            password = "testing123$";
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();
            studentPerformancePage.setOrganizationsValue( "SJ Regression Flex School" );
            studentPerformancePage.selectOptionsFromSubjectDropdown( "Math" );
            studentPerformancePage.clickSelectAll( studentPerformancePage.COURSES );
            studentPerformancePage.clickRunReport();
            StudentPerformanceOutputPage studentperformanceOutputPage = studentPerformancePage.clickRunBtn();
            SMUtils.nap( 10 );

            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.getReportPageTitle().equals( ReportsUIConstants.SPR_PAGE_TITLE ), "Student Performance page title is displayed successfully!!!",
                    "Student Performance page title is not displayed properly" );

            Log.testCaseInfo( "Verify the user able to copy and paste the page number in 'Go to' textbox" );
            Log.testCaseInfo( "Verify the user able to navigate to corresponding page entered" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.goToPage( 3 ), "Page number is entered and navigated to that page", "Unable to enter or navigate to the given page number" );

            Log.testCaseInfo( "Verify the message 'Number Only' appears when no value entered in 'Go to' textbox" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.goToPageNonNumber( "abc" ), "Numbers Only should be appeared on bottom of the  Go to textbox field",
                    "Numbers Only should be appeared on bottom of the Go to textbox is not displayed" );

            Log.testCaseInfo( "Verify the message 'Invalid' appears when not available page number value is entered in 'Go to' textbox" );
            Log.testCaseInfo( "Verify the user is not navigating to other pages when invalid / not available page number is given in the textbox" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.goToPageInvalidNumber( 1000 ), "Invalid Only should be appeared on bottom of the  Go to textbox field",
                    "Invalid Only should be appeared on bottom of the Go to textbox is not displayed" );

            Log.testCaseInfo( "Verify the message 'Required' appears on bottom of the 'Go to' textbox when no value is entered" );

            Log.testCaseInfo( "Verify the 'Next' & 'Back' button is available in the pagination section" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.isBackBtnDisplayed(), "Back button is available", "Back button is not available" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.isNextBtnDisplayed(), "Next button is available", "Next button is not available" );

            Log.testCaseInfo( "Verify the pagination section displays with the text 'Go to', text box to enter page number and total pages available" );
            Log.testCaseInfo( "Verify the 'Back' button is enabled and 'Next' button is disabled when it reached last page of the report" );
            studentperformanceOutputPage.reportOutputComponent.goToPage( 1 );
            studentperformanceOutputPage.reportOutputComponent.goToPage( studentperformanceOutputPage.reportOutputComponent.totalPageNo() );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.isDisableOrEnableBtn( "disable", "Next" ), "Next button is enabled", "Next button is not enabled" );

            Log.testCaseInfo( "Verify the 'Next' & 'Back' button is not clickable when its disabled" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.clickNextBtn(), "Next button is clickable", "Next button is not clickable" );
            studentperformanceOutputPage.reportOutputComponent.goToPage( 1 );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.clickBackBtn(), "Back button is clickable", "Back button is not clickable" );

            Log.testCaseInfo( "Verify the pagination section displays with the text 'Go to', text box to enter page number and total pages available" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.verifyPaginationText(), "Pagination is displaying as expected", "Pagination is not displaying as expected" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.isdisableBackBtn(), "Back button is disabled", "Back button is not disabled" );
            Log.softAssertThat( studentperformanceOutputPage.reportOutputComponent.isenableNextBtn(), "Next button is enabled", "Next button is not enabled" );

            Log.testCaseInfo( "Verify the 'Performance by Strand - Cumulative' section in 'Student Performance' report for Reading subject" );
            Log.softAssertThat( studentperformanceOutputPage.verifyStrandLabels(), "Performance by Strand - Cumulative header is displayed successfully!!!", "Performance by Strand - Cumulative header is not displayed properly" );

            Log.testCaseInfo( "Verify the 'Performance by Strand - Cumulative' section in 'Student Performance' report for Math subject" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "Strand" ).contains( "Computation Strands" ), "Computation Strands is displayed successfully!!!", "Computation Strands is not displayed properly" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "Strand" ).contains( "Application Strands" ), "Application Strands is displayed successfully!!!", "Application Strands is not displayed successfully!!!" );

            Log.testCaseInfo( "Verify the columns available in 'Computation Strands' section in 'Student Performance' report  for Math subject" );
            Log.testCaseInfo( "Verify the columns available in 'Application Strands' section in 'Student Performance' report for Math subject" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "cStrandsubheader" ).contains( "Strand" ), "Strand column is displayed successfully!!!", "Strand column is not displayed properly" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "cStrandsubheader" ).contains( "Strand Level" ), "Strand Level column is displayed successfully!!!", "Strand Level column is not displayed successfully!!!" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "cStrandsubheader" ).contains( "Skills Mastered" ), "Skills Mastered column is displayed successfully!!!", "Skills Mastered column is not displayed successfully!!!" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "cStrandsubheader" ).contains( "Skills Assessed" ), "Skills Assessed column is displayed successfully!!!", "Skills Assessed column is not displayed successfully!!!" );
            Log.softAssertThat( studentperformanceOutputPage.getFieldNamesPBS( "cStrandsubheader" ).contains( "Percent Skills Mastered" ), "Percent Skills Mastered column is displayed successfully!!!",
                    "Percent Skills Mastered column is not displayed successfully!!!" );
            Log.testCaseInfo( "Verify the 'Other Performance' section is not displaying under Areas for Growth section in 'Student Performance' report for Math subject" );
            Log.softAssertThat( studentperformanceOutputPage.getOtherPerformanceText(), "OtherPerformance Section is not available in report as expected", "OtherPerformance Section is not available in report" );

            //TODO - Will be doing assertions once the Automation of Admin SPR API call is ready
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
