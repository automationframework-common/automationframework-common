package com.savvas.sm.reports.api.tests;

import org.testng.annotations.Test;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.*;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;

public class TeacherAFG {

	SMAPIProcessor smAPIprocessor;
	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	public RBSUtils rbsUtils = new RBSUtils();
	private Response response;
	HashMap<String, String> userDetail = new HashMap<>();
	String payload;
	String userName;
	String password;
	String weeks;
	String subject;
	String bearerToken;
	String studentUserid;
	Map<String, String> headers = new HashMap<>();
	RBSUtils rbs = new RBSUtils();
	List<String> studentUserids = new ArrayList<>();
	private String smUrl;
	String studentDetails = null;
	List<String> studentIds;
	String studentUserName;
	String schoolAdminDetails = null;
	String schoolAdminUserName;
	String schoolAdminUserId;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String teacherDetails = null;
	String teacherId;
	String orgId;
	String teacherUsername;
	String assignmentId;
	String assignmentIdReading;

	@BeforeTest
	public void BeforeTest() {
		
		smUrl = configProperty.getProperty("SMAppUrl").trim();
		String envUrl = smUrl.substring(8); // To take out the https:// from the host
		String usernameSuffix = envUrl.split("\\.")[0];
		String usernameSuffixTest = usernameSuffix.replaceAll("[^a-zA-Z0-9]", "");
		teacherUsername = String.format(configProperty.getProperty(ConfigConstants.TEACHER_USERNAME), 5, 1,
				usernameSuffixTest);
		teacherDetails = ReportData.teacherDetails.get(teacherUsername);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		orgId = ReportData.orgId;
		List<String> studentIds = new ArrayList<>(
				ReportData.defaultMathAssignmentDetails.get(teacherUsername).keySet());
		assignmentId = ReportData.defaultMathAssignmentDetails.values().stream().map(assignmentDetails -> {
			String assignmentdetail = assignmentDetails.values().stream()
					.filter(assignment -> Objects.nonNull(SMUtils.getKeyValueFromResponse(assignment, "assignmentId")))
					.findFirst().orElse(null);
			return SMUtils.getKeyValueFromResponse(assignmentdetail, "assignmentId");

		}).collect(Collectors.toList()).toString().replace("[", "").replace("]", "").replace(" ", "");

		List<String> studentIds1 = new ArrayList<>(ReportData.defaultReadingAssignmentDetails.get(teacherUsername).keySet());
        assignmentIdReading=ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" ); 
            
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
	}

	@Test(priority = 1, dataProvider = "PositiveScenarios",groups= {"SmokeTest"})
	public void testAFGPositiveReportAPI(String testcaseId, String description, String statusCode, String scenario)
			throws Exception {
		Log.testCaseInfo(testcaseId + ":-" + description);
		payload = ReportAPIConstants.TeacherAFG.TEACHER_AFG_API_PAYLOAD;
		Log.message(payload);

		switch (scenario) {
		case "VALID_HEADERS_AUTHORIZATION_AND_PAYLOAD":
			Log.message("Case 1");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);

			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "ALL_REQUEST_PARAMS":
			Log.message("Case 2");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);

			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "VALID_STUDENT_IDS":
			Log.message("Case 3");

			String[] split = studentIds.toString().replace("[", "").replace("]", "").replace(" ", "").replace("\"", "")
					.split(",");
			String orgIds = "";
			for (String id : split) {
				if (orgIds.isEmpty()) {
					orgIds = "\"" + id + "\"";
				} else {
					orgIds = orgIds + ",\"" + id + "\"";
				}
			}
			payload = String.format(payload, orgIds);
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "VALID_MATH_SUBJECT_ID":
			Log.message("Case 4");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", "ffffffff62fdccd6d91403002e13e19b");
			headers.put("org-id", "8a7200af7f2c9d1b017f45c3000e04f9");
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "VALID_READING_SUBJECT_ID":
			Log.message("Case 5");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "2")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentIdReading);
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "ORDER_BY_VALUE":
			Log.message("Case 6");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId);
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "ASSIGNMENT_IDS":
			Log.message("Case 7");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId);
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		case "NO_AFG_DATA":
			Log.message("Case 8");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId + "invalid");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			validateResponseWithDB(response.getBody().asString());
			break;

		}
		// Verifying Status Code
		if (scenario.equalsIgnoreCase("VALID_READING_SUBJECT_ID") || scenario.equalsIgnoreCase("ASSIGNMENT_IDS")) {

			Log.assertThat(response.getStatusCode() == 200,
					"The actual status code " + response.getStatusCode() + " is the same as expected status code "
							+ statusCode,
					"The actual status code " + response.getStatusCode() + " is not the same as expected status code "
							+ statusCode);
			// Verifying schema in the Response body
			Log.assertThat(
					new SMAPIProcessor().isSchemaValid("AFG_Reading_Teacher_Schema", statusCode,
							response.getBody().asString()),
					"Schema is returned as expected.", "Schema is not as expected.");
		} else

		{
			Log.assertThat(response.getStatusCode() == 200,
					"The actual status code " + response.getStatusCode() + " is the same as expected status code "
							+ statusCode,
					"The actual status code " + response.getStatusCode() + " is not the same as expected status code "
							+ statusCode);
			// Verifying schema in the Response body
			Log.assertThat(
					new SMAPIProcessor().isSchemaValid("AFG_Math_Teacher_Schema", statusCode,
							response.getBody().asString()),
					"Schema is returned as expected.", "Schema is not as expected.");
		}
	}

	@Test
	@DataProvider(name = "PositiveScenarios")
	public Object[][] testPositiveScenario() {

		Object[][] inputData = { { "tc_AFGBFF001",
				"Verify 200 status code and response body when valid headers, authorization and payload are provided",
				CommonAPIConstants.STATUS_CODE_OK, "VALID_HEADERS_AUTHORIZATION_AND_PAYLOAD" },
				{ "tc_AFGBFF003",
						"Verify 200 status code and response body when valid headers, authorization and all request params in the payload are provided",
						CommonAPIConstants.STATUS_CODE_OK, "ALL_REQUEST_PARAMS" },
				{ "tc_AFGBFF010	",
						"Verify 200 status code and response body when valid student-ids[Student having test data for AOD] are provided in the request params",
						CommonAPIConstants.STATUS_CODE_OK, "VALID_STUDENT_IDS" },
				{ "tc_AFGBFF011",
						"Verify 200 status code and no data found message in the response body when students-id with no AOD data is provided in the request params",
						CommonAPIConstants.BAD_REQUEST_EXCEPTION, "NO_AFG_DATA" },
				{ "tc_AFGBFF013 ",
						"Verify 200 status code and response and Math response body when subjectId is provided with 1",
						CommonAPIConstants.STATUS_CODE_OK, "VALID_MATH_SUBJECT_ID" },
				{ "tc_AFGBFF014 ",
						"Verify 200 status code and response and Reading response body when subjectId is provided with 2",
						CommonAPIConstants.STATUS_CODE_OK, "VALID_READING_SUBJECT_ID" },
				{ "tc_AFGBFF018", "Verify the response is sorted in order with respect to orderBy value is provided",
						CommonAPIConstants.STATUS_CODE_OK, "ORDER_BY_VALUE" },
				{ "tc_AFGBFF019", "Verify 200 status code and response body when valid assignmentId are provided",
						CommonAPIConstants.STATUS_CODE_OK, "ASSIGNMENT_IDS" },

		};
		return inputData;
	}

	@Test(priority = 2, dataProvider = "NegativeScenarios")
	public void testAFGNegativeReportAPI(String testcaseId, String description, String scenario, String statusCode)
			throws Exception {
		Log.testCaseInfo(testcaseId + ":-" + description);
		payload = ReportAPIConstants.TeacherAFG.TEACHER_AFG_API_PAYLOAD;
		Log.message(payload);

		switch (scenario) {
		case "INVALID_PAYLOAD":
			Log.message("Case 1");
			payload = String.format(payload + "invalid", studentIds.get(0));
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			break;

		case "INVALID_ASSIGNMENT_ID":
			Log.message("Case 10");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "2")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			break;

		case "INVALID_AUTHORIZATION":
			Log.message("Case 2");
			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken + "1");
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			break;

		case "INVALID_SUBJECT_ID":
			Log.message("Case 3");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "5")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			;
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			break;

		case "NO_WEEK_PROVIDED":
			Log.message("Case 5");

			payload = String.format(payload, "\"" + studentIds.get(0) + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "1")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "")
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId);
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			break;

		case "NO_SUBJECT_ID":
			Log.message("Case 3");

			payload = String.format(payload, "\"" + studentUserid + "\"");
			bearerToken = rbs.getAccessToken(userName, password);
			headers.put("user-id", teacherId);
			headers.put("org-id", orgId);
			headers.put("Authorization", "Bearer " + bearerToken);
			payload = payload.replace(ReportAPIConstants.TeacherAFG.subject, "")
					.replace(ReportAPIConstants.TeacherAFG.weeks, "24")
					.replace(ReportAPIConstants.TeacherAFG.assignmentId, assignmentId)
					.replace(ReportAPIConstants.TeacherAFG.orderBy, "LO_DESCRIPTION");
			Log.message("My payload is" + payload);
			response = getResponse(userName, password);
			Log.message(response.getBody().asString());
			break;

		}
		// Verifying Status Code
		Log.assertThat(response.getStatusCode() == Integer.parseInt(statusCode),
				"The actual status code " + response.getStatusCode() + " is the same as expected status code "
						+ statusCode,
				"The actual status code " + response.getStatusCode() + " is not the same as expected status code "
						+ statusCode);

		// Verifying schema in the Response body
		if (scenario.equalsIgnoreCase("NO_AFG_DATA")) {
			Log.assertThat(response.getBody().asString().contains(ReportsAPIConstants.BAD_REQUEST_400),
					"Message displayed as expected", "Message not displayed as expected");
		}
		Log.testCaseResult();
	}

	@Test
	@DataProvider(name = "NegativeScenarios")
	public Object[][] testNegativeScenario() {

		Object[][] inputData = {

				{ "tc_AFGBFF004",
						"Verify 400 status code and response body when invalid payload is provided in the request payload",
						"INVALID_PAYLOAD", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "tc_AFGBFF005",
						"Verify 401 status code and response body when invalid authorization is provided in the headers",
						"INVALID_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
				{ "tc_AFGBFF012",
						"Verify 200 status code and Math  response body when no subject ID is provided in the request params",
						"NO_SUBJECT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "tc_AFGBFF015", "Verify 400 status code and response body when invalid subjectId is provided",
						"INVALID_SUBJECT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "tc_AFGBFF020", "Verify 200 status code and response body when invalid assignmentIds are provided",
						"INVALID_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
				{ "tc_AFGBFF021", "Verify 400 status code and response body when week is not provided",
						"NO_WEEK_PROVIDED", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

		};
		return inputData;
	}

	public Response getResponse(String userName, String password) throws Exception {

		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		String endPoint = "https://nightly-next-basic.smdemo.info/teacher-reports/report/aodreport";
		Response response = RestAssuredAPIUtil.POST(endPoint, headers, payload, "");
		Log.message(response.getBody().asString());
		Log.message("Response" + response.getBody().asString());
		return response;
	}

	@Test
	public Boolean validateResponseWithDB(String response) {

		String assignmentId = "78761";
		Map<String, Map<String, String>> skillDetails = new HashMap<>();
		Boolean result = false;
		try {

			String query = "SELECT DISTINCT lrfs.assignment_user_id,\r\n" + "                au.person_id,\r\n"
					+ "            st.strand_description AS cttype_name,     \r\n"
					+ "            slo.learning_object_id as object_id,     \r\n"
					+ "            (SELECT lrt.lo_review_type_name FROM math_lo_review_type lrt         \r\n"
					+ "                WHERE lrfs.lo_review_type_id = lrt.lo_review_type_id ) AS lo_review_type_name,     \r\n"
					+ "            slo.strand_lo_level AS strand_level,         \r\n"
					+ "            (SELECT lo.lobj_description FROM learning_object lo         \r\n"
					+ "                WHERE slo.learning_object_id = lo.learning_object_id ) AS skill_obj_description,        \r\n"
					+ "            lrfs.lo_review_fail_timestamp AS mastery_status_date,         \r\n"
					+ "            (SELECT lo.catalog_num FROM learning_object lo         \r\n"
					+ "                WHERE slo.learning_object_id = lo.learning_object_id ) AS catalog_num,        \r\n"
					+ "            (SELECT tl.targeted_lesson_number FROM targeted_lesson tl             \r\n"
					+ "                WHERE tl.targeted_lesson_id = (Select tllo.targeted_lesson_id from targeted_lesson_learning_object tllo where tllo.learning_object_id = slo.learning_object_id ) ) as lesson_number,         (SELECT tl.targeted_lesson_title FROM targeted_lesson  tl              WHERE tl.targeted_lesson_id = (Select tllo.targeted_lesson_id from targeted_lesson_learning_object tllo where tllo.learning_object_id = slo.learning_object_id ) ) as lesson_title  FROM math_strand st, math_lo_review_fail lrfs,         math_strand_learning_object slo,         assignment_user au,         assignment a WHERE     au.isdeleted = 0     AND EXISTS ( SELECT content_base_id FROM content_base cb         WHERE a.content_base_id = cb.content_base_id         AND cb.subject_id = 1 AND cb.content_type_base_id < 3 )         AND lrfs.lo_review_type_id =1         AND au.assignment_user_id = lrfs.assignment_user_id         AND au.assignment_id = a.assignment_id         AND lrfs.learning_object_id = slo.learning_object_id         AND slo.strand_id = st.strand_id    \r\n"
					+ "                    AND lrfs.lo_review_fail_timestamp IN\r\n"
					+ "                                (SELECT lo_review_fail_timestamp FROM math_lo_review_fail loah WHERE\r\n"
					+ "                                        loah.assignment_user_id = au.assignment_user_id)     \r\n"
					+ "                                            AND au.assignment_id = '{assignmentId}'";

			query = query.replace("{assignmentId}", assignmentId);
			List<Object[]> listItems = SQLUtil.executeQuery(query);
			Log.message(listItems.toString());

			Map<String, Map<String, String>> dataFromApiResponse = getDataFromApiResponse(response);

			for (int itr = 0; itr < listItems.size(); itr++) {

				Map<String, String> skillDetail = new HashMap<>();
				skillDetail.put("Level", listItems.get(itr)[5].toString());
				skillDetail.put("skill description", listItems.get(itr)[6].toString());
				skillDetail.put("catalog num", listItems.get(itr)[8].toString());
				skillDetail.put("Date at risk", listItems.get(itr)[7].toString());
				skillDetail.put("person Id", listItems.get(itr)[1].toString());
				if (Objects.nonNull(listItems.get(itr)[9])) {
					skillDetail.put("lesson number", listItems.get(itr)[9].toString());
					skillDetail.put("lesson title", listItems.get(itr)[10].toString());
				} else {
					skillDetail.put("lesson number", "");
					skillDetail.put("lesson title", "");
				}
				String studentLo = skillDetail.get("person Id") + "-" + skillDetail.get("Level") + " - "
						+ skillDetail.get("skill description");
				skillDetails.put(studentLo, skillDetail);

				result = SMUtils.compareTwoHashMap(dataFromApiResponse.get(studentLo), skillDetails.get(studentLo));

			}
			;
			Log.message("DB VALUE: " + skillDetails.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	private Map<String, Map<String, String>> getDataFromApiResponse(String responseBody) {
		// Getting data from response
		String rowCount = SMUtils.getKeyValueFromResponse(responseBody, "totalNoOfRows");
		Map<String, Map<String, String>> studentReportDetails = new HashMap<>();

		IntStream.range(0, Integer.parseInt(rowCount)).forEach(iter -> {
			JSONObject stdJson = new JSONObject(
					new JSONArray(SMUtils.getKeyValueFromResponse(responseBody, "rows")).get(iter));
			Log.message(stdJson.toString());
			HashMap<String, String> studentReport = new HashMap<>();
			studentReport.put("Level", stdJson.get("strandLevel").toString());
			studentReport.put("skill description", stdJson.get("loDescription").toString());
			studentReport.put("catalog num", stdJson.get("catalogNum").toString());
			studentReport.put("Date at risk", stdJson.get("failedDate").toString());
			studentReport.put("person Id", stdJson.get("personId").toString());
			if (Objects.nonNull(stdJson.get("lessonNumber").toString())) {
				studentReport.put("lesson number", stdJson.get("lessonNumber").toString());
				studentReport.put("lesson title", stdJson.get("lessonTitle").toString());
			} else {
				studentReport.put("lesson number", "");
				studentReport.put("lesson title", "");
			}
			studentReportDetails.put(stdJson.get("personId").toString() + "-" + stdJson.get("strandLevel") + "-"
					+ stdJson.getDouble("loDescription"), studentReport);
		});
		Log.message("Response Data: " + studentReportDetails);
		return studentReportDetails;
	}



}
