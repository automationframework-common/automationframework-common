package com.savvas.sm.reports.ui.pages;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.LastSessionConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.SEUReportConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.IFindBy;

public class RecentSessionsOutputPage extends LoadableComponent<RecentSessionsOutputPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportOutputComponent reportOutputComponent;

    // ********* SuccessMaker Launcher/Login Page Elements ***************

    @FindBy ( css = "report-viewer-header h2" )
    WebElement pageTitle;

    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportButtonRoot;

    @FindBy ( css = "div.pl-0 .list-head" )
    WebElement headerLegend;

    @FindBy ( css = "dl.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;

    @FindBy ( css = "dl.detail-row.info > dd:nth-child(2)" )
    WebElement schoolName;

    @FindBy ( css = "dl.detail-row.info > dd:nth-child(4)" )
    WebElement teacherName;

    @FindBy ( css = "dl.detail-row.info > dd:nth-child(6)" )
    WebElement grade;

    @FindBy ( css = "dl.detail-row.info > dd:nth-child(8)" )
    WebElement groupName;

    @FindBy ( css = "div span.pagination-text-suffix" )
    WebElement pageNumber;

    @FindBy ( css = "div h3" )
    WebElement assignment;
    // Recent Session Report Grid

    @FindBy ( css = "tr.header th" )
    List<WebElement> reporttabletitle;

    @FindBy ( css = "tr.sub-header th" )
    List<WebElement> reporttablesubtitle;

    @FindBy ( css = "tr td.foot" )
    List<WebElement> lasttworow;

    @FindBy ( css = "p.table-note" )
    WebElement endtablenotes;

    @FindBy ( css = "tr td:nth-of-type(2)" )
    List<WebElement> currentcourselevelrow;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement clickNextButton;

    @FindBy ( css = "cel-button.back-btn" )
    WebElement clickBackButton;

    @FindBy ( css = "ul li" )
    List<WebElement> selectedOptions;

    @FindBy ( css = "dd.label-value" )
    WebElement selectedOptionsDemographic;

    @FindBy ( css = "section div div div.col-3:nth-of-type(3)" )
    WebElement legend;

    @FindBy ( css = "p.table-note" )
    WebElement endTableNotes;

    @FindBy ( css = "table tbody tr " )
    List<WebElement> gridValues;

    @FindBy ( css = "table tfoot tr:nth-of-type(1)" )
    List<WebElement> meanValues;

    @FindBy ( css = "table tfoot tr:nth-of-type(2)" )
    List<WebElement> standardDeviationValues;

    @FindBy ( css = "table.report-viewer-grid" )
    WebElement reportTable;
    
    @IFindBy ( how = How.CSS, using = "div.error p.header", AI = false )
    WebElement errorMessage;

    @FindBy ( css = "export-pdf-modal cel-modal.export-pdf-modal" )
    WebElement exportPDFs;
    
    @FindBy ( css = "export-data-modal cel-modal.export-data-modal" )
    WebElement exportCSV;
    
    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement assignmentName;
    
    @FindBy ( css = ".ml-3.detail-row > dd" )
    WebElement reportRunDate;
    
    @FindBy ( css = ".info > dd:nth-of-type(3)" )
    WebElement gradesSelected;
    
    @FindBy ( css = ".info > dd:nth-of-type(4)" )
    WebElement groupsSelected;
    
    @FindBy ( css = "ul.selected-options" )
    List<WebElement> headerLegend1;

    @FindBy ( css = "div > div:nth-child(3) > span" )
    WebElement headerLegendValue;

    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> valuesSelectedOptions;
    
    @FindBy ( css = "section > report-grid > div > p" )
    List<WebElement> notesLabels;
    
    // ****Child Elements****
    private String button = "button.button";
    private String runButton = "button";
    String columnValue = "td:nth-of-type(%s)";
    String currentCourseLevel = "//div[contains(text(), '%s')]";
    String parentCurrentCourseLevel = "/parent::td/following-sibling::td[%s]";
    String tabledata = "td";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public RecentSessionsOutputPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportOutputComponent = new ReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 60 ) && verifiedLegendField() ) {
            Log.message( "Recent Sessions Report output Page loaded successfully." );
        } else {
            Log.fail( "Recent Sessions Report output Page not loaded successfully." );
        }

    }

    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabels() {
        Log.message( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if ( SMUtils.waitForElement( driver, headerLegend ) ) {
            Log.assertThat( SMUtils.getTextOfWebElement( headerLegend, driver ).equals( ReportsUIConstants.LEGEND_HEADER ), "Legend header is displayed successfully!!!", "Legend header is not displayed" );
            Log.assertThat( IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS.get( itr ) ) ), "All the labels of the legend are displayed",
                    "All the labels of the legend are not displayed" );
            Log.assertThat( IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_VALUES.get( itr ) ) ),
                    "All the label values of the legend are displayed", "All the label values of the legend are not displayed" );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }

    /**
     * To get Recent Sessions Report Table page header
     * 
     * @return
     */
    public List<String> getReportTableTitle() {
        Log.message( "Getting Recent Session Report Table Title" );
        SMUtils.waitForElement( driver, endtablenotes );
        return reporttabletitle.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Recent Sessions Report Table page sub header
     * 
     * @return
     */
    public List<String> getReportTableSubTitle() {
        Log.message( "Getting Recent Session Report Table sub Title" );
        SMUtils.waitForElement( driver, endtablenotes );
        return reporttablesubtitle.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Recent Sessions Report Table page last two row
     * 
     * @return
     */
    public List<String> getLastTwoRow() {
        Log.message( "Getting the last two row of Mean - 8 Students and Standard Deviation" );
        SMUtils.waitForElement( driver, endtablenotes );
        return lasttworow.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Recent Sessions Report Table page notes
     * 
     * @return
     */
    public String getReportTableNotes() {
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, endtablenotes );
        return endtablenotes.getText().trim();
    }

    /**
     * To get Last Sessions Report selected Organization Name
     * 
     * @return
     */
    public String getOrganization() {
        SMUtils.nap( 3 );
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, schoolName );
        return schoolName.getText().trim();
    }

    /**
     * To get Last Sessions Report selected Teacher Name
     * 
     * @return
     */
    public boolean getSelectedTeacher() {
        SMUtils.nap( 3 );
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, teacherName );
        return teacherName.isDisplayed();
    }

    /**
     * To get Last Sessions Report selected Grade
     * 
     * @return
     */
    public boolean getSelectedGrade() {
        SMUtils.nap( 3 );
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, grade );
        return grade.isDisplayed();
    }

    /**
     * To get Last Sessions Report selected Group Name
     * 
     * @return
     */
    public boolean getSelectedGroup() {
        SMUtils.nap( 3 );
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, groupName );
        return groupName.isDisplayed();
    }

    /**
     * To get Last Sessions Report selected Group Name
     * 
     * @return
     */
    public boolean verifiedLegendField() {
        SMUtils.nap( 3 );
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, legend, 60 );
        return legend.isDisplayed();
    }

    /**
     * To get Last Sessions Report selected option Additional Grouping field
     * 
     * @return
     */
    public String getSelectedAdditionalGrouping() {
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Log.message( "Getting Recent Session Report Additional Grouping field" );
        return selectedOptions.get( 0 ).getText().trim();
    }

    /**
     * To get Last Sessions Report selected option Sort field
     * 
     * @return
     */
    public String getSelectedSortOption() {
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Log.message( "Getting Recent Session Report Sort Option field" );
        return selectedOptions.get( 1 ).getText().trim();
    }

    /**
     * To get Last Sessions Report selected option Student Demographic field
     * 
     * @return
     */
    public String selectedOptionDemographic() {
        Log.message( "Getting Recent Session Report Student Demographic field" );
        return selectedOptions.get( 5 ).getText().trim();
    }

    /**
     * Verify the Last Sessions Report selected Student Demographic value
     * 
     * @return
     */
    public boolean getDemographicValue() {
        return selectedOptionsDemographic.isDisplayed();
    }

    /**
     * To get Last Sessions Report total page number
     * 
     * @return
     */
    public int getPageNumber() {
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        String textOfPage = pageNumber.getText().trim();
        StringBuffer sb = new StringBuffer( textOfPage );
        StringBuffer delete = sb.delete( 0, 2 );
        String page = delete.toString().trim();
        int pagenumber = Integer.parseInt( page );
        return pagenumber;

    }

    /**
     * To get Last Sessions Report Assignment Name
     * 
     * @return
     */
    public boolean getAssignmentName() {

        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        for ( int i = 1; i <= getPageNumber(); i++ ) {
            SMUtils.isElementPresent( assignment );
            SMUtils.getWebElement( driver, clickNextButton, button ).click();

        }
        return true;

    }

    /**
     * To get Last Sessions Report Teacher Name
     * 
     * @return
     */
    public Set<String> getTeachertName() {
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Set<String> outputTeacherName = new LinkedHashSet<String>();
        for ( int i = getPageNumber(); i >= 1; i-- ) {
            String textOfWebElement = teacherName.getText().trim();
            outputTeacherName.add( textOfWebElement );
            SMUtils.getWebElement( driver, clickBackButton, button ).click();

        }
        return outputTeacherName;

    }

    /**
     * To get Last Sessions Report Group Name
     * 
     * @return
     */
    public Set<String> getGroupName() {
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Set<String> outputGroupName = new LinkedHashSet<String>();
        for ( int i = getPageNumber(); i >= 1; i-- ) {
            String textOfWebElement = groupName.getText().trim();
            outputGroupName.add( textOfWebElement );
            SMUtils.getWebElement( driver, clickBackButton, button ).click();

        }
        return outputGroupName;

    }

    /**
     * To get Last Sessions Report Grade
     * 
     * @return
     */
    public Set<String> getGrade() {
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Set<String> outputGrade = new LinkedHashSet<String>();
        for ( int i = getPageNumber(); i >= 1; i-- ) {
            String textOfWebElement = grade.getText().trim();
            outputGrade.add( textOfWebElement );
            SMUtils.getWebElement( driver, clickBackButton, button ).click();

        }
        return outputGrade;

    }

    /**
     * To get Recent Sessions Report Table page current course level row
     * 
     * @return
     */
    public List<String> getCurrentCourseLevelRow() {
        Log.message( "Getting Recent Session Report Current Course Level Row " );
        SMUtils.waitForElement( driver, endtablenotes );
        return currentcourselevelrow.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    /**
     * To Click Run Report Button
     */
    public void clickRunReportButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, runReportButtonRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, runReportButtonRoot, runButton ) );
            Log.message( "Clicked Run Report Button!" );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );

        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Clicked Run Report Button Failed" );

        }
    }

    /**
     * To get Mean value from UI
     * 
     * @return
     */
    public String getMeanValue( String columnName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        List<String> meanValue = new ArrayList<>();
        meanValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.indexOf( columnName ) + 2 ) ) );
            meanValue.add( columnData.get( 0 ).getText().trim() );
        } );
        return meanValue.get( 0 );

    }

    /**
     * To get Standard Deviation value from UI
     * 
     * @return
     */

    public String getStandardDeviationValue( String columnName ) {
        SMUtils.waitForElement( driver, endTableNotes );
        List<String> meanValue = new ArrayList<>();
        standardDeviationValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.indexOf( columnName ) + 2 ) ) );
            meanValue.add( columnData.get( 0 ).getText().trim() );
            SMUtils.nap( 4 );
        } );
        return meanValue.get( 0 );

    }

    /**
     * To verify the Mean Value
     * 
     * @return
     */
    public boolean totalColumnvaluesCompareMeanValue( String columnName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        List<Double> columnValueList = new ArrayList<>();
        SMUtils.nap( 10 );// To wait until spinner disappear.
        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.indexOf( columnName ) + 2 ) ) );
            IntStream.range( 0, columnData.size() ).forEach( itr -> {

                columnValueList.add( Double.parseDouble( columnData.get( itr ).getText().trim() ) );

            } );
        } );
        double sum = columnValueList.stream().collect( Collectors.summingDouble( Double::doubleValue ) );
        Double totalColumnValue = sum / columnValueList.size();
        String totalValue = new DecimalFormat( "0.00" ).format( totalColumnValue );
        return totalValue.equals( getMeanValue( columnName ) );

    }

    /**
     * To verify the Standard Deviation Value
     * 
     * @return
     */
    public boolean totalColumnvaluesCompareStandardDeviationValue( String columnName ) {

        SMUtils.waitForElement( driver, endTableNotes );
        List<Double> columnValueList = new ArrayList<>();
        double sum = 0.0;
        double standardDeviation = 0.0;
        double mean = 0.0;
        double sq = 0.0;
        double res = 0.0;
        String totalValue;
        SMUtils.nap( 5 );// To wait until spinner disappear.
        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.LastSessionConstants.GRID_SUB_HEADER.indexOf( columnName ) + 2 ) ) );
            int size = columnData.size();
            for ( int i = 0; i < size; i++ ) {

                columnValueList.add( Double.parseDouble( columnData.get( i ).getText().trim() ) );

            }
        } );

        int size = columnValueList.size();
        for ( int i = 0; i < size; i++ ) {

            sum = sum + columnValueList.get( i );
        }
        mean = sum / ( size );
        for ( int i = 0; i < size; i++ ) {
            standardDeviation = standardDeviation + Math.pow( ( columnValueList.get( i ) - mean ), 2 );
        }

        sq = standardDeviation / size;

        res = Math.sqrt( sq );

        totalValue = new DecimalFormat( "0.00" ).format( res );
        SMUtils.nap( 4 );
        return totalValue.equals( getStandardDeviationValue( columnName ) );

    }

    /**
     * To format the given date as yyyy-MM-dd
     * 
     * @param date
     * @return
     */
    public String dateFormat( String date ) {
        String formatedDate = null;
        try {
            SimpleDateFormat actualDateFormat = new SimpleDateFormat( "yyyy-MM-dd" );
            SimpleDateFormat expectedDateFormat = new SimpleDateFormat( "MM/dd/yyyy" );
            formatedDate = expectedDateFormat.format( actualDateFormat.parse( date ) );
        } catch ( Exception e ) {
            Log.message( "Given date is an invalid date format: " + date );
        }
        return formatedDate;
    }

    /**
     * Get the LSR Math grid values from UI
     * 
     * @return
     */
    public List<String> getMathCurrentCourseLevelAndRawPerformance( String studentName ) {

        List<String> rawPerformancesValues = new ArrayList<>();
        String studentCurrentCourseLevel = String.format( currentCourseLevel, studentName ) + parentCurrentCourseLevel;
        SMUtils.waitForElement( driver, endTableNotes, 10 );
        for ( int i = 1; i <= 8; i++ ) {
            WebElement StudentRawPerformance = driver.findElement( By.xpath( String.format( studentCurrentCourseLevel, i ) ) );

            rawPerformancesValues.add( StudentRawPerformance.getText().trim() );
        }

        return rawPerformancesValues;

    }

    /**
     * Get the LSR reading grid values from UI
     * 
     * @return
     */
    public List<String> getReadingCurrentCourseLevelAndRawPerformance( String studentName ) {

        List<String> rawPerformancesValues = new ArrayList<>();
        String studentCurrentCourseLevel = String.format( currentCourseLevel, studentName ) + parentCurrentCourseLevel;
        SMUtils.waitForElement( driver, endTableNotes, 10 );
        for ( int i = 1; i <= 11; i++ ) {
            WebElement StudentRawPerformance = driver.findElement( By.xpath( String.format( studentCurrentCourseLevel, i ) ) );

            rawPerformancesValues.add( StudentRawPerformance.getText().trim() );
        }

        return rawPerformancesValues;

    }

    /**
     * To format the percentage in DB
     * 
     * @return
     */
    public String totalPercentange( float ExercisesCorrect, float ExercisesAttempted ) {
        float percentage = 100;
        float totalPercentage;
        String exercisesPercentCorrect;
        totalPercentage = ExercisesCorrect * percentage / ExercisesAttempted;
        exercisesPercentCorrect = String.valueOf( Math.round( totalPercentage ) + "%" );
        return exercisesPercentCorrect;
    }

    /**
     * To format the exercisesCorrectAndAttempted in DB
     * 
     * @return
     */
    public String exercisesCorrectAndAttempted( String a, String b ) {
        String totalValue;
        if ( a.equals( "0" ) && b.equals( "0" ) ) {
            totalValue = "--/--";
        } else {
            totalValue = a + "/" + b;
        }
        return totalValue;

    }

    /**
     * To get UI grid values for Math subject
     * 
     * @return
     */
    public Map<String, Map<String, String>> getMathGridValues() {
        SMUtils.waitForElement( driver, reportTable );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();
        BooleanSupplier isNextPageAvailable = () -> {
            if ( isNextButtonEnabled() ) {
                clickNextButton();
                return true;
            } else {
                return false;
            }
        };
        do {
            gridValues.stream().forEach( row -> {
                List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
                Map<String, String> gridValue = new HashMap<>();

                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 0 ), columnData.get( 1 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 1 ), columnData.get( 2 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 2 ), columnData.get( 3 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 3 ), columnData.get( 4 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 4 ), columnData.get( 5 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 5 ), columnData.get( 6 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 6 ), columnData.get( 7 ).getText().trim() );
                gridValue.put( adminLSRConstants.LAST_SESSION_MATH_REPORT_FIELDS.get( 7 ), columnData.get( 8 ).getText().trim() );

                allGridValues.put( columnData.get( 0 ).getText().trim(), gridValue );
            } );

        } while ( isNextPageAvailable.getAsBoolean() );
        Log.message( "UI Grid Values: " + allGridValues );
        return allGridValues;
    }

    /**
     * To get UI grid values for Reading subject
     * 
     * @return
     */
    public Map<String, Map<String, String>> getReadingGridValues() {
        SMUtils.waitForElement( driver, reportTable );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();
        BooleanSupplier isNextPageAvailable = () -> {
            if ( isNextButtonEnabled() ) {
                clickNextButton();
                return true;
            } else {
                return false;
            }
        };
        do {
            gridValues.stream().forEach( row -> {
                List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
                Map<String, String> gridValue = new HashMap<>();

                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 0 ), columnData.get( 1 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 1 ), columnData.get( 2 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 2 ), columnData.get( 3 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 3 ), columnData.get( 4 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 4 ), columnData.get( 5 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 5 ), columnData.get( 6 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 6 ), columnData.get( 7 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 7 ), columnData.get( 8 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 8 ), columnData.get( 9 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 9 ), columnData.get( 10 ).getText().trim() );
                gridValue.put( LastSessionConstants.READING_COLUMN_HEADERS.get( 10 ), columnData.get( 11 ).getText().trim() );

                allGridValues.put( columnData.get( 0 ).getText().trim(), gridValue );
            } );

        } while ( isNextPageAvailable.getAsBoolean() );
        Log.message( "UI Grid Values: " + allGridValues );
        return allGridValues;
    }

    /**
     * This method is used to get all values in Student row
     * 
     * @return
     */
    public List<String> getStudentRowValues() {

        List<String> studentList = new ArrayList<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            studentList.add( columnData.get( 0 ).getText().trim() );
        } );
        return studentList;
    }

    /**
     * This method is used to click Next button
     * 
     * @return
     */
    public boolean isNextButtonEnabled() {
        try {
            SMUtils.waitForElement( driver, clickNextButton );
            return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, clickNextButton, button ) );
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * This method is used to click Next button
     */
    public void clickNextButton() {
        try {
            SMUtils.waitForElement( driver, clickNextButton );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, clickNextButton, button ) );
        } catch ( Exception e ) {
            Log.message( "Unable to click Next button." );
        }
    }

    /**
     * This method is verify sorting functionality
     * 
     * @return
     */
    public boolean sortAndCompareColumnvalues( String columnName ) {
        SMUtils.waitForElement( driver, reportTable );
        List<String> columnValueList = new ArrayList<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, LastSessionConstants.SORT.indexOf( columnName ) + 1 ) ) );
            IntStream.range( 0, columnData.size() ).forEach( itr -> {
                if ( !columnData.get( itr ).getText().trim().equals( "In IP" ) ) {
                    columnValueList.add( columnData.get( itr ).getText().trim().replace( "*", "" ).replace( "%", "" ) );
                }
            } );
        } );
        if ( columnName.equals( LastSessionConstants.SORT.get( 6 ) ) ) {
            List<Integer> percentList = columnValueList.stream().map( value -> Integer.parseInt( value.replace( "00:", "" ) ) ).collect( Collectors.toList() );
            return columnValueList.stream().map( x -> x.split( ":" )[1] ).map( x -> Integer.parseInt( x ) ).sorted().collect( Collectors.toList() ).toString().equals( percentList.toString() );

        } else if ( columnName.equals( LastSessionConstants.SORT.get( 4 ) ) ) {
            return columnValueList.stream().map( x -> Integer.parseInt( x ) ).sorted().collect( Collectors.toList() ).toString().equals( columnValueList.toString() );

        } else {
            return columnValueList.stream().sorted( String.CASE_INSENSITIVE_ORDER ).collect( Collectors.toList() ).equals( columnValueList );
        }
    }
    
    /**
     * Get current URL for report viewer page
     * 
     * @return
     */
    public String getReportViewerURL() {

        String URL = driver.getCurrentUrl();
        String actualURL = URL + System.nanoTime();
        Log.message( "Getting URL for report viewr page" );
        return actualURL;
    }

    /**
     * Launching report viewr page again
     */
    public void launchURLWithWrongRequestID() {

        SMUtils.nap( 2 );// This wait is required to load report viewr page
        String launchingURL = getReportViewerURL();
        Log.message( "Launching URL again after adding wrong request ID in URL" );
        driver.navigate().to( launchingURL );

    }

    /**
     * Getting status of PDF button when error message pops up
     * 
     * @return
     */
    public String getPDFButtonDisabled() {

        SMUtils.waitForElement( driver, exportPDFs );
        String attributeValue = exportPDFs.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }
    
    /**
     * Getting status of CSV button when error message pops up
     * 
     * @return
     */
    public String getCSVButtonDisabled() {

        SMUtils.waitForElement( driver, exportCSV );
        String attributeValue = exportCSV.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }
    
    /**
     * To validate the name of an assignment is displayed in output page
     * 
     * @return
     */
    public boolean isAssignmentNameDisplayed() {
        Log.message( "Verifying the presence of an assignment name" );
        SMUtils.waitForElement( driver, assignmentName );
        String nameOfAssignment = SMUtils.getTextOfWebElement( assignmentName, driver );
        Log.message( "Assignment Name is :  " + nameOfAssignment );
        return SMUtils.isElementPresent( assignmentName );
    }
    
    /**
     * To validate Report Run Date is in Prescribed Format
     * 
     * @return
     */
    public boolean validateReportRunDate() {
        SMUtils.waitForElement( driver, reportRunDate );
        String reportRunDate1 = SMUtils.getTextOfWebElement( reportRunDate, driver );
        Log.message( "Report Timestamp: " + reportRunDate1 );
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "MM/dd/yy '-' hh:mm" );
        Log.message( "Formatted Date : " + formatter.format( OffsetDateTime.now() ) );
        // Change it to contains method when sometimes Report Run time in BS is different than the local one
        Log.assertThat( formatter.format( OffsetDateTime.now() ).equalsIgnoreCase( reportRunDate1 ), "ReportRun Date and Time is Matching", "ReportRun Date and Time is not Matching" );
        return true;
    }
    
    public boolean validateRunReportDate() {
        SMUtils.waitForElement( driver, reportRunDate );
        String reportRunDate1 = SMUtils.getTextOfWebElement( reportRunDate, driver );
        Log.message( "Report Timestamp: " + reportRunDate1 );
        return true;
    }
    
    /**
     * To verify the Info Header values are displaying
     */
    public boolean isInfoHeaderValuesDisplaying() {
        SMUtils.isElementPresent( schoolName );
        SMUtils.isElementPresent( teacherName );
        SMUtils.isElementPresent( gradesSelected );
        SMUtils.isElementPresent( groupsSelected );
        String schoolValue = SMUtils.getTextOfWebElement( schoolName, driver );
        Log.message("school value: "+schoolValue);
        String teacherValue = SMUtils.getTextOfWebElement( teacherName, driver );
        String selcetedGradesValue = SMUtils.getTextOfWebElement( gradesSelected, driver );
        String selectedGroupsValue = SMUtils.getTextOfWebElement( groupsSelected, driver );
        Log.message( "Info Header Values are:  " + schoolValue + "  " + teacherValue + "  " + selcetedGradesValue + "  " + selectedGroupsValue );
        return true;
    }
    
    /**
     * To list the default actual selected options is present in output page
     * 
     * @return actlistOfSelectedOptions
     */
    public ArrayList<String> defaultSelectedOptions() {
    	List<String> values=valuesSelectedOptions.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        Log.message("default options:"+values.toString());
        ArrayList<String> actlistOfSelectedOptions = new ArrayList<String>();
        actlistOfSelectedOptions.add( values.get(0) );
        actlistOfSelectedOptions.add( values.get(1) );
        actlistOfSelectedOptions.add(values.get(2) );
        //actlistOfSelectedOptions.add(actNoOfgrps);
        Log.message( "List of Actual Options: " + actlistOfSelectedOptions );
        return actlistOfSelectedOptions;
    }
    
    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabelsChecking() {
        Log.event( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if ( SMUtils.waitForElement( driver, headerLegendValue ) ) {
            boolean containsAll = SMUtils.getAllTextFromWebElementList( headerLegend1 ).containsAll( ReportsUIConstants.AFGReportConstants.LEGEND_HEADERS );
            List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList(headerLegend1);
            Log.message("Legend Labels: "+allTextFromWebElementList.toString());
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }
    
    public boolean verifyNotesLabelChecking() {
        Log.event( "Verifying Notes Label" );
        boolean isLegendLabelDisplayed = false;
        List<String> webElementDirect = SMUtils.getAllTextFromWebElementList(notesLabels);
        Log.message("NotesLabels: "+webElementDirect.toString());
	    return isLegendLabelDisplayed = true;
        }
    

}