package com.savvas.sm.reports.ui.tests.admin.afg;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;

import io.restassured.response.Response;

public class ReportViewerStudentSortingAFGReport extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String organizationName;
    private String teacherUsername;
    private String teacherName;
    private String adminUserId;
    AreaForGrowthPage areasForGrowthReportPage;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        Log.message( adminUserId );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    }

    @Test ( description = " Verify Admin can able to see the AFG report with student name in report viewer page ", groups = { "SMK- ", "AreasForGrowthReportOutputPage", "AreasForGrowthReportStudentSorting" }, priority = 1 )
    public void SMAFGStudetnSorting_001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGStudetnSorting_001 :Verify Admin can able to see the AFG report with student name in report viewer page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            List<WebElement> studentUserNameEle = driver.findElements( By.cssSelector( afgPage.studentNameCSS ) );
            List<String> studentUNameActual = new ArrayList<String>();
            List<String> studentUNameExpected = new ArrayList<String>();

            studentUserNameEle.forEach( element -> studentUNameActual.add( element.getText() ) );
            studentUserNameEle.forEach( element -> studentUNameExpected.add( element.getText() ) );

            SMUtils.logDescriptionTC( "Verify the Report viewer page displaying the student name in correct format for AGF Report" );

            if ( afgReportViewerPage.getSkillRiskText() != "0" ) {
                List<WebElement> studentFullNameEle = driver.findElements( By.cssSelector( afgPage.studentNameCSS ) );
                List<String> studentFullNameActual = new ArrayList<String>();
                List<String> studentFullNameExpected = new ArrayList<String>();
                studentFullNameEle.forEach( element -> studentFullNameActual.add( element.getText() ) );
                studentFullNameEle.forEach( element -> studentFullNameExpected.add( element.getText() ) );
                List<String> lastNameOnlyActual = getLastNameOfStudentName( studentUNameActual );
                List<String> lastNameOnlyExpected = getLastNameOfStudentName( studentUNameExpected );
                lastNameOnlyActual.forEach( System.out::println );
                Log.assertThat( SMUtils.sortAndCompareList( lastNameOnlyActual, lastNameOnlyExpected, Constants.ASCENDING ), "'Student Name' sorting is matching as expected in Areas For Growth report",
                        "'Student Name' sorting is not matching as expected in Areas For Growth report" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
            Log.testCaseResult();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Report viewer page,the student name is sorted with last name with in the strand", groups = { "SMK- ", "AreasForGrowthReportOutputPage", "AreasForGrowthReportStudentSorting" }, priority = 1 )
    public void SMAFGStudetnSorting_002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGStudetnSorting_002 :Verify the Report viewer page,the student name is sorted with last name with in the strand<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( username, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To click the run report button 
            AFGReportViewerPage afgReportViewerPage = afgPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify the Report viewer page sorted in correct order" );

            List<WebElement> studentUserNameEle = driver.findElements( By.cssSelector( afgPage.studentNameCSS ) );
            List<String> studentUNameActual = new ArrayList<String>();
            List<String> studentUNameExpected = new ArrayList<String>();
            studentUserNameEle.forEach( element -> studentUNameActual.add( element.getText() ) );
            studentUserNameEle.forEach( element -> studentUNameExpected.add( element.getText() ) );

            if ( afgReportViewerPage.getSkillRiskText() != "0" ) {

                List<WebElement> studentFullNameEle = driver.findElements( By.cssSelector( afgPage.studentNameCSS ) );
                List<String> studentFullNameActual = new ArrayList<String>();
                List<String> studentFullNameExpected = new ArrayList<String>();
                studentFullNameEle.forEach( element -> studentFullNameActual.add( element.getText() ) );
                studentFullNameEle.forEach( element -> studentFullNameExpected.add( element.getText() ) );
                List<String> lastNameOnlyActual = getLastNameOfStudentName( studentUNameActual );
                List<String> lastNameOnlyExpected = getLastNameOfStudentName( studentUNameExpected );
                lastNameOnlyActual.forEach( System.out::println );
                Log.assertThat( SMUtils.sortAndCompareList( lastNameOnlyActual, lastNameOnlyExpected, Constants.ASCENDING ), "'Student Name' sorting is matching as expected in Areas For Growth report",
                        "'Student Name' sorting is not matching as expected in Areas For Growth report" );

            } else {
                Log.assertThat( afgReportViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the student details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, List<String>> getstudentsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, List<String>> studentDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.stream().forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                List<String> students = new ArrayList<>();
                JSONArray stduentArray = new JSONObject( skillDetail.toString() ).getJSONArray( AFGReportConstants.STUDENT_ROWS );
                List<String> studentDetailList = new ArrayList<>();
                IntStream.range( 0, stduentArray.length() ).forEach( itr -> studentDetailList.add( stduentArray.get( itr ).toString() ) );

                studentDetailList.stream().forEach( student -> {
                    String[] dateArray = SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.FAILED_DATE ).substring( 0, 10 ).split( "-" );
                    String dateAtRisk = dateArray[1] + "/" + dateArray[2] + "/" + dateArray[0];
                    students.add( SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.STUDENT_NAME ) + " - " + dateAtRisk );
                } );

                studentDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), students );
            } );

        } );
        return studentDetailFromResponse;
    }

    private List<String> getLastNameOfStudentName( List<String> studentName ) throws Exception {
        List<String> studentLastName = new ArrayList<String>();
        for ( String sName : studentName ) {
            String lastName = Stream.of( sName.split( " " ) ).reduce( ( first, last ) -> last ).get();
            studentLastName.add( lastName );
        }

        return studentLastName;
    }
}
