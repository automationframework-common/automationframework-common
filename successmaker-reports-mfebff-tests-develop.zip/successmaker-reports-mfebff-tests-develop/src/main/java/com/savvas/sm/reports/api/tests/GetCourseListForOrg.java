package com.savvas.sm.reports.api.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentSearchUsingSolar;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class used for testing teh course listing API for org
 * 
 * @author ajith.mohan
 *
 */
public class GetCourseListForOrg extends ReportAPI {
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String expectedJson;
    private String smUrl;
    private String adminDetails;
    private String userId;
    private String orgId;
    private String orgIdHeader;
    private String subjectId;
    private String accessToken;
    private List<String> studentsForSchool = new ArrayList<String>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> assignMultipleAssignments = new HashMap<>();
    private List<String> courseIDs = new ArrayList<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private List<String> stuDetails = new ArrayList<>();
    boolean isZeroState = false;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
    }

    @Test ( priority = 1, dataProvider = "positivecases", groups = { "smoke_test_case", "Smoke_getCoursesForOrg001", "course Listing for Org", "SMK-59677", "P1", "API", "SmokeTest" } )
    public void getCoursesForOrg001( String desc, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( desc );

        switch ( scenario ) {
            case "HAPPY PATH":
                SMUtils.logDescriptionTC( "Verify the API returning assignmentId in the response." );
                SMUtils.logDescriptionTC( "Verify the API returning assignmentTitle in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning assignerId in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning organizationId in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning organizationName in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning assignerFirstName in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning assignerLastName in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning assignerMiddleName in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning productId in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning assignmentId in the response" );
                SMUtils.logDescriptionTC( "Verify the API returning productId in the response" );

                String adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                String teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
                Log.message( "Teacher Details: " + teacherDetails );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
                subjectId = AssignmentAPIConstants.READING;
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                courseIDs.clear();
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING );
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING_1 );
                studentRumbaIds.clear();
                IntStream.range( 0, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
                    String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                    studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                } );

                assignMultipleAssignments = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
                Log.message( "Assigned Assignments: " + assignMultipleAssignments );
                isZeroState = false;
                break;

            case "FOCUS COURSE ALONE MATH":
                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                String teacherDetailsFocus = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL ) );

                Log.message( "Teacher Details: " + teacherDetailsFocus );

                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL ) ), teacherDetailsFocus );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL ) );
                subjectId = AssignmentAPIConstants.MATH;
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL ) ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetailsFocus, RBSDataSetupConstants.USERID ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetailsFocus, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                courseIDs.clear();
                courseIDs.add( AssignmentAPIConstants.FOCUS_MATH_1 );
                courseIDs.add( AssignmentAPIConstants.FOCUS_MATH_2 );
                studentRumbaIds.clear();
                IntStream.range( 0, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
                    String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetailsFocus, RBSDataSetupConstants.USERNAME ) );
                    studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                } );

                assignMultipleAssignments = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
                Log.message( "Assigned Assignments: " + assignMultipleAssignments );
                isZeroState = false;
                break;

            case "FOCUS COURSE ALONE READ":
                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                String teacherDetails1 = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
                Log.message( "Teacher Details: " + teacherDetails1 );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) ), teacherDetails1 );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
                subjectId = AssignmentAPIConstants.READING;
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERID ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                courseIDs.clear();
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING );
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING_1 );
                studentRumbaIds.clear();
                IntStream.range( 0, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
                    String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ) );
                    studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                } );

                assignMultipleAssignments = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
                Log.message( "Assigned Assignments: " + assignMultipleAssignments );
                isZeroState = false;
                break;

            case "ZERO STATE":

                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                subjectId = AssignmentAPIConstants.READING;
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                isZeroState = true;
                break;

            case "READING SUBJECT ID IN MATH SCHOOL":

                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                subjectId = AssignmentAPIConstants.READING;
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                isZeroState = true;
                break;

            case "MATH SUBJECT ID IN READING SCHOOL":

                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
                subjectId = AssignmentAPIConstants.MATH;
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                isZeroState = true;
                break;

            case "DELETED ASSIGNMENT":

                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                String teacherDetails2 = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), teacherDetails2 );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                subjectId = AssignmentAPIConstants.MATH;
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                String courseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() );
                String courseId = new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH,
                        SMUtils.getKeyValueFromResponse( teacherDetails2, "userId" ), orgId, DataSetupConstants.SETTINGS, courseName );
                studentRumbaIds.clear();
                IntStream.range( 0, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
                    String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
                    studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                } );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails2, "userId" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );

                HashMap<String, String> deleteAssignment = new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
                Log.message( deleteAssignment.get( "body" ) );

                HashMap<String, String> courseListingresp = getCoursesListingforOrg( smUrl, userId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), orgId, accessToken, subjectId, studentsForSchool );
                if ( !courseListingresp.get( Constants.REPORT_BODY ).contains( courseName ) ) {
                    Log.pass( "Deleted assignment not listed for admin" );
                }
                isZeroState = false;
                break;

            case "MULTIPLE SCHOOL STUDENT":

                adminForLogin = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
                Log.message( "Teacher Details: " + teacherDetails );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
                subjectId = AssignmentAPIConstants.READING;
                userId = SMUtils.getKeyValueFromResponse( adminForLogin, RBSDataSetupConstants.USERID );
                orgIdHeader = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                courseIDs.clear();
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING );
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING_1 );
                studentRumbaIds.clear();
                IntStream.range( 0, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
                    String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                    studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                } );

                assignMultipleAssignments = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
                Log.message( "Assigned Assignments: " + assignMultipleAssignments );
                isZeroState = false;
                break;
        }

        HashMap<String, String> courseListingforOrg = getCoursesListingforOrg( smUrl, userId, orgIdHeader, orgId, accessToken, subjectId, studentsForSchool );
        verifyResponse( courseListingforOrg.get( Constants.REPORT_BODY ), orgId, Integer.valueOf( subjectId ), studentsForSchool, isZeroState );

        Log.testCaseResult();

    }

    @DataProvider ( name = "positivecases" )
    public Object[][] positivedata() {

        Object[][] inputData = { { "Verify the admin can not able to see the courses which is not assigned to the students/groups.", "ZERO STATE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response returning, all the assignments from the selected school.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin can able to see only Focus assignments when the school having only focus license.", "FOCUS COURSE ALONE MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin can see all assignments from school when the school has flex license.", "FOCUS COURSE ALONE READ", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin can see default/ focus/ custom by settings,skill, and standards assignments.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin cannot see any Math assignment when admin sending subject ID as 2.", "READING SUBJECT ID IN MATH SCHOOL", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin cannot see any Reading assignments when the admin sending subject Id as 1", "MATH SUBJECT ID IN READING SCHOOL", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin cannot able to see the deleted assignment from the school.", "DELETED ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin should not see the assignments from other school when the teacher part of multiple school.", "MULTIPLE SCHOOL STUDENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the admin can not see the duplicate assignment from same teachers with in the school.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "negativeCases", groups = { "course Listing for Org", "SMK-59677", "P1", "API" } )
    public void getCoursesForOrg002( String desc, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( desc );
        String exception = null;
        String message = null;

        switch ( scenario ) {
            case "TEACHER AUTH":
                teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                subjectId = AssignmentAPIConstants.MATH;
                userId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                break;

            case "STUDENT AUTH":
                teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                studentsForSchool = getStudentsForSchool( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), teacherDetails );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), password );
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                subjectId = AssignmentAPIConstants.MATH;
                userId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                break;
            case "INVALID AUTH":
                studentsForSchool.add( AssignmentAPIConstants.MATH );
                accessToken = UserConstants.INVALID_TEACHER;
                orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                subjectId = AssignmentAPIConstants.MATH;
                userId = UserConstants.INVALID_TEACHER;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;

                break;
        }

        HashMap<String, String> courseListingforOrg = getCoursesListingforOrg( smUrl, userId, orgId, orgId, accessToken, subjectId, studentsForSchool );
        new GroupAPI().verifyException( courseListingforOrg.get( Constants.REPORT_BODY ), exception, true, message );

        Log.testCaseResult();

    }

    @DataProvider ( name = "negativeCases" )
    public Object[][] negativeCases() {

        Object[][] inputData = { { "Verify the API throwing exception for Teacher credentials", "TEACHER AUTH", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the API throwing exception for student credentials", "STUDENT AUTH", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the API throwing exception for invalid credentials", "INVALID AUTH", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },

        };
        return inputData;
    }

    /**
     * To verify the Response
     * 
     * @param response
     * @param organizationId
     * @param subjectId
     * @param studentIds
     * @return
     */
    public boolean verifyResponse( String response, String organizationId, int subjectId, List<String> studentIds, boolean isZeroState ) {
        JSONObject courseDetail = new JSONObject( response );
        ArrayList<Boolean> verified = null;
        ArrayList<Boolean> verifiedAll = null;
        boolean isverified = false;
        List<String> assignmentIDsDB = new ArrayList<>();
        List<String> assignmentIDsAPI = new ArrayList<>();
        try {
            if ( isZeroState ) {
                new GroupAPI().verifyException( response, CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION, false, ReportsAPIConstants.COURSE_LIST_ZERO_STATE_MESSAGE );
            } else {
                JSONArray courseDetails = courseDetail.getJSONArray( "data" );
                List<HashMap<String, String>> courseForOrg = new SqlHelperCourses().getCourseForOrg( subjectId, studentIds );
                for ( Object course : courseDetails ) {

                    verifiedAll = new ArrayList<>();
                    JSONObject courseJson = new JSONObject( course.toString() );
                    assignmentIDsAPI.add( courseJson.get( "assignmentId" ).toString() );
                    for ( HashMap<String, String> courseFromDB : courseForOrg ) {
                        assignmentIDsDB.add( courseFromDB.get( Constants.ASSIGNMENT_ID ) );
                        verified = new ArrayList<>();
                        if ( courseJson.get( "assignmentId" ).toString().equals( courseFromDB.get( Constants.ASSIGNMENT_ID ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( courseJson.get( "assignerId" ).toString().equals( courseFromDB.get( Constants.ASSIGNMENT_OWNER_ID ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( courseJson.get( "assignmentTitle" ).toString().equals( courseFromDB.get( Constants.ASSIGNMENT_TITLE_DB ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( courseJson.get( "contentBaseId" ).toString().equals( courseFromDB.get( Constants.CONTENT_BASE_ID_DB ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( courseJson.get( "productId" ).toString().equals( courseFromDB.get( Constants.PRODUCT_ID_DB ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( courseJson.get( "assignerFirstName" ).toString().equals( SMUtils.getKeyValueFromResponse( new RBSUtils().getUser( courseJson.getString( "assignerId" ) ), RBSDataSetupConstants.FIRSTNAME ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( courseJson.get( "assignerLastName" ).toString().equals( SMUtils.getKeyValueFromResponse( new RBSUtils().getUser( courseJson.getString( "assignerId" ) ), RBSDataSetupConstants.LASTNAME ) ) ) {
                            verified.add( true );
                        } else {
                            verified.add( false );
                        }
                        if ( SMUtils.isAllValueTrue( verified ) ) {
                            verifiedAll.add( true );
                            Log.message( "Verified the fields for assignment - " + courseJson.get( "assignmentId" ).toString() );
                            break;
                        } else {
                            verifiedAll.add( false );
                        }
                    }
                    if ( SMUtils.isAllValueTrue( verifiedAll ) ) {
                        isverified = true;
                    }
                }
            }
            Set<String> set = new HashSet<>( assignmentIDsDB );
            assignmentIDsDB.clear();
            assignmentIDsDB.addAll( set );
            Collections.sort( assignmentIDsDB );
            Collections.sort( assignmentIDsAPI );
            Log.message( "Assignments From DB - " + assignmentIDsDB );
            Log.message( "Assignments From API - " + assignmentIDsAPI );
        } catch ( Exception e ) {
            Log.fail( "Zero state returned in response!" );
        }

        return isverified;
    }

    /**
     * To get all the students from org
     * 
     * @param orgId
     * @param teacherDetails
     * @return
     * @throws Exception
     */
    public List<String> getStudentsForSchool( String orgId, String teacherDetails ) throws Exception {

        List<String> studentIds = new ArrayList<>();
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        String endpoint = StudentSearchUsingSolar.STUDENT_SOLAR_SEARCH;

        for ( int offset = 0; offset < 100; offset++ ) {
            JSONObject bodyData = new JSONObject();
            bodyData.put( "organizationId", orgId );
            bodyData.put( "offset", offset );

            HashMap<String, String> response = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, bodyData.toString() );
            JSONObject jsonResp = new JSONObject( response.get( Constants.REPORT_BODY ) );

            JSONArray studentArray = jsonResp.getJSONObject( "data" ).getJSONArray( "userList" );
            if ( studentArray.isEmpty() ) {
                break;
            } else {
                for ( Object object : studentArray ) {
                    JSONObject student = new JSONObject( object.toString() );
                    String studentId = student.get( "userId" ).toString();
                    studentIds.add( studentId );
                }
            }

        }
        return studentIds;

    }

    /**
     * This method will return courses for given organization based on the
     * student selected
     * 
     * @param envUrl
     * @param userId
     * @param orgId
     * @param accessToken
     * @param subjectId
     * @param studentList
     * @return
     */
    public HashMap<String, String> getCoursesListingforOrg( String envUrl, String userId, String orgIdHeader, String schoolID, String accessToken, String subjectId, List<String> studentList ) {
        String endpoint = AdminConstants.GET_COURSE_LISTING;
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgIdHeader );

        // Input Params
        HashMap<String, String> params = new HashMap<>();
        endpoint = endpoint.concat( "?subjectTypeId=" ) + subjectId;
        JSONObject jsonBody = new JSONObject();
        JSONArray organizationArray = new JSONArray();
        JSONArray studentArray = new JSONArray();
        organizationArray.put( schoolID );

        for ( String student : studentList ) {
            studentArray.put( student );
        }
        jsonBody.put( "orgIds", organizationArray );
        jsonBody.put( "studentIds", studentArray );

        Log.message( "request body" + jsonBody.toString() );

        // Makes a POST call
        HashMap<String, String> postResponse = null;
        try {
            postResponse = RestHttpClientUtil.POST( envUrl, headers, params, endpoint, jsonBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

}