package com.savvas.sm.reports.api.report;

import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class CPReportAdminGraphQLTest extends UserAPI {
    @Test ( dataProvider = "getData", groups = { "SMK-57925 GraphQL API for CP report Admin", "API","SmokeTest" }, priority = 1 )
    public void testCPRepostAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        LocalDate now = LocalDate.now();
        Date date = new Date();
        LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.SUNDAY ) );
        String thisWeekStartDay = firstMonday.toString();
        String thisWeekEndDay = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );

        String payload = getPayload();
        String query;
        Response response = null;
        String responseStatusCode = "";
        switch ( scenarioType ) {
            case "VALID_SCENARIO":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_TOKEN":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
			case "WITHOUT_ORG_ID":
				queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
				queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
				query = constructQueryItems( queryItem );
				payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
				response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
				break;
			case "WITHOUT_USER_ID":
				queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
				queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
				query = constructQueryItems( queryItem );
				payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
				response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
				break;
			case "WITHOUT_FILTER_PARAM":
				queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
				queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
				query = constructQueryItems( queryItem );
				payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
				response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
				break;
			case "INVALID_START_DATE":
				queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
				queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
				queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER.replace( "2022-03-29", ReportAPIConstants.INVALID ) );
				query = constructQueryItems( queryItem );
				payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
				response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
				break;
			case "INVALID_END_DATE":
				queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
				queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
				queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER.replace( "2022-04-30", ReportAPIConstants.INVALID ) );
				query = constructQueryItems( queryItem );
				payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
				response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
				break;
			case "SUBJECT_MATH":
				queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
				queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
				queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER.replace( Constants.READING, Constants.MATH ) );
				query = constructQueryItems( queryItem );
				payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
				response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
				break;

        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_SCENARIO" },
                { "TC002", "401", "Verify the status code 401 for response body for not providing token in header", "WITHOUT_TOKEN" },
				{ "TC003", "400", "Verify the status code 400 for response body for not providing orgId in request body", "WITHOUT_ORG_ID" },
				{ "TC004", "400", "Verify the status code 400 for response body for not providing userId in request body", "WITHOUT_USER_ID" },
				{ "TC005", "400", "Verify the status code 400 for response body for not providing filterParam in request body", "WITHOUT_FILTER_PARAM" },
				{ "TC006", "INTERNAL_SERVER_ERROR", "Verify the status code INTERNAL_SERVER_ERROR for response body for not invalid start time in request body", "INVALID_START_DATE" },
				{ "TC007", "INTERNAL_SERVER_ERROR", "Verify the status code INTERNAL_SERVER_ERROR for response body for not invalid end time in request body", "INVALID_END_DATE" },
				{ "TC008", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_MATH" }

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "CPReportAdminRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }
}
