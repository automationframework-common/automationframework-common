package com.savvas.sm.reports.ui.tests.teacher.afg;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AFGReportOutputPage;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class AFGReportOutputScreenWithFiltersTest extends EnvProperties {

	private String smUrl;
	private String browser;
	private String username;
	private String password;
	private String org;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL); 
	String teacherDetails;

	@BeforeTest
	public void initTest() throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school); 
		username =SMUtils.getKeyValueFromResponse(teacherDetails,RBSDataSetupConstants.USERNAME); 
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		 

	}

	@Test( description = "Verify Groups are selected by default under Areas for Growth Difficulty sub-nav", groups = { "SMK-65682" }, priority = 1 )
	public void tcAFGOutputReportOptions001() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);
		AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage(driver);
		LeftNavigationBar leftNavBar = new LeftNavigationBar(driver);
		ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
		ReportOutputComponent reportOutputComponent = new ReportOutputComponent(driver);
		AFGReportViewerPage afgReportViewer = new AFGReportViewerPage(driver);
		AFGReportOutputPage afgReportOutputPage = new AFGReportOutputPage(driver);
		Log.testCaseInfo("tc_AFG_1: Verify Groups are selected by default under Areas for Growth Difficulty sub-nav<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			// Verifying Course Widget
			boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to reports page
			areaForGrowthPage.navigateToReports();
			driver.switchTo().frame(ReportsUIConstants.REPORTS_IFRAME);
			// Click on Areas For Growth Report
			leftNavBar.clickOnAreaForGrowthPage();

			// Verify 'Run Report' button enabled
			Log.assertThat(reportFilterComponent.isRunReportButtonDisplayed(),
					" Run Report option is present at the bottom", " Run Report option is not present at the bottom");
			Log.assertThat(reportFilterComponent.isRunReportButtonEnabled(), "Run Report Option is Enabled",
					"Run Report Option is disabled");

			// Click Run Report
			Log.assertThat(reportFilterComponent.clickRunReportButton(), "Run Report Button Clicked successfully",
					"Run Report Button Clicked successfully");
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.logDescriptionTC("TC001 & TC 002 : Verify the teacher can able to view the Areas For Growth Report  in a new tab after clicking on \" Run report Button\"");
			Log.assertThat(	reportOutputComponent.getReportPageTitle().equals(ReportsUIConstants.ReportTypes.AREAS_FOR_GROWTH),"The Areas Of Growth ReportViewer loaded Successfully","The Areas Of Growth ReportViewer loaded Successfully");

			SMUtils.logDescriptionTC("TC003 : Verify First iframe contains Assignment name, Report run date, School name, teacher name, Grade, and Group name(If selected by group) are display respectively");
			Log.assertThat(reportOutputComponent.isAssignmentNameDisplyed(), "Asssignment name displayed","Assignment name not displayed");
			Log.assertThat(!reportOutputComponent.getInfoHeader().isEmpty(), "InfoHeaders are displayed as expected","InfoHeaders are displayed as expected");

			SMUtils.logDescriptionTC("TC004:Verify the Second iframe contains \"Selected Options\"- Additional grouping, sort, dates at risk, grades, groups, display name");
			Log.assertThat(reportOutputComponent.getSelectedOptionHeader().equals(ReportsUIConstants.SELECTED_OPTION_HEADER),"Selected options header displaying", "Selected options header is not shown");
			Log.assertThat(!reportOutputComponent.getSelectedOptionValues().isEmpty(),"Reterived values from the Selected option header", "unable to get selected");

			SMUtils.logDescriptionTC("TC005 & TC006: Verify the number of Total skills At risk & Total Students at Risk displaying below the first iframe");
			Log.assertThat(afgReportOutputPage.isTotalSkillsAtRisk(), "Displayed Total Skills At Risk","not Displayed Total Skills At Risk");
			Log.assertThat(afgReportOutputPage.isTotalStudentsAtRisk(), "Displayed Total student At Risk","not Displayed Total Studetns At Risk");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test( description = "Verify Students are selected and run report under Areas for Growth Difficulty sub-nav", groups = { "SMK-65682" }, priority = 2 )
	public void tcAFGOutputReportOptions002() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);
		AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage(driver);
		LeftNavigationBar leftNavBar = new LeftNavigationBar(driver);
		ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
		ReportOutputComponent reportOutputComponent = new ReportOutputComponent(driver);
		Log.testCaseInfo("TC 008: Verify the AFG Report generation for all Students and all Assignments<small><b><i>["+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			// Verifying Course Widget
			boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed","Course widget is not diplayed");

			// Navigate to reports page
			areaForGrowthPage.navigateToReports();
			driver.switchTo().frame(ReportsUIConstants.REPORTS_IFRAME);
			// Click on Areas For Growth Report
			leftNavBar.clickOnAreaForGrowthPage();

			// Selecting all Students
			Log.assertThat(reportFilterComponent.isStudentRadioButtonClickable(), "Student Radio Button Clicked","Student Radio button not clicked");

			// Verify 'Run Report' button enabled
			Log.assertThat(reportFilterComponent.isRunReportButtonDisplayed()," Run Report option is present at the bottom", " Run Report option is not present at the bottom");
			Log.assertThat(reportFilterComponent.isRunReportButtonEnabled(), "Run Report Option is Enabled","Run Report Option is disabled");

			// Click Run Report
			Log.assertThat(reportFilterComponent.clickRunReportButton(), "Run Report Button Clicked successfully","Run Report Button Clicked successfully");
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Verify the Student selected in report output
			String studentSelectedLabel = reportOutputComponent.getSelectedOptionValues().get(3).replaceAll("[0-9]","");
			Log.assertThat(studentSelectedLabel.trim().equals("students selected"), "All Students Selected as Input","All Students are not selected as input");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test( description = "Verify Mulitple groups are selected in Groups dropdown and verify in Run report", groups = { "SMK-65682" }, priority = 3)
	public void tcAFGOutputReportOptions003() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);
		AreaForGrowthPage areaForGrowthPage = new AreaForGrowthPage(driver);
		LeftNavigationBar leftNavBar = new LeftNavigationBar(driver);
		ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

		Log.testCaseInfo("TC:11: Verify the AFG Report generation for multiple groups.<small><b><i>[" + browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			boolean courseWidgetDisplayed = areaForGrowthPage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed","Course widget is not diplayed");

			// Navigate to reports page
			areaForGrowthPage.navigateToReports();
			driver.switchTo().frame(ReportsUIConstants.REPORTS_IFRAME);
			// Click on Areas For Growth Report
			leftNavBar.clickOnAreaForGrowthPage();
			
			//Clicking Groups
			Log.assertThat(areaForGrowthPage.verifyGroupsBtnSelected(), "Groups are selected","Groups are not selected");
			
			// Click Run Report
			Log.assertThat(reportFilterComponent.clickRunReportButton(), "Run Report Button Clicked successfully","Run Report Button Clicked successfully");
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			AFGReportOutputPage afgReportOutputPage = new AFGReportOutputPage(driver);
			Log.assertThat(afgReportOutputPage.getGroupLabelValue().equals(ReportsUIConstants.AREA_FOR_GROWTH_MULTIGROUP_VALUE),"The group label value '" + ReportsUIConstants.AREA_FOR_GROWTH_MULTIGROUP_VALUE+ "' is displayed when multi group is selected","The group label value '" + ReportsUIConstants.AREA_FOR_GROWTH_MULTIGROUP_VALUE+ "' is not displayed when multi group is selected");
			SMUtils.logDescriptionTC("TC013: Verify the default sorting - Strand column");
			Log.assertThat(SMUtils.sortAndCompareList(afgReportOutputPage.strandColumn(), afgReportOutputPage.strandColumn(),Constants.ASCENDING),"The default sorting based on 'Strand' displayed correctly","The default sorting based on 'Strand' not displayed correctly");
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

}
