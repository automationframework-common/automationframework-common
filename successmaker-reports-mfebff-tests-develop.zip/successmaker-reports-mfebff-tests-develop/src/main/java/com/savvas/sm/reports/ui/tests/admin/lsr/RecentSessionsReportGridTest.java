package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.text.DecimalFormat;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;

import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class RecentSessionsReportGridTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String userNameDistrictAdmin;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        userNameDistrictAdmin = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify Recent Sessions Report output page is accessible for district admin", groups = {"Smoke", "SMK-57825", "ReportOutputPage", "RecentSessions" }, priority = 1 )
    public void tcRSROutputPage001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcRSROutputPage001: Verify Recent Sessions Report output page is accessible for district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( userNameDistrictAdmin, password );
            

            //Navigating to the recent session report filter page
            RecentSessionsPage recentSessionPage = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

            // Load output page
            RecentSessionsOutputPage outputPage = recentSessionPage.clickRunBtn();

            SMUtils.logDescriptionTC( "Verify the Recent Sessions report table should be display with Student,Level,Raw performance and Usage columns." );
            Log.assertThat( outputPage.getReportTableTitle().equals( ReportsUIConstants.REPORT_TABLE_TITTLE ), "Report table page tittle is displayed successfully!!!", "Report table page title is not displayed properly" );

            SMUtils.logDescriptionTC( "Verify the Recent Sessions report table should be display sub column of Current Course Level under the Level column." );
            SMUtils.logDescriptionTC( "Verify the Recent Sessions report should contains Raw  Performance datas for below columns Exercises Corrrect Exercises Attempted Exercises Percent Correct" );
            SMUtils.logDescriptionTC( "Verify the Recent Sessions report should contains Usage datas for below columns Help Used,Time Spent,Total Sessions,Usage Goals Status,Session Date" );
            SMUtils.logDescriptionTC( "Verify the Recent Sessions report the notes should be display in Total sessions column under the usage column minimun of 1 assignment" );
            Log.assertThat( outputPage.getReportTableSubTitle().equals( ReportsUIConstants.REPORT_TABLE_SUB_TITTLE ), "Report table page sub tittle is displayed successfully!!!", "Report table page title is not displayed properly" );

            SMUtils.logDescriptionTC( "Verify the Recent Sessions report the Mean label is displayed under the student cloumn" );
            SMUtils.logDescriptionTC( "Verify the Standard deviation label is displayed under the student column" );
            Log.assertThat( outputPage.getLastTwoRow().equals( ReportsUIConstants.REPORT_TABLE_LAST_TWO_ROW ), "Report table page last two row is displayed successfully!!!", "Report table page last two row is not displayed properly" );

            SMUtils.logDescriptionTC( "Verify the Recent Sessions report table under the Level column the Current Course Level format should be display in hundredth decimal" );
            List<String> levelRow = outputPage.getCurrentCourseLevelRow();
            DecimalFormat df = new DecimalFormat( "#.##" );
            List<String> expectedrow = levelRow.stream().map( value -> df.format( Double.valueOf( value ) ) ).collect( Collectors.toList() );
            Log.assertThat( levelRow.containsAll( expectedrow ), "In Report table page the Current Course Level Row  is displayed hundredth decimal successfully!!!",
                    "In Report table page the Current Course Level Row  is not displayed hundredth decimal properly!!!" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
