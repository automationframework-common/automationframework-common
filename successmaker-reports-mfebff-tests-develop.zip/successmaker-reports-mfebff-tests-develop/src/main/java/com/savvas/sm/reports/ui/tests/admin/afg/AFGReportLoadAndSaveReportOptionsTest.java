package com.savvas.sm.reports.ui.tests.admin.afg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class AFGReportLoadAndSaveReportOptionsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> courses;
    private List<String> teachers;
    private List<String> groups;
    SaveReportFilterPopup saveReportOptionPopup;
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String flexSchool;
    private String mathSchool;
    private String org;
    private String orgNameFromId;
    private String organizationName;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the user can navigates to areas For Growth Report page", groups = { "SMK-63439/SMK-63438", "SaveReportOption", "I can save my reporting options for my areas for growth report", "Smoke" }, priority = 1 )
    public void smAFGSaveReport_001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smAFGSaveReport_001: Verify the user can navigates to areas For Growth Report page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            SMUtils.logDescriptionTC( "Verify 'Save Report Option'  button in areas for growth report page" );
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in AFG report",
                    "The save report option is not displayed in AFGreport" );
            Log.assertThat( !areasForGrowthReportPage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify all available fields in 'Save Report Option  Popup." );
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to cancel the in 'Save Report Option ' Popup on CPR aggregate report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with new name." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify If User enter more than 50 characters in new custom report configuration text box" );
            saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            SMUtils.logDescriptionTC( "Verify User can able to click the cancel and close(X) in save report option." );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)", groups = { "SMK-63439/SMK-63438", "Smoke", "SaveReportOption",
            "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smAFGSaveReport_002: Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC(
                    "Verify User can able to save the report option with 'Teacher' option in Additional Grouping, ' Student Id' option in Display ,  'Level' in sort Dropdown and '24 weeks' in dates at risk dropdown with Mask Student display on Areas for Growth Report and load the report" );
            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SORT_LABEL, "Level" );
            areasForGrowthReportPage.clickMaskStudentCheckBox();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "24 Weeks" );
            areasForGrowthReportPage.reportFilterComponent.expandDemographicFilters();
            HashMap<String, String> getAllOptionBeforeSelected = areasForGrowthReportPage.getAllSelectedFilters();
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );

            Log.testCaseResult();

            areasForGrowthReportPage.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading)" );
            SMUtils.logDescriptionTC(
                    "Verify User can able to save the report option with 'Grade' option in Additional Grouping, ' Student Username' option in Display , 'Skill Description' in sort Dropdown and  '20 weeks' in dates at risk dropdown with Mask Student display on Areas for growth Report and load the report" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ), courses.get( 2 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Reading)" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skill Description" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "20 Weeks" );

            saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "SMK-63439/SMK-63438", "SaveReportOption",
            "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smAFGSaveReport_003:Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ), password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not  disabled if the user does not have already saved options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Group' option in Additional Grouping and  '16 weeks' option in dates at risk Dropdown with All options in student demographics dropdowns and load the report", groups = {
            "SMK-63439/SMK-63438", "Smoke", "SaveReportOption", "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smAFGSaveReport_004:Verify User can able to save the report option with 'Group' option in Additional Grouping and  '16 weeks' option in dates at risk Dropdown with All options in student demographics dropdowns and load the report <small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            SMUtils.logDescriptionTC( "Verify if new assignment and group created by the teacher also shown as selected  while report option is selected when the filter option is saved with all of the assignment and group" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown." );
            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SORT_LABEL, "Level" );
            areasForGrowthReportPage.reportFilterComponent.expandDemographicFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            HashMap<String, String> getAllOptionBeforeSelected = areasForGrowthReportPage.getAllSelectedFilters();
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with  '12 weeks' option in dates at risk Dropdown with Select multiple options in student demographics dropdowns and load the report", groups = { "SMK-63439/SMK-63438",
            "SaveReportOption", "Smoke", "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smAFGSaveReport_005:Verify User can able to save the report option with  '12 weeks' option in dates at risk Dropdown with Select multiple options in student demographics dropdowns and load the report <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "12 Weeks" );
            areasForGrowthReportPage.reportFilterComponent.expandDemographicFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,
                    Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,
                    Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );

            HashMap<String, String> getAllOptionBeforeSelected = areasForGrowthReportPage.getAllSelectedFilters();
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with  '8 weeks' option in dates at risk Dropdown and Select  any one options in student demographics dropdowns and load the report", groups = { "Smoke", "SMK-63439/SMK-63438",
            "SaveReportOption", "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smAFGSaveReport_006: Verify User can able to save the report option with  '8 weeks' option in dates at risk Dropdown and Select  any one options in student demographics dropdowns and load the report<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '8 weeks' option in dates at risk Dropdown and Select  any one options in student demographics dropdowns and load the report" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '4 weeks' option in dates at risk Dropdown , Select 'Yes' option in 'Disability  Status' dropdown and 'English' in English Language Proficiency dropdown. " );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '4 weeks' option in dates at risk Dropdown , Select 'Yes' option in 'Disability  Status' dropdown and 'English' in English Language Proficiency dropdown. " );
            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "8 Weeks" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            areasForGrowthReportPage.reportFilterComponent.expandDemographicFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );

            HashMap<String, String> getAllOptionBeforeSelected = areasForGrowthReportPage.getAllSelectedFilters();
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with  '1 weeks' option in dates at risk Dropdown with Select 'White' option in 'Race' dropdown and 'Hispanico or Latino' in special services dropdown. ", groups = {
            "SMK-63439/SMK-63438", "Smoke", "SaveReportOption", "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smAFGSaveReport_007:Verify User can able to save the report option with  '1 weeks' option in dates at risk Dropdown with Select 'White' option in 'Race' dropdown and 'Hispanico or Latino' in special services dropdown. <small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, org );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '1 weeks' option in dates at risk Dropdown with Select 'White' option in 'Race' dropdown and 'Hispanico or Latino' in special services dropdown. " );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '2 weeks' option in dates at risk Dropdown and 'Non-Migrant' in Migrant status dropdown. " );
            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "2 Weeks" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );
            areasForGrowthReportPage.reportFilterComponent.expandDemographicFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );

            HashMap<String, String> getAllOptionBeforeSelected = areasForGrowthReportPage.getAllSelectedFilters();
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Teacher' option in Additional Grouping, ' Student Id' option in Display ,  'Level' in sort Dropdown and '24 weeks' in dates at risk dropdown with Mask Student display on Areas for Growth Report and load the report", groups = {
            "SMK-63439/SMK-63438", "SaveReportOption", "I can save my reporting options for my areas for growth report" }, priority = 1 )
    public void smAFGSaveReport_008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "smAFGSaveReport_008:Verify User can able to save the report option with 'Teacher' option in Additional Grouping, ' Student Id' option in Display ,  'Level' in sort Dropdown and 1 weeks' in dates at risk dropdown with Mask Student display on Areas for Growth Report and load the report<small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AreaForGrowthPage areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "2 Weeks" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );

            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );

            HashMap<String, String> getAllOptionBeforeSelected = areasForGrowthReportPage.getAllSelectedFilters();
            SaveReportFilterPopup saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            HashMap<String, String> getAllOptionPostSave = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSelected, getAllOptionPostSave ), "All selected Option showing after loading the report", "Issue in loading the report options" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if delete the Group, after saved the filters options with the groups" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFG Report Testing Settings" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify if delete the Group, after saved the filters options with the groups" );
            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilters();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();
            HashMap<String, String> getAllOptionBeforeSave = areasForGrowthReportPage.getAllSelectedFilters();
            saveReportOptionPopup = areasForGrowthReportPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterNameReport = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterNameReport );
            saveReportOptionPopup.clickSaveButton();
            areasForGrowthReportPage.reportFilterComponent.clickResetButton();
            Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

            //adding the student to the  group for the  teacher
            String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userId" ) ),
                    RBSDataSetup.organizationIDs.get( flexSchool ), new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            //delete group with assignment
            new GroupAPI().deleteGroup( newGroupId, teacherId, RBSDataSetup.organizationIDs.get( flexSchool ),
                    new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterNameReport );
            HashMap<String, String> getAllOptionPostSaved = areasForGrowthReportPage.getAllSelectedFilters();
            Log.assertThat( areasForGrowthReportPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterNameReport ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.assertThat( SMUtils.compareTwoHashMap( getAllOptionBeforeSave, getAllOptionPostSaved ), "All selected Option showing after loading the report", "Issue in loading the report options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
