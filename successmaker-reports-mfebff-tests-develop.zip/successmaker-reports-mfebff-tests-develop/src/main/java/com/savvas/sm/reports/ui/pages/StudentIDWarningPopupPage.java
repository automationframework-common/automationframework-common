package com.savvas.sm.reports.ui.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

public class StudentIDWarningPopupPage extends LoadableComponent<StudentIDWarningPopupPage> {
    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    @FindBy ( css = "p.description" )
    WebElement description;
    @FindBy ( css = "cel-modal-window.hydrated" )
    WebElement popupheader;
    @FindBy ( css = "div.error-container p" )
    WebElement descriptionforwarningmodel;
    @FindBy ( css = "p.m-0:nth-child(1)" )
    WebElement textstudentId;

    private String displaystudentid = "div.title-container h1";
    private String closeicon = "cel-icon-button";
    private String button = "button";
    private String closebtn = "cel-button.ok-button";

    public StudentIDWarningPopupPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, description );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, description, 10 ) ) {
            Log.message( "Area For Growth Page loaded successfully." );
        } else {
            Log.fail( "Area For Growth Page not loaded successfully." );
        }

    }

    public String verifywarningmodel() {
        SMUtils.waitForElement( driver, popupheader );
        WebElement warningmodel = SMUtils.getWebElement( driver, popupheader, displaystudentid );

        Log.message( "warning model is displayed" );
        return warningmodel.getText().trim();
    }

    public void clickIconbutton() {
        SMUtils.waitForElement( driver, popupheader );
        WebElement parent = SMUtils.getWebElement( driver, popupheader, closeicon );
        WebElement webElement = SMUtils.getWebElement( driver, parent, button );
        SMUtils.clickJS( driver, webElement );
        Log.message( "Clicked closeicon Button" );
    }

    public String verifydisplaystudenttext() {
        SMUtils.waitForElement( driver, popupheader );

        return textstudentId.getText().trim();
    }

    public void clickCloseButton() {
        WebElement closeParentElement;
        SMUtils.waitForElement( driver, popupheader );
        closeParentElement = SMUtils.getWebElement( driver, popupheader, closebtn );
        WebElement atualElement = SMUtils.getWebElement( driver, closeParentElement, button );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked close Button" );
    }

}
