package com.savvas.sm.reports.ui.pages;

import static org.testng.AssertJUnit.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.smoke.admin.pages.AreasForGrowthReport;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.utils.SMUtils;

public class AdminLauncherPage extends LoadableComponent<AdminLauncherPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private final WebDriver driver;
    private String smUrl;
    private String browser;

    // ********* SuccessMaker Launcher/Login Page Elements ***************
    @FindBy ( id = "launchButton" )
    WebElement smLaunchButton;

    @FindBy ( id = "username" )
    WebElement elementUsername;

    @FindBy ( id = "password" )
    WebElement elementPassword;

    @FindBy ( className = "btn-submit" )
    WebElement elementSignInButton;

    @FindBy ( id = "splashImg" )
    WebElement imgSuccessMaker;

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public AdminLauncherPage( WebDriver driver, String url ) {
        this.driver = driver;
        smUrl = url;
        PageFactory.initElements( driver, this );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Override
    protected void isLoaded() {

        assertTrue( "HomePage is not loaded!", driver.getCurrentUrl().contains( smUrl ) );

        if ( browser.toLowerCase().contains( "safari" ) ) {
            if ( SMUtils.waitForElement( driver, elementSignInButton, 10 ) ) {

                Log.message( "SM Login page loaded successfully!" );
            } else {
                Log.fail( "SM login page did not load." );
            }
        } else {
            if ( SMUtils.waitForElement( driver, smLaunchButton ) ) {
                Log.message( "SM Pre-Login page loaded successfully!" );
            } else {
                Log.fail( "SM pre-login page did not load." );
            }
        }
    }

    @Override
    protected void load() {
        if ( browser.toLowerCase().contains( "safari" ) ) {
            driver.get( smUrl + "/lms/sso" ); // SMK-44058
                                              // -
                                              // browser
        } else { // So Launching login page directly only on safari
            driver.get( smUrl );
        }
        Log.message( "Hit the SM Instance Url - " + smUrl );
    }

    /**
     * To login to SM application
     * 
     * @param username
     * @param password
     * @return
     */
    public AreaForGrowthPage loginToSM( String username, String password ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadMFEPage();
        return new AreaForGrowthPage( driver ).get();
    }

    /**
     * To login to SM application As Teacher
     * 
     * @param username
     * @param password
     * @return
     */
    public AreaForGrowthPage loginToSMAsTeacher( String username, String password ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadTeacherMFEPage();
        return new AreaForGrowthPage( driver ).get();
    }
    
    /**
     * To login to SM application As Teacher
     * 
     * @param username
     * @param password
     * @return
     */

    public AreaForGrowthReportPage loginToSMATeacher( String username, String password ) {

        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadTeacherMFEPage();
        return new AreaForGrowthReportPage( driver ).get();
    }



    /**
     * To load MFE page
     * 
     */
    private void loadMFEPage() {
        try {
            driver.get( ReportsUIConstants.ADMIN_REPORT_MFE_URL );
            Log.message( "MFE Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE url not loaded" );
        }
    }

    /**
     * To load MFE page
     * 
     */
    private void loadTeacherMFEPage() {
        try {
            driver.get( ReportsUIConstants.MFE_TEACHER_URL );
            Log.message( "MFE Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE url not loaded" );
        }
    }

    /***
     * Click Enter here to launch the SSO Login Page
     * 
     */
    private void launchSM() {
        try {
            SMUtils.waitForElement( driver, smLaunchButton, 15 );
            SMUtils.clickJS( driver, smLaunchButton );

            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 2 ) );

            WebDriverWait wait1 = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
            WebDriverWait wait11 = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            SMUtils.switchWindow( driver );
            Log.message( "Enter Here in launcher Page is clicked Successfully" );
        } catch ( Exception e ) {
            Log.message( "Unable to click Enter Here button in Launcher Page" );
        }
    }

    /**
     * To enter the credentials in SM application
     * 
     * @param username
     * @param password
     */
    private void enterCredentials( String username, String password ) {
        try {

            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
            wait.until( ExpectedConditions.visibilityOf( elementUsername ) );

            WebDriverWait wait1 = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
            WebDriverWait wait11 = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
            wait11.until( ExpectedConditions.visibilityOf( elementUsername ) );
            elementUsername.clear();
            elementUsername.sendKeys( username );
            Log.event( "Entered userName - " + username );

            wait11.until( ExpectedConditions.visibilityOf( elementPassword ) );
            elementPassword.clear();
            elementPassword.sendKeys( password );
            Log.event( "Entered Password - " + password );

            wait11.until( ExpectedConditions.elementToBeClickable( elementSignInButton ) );
            SMUtils.clickJS( driver, elementSignInButton );
        } catch ( Exception e ) {
            Log.message( "Unable to login to the SM Application" );
        }

    }

    /**
     * To login to SM application
     *
     * @param username
     * @param password
     * @return
     */
    public PrescriptiveSchedulingPage loginToSMPSReport( String username, String password ) throws Exception {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadMFETeacherPage();
        return new PrescriptiveSchedulingPage( driver ).get();
    }

    /**
     * To login to SM application as Admin PSR
     *
     * @param username
     * @param password
     * @return
     */
    public PrescriptiveSchedulingPage loginToSMPSReportAdmin( String username, String password ) throws Exception {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadMFEAdminPage();
        return new PrescriptiveSchedulingPage( driver ).get();
    }

    /**
     * To load MFE page
     *
     */
    private void loadMFETeacherPage() {
        try {
            driver.get( ReportsUIConstants.MFE_TEACHER_URL );
            Log.message( "MFE Teacher Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE Teacher url not loaded" );
        }
    }

    /**
     * @param adminUsername
     * @param adminPassword
     * @return AreasForGrowthReport
     */
    public AreasForGrowthReport loginSMReportsAsAdmin( String adminUsername, String adminPassword ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( adminUsername, adminPassword );
        loadMFEPage();
        return new AreasForGrowthReport( driver ).get();
    }

    /**
     * @param teacherUsername
     * @param teacherPassword
     * @return AreasForGrowthReport
     */
    public com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport loginSMReportsAsTeacher( String teacherUsername, String teacherPassword ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( teacherUsername, teacherPassword );
        loadTeacherMFEPage();
        return new com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport( driver ).get();
    }

    /**
     * To load MFE page
     *
     */
    private void loadMFEAdminPage() {
        try {
            driver.get( ReportsUIConstants.ADMIN_REPORT_MFE_URL );
            Log.message( "Admin report MFE page is loaded" );
        } catch ( Exception e ) {
            Log.message( "Admin report MFE page is loaded" );
        }
    }

    /**
     * This method is used to login SM Reports
     * 
     * @param username
     * @param password
     * @return
     */
    public AreaForGrowthPage loginToSMReports( String username, String password ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadMFEAdminPage();
        return new AreaForGrowthPage( driver ).get();
    }
    
}