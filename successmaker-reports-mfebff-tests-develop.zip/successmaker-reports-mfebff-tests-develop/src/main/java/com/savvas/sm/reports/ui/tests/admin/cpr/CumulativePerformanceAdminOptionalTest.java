package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CumulativePerformanceAdminOptionalTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String org;
    private List<String> courses;

    @BeforeTest
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the Cumulative Performance menu is displayed in the sub-navigation of Reports Page", groups = {"Smoke", "SMK-55038", "AdminDashboard", "Reports", "Area for growth" }, priority = 1 )
    public void tcCumulativePerformance001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance001: VerifyPage title and description <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:01 Verify the Cumulative Performance menu is displayed in the sub-navigation of Reports Page" );
            //           ( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.CUMULATIVE_PERFORMANCE ), "The Cumulative Performance is displayed in Report MFE sub-navigation",
            //                    "Cumulative Performance is displayed in Report MFE sub-navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:02 Verify the Organizations label is displayed in the Cumulative Performance page" );
            SMUtils.logDescriptionTC( "TC:02 Verify the Organizations drop down is displayed Cumulative Performance in the page" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization label is displayed", "The Organization label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ),
                    "The Organization label is displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "The Organization label is not displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.testCaseResult();

            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isMultiSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization drop down is displayed",
                    "The Organization drop down is not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the CP Report generation with 'Student Name' option in Display, None option in Additional Grouping Dropdown and Student from sort", groups = {"Smoke", "SMK-57917", "AdminDashboard", "Reports",
    "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance002: Verify the CP Report generation with Default 'Student Name' option in Display, None option in Additional Grouping Dropdown and Student in sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:03 Verify the CP Report generation with Default 'Student Name' option in Display" );
            SMUtils.logDescriptionTC( "TC:04 Verify the CP Report generation with Default 'None' option in Additional Grouping" );
            SMUtils.logDescriptionTC( "TC:05 Verify the CP Report generation with Default Cumulative 'Student' option in sort" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the CP Report generation with 'Student Username' option in Display, 'Teacher' option in Additional Grouping Dropdown and 'Assigned Course Level' in sort", groups = { "SMK-57917", "AdminDashboard", "Reports",
    "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcCumulativePerformance003: Verify the CP Report generation with 'Student Username' option in Display, 'Teacher' option in Additional Grouping Dropdown and 'Assigned Course Level' in sort <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:06 Verify the CP Report generation with 'Student Username' option in Display" );
            SMUtils.logDescriptionTC( "TC:07 Verify the CP Report generation with 'Teacher' option in Additional Grouping" );
            SMUtils.logDescriptionTC( "TC:08 Verify the CP Report generation with 'Assigned Course Level' option in sort" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Assigned Course Level" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Student ID' option in Display, 'Grade' option in Additional Grouping Dropdown and 'Current Course Level' in sort", groups = { "SMK-57917", "AdminDashboard", "Reports",
    "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance004:Verify the CP Report generation with 'Student ID' option in Display, 'Grade' option in Additional Grouping Dropdown and 'Current Course Level' in sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:09 Verify the CP Report generation with 'Student ID' option in Display" );
            SMUtils.logDescriptionTC( "TC:10 Verify the CP Report generation with 'Grade' option in Additional Grouping" );
            SMUtils.logDescriptionTC( "TC:11 Verify the CP Report generation with 'Current Course Level' option in sort" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );
            cumulativePerformancePage.reportFilterComponent.handleStudentPopup();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Group' option in Additional Grouping Dropdown and 'IP Level' in sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance005:Verify the CP Report generation with 'Group' option in Additional Grouping Dropdown and 'IP Level' in sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:12 Verify the CP Report generation with 'Group' option in Additional Grouping Dropdown" );
            SMUtils.logDescriptionTC( "TC:13 Verify the CP Report generation with 'IP Level' option in sort" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Group" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "IP Level" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Gain' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance006:Verify the CP Report generation with 'Gain' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:14 Verify the CP Report generation with 'Gain' option in Sort" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Gain" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Time Spent' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance007:Verify the CP Report generation with 'Time Spent' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:15 Verify the CP Report generation with 'Time Spent' option in Sort " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Total Sessions' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance008:Verify the CP Report generation with 'Total Sessions' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:16 Verify the CP Report generation with 'Total Sessions' option in Sort  " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Total Sessions" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Exercises Correct' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance009:Verify the CP Report generation with 'Exercises Correct' option in Additional Grouping <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:17 Verify the CP Report generation with 'Exercises Correct' option in Sort  " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Exercises Attempted' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance010:Verify the CP Report generation with 'Exercises Attempted' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:18 Verify the CP Report generation with 'Exercises Attempted' option in Sort " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Attempted" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Exercises Percent Correct' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance011:Verify the CP Report generation with 'Exercises Percent Correct' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:19 Verify the CP Report generation with 'Exercises Percent Correct' option in Sort " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Percent Correct" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Skills Assessed' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance012() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance012:Verify the CP Report generation with 'Skills Assessed' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:20 Verify the CP Report generation with 'Skills Assessed' option in Sort " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Assessed" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Skills Mastered' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance013() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance013:Verify the CP Report generation with 'Skills Mastered' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:21 Verify the CP Report generation with 'Skills Mastered' option in Sort" );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Mastered" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Skills Percent Mastered' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance014() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance014:Verify the CP Report generation with 'Skills Percent Mastered' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:22 Verify the CP Report generation with 'Skills Percent Mastered' option in Sort " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify Optional Filters should display on Cumulative Performance Report" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Percent Mastered" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'AP' option in Sort", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance015() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance015:Verify the CP Report generation with 'AP' option in Sort <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:23 Verify the CP Report generation with 'AP' option in Sort " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();

            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getSelectStudentBy().contentEquals( ReportsUIConstants.CP_SELECT_STUDENT_BY ), "Optional filter is expanded", "Optional Filter is not expanded" );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "AP" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation for All Teachers under Teacher dropdown in optional Filter Dropdown under SELECT STUDENTS BY", groups = { "SMK-57917", "AdminDashboard", "Reports",
    "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance016() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcCumulativePerformance016: Verify the CP Report generation for All Teachers under Teacher dropdown in optional Filter Dropdown under SELECT STUDENTS BY <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:24 Verify the CP Report generation with All Teacher in Teacher Dropdown " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            SMUtils.waitForSpinnertoDisapper( driver, 20 );
            SMUtils.nap( 10 );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );

            List<String> tecValues = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValues: " + tecValues );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected Teacher is displaying",
                    "Selected Teacher is not displaying" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation for All Grade Students under Grades dropdown in optional Filter Dropdown under SELECT STUDENTS BY", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance017() throws Exception {
        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        String headerText = "";

        Log.testCaseInfo( "tcCumulativePerformance017: Verify the CP Report generation for All Grade Students under Grades dropdown in optional Filter Dropdown under SELECT STUDENTS BY <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:25 Verify the CP Report generation with All Grades in Grade Dropdown " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected Grades are displaying",
                    "Selected Grades are not displaying" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation for All Groups under Group dropdown in optional Filter Dropdown under SELECT STUDENTS BY", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance018() throws Exception {
        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance018: Verify the CP Report generation for All Group Students under Group dropdown in optional Filter Dropdown under SELECT STUDENTS BY <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:25 Verify the CP Report generation with All Groups in Group Dropdown " );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( org ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );


            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected Groups are displaying",
                    "Selected Groups are not displaying" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}