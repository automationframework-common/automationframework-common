package com.savvas.sm.reports.bffall.tests;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.LSTeacherReportDBQuery;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class LSRTeacherReportGraphQLTest extends EnvProperties {
	private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String smUrl;
	private String browser;
	private String teacherDetails = null;
	private String orgId = null;
	private String teacherId = null;
	private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();
	private static HashMap<String, String> assignmentIds = new HashMap<String, String>();

	private List<String> courseIDs = new ArrayList<>();
	private HashMap<String, String> groupDetails = new HashMap<>();


	private String username;
	private String studentDetail = null;
	private String studentUserID;
	private String studentUsername;
	private String groupID;
	int mathAssignmentId;
	String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

	@BeforeClass ( alwaysRun = true )
	public void BeforeClass() throws Exception {

		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		browser = configProperty.getProperty( "BrowserPlatformToRun" );

		teacherDetails = RBSDataSetup.getMyTeacher( school );
		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
		username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );

		studentDetail = RBSDataSetup.getMyStudent( school, username );
		studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
		studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );

		studentRumbaIds.add( studentUserID );

		studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
		studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) );
		String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
		groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
		groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		groupDetails.put( GroupConstants.GROUP_NAME, "groupName" );

		assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
		assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

		Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );
		HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
		groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );

		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

		contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

		Log.message( "contentbasename: " + contentBaseName );

		contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, 
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
						contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );


		contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, 
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL,
						contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, 
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
						contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, 
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD,
						contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );


		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );

		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );


		Log.message( "Assigning assignment..." );

		HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
		Log.message( "Assignment Details" + assignmentResponse );
		try {
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), true );
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );

			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false );
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), false );
			executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );
		} catch ( IOException e ) {
			e.printStackTrace();
		}

		JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
		Log.message( "assignmentDetailsJson" + assignmentDetailsJson );
		JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

		for ( Object assignment : assignmentList ) {
			JSONObject assignmentInfo = new JSONObject( assignment.toString() );
			assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
		}
		Log.message( "Assignment IDs - " + assignmentIds );
	}

	@Test ( enabled = true, priority = 1, dataProvider = "PositiveScenarios", groups = { "Teacher LSR Report Graphql", "SMK-59115", "P1", "API"} )
	public void getTeacherLSReport_Positive( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
		Log.testCaseInfo( testcaseName + testcaseDescription );

		HashMap<String, String> headers = new HashMap<>();
		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
		headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
		headers.put( Constants.USERID_SM_HEADER, teacherId);
		headers.put( Constants.ORGID_SM_HEADER, orgId );
		headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
		Response response = null;

		String payload = null;
		switch ( scenarioType ) {
		case "MATH":

			Log.testCaseInfo( "Verify the 200 code graphql response is obtaining the predictable result for mandatory query input params (Teacher id and organization id)" );
			Log.testCaseInfo( "Verify the 200 code graphql response is obtaining the predictable result for all query input params" );
			Log.testCaseInfo( "Verify the 200 response 7 days before today Date report data are fetched when no start date is provided in the query input params");
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining the predictable result when valid studentId's data are provided in the query input params" );
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when multiple set query is given for lsReportData query with in the query input params");
			
			int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true );

			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+ payload  );

			// Get data from response
			HashMap<String, String> dataFromResponse = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response-Math: " + dataFromResponse );

			String mathAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathAssignmentId)  );

			// Get data from DB
			Map<String,  String> lsrdataFromDB = LSRdataFromDB( mathAssignmentUserId, true );
			Log.message( "LSR Data From DB -Math: " + ( lsrdataFromDB ) );
			Log.assertThat( SMUtils.compareTwoHashMap(lsrdataFromDB, dataFromResponse), "Report data are same as DB data", "Report data are not same as DB data" );
			break;



		case "MATH_SETTINGS":

			Log.testCaseInfo( "Verify Math subject data report are returned as 200 response when subjectId param is provided with \"1\" in the query input params" );
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when lastSession is given for getlsReportData query with in the query input params" );
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when all set query is given for lsReportData sub set query with in the query input params" );
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when all set query is given for lsReportData query with in the query input params");
			
			int mathSettingsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 1, true, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathSettingsAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+ payload );

			// Get data from response
			HashMap<String, String> dataFromResponseMathSettings = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response-MathSet: " + dataFromResponseMathSettings );

			String mathSettingsAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathSettingsAssignmentId)  );

			// Get data from DB
			Map<String, String> lsrdataFromDBMathSettings = LSRdataFromDB( mathSettingsAssignmentUserId, true );
			Log.message( "LSR Data From DB-MathSet: " + ( lsrdataFromDBMathSettings ) );
			Log.assertThat( SMUtils.compareTwoHashMap(lsrdataFromDBMathSettings, dataFromResponseMathSettings), "Report data are same as DB data", "Report data are not same as DB data" );
			break;


		case "MATH_SKILLS":

			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when multiple set query is given for lsReportData sub set query with in the query input params");
			Log.testCaseInfo( "Verify 200 response the first 100 rows of report data are fetched when limit and offset are not provided in the query input params");
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when single set query is given for lsReportData query with in the query input params");
			Log.testCaseInfo( "Verify the graphql 200 response is obtaining predictable response when single set query is given for teacherInfo sub set query with in the query input params");
			
			int mathSkillsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 1, true, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathSkillsAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+ payload );

			// Get data from response
			HashMap<String, String> dataFromResponseMathSkills = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response-MathSkills: " + dataFromResponseMathSkills );

			String mathSkillsAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathSkillsAssignmentId)  );

			// Get data from DB
			Map<String, String> lsrdataFromDBMathSkills = LSRdataFromDB( mathSkillsAssignmentUserId, true );
			Log.message( "LSR Data From DB-MathSet: " + ( lsrdataFromDBMathSkills ) );
			Log.assertThat( SMUtils.compareTwoHashMap(lsrdataFromDBMathSkills, dataFromResponseMathSkills), "Report data are same as DB data", "Report data are not same as DB data" );
			break;



		case "MATH_STANDARDS":

			Log.testCaseInfo( "Verify 200 response the report data are sorted by person_id by default if the orderBy is not provided in the query input params");
			Log.testCaseInfo( "Verify Reading subject data report are returned as 200 response when subjectId param is provided with 2 in the query input params");
			Log.testCaseInfo( "Verify 200 response the report data are sorted with respect to the orderBy value if the orderBy with valid data is provided in the query input params");
			
			int mathStdsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 1, true, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathStdsAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+ payload );

			// Get data from response
			HashMap<String, String> dataFromResponseMathStds = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response-MathStd: " + dataFromResponseMathStds );

			String mathStdsAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathStdsAssignmentId)  );

			// Get data from DB
			Map<String, String> lsrdataFromDBMathStds = LSRdataFromDB( mathStdsAssignmentUserId, true );
			Log.message( "LSR Data From DB-MathSet: " + ( lsrdataFromDBMathStds ) );
			Log.assertThat( SMUtils.compareTwoHashMap(lsrdataFromDBMathStds, dataFromResponseMathStds), "Report data are same as DB data", "Report data are not same as DB data" );
			break;



		case "READING":

			int readAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+payload );

			// Get data from response
			HashMap<String,String> dataFromResponseRead = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response-Read: " + dataFromResponseRead );

			String readAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(readAssignmentId)  );

			// Get data from DB
			HashMap<String, String> readLSRdataFromDB = LSRdataFromDB( readAssignmentUserId , false);
			Log.message( "LSR Data From DB -Read: " +  readLSRdataFromDB  );
			Log.assertThat( SMUtils.compareTwoHashMap(readLSRdataFromDB, dataFromResponseRead), "Report data are same as DB data", "Report data are not same as DB data" );
			break;



		case "READING_SETTINGS":

			int readSettingsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readSettingsAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+payload );

			// Get data from response
			HashMap<String, String> dataFromResponseReadSet = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response DB-ReadSet: " + dataFromResponseReadSet );

			String readSettingsAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(readSettingsAssignmentId)  );

			// Get data from DB
			HashMap<String, String> readSetLSRdataFromDB = LSRdataFromDB( readSettingsAssignmentUserId, false );
			Log.message( "LSR Data From DB-ReadSet: " + ( readSetLSRdataFromDB ) );
			Log.assertThat( SMUtils.compareTwoHashMap(dataFromResponseReadSet, readSetLSRdataFromDB), "Report data are same as DB data", "Report data are not same as DB data" );
			break;


		case "READING_SKILLS":

			int readSkillsAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );

			payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readSkillsAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+payload );

			// Get data from response
			HashMap<String, String> dataFromResponseReadSkills = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response DB-ReadSet: " + dataFromResponseReadSkills );

			String readSkillsAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(readSkillsAssignmentId)  );

			// Get data from DB
			HashMap<String, String> readSkillsLSRdataFromDB = LSRdataFromDB( readSkillsAssignmentUserId, false );
			Log.message( "LSR Data From DB-ReadSet: " + ( readSkillsLSRdataFromDB ) );
			Log.assertThat( SMUtils.compareTwoHashMap(dataFromResponseReadSkills, readSkillsLSRdataFromDB), "Report data are same as DB data", "Report data are not same as DB data" );
			break;


		case "READING_STANDARDS":

			int readStdAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 2, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( readStdAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+payload );

			// Get data from response
			HashMap<String, String> dataFromResponseReadStd = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response DB-ReadSet: " + dataFromResponseReadStd );

			String readStdAssignmentUserId=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(readStdAssignmentId)  );

			// Get data from DB
			HashMap<String, String> readStdLSRdataFromDB = LSRdataFromDB( readStdAssignmentUserId, false );
			Log.message( "LSR Data From DB-ReadSet: " + ( readStdLSRdataFromDB ) );
			Log.assertThat( SMUtils.compareTwoHashMap(dataFromResponseReadStd, readStdLSRdataFromDB), "Report data are same as DB data", "Report data are not same as DB data" );
			break;


		case "WIHTOUT_MATH_SUBJECTID":

			
			int mathAssignmentId1 = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
			payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId1 ), false );

			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.message( "payload:"+ payload  );

			// Get data from response
			HashMap<String, String> dataFromResponse1 = getDataFromResponse( response.getBody().asString() );
			Log.message( "LSR Data From Response-Math: " + dataFromResponse1 );

			String mathAssignmentUserId1=new SqlHelperCourses().getAssignmentUserId( studentUserID,String.valueOf(mathAssignmentId1)  );

			// Get data from DB
			Map<String,  String> lsrdataFromDB1 = LSRdataFromDB( mathAssignmentUserId1, true );
			Log.message( "LSR Data From DB -WithoutSubId: " + ( lsrdataFromDB1 ) );
			Log.assertThat( SMUtils.compareTwoHashMap(lsrdataFromDB1, dataFromResponse1), "Report data are same as DB data", "Report data are not same as DB data" );
			break;
		}
		Log.testCaseResult();

	}


	@DataProvider (name="PositiveScenarios")
	public Object[][] PositiveScenarios() {
		return new Object[][] { 
			{ "TC001", "200", "Verify the 200 code graphql response is obtaining the predictable result for all set of Fields for LS Reports query", "MATH" }, 
			{ "TC002", "200", "Verify the graphql 200 response is obtaining predictable response with respective assignments report data when valid assignmentId's are provided in the query input params", "MATH_SETTINGS" },
			{ "TC003", "200", "Verify the 200 response is fetching respective data with respect to the studentId's, subjectId, limit, offset, orderBy, assignmentId's with valid data are provided in the query input params", "MATH_SKILLS" },
			{ "TC004", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body for Math-Standards" , "MATH_STANDARDS" },
			{ "TC005", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body for Default Reading" , "READING" },
			{ "TC006", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body for Reading-Settings" , "READING_SETTINGS" },
			{ "TC007", "200", "Verify 200 response the report data are fetched from 5-105 when limit is provided with 100 and offset value is provided with 5 in the query input params" , "READING_SKILLS" },
			{ "TC008", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body for Reading-Standards" , "READING_STANDARDS" },
			{ "TC009", "200", "Verify the graphql 200 response is obtaining the Math subject(Default) data report are returned as response when subjectId param is not provided in query input params" , "WIHTOUT_MATH_SUBJECTID" },

		};
	}


	@Test ( enabled = true, priority = 2, dataProvider = "getDataNegativeCases", groups = { "Teacher LSR Report Graphql", "SMK-59115", "P2", "API" } )
	public void getTeacherLSReport_Negative( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
		Log.testCaseInfo( testcaseName + testcaseDescription );

		HashMap<String, String> headers = new HashMap<>();
		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
		headers.put( Constants.USERID_SM_HEADER, teacherId );
		headers.put( Constants.ORGID_SM_HEADER, orgId );
		headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

		String payload = null;
		Response response = null;
		int mathAssignmentId = Integer.parseInt( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

		switch ( scenarioType ) {
		case "INVALID_TOKEN":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, "abcd" );

			payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat(response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Unauthorized message returned as expected!", "Unauthorized message is not returned!!"); 
			break;

		case "INVALID_TEACHER_ID":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, "ABCD" );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat(response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message returned as expected!", "Message is not returned!!"); 
			break;

		case "INVALID_ORG_ID":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, "1234" );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat(response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message returned as expected!", "Message is not returned!!"); 
			break;

		case "INVALID_QUERY":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, "1234", 1, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_FOUND_404 )   , "Message returned as expected!", "Message is not returned!!"); 
			break;

		case "INVALID_SUB_ID":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, orgId, 5, false, Arrays.asList( groupID ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true);
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.INVALID_MESSAGE_FOR_SUBJECTID )   , "Message returned as expected!", "Message is not returned!!"); 
			break;

		case "EMPTY_STUDENT":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, orgId, 1, false, Arrays.asList( "" ), Arrays.asList( "" ), Arrays.asList( mathAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.STUDENTS_NOT_FOUND )   , "Message returned as expected!", "Message is not returned!!"); 
			break;

		case "EMPTY_GROUPS":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, orgId, 1, true, Arrays.asList( "" ), Arrays.asList( studentUserID ), Arrays.asList( mathAssignmentId ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.STUDENTS_NOT_FOUND )   , "Message returned as expected!", "Message is not returned!!"); 
			break;

		case "INVALID_ASSIGNMENT_ID":
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( Constants.USERID_SM_HEADER, teacherId );
			headers.put( Constants.ORGID_SM_HEADER, orgId );
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );

			payload = getResponseBody( teacherId, orgId, 1, true, Arrays.asList( "groupID" ), Arrays.asList( studentUserID ), Arrays.asList( 0 ), true );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			Log.message( "response :"+ response.getBody().asString());
			Log.assertThat( String.valueOf( response.getStatusCode() ).equals( Constants.VALID_RESPONSE_200 ), "Status code is returned as expected", "Status code is not returned as expected" );
			Log.assertThat( response.getBody().asString().contains("\"totalNoOfRows\": 0")  , "Message returned as expected!", "Message is not returned!!"); 
			break;
		}
		Log.testCaseResult();
	}

	@DataProvider (name ="getDataNegativeCases")
	public Object[][] getDataNegativeCases() {
		return new Object[][] { 
			{ "TC010", "401", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_TOKEN" },
			{ "TC011", "401", "Verify 401: UnAuthorized message in response when invalid teacher-id is given in input query param for LS Reports query \r\n"
					+ "", "INVALID_TEACHER_ID" },
			{ "TC012", "403", "Verify 403 the user is not authorized message on the response when irrespective org id is given in input query param for LS Reports query\r\n"
					+ "", "INVALID_ORG_ID" },
			{ "TC013", "400", "Verify 400: Bad Request in the error message of the response body when invalid query has been given", "INVALID_QUERY" },
			{ "TC014", "400", "Verify 400 code in the error message of the response body when invalid subject id is given in the query \r\n"
					+ "", "INVALID_SUB_ID" },
			{ "TC015", "400", "Verify 400 code and validation error in the graphql response when empty studentId is provided in the query input params\r\n"
					+ "", "EMPTY_STUDENT" },
			{ "TC016", "400", "Verify 400 code and validation error in the graphql response when empty groupId is provided in the query input params\r\n"
					+ "", "EMPTY_GROUPS" }
		};
	}



	// Get response body
	public String getResponseBody( String userId, String orgId, int subject, boolean isGroupSelected, List<String> groupIds, List<String> studentIds, List<Integer> assignmentIds, boolean withSubjectParam ) {
		AtomicReference<String> requestBody = new AtomicReference<>();
		try {

			if (withSubjectParam==false) {
				// Generate Pay load
				String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report"
						+ File.separator;
				requestBody.set( SMUtils.convertFileToString( basePath + "LSTeacherReportRequest.json" ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", orgId ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.teacherId", userId ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.isGroupSelected", isGroupSelected ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.limit", ReportAPIConstants.LIMITS ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.offset", ReportAPIConstants.OFFSETS ) );
				requestBody.set( JSONUtil.removeProperty(requestBody.get(), "variables.subject") );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.studentIds", studentIds ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.groupIds", groupIds ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.assignmentIds", assignmentIds ) );
			} else {
				String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report"
						+ File.separator;
				requestBody.set( SMUtils.convertFileToString( basePath + "LSTeacherReportRequest.json" ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", orgId ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.teacherId", userId ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.isGroupSelected", isGroupSelected ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.limit", ReportAPIConstants.LIMITS ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.offset", ReportAPIConstants.OFFSETS ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.subject", subject ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.studentIds", studentIds ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.groupIds", groupIds ) );
				requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.assignmentIds", assignmentIds ) );
			}


			Log.message( "Payload : " + requestBody.get() );
		} catch ( Exception e ) {
			Log.message( e.getMessage() );
		}
		return requestBody.get();
	}

	public  HashMap<String, String> getDataFromResponse( String response ) {

		// Getting data from response
		String jsonObj = getKeyValueFromResponseWithArray( response, "data,getLSReportData,lsReportResponse" );
		Log.message( "Response Data: " + jsonObj );

		HashMap<String, String> studentReport = new HashMap<>();
		String rawPerformance = getKeyValueFromResponseWithArray( jsonObj, "rows" );

		//Loop1
		IntStream.range( 0, new JSONArray( rawPerformance ).length() ).forEach( itr -> {

			String currentCourseLevel = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "currentCourseLevel" );
			String totalCorrect = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalCorrect" );
			String totalAttempts = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalAttempts" );
			String sessionHelpCount = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "sessionHelpCount" );
			String timeSpent = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "timeSpent" );
			String totalSessions = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( rawPerformance ).get( itr ).toString(), "totalSessions" );

			String hour;
			String min;
			if (timeSpent.length()==5) {
				hour = timeSpent.substring(0,2);
				min = timeSpent.substring(3);

			} else {
				hour = timeSpent.substring(0,1);
				min = timeSpent.substring(2);
			}
			int hourInt = Integer.parseInt(hour);
			int minInt = Integer.parseInt(min);
			int timeSpentValue = hourInt * 60 + minInt;

			float courseLvlFloat = Float.parseFloat(currentCourseLevel);
			int courseLvl = (int)courseLvlFloat;
			currentCourseLevel = String.valueOf(courseLvl);


			studentReport.put( "currentCourseLevel", currentCourseLevel );
			studentReport.put( "totalCorrect", totalCorrect );
			studentReport.put( "totalAttempts", totalAttempts );
			studentReport.put( "sessionHelpCount", sessionHelpCount );
			studentReport.put( "timeSpent", String.valueOf(timeSpentValue) );
			studentReport.put( "totalSessions", totalSessions );
			Log.message("StudentReportDetails: " + studentReport);

		} );
		return studentReport;
	}




	/**
	 * To get the LSR data from DB
	 * 
	 * @param assignmentUserID
	 * @return valuesFromDB
	 */
	public HashMap<String, String> LSRdataFromDB( String assignmentUserId, boolean isMath ) {
		HashMap<String, String> valuesFromDB = new HashMap<>();
		String query;

		if (isMath==true) {

			query = LSTeacherReportDBQuery.LS_TEACHER_MATH_QUERY.replace("mathAssignmentUserID", assignmentUserId);
		} else {

			query = LSTeacherReportDBQuery.LS_TEACHER_READ_QUERY.replace("readAssignmentUserID", assignmentUserId);
		}

		List<Object[]> rowList = SQLUtil.executeQuery( query );
		rowList.forEach( object -> {

			String courseLevel= object[1].toString();
			float courseLvlFloat = Float.parseFloat(courseLevel);
			int courseLvl = (int)courseLvlFloat;
			courseLevel = String.valueOf(courseLvl);

			valuesFromDB.put( "currentCourseLevel", courseLevel );
			valuesFromDB.put( "totalCorrect", object[2].toString() );
			valuesFromDB.put( "totalAttempts", object[3].toString() );
			valuesFromDB.put( "sessionHelpCount", object[4].toString() );
			valuesFromDB.put( "timeSpent", object[5].toString() );
			valuesFromDB.put( "totalSessions", object[6].toString() );
		}
				);
		return valuesFromDB;
	}



	/**
	 * This method will return all the parameters which present in given path
	 * Even it is array, object etc.
	 * 
	 * @param response
	 * @param path
	 * @return
	 */
	public static String getKeyValueFromResponseWithArray( String response, String path ) {
		String[] json_Array = path.split( "," );
		String keyValue = null;
		try {
			if ( json_Array.length <= 1 ) {
				JSONObject jsonObj = new JSONObject( response );
				String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
				return JsonArrayValue;
			} else if ( json_Array.length == 2 ) {
				JSONObject jsonObj = new JSONObject( response );
				String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
				JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
				keyValue = jsonObj1.get( json_Array[1] ).toString();
				return keyValue;
			} else if ( json_Array.length == 3 ) {
				JSONObject jsonObj = new JSONObject( response );
				String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
				JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
				String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
				JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
				keyValue = jsonObj2.get( json_Array[2] ).toString();
				//return keyValue;
			}
		} catch ( Exception e ) {
			e.printStackTrace();
			return keyValue;
		}
		return keyValue;
	}




	/**
	 * To execute the course
	 * 
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
		final WebDriver driver = WebDriverFactory.get( browser );
		Log.message( "Student username " + studentUserName );
		LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
		StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

		if ( isMath ) {
			try {
				studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
				studentsPage.logout();
				driver.close();
			} catch ( Exception e ) {
				driver.close();
			}
		} else {
			try {
				studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "20" );
				studentsPage.logout();
				driver.close();
			} catch ( Exception e ) {
				driver.close();
			}
		}

	}

}
