package com.savvas.sm.reports.smoke.admin.pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.admin.ui.pages.AdminReportFilterComponent;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class PerspectiveSchedulingReport extends LoadableComponent<PerspectiveSchedulingReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public AdminReportFilterComponent reportFilterComponent;

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Prescriptive Scheduling Report']", AI = false )
    public WebElement txtPerspectiveSchedulingReportHeader;

    @IFindBy ( how = How.CSS, using = "input#gradek", AI = false )
    public WebElement fldGradeK;

    @IFindBy ( how = How.CSS, using = "input#grade1", AI = false )
    public WebElement fldGrade1;

    @IFindBy ( how = How.CSS, using = "input#grade2", AI = false )
    public WebElement fldGrade2;

    @IFindBy ( how = How.CSS, using = "input#grade3", AI = false )
    public WebElement fldGrade3;

    @IFindBy ( how = How.CSS, using = "input#grade4", AI = false )
    public WebElement fldGrade4;

    @IFindBy ( how = How.CSS, using = "input#grade5", AI = false )
    public WebElement fldGrade5;

    @IFindBy ( how = How.CSS, using = "input#grade6", AI = false )
    public WebElement fldGrade6;

    @IFindBy ( how = How.CSS, using = "input#grade7", AI = false )
    public WebElement fldGrade7;

    @IFindBy ( how = How.CSS, using = "input#grade8", AI = false )
    public WebElement fldGrade8;

    @IFindBy ( how = How.CSS, using = "input#grade9", AI = false )
    public WebElement fldGrade9;

    @IFindBy ( how = How.CSS, using = "input#grade10", AI = false )
    public WebElement fldGrade10;

    @IFindBy ( how = How.CSS, using = "input#grade11", AI = false )
    public WebElement fldGrade11;

    @IFindBy ( how = How.CSS, using = "input#grade12", AI = false )
    public WebElement fldGrade12;

    @IFindBy ( how = How.XPATH, using = "//label[text()=' SET TARGET DATE ']", AI = false )
    public WebElement txtSetTargetDate;

    @IFindBy ( how = How.CSS, using = "div.col.date-container", AI = false )
    public WebElement eleDateContainer;

    @IFindBy ( how = How.XPATH, using = "//*[text()=' SET TARGET LEVEL PER GRADE ']", AI = false )
    public WebElement txtSetTargetLevelPerGrade;

    @IFindBy ( how = How.TAG_NAME, using = "cel-date-input", AI = false )
    public WebElement targetDateRoot;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String calDateInput[] = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('#celDateInput')" };
    public String iconDatePicker[] = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('div > cel-icon-button').shadowRoot.querySelector('button > cel-icon')" };

    public String drpDwnAdditionalGroupingshadowDOM[] = { "cel-single-select", "document.querySelector('#additional-grouping').shadowRoot.querySelector('#dropdown')" };
    public String elePrescriptiveSchedulingAggregateReportshadowDOM[] = { "cel-tab-panel", "document.querySelector('cel-tab-panel').shadowRoot.querySelector('#\\\\31')" };

    public String btnPrescriptiveSchedulingAggregate[] = { "cel-tab-panel", "document.querySelector('cel-tab-panel').shadowRoot.querySelector('button[id = \"1\"]')" };
    public String[] targetDateElement = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('#celDateInput');" };
    public String[] btnCalendarIcon = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('cel-icon-button').shadowRoot.querySelector('button')" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };

    List<String> expectedGrades = new ArrayList<String>( Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12" ) );
    /* String used for List of Elements inside Methods */

    public String grades = "//label[contains(text(),' Grade ')]";
    public String targetDate = " SET TARGET DATE ";
    public String targetLevelPerGrade = " SET TARGET LEVEL PER GRADE ";

    public String txtAdditionalGroupingDrpdwn = "grade";
    public String txtPrescriptiveSchedulingAggregate = "Prescriptive Scheduling Aggregate";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtPerspectiveSchedulingReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public PerspectiveSchedulingReport() {}

    public PerspectiveSchedulingReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas Validate Calendar Date Input Field
     * @throws InterruptedException
     */
    public void validateCalendarDateInputField( WebDriver driver ) throws InterruptedException {
        WebElement calDateInput = ShadowDOMUtils.retryAndGetWebElement( driver, this.calDateInput[0], this.calDateInput[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, calDateInput, "Calendar Date Input" );
    }

    /**
     * @author aravindan.srinivas Validate Icon Date Picker
     * @throws InterruptedException
     */
    public void validateIconDatePicker( WebDriver driver ) throws InterruptedException {
        WebElement iconDatePicker = ShadowDOMUtils.retryAndGetWebElement( driver, this.iconDatePicker[0], this.iconDatePicker[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, iconDatePicker, "Icon Date Picker" );
    }

    /**
     * @author aravindan.srinivas verify the text Set Target Date is Displayed
     *         in the web page.
     * @param driver
     */
    public void verifyTextSetTargetDate( WebDriver driver ) {
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSetTargetDate, targetDate, "Set Target Date" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSetTargetDate, "Set Target Date Element" );
    }

    /**
     * @author aravindan.srinivas verify the Set Target Level PerGrade is
     *         Displayed in the web page.
     * @param driver
     */
    public void verifyTextSetTargetLevelPerGrade( WebDriver driver ) {
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtSetTargetLevelPerGrade, targetLevelPerGrade, "Set Target Level PerGrade" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtSetTargetLevelPerGrade, "Set Target Level PerGrade Element" );
    }

    /**
     * @author aravindan.srinivas verify the Date Container is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyDateContainer( WebDriver driver ) {
        ReportsBrowserActions.verifyElementIsDisplayed( driver, eleDateContainer, "Date Container Element" );
    }

    /**
     * @author aravindan.srinivas Validate Grade from K to 12
     */
    public void validateGrades( WebDriver driver ) {
        List<WebElement> elements = driver.findElements( By.xpath( grades ) );

        List<String> actualGrades = new ArrayList<String>();
        for ( WebElement ele : elements ) {
            actualGrades.add( ele.getText().trim() );
        }
        Log.assertThat( actualGrades.equals( expectedGrades ), "Grades Matched", "Grades MisMatched!!" );

    }

    /**
     * @author aravindan.srinivas verify the Elements Grade is Displayed in the
     *         web page.
     * @param driver
     */
    public void verifyElementGrades( WebDriver driver ) {

        List<WebElement> gradeElement = driver.findElements( By.cssSelector( "input[id*='grade']" ) );

        for ( int i = 0; i < gradeElement.size(); i++ ) {
            String attributeID = gradeElement.get( i ).getAttribute( "id" );
            ReportsBrowserActions.verifyElementIsDisplayed( driver, gradeElement.get( i ), attributeID );
        }
        Log.assertThat( gradeElement.size() == 13, "Grades Count :" + gradeElement.size() + "Is Matched", "Grades Count :" + gradeElement.size() + "Is MisMatched" );
    }

    /**
     * @author aravindan.srinivas validate Additional Grouping drop down Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAdditionalGroupingDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnAdditionalGroupingshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnAdditionalGroupingshadowDOM[0], this.drpDwnAdditionalGroupingshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnAdditionalGroupingshadowDOM, "Additional Grouping Drop Down Field" );
        String attributeValue = drpDwnAdditionalGroupingshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equalsIgnoreCase( txtAdditionalGroupingDrpdwn ), "Selected '" + attributeValue + "' as default value in Additional Grouping Drpdwn Field",
                "'" + attributeValue + "' is not a default value in Additional Grouping Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas validate the user able to land on the
     *         Perspective Scheduling Aggregate Report Page
     * @return
     * @return CumulativePerformanceAggregateReport page
     * @throws InterruptedException
     */
    public PerspectiveSchedulingAggregateReport navigateToPerspectiveSchedulingAggregateReport( WebDriver driver ) throws InterruptedException {
        WebElement elePrescriptiveSchedulingAggregateReportshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.elePrescriptiveSchedulingAggregateReportshadowDOM[0], this.elePrescriptiveSchedulingAggregateReportshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, elePrescriptiveSchedulingAggregateReportshadowDOM, "Prescriptive Scheduling Aggregate Report" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, elePrescriptiveSchedulingAggregateReportshadowDOM, txtPrescriptiveSchedulingAggregate, "Text : Prescriptive Scheduling Aggregate Report" );
        ReportsBrowserActions.click( driver, elePrescriptiveSchedulingAggregateReportshadowDOM, "Cumulative Performance Aggregate Report" );
        return new PerspectiveSchedulingAggregateReport( driver ).get();
    }

    /**
     * @author aravindan.srinivas Validate all the fields and headers present in
     *         the Perspective Scheduling Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInPerspectiveSchedulingReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtPerspectiveSchedulingReportHeader.getText();
        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        reportsFilterUtils.verifyTextOrganizationsHeader( driver );
        reportsFilterUtils.validateOrgDrpdwnField( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        verifyTextSetTargetDate( driver );
        verifyDateContainer( driver );
        validateCalendarDateInputField( driver );
        validateIconDatePicker( driver );
        verifyTextSetTargetLevelPerGrade( driver );
        validateGrades( driver );
        verifyElementGrades( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );

        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );

        reportsFilterUtils.verifyTextSelectStudentBy( driver );

        reportsFilterUtils.verifyTextTeacher( driver );
        reportsFilterUtils.validateTeacherDrpdwnField( driver );

        reportsFilterUtils.verifyTextGrade( driver );
        reportsFilterUtils.validateGradeDrpdwnField( driver );

        reportsFilterUtils.verifyTextGroup( driver );
        reportsFilterUtils.validateGroupDrpdwnField( driver );

        reportsFilterUtils.verifyTextAdditionalGrouping( driver );
        validateAdditionalGroupingDrpdwnField( driver );

        reportsFilterUtils.verifyTextDisplay( driver );
        reportsFilterUtils.validateDisplayDrpdwnField( driver );

        reportsFilterUtils.validateMaskCheckBoxField( driver );

        reportsFilterUtils.verifyTextSortInAdditionalGrouping( driver );
        reportsFilterUtils.validateSortDrpdwnField( driver, currentReportName );

        // Demographics Filter
        WebElement txtStudentDemographics = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtStudentDemographicsShadowDOM[0], reportsFilterUtils.txtStudentDemographicsShadowDOM[1] );
        SMUtils.click( driver, txtStudentDemographics );

        reportsFilterUtils.verifyTextDisablityStatus( driver );
        reportsFilterUtils.validateDisabilityStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextEnglishLanguageProficiency( driver );
        reportsFilterUtils.validateEnglishLanguageProficiencyDrpdwnField( driver );

        reportsFilterUtils.verifyTextEthnicity( driver );
        reportsFilterUtils.validateEthnicityDrpdwnField( driver );

        reportsFilterUtils.verifyTextMigrantStatus( driver );
        reportsFilterUtils.validateMigrantStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextRace( driver );
        reportsFilterUtils.validateRaceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSpecialServices( driver );
        reportsFilterUtils.validateSpecialServiceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSocioEconomicStatus( driver );
        reportsFilterUtils.validateSocioEconomicStatusDrpdwnField( driver );
    }

    /**
     * This method is dynamically working to select the grade in Prescriptive
     * Scheduling page by giving the inputs of grade and value
     * 
     * @author raseem.mohamed
     * @param driver
     * @param gradeToSelect
     * @param value
     *
     */
    public void enterGrade( WebDriver driver, String gradeToEnter, String gradeValueToEnter ) {
        String gradeValue = null;
        try {
            float rawValue2 = Float.valueOf( gradeValueToEnter ).floatValue();
            gradeValue = String.valueOf( rawValue2 );
            WebElement grades = driver.findElement( By.xpath( "//input[@id='grade" + gradeToEnter + "']" ) );
            // Click on the respective grade and clear the field before entering the value
            Actions action = new Actions( driver );
            action.moveToElement( grades ).doubleClick().click().sendKeys( Keys.BACK_SPACE ).perform();
             action.moveToElement( grades ).click().sendKeys( gradeValue ).perform();
            Log.message( "'" + gradeValue + "'Value Entered Successfully On Grade " + gradeToEnter );
        } catch ( Exception e ) {
            Log.message( "Failed : '" + gradeValue + "'Value Not Entered Successfully On Grade " + gradeToEnter );
            e.printStackTrace();
        }

    }

    /**
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public void SelectGradeAndEnterTheGrade( WebDriver driver ) throws InterruptedException {
        enterGrade( driver, ReportsUIConstants.GRADE_K, "1" );
    }

    /**
     * @author sathish.suresh Validate PSR run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validatePSRRunReport( WebDriver driver, String flexSchoolId ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        this.chooseOrganization( driver, flexSchoolId );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        PerspectiveSchedulingReport perspectiveSchedulingReport = new PerspectiveSchedulingReport( driver );
        perspectiveSchedulingReport.selectTargetDate( driver, 3 );
        perspectiveSchedulingReport.SelectGradeAndEnterTheGrade( driver );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sathish.suresh Perscriptive Scheduling saved report Validation
     * @param driver
     * @param flexSchoolId 
     * @throws InterruptedException
     */
    public void validatePSRSavedReports( WebDriver driver, String flexSchoolId ) throws InterruptedException {
        Random rnd = new Random();
        int n = 1 + rnd.nextInt();
        String savedReportName = "Automation Validation" + n; // update
        System.out.println( savedReportName );
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Prescriptive Scheduling Report" ), "User Landed On Areas Of Growth Report", "User Not Landed On Areas Of Growth Report" );

        WebElement drpdwnSubjectshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnSubjectshadowDOM[0], reportsFilterUtils.drpdwnSubjectshadowDOM[1] );
        WebElement drpdwnCoursesshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnCoursesshadowDOM[0], reportsFilterUtils.drpdwnCoursesshadowDOM[1] );

        this.chooseOrganization( driver, flexSchoolId );
        

        SMUtils.click( driver, drpdwnSubjectshadowDOM );
        Log.message( "User Clicked On Subject Drop Down" );
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelect( driver, drpdwnSubjectshadowDOM, "Math", "Course drop Down" );

        Thread.sleep( 2000 );
        reportsFilterUtils.verifyCourseDropDownIsEnabled( driver, drpdwnCoursesshadowDOM );
        ArrayList<String> optionToSelect = new ArrayList<String>( Arrays.asList( "Select All" ) );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", optionToSelect );

        PerspectiveSchedulingReport perspectiveSchedulingReport = new PerspectiveSchedulingReport( driver );

        // select date
        perspectiveSchedulingReport.selectTargetDate( driver, 3 );
        // select grade
        perspectiveSchedulingReport.SelectGradeAndEnterTheGrade( driver );
        Thread.sleep( 3000 );
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author sathish.suresh Click on Prescriptive Scheduling aggregate report
     * @param driver
     * @return
     */
    public PerspectiveSchedulingAggregateReport clickPerspectiveSchedulingAggregateReport( WebDriver driver ) {
        WebElement webElement = ShadowDOMUtils.getWebElement( driver, btnPrescriptiveSchedulingAggregate[0], btnPrescriptiveSchedulingAggregate[1] );
        SMUtils.click( driver, webElement );
        Log.message( "Clicked on Perspective Scheduling Aggregate Report" );
        return new PerspectiveSchedulingAggregateReport( driver ).get();
    }

    public void selectTargetDate( WebDriver driver, int futureDateCount ) throws InterruptedException {
        SMUtils.nap( 3 );
        SMUtils.waitForElement( driver, targetDateRoot );
        WebElement inpDate = ShadowDOMUtils.retryAndGetWebElement( driver, targetDateElement[0], targetDateElement[1] );
        SMUtils.scrollDownIntoViewElement( driver, inpDate );
        Calendar calendar = Calendar.getInstance();
        calendar.add( Calendar.DATE, futureDateCount );
        Date futureDate = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy" );
        String formattedDate = sdf.format( futureDate );
        inpDate.clear();
        inpDate.sendKeys( formattedDate );
        inpDate.click();
        Log.message( "Date Selected" );
    }

    /**
     * @author sakthi.sasi Used to perform Organization choosing
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public PerspectiveSchedulingReport chooseOrganization( WebDriver driver, String orgId ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.nap( 5 );
        System.out.println( orgId );
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, drpOrganizationOptions[0], drpOrganizationOptions[1] );
        drpdwnElement.click();
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelectValue( driver, drpdwnElement, orgId, "Choosing Organization" );
        return this;

    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public PerspectiveSchedulingReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtPerspectiveSchedulingReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to expand optional filters
     * 
     * @param driver
     * @return
     */
    public PerspectiveSchedulingReport clickOptionalFilters( WebDriver driver ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtPerspectiveSchedulingReportHeader );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        SMUtils.click( driver, txtOptionalFilter );
        return this;

    }

    /**
     * @author sakthi.sasi Used to verify the Organization ID's
     * 
     * @param driver
     * @param districtAdmin
     * @param smUrl
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingReport verifyOrgIds( WebDriver driver, Admins districtAdmin, String smUrl ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.compareOrganizationElements( driver, districtAdmin, smUrl ), "Organization List Matches", "Organization List doesn't Match" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Organization is available or not
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public PerspectiveSchedulingReport verifyOrg( WebDriver driver, String orgName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.validateOrganizationDropdownValue( driver, orgName ), "Organization is Available", "Organization is not Available" );
        return this;
    }

    /**
     * @author raseem.mohamed Used to verify the Courses
     * @param driver
     * @param admin
     * @param orgIds
     * @param SubjectName
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingReport verifyCourses( WebDriver driver, Admins admin, List<String> orgIds, String SubjectName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expcourseNames = new ArrayList<String>();
        List<String> actualCourseNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.COURSES );
        Log.message( "Actual Courses Name From UI : " + actualCourseNames );
        if ( SubjectName.equalsIgnoreCase( "reading" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "prescriptiveScheduling", "2" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        } else if ( SubjectName.equalsIgnoreCase( "math" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "prescriptiveScheduling", "1" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        }

        Log.message( "Courses Name From UI : " + actualCourseNames );

        int actualSize = actualCourseNames.size();
        int expectSize = expcourseNames.size();
        String actual = String.valueOf( actualSize );
        String expect = String.valueOf( expectSize );

        boolean validate = false;
        if ( actualSize == expectSize ) {
            for ( int i = 0; i < actualCourseNames.size(); i++ ) {
                validate = actualCourseNames.get( i ).contains( expcourseNames.get( i ) );
                if ( validate == false ) {
                    Log.softAssertThat( validate, "Course " + actualCourseNames + "Value Is Matching", "Course" + actualCourseNames + " Value Is Not Matching" );
                }
            }
        }
        Log.assertThat( actual.equalsIgnoreCase( expect ), "Passed : Courses Are Matching", "Failed : Courses Are Not Matching" );
        return this;
    }

    /**
     * @author raseem.mohamed Used to verify the Teachers in UI matches the
     *         Teaches fetched from RBS
     * 
     * @param driver
     * @param admin
     * @param orgIds
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingReport verifyTeachers( WebDriver driver, Admins admin, List<String> orgIds ) throws Exception {

        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        List<String> actualTeacherNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.TEACHERS );
        System.out.println( "Actual teacher Name" + actualTeacherNames );
        List<String> actualTeacherID = reportsFilterUtils.getAllTeacherID( reportsFilterUtils.TEACHERS );
        System.out.println( actualTeacherID );
        List<String> expTeacherID = reportsFilterUtils.getTeacherId( driver, admin, orgIds );
        reportsFilterUtils.setValuesForDropdown( reportsFilterUtils.TEACHERS, actualTeacherNames.subList( 1, 3 ) );
        Log.softAssertThat( expTeacherID.containsAll( actualTeacherID ), "Teachers are matching", "Teachers are not matching" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Groups in UI matches the Group
     *         fetched from RBS
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingReport verifyGroup( WebDriver driver ) throws Exception {

        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        List<String> actualTeacherNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.TEACHERS );
        reportsFilterUtils.setValuesForDropdown( reportsFilterUtils.TEACHERS, actualTeacherNames.subList( 1, 3 ) );
        expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getGroupIds() );
        List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getGroupNames();
        Collections.sort( expgroupNames );
        Collections.sort( allValuesFromGroupsDropdown );

        Log.softAssertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );

        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Grades
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public PerspectiveSchedulingReport verifyGrades( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> allValuesFromGradesDropdown = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.GRADES );
        Log.assertThat( allValuesFromGradesDropdown.containsAll( Constants.Students.ALL_GRADES ), "The Grade Values is matching", "The Grade Values is matching" );

        reportsFilterUtils.clickSelectAll( reportsFilterUtils.GRADES );
        Log.testCaseInfo( "Verify if the Grade All is selected when ticked All option" );
        Log.softAssertThat( reportsFilterUtils.isSelectAllChecked( reportsFilterUtils.GRADES ), "The Select All option is Checked", "The Select All option is not Checked" );
        reportsFilterUtils.clickGradesDropdown();
        return this;
    }

}
