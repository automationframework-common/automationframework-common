package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.DemographicFilters;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CPAdminDemographicsTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }


    @Test ( description = "Verify the CP Report generation with 'Select All' option in Student Demographic", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance", "Smoke" }, priority = 1 )
    public void tcCumulativePerformance001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance001: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            SMUtils.waitForSpinnertoDisapper( driver, 15 );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.expandStudentDemographics();

            SMUtils.waitForSpinnertoDisapper( driver , 10);
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            List<String>  disbailityValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
            List<String>  englishValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
            List<String>  migrantValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
            List<String>  raceValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
            List<String>  ethnicityValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
            List<String>  socioValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );
            List<String>  specialServicesValues = Arrays.asList( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );

            Log.assertThat( disbailityValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( englishValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( migrantValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( raceValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( ethnicityValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( socioValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( specialServicesValues.get( 0 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Test Pass!", "Test Failed!!" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    // Check selecting "Single" option and Run Report in Demographics

    @Test ( description = "Verify the CP Report generation with 'Only One' option Selected in Student Demographic", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance002: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            SMUtils.waitForSpinnertoDisapper( driver, 15 );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.expandStudentDemographics();

            SMUtils.waitForSpinnertoDisapper( driver , 10);
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 0 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 1 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 1 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 0 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( DemographicFilters.ETHNICITY.get( 0 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 1 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 1 ) ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            List<String>  disbailityValues = Arrays.asList( ReportsUIConstants.SELECTED_DISABLITY_OPTION );
            List<String>  englishValues = Arrays.asList( ReportsUIConstants.SELECTED_ENGLISH_PROFICIENCY_OPTION );
            List<String>  migrantValues = Arrays.asList( ReportsUIConstants.SELECTED_MIGRANT_STATUS_OPTION );
            List<String>  raceValues = Arrays.asList( ReportsUIConstants.SELECTED_RACE_OPTION );
            List<String>  ethnicityValues = Arrays.asList( ReportsUIConstants.SELECTED_ETHNICITY_OPTION );
            List<String>  socioValues = Arrays.asList(ReportsUIConstants.SELECTED_SOCIOECONOMIC_STATUS );
            List<String>  specialServicesValues = Arrays.asList( ReportsUIConstants.SELECTED_SPECIAL_SERVICES );

            Log.assertThat( disbailityValues.get( 0 ).equalsIgnoreCase( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( englishValues.get( 0 ).equalsIgnoreCase( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( migrantValues.get( 0 ).equalsIgnoreCase( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( raceValues.get( 0 ).equalsIgnoreCase( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( ethnicityValues.get( 0 ).equalsIgnoreCase( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( socioValues.get( 0 ).equalsIgnoreCase( cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( specialServicesValues.get( 0 ).equalsIgnoreCase(  cumulativePerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) ), "Test Pass!", "Test Failed!!" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CP Report generation with 'Multiple Checkbox' option in Student Demographic", groups = { "SMK-57917", "AdminDashboard", "Reports", "Cumulative Performance" }, priority = 1 )
    public void tcCumulativePerformance003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance003: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            SMUtils.waitForSpinnertoDisapper( driver, 15 );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = cumulativePerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cumulativePerformancePage.reportFilterComponent.expandOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.expandStudentDemographics();

            SMUtils.waitForSpinnertoDisapper( driver , 10);
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 1 ),  DemographicFilters.DISABILITY_STATUS.get( 2 ) ) );
            List<String> disbailityValuesAfter = cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) ;
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown(  ReportsUIConstants.DISABILITY_STATUS  );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 1 ),  DemographicFilters.MIGRANT_STATUS.get( 2 ) ) );
            List<String> migrantValuesAfter = cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) ;
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( DemographicFilters.RACE.get( 1 ),  DemographicFilters.RACE.get( 2 ) ) );
            List<String> raceValuesAfter = cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ); 
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( DemographicFilters.ETHNICITY.get( 1 ),  DemographicFilters.ETHNICITY.get( 2 ) ) );
            List<String> ethnicityValuesAfter =cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) ;
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 1 ),  DemographicFilters.SOCIOECONOMIC_STATUS.get( 2 ) ) );
            List<String> socioValuesAfter =cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) ;
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            SMUtils.waitForSpinnertoDisapper( driver );

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 1 ),  DemographicFilters.SPECIAL_SERVICES.get( 2 ) ) );
            List<String> specialServicesValuesAfter =cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) ;
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 1 ),  DemographicFilters.ENGLISH_LANGUAGE.get( 2 ) ) );
            List<String> englishValuesAfter = cumulativePerformancePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY )  ;
            cumulativePerformancePage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            SMUtils.waitForSpinnertoDisapper( driver );

            List<String>  disbailityValues = Arrays.asList( DemographicFilters.DISABILITY_STATUS.get( 1 ),  DemographicFilters.DISABILITY_STATUS.get( 2 ) );
            List<String>  englishValues = Arrays.asList( DemographicFilters.ENGLISH_LANGUAGE.get( 1 ),  DemographicFilters.ENGLISH_LANGUAGE.get( 2 ) );
            List<String>  migrantValues = Arrays.asList( DemographicFilters.MIGRANT_STATUS.get( 1 ),  DemographicFilters.MIGRANT_STATUS.get( 2 ) );
            List<String>  raceValues = Arrays.asList( DemographicFilters.RACE.get( 1 ),  DemographicFilters.RACE.get( 2 ) );
            List<String>  ethnicityValues = Arrays.asList( DemographicFilters.ETHNICITY.get( 1 ),  DemographicFilters.ETHNICITY.get( 2 ) );
            List<String>  socioValues = Arrays.asList( DemographicFilters.SOCIOECONOMIC_STATUS.get( 1 ),  DemographicFilters.SOCIOECONOMIC_STATUS.get( 2 ) );
            List<String>  specialServicesValues = Arrays.asList( DemographicFilters.SPECIAL_SERVICES.get( 1 ),  DemographicFilters.SPECIAL_SERVICES.get( 2 ) );

            Log.message( "disbailityValues: " + disbailityValues + " disbailityValuesAfter: " + disbailityValuesAfter );
            Log.message( "englishValues: " + englishValues + " englishValuesAfter: " + englishValuesAfter );
            Log.message( "migrantValues: " + migrantValues + " migrantValuesAfter: " + migrantValuesAfter );
            Log.message( "raceValues: " + raceValues + " raceValuesAfter: " + raceValuesAfter );
            Log.message( "ethnicityValues: " + ethnicityValues + " ethnicityValuesAfter: " + ethnicityValuesAfter );
            Log.message( "socioValues: " + socioValues + " socioValuesAfter: " + socioValuesAfter );
            Log.message( "specialServicesValues: " + specialServicesValues + " specialServicesValuesAfter: " + specialServicesValuesAfter );

            Log.assertThat( SMUtils.compareTwoList( disbailityValues, disbailityValuesAfter ), "Test Pass!", "Test Failed!!" );
            //            Log.assertThat( SMUtils.compareTwoList( englishValues, englishValuesAfter ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( SMUtils.compareTwoList( migrantValues, migrantValuesAfter ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( SMUtils.compareTwoList( raceValues, raceValuesAfter ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( SMUtils.compareTwoList( ethnicityValues, ethnicityValuesAfter ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( SMUtils.compareTwoList( socioValues, socioValuesAfter ), "Test Pass!", "Test Failed!!" );
            Log.assertThat( SMUtils.compareTwoList( specialServicesValues, specialServicesValuesAfter ), "Test Pass!", "Test Failed!!" );

            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            Log.assertThat( outputPage.getReportPageTitle().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE ), "Cumulative Performance Report data displayed", "Cumulative Performance Report data not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
