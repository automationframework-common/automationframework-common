package com.savvas.sm.reports.api.tests;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;

public class AdminLSRReportData {

    SMAPIProcessor smAPIprocessor;
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String districtAdminDetails;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String districtId;
    public static String teacherId;
    public static String districtUserName;
    public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgList;
    private Response response;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String studentDetails;
    String studentUsername;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String subdistrictWithoutOrgUserID;
    String subdistrictWithoutOrgUsername;
    String subDistrictwithoutOrgId;
    String subDistrictOrgID;
    String singleSchoolAdminUserID;
    String singleSchoolAdminUsername;
    String singleSchoolAdminOrgId;
    String multiSchoolAdminUserID;
    String multiSchoolAdminUsername;
    String multiSchoolAdminOrgId;
    String payload;
    String userName;
    String password;
    String adminToken;
    String schoolID;
    String distID;
    String userID;
    Map<String,String> headers = new HashMap<>();
    RBSUtils rbs = new RBSUtils();


    @Test (priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin LSR Graphql", "SMK-57821", "P1", "API","SmokeTest" })
    public void getAdminLSROutput_positive(String tcId, String description, String scenario, String statusCode) throws Exception{
        Log.testCaseInfo( tcId + ":-" + description );
        payload = adminLSRConstants.REQ_PAYLOAD;

        switch (scenario) {

            //Math subject validation
            case "DISTRICT_ADMIN":
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                payload = String.format( payload, schoolID, "Math", userID , distID );
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken); 
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput( userName, password, schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break; 


            case "SUBDISTRICT_ADMIN":
                userName = "savvas_subdistrict_admin";
                password = "testing123$";
                schoolID = "8a7200af7f2c9d1b017f45c3000e04f9";
                userID = "ffffffff62c3bbf926ed69003190b7ba";
                distID = "8a72012881b66e5e0181cc924d1d0042";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("savvas_subdistrict_admin", "testing123$", schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break;

            case "SCHOOL_ADMIN":
                userName = "warriors_customer";
                password = "password1";
                schoolID = "8a7200af7f2c9d1b017f45c3000e04f9";
                userID = "ffffffff621e2934a7f5d30030674a30";
                distID = "8a7200af7f2c9d1b017f45c3000e04f9";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("warriors_customer", "password1", schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break;

            case "ZERO_STATE": 
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a7209e882eb26d60182f78f04e2005a";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "").replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break;

            case "FILTER_BY_IP_NOT_CLEARED": 
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "").replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"4646\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break;


            case "FILTER_BY_TEACHER_GROUP_GRADE_AND_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "\\\"ffffffff62ff731454321c00335308c9\\\"" ).replace( adminLSRConstants.GRADE_ID_VALUE, "\\\"06\\\"" ).replace( adminLSRConstants.GROUP_ID_VALUE, "\\\"a69da5c60e5b4525a2f73f636dc5ff74\\\"").replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79375\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break;

            case "FILTER_BY_TEACHER_GRADE_AND_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "\\\"ffffffff62ff731454321c00335308c9\\\"" ).replace( adminLSRConstants.GRADE_ID_VALUE, "\\\"06\\\"" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79375\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break;    

            case "FILTER_BY_TEACHER_GROUP_AND_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "\\\"ffffffff62ff731454321c00335308c9\\\"" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "\\\"a69da5c60e5b4525a2f73f636dc5ff74\\\"" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79375\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break; 

            case "FILTER_BY_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79375\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break; 

            case "FILTER_BY_MULTIPLE_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Math", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"7582\\\"" + "\\\"79175\\\""  ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break; 

                //Reading Subject validation    
            case "FILTER_BY_TEACHER_AND_READING_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "\\\"ffffffff62ff731454321c00335308c9\\\"" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79174\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                Log.message( "My payload is" +payload );
                break; 

            case "FILTER_BY_GRADE_AND_READING_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "\\\"KG\\\"" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79174\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                break; 

            case "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID" :
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "\\\"a69da5c60e5b4525a2f73f636dc5ff74\\\"" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79174\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                break; 

            case "FILTER_BY_CUSTOM_SETTINGS_COURSE":
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79375\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                break; 

            case "FILTER_BY_CUSTOM_STANDARDS_COURSE":
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"7577\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                break; 

            case "FILTER_BY_CUSTOM_SKILLS_COURSE":
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"79175\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                break; 

            case "FILTER_BY_FOCUS COURSE":
                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = String.format( payload, schoolID, "Reading", userID, distID );
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "\\\"a69da5c60e5b4525a2f73f636dc5ff74\\\"" ).replace( adminLSRConstants.ASSIGNMENT_ID, "\\\"4646\\\"" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput("districtadmin_rvc", "password1", schoolID, userID, distID);
                break; 
        }
        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if(scenario.equalsIgnoreCase( "FILTER_BY_TEACHER_AND_READING_ASSIGNMENT_ID" )|| scenario.equalsIgnoreCase( "FILTER_BY_GRADE_AND_READING_ASSIGNMENT_ID" )||scenario.equalsIgnoreCase( "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID" )){            
            // Verifying schema in the Response body
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "LSR_Admin_Schema_Reading", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }
        else if (scenario.equals( "ZERO_STATE" )){
            Log.assertThat( response.getBody().asString().contains( "Report details not found" ), "Message displayed as expected", "Message not displayed as expected" );
        }
        else{           
            // Verifying schema in the Response body
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "LSR_Admin_Schema_Math", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }

        Log.testCaseResult();

    }


    @DataProvider(name = "PositiveScenarios")
    public Object[][] testScenario() {

        Object[][] inputData = {
                { "tc_LSRBFF001", "Verify the 200 status code and valid reponse for the district admin credential.",
                    "DISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF002", "Verify the 200 status code and valid reponse for the school admin credential.",
                        "SUBDISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF003", "Verify the 200 status code and valid reponse for the subdistrict admin credential.",
                            "SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF004", "Verify the 200 Status code and zero state response, if the students are not started the selected assignments",
                                "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF005", "Verify the 200 Status code and zero state response, if the students are not cleared the IP for Default courses",
                                    "FILTER_BY_IP_NOT_CLEARED", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF006", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  any one TeacherId, any one GroupId, any one Grade, Math subject and any one assignmentId ",
                                        "FILTER_BY_TEACHER_GROUP_GRADE_AND_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF007", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  any one TeacherId, Empty array for GroupId , any one Grade, Math subject and any one assignmentId ",
                                            "FILTER_BY_TEACHER_GRADE_AND_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF008", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  any one TeacherId, any one GroupId , empty array for Grade, Math subject and any one assignmentId ",
                                                "FILTER_BY_TEACHER_GROUP_AND_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF009", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  empty array for TeacherId, any one GroupId, any one Grade, Math subject and any one assignmentId ",
                                                    "FILTER_BY_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF010", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  empty array for TeacherId, empty array for  GroupId, empty array for  Grade, Math subject and any one assignmentId ",
                                                        "FILTER_BY_MULTIPLE_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF011", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  empty array for TeacherId, empty array for  GroupId, empty array for  Grade, Math subject and multiple assignmentIds ",
                                                            "FILTER_BY_TEACHER_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF012", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  additional grouping  as  1 (Teacher), Reading subject and any one reading assignmentId .",
                                                                "FILTER_BY_GRADE_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF013", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  additional grouping  as  3 (Group) , Reading subject and any one reading assignmentId .",
                                                                    "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF014", "Verify the 200 Status code and  the output response , while pass the Custom by Settings assignment Ids in the query",
                                                                        "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF015", "Verify the 200 Status code and  the output response , while pass the Custom by skills assignment Ids  in the query",
                                                                            "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF016", "Verify the 200 Status code and  the output response , while pass the Custom by standard assignment Ids  in the query",
                                                                                "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF017", "Verify the 200 Status code and  the output response , while pass the Focus course assignment Ids  in the query",
                                                                                    "FILTER_BY_GROUP_AND_READING_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_OK },
        };
        return inputData;
    }

    @Test (priority = 2, dataProvider = "NegativeScenarios", groups = { "Admin LSR Graphql", "SMK-57821", "P1", "API" })
    public void getAdminLSROutput_Negative(String tcId, String description, String scenario, String statusCode) throws Exception{
        Log.testCaseInfo( tcId + ":-" + description );
        payload = adminLSRConstants.REQ_PAYLOAD;

        switch (scenario) {

            case "INVALID_ACCESS_TOKEN":

                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                payload = String.format( payload, schoolID, "Math", userID , distID );
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer 123$"); 
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput( userName, password, schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break; 

            case "INVALID_ORG_ID":

                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "123$";
                userID = "ffffffff6221b22970a3dc00317b4595";
                payload = String.format( payload, schoolID, "Math", userID , distID );
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken);
                headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, "123$");
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput( userName, password, schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break; 

            case "INVALID_USER_ID":

                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "12345$";
                payload = String.format( payload, schoolID, "Math", userID , distID );
                adminToken = rbs.getAccessToken( userName, password );
                headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, userID);
                headers.put( "Authorization", "Bearer "+adminToken);
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput( userName, password, schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break; 

            case "EMPTY_ORG_ID":

                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "";
                userID = "ffffffff6221b22970a3dc00317b4595";
                payload = String.format( payload, schoolID, "Math", userID , distID );
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer "+adminToken); 
                headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, distID);
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput( userName, password, schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break; 

            case "INVALID_SUBJECT_TYPE":

                userName = "districtadmin_rvc";
                password = "password1";
                schoolID = "8a72019a7f90ca06017fb5b542c41014";
                distID = "8a72071d7e51ae88017e7aef435101c6";
                userID = "ffffffff6221b22970a3dc00317b4595";
                payload = String.format( payload, schoolID, "123", userID , distID );
                adminToken = rbs.getAccessToken( userName, password );
                headers.put( "Authorization", "Bearer 123$"); 
                payload = payload.replace( adminLSRConstants.TEACHER_ID_VALUE, "" ).replace( adminLSRConstants.GRADE_ID_VALUE, "" ).replace( adminLSRConstants.GROUP_ID_VALUE, "" ).replace( adminLSRConstants.ASSIGNMENT_ID, "" ).replace( adminLSRConstants.DISABILITY_STATUS, "" ).replace( adminLSRConstants.ENGLISH_PROFICIENCY, "" ).replace( adminLSRConstants.GENDER, "" ).replace( adminLSRConstants.MIGRANT_STATUS, "" ).replace( adminLSRConstants.RACE, "" ).replace( adminLSRConstants.Ethnicity, "" ).replace( adminLSRConstants.SOCIO_STATUS, "" ).replace( adminLSRConstants.SPECIAL_SERVICES, "" );
                Log.message( "My payload is" +payload );
                response = getLSROutput( userName, password, schoolID, userID, distID);
                Log.message(response.getBody().asString());
                break; 

        }

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if(scenario.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" )){

            // Verifying message in the Response body
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }
        else if (scenario.equalsIgnoreCase( "INVALID_ORG_ID" )){

            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }

        else if (scenario.equalsIgnoreCase( "INVALID_USER_ID" )){

            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }

        else if (scenario.equalsIgnoreCase( "EMPTY_ORG_ID" )){

            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }

        else if (scenario.equalsIgnoreCase( "INVALID_SUBJECT_TYPE" )){

            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }

        Log.testCaseResult();

    }

    @DataProvider(name = "NegativeScenarios")
    public Object[][] testNegativeScenario() {

        Object[][] inputData = {
                { "tc_LSRBFF018", "Verify 401: UnAuthorized message in response when invalid Bearer token is given ",
                    "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF019", "Verify 403 status code and response when invalid organizationId is given in the query ",
                        "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF020", "Verify  401: UnAuthorized  and response when invalid userId is given in the query ",
                            "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF021", "Verify the message in the response when organizationId passed as empty array. ",
                                "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSRBFF022", "Verify the message in the response when invalid subject type passed in the query.",
                                    "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_OK },
        };
        return inputData;
    }

    /**
     * To get the LSR output data
     * @param username
     * @param password
     * @param schoolID
     * @param userID
     * @param distID
     * @return
     * @throws Exception
     */
    public Response getLSROutput(String username, String password, String schoolID, String userID, String distID ) throws Exception {

        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, userID);
        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, distID);
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String endPoint = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";
        Response response = RestAssuredAPIUtil.POSTGraphQl(endPoint,headers,payload,"");
        Log.message( response.getBody().asString() );
        Log.message("Response" + response.getBody().asString());
        return response;
    }
}
