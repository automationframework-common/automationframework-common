package com.savvas.sm.reports.ui.pages;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.learningservices.utils.ShadowDOMUtils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.smoke.admin.pages.ReportsBrowserActions;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.IFindBy;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PrescriptiveSchedulingPage extends LoadableComponent<PrescriptiveSchedulingPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    @FindBy ( css = "h1.report-heading" )
    WebElement pageTitle;

    @FindBy ( css = "p.description" )
    WebElement description;

    @FindBy ( css = "cel-date-input[value='reportService.reportForm.value.targetDate']" )
    WebElement targetDateRoot;

    @FindBy ( id = "input.number-input" )
    WebElement grade;

    @FindBy ( id = "gradek" )

    WebElement gradek;

    @FindBy ( id = "grade1" )
    WebElement grade1;

    @FindBy ( id = "grade2" )
    WebElement grade2;

    @FindBy ( id = "grade3" )
    WebElement grade3;

    @FindBy ( id = "grade4" )
    WebElement grade4;

    @FindBy ( id = "grade5" )
    WebElement grade5;

    @FindBy ( id = "grade6" )
    WebElement grade6;

    @FindBy ( id = "grade7" )
    WebElement grade7;

    @FindBy ( id = "grade8" )
    WebElement grade8;

    @FindBy ( css = "cel-side-navigation[class='side-nav-bar hydrated']" )
    WebElement sideNavigationRoot;

    @FindBy ( css = "p.col.section-main-title.mt-3" )
    WebElement setTargetLevel;

    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportRoot;

    @FindBy ( css = "save-report-options cel-modal" )
    WebElement saveReportOption;

    @FindBy ( css = "cel-button.ml-auto" )
    WebElement reSet;
    
    @FindBy (css = "h3.assignment-name.ml-3")
    WebElement assignmentOutputName;
    
    @FindBy (css = ".info > dd:nth-of-type(1)")
    WebElement orgNameOutput;

    @FindBy (css = "[alt='Savvas']")
    WebElement footer;
    
    @FindBy (css = "p.header.mt-1")
    WebElement noDataToDisplay;
    

    @FindBy (css = "table#table>thead>tr>th")
    List<WebElement> outputTableHeadersRead;

    @FindBy ( css = "div .col-3 .list-head" )
    List<WebElement> headerLegend;

    @FindBy ( css = "dl.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;

    @FindBy ( css = "[alt='successmaker']")
    WebElement smLogo;

    @FindBy ( css = "span.reports.text-lowercase")
    WebElement reportViewer;
    
    @FindBy (css="input.pagination-text-field")
    WebElement pageTxtBox;

//@IFindBy ( how = How.CSS, using = "cel-tab-panel.tab-panel", AI = false )
//    private WebElement togglebutton;

@FindBy ( css = "cel-tab-panel.tab-panel" )
WebElement togglebutton;
    
@FindBy ( css = "div dd:nth-of-type(3)" )
WebElement runReportGradeValue;


    @FindBy ( css = "h2[class='header']" )
    WebElement fldReportHeader;

    @FindBy ( css = ".header.mt-1.mb-1" )
    WebElement zeroState;

    //Child Elements
    private String childNav1 = "nav";
    private String childSubNavigationMenu = "cel-side-item";
    private String childSubNavigationButton = "button";
    private String child = "cel-button";
    public String studentNameCSS = "#table > tbody > tr  > td:nth-child(1) > div";
    private String button = "button";

    @FindBy ( id = "grade9" )
    WebElement grade9;

    //Saved Reports

    @FindBy ( css = "div.spinner-container" )
    WebElement Spinner;
    private int counter = 0;
    public static String TEACHERS = "#teachers";
    public static String LABEL = "label";
    public static String SUBJECT = "#subject > div > cel-single-select";
    public static String ORGANIZATIONS = "#organization > div > cel-single-select";
    public static List<String> SINGLE_SELECT_DROPDOWNS = new ArrayList<String>( Arrays.asList( ORGANIZATIONS, SUBJECT ) );
    public static String DROPDOWN_GRADNPARENT = "%s > cel-multi-select";
    public static String DROPDOWN_LIST_Root1 = "#dropdown > cel-multi-checkbox.multi-checkbox.hydrated";
    public static String DROPDOWN_LIST_SINGLE_SELECT_Root1 = "#dropdown > cel-single-select";
    public static String DROPDOWN_DATA_ROOT = "div > div.bottom-container > div > cel-checkbox-item";
    public static String DROPDOWN_GRAND_CHILD = "label > span";
    public static String DROPDOWN_LIST_Root2 = "div > div.bottom-container div";
    public static String DROPDOWN_PARENT1 = "div > button > cel-icon";
    public static String DIV = "div";
    public static String checkMarkCCSS = "checkmark-icon cel-color cel-color-disabled icon-small hydrated";
    public static String SELECT_ALL_ROOT2 = "div > div.header-container.item-container.border-bottom > cel-checkbox-item";
    public static String SELECT_ALL_ROOT3 = "label > input[type=checkbox]";
    public String[] targetDateElement = { "cel-date-input", "document.querySelector('cel-date-input').shadowRoot.querySelector('#celDateInput');" };
    public List<String> listPSRExpectedColumnList = new ArrayList<String>( Arrays.asList( "Student", "Performance Data", "Current Rate", "Current Forecast", "Prescription", "", "Current Course Level", "IP Level", "Time Since IP", "Skills Percent Mastered",
            "Session Length Setting", "Average Min/Day", "Current Learning Rate", "Time", "Level", "Add'l Sessions to Target", "Add'l Time to Target", "Add'l Min/Day to Target" ) );

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public PrescriptiveSchedulingPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, description );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, description, 30 ) ) {
            Log.message( "Area For Growth Page loaded successfully." );
        } else {
            Log.fail( "Area For Growth Page not loaded successfully." );
        }
    }

    public void selectTargetDate( WebDriver driver, int futureDateCount ) throws InterruptedException {
        SMUtils.nap( 3 );
        SMUtils.waitForElement( driver, targetDateRoot );
        WebElement inpDate = ShadowDOMUtils.retryAndGetWebElement( driver, targetDateElement[0], targetDateElement[1] );
        SMUtils.scrollDownIntoViewElement( driver, inpDate );
        Calendar calendar = Calendar.getInstance();
        calendar.add( Calendar.DATE, futureDateCount );
        Date futureDate = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy" );
        String formattedDate = sdf.format( futureDate );
        inpDate.clear();
        inpDate.sendKeys( formattedDate );
        inpDate.click();
        Log.message( "Date Selected" );
    }

    public boolean selectTargetDateAsCurrentDate() {
        boolean flag = false;
        try {
            SMUtils.nap( 10 );
            SMUtils.waitForElement( driver, targetDateRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, targetDateRoot, "#cel-date-input-1" ) );
            SMUtils.waitForElement( driver, targetDateRoot );
            WebElement cal = SMUtils.getWebElement( driver, targetDateRoot, ".cel-calendar-component.hydrated" );
            SMUtils.waitForElement( driver, cal );
            WebElement currentDate = SMUtils.getWebElement( driver, cal, ".day-circle.today" );
            SMUtils.nap( 10 );
            SMUtils.clickJS( driver, currentDate );

            //date.sendKeys( dateStr );
            Log.message( "Date Selected" );
            flag = true;
        } catch ( Exception e ) {
            Log.message( "User is unable to select the current date" );
        }
        return flag;
    }
    
    public boolean selectTargetDateAsCurrentDate2() {
        boolean flag = false;
        try {

            SMUtils.nap( 10 );
            SMUtils.waitForElement( driver, targetDateRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, targetDateRoot, "cel-icon-button.calendar-button" ) );
            SMUtils.waitForElement( driver, targetDateRoot );
            WebElement calparent = SMUtils.getWebElement( driver, targetDateRoot, "cel-calendar.cel-calendar-component.hydrated" );
            SMUtils.waitForElement( driver, calparent );
            WebElement currentDate = SMUtils.getWebElement( driver, calparent, "div table tbody tr td.today span" );
            SMUtils.nap( 10 );
            SMUtils.clickJS( driver, currentDate );

            //date.sendKeys( dateStr );
            Log.message( "Date Selected" );
            flag = true;
        } catch ( Exception e ) {
            Log.message( "User is unable to select the current date" );
        }
        return flag;
    }

    /**
     * This method is dynamically working to select the grade in Prescriptive
     * Scheduling page by giving the inputs of grade and value
     * 
     * @author raseem.mohamed
     * @param driver
     * @param gradeToSelect
     * @param value
     *
     */
    public void enterGrade( WebDriver driver, String gradeToEnter, String gradeValueToEnter ) {
        String gradeValue = null;
        try {
            float rawValue2 = Float.valueOf( gradeValueToEnter ).floatValue();
            gradeValue = String.valueOf( rawValue2 );
            WebElement grades = driver.findElement( By.xpath( "//input[@id='grade" + gradeToEnter + "']" ) );
            // Click on the respective grade and clear the field before entering the value
            Actions action = new Actions( driver );
            action.moveToElement( grades ).doubleClick().click().sendKeys( Keys.BACK_SPACE ).perform();
            action.moveToElement( grades ).click().sendKeys( gradeValue ).perform();
            Log.message( "'" + gradeValue + "'Value Entered Successfully On Grade " + gradeToEnter );
        } catch ( Exception e ) {
            Log.message( "Failed : '" + gradeValue + "'Value Not Entered Successfully On Grade " + gradeToEnter );
            e.printStackTrace();
        }

    }

    /**
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public void SelectGradeAndEnterTheGrade( WebDriver driver ) throws InterruptedException {
        enterGrade( driver, ReportsUIConstants.GRADE_K, "1" );
    }

    public boolean checkReportHeader() {
        try {
            WebElement heading = driver.findElement( By.cssSelector( "h1.report-heading" ) );
            return heading.getText().equals( "Prescriptive Scheduling Report" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Header not found" );
        }
        return false;
    }

    public boolean checkReportHeaderAfterRun() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( "h2.header" ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( "h2.header" ) ), 5000 );
            WebElement heading = driver.findElement( By.cssSelector( "h2.header" ) );
            return heading.getText().equals( "Prescriptive Scheduling" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Header not found" );
        }
        return false;
    }

    public boolean clickNextButton() {
        try {
            WebElement nextRoot = driver.findElement( By.cssSelector( "cel-button.next-btn" ) );
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, nextRoot, "button" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            WebElement heading = driver.findElement( By.cssSelector( "h2.header" ) );
            return heading.getText().equals( "Prescriptive Scheduling" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Header not found" );
        }
        return false;
    }

    /**
     * Get all the Saved Report Dropdown elements
     * 
     * @return
     */
    public List<WebElement> getAllSavedReportDropdownElements() {
        String query = "var root = document.querySelector('cel-single-select#savedReportOptions').shadowRoot.querySelectorAll('label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        Log.message( ddElements.toString() );
        return ddElements;
    }

    public void fillGrade( String gradeValue ) throws Exception {
        SMUtils.waitForElement( driver, gradek );
        gradek.sendKeys( gradeValue );
        grade1.sendKeys( gradeValue );
        grade2.sendKeys( gradeValue );
        grade3.sendKeys( gradeValue );
        grade4.sendKeys( gradeValue );
        grade5.sendKeys( gradeValue );
        grade6.sendKeys( gradeValue );
        grade7.sendKeys( gradeValue );
        grade8.sendKeys( gradeValue );

        //date.sendKeys( dateStr );
        Log.message( "Grade Filled" );
    }

    /**
     * Fill the target levels for grades
     * 
     * @return
     */
    public void fillTargetLevels( String gradeValue ) throws Exception {
        SMUtils.waitForElement( driver, gradek );
        gradek.sendKeys( Keys.BACK_SPACE );
        gradek.sendKeys( Keys.BACK_SPACE );
        gradek.sendKeys( Keys.BACK_SPACE );
        gradek.sendKeys( Keys.BACK_SPACE );
        gradek.sendKeys( gradeValue );
        grade1.sendKeys( Keys.BACK_SPACE );
        grade1.sendKeys( Keys.BACK_SPACE );
        grade1.sendKeys( Keys.BACK_SPACE );
        grade1.sendKeys( Keys.BACK_SPACE );
        grade1.sendKeys( gradeValue );
        grade2.sendKeys( Keys.BACK_SPACE );
        grade2.sendKeys( Keys.BACK_SPACE );
        grade2.sendKeys( Keys.BACK_SPACE );
        grade2.sendKeys( Keys.BACK_SPACE );
        grade2.sendKeys( gradeValue );
        grade3.sendKeys( Keys.BACK_SPACE );
        grade3.sendKeys( Keys.BACK_SPACE );
        grade3.sendKeys( Keys.BACK_SPACE );
        grade3.sendKeys( Keys.BACK_SPACE );
        grade3.sendKeys( gradeValue );
        grade4.sendKeys( Keys.BACK_SPACE );
        grade4.sendKeys( Keys.BACK_SPACE );
        grade4.sendKeys( Keys.BACK_SPACE );
        grade4.sendKeys( Keys.BACK_SPACE );
        grade4.sendKeys( gradeValue );
        grade5.sendKeys( Keys.BACK_SPACE );
        grade5.sendKeys( Keys.BACK_SPACE );
        grade5.sendKeys( Keys.BACK_SPACE );
        grade5.sendKeys( Keys.BACK_SPACE );
        grade5.sendKeys( gradeValue );
        grade6.sendKeys( Keys.BACK_SPACE );
        grade6.sendKeys( Keys.BACK_SPACE );
        grade6.sendKeys( Keys.BACK_SPACE );
        grade6.sendKeys( Keys.BACK_SPACE );
        grade6.sendKeys( gradeValue );
        grade7.sendKeys( Keys.BACK_SPACE );
        grade7.sendKeys( Keys.BACK_SPACE );
        grade7.sendKeys( Keys.BACK_SPACE );
        grade7.sendKeys( Keys.BACK_SPACE );
        grade7.sendKeys( gradeValue );
        grade8.sendKeys( Keys.BACK_SPACE );
        grade8.sendKeys( Keys.BACK_SPACE );
        grade8.sendKeys( Keys.BACK_SPACE );
        grade8.sendKeys( Keys.BACK_SPACE );
        grade8.sendKeys( gradeValue );
        grade9.click();

        Log.message( "Target Levels Updated" );
    }

    /**
     * Return true if the Dropdown is expanded
     * 
     * @param dropdown
     * @return
     */
    public boolean isDropdownExpanded( String dropdown ) {
        WebElement rootElement = null;
        WebElement lisRoot = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, LABEL );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            lisRoot = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
        }
        return lisRoot != null ? true : false;
    }

    /**
     * Expand Dropdown
     * 
     * @param dropdownName
     */
    public void expanDropdown( String dropdownName ) {
        if ( !isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
            SMUtils.nap( 2 ); // wait for dropdown load

            Log.message( "Dropdown expanded: " + dropdownName );
        } else {
            Log.message( dropdownName + " Dropdown already expanded" );
        }
    }

    /**
     * Return true if Organization Dropdown is expanded
     * 
     * @return
     */
    public boolean isOrganizaionDropdownExpanded() {
        return isDropdownExpanded( ORGANIZATIONS );
    }

    public void expandOrganizationDropdown() {
        if ( !isOrganizaionDropdownExpanded() ) {
            expanDropdown( ORGANIZATIONS );
        } else {
            Log.message( "Organization Dropdown is Expanded" );
        }
    }

    /**
     * Get all the Org Dropdown elements
     * 
     * @return
     */
    public List<WebElement> getAllOrganizationDropdownElements() {
        String query = "var root = document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelectorAll('label'); { return root ;}";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        List<WebElement> ddElements = (List<WebElement>) javascriptExecutor.executeScript( query );
        return ddElements;
    }

    /**
     * To get the Dropdown Elements
     * 
     * @param dropdown
     * @return
     */
    public List<WebElement> getAllDropdownElements( String dropdown ) {
        if ( !isDropdownExpanded( dropdown ) ) {
            expanDropdown( dropdown );
        }
        WebElement rootElement = null;
        if ( dropdown.equals( ORGANIZATIONS ) ) {
            return getAllOrganizationDropdownElements();
        } else if ( SINGLE_SELECT_DROPDOWNS.contains( dropdown ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdown ) );
            List<WebElement> parent = SMUtils.getWebElementsDirect( driver, rootElement, LABEL );
            return parent;
        } else {
            final List<WebElement> streamList = new ArrayList<WebElement>();
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            WebElement parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdown ) ) );
            parent = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1 );
            List<WebElement> dataParent = SMUtils.getWebElements( driver, parent, DROPDOWN_DATA_ROOT );
            dataParent.stream().forEach( ddElement -> {
                streamList.add( SMUtils.getWebElementDirect( driver, ddElement, DROPDOWN_GRAND_CHILD ) );
            } );
            return streamList;
        }
    }

    /**
     * Select the options in the Dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void selectOptionsFromDropdown( String dropdownName, List<String> options ) {
        List<WebElement> elements = getAllDropdownElements( dropdownName );
        if ( elements.size() > 0 ) {
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                WebElement option = elements.stream().filter( element -> options.contains( element.getText().trim() ) ).findFirst().orElse( null );
                SMUtils.scrollDownIntoViewElement( driver, option );
                String optionName = option.getText().trim();
                SMUtils.click( driver, option );
                Log.message( optionName + " is ticked" );
            } else {
                elements.stream().filter( element -> options.contains( element.getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollDownIntoViewElement( driver, element );
                    SMUtils.click( driver, element );
                    Log.message( element.getText().trim() + " is ticked" );
                } );
                ;
            }

        } else {
            Log.message( "Issue in Selecting values for " + dropdownName );
        }
    }

    /**
     * Wait for the spinner to Load and Wait for disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, Duration.ofSeconds( 60 ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }

    public static String selectAllCheckBoxColor = "#006be0";

    /**
     * Return true if the checkBox is selected
     * 
     * @param dropdownName
     * @return
     */
    public boolean verifySelectAllCheckBoxColor( String dropdownName ) {
        WebElement rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, SELECT_ALL_ROOT3 );
        String color = Color.fromString( element.getCssValue( "background-color" ) ).asHex();
        return ( color.equals( selectAllCheckBoxColor ) ) ? true : false;
    }

    /**
     * Close dropdown Element
     * 
     * @param dropdownName
     */
    public void closeDropdown( String dropdownName ) {
        if ( isDropdownExpanded( dropdownName ) ) {
            WebElement rootElement = null;
            if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
                rootElement = driver.findElement( By.cssSelector( dropdownName ) );
            } else {
                rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
            }
            WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_PARENT1, DIV );
            SMUtils.click( driver, element );
        } else {
            Log.message( dropdownName + " Dropdown already closed" );
        }
    }

    /**
     * Unselect All options in Dropdown
     * 
     * @param dropdownName
     */
    public void unSelectAll( String dropdownName ) {
        expanDropdown( dropdownName );
        WebElement rootElement = null;
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            rootElement = driver.findElement( By.cssSelector( dropdownName ) );
        } else {
            rootElement = driver.findElement( By.cssSelector( DROPDOWN_GRADNPARENT.format( DROPDOWN_GRADNPARENT, dropdownName ) ) );
        }
        WebElement element = SMUtils.getWebElementDirect( driver, rootElement, DROPDOWN_LIST_Root1, SELECT_ALL_ROOT2, "label" );
        if ( verifySelectAllCheckBoxColor( dropdownName ) ) {
            SMUtils.click( driver, element );
        } else {
            SMUtils.click( driver, element );
            SMUtils.click( driver, element );
        }
        Log.message( "Clicked Select ALL for " + dropdownName + "Dropdown" );
        closeDropdown( dropdownName );
    }

    /***
     * It will opend and the Tick the Values in the Dropdown With options and
     * close the dropdown
     * 
     * @param dropdownName
     * @param options
     */
    public void setValuesForDropdown( String dropdownName, List<String> options ) {
        expanDropdown( dropdownName );
        if ( SINGLE_SELECT_DROPDOWNS.contains( dropdownName ) ) {
            selectOptionsFromDropdown( dropdownName, options );
        } else {
            unSelectAll( dropdownName );
            selectOptionsFromDropdown( dropdownName, options );
            closeDropdown( dropdownName );
        }
        if ( dropdownName.equals( TEACHERS ) ) {
            waitForSpinnerToLoadAndDisppear();
        }
    }

    /**
     * This will click and Set the values in Organization Dropdown and close and
     * wait for sppinner to load
     * 
     * @param orgName
     */
    public void setOrganizationsValue( String orgName ) {
        expandOrganizationDropdown();
        setValuesForDropdown( ORGANIZATIONS, new ArrayList<String>( Arrays.asList( orgName ) ) );
        waitForSpinnerToLoadAndDisppear();

        if ( SMUtils.waitForLocator( driver, By.cssSelector( "reports-wrapper > div > img" ), 2 ) ) {
            counter++;
            SMUtils.sendF5Key( driver );
            waitForSpinnerToLoadAndDisppear();
            setOrganizationsValue( orgName );
        }
        counter = 0;
    }

    /**
     * To get the organization Details in the Dropdown From click dropdown and
     * get the details and close dropdown
     * 
     * @return
     */
    public HashMap<String, String> getOrganizationDetails() {
        Log.message( "Getting Organization Details..." );
        expandOrganizationDropdown();
        HashMap<String, String> details = new HashMap<String, String>();
        List<WebElement> allOrganizationDropdownElements = getAllOrganizationDropdownElements();
        allOrganizationDropdownElements.stream().forEach( elements -> {
            details.put( elements.getAttribute( "data-label" ), elements.getAttribute( "for" ) );
        } );
        closeDropdown( ORGANIZATIONS );
        Log.message( "Organization details fetched!" );
        return details;
    }

    /**
     * To verify the sub navigation is selected or not
     * 
     * @return
     *
     * @return
     */
    public boolean isPSRsubNavigationSelected() {
        boolean flag = false;
        Log.message( "Verifing PSR Sub navigation is selected" );
        List<WebElement> list = SMUtils.getWebElements( driver, sideNavigationRoot, childSubNavigationMenu );

        for ( WebElement e : list ) {
            WebElement reportElement = SMUtils.getWebElement( driver, e, childSubNavigationButton );
            if ( reportElement.getText().equals( "Prescriptive Scheduling" ) ) {
                if ( reportElement.getAttribute( "class" ).contains( "side-item side-item-active" ) ) {
                    flag = true;
                }
            }
        }

        return flag;

    }

    /**
     * To Verify the SET TARGET LEVEL PER GRADE is displayed
     * 
     * @return flag status
     */
    public boolean isSetTargetLevelPerGradeIsDisplayed() {
        boolean flag = false;
        SMUtils.waitForElement( driver, setTargetLevel );
        if ( SMUtils.getTextOfWebElement( setTargetLevel, driver ).contentEquals( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SET_TARGET_LEVEL_PER_GRADE ) ) {
            flag = true;
        }

        return flag;
    }

    /**
     * To validate the runReport button Enabled
     * 
     * @return
     */

    public boolean isRunReportEnabled() {
        boolean flag = false;
        SMUtils.waitForElement( driver, runReportRoot );
        if ( SMUtils.getWebElementDirect( driver, runReportRoot, childSubNavigationButton ).isEnabled() ) {
            flag = true;
        }
        Log.message( "Clicked Run Report Button is Enabled" );

        return flag;
    }

    /**
     * To validate the runReport button is disabled
     * 
     * @return
     */

    public boolean isRunReportDisabled() {
        boolean flag = true;
        SMUtils.waitForElement( driver, runReportRoot );
        if ( SMUtils.getWebElementDirect( driver, runReportRoot, childSubNavigationButton ).isEnabled() ) {
            flag = false;
        }
        Log.message( "Run Report Button is DisEnabled" );

        return flag;
    }

    public boolean isResetBtnDisabled() {
        boolean flag = true;
        SMUtils.waitForElement( driver, reSet );
        if ( SMUtils.getWebElementDirect( driver, reSet, childSubNavigationButton ).isEnabled() ) {
            flag = false;
        }
        Log.message( "Reset Button is DisEnabled" );

        return flag;
    }

    public boolean isSaveReportOptionDisabled() {
        boolean flag = true;
        SMUtils.waitForElement( driver, saveReportOption );
        if ( SMUtils.getWebElementDirect( driver, saveReportOption, child, childSubNavigationButton ).isEnabled() ) {
            flag = false;
        }
        Log.message( "Save Report Option Button is DisEnabled" );

        return flag;
    }

    @FindBy ( xpath = "//cel-button[@data-icon-type='right'] " )
    WebElement rightNextButton;

    @FindBy ( xpath = "//cel-button[@data-icon-type='left'] " )
    WebElement leftBackButton;

    @FindBy ( xpath = "//dt[contains(text(),'School Days to Target:')]/following::dd" )
    WebElement schoolDaysToTargetValue;

    @FindBy ( xpath = "//th[contains(text(),'Performance Data')]" )
    WebElement perfomanceDataHeader;

    public static String studentData = "//tbody//child::tr[%s]//td[%s]";
    public static String rowCountXpath = "//tbody//child::tr";

    String gradeTarget = "document.querySelector('#grade%s').value";
    private String calendarDatesQuery = "var root1 = document.querySelector('set-target-date-level cel-date-input').shadowRoot.querySelector('cel-date-popup').shadowRoot.querySelector('cel-calendar').shadowRoot.querySelectorAll('div.calendar-container > div cel-calendar-date:not(div.row.days)'); var vl =[]; root1.forEach ( ele => { if ( ele.getAttribute('data-day')!=null ) {vl.push(ele);}}); { return vl};";
    private static String gradeIncrementor = "#grade%s%sncrementor > cel-icon";
    private static String gradeDecrementor = "#grade%s%secrement%sr > cel-icon";
    public static List<String> GradeLevels = Arrays.asList( "k", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" );

    /**
     * click Next Button in in Output Page
     * 
     * @return
     */
    public boolean clickNextButtoninOuputPage() {
        WebElement button = SMUtils.getWebElementDirect( driver, rightNextButton, "button" );
        if ( button.getAttribute( "aria-disabled" ).equals( "false" ) ) {
            SMUtils.clickJS( driver, button );
            return true;
        } else {
            Log.message( "Last Page is reached" );
            return false;
        }
    }

    /**
     * Click Back Button in Output Page.
     * 
     * @return
     */
    public boolean clickBackButtoninOuputPage() {
        WebElement button = SMUtils.getWebElementDirect( driver, leftBackButton, "button" );
        if ( !button.getAttribute( "aria-disabled" ).equals( "false" ) ) {
            SMUtils.clickJS( driver, button );
            return true;
        } else {
            Log.message( "First Page Reached" );
            return false;
        }
    }

    /**
     * Set Target Level for the Grde
     * 
     * @param Grade
     * @param value
     */
    public void setTargetLevelForGrade( String Grade, double value ) {
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript( gradeTarget.format( gradeTarget, Grade ) + "='" + String.valueOf( new DecimalFormat( "#.00" ).format( value ) ) + "';" );
    }

    /**
     * Click Incrementor For Grade
     * 
     * @param GradelLevel
     */
    public void clickIncrementGrade( String GradelLevel ) {
        String formated;
        if ( GradelLevel.equalsIgnoreCase( "k" ) ) {
            formated = gradeIncrementor.format( gradeIncrementor, GradelLevel, "I" );
        } else {
            formated = gradeIncrementor.format( gradeIncrementor, GradelLevel, "i" );
        }

        WebElement parent = driver.findElement( By.cssSelector( formated ) );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, parent, "div" ) );
        Log.message( "Clikced Incrementor for Grade: " + GradelLevel );

    }

    /**
     * Click Decrement for Grade Level
     * 
     * @param GradelLevel
     */
    public void clickDecrementGrade( String GradelLevel ) {
        String formated;
        if ( GradelLevel.equalsIgnoreCase( "k" ) ) {
            formated = gradeIncrementor.format( gradeDecrementor, GradelLevel, "D", "e" );
        } else {
            formated = gradeIncrementor.format( gradeDecrementor, GradelLevel, "d", "o" );
        }

        WebElement parent = driver.findElement( By.cssSelector( formated ) );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, parent, "div" ) );
        Log.message( "Clikced Decrementor for Grade: " + GradelLevel );

    }

    @FindBy ( css = "cumulative-performance > cel-accordion-item" )
    WebElement optionalFilterRoot;

    /**
     * Click optional Filter in Report
     */
    public void clickOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }
    
    /**
     * navigate To PSAR Report
     * 
     */

    public void  navigateToPSAReport() {
        Log.message( "Clicking on the Prescriptive scheduling Aggregate element in sub-navigation" );
        SMUtils.getWebElementsDirect( driver, togglebutton, button ).stream().filter( element -> element.getText().trim().equalsIgnoreCase( ReportTypes.PRESCRIPTIVE_SCHEDULING_AGGREGATE ) ).forEach( element -> SMUtils.clickJS( driver, element ) );
//        return new PrescriptiveSchedulingPage( driver ).get();
        

    }

    public  String getGrade() {
        return runReportGradeValue.getText();
    }
    
    public void validatePSReportOutputColumns( WebDriver driver ) throws InterruptedException {

        ReportsBrowserActions.waitForSpinnerToBeInvisible( driver );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 45 ) );
        wait.until( ExpectedConditions.visibilityOf( driver.findElement( By.cssSelector( "report-grid" ) ) ) );
        List<WebElement> table = driver.findElements( By.cssSelector( "report-grid thead tr th" ) );
        List<String> columnsList = SMUtils.getAllTextFromWebElementList( table );
        String txtReportName = fldReportHeader.getText();
        Log.assertThat( columnsList.equals( listPSRExpectedColumnList ), txtReportName + " output columns are verified successfully", "Failed to verify " + txtReportName + " output coloumns" );

    }

    public boolean verifyZeroState( WebDriver driver ) {
        boolean status = false;
        if ( zeroState.getText().equalsIgnoreCase( "No data to display" ) ) {
            status = true;
        } else {
            status = false;
        }
        return status;
    }

    
    public String getAssignmentNameOutput(WebDriver driver) {
        return assignmentOutputName.getText();
    }
    
    public List<String> getAllAssignmentNamesFromOutput(WebDriver driver, int totalPageCount) {
        List<String> allAssignmentNames = new ArrayList<>();
        for ( int  i=0; i<totalPageCount; i++ ) {
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            outputPage.clickNextBtn();
            allAssignmentNames.add( getAssignmentNameOutput(driver));
        }
        return allAssignmentNames;
    }
    
    public List<String> getSampleAssignmentNamesFromOutput(WebDriver driver, int totalPageCount) {
        List<String> allAssignmentNames = new ArrayList<>();
        for ( int  i=0; i<totalPageCount; i=i+499 ) {
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            pageTxtBox.clear();
            pageTxtBox.sendKeys( ""+i);
            pageTxtBox.sendKeys( Keys.ENTER );
//            outputPage.clickNextBtn();
            allAssignmentNames.add( getAssignmentNameOutput(driver));
        }
        return allAssignmentNames;
    }
    
    public void EnterpgNo(WebDriver driver) {
        for ( int  i=0; i<1000; i=i+499 ) {
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            SMUtils.clickJS( driver, pageTxtBox );
            pageTxtBox.clear();
            pageTxtBox.sendKeys( i+" ");
            pageTxtBox.sendKeys( Keys.ENTER );
            Log.message(" page no :"+i );
    }
        }
    
    public String getOrgNameOutput(WebDriver driver) {
        return orgNameOutput.getText();
    }
    
    public boolean verifyFooterIsDispayed(WebDriver driver) {
        boolean  status = false;
        if ( footer.isDisplayed() ) {
            Log.message( "Footer is displayed!" );
            status = true;
        } else {
            status = false;
        }
        return status;
    }
    
    
    public boolean VerifyPSRZeroState(WebDriver driver) {
        boolean status = false;
        if ( noDataToDisplay.getText().equalsIgnoreCase( ReportsUIConstants.NO_DATA_TO_DISPLAY ) ) {
            status = true;
} else {
            status = false;
}
        return status;
}
    
    /**
     * To get the Output Table Headers and its field values
     * 
     * @return Output Table Header values
     */

    public  List<String> getOutputTableHeadersRead(WebDriver driver) throws InterruptedException  {
        SMUtils.waitForSpinnertoDisapper( driver );
        List<String> values = outputTableHeadersRead.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
        values.remove( 4 );
        Log.message( "Header values: " + values );
        return values;
    }

    /**
     * To verify the Output Table Headers and its field values
     * 
     * @return status
     */
    public  boolean verifyOutputTableHeadersRead(WebDriver driver) throws InterruptedException  {
        boolean status = false;
        SMUtils.waitForSpinnertoDisapper( driver );
        List<String> uiValues = getOutputTableHeadersRead( driver );
        List<String> expectedValues = ReportsUIConstants.PSR_OUTPUT_TABLE_HEADERS_READ;

        for ( String string : expectedValues ) {
            for ( String actual : uiValues ) {
                string.contains( actual );
                status = true;
            }

        }
        return status;
    }


    /**
     * To verify the SM logo and report Viewer text in output page
     * 
     * @return
     */
    public boolean verifySMLogoandViewer(WebDriver driver) {
        boolean status = false;
        if (  smLogo.isDisplayed() ) {
            reportViewer.getText().equals( ReportsUIConstants.REPORT_VIEWER );
            status = true;
        } else {
            status = false;
        }
       return status;
    }



    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabelsForReading() {
        Log.event( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if (SMUtils.getAllTextFromWebElementList( headerLegend ).containsAll( ReportsUIConstants.LS_LEGEND_HEADERS )) {
            IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS.get( itr ) ) );
            IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_VALUES.get( itr ) ) );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }


}
