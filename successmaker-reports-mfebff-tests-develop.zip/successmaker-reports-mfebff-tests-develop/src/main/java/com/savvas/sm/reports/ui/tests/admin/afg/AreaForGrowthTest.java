package com.savvas.sm.reports.ui.tests.admin.afg;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class AreaForGrowthTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String org;

    @BeforeTest ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Area for growth Page title and description", groups = { "Smoke", "SMK-55038", "AdminDashboard", "Reports", "Area for growth" }, priority = 1 )
    public void tcAreaForGrowth001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAreaForGrowth001: Verify area for growth Page title and description <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "TC:1 Verify the Area for growth menu is displayed in the sub-navigation of Reports Page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.AREAS_FOR_GROWTH ), "The Area for growth is displayed in Report MFE sub-navigation",
                    "The Area for growth is displayed in Report MFE sub-navigation" );

            dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            Log.assertThat( dashBoardPage.isAFGSubNavigationSelected(), "The area for growth in sub navigation is selected and it is verified", "The area for growth in sub navigation is not selected and it is verified" );

            SMUtils.logDescriptionTC( "TC:2 Verify the title of area for growth page is displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isReportTitleDisplayed(), "The area for growth title is displayed and it is verified", "The area for growth title is not displayed and it is verified" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE ), "The area for growth title text is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE,
                    "The Recent Session title text is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE );

            SMUtils.logDescriptionTC( "TC:3 Verify the help icon (?) is displayed along with the title of the Recent Session Page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isHelpIconDisplayed(), "The area for growth help icon is displayed and it is verified", "The area for growth help icon is not displayed and it is verified" );

            SMUtils.logDescriptionTC( "TC:4 Verify the page description is displayed below the title of the area for growth Page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isReportDescriptionDisplayed(), "The area for growth description is displayed and it is verified", "The area for growth description is not displayed and it is verified" );
            Log.message( dashBoardPage.reportFilterComponent.getReportDescription() );
            Log.assertThat( dashBoardPage.reportFilterComponent.getReportDescription().equals( ReportsUIConstants.AREA_FOR_GROWTH_PAGE_DESCRIPTION ),
                    "The area for growth description text is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_DESCRIPTION, "The area for growth description text is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_DESCRIPTION );

            SMUtils.logDescriptionTC( "TC 5:Verify Saved Report Option label is displayed and drop down in the area for growth Page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL ), "The area for growth Save Report Option label is displayed and it is verified",
                    "The area for growth Save Report Option label is not displayed and it is verified" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL ),
                    "The area for growth Save Report Option label text is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL,
                    "The area for growth Save Report Option label text is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL );

            Log.assertThat( dashBoardPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL ), "The area for growth Save Report Option drop down is displayed and it is verified",
                    "The area for growth Save Report Option drop down is not displayed and it is verified" );

            SMUtils.logDescriptionTC( "TC 7:Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL ), "The area for growth Save Report Option drop down arrow is displayed and it is verified",
                    "The area for growth  Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );

            SMUtils.logDescriptionTC( "TC8: Verify the Organizations label is displayed and drop down in the area for growth page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL ), "The Organization label is displayed", "The Organization label is not displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL ), "The Organization label is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL,
                    "The Organization label is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL );

            //new ReportFilterComponent( driver ).selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, org );
            dashBoardPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, org );

            SMUtils.logDescriptionTC( "TC9:Verify the Course Selection label is displayed in the area for growth report page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.RECENT_SESSION_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );

            SMUtils.logDescriptionTC( "TC10:Verify the Subject label is displayed and drop down in the area for growth page" );

            Log.assertThat( dashBoardPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );

            Log.assertThat( dashBoardPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );

            SMUtils.logDescriptionTC( "TC11:Verify the default text is displayed in the subject drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL ).equals( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_WATERMARK ),
                    "The Subject drop down default text is verified", "The Subject drop down default text is not verified" );

            SMUtils.logDescriptionTC( "TC12(1):Verify the Subject drop down is a single select drop down" );
            SMUtils.logDescriptionTC( "TC12(2):Verify the tick symbol is displayed when any of the subject drop down values are selecred" );

            //dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.collapseSingleSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL );
            Log.message( dashBoardPage.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL ).equals( ReportsUIConstants.MATH ), "The given value is selected in Subject drop down",
                    "The given value is not selected in Subject drop down" );

            SMUtils.logDescriptionTC( "TC13:Verify the Course(s) label is displayed and drop down in the Recent Sessions drop down" );

            dashBoardPage.reportFilterComponent.getDropdownLabels();
            new ReportFilterComponent( driver ).selectOptionsFromSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, org );
            dashBoardPage.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_SUBJECT_LABEL, ReportsUIConstants.MATH );

            Log.assertThat( dashBoardPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.AREA_FOR_GROWTH_COURSES_LABEL ), "The Courses label is displayed", "The Courses label is not displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.AREA_FOR_GROWTH_COURSES_LABEL ), "The Courses label is verifed and displayed as " + ReportsUIConstants.RECENT_SESSION_COURSE_SELECTION_LABEL,
                    "The Courses label is not verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Area for growth Page optional filters label and dropdown options", groups = { "Smoke", "SMK-55038", "AdminDashboard", "Reports", "Area for growth" }, priority = 1 )
    public void tcAreaForGrowth002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAreaForGrowth002: Verify area for growth Page optional filters label and dropdown options <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // optional filters
            SMUtils.logDescriptionTC( "TC14:Verify Optional Filters should display on area for growth Report page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );

            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilters(), "Optional filter is expanded", "Optional Filter is not expanded" );

            SMUtils.logDescriptionTC( "TC15:Verify 'SELECT STUDENTS BY' text under Optional Filters " );
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying",
                    "Select student by is not displaying. Expected: " + ReportsUIConstants.SELECT_STUDENT_BY + ".Actual:" + dashBoardPage.reportFilterComponent.getSelectStudentBy() );

            SMUtils.logDescriptionTC( "TC16:Verify Teacher Dropdown should display under Recent Session Report" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.TEACHER_LABEL ), "Teacher label is displaying", "Teacher label is not displaying" );

            new ReportFilterComponent( driver ).selectOptionsFromSelectDropdown( ReportsUIConstants.AREA_FOR_GROWTH_ORGANIZATIONS_LABEL, org );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Teacher dropdown",
                    "All is not displaying for Teacher dropdown" );

            SMUtils.logDescriptionTC( "TC17:Verify Grade Dropdown should display under Recent Session Report" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GRADE_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );

            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Grade dropdown",
                    "All is not displaying for Grade dropdown" );

            SMUtils.logDescriptionTC( "TC18:Verify Group Dropdown should display under Recent Session Report" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );

            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Log.assertThat( dashBoardPage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.GROUP_LABEL ), "Search Bar is displaying for Group", "Search Bar is not displaying for Group" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).contains( ReportsUIConstants.ALL ), "All displayed for Group dropdown",
                    "All is not displaying for Group dropdown" );

            SMUtils.logDescriptionTC( "TC19:Verify Additional Grouping Dropdown should display under Recent Session Report" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );

            Log.message( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ) + "" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );

            SMUtils.logDescriptionTC( "TC21:Verify Display Dropdown should display under Recent Session Report" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );

            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying", "Display option are not displaying" );

            SMUtils.logDescriptionTC( "TC22:Verify Mask Student Dispaly should be display ." );
            Log.assertThat( dashBoardPage.reportFilterComponent.getMaskStudentDisplayAndRemovePageBreaklbl().get( 0 ).equals( ReportsUIConstants.MASK_STUDENT_DISPLAY ), "Mask Student is displaying", "Mask Student is not displaying" );

            SMUtils.logDescriptionTC( "TC23:Verify Sort Dropdown should display under Recent Session Report" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.message( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.SORT_LABEL ) + "" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.SORT_LABEL ).containsAll( ReportsUIConstants.SORT ), "All the sorts filter option are displaying", "Sort filter option are not displaying" );

            SMUtils.logDescriptionTC( "TC24:Verify all option available for date at risk dropdown" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DATE_AT_RISK ), "Date at Risk header is displaying", "Date at Risk header is not displaying" );
            Log.message( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.DATE_AT_RISK ) + "" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownOptions( ReportsUIConstants.DATE_AT_RISK ).containsAll( ReportsUIConstants.DATE_AT_RISK_OPTIONS ), "All the date at risk filter option are displaying",
                    "date at risk filter option are not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Area for growth Page Student demographics optional label and dropdown options", groups = { "Smoke", "SMK-55038", "AdminDashboard", "Reports", "Area for growth" }, priority = 1 )
    public void tcAreaForGrowth003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAreaForGrowth003: Verify area for growth Page Student demographics optional label and dropdown options <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "TC25:Verify Student demographics Option label is displayed in the area for growth Page" );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilters(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getStudentDemographicsLabel().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly",
                    "Student demographics label not displayed properly. Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -" + dashBoardPage.reportFilterComponent.getStudentDemographicsLabel() );

            // Expand student demographics
            Log.assertThat( dashBoardPage.reportFilterComponent.expandStudentDemographics(), "User able to expande the studen demographics accordion", "Issue in expand the Student demographics accordion!" );

            SMUtils.logDescriptionTC( "TC26:Verify the Disability status option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly", "Issue in display th Disability status dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the Disability status dropdown and check dropdown option are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Disability status dropdown" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( ReportsUIConstants.AFG_DISABILITY_STATUS_OPTIONS ),
                    "ALL options are displayed properly in disability status dropdown", "Issue in displaying the options in disability status dropdown! Expected - " + ReportsUIConstants.AFG_DISABILITY_STATUS_OPTIONS + " Actual - "
                            + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );

            SMUtils.logDescriptionTC( "TC26:Verify Race option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display the race dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the Race dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Race drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( ReportsUIConstants.AFG_RACE_OPTIONS ), "ALL options are displayed properly in race dropdown",
                    "Issue in displaying the options in race dropdown! Expected - " + ReportsUIConstants.AFG_RACE_OPTIONS + " Actual - " + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ) );

            SMUtils.logDescriptionTC( "TC27:Verify SocioEconomic Status option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly",
                    "Issue in display the SocioEconomic Status dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the SocioEconomic Status dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Socioeconomic Status drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( ReportsUIConstants.AFG_SOCIOECONOMIC_STATUS_OPTIONS ),
                    "ALL options are displayed properly in SocioEconomic Status dropdown", "Issue in displaying the options in SocioEconomic Status dropdown! Expected - " + ReportsUIConstants.AFG_SOCIOECONOMIC_STATUS_OPTIONS + " Actual - "
                            + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );

            SMUtils.logDescriptionTC( "TC28:Verify English langauge proficiency Status option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English langauge proficiency Status  dropdown label is displayed properly",
                    "Issue in display the English langauge proficiency Status  dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the English langauge proficiency dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in English langauge proficiency drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( ReportsUIConstants.AFG_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS ),
                    "ALL options are displayed properly in English langauge proficiency Status dropdown", "Issue in displaying the options in English langauge proficiency Status dropdown! Expected - "
                            + ReportsUIConstants.AFG_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS + " Actual - " + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );

            SMUtils.logDescriptionTC( "TC29:Verify migrant Status option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), " Migrant status dropdown label is displayed properly", "Issue in display the  migrant status dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the migrant Status dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Migrant drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).containsAll( ReportsUIConstants.AFG_MIGRANT_STATUS_OPTIONS ),
                    "ALL options are displayed properly in  migrant status dropdown", "Issue in displaying the options in  migrant status dropdown! Expected - " + ReportsUIConstants.AFG_MIGRANT_STATUS_OPTIONS + " Actual - "
                            + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );

            SMUtils.logDescriptionTC( "TC30:Verify Ethnicity option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the Ethnicity dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Ethnicity drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).containsAll( ReportsUIConstants.AFG_ETHNICITY_OPTIONS ), "ALL options are displayed properly in Ethnicity dropdown",
                    "Issue in displaying the options in Ethnicity dropdown! Expected - " + ReportsUIConstants.AFG_ETHNICITY_OPTIONS + " Actual - "
                            + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );

            SMUtils.logDescriptionTC( "TC31:Verify social services option name is displayed in the Student demographics" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special services dropdown label is displayed properly", "Issue in display the Special services dropdown label!" );

            SMUtils.logDescriptionTC( "Verify and click the special services dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in special services drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( ReportsUIConstants.AFG_SPECIAL_SERVICES_OPTIONS ),
                    "ALL options are displayed properly in Ethnicity dropdown", "Issue in displaying the options in Ethnicity dropdown! Expected - " + ReportsUIConstants.AFG_SPECIAL_SERVICES_OPTIONS + " Actual - "
                            + dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the area for growth page is displayed for District admin", groups = { "Smoke", "SMK-55038", "AdminDashboard", "Reports", " area for growth" }, priority = 1 )
    public void tcAreaforgrowth004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAreaforgrowth004: Verify the area for growth page is displayed for District admin. <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

        try {
            SMUtils.logDescriptionTC( "TC32:Verify the area for growth page is displayed for District admin" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isReportTitleDisplayed(), "The area for growth title is displayed and it is verified", "The area for growth title is not displayed and it is verified" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE ), "The area for growth title text is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE,
                    "The area for growth title text is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the area for growth page is displayed for Sub-district admin", groups = { "Smoke", "SMK-55038", "AdminDashboard", "Reports", "area for growth" }, priority = 1 )
    public void tcAreaforgrowth005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAreaforgrowth005: Verify the area for growth page is displayed for Sub-district admin <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

        try {
            SMUtils.logDescriptionTC( "TC33:Verify the area for growth page is displayed for Sub-district admin" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isReportTitleDisplayed(), "The area for growth title is displayed and it is verified", "The area for growth title is not displayed and it is verified" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE ), "The area for growth title text is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE,
                    "The area for growth title text is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the area for growth page is displayed for School admin", groups = { "Smoke", "SMK-55038", "AdminDashboard", "Reports", "area for growth" }, priority = 1 )
    public void tcAreaforgrowth006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcAreaforgrowth006: Verify the area for growth page is displayed for School admin <small><b><i>[" + browser + "]</b></i></small>" );

        username = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
        dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

        try {
            SMUtils.logDescriptionTC( "TC34:Verify the area for growth page is displayed for School admin" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isReportTitleDisplayed(), "The area for growth title is displayed and it is verified", "The area for growth title is not displayed and it is verified" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getReportTitle().equals( ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE ), "The area for growth title text is displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE, "The area for growth title text is not displayed as " + ReportsUIConstants.AREA_FOR_GROWTH_PAGE_TITLE );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
