package com.savvas.sm.reports.ui.tests.teacher.lsr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.reports.util.JSONParserUtils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LastSessionReportSaveReportOptions extends EnvProperties {

    private String smUrl;
    private String smUrl1;
    private String browser;
    private String username;
    private String password;
    private String username1;
    private String password1;
    private String teacherDetails;
    private String teacherDetails1;
    private String teacherUsername;
    private String teacherUsername1;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
	private String configGraphQL;


    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        smUrl1 = configProperty.getProperty( "ssoURL" );

        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        username1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "userName" );
        password1 = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUsername1 = SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME );
        
		configGraphQL = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";

        HashMap<String, String> courseIds = new HashMap<>();
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        String studentDetail = RBSDataSetup.getMyStudent( school, teacherUsername );
        String studentDetail1 = RBSDataSetup.getMyStudent( school, teacherUsername1 );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, new ArrayList<>( Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) ) ), new ArrayList<>( courseIds.values() ) );

        HashMap<String, String> staffDetails1 = new HashMap<>();
        staffDetails1.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        staffDetails1.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERID ) );
        staffDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername1, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails1, new ArrayList<>( Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetail1, RBSDataSetupConstants.USERID ) ) ), new ArrayList<>( courseIds.values() ) );

    }

    @Test ( description = "Verify the functionality of Save Report Option for Last Session Report", groups = { "SMK-59825", "Teacher Dashboard", "Reports", "Last Session Report" }, priority = 1 )
    public void tcLastSessionSaveReportOptions01( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the functionality of Save Report Option for Last Session Report<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( username, password );
            RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();

            Log.testCaseInfo( "Verify Saved Report Option label is displayed in the Last Session Report Page" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ), "The Last Session Save Report Option label is displayed and it is verified",
                    "Last Session Report Save Report Option label is not displayed and it is verified" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "Last Session Report Save Report Option label text is displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "Last Session Report Save Report Option label text is not displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify Saved Report Option drop down is displayed in the Last Session Report" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ), "Last Session Report Save Report Option drop down is displayed and it is verified",
                    "Last Session Report Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            String savedReport = "SavedReport" + System.nanoTime();
            SaveReportFilterPopup saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( savedReport );
            saveReportOptionPopup.clickSaveButton();
            Log.testCaseInfo( "Verify the default text in the displayed in the Saved Report Option drop down" );
            Log.message( recentSessionsPage.reportFilterComponent.getWatermarkTextForSaveReportDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ) );
            Log.assertThat(
                    recentSessionsPage.reportFilterComponent.getWatermarkTextForSaveReportDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).equals( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER ),
                    "Last Session Report Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER,
                    "Last Session Report Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ),
                    "The Last Session Save Report Option drop down arrow is displayed and it is verified", "The Last Session Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Saved Report option drop down is listed with saved report options" );
            recentSessionsPage.reportFilterComponent.expandSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Saved report option name is displayed when it is selected" );

            //Click Save Report Options button 
            //recentSessionsPage.reportFilterComponent.clickSaveReportButton();

            Log.testCaseInfo( "Verify user can click the 'Save Report Option' button in Last Session report page" );
            Log.testCaseInfo( "Verify all available fields in 'Save Report Option Popup." );
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();
            driver.navigate().refresh();
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.testCaseInfo( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify user can able to cancel the in 'Save Report Option ' Popup on Last Session report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( recentSessionsPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to save the report option with new name." );
            Log.testCaseInfo( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "SavedReport" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            String filterName2 = "SavedReport" + System.nanoTime();
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName2 );
            saveReportOptionPopup.clickSaveButton();
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( recentSessionsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify If User enter more than 50 characters in new custom report configuration text box." );
            saveReportOptionPopup = recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            Log.testCaseInfo( "Verify User can able to click the close button in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( recentSessionsPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            driver.navigate().refresh();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to single select Aditional Grouping" );
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Group" );

            Log.assertThat( recentSessionsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ADDITIONAL_OPTION ),
                    "User is able to single select Aditional Grouping as Group", "Additional Grouping is not selected as a Group" );

            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to single select Sort" );
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Student" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SORT_LABEL ).equalsIgnoreCase( "Student" ), "User is able to single select Sort as Student",
                    "Sort is not selected as a Student" );

            Log.testCaseResult();

            recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( recentSessionsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
            Log.testCaseInfo( "Verify that after save report options, all the values saved before are getting retained" );
            String sortDropdownSelectedValues = ReportsUIConstants.STUDENT1_LABEL;
            String additionalGroupingDropdownSelectedValues = ReportsUIConstants.GROUP_LABEL;
            Log.assertThat( recentSessionsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).equalsIgnoreCase( additionalGroupingDropdownSelectedValues ),
                    "Additional Grouping Values are Retained Successfully", "Additional Grouping Values not retained Successfully" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SORT_LABEL ).equalsIgnoreCase( sortDropdownSelectedValues ), "Sort Values are Retained Successfully",
                    "Sort Values not retained Successfully" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "SMK-59825", "Teacher Dashboard", "Reports", "Last Session Report" }, priority = 1 )
    public void tcLastSessionSaveReportOptions02( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( username1, password1 );
            RecentSessionsPage recentSessionsPage = areaForGrowthPage.reportFilterComponent.clickOnLastSessionsPage();

            SMUtils.logDescriptionTC( "Verify the Existing custom report configuration dropdown if the user does not have already saved options" );

            recentSessionsPage.reportFilterComponent.clickSaveReportOptionButton();
            SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup( driver );

            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not  disabled if the user does not have already saved options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    
	@Test(description = "Verify the Math-Assignments count matches with the mocked assignments count.", groups = {
			"SMK-67096", "reports", "lastSessionReport" , "mock"}, priority = 1)
	public void tcLastSessionReport_03(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_03: Verify the Math-Assignments count matches with the mocked assignments count. <small><b><i>["
						+ browser + "]</b></i></small>");
	
		try {
			if (DevToolsUtils.isMock( context ) ) {					
			
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify Last Session option should present under the Reports top menu.");

			String json = JSONParserUtils.readFileFromJsonFile("Math_Assignments.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "Assignments", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());
			
			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> allOptions = reportFilterComponent
					.getAllOptionsFromAssignmentMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);
			int assignmentsCount = allOptions.size() - 1;
			Log.assertThat(assignmentsCount == 14, "Assignments count matched", "Assignments count didn't matched");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Reading-Assignments count matches with the mocked assignments count", groups = {
			"SMK-67096", "reports", "lastSessionReport", "mock" }, priority = 1)
	public void tcLastSessionReport_04(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_04: Verify the Reading-Assignments count matches with the mocked assignments count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Reading-Assignments count matches with the mocked assignments count");

			String json = JSONParserUtils.readFileFromJsonFile("Reading_Assignments.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "Assignments", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> allOptions = reportFilterComponent
					.getAllOptionsFromAssignmentMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);
			int assignmentsCount = allOptions.size() - 1;
			Log.assertThat(assignmentsCount == 2, "Assignments count matches.", "Assignments count didn't match");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Saved Report Options matches with the mocked count", groups = { "SMK-67096",
			"reports", "lastSessionReport", "mock" }, priority = 1)
	public void tcLastSessionReport_05(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_05: Verify the Saved Report Options count matches with the mocked count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Saved Report count matches with the mocked count");

			String json = JSONParserUtils.readFileFromJsonFile("OneSavedReportOptions.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GetAllReportOption", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			reportFilterComponent.expandExistingReportOptionDropdown();
			List<String> allSavedOptions = reportFilterComponent.getAvailableOptionsFromSavedReportOptionDropdown();

			System.out.println("count : " + allSavedOptions.size());

			Log.assertThat(allSavedOptions.size() == 2, "Saved Options count matches.",
					"Saved Options count didn't match");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Saved Report Options matches with the mocked count", groups = { "SMK-67096",
			"reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_06(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_06: Verify the Saved Report Options count matches with the mocked count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Saved Report count matches with the mocked count");

			String json = JSONParserUtils.readFileFromJsonFile("TwoSavedReportOptions.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GetAllReportOption", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			List<String> allSavedOptions = reportFilterComponent.getAvailableOptionsFromSavedReportOptionDropdown();

			System.out.println("count : " + allSavedOptions.size());
			Log.assertThat(allSavedOptions.size() == 3, "Saved Options count matches.",
					"Saved Options count didn't match");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Studnets dropdown matches with the one mocked studnets count", groups = {
			"SMK-67096", "reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_07(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_07: Verify the Studnets dropdown matches with the one mocked studnets count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Saved Report count matches with the mocked count");

			String json = JSONParserUtils.readFileFromJsonFile("GroupAndStudentDetails_OneStudent.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			reportFilterComponent.clickStudentRadioButton();
			List<String> options = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);
			int availableGroupOptions = options.size() - 1;
			System.out.println("count : " + availableGroupOptions);
			Log.assertThat(availableGroupOptions == 1, "Studnet count returned as expected.",
					"Student count didn't match");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Studnets dropdown matches with the Five mocked studnets count", groups = {
			"SMK-67096", "reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_08(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_08: Verify the Studnets dropdown matches with the Five mocked studnets count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Studnets dropdown matches with the Five mocked studnets count");

			String json = JSONParserUtils.readFileFromJsonFile("GroupAndStudentDetails.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			reportFilterComponent.clickStudentRadioButton();
			List<String> options = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENT_LABEL);
			int availableGroupOptions = options.size() - 1;
			System.out.println("count : " + availableGroupOptions);
			Log.assertThat(availableGroupOptions == 5, "Studnet count returned as expected.",
					"Student count didn't match.");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Groups dropdown matches with the two mocked Group count", groups = { "SMK-67096",
			"reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_09(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_09: Verify the Groups dropdown matches with the two mocked Group count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the two mocked Group count");

			String json = JSONParserUtils.readFileFromJsonFile("GroupAndStudentDetails.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> options = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);
			int availableGroupOptions = options.size() - 1;
			System.out.println("Group count : " + availableGroupOptions);
			Log.assertThat(availableGroupOptions == 2, "Group count returned as expected.",
					"Group count didn't match.");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Groups dropdown matches with the Zero mocked Group count", groups = { "SMK-67096",
			"reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_10(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_10: Verify the Groups dropdown matches with the Zero mocked Group count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the Zero mocked Group count");

			String json = JSONParserUtils.readFileFromJsonFile("GroupAndStudentDetails_ZeroGroups.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> options = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);
			int availableGroupOptions = options.size() - 1;
			System.out.println("Group count : " + availableGroupOptions);
			Log.assertThat(availableGroupOptions == 0, "Group count returned as expected.",
					"Group count didn't match.");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Groups dropdown matches with the one mocked Group count", groups = { "SMK-67096",
			"reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_11(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_11: Verify the Groups dropdown matches with the one mocked Group count. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Groups dropdown matches with the one mocked Group count");

			String json = JSONParserUtils.readFileFromJsonFile("GroupAndStudentDetails_OneGroups.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);
			List<String> options = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_LABEL);
			int availableGroupOptions = options.size() - 1;
			System.out.println("Group count : " + availableGroupOptions);
			Log.assertThat(availableGroupOptions == 1, "Group count returned as expected.",
					"Group count didn't match.");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Zero State Message for the Zero mocked studnets data", groups = { "SMK-67096",
			"reports", "lastSessionReport" , "mock" }, priority = 1)
	public void tcLastSessionReport_12(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcLastSessionReport_12: Verify the Zero State Message for the Zero mocked studnets data. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			if (DevToolsUtils.isMock( context ) ) {					
					
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			SMUtils.logDescriptionTC("Verify the Zero State Message for the Zero mocked studnets data");

			String json = JSONParserUtils.readFileFromJsonFile("GroupAndStudentDetails_ZeroStudents.json");
			DevTools tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post",
					json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			RecentSessionsPage lastSessionPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();
			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			String zeroStateMessage = "No students exist in the database. Once students are available, you will be able to use the Reports feature.";
			Log.assertThat(reportFilterComponent.verifyZeroStateMessage().contains(zeroStateMessage),
					"Zero State verified!", "Zero State not verified.");

			RequestMockUtils.closeMock(tools);
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

}