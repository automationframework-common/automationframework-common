/**
 * 
 */
/**
 * @author nishanth.kamaraj
 *
 */
package com.savvas.sm.reports.api.groups;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

public class GradeListTest extends ReportAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    public RBSUtils rbsUtils = new RBSUtils();
    private String username;
    private String password;
    private String orgId;
    private String userId;
    private String accessToken;
    private String subdistrictUsername;
    private String multiscl_orgId;
    private Map<String, String> response;
    HashMap<String, String> params = new HashMap<String, String>();
    ReportAPI reports = new ReportAPI();
    String endPoint = AdminConstants.GRADE_LISTING_BFF;

    @BeforeClass
    public void BeforeClass() throws Exception {

        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = configProperty.getProperty( "district_ID" );

        // Creating Admin user data to login
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        subdistrictUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );

        accessToken = rbsUtils.getAccessToken( username, password );
    }

    /**
     * To Verify valid scenarios for Grade Listing
     * 
     * @param testcaseName
     * @param statusCode
     * @param testcaseDescription
     * @param scenarioType
     * @throws Exception
     */
    @Test ( dataProvider = "GradeListPositiveScenariosData", groups = { "SMK-58053", "Grade List Report bff", "API" }, priority = 1 )
    public void tcGradeList001( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        String startDate;
        String endDate;
        Map<String, String> deleteResponse = new HashMap<String, String>();
        List<String> dateFromGetCall;

        Log.testCaseInfo( testcaseName + ":" + testcaseDescription );

        HashMap<String, String> response = new HashMap<>();

        switch ( scenarioType ) {
            case "DISTRICT ADMIN":

                // To get response
                response = getGradeList( userId, Arrays.asList( orgId ), accessToken );
                break;

            case "SUB DISTRICT ADMIN":

                username = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                String adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                Log.message( "admin details" + adminDetails );

                userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                String subdist_orgId = SMUtils.getKeyValueFromResponse( adminDetails, "activeAffiliations,organizationId" );

                accessToken = rbsUtils.getAccessToken( username, password );

                // To get response
                response = getGradeList( userId, Arrays.asList( subdist_orgId ), accessToken );
                break;

            case "MULTI SCL ADMIN":

                username = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
                Log.message( "admin details" + adminDetails );

                userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                multiscl_orgId = SMUtils.getKeyValueFromResponse( adminDetails, "activeAffiliations,organizationId" );
                accessToken = rbsUtils.getAccessToken( username, password );

                // To get response
                response = getGradeList( userId, Arrays.asList( multiscl_orgId ), accessToken );
                break;

            case "SCHOOL ADMIN":

                username = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                Log.message( "admin details" + adminDetails );

                userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                String scladmin_orgId = SMUtils.getKeyValueFromResponse( adminDetails, "activeAffiliations,organizationId" );
                accessToken = rbsUtils.getAccessToken( username, password );

                // To get response
                response = getGradeList( userId, Arrays.asList( scladmin_orgId ), accessToken );
                break;

            case "SAVVAS ADMIN":

                username = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
                Log.message( "admin details" + adminDetails );

                userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                String savvas_orgId = SMUtils.getKeyValueFromResponse( adminDetails, "activeAffiliations,organizationId" );
                accessToken = rbsUtils.getAccessToken( username, password );

                // To get response
                response = getGradeList( userId, Arrays.asList( savvas_orgId ), accessToken );
                break;
        }

        Log.message( "response body:" + response );
        // status code Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        // Verify the response

        verifyResponse( response );

        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] GradeListPositiveScenariosData() {
        Object[][] data = { { "tcGradeList001: ", "200", "Verify the API  when admin is for system admin", "DISTRICT ADMIN" }, { "tcGradeList001: ", "200", "Verify the API  when the admin is for Subdistrict admin", "SUB DISTRICT ADMIN" },
                { "tcGradeList001: ", "200", "Verify the API  When the admin is for multi school", "MULTI SCL ADMIN" }, { "tcGradeList001: ", "200", "Verify the API  When the admin is for one school", "SCHOOL ADMIN" },
                { "tcGradeList001: ", "200", "Verify the API  for the response having all the Data", "SAVVAS ADMIN" } };
        return data;
    }

    /**
     * To Verify Invalid scenarios for Grade Listing
     * 
     * @param testcaseName
     * @param statusCode
     * @param testcaseDescription
     * @param scenarioType
     * @throws Exception
     */
    @Test ( dataProvider = "GradeListNegativeScenariosData", groups = { "SMK-58053", "Grade List Report bff", "API" }, priority = 1 )
    public void tcGradeList002( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        String startDate;
        String endDate;
        Map<String, String> deleteResponse = new HashMap<String, String>();
        List<String> dateFromGetCall;

        Log.testCaseInfo( testcaseName + ":" + testcaseDescription );

        HashMap<String, String> response = new HashMap<>();

        switch ( scenarioType ) {
            case "INVALID USER ID":

                // To get response
                response = getGradeList( UserConstants.INVALID_TEACHER_ID, Arrays.asList( orgId ), accessToken );
                break;

            case "INVALID ORG ID":

                // To get response
                response = getGradeList( orgId, Arrays.asList( UserConstants.INVALID_ORG_ID ), accessToken );
                break;

            case "INVALID TOKEN":

                // To get response
                response = getGradeList( orgId, Arrays.asList( orgId ), UserConstants.INVALID_TEACHER_ID );
                break;

            case "INVALID USER ID AND ORG ID":

                // To get response
                response = getGradeList( UserConstants.INVALID_TEACHER_ID, Arrays.asList( UserConstants.INVALID_TEACHER_ID ), accessToken );
                break;

            case "OTHER ADMIN ORG ID":

                username = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
                String adminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                Log.message( "admin details" + adminDetails );

                userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                String otheradmin_orgId = SMUtils.getKeyValueFromResponse( adminDetails, "activeAffiliations,organizationId" );

                // To get response
                response = getGradeList( UserConstants.INVALID_TEACHER_ID, Arrays.asList( otheradmin_orgId ), accessToken );
                break;
        }

        Log.message( "response body:" + response );
        // status code Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

        Log.testCaseResult();
        Log.endTestCase();
    }

    // @DataProvider

    /*
     * Invalid scenarios get valid response bodies. This scenario will be fixed
     * in 257 sprints by the developer team.
     * 
     */
    public Object[][] GradeListNegativeScenariosData() {
        Object[][] data = { { "tcGradeList002: ", "200", "Verify the API  when the user id is invalid", "INVALID USER ID" }, { "tcGradeList002: ", "200", "Verify the API  when the org is invalid", "INVALID ORG ID" },
                { "tcGradeList002: ", "200", "Verify the API  When the access token is invalid", "INVALID TOKEN" }, { "tcGradeList002: ", "200", "Verify the API  When the user id and org id both are invalid", "INVALID USER ID AND ORG ID" },
                { "tcGradeList002: ", "200", "Verify the API  when the other admin org id as input", "OTHER ADMIN ORG ID" } };
        return data;
    }

    public void verifyResponse( HashMap<String, String> response ) {
        Log.testCaseInfo( "Verify the response for grade k value in the API." );
        Log.testCaseInfo( "Verify the response for grade 1 - 12  values  in the API." );
        Log.testCaseInfo( "Verify the response for  grade value as Not specoified in the API." );
        Log.testCaseInfo( "Verify the fields gradeName,gradeid,display order and grade values are display in response " );

        List<String> actGradeListing = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), Constants.GRADE_NAME );

        Log.assertThat( actGradeListing.containsAll( Constants.Students.ALL_GRADES ), "Grades are listing", "Grades are not listing properly" );

    }

}
