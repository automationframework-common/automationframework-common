package com.savvas.sm.reports.api.teacher.exportCSVTest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.util.ExportUtils;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

import io.restassured.response.Response;

/**
 * To verify the Teacher - Student Performance report Export CSV API
 * 
 * @author bharathi.murugan
 */
public class TeacherStudentPerformanceExportCSVTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String school;
    private String orgId;
    private String teacherDetails;
    private String teacherId;
    private String teacherUsername;
    private String studentOneDetails;
    private String studentTwoDetails;
    private String studentThreeDetails;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    private Map<String, String> headers = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void init() {
        // Retrieving URL from Config.properites
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        //To get the school and teacher details from RBS Datasetup
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );

        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        //To get the student details
        studentOneDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentTwoDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentThreeDetails = RBSDataSetup.getMyStudent( school, teacherUsername );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentOneDetails, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentTwoDetails, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentThreeDetails, RBSDataSetupConstants.USERID ) );

        //Math Course Names
        courseName.put( Constants.MATH, AssignmentAPIConstants.MATH_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime() ) );

        //Reading Course Names
        courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        //Math course Ids
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );

            courseIds.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE,
                    new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherId, orgId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
        } catch ( Exception e ) {
            Log.message( "Issue in Math Custom course creation!! - " + e.getMessage() );
        }

        //Reading course Ids
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
            courseIds.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
                    new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherId, orgId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            //Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }
            Log.message( "Assignment IDs - " + assignmentIds );
        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }

        IntStream.range( 0, 2 ).parallel().forEach( itr -> {
            if ( itr == 0 ) {
                //Course Execution - student 1 (IP Cleared student) 
                String studentUsername = SMUtils.getKeyValueFromResponse( studentOneDetails, RBSDataSetupConstants.USERNAME );
                executeCourse( studentUsername, courseName.get( Constants.MATH ), true, true );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ), true, true );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ), true, true );

                executeCourse( studentUsername, courseName.get( Constants.READING ), false, true );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ), false, true );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ), false, true );
            } else if ( itr == 1 ) {
                //Course Execution - student 2 (IN IP student) 
                String studentUsername = SMUtils.getKeyValueFromResponse( studentTwoDetails, RBSDataSetupConstants.USERNAME );
                executeCourse( studentUsername, courseName.get( Constants.MATH ), true, false );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ), true, false );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ), true, false );

                executeCourse( studentUsername, courseName.get( Constants.READING ), false, false );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ), false, false );
                executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ), false, false );
            }

        } );

        //headers for authorization
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
    }

    @Test ( dataProvider = "positiveScenarios", groups = { "SMK-66709", "Export-CSV", "P1", "smoke_test_case" }, priority = 1 )
    public void teacherSPRExportCSVAPIPositiveTests( String tcId, String description, String statusCode, String scenario ) {

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        headers.put( Constants.AUTHORIZATION, Constants.BEARER + teacherAccessToken );

        switch ( scenario ) {
            case "MATH_ASSIGNMENTS_FOR_STUDENT_ID":
                Response csvResponse = ExportUtils.postTeacherStudentPerformanceReportCSV( headers, false, Arrays.asList( studentRumbaIds.get( 0 ) ), true, Arrays.asList( assignmentIds.get( courseName.get( Constants.MATH ) ) ), 10400, false,
                        new ArrayList<>() );

                break;

            default:
                break;
        }
    }

    /**
     * Data provider for positive scenario
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarios" )
    public Object[][] positiveScenarios() {

        Object[][] inputData = { { "tc_teacherSPRCSV001", "SPR-Teacher : Verfiy the satus code and column headers in the response, if pass the student Ids and math assignment Ids in the request parameter", CommonAPIConstants.STATUS_CODE_OK,
                "MATH_ASSIGNMENTS_FOR_STUDENT_ID" } };
        return inputData;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "95", "2", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "31" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "95", "2", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "31" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

}
