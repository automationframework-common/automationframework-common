package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.restassured.response.Response;

public class CPADataGridTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> org;
    private List<String> courses;
    private String organizationName;
    private String adminUserId;
    private String teacherUsername;
    private String teacherName;
    String grade;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        username = ReportData.districtAdmin;
        adminUserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, RBSDataSetupConstants.USERID );
        Log.message( adminUserId );
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        teacherUsername = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 1, usernameSuffixTest );
        teacherName = "(" + SMUtils.getKeyValueFromResponse( ReportData.teacherDetails.get( teacherUsername ), RBSDataSetupConstants.FIRSTNAME ) + " "
                + SMUtils.getKeyValueFromResponse( ReportData.teacherDetails.get( teacherUsername ), RBSDataSetupConstants.LASTNAME ) + ")";

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default math course is only assigned to the student", groups = { "SMK-57913", "CPAggregateDataGrid", "CPAggregateDataGrid" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default math course is only assigned to the student<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Math" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );
            // getCPARResponseDetails(bffReport.getBody().asString());

            grade = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "COMPLETE" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "default math course is only assigned to the student is present",
                    "default math course is only assigned to the student is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default math course is assigned to the student and attempted under IP", groups = { "SMK-57913", "CPAggregateDataGrid", "CPAggregateDataGrid" }, priority = 2 )
    public void tcCPRAggregateSaveReportOptions002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default math course is assigned to the student and attempted under IP<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Math" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "PENDING" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default math course is assigned to the student and attempted under IP is present",
                    "single student when the default math course is assigned to the student and attempted under IP is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default math course is assigned to the student and attempted IP Cleared", groups = { "SMK-57913", "CPAggregateDataGrid", "CPAggregateDataGrid" }, priority = 3 )
    public void tcCPRAggregateSaveReportOptions003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default math course is assigned to the student and attempted IP Cleared<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Math" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "COMPLETE" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default math course is assigned to the student and attempted IP Cleared is present",
                    "single student when the default math course is assigned to the student and attempted IP Cleared is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default math course is assigned to the student and attempted IP Cleared with more than 90%", groups = { "SMK-57913", "CPAggregateDataGrid",
            "CPAggregateDataGrid" }, priority = 4 )
    public void tcCPRAggregateSaveReportOptions004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default math course is assigned to the student and attempted IP Cleared with more than 90%<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Math" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "PENDING" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default math course is assigned to the student and attempted IP Cleared with more than 90% is present",
                    "single student when the default math course is assigned to the student and attempted IP Cleared with more than 90% is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default reading course is only assigned to the student", groups = { "SMK-57913", "CPAggregateDataGrid", "CPAggregateDataGrid" }, priority = 5 )
    public void tcCPRAggregateSaveReportOptions005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default reading course is only assigned to the student<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Reading" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "COMPLETE" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default reading course is only assigned to the student is present",
                    "single student when the default reading course is only assigned to the student is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default reading course is assigned to the student and attempted under IP", groups = { "SMK-57913", "CPAggregateDataGrid", "CPAggregateDataGrid" }, priority = 6 )
    public void tcCPRAggregateSaveReportOptions006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default reading course is assigned to the student and attempted under IP<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ));
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Reading" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "PENDING" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default reading course is assigned to the student and attempted under IP is present",
                    "single student when the default reading course is assigned to the student and attempted under IP is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default reading course is assigned to the student and attempted IP Cleared", groups = { "SMK-57913", "CPAggregateDataGrid", "CPAggregateDataGrid" }, priority = 7 )
    public void tcCPRAggregateSaveReportOptions007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default reading course is assigned to the student and attempted IP Cleared<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Reading" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "COMPLETE" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default reading course is assigned to the student and attempted under IP is present",
                    "single student when the default reading course is assigned to the student and attempted under IP is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the CPR aggregate Report for a single student when the default reading course is assigned to the student and attempted IP Cleared with more than 75%", groups = { "SMK-57913", "CPAggregateDataGrid",
            "CPAggregateDataGrid" }, priority = 8 )
    public void tcCPRAggregateSaveReportOptions008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify the CPR aggregate Report for a single student when the default reading course is assigned to the student and attempted IP Cleared with more than 75%<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( organizationName ) );

            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            SMUtils.logDescriptionTC( "Verify User can able to run the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to run the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            CPAReportViewerPage reportClick = CPAReport.clickRunReportButton();
            CPAReportViewerPage reportViewer = new CPAReportViewerPage( driver );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District: 2022 Successmaker Basic District Grade: All" ), "District present", "District Not present" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.message( reportViewer.getLegendOptions().toString() );
            Map<String, Map<String, String>> skillsDetails = reportViewer.getGridvalues();
            Log.message( skillsDetails.toString() );

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
            headers.put( Constants.USERID_SM_HEADER, adminUserId );

            Map<String, String> filters = new HashMap<>();
            filters.put( "{subject}", "Reading" );
            filters.put( "{orgId}", configProperty.getProperty( "district_ID" ) );
            filters.put( "{userId}", adminUserId );
            filters.put( "{selectedOrgId}", ReportData.orgId );
            filters.put( "{additionalGrouping}", "2" );

            Response bffReport = (Response) reportViewer.getBFFReport( headers, filters );
            Log.message( bffReport.getBody().asString() );
            Log.message( skillsDetails.toString() );

            grade = ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignments -> SMUtils.getKeyValueFromResponse( assignments, "ipStatus" ).equals( "PENDING" ) ).map(
                    assignments -> SMUtils.getKeyValueFromResponse( assignments, "assignedLevel" ) ).findFirst().orElse( null );
            if ( grade.equals( "0" ) ) {
                grade = "K -";
            } else {
                grade = "G" + grade + " -";
            }
            Map<String, Map<String, String>> responseDetails = reportViewer.getCPARResponseDetails( bffReport.getBody().asString() );

            String actualKey = responseDetails.keySet().stream().filter( key -> key.contains( grade ) ).findFirst().orElse( null );

            Log.assertThat( SMUtils.compareTwoHashMap( skillsDetails.get( actualKey ), responseDetails.get( actualKey ) ), "single student when the default reading course is assigned to the student and attempted under IP is present",
                    "single student when the default reading course is assigned to the student and attempted under IP is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
