package com.savvas.sm.reports.bff.admin.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicValues;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import io.restassured.response.Response;

public class CPARReportAdminGraphQLTest extends EnvProperties {

    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String studentId;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String mathId;
    String readingId;
    String responseStatusCode;
    String assignmentdetail;
    String flexSchool;
    String teacherDetails;
    String orgId;
    String teacherId;
    String studentDemographicDetails;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );
        studentId = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[0].toString();
        studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );
        studentAssignmentIdReading = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        // School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = ReportData.orgId;
        studentDemographicDetails = new UserAPI().getStudentDetailsByStudentId( studentId, firstTeacherId, selectedSchoolId, new RBSUtils().getAccessToken( firstTeacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) ).get( Constants.REPORT_BODY );

    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin CPAR Report Graphql", "SMK-58038", "P1", "API" } )
    public void getAdminCPARReport_Positive( String tcId, String description, String statusCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();
        List<String> studId = new ArrayList<String>();
        studId.add( studentId );

        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getCPAAdminReportData" ) ).get( 0 ).toString(), "courseName" );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Subject is displayed as Math", "Subject is not displayed as Math" );
                Log.assertThat( validateResponseDataWithCPR( response.getBody().asString(), selectedSchoolId, true, false ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "SUB_DISTRICT_ADMIN":
                response = getCPARReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, subDistId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithCPR( response.getBody().asString(), subDistId, true, false ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "SCHOOL_ADMIN":

                response = getCPARReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, adminSchoolId, Constants.READING, filterByValues );
                subjectName = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getCPAAdminReportData" ) ).get( 0 ).toString(), "courseName" );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.READING ), "Subject is displayed as Reading", "Subject is not displayed as Reading" );
                Log.assertThat( validateResponseDataWithCPR( response.getBody().asString(), adminSchoolId, false, false ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":
                // Filter by single Teacher, Grade and Group

                filterByValues.put( DemographicFilters.RACE, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,race" ) );
                filterByValues.put( DemographicFilters.ETHNICITY, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,ethnicity" ) );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,specialServices" ) );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,hasDisability" ) );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,hasEconomicDisadvantage" ) );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,hasEnglishProficiency" ) );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, SMUtils.getKeyValueFromResponse( studentDemographicDetails, "data,isMigrant" ) );

                response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                Log.assertThat( validateResponseDataWithCPR( response.getBody().asString(), distId, true, false ), "Report data are same as DB data", "Report data are not same as DB data" );

                break;

            case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":
                // Filter by single Teacher, Grade and Group
                filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                Log.assertThat( validateResponseDataWithCPR( response.getBody().asString(), distId, true, true ), "Report data are same as DB data", "Report data are not same as DB data" );

                break;

        }

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + "is not Verified" );

        Log.testCaseResult();

    }

    @DataProvider ( name = "PositiveScenarios" )
    public Object[][] testScenario() {

        Object[][] inputData = {

                { "tc_CPAR_BFF_001", "Verify the 200 status code and valid reponse for the district admin credentia", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },

                { "tc_CPAR_BFF_002", "Verify the 200 status code and valid reponse for the subdistrict admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT_ADMIN" },

                { "tc_CPAR_BFF_003", "Verify the 200 status code and valid reponse for the school admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },

                { "tc_CPAR_BFF_004", "Verify the 200 Status code and the output response when passing single values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE" },

                { "tc_CPAR_BFF_005", "Verify the 200 Status code and the output response when passing multiple values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE" },


        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "NegativeScenarios", groups = { "Admin CPAR Report Graphql", "SMK-58038", "P1", "API" } )
    public void getAdminCPARReport_Negative( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        switch ( scenario ) {

            case "INVALID_ACCESS_TOKEN":

                response = getCPARReport( distAdminUserName + "INVALID", password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_ORG_ID":

                response = getCPARReport( distAdminUserName, password, distAdminuserId, distId + "INVALID", selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_USER_ID":

                response = getCPARReport( distAdminUserName, password, distAdminuserId + "INVALID", distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "EMPTY_ORG_ID":

                response = getCPARReport( distAdminUserName, password, distAdminuserId, "", selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "EMPTY_USER_ID":

                response = getCPARReport( distAdminUserName, password, "", distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;
        }

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message not displayed as expected" );
        } else {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message not displayed as expected" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "NegativeScenarios" )
    public Object[][] testNegativeScenario() {

        Object[][] inputData = { { "tc_CPAR_BFF_007", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPAR_BFF_008", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPAR_BFF_009", "Verify  401: UnAuthorized  and response when invalid userId is given in the query ", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPAR_BFF_010", "Verify the message in the response when organizationId passed as empty array. ", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPAR_BFF_011", "Verify the message in the response when invalid subject type passed in the query.", "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin CPAR Report Graphql", "SMK-58038", "P1", "API", "smoke_test_case" } )
    public void getAdminCPARReport_SchemaValidation( String tcId, String description, String statusCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();
        try {
            switch ( scenario ) {

                case "DISTRICT_ADMIN":

                    response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPAR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SUB_DISTRICT_ADMIN":

                    response = getCPARReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPARReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPAR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SCHOOL_ADMIN":
                    response = getCPARReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.READING, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPARReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.READING, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPAR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPAR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                    response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPAR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "FILTER_BY_COURSE_VALUE":

                    mathId = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    readingId = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    filterByValues.put( "{courseList}", mathId + "," + readingId );

                    response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPAR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;
            }

        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( response, "CPAR" );
        }
        Log.testCaseResult();

    }

    /**
     * TO validate CPAR with Mean value of CPR
     * 
     * @param responseBody
     * @param selectedOrg
     * @param isMath
     * @param isAllDemographic
     * @return
     * @throws Exception
     */
    public boolean validateResponseDataWithCPR( String responseBody, String selectedOrg, boolean isMath, boolean isAllDemographic ) throws Exception {
        Boolean validation;
        if ( responseBody.contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
            Log.message( ReportAPIConstants.NO_DATA_FOUND_MESSAGE );
            validation = true;
        } else {
            // Get data from response

            HashMap<String, HashMap<String, String>> responseFromCPAR = getDataFromResponse( responseBody );
            Log.message( "CPAR Data From  Response ----->" + " " + responseFromCPAR );
            String courseId = null;
            String subject = null;
            if ( isMath ) {
                
                String courseListMath = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    
                courseId=courseListMath;
                subject = Constants.MATH;

            } else {
                String courseListReading = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    
                courseId=courseListReading;
                subject = Constants.READING;
            }

            Log.message( "Performing CPR API call" );
            HashMap<String, String> filterByValues = new HashMap<>();
            CPRReportAdminGraphQLTest cPRReportAdminGraphQLTest = new CPRReportAdminGraphQLTest();
            filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );
            filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02" );
            filterByValues.put( "{courseList}", courseId );
            if ( isAllDemographic ) {
                filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

            }
            Response responseCPR = cPRReportAdminGraphQLTest.getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, subject, filterByValues );

            Map<String, Map<String, String>> responseFromCPR = null;
            if ( !responseCPR.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                responseFromCPR = getResponseFromCPR( responseCPR.getBody().asString() );
            } else {
                responseFromCPR = setNullResposneForCPR( responseCPR.getBody().asString() );
            }

            validation = responseFromCPR.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), responseFromCPAR.get( entry.getKey() ) ) );
        }
        return validation;

    }

    /**
     * Setting the CPR Response to default values
     * @param responseCPR
     * @return
     */
    private Map<String, Map<String, String>> setNullResposneForCPR( String responseCPR ) {
        Map<String, Map<String, String>> studentReportDetails = new HashMap<>();
        Map<String, String> studentReport = new HashMap<>();
        studentReport.put( "timeSpent", "NA" );
        studentReport.put( "totalSessions", "NA" );

        studentReport.put( "currentCourseLevel", "NA" );

        studentReport.put( "gain", "NA" );

        studentReport.put( "ipLevel", "NA" );

        studentReport.put( "skillsAssessed", "NA" );

        studentReport.put( "skillsMastered", "NA" );

        studentReport.put( "exercisesCorrect", "NA" );
        studentReport.put( "exercisesAttempted", "NA" );

        studentReportDetails.put( "02", studentReport );

        return studentReportDetails;
    }

    /**
     * Fetching the CPR response
     * @param response
     * @return
     */
    public Map<String, Map<String, String>> getResponseFromCPR( String response ) {

        // Getting data from response
        String jsonObj1 = getKeyValueFromResponseWithArray( response, "data,getAdminCPReportData" );
        String orgData = getKeyValueFromResponseWithArray( jsonObj1, "orgData" );
        Map<String, Map<String, String>> studentReportDetails = new HashMap<>();

        ArrayList<Integer> timeSpent = new ArrayList<Integer>();
        ArrayList<Integer> totalSessions = new ArrayList<Integer>();
        ArrayList<Integer> currentCourseLevel = new ArrayList<Integer>();
        ArrayList<Integer> gain = new ArrayList<Integer>();
        ArrayList<Integer> ipLevel = new ArrayList<Integer>();
        ArrayList<Integer> skillsAssessed = new ArrayList<Integer>();
        ArrayList<Integer> skillsMastered = new ArrayList<Integer>();
        ArrayList<Integer> exercisesCorrect = new ArrayList<Integer>();
        ArrayList<Integer> exercisesAttempted = new ArrayList<Integer>();

        IntStream.range( 0, new JSONArray( orgData ).length() ).forEach( iter -> {

            String students = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( orgData ).get( iter ).toString(), "studentRows" );

            try {
                IntStream.range( 0, new JSONArray( students ).length() ).forEach( itr -> {

                    String usage = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "usage" );

                    JSONObject usageJson = new JSONObject( usage );
                    timeSpent.add( usageJson.get( "timeSpent" ).toString().contains( "0" ) ? 0 : (Integer) usageJson.get( "timeSpent" ) );
                    totalSessions.add( usageJson.get( "totalSessions" ).toString().contains( "null" ) ? 0 : (Integer) usageJson.get( "totalSessions" ) );

                    String studentsData = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "levelData" );

                    JSONObject stdJson = new JSONObject( studentsData );

                    currentCourseLevel.add( Integer.parseInt( stdJson.get( "currentCourseLevel" ).toString() ) <= 0 ? 0 : (Integer) stdJson.get( "currentCourseLevel" ) );

                    gain.add( stdJson.get( "gain" ).toString().contains( "0" ) ? 0 : (Integer) stdJson.get( "gain" ) );

                    ipLevel.add( stdJson.get( "ipLevel" ).toString().equals( "null" ) ? 0 : (Integer) stdJson.get( "ipLevel" ) );

                    String mastery = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "mastery" );
                    JSONObject masteryJson = new JSONObject( mastery );
                    skillsAssessed.add( masteryJson.get( "skillsAssessed" ).toString().contains( "0" ) ? 0 : (Integer) masteryJson.get( "skillsAssessed" ) );

                    skillsMastered.add( masteryJson.get( "skillsMastered" ).toString().contains( "0" ) ? 0 : (Integer) masteryJson.get( "skillsMastered" ) );

                    String instructionalPerformance = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "instructionalPerformance" );
                    JSONObject instructionJson = new JSONObject( instructionalPerformance );

                    exercisesCorrect.add( instructionJson.get( "exercisesCorrect" ).toString().contains( "0" ) ? 0 : (Integer) instructionJson.get( "exercisesCorrect" ) );
                    exercisesAttempted.add( instructionJson.get( "exercisesAttempted" ).toString().contains( "0" ) ? 0 : (Integer) instructionJson.get( "exercisesAttempted" ) );

                } );
            } catch ( Exception e ) {
                e.printStackTrace();
            }

        } );
        HashMap<String, String> studentReport = new HashMap<>();

        int avgTimeSpent = 0;
        int avgTotalSessions = 0;
        int avgCurrentCourseLevel = 0;
        int avgGain = 0;
        int avgIpLevel = 0;
        int avgSkillAssessed = 0;
        int avgSkillMastered = 0;
        int avgExerciseCorrect = 0;
        int avgExerciseAttempted = 0;

        for ( Integer value : timeSpent ) {
            avgTimeSpent += value;
        }
        avgTimeSpent = avgTimeSpent / timeSpent.size();

        for ( Integer value : totalSessions ) {
            avgTotalSessions += value;
        }
        avgTotalSessions = avgTotalSessions / totalSessions.size();

        for ( Integer value : currentCourseLevel ) {
            avgCurrentCourseLevel += value;
        }
        avgCurrentCourseLevel = avgCurrentCourseLevel / currentCourseLevel.size();

        for ( Integer value : gain ) {
            avgGain += value;
        }
        avgGain = avgGain / gain.size();

        for ( Integer value : ipLevel ) {
            avgIpLevel += value;
        }
        avgIpLevel = avgIpLevel / ipLevel.size();

        for ( Integer value : skillsAssessed ) {
            avgSkillAssessed += value;
        }
        avgSkillAssessed = avgSkillAssessed / skillsAssessed.size();

        for ( Integer value : skillsMastered ) {
            avgSkillMastered += value;
        }
        avgSkillMastered = avgSkillMastered / skillsMastered.size();

        for ( Integer value : exercisesCorrect ) {
            avgExerciseCorrect += value;
        }
        avgExerciseCorrect = avgExerciseCorrect / exercisesCorrect.size();

        for ( Integer value : exercisesAttempted ) {
            avgExerciseAttempted += value;
        }
        avgExerciseAttempted = avgExerciseAttempted / exercisesAttempted.size();

        studentReport.put( "timeSpent", ( avgTimeSpent <= 0 ) ? "0" : Integer.toString( avgTimeSpent ) );
        studentReport.put( "totalSessions", ( avgTotalSessions <= 0 ) ? "NA" : Integer.toString( avgTotalSessions ) );
        studentReport.put( "currentCourseLevel", ( avgCurrentCourseLevel <= 0 ) ? "NA" : Integer.toString( avgCurrentCourseLevel ) );

        studentReport.put( "gain", ( avgGain <= 0 ) ? "NA" : Integer.toString( avgGain ) );

        studentReport.put( "ipLevel", ( avgIpLevel <= 0 ) ? "NA" : Integer.toString( avgIpLevel ) );

        studentReport.put( "skillsAssessed", ( avgSkillAssessed <= 0 ) ? "NA" : Integer.toString( avgSkillAssessed ) );

        studentReport.put( "skillsMastered", ( avgSkillMastered <= 0 ) ? "NA" : Integer.toString( avgSkillMastered ) );
        studentReport.put( "exercisesCorrect", ( avgExerciseCorrect <= 0 ) ? "0" : Integer.toString( avgExerciseCorrect ) );
        studentReport.put( "exercisesAttempted", ( avgExerciseAttempted <= 0 ) ? "NA" : Integer.toString( avgExerciseAttempted ) );

        studentReportDetails.put( "02", studentReport );
        Log.message( "CPR Response Data: " + studentReportDetails );
        return studentReportDetails;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromResponse( String responseBody ) {
        int count = 1;
        // Getting data from response
        String jsonObj1 = getKeyValueFromResponseWithArray( responseBody, "data,getCPAAdminReportData" );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();

        IntStream.range( 0, new JSONArray( jsonObj1 ).length() ).forEach( iter -> {
            String dataRow = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( jsonObj1 ).get( iter ).toString(), "dataRows" );

            IntStream.range( 0, new JSONArray( dataRow ).length() ).forEach( itr -> {
                String grade = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( jsonObj1 ).get( iter ).toString(), "grade" );
                String studentsData = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "levelDataMean" );

                JSONObject stdJson = new JSONObject( studentsData );
                HashMap<String, String> studentReport = new HashMap<>();

                studentReport.put( "ipLevel", stdJson.get( "ipLevel" ).toString().equals( "null" ) ? "NA" : stdJson.get( "ipLevel" ).toString() );
                studentReport.put( "currentCourseLevel", stdJson.get( "currentCourseLevel" ).toString().equals( "null" ) ? "NA" : stdJson.get( "currentCourseLevel" ).toString() );
                studentReport.put( "gain", stdJson.get( "gain" ).toString().equals( "null" ) ? "NA" : stdJson.get( "gain" ).toString() );

                String mastery = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "masteryMean" );
                JSONObject masteryJson = new JSONObject( mastery );
                studentReport.put( "skillsAssessed", masteryJson.get( "skillsAssessed" ).toString().contains( "null" ) ? "NA" : masteryJson.get( "skillsAssessed" ).toString() );

                studentReport.put( "skillsMastered", masteryJson.get( "skillsMastered" ).toString().contains( "null" ) ? "NA" : masteryJson.get( "skillsMastered" ).toString() );

                String instructionalPerformance = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "instructionalPerformanceMean" );
                JSONObject instructionJson = new JSONObject( instructionalPerformance );
                studentReport.put( "exercisesCorrect",
                        instructionJson.get( "exercisesCorrect" ).toString().contains( "null" ) || instructionJson.get( "exercisesCorrect" ).toString().contains( "null" ) ? "NA" : instructionJson.get( "exercisesCorrect" ).toString() );
                studentReport.put( "exercisesAttempted", instructionJson.get( "exercisesAttempted" ).toString().contains( "null" ) ? "NA" : instructionJson.get( "exercisesAttempted" ).toString() );

                String usage = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "usageMean" );
                JSONObject usageJson = new JSONObject( usage );
                studentReport.put( "timeSpent", usageJson.get( "timeSpent" ).toString().contains( "null" ) ? "NA" : usageJson.get( "timeSpent" ).toString() );
                studentReport.put( "totalSessions", usageJson.get( "totalSessions" ).toString().contains( "null" ) ? "NA" : usageJson.get( "totalSessions" ).toString() );

                studentReportDetails.put( grade, studentReport );

            } );
        } );
        Log.message( "CPAR Response Data: " + studentReportDetails );
        return studentReportDetails;
    }

    /**
     * This method used to fetch report data from CPAR grapphql
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues - pass the optional filter values in HashMap
     * @return
     * @throws Exception
     */
    public static Response getCPARReport( String username, String password, String userId, String userOrgId, String schoolId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload
        String payLoad = getPayLoad();
        payLoad = String.format( payLoad, userOrgId, userId, subject, schoolId );
        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().equals( ReportFilters.ADDITIONAL_GROUP_ID_VALUE ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
                                                                                 // payload in number format
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in
                                                                                                   // payload in string
                                                                                                   // format
            }
        }
        payLoad = payLoad.replace( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "0" ).replace( ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( DemographicFilters.DISABILITY_STATUS, "" ).replace(
                DemographicFilters.ENGLISH_PROFICIENCY, "" ).replace( DemographicFilters.GENDER, "" ).replace( DemographicFilters.MIGRANT_STATUS, "" ).replace( DemographicFilters.RACE, "" ).replace( DemographicFilters.ETHNICITY, "" ).replace(
                        DemographicFilters.SOCIO_STATUS, "" ).replace( DemographicFilters.SPECIAL_SERVICES, "" ).replace( "{courseList}", "" );
        Log.message( "Headers :" + headers );
        Log.message( "Payload : " + payLoad );

        // Getting CPAR repport response
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {

            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();

            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }

    public static String getPayLoad() {
        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getCPAAdminReportData(\\n    organizationId: \\\"%s\\\"\\n    userId: \\\"%s\\\"\\n    filterParams: {subject: \\\"%s\\\", courseList: [{courseList}], additionalGrouping: 2, filterBySchool: [\\\"%s\\\"], filterByDemographics: {disabilityStatus: [{disabilityStatus}], englishLanguageProficiency: [{language}], gender: [{gender}], migrantStatus: [{migrantStatus}], race: [{race}], ethnicity: [{ethnicity}], socioeconomicStatus: [{socioStatus}], specialServices: [{specialServices}]}}\\n  ) {\\n    courseName\\n    reportRun\\n    grade\\n    dataRows {\\n      orgData {\\n        organizationName\\n        numberOfStudents\\n      }\\n      levelDataMean {\\n        currentCourseLevel\\n        ipLevel\\n        gain\\n      }\\n      usageMean {\\n        timeSpent\\n        totalSessions\\n      }\\n      instructionalPerformanceMean {\\n        exercisesCorrect\\n        exercisesAttempted\\n        exercisesPercentCorrect\\n      }\\n      masteryMean {\\n        skillsAssessed\\n        skillsMastered\\n        skillsPercentMastered\\n        percentStudentsWithAP\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    /**
     * To get data from given response for UI validation
     * 
     * @param responseBody
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromResponseForVerification( String responseBody ) {
        int count = 1;
        // Getting data from response
        String jsonObj1 = getKeyValueFromResponseWithArray( responseBody, "data,getCPAAdminReportData" );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();

        IntStream.range( 0, new JSONArray( jsonObj1 ).length() ).forEach( iter -> {
            String dataRow = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( jsonObj1 ).get( iter ).toString(), "dataRows" );

            IntStream.range( 0, new JSONArray( dataRow ).length() ).forEach( itr -> {
                String grade = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( jsonObj1 ).get( iter ).toString(), "grade" );
                String studentsData = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "levelDataMean" );

                JSONObject stdJson = new JSONObject( studentsData );
                HashMap<String, String> studentReport = new HashMap<>();

                studentReport.put( "currentCourseLevel", stdJson.get( "currentCourseLevel" ).toString().equals( "null" ) ? "NA" : stdJson.get( "currentCourseLevel" ).toString() );

                String instructionalPerformance = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "instructionalPerformanceMean" );
                JSONObject instructionJson = new JSONObject( instructionalPerformance );
                studentReport.put( "exercisesCorrect",instructionJson.get( "exercisesCorrect" ).toString().contains( "null" ) || instructionJson.get( "exercisesCorrect" ).toString().contains( "0" ) ? "NA" : instructionJson.get( "exercisesCorrect" ).toString() );
                studentReport.put( "exercisesAttempted", instructionJson.get( "exercisesAttempted" ).toString().contains( "null" ) || instructionJson.get( "exercisesAttempted" ).toString().contains( "0" ) ? "NA" : instructionJson.get( "exercisesAttempted" ).toString() );

                String usage = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( dataRow ).get( itr ).toString(), "usageMean" );
                JSONObject usageJson = new JSONObject( usage );
                studentReport.put( "totalSessions", usageJson.get( "totalSessions" ).toString().contains( "null" ) ? "NA" : usageJson.get( "totalSessions" ).toString() );

                studentReportDetails.put( grade, studentReport );

            } );
        } );
        Log.message( "CPAR Response Data: " + studentReportDetails );
        return studentReportDetails;
    }
}