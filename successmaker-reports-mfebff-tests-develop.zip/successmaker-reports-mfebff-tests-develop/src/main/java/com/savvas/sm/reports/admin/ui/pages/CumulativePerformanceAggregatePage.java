package com.savvas.sm.reports.admin.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class CumulativePerformanceAggregatePage extends LoadableComponent<CumulativePerformanceAggregatePage> {

    WebDriver driver;
    boolean isPageLoaded;
    public AdminReportFilterComponent reportFilterComponent;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    /***************** POM for Page **************************/

    @IFindBy ( how = How.CSS, using = "cel-tab-panel.tab-panel.hydrated.tab-panel-cumulativePerformanceAggregate", AI = false )
    private WebElement cprAggregatetoggle;

    @IFindBy ( how = How.CSS, using = "saved-report-options label", AI = false )
    private WebElement savereportOptionLabel;

    @IFindBy ( how = How.TAG_NAME, using = "h1", AI = false )
    private WebElement pageTitle;

    @IFindBy ( how = How.CSS, using = "cel-tab-panel.tab-panel", AI = false )
    private WebElement togglebutton;

    @IFindBy ( how = How.CSS, using = "cel-button", AI = false )
    private WebElement runReportRoot;

    @IFindBy ( how = How.CSS, using = ".optional-filters-wrapper.hydrated", AI = false )
    private WebElement optionalFilterRoot;

    /**************** Child Elements *******************/

    private String cprAggregateChild = "div.tab-container button.selected";
    private String accordion = "#accordion-button-undefined";
    private String selectedButton = "button.selected";

    public CumulativePerformanceAggregatePage() {}

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public CumulativePerformanceAggregatePage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        reportFilterComponent = new AdminReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "cumulative Aggregate Performance Page loaded successfully." );
        } else {
            Log.fail( "Cumulative Aggregate Performance Page not loaded successfully." );
        }

    }

    /**
     * To verify the sub navigation is selected or not
     * 
     * @return
     */
    public boolean isCPAReportSelected() {
        Log.message( "Verifing Cumulative Performance Aggregate is selected" );
        return SMUtils.getWebElementDirect( driver, cprAggregatetoggle, selectedButton ).getText().trim().equalsIgnoreCase( ReportTypes.CUMULATIVE_PERFORMANCE_AGGREGATE );

    }

    /**
     * Get text for cpr aggregate
     * 
     * @return
     */
    public String getCPRAggregateHeaderText() {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprAggregateChild );
        Log.message( "Get CPR aggregate text" );
        return actualElement.getText().trim();
    }

    /**
     * Click optional Filter in Report
     */
    public void clickOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, accordion );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }

    /**
     * 
     * @return
     * @throws Exception
     */
    public boolean isCPRAggregateColorDisplay() throws Exception {
        SMUtils.waitForElement( driver, cprAggregatetoggle );
        WebElement actualElement = SMUtils.getWebElement( driver, cprAggregatetoggle, cprAggregateChild );
        Log.message( "Verifying CPR aggregate color is displaying" );
        return SMUtils.checkColor( actualElement, ReportsUIConstants.COLOR_CPRAGGREGATE );
    }

}
