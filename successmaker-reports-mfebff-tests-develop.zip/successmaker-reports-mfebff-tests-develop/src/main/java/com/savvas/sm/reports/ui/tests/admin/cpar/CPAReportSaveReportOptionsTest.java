package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class CPAReportSaveReportOptionsTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify 'Save Report Option'  button in CPR aggregate report page", groups = { "Smoke", "SMK-57902", "SaveReportOption", "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateSaveReportOptions001: Verify the user can navigates to Cumulativer Performance Aggregate page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            SMUtils.logDescriptionTC( "Verify 'Save Report Option'  button in CPR aggregate report page" );
            Log.assertThat( CPAReport.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in CPA report",
                    "The save report option is not displayed in CPA report" );
            Log.assertThat( !CPAReport.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();

            orgName = CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify user can click the 'Save Report Option' button in CPR aggregate report page" );
            SMUtils.logDescriptionTC( "Verify all available fields in 'Save Report Option Popup." );
            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to cancel the in 'Save Report Option ' Popup on CPR aggregate report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( CPAReport.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with new name." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify If User enter more than 50 characters in new custom report configuration text box." );
            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            SMUtils.logDescriptionTC( "Verify User can able to click the close button in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( CPAReport.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)", groups = { "Smoke", "SMK-57902", "SaveReportOption", "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateSaveReportOptions002: Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Time Spent(Mean)' in sort Dropdown with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ), courses.get( 2 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Time Spent (Mean)" );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with all options in all required and optional filters" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Total Sessions(Mean)' in sort Dropdown with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Total Sessions (Mean)" );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Grade' option in Additional Grouping 'IP Level(Mean)\" in sort Dropdown with display on CPR aggregate report and load the report", groups = { "SMK-57902", "SaveReportOption",
            "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcCPRAggregateSaveReportOptions003: Verify User can able to save the report option with 'Grade' option in Additional Grouping 'IP Level(Mean)\" in sort Dropdown with display on CPR aggregate report and load the report)<small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping 'IP Level(Mean)\" in sort Dropdown with display on CPR aggregate report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "IP Level (Mean)" );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Gain(Mean)' in sort Dropdown with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Gain (Mean)" );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Excercises Correct(Mean)' in sort Dropdown with display on CPR aggregate Report and load the report" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct (Mean)" );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Excercises Attempted(Mean)' in sort Dropdown with All options in student demographics dropdowns and load the report and load the report", groups = { "SMK-57902",
            "SaveReportOption", "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcCPRAggregateSaveReportOptions004:Verify User can able to save the report option with 'Excercises Attempted(Mean)' in sort Dropdown with All options in student demographics dropdowns and load the report and load the report<small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Excercises Attempted(Mean)' in sort Dropdown with All options in student demographics dropdowns and load the report and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct (Mean)" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Excercises Precent Correct(Mean)' in sort Dropdown with in sort Dropdown with multiple options in student demographics dropdowns and load the report", groups = { "SMK-57902",
            "SaveReportOption", "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcCPRAggregateSaveReportOptions005:Verify User can able to save the report option with 'Excercises Precent Correct(Mean)' in sort Dropdown with in sort Dropdown with multiple options in student demographics dropdowns and load the report<small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Excercises Precent Correct(Mean)' in sort Dropdown with in sort Dropdown with multiple options in student demographics dropdowns and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Percent Correct (Mean)" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ), ReportsUIConstants.GENDER_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Skills Assessed(Mean)' in sort Dropdown with Select any one options in student demographics dropdowns and load the report", groups = { "SMK-57902", "SaveReportOption",
            "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateSaveReportOptions006:Verify User can able to save the report option with 'Skills Assessed(Mean)' in sort Dropdown with Select any one options in student demographics dropdowns and load the report<small><b><i>["
                + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Skills Assessed(Mean)' in sort Dropdown with Select any one options in student demographics dropdowns and load the report" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Assessed (Mean)" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Skills Mastered(Mean)' in sort Dropdown, Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown.", groups = { "SMK-57902",
            "SaveReportOption", "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcCPRAggregateSaveReportOptions007:Verify User can able to save the report option with 'Skills Mastered(Mean)' in sort Dropdown, Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown.<small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Skills Mastered(Mean)' in sort Dropdown, Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown." );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Mastered (Mean)" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Skills Percent Mastered(Mean)' in sort Dropdown with Select 'Female' option in 'Gender' dropdown and 'Migrant' in Migrant status dropdown." );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Percent Mastered (Mean)" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Percent Students With AP' in sort Dropdown, 'White' option in Race dropdown and 'Hispanico or Latino' in Ethnicity dropdown." );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Percent Students With AP" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            CPAReport.reportFilterComponent.clickResetButton();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Select 'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown." );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.size() - 1 ) ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.size() - 1 ) ) );

            saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "Smoke", "SMK-57902", "SaveReportOption", "CPASaveReportOption" }, priority = 1 )
    public void tcCPRAggregateSaveReportOptions008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateSaveReportOptions008: Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            SMUtils.logDescriptionTC( "Verify the Existing custom report configuration dropdown if the user does not have already saved options" );

            orgName = CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 0 );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = CPAReport.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not  disabled if the user does not have already saved options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
