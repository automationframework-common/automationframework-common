package com.savvas.sm.reports.smoke.teacher.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.teacher.ui.pages.PrescriptiveSchedulingReport;
import com.savvas.sm.reports.constants.ReportsUIConstants.Reports;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AreasForGrowthReport extends LoadableComponent<AreasForGrowthReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    Random random = new Random();
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.CSS, using = "h1.report-heading", AI = false )
    public WebElement txtAreasForGrowthReportHeader;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String drpDwnAdditionalGroupingshadowDOM[] = { "cel-accordion-item",
            "document.querySelector(\"body > app-root > div > teacher-reports-wrapper > div > div > section > teacher-report > section > section > form > teacher-report-body > div > teacher-areas-for-growth > cel-accordion-item > section > section > div:nth-child(1) > single-select > div > cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };
    public String drpDwnDisplayshadowDOM[] = { "cel-accordion-item",
            "document.querySelector(\"body > app-root > div > teacher-reports-wrapper > div > div > section > teacher-report > section > section > form > teacher-report-body > div > teacher-areas-for-growth > cel-accordion-item > section > section > div:nth-child(1) > div > single-select > div > cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };
    public String drpDwnSortshadowDOM[] = { "cel-accordion-item",
            "document.querySelector(\"body > app-root > div > teacher-reports-wrapper > div > div > section > teacher-report > section > section > form > teacher-report-body > div > teacher-areas-for-growth > cel-accordion-item > section > section > div:nth-child(2) > single-select:nth-child(1) > div > cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };
    public String drpDwnDatesAtRiskShadowDOM[] = { "cel-single-select",
            "document.querySelector(\"body > app-root > div > teacher-reports-wrapper > div > div > section > teacher-report > section > section > form > teacher-report-body > div > teacher-areas-for-growth > cel-accordion-item > section > section > div:nth-child(2) > single-select:nth-child(2) > div > cel-single-select\").shadowRoot.querySelector(\"#dropdown\")" };

    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };
    public String txtAdditionalGroupingDrpdwn = "NONE";
    public String txtGroupDrpdwn = "STUDENT_NAME";
    public String txtSortDrpdwn = "STRAND";
    public String txtDatesAtRiskDrpdwn = "SINCE_IP";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtAreasForGrowthReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public AreasForGrowthReport() {}

    public AreasForGrowthReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas validate Additional Grouping dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateAdditionalGroupingDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnAdditionalGroupingshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnAdditionalGroupingshadowDOM[0], this.drpDwnAdditionalGroupingshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnAdditionalGroupingshadowDOM, "Additional Grouping Drop Down Field" );
        String attributeValue = drpDwnAdditionalGroupingshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equals( txtAdditionalGroupingDrpdwn ), "Selected '" + attributeValue + "' as default value in Additional Grouping Drpdwn Field", "'" + attributeValue + "' is not a default value in Additional Grouping Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas validate Display dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateDisplayDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnDisplayshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnDisplayshadowDOM[0], this.drpDwnDisplayshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnDisplayshadowDOM, "Display Drop Down Field" );
        String attributeValue = drpDwnDisplayshadowDOM.getAttribute( "data-selected" );
        Log.softAssertThat( attributeValue.equals( txtGroupDrpdwn ), "Selected '" + attributeValue + "' as default value in Group Drpdwn Field", "'" + attributeValue + "' is not a default value in Group Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas validate Sort dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSortDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnSortshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnSortshadowDOM[0], this.drpDwnSortshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnSortshadowDOM, "Sort Drop Down Field" );
        String attributeValue = drpDwnSortshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.trim().equalsIgnoreCase( txtSortDrpdwn ), "Selected '" + attributeValue + "' as default value in Sort Drpdwn Field", "'" + attributeValue + "' is not a default value in Sort Drpdwn Field" );
    }

    /**
     * @author raseem.mohamed Description - This method used to verify that user
     *         once apply saved reports option we verifying the same value is
     *         retained in saved report drop down or not
     */ // Changes Based On Teacher
    public void validateSavedReports( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Thread.sleep( 2000 );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Areas For Growth Report" ), "User Landed On Areas For Growth Report", "User Not Landed On Areas For Growth Report" );
        List<String> expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds());
        List<String> groups = new ArrayList<String>( Arrays.asList( expgroupNames.get(0) ) );
        reportsFilterUtils.selectGroupsDropdwn( driver, groups );
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        String savedReportName = "Automation Teacher SavedReport " + random.nextInt(); // Generating Random Name For Saved
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author sathish.suresh validate Dates At Risk dropdown Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateDatesAtRiskDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnDatesAtRiskShadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnDatesAtRiskShadowDOM[0], this.drpDwnDatesAtRiskShadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnDatesAtRiskShadowDOM, "Dates At Risk Drop Down Field" );
        String attributeValue = drpDwnDatesAtRiskShadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.equals( txtDatesAtRiskDrpdwn ), "Selected '" + attributeValue + "' as default value in Dates At Risk Drpdwn Field", "'" + attributeValue + "' is not a default value in Dates At Risk Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas validate All Fields in AFG Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInAFGReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtAreasForGrowthReportHeader.getText();

        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        // groups & Students - text
        // groups text & drop down
        // students text and drop down 
        reportsFilterUtils.verifyTextGroupsAndStudents( driver );
        reportsFilterUtils.verifyTextGroupsHeader( driver );
        reportsFilterUtils.validateGroupsDrpdwnField( driver );

        reportsFilterUtils.verifyTextStudentsHeader( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        //Assignment text & drop down
        reportsFilterUtils.verifyTextAssignmentsHeader( driver );
        reportsFilterUtils.validateAssignmentsDrpdwnField( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );
        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );
        SMUtils.click( driver, txtOptionalFilter );

        reportsFilterUtils.verifyTextAdditionalGrouping( driver );

        validateAdditionalGroupingDrpdwnField( driver );
        reportsFilterUtils.verifyTextDisplay( driver );
        validateDisplayDrpdwnField( driver );

        reportsFilterUtils.validateMaskCheckBoxField( driver );

        reportsFilterUtils.verifyTextSortInAdditionalGrouping( driver );
        validateSortDrpdwnField( driver );

        reportsFilterUtils.verifyTextDatesAtRisk( driver );
        validateDatesAtRiskDrpdwnField( driver );

    }

    /**
     * @author sathish.suresh Validate AFG run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateAFGRunReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds());
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "organization", expgroupNames.get(0));
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        ReportsViewerPage clickRunReport = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param reportNameToSwitch
     * @return Object
     * @throws InterruptedException
     */
    public Object selectReportFromSideNavigation( WebDriver driver, Reports reports ) throws InterruptedException {
        Object returnPage = null;
        String reportNameToSwitch = String.valueOf( reports );
        Log.message( "Report Name To Switch : " + reportNameToSwitch );
        String btnCumulativePerformanceshadowDOM[] = { "cel-side-navigation", "document.querySelector('cel-side-navigation').shadowRoot.querySelector('cel-side-item[data-label=\"" + reportNameToSwitch + "\"]').shadowRoot.querySelector('button')" };
        WebElement webElement = ShadowDOMUtils.retryAndGetWebElement( driver, btnCumulativePerformanceshadowDOM[0], btnCumulativePerformanceshadowDOM[1] );
        SMUtils.click( driver, webElement );
        // Returning Respective Reports Page Based On The Selection
        switch ( reportNameToSwitch ) {
            case "Areas For Growth":
                returnPage = new AreasForGrowthReport( driver ).get();
                break;
            case "Cumulative Performance":
                returnPage = new CumulativePerformanceReport( driver ).get();
                break;
            case "Last Session":
                returnPage = new LastSessionReport( driver ).get();
                break;
            case "Student Performance":
                returnPage = new StudentPerformanceReport( driver ).get();
                break;
            case "Prescriptive Scheduling":
                returnPage = new PrescriptiveSchedulingReport( driver ).get();
                break;

        }
        ;
        return returnPage;
    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public AreasForGrowthReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtAreasForGrowthReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sathish.suresh Validate Teacher AFG run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateAFGTeacherRunReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        reportsFilterUtils.selectStudentRadioBtn( driver );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sakthi.sasi Used to verify the Groups in UI matches the Group
     *         fetched from RBS
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyGroup( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getTeacherGroupIds() );
        List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getTeacherGroupNames();
        Collections.sort( expgroupNames );
        Collections.sort( allValuesFromGroupsDropdown );
        Log.softAssertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
        return this;
    }

    /**
     * @author sakthi.sasi
     *  Used to verify the assignments
     * @param driver
     * @param username
     * @param smUrl
     * @param teacherDetails
     * @param assignmentType
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyAssignments( WebDriver driver, String username, String smUrl, String teacherDetails, String assignmentType ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> assignmentsFromUI = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.ASSIGNMENTS );
        List<String> assignmentList = reportsFilterUtils.getAssignmentDetails( smUrl, username, teacherDetails, assignmentType );
        Log.softAssertThat( assignmentList.containsAll( assignmentsFromUI ), "All assignments displayed properly in the assignment dropdown!", "Assignments not displayed properly in thes assignment dropdown" );
        return this;
    }

    /**
     * @author sakthi.sasi
     * Used to verify the students
     * @param driver
     * @param schoolName
     * @param username
     * @return
     * @throws Exception
     */
    public AreasForGrowthReport verifyStudents( WebDriver driver, String schoolName, String username ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        reportsFilterUtils.selectStudentRadioBtn( driver );
        // get WebElements of dropdown option checkboxes
        List<String> allStudentsFromUI = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.Teacher_Students );
        List<String> studentNames = reportsFilterUtils.getStudentsList( username, schoolName );
        Log.softAssertThat( studentNames.containsAll( allStudentsFromUI ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );
        return this;
    }

}
