package com.savvas.sm.reports.ui.tests.teacher.afg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants.RemoveStudentsFromGroupsAPIConstants;

public class AFGTeacherReportSaveReportOptionsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String orgId;
    public  String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;;
    private String username1;
    private String teacherDetails;
    private String teacherId;
    private String teacherDetails1;
    private String teacherId1;
    private String teacherUsername;
    private String teacherUsername1;
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static List<String> studentRumbaIds1 = new ArrayList<>();
    private static List<String> studentUserName = new ArrayList<>();
    private static List<String> courseIDs = new ArrayList<>();
    private static HashMap<String, String> groupDetails = new HashMap<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> assignmentDetails1 = new HashMap<>();
    private static HashMap<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> contentBaseName = new HashMap<>();
    private String studentDetail = null;
    private String studentDetail1 = null;
    private String studentDetail2 = null;
    private String studentDetail3 = null;
    String studentId  = null;
    String studentId1 = null;
    String studentId2 = null;
    String studentId3 = null;
    CourseAPI coursesMethod = new CourseAPI();


    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );

        //Teacher Details 1
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        Log.message( "teacherUsername: " + teacherUsername + " teacherId: " + teacherId );

        //Teacher Details 2
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        teacherUsername1 = SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME );
        teacherId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "userId" );
        Log.message( "teacherUsername1: " + teacherUsername1 + " teacherId1: " + teacherId1 );

        //Student Details
        studentDetail=RBSDataSetup.getMyStudent( school, teacherUsername );
        studentDetail1=RBSDataSetup.getMyStudent( school, teacherUsername );
        studentDetail2=RBSDataSetup.getMyStudent( school, teacherUsername1 );
        studentDetail3=RBSDataSetup.getMyStudent( school, teacherUsername1 );

        studentId= SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentId1= SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER );
        studentId2= SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USERID_HEADER );
        studentId3= SMUtils.getKeyValueFromResponse( studentDetail3, Constants.USERID_HEADER );

        studentRumbaIds.add( studentId );
        studentRumbaIds.add( studentId1 );
        studentRumbaIds1.add( studentId2 );
        studentRumbaIds1.add( studentId3 );
        Log.message( "studentRumbaIds: " + studentRumbaIds );

        studentUserName.add( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );
        studentUserName.add( SMUtils.getKeyValueFromResponse( studentDetail1, RBSDataSetupConstants.USERNAME ) );
        studentUserName.add( SMUtils.getKeyValueFromResponse( studentDetail2, RBSDataSetupConstants.USERNAME ) );
        studentUserName.add( SMUtils.getKeyValueFromResponse( studentDetail3, RBSDataSetupConstants.USERNAME ) );
        Log.message( "studentUserName: " + studentUserName );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "ChiefsGroupTest" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        HashMap<String, String> createGroupDetails = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
        String groupId = SMUtils.getKeyValueFromResponse(createGroupDetails.get(Constants.REPORT_BODY), "data,groupId");
        Log.message( "GroupID: " + groupId );

        //Assignment Details
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
                coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment for Students..." );
        Log.message( "Assignment Details(Students)- " + new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs ) );

        assignmentDetails1.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails1.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails1.put( AssignmentAPIConstants.COURSE_ID, courseIDs.get( 0 ) );

        Log.message( "Assigning assignment for Groups..." );
        Log.message( "Assignment Details(Groups)- " + new AssignmentAPI().assignAssignment( smUrl, assignmentDetails1, studentRumbaIds1, AssignmentAPIConstants.GROUPS_TYPE  ) );
    }


    @Test ( description = "Verify 'Save Report Option'  button in areas for growth report page", groups = { "SMK-66746", "Teacher Dashboard", "Save Report Options", "AFG Report" }, priority = 1 )
    public void tcAFGteacherSaveReport001( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "TC025: Verify User can able to save the report option with multiple options in all required and optional filters  with Subject (Math)" );
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( teacherUsername, password );
            Log.message( "Login as Teacher: " + teacherUsername + " Password: " + password );
            String filterName = "AFGSaveReport" + System.nanoTime();

            Log.testCaseInfo( "TC001: Verify 'Save Report Option'  button in AFG Report page" );
            Log.testCaseInfo( "TC022: Verify User can able to save the report option with default Optional filters." );
            Log.assertThat( areaForGrowthPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ), "Save Report Option label is displayed in AFG report input page, Test Passed!!",
                    "Save Report Option label is not displayed in AFG report input page, Test Failed :(" );
            Log.testCaseResult();

            driver.navigate().refresh();
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );
            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();
            SMUtils.waitForSpinnertoDisapper( driver, 5 );

            if ( areaForGrowthPage.reportFilterComponent.isSaveReportButtonEnabled() ) {

                Log.message( "TC002: Verify user can click the 'Save Report Option'  button in AFG Report page" );
                SaveReportFilterPopup saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                Log.testCaseResult();

                Log.testCaseInfo( "TC003: Verify all available fields in 'Save Report Option  Popup for AFG teacher Report" );
                Log.testCaseInfo( "TC004: Verify Save Report Header is getting displayed in the Save Report Option popup for AFG report" );
                Log.testCaseInfo( "TC005: Verify 'Name and save this new custom report configuration.' title is displayed above the new report filter textbox  in the Save Report Option popup modal for AFG report" );
                Log.testCaseInfo( "TC006: Verify Help icon(?) along with Save Report Options  title is displayed  in the Save Report Option popup modal for AFG report" );
                Log.testCaseInfo( "TC007: Verify 'Name new custom report configuration' placeholder is getting displayed inside the textbox for the new save Report option textbox in the Save Report Option popup modal for AFG Report" );
                Log.testCaseInfo( "TC008: Verify 'Select an existing custom report configuration to be replaced/updated.' title is displayed above the existing report filers dropdown in the Save Report option popup modal for AFG Report " );

                Log.assertThat( saveReportOptionPopup.isSaveReportOptionsHeaderDisplayed(), "Save Report Option Header is displayed as expected!", "Save Report Option Header is not displayed as expected!!" );
                Log.assertThat( saveReportOptionPopup.isHelpIconInHeaderDisplayed(), "Help Icon(?) in Header is displayed as expected!", "Help Icon(?) in Header is not displayed !!!" );
                Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly","New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
                Log.assertThat( saveReportOptionPopup.ValidateNewReportFilterPlaceholder( "Name new custom report configuration" ), "Expected text is present Save Report options dialog box","Expected text is Not Present in Save Report options dialog box" );
                Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly","New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
                Log.testCaseResult();

                Log.testCaseInfo( "TC010: Verify that 'Save' button is displayed in disabled state by default when user enters into the Save Report option popup  of AFG report" );
                Log.testCaseInfo( "TC011: Verify if click the save button with empty Name in 'Save Report Option' Popup for AFG Report" );
                Log.testCaseInfo( "TC030: Verify the Existing custom report configuration dropdown if the user does not have already saved options" );
                Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
                Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
                saveReportOptionPopup.clickSaveButton();
                Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
                Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing dropdown in Save Report Popup is not enabled in Zero state, Test Passed!!", "Existing dropdown in Save Report Popup is enabled in Zero state, Test Failed:(" );
                Log.testCaseResult();

                Log.testCaseInfo( "TC018: Verify User can able to click the cancel in save report option of AFG Report" );
                Log.testCaseInfo( "TC021: Verify If User enter more than 50 characters in new custom report configuration text box of AFG Report." );
                saveReportOptionPopup.enterNameForSaveReport( ReportsUIConstants.LENGTHY_NAME );
                Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length","Error Message is not displayed properly for name exceed maximum length" );
                saveReportOptionPopup.clickCancelButton();
                SMUtils.waitForSpinnertoDisapper( driver );
                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                Log.testCaseInfo( "TC019: Verify User can able to click the close button(X icon) in save report option of AFG Report." );
                saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                saveReportOptionPopup.clickCloseIcon();
                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                Log.testCaseInfo( "TC014: Verify User can able to save the report option with new name for AFG report" );
                Log.testCaseInfo( "TC020: Verify If User enter less than 50 characters in new custom report configuration text box of AFG Report." );
                Log.testCaseInfo( "TC026: Verify User can able to save the report option with Additional grouping as 'Group' , Display as 'Student ID',  Sort as ' Level'  and Dates at Risk as '12 Weeks'" );
                areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORTNAME.get( 1 ) );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAYNAME.get( 1 ) );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATESATRISK.get( 4 ) );
                saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                saveReportOptionPopup.enterNameForSaveReport( filterName );
                saveReportOptionPopup.clickSaveButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                Log.testCaseInfo( "TC016: Verify the newly saved report filter is getting displayed with the filter name  in the 'SAVED REPORT OPTIONS' dropdown of AFG Report input page" );
                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                Log.testCaseInfo( "TC012: Verify if user clicks the save button with already existing name in 'Save Report Option' Popup for AFG Report" );
                Log.testCaseInfo( "TC028: Verify User can able to save the report with same name after selecting the existing saved report filter from AFG report input page" );
                saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                SMUtils.nap( 5 );
                saveReportOptionPopup.enterNameForSaveReport( filterName );
                saveReportOptionPopup.clickSaveButton();
                Log.assertThat( areaForGrowthPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
                Log.testCaseResult();

            } else {

                Log.fail( "Save Report Option is not in enabled state:( "
                        + "- Please check the student, Group and Assignment details for the teacher: " + teacherUsername  );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }



    @Test ( description = "Verify User can able to save the report option with special characters, String, Integer  for AFG report", groups = { "SMK-66746", "Teacher Dashboard", "Save Report Options", "AFG Report" }, priority = 1 )
    public void tcAFGteacherSaveReport002( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        String filterName = "~!@#$%^&234JJS" + System.nanoTime();

        Log.testCaseInfo( "TC023: Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page" );
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( teacherUsername, password );
            Log.message( "Login as Teacher: " + teacherUsername + " Password: " + password );

            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver, 5 );
            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();

            Log.testCaseInfo( "TC024: Verify User can able to save the report option with single options in all required and optional filters  with Subject (Reading)" );
            Log.testCaseInfo( "TC027: Verify User can able to save the report option with Additional grouping as 'Grade' , Display as 'Student Username',  Sort as ' Strand'  and Dates at Risk as '24 Weeks'" );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORTNAME.get( 0 ) );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAYNAME.get( 2 ) );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATESATRISK.get( 1 ) );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );

            if ( areaForGrowthPage.reportFilterComponent.isSaveReportButtonEnabled() ) {

                Log.testCaseInfo( "TC015: Verify User can able to save the report option with special characters, String, Integer  for AFG report" );
                SaveReportFilterPopup saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                saveReportOptionPopup.enterNameForSaveReport( filterName );
                saveReportOptionPopup.clickSaveButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                Log.testCaseInfo( "TC009: Verify 'Select existing custom report configuration' placeholder is getting displayed inside the existing Report filter dropdown in the Save Report Option popup modal for AFG Report" );
                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                Log.testCaseInfo( "TC017: Verify the newly saved report filter is getting displayed with the filter name  in the \"Existing custom report configuration\" dropdown of Saved Report Option popup modal" );
                saveReportOptionPopup.ValidateExistingReportFilterPlaceholder( filterName );
                Log.testCaseResult();

                Log.testCaseInfo( "TC029: Verify User can able to save the report with new name after selecting the existing saved report filter from AFG report input page" );
                filterName = "NewFilter" + System.nanoTime();
                saveReportOptionPopup.enterNameForSaveReport( filterName );
                saveReportOptionPopup.clickSaveButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                Log.testCaseInfo( "TC023: Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page" );
                Log.testCaseInfo( "TC013: Verify user can able to select the option in Existing custom report configuration dropdown for AFG Report" );
                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
                saveReportOptionPopup.clickSaveButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                Log.assertThat( areaForGrowthPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
                Log.testCaseResult();


            } else {

                Log.fail( "Save Report Option is not in enabled state:( "
                        + "- Please check the student, Group and Assignment details for the teacher: " + teacherUsername  );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page(Math)", groups = { "SMK-66746", "Teacher Dashboard", "Save Report Options", "AFG Report" }, priority = 1 )
    public void tcAFGteacherSaveReport003( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        String filterName = "ChiefsFilter" + System.nanoTime();

        Log.testCaseInfo( "TC023: Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page(Math)" );
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( teacherUsername, password );
            Log.message( "Login as Teacher: " + teacherUsername + " Password: " + password );

            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver, 5 );
            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();

            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORTNAME.get( 0 ) );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAYNAME.get( 2 ) );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATESATRISK.get( 1 ) );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );

            List<String> beforeSubjectValues =  Arrays.asList(ReportsUIConstants.MATH);
            List<String> beforeAssignmentValues =  Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION  );
            List<String> beforeAdditionalGroupValues =  Arrays.asList(AFGReportConstants.GRADE_CAPS); //GRADE
            List<String> beforeSortValues =  Arrays.asList(AFGReportConstants.STRAND_CAPS); //STRAND
            List<String> beforeDisplayValues =  Arrays.asList(AFGReportConstants.STUDENT_USERNAME_CAPS); //STUDENT_USERNAME
            List<String> beforeDateAtRiskValues =  Arrays.asList(AFGReportConstants.DATE_AT_RISK_INT.get( 0 )); //24

            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( AFGReportConstants.AFG_SUBJECT_LABEL, beforeSubjectValues);
            beforeSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, beforeAssignmentValues);
            beforeSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, beforeAdditionalGroupValues);
            beforeSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, beforeSortValues);
            beforeSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, beforeDisplayValues);
            beforeSavedFilterValues.put( ReportsUIConstants.DATE_AT_RISK, beforeDateAtRiskValues);
            Log.message( "beforeSavedFilterValues: " + beforeSavedFilterValues );

            if ( areaForGrowthPage.reportFilterComponent.isSaveReportButtonEnabled() ) {

                SaveReportFilterPopup saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                saveReportOptionPopup.enterNameForSaveReport( filterName );
                saveReportOptionPopup.clickSaveButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                String subjectID =  areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL) ;
                if ( subjectID.equals( "1" ) ) {
                    subjectID = subjectID.replace( "1", "Math" );
                } else {
                    subjectID = subjectID.replace( "2", "Reading" );
                }

                List<String> subjectValues =  Arrays.asList( subjectID );
                List<String> assignmentValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL) );
                List<String> adtlGroupingValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.ADDITIONAL_GROUPING_LBL) );
                List<String> sortValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.SORT_LABEL) );
                List<String> displayValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.DISPLAY_LABEL) );
                List<String> dateAtRiskValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.DATE_AT_RISK) );

                HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
                afterSavedFilterValues.put( AFGReportConstants.AFG_SUBJECT_LABEL, subjectValues);
                afterSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, assignmentValues);
                afterSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, adtlGroupingValues);
                afterSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, sortValues);
                afterSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, displayValues);
                afterSavedFilterValues.put( ReportsUIConstants.DATE_AT_RISK, dateAtRiskValues);
                Log.message( "afterSavedFilterValues: " + afterSavedFilterValues );

                Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                        "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );
                Log.testCaseResult();


            } else {

                Log.fail( "Save Report Option is not in enabled state:( "
                        + "- Please check the student, Group and Assignment details for the teacher: " + teacherUsername  );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page(Read)", groups = { "SMK-66746", "Teacher Dashboard", "Save Report Options", "AFG Report" }, priority = 1 )
    public void tcAFGteacherSaveReport004( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        String filterName = "ChiefsRead" + System.nanoTime();

        Log.testCaseInfo( "TC031: Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page(Read)" );
        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage areaForGrowthPage = smLoginPage.loginToSMAsTeacher( teacherUsername, password );
            Log.message( "Login as Teacher: " + teacherUsername + " Password: " + password );

            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver, 5 );
            areaForGrowthPage.reportFilterComponent.clickStudentRadioButton();

            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORTNAME.get( 0 ) );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAYNAME.get( 2 ) );
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(  ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATESATRISK.get( 1 ) );
            SMUtils.waitForSpinnertoDisapper( driver, 5 );

            List<String> beforeSubjectValues =  Arrays.asList(ReportsUIConstants.READING);
            List<String> beforeAssignmentValues =  Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION  );
            List<String> beforeAdditionalGroupValues =  Arrays.asList(AFGReportConstants.GRADE_CAPS); //GRADE
            List<String> beforeSortValues =  Arrays.asList(AFGReportConstants.STRAND_CAPS); //STRAND
            List<String> beforeDisplayValues =  Arrays.asList(AFGReportConstants.STUDENT_USERNAME_CAPS); //STUDENT_USERNAME
            List<String> beforeDateAtRiskValues =  Arrays.asList(AFGReportConstants.DATE_AT_RISK_INT.get( 0 )); //24

            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( AFGReportConstants.AFG_SUBJECT_LABEL, beforeSubjectValues);
            beforeSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, beforeAssignmentValues);
            beforeSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, beforeAdditionalGroupValues);
            beforeSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, beforeSortValues);
            beforeSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, beforeDisplayValues);
            beforeSavedFilterValues.put( ReportsUIConstants.DATE_AT_RISK, beforeDateAtRiskValues);
            Log.message( "beforeSavedFilterValues: " + beforeSavedFilterValues );

            if ( areaForGrowthPage.reportFilterComponent.isSaveReportButtonEnabled() ) {

                SaveReportFilterPopup saveReportOptionPopup = areaForGrowthPage.reportFilterComponent.clickSaveReportOptionButton();
                saveReportOptionPopup.enterNameForSaveReport( filterName );
                saveReportOptionPopup.clickSaveButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                Log.testCaseResult();

                areaForGrowthPage.reportFilterComponent.clickResetButton();
                SMUtils.waitForSpinnertoDisapper( driver, 5 );
                areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
                SMUtils.waitForSpinnertoDisapper( driver, 5 );

                String subjectID =  areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL) ;
                if ( subjectID.equals( "2" ) ) {
                    subjectID = subjectID.replace( "2", "Reading" );
                } else {
                    subjectID = subjectID.replace( "1", "Math" );
                }

                List<String> subjectValues =  Arrays.asList( subjectID );
                List<String> assignmentValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL) );
                List<String> adtlGroupingValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.ADDITIONAL_GROUPING_LBL) );
                List<String> sortValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.SORT_LABEL) );
                List<String> displayValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.DISPLAY_LABEL) );
                List<String> dateAtRiskValues =  Arrays.asList( areaForGrowthPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew(ReportsUIConstants.DATE_AT_RISK) );

                HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
                afterSavedFilterValues.put( AFGReportConstants.AFG_SUBJECT_LABEL, subjectValues);
                afterSavedFilterValues.put( ReportsUIConstants.ASSIGNMENTS_LBL, assignmentValues);
                afterSavedFilterValues.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, adtlGroupingValues);
                afterSavedFilterValues.put( ReportsUIConstants.SORT_LABEL, sortValues);
                afterSavedFilterValues.put( ReportsUIConstants.DISPLAY_LABEL, displayValues);
                afterSavedFilterValues.put( ReportsUIConstants.DATE_AT_RISK, dateAtRiskValues);
                Log.message( "afterSavedFilterValues: " + afterSavedFilterValues );

                Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                        "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );
                Log.testCaseResult();


            } else {

                Log.fail( "Save Report Option is not in enabled state:( "
                        + "- Please check the student, Group and Assignment details for the teacher: " + teacherUsername  );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}