package com.savvas.sm.reports.ui.pages;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

public class StudentPerformanceOutputPage extends LoadableComponent<StudentPerformanceOutputPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportOutputComponent reportOutputComponent;

    // ********* SuccessMaker Launcher/Login Page Elements ***************

    @FindBy ( css = "report-viewer-header h2" )
    WebElement pageTitle;

    @FindBy ( css = "div.row.ml-0 .list-head" )
    WebElement headerLegend;

    @FindBy ( css = "dl.detail-row.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;

    //Recent Session Report Grid

    @FindBy ( css = "tr.header th" )
    List<WebElement> reporttabletitle;

    @FindBy ( css = "tr.sub-header th" )
    List<WebElement> reporttablesubtitle;

    @FindBy ( css = "tr td.foot" )
    List<WebElement> lasttworow;

    @FindBy ( css = "p.table-note" )
    WebElement endtablenotes;

    @FindBy ( css = "tr td:nth-of-type(2)" )
    List<WebElement> currentcourselevelrow;

    @FindBy ( css = "spr-performance-by-strand span" )
    WebElement Strandheader;

    @FindBy ( css = "spr-performance-summary > section > h2 > span" )
    WebElement performanceSummaryHeader;

    @FindBy ( css = "span.section-main-header" )
    List<WebElement> sprSectionHeaders;

    @FindBy ( css = "#table > thead > tr.sub-header" )
    WebElement pbLevelDataHeader;

    @FindBy ( css = "div.cell-data.text-overflow-nowrap" )
    List<WebElement> sprRowFieldNames;

    @FindBy ( css = "#table > tbody > tr > td.col-group-end:nth-child(2) > div" )
    List<WebElement> sprRowFieldValues;

    @FindBy ( css = "h2.student-name.ml-3" )
    WebElement studentName;

    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement assignmentName;

    @FindBy ( css = "dl.detail-row.ml-3 dt" )
    WebElement reportRunText;

    @FindBy ( css = "dl.detail-row.ml-3 dd" )
    WebElement reportRunDate;

    @FindBy ( css = "dl.detail-row.info dt" )
    List<WebElement> reportInfoText;

    @FindBy ( css = "dl.detail-row.info dd" )
    List<WebElement> reportInfovalues;

    //For verifying the decimal & other patterns in report output page
    public Pattern decimal = Pattern.compile( "\\d{1}.\\d{2}" );
    public Pattern timeFormat = Pattern.compile( "\\d{2}:\\d{2}" );

    @FindBy ( css = "table.report-viewer-grid.perf-by-strand-math thead tr" )
    List<WebElement> Strand;

    @FindBy ( css = "#table.report-viewer-grid.perf-by-strand-math thead tr.sub-header th" )
    List<WebElement> strandsubheader;

    // ****Child Elements****
    private String button = "button.button";

    /**
     *
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */
    public StudentPerformanceOutputPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportOutputComponent = new ReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "Sudent Performance Report output Page loaded successfully." );
        } else {
            Log.fail( "Sudent Performance Report output Page not loaded successfully." );
        }

    }

    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabels() {
        Log.message( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if ( SMUtils.waitForElement( driver, headerLegend ) ) {
            Log.assertThat( SMUtils.getTextOfWebElement( headerLegend, driver ).equals( ReportsUIConstants.LEGEND_HEADER ), "Legend header is displayed successfully!!!", "Legend header is not displayed" );
            Log.assertThat( IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_SP.get( itr ) ) ), "All the labels of the legend are displayed",
                    "All the labels of the legend are not displayed" );
            Log.assertThat( IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_VALUES_SP.get( itr ) ) ),
                    "All the label values of the legend are displayed", "All the label values of the legend are not displayed" );
            isLegendLabelDisplayed = true;
        }

        return isLegendLabelDisplayed;
    }

    public boolean verifyStrandLabels() {
        Log.message( "Verifying Strand header and its labels" );
        boolean isStrandLabelDisplayed = false;
        if ( SMUtils.waitForElement( driver, Strandheader ) ) {
            Log.message( "Application value" + SMUtils.getTextOfWebElement( Strandheader, driver ) );
            Log.assertThat( SMUtils.getTextOfWebElement( Strandheader, driver ).equals( ReportsUIConstants.STRAND_HEADER ), "Performance by Strand - Cumulative header is displayed successfully!!!",
                    "Performance by Strand - Cumulative header is not displayed" );
            isStrandLabelDisplayed = true;
        }
        return isStrandLabelDisplayed;
    }

    /**
     * To get Recent Sessions Report Table page header
     * 
     * @return
     */
    public List<String> getReportTableTitle() {
        Log.message( "Getting Recent Session Report Table Title" );
        SMUtils.waitForElement( driver, endtablenotes );
        return reporttabletitle.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Recent Sessions Report Table page sub header
     * 
     * @return
     */

    public List<String> getReportTableSubTitle() {
        Log.message( "Getting Recent Session Report Table sub Title" );
        SMUtils.waitForElement( driver, endtablenotes );
        return reporttablesubtitle.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Recent Sessions Report Table page last two row
     * 
     * @return
     */

    public List<String> getLastTwoRow() {
        Log.message( "Getting the last two row of Mean - 8 Students and Standard Deviation" );
        SMUtils.waitForElement( driver, endtablenotes );
        return lasttworow.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Recent Sessions Report Table page notes
     * 
     * @return
     */

    public String getReportTableNotes() {
        Log.message( "Getting Recent Session Report Table Notes" );
        SMUtils.waitForElement( driver, endtablenotes );
        return endtablenotes.getText().trim();
    }

    public boolean getOtherPerformanceText() {
        Log.message( "Checking Other Performance Section is available in the report" );
        if ( driver.getPageSource().contains( "Other Performance" ) ) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * To get Recent Sessions Report Table page current course level row
     * 
     * @return
     */

    public List<String> getCurrentCourseLevelRow() {
        Log.message( "Getting Recent Session Report Current Course Level Row " );
        SMUtils.waitForElement( driver, endtablenotes );
        return currentcourselevelrow.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    /**
     * To get SPR output page sub header
     * 
     * @return
     */

    public List<String> getSPRPSSubTitle() {
        Log.message( "Getting Recent Session Report Table sub Title" );
        SMUtils.waitForElement( driver, performanceSummaryHeader );
        return reporttablesubtitle.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get SPR Section Headers
     * 
     * @return
     * @throws InterruptedException
     */

    public List<String> getSectionHeaders() throws InterruptedException {
        Log.message( "Getting Section Headers from SPR Report output page" );
        SMUtils.waitForSpinnertoDisapper( driver, 30 );
        SMUtils.waitForElement( driver, performanceSummaryHeader );
        return sprSectionHeaders.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get SPR Field names of Performance by Strands
     *
     * @return
     */
    public List<String> getFieldNamesPBS( String fieldname ) {
        Log.message( "Getting Field names for Performance Summary section" );
        SMUtils.waitForElement( driver, Strandheader );
        if ( Strandheader.isDisplayed() )
            Log.message( "Report Page has Performance Summary Data" );
        else
            Log.message( "Performance Summary Data isn't available for the selected Report Filters. Please change the Filter data in SPR input page and rerun the test cases" );
        if ( fieldname.equalsIgnoreCase( "Strand" ) )
            return Strand.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        else
            return strandsubheader.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    /**
     * To get SPR Field values of Performance by Strands
     *
     * @return
     */

    public List<String> getSPRPBSFieldValues( String fieldname ) {
        SMUtils.waitForElement( driver, Strandheader );
        if ( fieldname.equalsIgnoreCase( "Strand" ) )
            return Strand.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        else
            return strandsubheader.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    /**
     * To get SPR Field names
     * 
     * @return
     */

    public List<String> getFieldNamesPS() {
        Log.message( "Getting Field names for Performance Summary section" );
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        if ( pbLevelDataHeader.isDisplayed() )
            Log.message( "Report Page has Performance Summary Data" );
        else
            Log.message( "Performance Summary Data isn't available for the selected Report Filters. Please change the Filter data in SPR input page and rerun the test cases" );
        return sprRowFieldNames.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get SPR Field values
     * 
     * @return
     */

    public List<String> getSPRFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        return sprRowFieldValues.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get SPR Assigned Course Level Field value
     * 
     * @return
     */

    public String getAssignedCourseLevelFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        return getSPRFieldValues().get( 0 );
    }

    /**
     * To verify SPR Current Course Level Field value is decimal or not
     * 
     * @return
     */

    public boolean verifyCurrentCourseLevelFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String CurrentCourseLevel = getSPRFieldValues().get( 1 );
        if ( CurrentCourseLevel.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Current course level is" + CurrentCourseLevel );
        return decimal.matcher( CurrentCourseLevel ).matches();
    }

    /**
     * To verify SPR IP Level Field value is decimal or not
     * 
     * @return
     */

    public boolean verifyIPLevelFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String ipLevel = getSPRFieldValues().get( 2 );
        if ( ipLevel.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The IP level is" + ipLevel );
        return decimal.matcher( ipLevel ).matches();
    }

    /**
     * To verify SPR gain Field value is decimal or not
     * 
     * @return
     */

    public boolean verifyGainFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String gain = getSPRFieldValues().get( 3 );
        if ( gain.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The IP level is" + gain );
        return decimal.matcher( gain ).matches();
    }

    /**
     * To verify Exercises Correct Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyExercisesCorrectValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String exercisesCorrect = getSPRFieldValues().get( 4 );
        if ( exercisesCorrect.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Exercises Correct value is" + exercisesCorrect );
        try {
            int Value = Integer.parseInt( exercisesCorrect );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Exercises Attempted Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyExercisesAttemptedValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String exercisesAttempted = getSPRFieldValues().get( 5 );
        if ( exercisesAttempted.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Exercises Attempted value is" + exercisesAttempted );
        try {
            int Value = Integer.parseInt( exercisesAttempted );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Exercises Percent Correct Field value is in percentage or not
     * 
     * @return
     */

    public boolean verifyExercisesPercentCorrectValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String exercisesPercentCorrect = getSPRFieldValues().get( 6 );
        if ( exercisesPercentCorrect.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Exercises Percent Correct value is" + exercisesPercentCorrect );
        return exercisesPercentCorrect.contains( "%" );
    }

    /**
     * To verify Computation Retention Index (CRI) Field value is in percentage
     * or not
     * 
     * @return
     */

    public boolean verifyCRIValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String cri = getSPRFieldValues().get( 8 );
        if ( cri.equalsIgnoreCase( "In IP" ) || cri.equalsIgnoreCase( "NA" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The IP level is" + cri );
        return cri.contains( "%" );
    }

    /**
     * To verify Skills Mastered Field value is whole number or not
     * 
     * @return
     */

    public boolean verifySkillsMasteredValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String skillsMastered = getSPRFieldValues().get( 9 );
        if ( skillsMastered.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Skills Mastered value is" + skillsMastered );
        try {
            int Value = Integer.parseInt( skillsMastered );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Skills Assessed Field value is whole number or not
     * 
     * @return
     */

    public boolean verifySkillsAssessedValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String skillsAssessed = getSPRFieldValues().get( 10 );
        if ( skillsAssessed.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Skills Assessed value is" + skillsAssessed );
        try {
            int Value = Integer.parseInt( skillsAssessed );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Skills Percent Mastered Field value is in percentage or not
     * 
     * @return
     */

    public boolean verifySkillsPercentMasteredValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String skillsPercentMastered = getSPRFieldValues().get( 11 );
        if ( skillsPercentMastered.equalsIgnoreCase( "In IP" ) ) {
            Log.message( "The course is still In IP" );
            return true;
        } else
            Log.message( "The Skills Percent Mastered is" + skillsPercentMastered );
        return skillsPercentMastered.contains( "%" );
    }

    /**
     * To verify Help Used Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyHelpUsedValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String helpUsed = getSPRFieldValues().get( 12 );
        Log.message( "The Help Used value is" + helpUsed );
        try {
            int Value = Integer.parseInt( helpUsed );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Audio Repeats Used Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyAudioRepeatsUsedValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String audioRepeatsUsed = getSPRFieldValues().get( 13 );
        Log.message( "The Audio Repeats Used value is" + audioRepeatsUsed );
        try {
            int Value = Integer.parseInt( audioRepeatsUsed );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Report Card Views Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyReportCardViewsValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String reportCardViews = getSPRFieldValues().get( 14 );
        Log.message( "The Report Card Views value is" + reportCardViews );
        try {
            int Value = Integer.parseInt( reportCardViews );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Glossary Used Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyGlossaryUsedValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String glossaryUsed = getSPRFieldValues().get( 15 );
        Log.message( "The Glossary Used value is" + glossaryUsed );
        try {
            int Value = Integer.parseInt( glossaryUsed );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Time Spent Field value format
     * 
     * @return
     */

    public boolean verifyTimeSpentFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String timeSpent = getSPRFieldValues().get( 16 );
        Log.message( "The Time Spent is " + timeSpent );
        return timeFormat.matcher( timeSpent ).matches();
    }

    /**
     * To verify Total Sessions Field value is whole number or not
     * 
     * @return
     */

    public boolean verifyTotalSessionsValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String totalSessions = getSPRFieldValues().get( 17 );
        Log.message( "The Total Sessions value is " + totalSessions );
        try {
            int Value = Integer.parseInt( totalSessions );
            return true;
        } catch ( NumberFormatException e ) {
            Log.message( "Input String cannot be parsed to Integer." );
            return false;
        }
    }

    /**
     * To verify Average Session Time Field value format
     * 
     * @return
     */

    public boolean verifyAverageSessionTimeFieldValues() {
        SMUtils.waitForElement( driver, pbLevelDataHeader );
        String averageSessionTime = getSPRFieldValues().get( 16 );
        Log.message( "The Average Session Time is " + averageSessionTime );
        return timeFormat.matcher( averageSessionTime ).matches();
    }

    /**
     * To get Student name from Report Output Page
     * 
     * @return
     */
    public String getStudentName() {
        SMUtils.waitForElement( driver, studentName );
        String name = SMUtils.getTextOfWebElement( studentName, driver );
        Log.message( "Student Name is: " + name );
        return name;
    }

    /**
     * To get Assignment name from Report Output Page
     * 
     * @return
     */
    public String getAssignmentName() {
        SMUtils.waitForElement( driver, studentName );
        String name = SMUtils.getTextOfWebElement( assignmentName, driver );
        Log.message( "Student Name is: " + name );
        return name;
    }

    /**
     * To verify report run date from Report Output Page
     * 
     * @return
     */
    public boolean verifyReportRunDate() {
        SMUtils.waitForElement( driver, studentName );
        String name = SMUtils.getTextOfWebElement( reportRunText, driver );
        String date = SMUtils.getTextOfWebElement( reportRunDate, driver );
        Log.message( "Report Run text is present" );
        Log.message( "Report Run Date is " + date );
        return !name.isEmpty();
    }

    /**
     * To verify SPR Report Info Texts
     * 
     * @return
     */

    public boolean verifyReportInfoText() {
        SMUtils.waitForElement( driver, studentName );
        List<String> reportInfo = reportInfoText.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        return reportInfo.contains( "School:" ) && reportInfo.contains( "Teacher:" ) && reportInfo.contains( "Grade:" ) && reportInfo.contains( "Group:" );
    }

    /**
     * To get Group Value
     * 
     * @return
     */

    public String getGroupValue() {
        SMUtils.waitForElement( driver, studentName );
        List<String> reportInfo = reportInfovalues.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        return reportInfo.get( reportInfo.size() - 1 );
    }

    public List<String> getFieldNamesPS( String fieldname ) {
        Log.message( "Getting Field names for Performance Summary section" );
        SMUtils.waitForElement( driver, Strandheader );
        if ( Strandheader.isDisplayed() )
            Log.message( "Report Page has Performance Summary Data" );
        else
            Log.message( "Performance Summary Data isn't available for the selected Report Filters. Please change the Filter data in SPR input page and rerun the test cases" );
        if ( fieldname.equalsIgnoreCase( "Strand" ) )
            return Strand.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        else
            return strandsubheader.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    /**
     * To get SPR Field values
     *
     * @return
     */

    public List<String> getSPRFieldValues( String fieldname ) {
        SMUtils.waitForElement( driver, Strandheader );
        if ( fieldname.equalsIgnoreCase( "Strand" ) )
            return Strand.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        else
            return strandsubheader.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

}