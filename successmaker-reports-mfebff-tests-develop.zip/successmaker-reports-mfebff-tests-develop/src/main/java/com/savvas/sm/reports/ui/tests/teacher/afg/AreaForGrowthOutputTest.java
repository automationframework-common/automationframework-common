package com.savvas.sm.reports.ui.tests.teacher.afg;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthOutputPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.DashboardPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class AreaForGrowthOutputTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherUserName1;
    String teacherDetails;
    private String groupName;
    private String studentId;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUserName1 = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        RBSUtils rbsUtils = new RBSUtils();

    }

    @Test ( description = "Verify Areas For Growth Default Report Output Page UI Components -Math", groups = { "SMK-63410", "Areas For Growth Report", "AFG" }, priority = 1 )
    public void tcSMAreasForGrowthTest001() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            //Static Teacher User
            String username =teacherUserName1;
            Log.message( "Login in with Teacher: " + username );

            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUserName1, password );
            SMUtils.waitForSpinnertoDisapper( driver );
            AreaForGrowthPage areaForGrowthPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( areaForGrowthPage.checkReportHeader(), "Areas For Growth Report page Header is displayed in Input Page", "Areas For Growth Report page Header is not displayed  in Input Page" );

            // Load output page
            AreaForGrowthOutputPage areaForGrowthOutputPage = areaForGrowthPage.clickRunBtn();                
            Log.message( "Areas For Growth Run Report button is displayed and clicked" );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            //Validating Test cases
            SMUtils.logDescriptionTC( "Verify the header of the   Areas For Growth Report contains \" Areas For Growth \" in bold letters in the top left of the page" );
            Log.assertThat( areaForGrowthOutputPage.checkReportTitleAndFontAfterRun(), "Areas For Growth Header is displayed in report output page", "Areas For Growth Header is not displayed in report output page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Areas For Growth Report is getting loaded in a new tab when user is clicking on Run Report button in the input screen  based on selections " );
            SMUtils.logDescriptionTC( "Verify the teacher can able to view the Areas For Growth Report  in a new tab after clicking on \" Run report Button\"" );
            String currentURL = driver.getCurrentUrl();
            Log.assertThat( currentURL.contains( "requestId" ), "New tab is opened for AFG report", "New tab is not opened for AFG report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the title  of the   Areas For Growth Report  is displaying as ' report viewer '   with successmaker logo in the top left of the page" );
            Log.assertThat( areaForGrowthOutputPage.checkReportViewer(), "Report Viewer Header is displayed in report output page", "Report Viewer Header is not displayed in report output page" );
            Log.testCaseResult();
            Log.assertThat( areaForGrowthOutputPage.checkSMLogo(), "SM Logo is displayed in report output page", "SM Logo is not displayed in report output page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Date and time is getting displayed in a prescribed format under report run in the Areas For Growth Report  " );
            Log.assertThat( areaForGrowthOutputPage.validateReportRunDate(), "Report Run Date is in correct format", "Report Run Date is not in correct format" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Strand,Level & Skill description columns is getting displayed in the Areas For Growth Report" );
            Log.assertThat( areaForGrowthOutputPage.isParentColumnsdisplayed(), "Strand, Level and Skill desciption columns are getting displayed", "Strand, Level and Skill desciption columns are not getting displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the student ,Date at Risk & Targetted Lesson columns is getting displayed under the skill description column in the Areas For Growth Report  " );
            Log.assertThat( areaForGrowthOutputPage.ischildColumnsdisplayed(), "Student, Date at Risk and Targetted Lesson columns are getting displayed", "Student, Date at Risk and Targetted Lesson columns are not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Date at Risk  is getting displayed in a prescribed format under the skill description in the Areas For Growth Report " );
            Log.assertThat( areaForGrowthOutputPage.validateDateFormat(), "The Date Value is in MM/DD/YYYY Format and as expected", "The Date Value is not in MM/DD/YYYY Format" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify mutliple pages are displayed  in the report page if we have multiple students " );
            SMUtils.logDescriptionTC( "Verify Teacher is able to view the next AFG Data by clicking Next  button if we have multiple pages" );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.isNextBtnDisplayed() && areaForGrowthOutputPage.reportOutputComponent.clickNextBtn(), "Next button is displayed and clickable in AFG report viewer page",
                    "Next button is not displayed in AFG report viewer page" );

            SMUtils.logDescriptionTC( "Verify teacher is able to view the previous students AFG data by clicking Back button if we have multiple pages" );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.isBackBtnDisplayed() && areaForGrowthOutputPage.reportOutputComponent.clickBackBtn(), "Back button is displayed and clickable in AFG report viewer page",
                    "Back button is not displayed in AFG report viewer page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify teacher is able to go to respective page by entering respective page number in the box provided near to \"Go to\" text & click on enter on the keyboard   if we have multiple pages in the report generated" );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.goToPage( 3 ), "Go to Page is displayed and clickable in AFG report viewer page", "Go to Page is not displayed in AFG report viewer page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the message \" Invalid\" is displayed   in  Report page while giving page number out of the bound  in the box provided near to \"Go to\" text if we have multiple pages" );
            areaForGrowthOutputPage.reportOutputComponent.goToPage( 0 );
            Log.assertThat( areaForGrowthOutputPage.isInvalidMsgDisplayed(), "Invalid message is displayed  when giving wrong inputs in Go to Page-  AFG report viewer page",
                    "Invalid message is not displayed when giving wrong inputs in Go to Page-  AFG report viewer page!" );

            SMUtils.logDescriptionTC( "Verify teacher is able to enter only the page number within the limit specified in the box provied near to \"Go to\" text " );
            areaForGrowthOutputPage.reportOutputComponent.goToPage( 1 );
            int maxNegativeTotalPages = areaForGrowthOutputPage.totalPages() + 1;
            areaForGrowthOutputPage.reportOutputComponent.goToPage( maxNegativeTotalPages );
            Log.assertThat( areaForGrowthOutputPage.isInvalidMsgDisplayed(), "Invalid message is displayed  when giving invalid page numbers as inputs in Go to Page-  AFG report viewer page",
                    "Invalid message is not displayed when giving invalid page numbers as inputs in Go to Page-  AFG report viewer page!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the teacher getting error message as\" Required \" if no input value is given in the box provided near to \"Go to\" text " );
            Log.assertThat( areaForGrowthOutputPage.isRequiredMsgDisplayed(), "Required message is displayed when no inputs is given in Go TO Page!", "Required message is not displayed when no inputs is given in Go TO Page!!" );
            Log.testCaseResult();

            //Obselete Cases
//            SMUtils.logDescriptionTC( "Verify Teacher is able to view the pdf & csv icon in the top right page of the report page" );
//            Log.assertThat( areaForGrowthOutputPage.isPDFIconDisplayed(), "PDF Icon is displayed!", "PDF Icon is not displayed!" );
//            Log.assertThat( areaForGrowthOutputPage.isDOCIconDisplayed(), "Doc Icon is displayed!", "Doc Icon is not displayed!" );
//            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Assignment name is getting displayed in the Areas For Growth Report " );
            Log.assertThat( areaForGrowthOutputPage.isAssignmentNameDisplayed(), "Assignment Name is getting displayed successfully", "Assignment Name is not getting displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the selected options are getting displayed in a Prescribed Format in the Areas For Growth Report " );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.getSelectedOptionHeader().equals( AFGReportConstants.SELECTED_OPTION_HEADER ), "Selected Options is getting displayed successfully", "Selected Options is not getting displayed" );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.getSelectedOptionValues().containsAll( areaForGrowthOutputPage.defaultSelectedOptions() ), "Selected options is getting displayed properly",
                    "Selected options is not getting displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the total skills at risk & total students at risk  is getting displayed   in the Areas For Growth Report  " );
            Log.assertThat( areaForGrowthOutputPage.isTotalSkillsAtRiskDisplayed(), "Total Skills At Risk Displayed is getting displayed properly", "Total Skills At Risk Displayed is not getting displayed properly" );
            Log.assertThat( areaForGrowthOutputPage.isTotalStudentsAtRiskDisplayed(), "Total Students At Risk Displayed is getting displayed properly", "Total Students At Risk Displayed is not getting displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the total skills at risk pointing out the Total number of distinct skills presented in this AFG report" );
            Log.assertThat( areaForGrowthOutputPage.getSkillDescription().size() == Integer.parseInt( areaForGrowthOutputPage.getTotalSkillsCount().getText() ), "Total skills at risk displays successfully",
                    "Total skills at risk not displays successfully" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the total skills at students pointing out the Total number of distinct students presented in this AFG report." );
            Log.assertThat( new HashSet<String>( areaForGrowthOutputPage.getAllStudents() ).size() == Integer.parseInt( areaForGrowthOutputPage.getAtRiskSkillsCount().getText() ), "Total skills at student risk displays successfully",
                    "Total skills at student risk risk not displays successfully" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the LO Number , LO Description & Student (First & lastname)  is getting displayed in student column under the skill description in the Areas For Growth Report  incase of math subject" );
            Log.assertThat( areaForGrowthOutputPage.isLONumberDisplayed(), "LO number is displayed", "LO number is not displayed" );
            Log.assertThat( areaForGrowthOutputPage.getAllStudents().contains( areaForGrowthOutputPage.getAllStudents().get( 0 ) ), "Student Name is displayed", "Student Name is not displayed" );
            Log.assertThat( areaForGrowthOutputPage.getSkillDescription().contains( areaForGrowthOutputPage.getSkillDescription().get( 0 ) ), "LO Description is displayed", "LO Description is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the level pointing out the Strand level in which a specific Math LO is Not Mastered for Math subject  or Reading skill is At Risk for Reading.subject  " );
            Log.assertThat( areaForGrowthOutputPage.isLevelandStrandsDisplayed(), "Strand and Level are displayed", "Strand and Level are not displayed" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Math - Verfiy the legends are displayed in the AFG Output UI " );
            Log.assertThat( areaForGrowthOutputPage.verifyLegendHeaderAndLabelsForMath(), "Math - Legend Header and Labels are getting displayed properly", "Math - Legend Header and Labels are not getting displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the School name, Teacher Name , Grade level.& Group name is getting displayed in the Areas For Growth Report " );
            Log.assertThat( areaForGrowthOutputPage.isInfoHeaderValuesDisplaying(), "Info Header values are getting displayed", "Info Header values are not getting displayed" );
            List<String> infoHeaders = areaForGrowthOutputPage.reportOutputComponent.getInfoHeader();
            IntStream.range( 0, infoHeaders.size() ).forEach( itr -> {
                Log.assertThat( infoHeaders.get( itr ).equals( ReportsUIConstants.INFO_LABELS.get( itr ) ), infoHeaders.get( itr ) + " is displayed in the AFG report Viewer",
                        ReportsUIConstants.INFO_LABELS.get( itr ) + " is not displayed in the AFG report Viewer" );
                Log.testCaseResult();

            } );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Areas For Growth Report Output in Zero State", groups = { "SMK-63410", "Areas For Growth Report", "AFG" }, priority = 1 )
    public void tcSMAreasForGrowthTest002() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            //Static Teacher User
            String username = "teacher_k01";
            Log.message( "Login in with Teacher: " + username );

            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(username, password);
            SMUtils.waitForSpinnertoDisapper( driver );
            AreaForGrowthPage areaForGrowthPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( areaForGrowthPage.checkReportHeader(), "Areas For Growth Report page Header is displayed in Input Page", "Areas For Growth Report page Header is not displayed  in Input Page" );

            // Load output page
            AreaForGrowthOutputPage areaForGrowthOutputPage = areaForGrowthPage.clickRunBtn();
            Log.message( "Areas For Growth Run Report button is displayed and clicked" );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            int totalNoOfPages = areaForGrowthOutputPage.totalPages();
            Log.message( "Total no of pages: " + totalNoOfPages );

            if ( totalNoOfPages == 1 ) {

                //Validating Test cases
                SMUtils.logDescriptionTC( "Verfiy the background color of the back button is white and the Background color of Next button is Grey color when the report consist of single page only" );
                Log.assertThat( areaForGrowthOutputPage.checkColorOfBackButton(), "Background color of the Back Button is matched successfully", "Background color of the Back Button is not matched successfully" );
                Log.assertThat( areaForGrowthOutputPage.checkColorOfNextButton(), "Background color of the Next Button is matched successfully", "Background color of the Next Button is not matched successfully" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Verify the Back button is in disabled state when report consist of single page only" );
                Log.assertThat( !( areaForGrowthOutputPage.isBackButtonDisabled() ), "Back button is not clickable, Test passed successfully", "Back button is  clickable, Test Failed " );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Verify the Next button is in disabled state when report consist of single page only" );
                Log.assertThat( !( areaForGrowthOutputPage.isNextButtonDisabled() ), "Next button is not clickable, Test passed successfully", "Next button is  clickable, Test Failed " );
                Log.testCaseResult();

                if ( areaForGrowthOutputPage.getZeroStateMessage().equalsIgnoreCase( AFGReportConstants.ZERO_STATE_MESSAGE ) ) {
                    SMUtils.logDescriptionTC( "Verfiy the Message \"No data  to show\"  is displayed in the AFG Report if no data present for the particular selection  in the input screen under AFG Sub tab" );
                    Log.assertThat( areaForGrowthOutputPage.getZeroStateMessage().equalsIgnoreCase( AFGReportConstants.ZERO_STATE_MESSAGE ), "Zero State Message matches successfully", "Zero State Message not matches successfully" );
                    Log.testCaseResult();
                }

            } else {
                Log.message( "Report has some data! (or) Report data not loaded properly!!" );

            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Targetted Lessons Link is openieng in new tab", groups = { "SMK-63410", "Areas For Growth Report", "AFG" }, priority = 1 )
    public void tcSMAreasForGrowthTest003() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            //Static Teacher User
            String username = "teacher_d12";
            Log.message( "Login in with Teacher: " + username );

            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(username, password);
            SMUtils.waitForSpinnertoDisapper( driver );
            AreaForGrowthPage areaForGrowthPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( areaForGrowthPage.checkReportHeader(), "Areas For Growth Report page Header is displayed in Input Page", "Areas For Growth Report page Header is not displayed  in Input Page" );

            // Load output page
            AreaForGrowthOutputPage areaForGrowthOutputPage = areaForGrowthPage.clickRunBtn();
            Log.message( "Areas For Growth Run Report button is displayed and clicked" );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            //Validating Test cases
            SMUtils.logDescriptionTC( "Reading  - Verfiy the legends are displayed in the AFG Output UI " );
            Log.assertThat( areaForGrowthOutputPage.verifyLegendHeaderAndLabelsForReading(), "Legend header and values are displayed as expected for Reading subject", "Legend header and values are not displayed as expected for Reading subject" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Targetted Lesson column content is getting displayed as a link under the skill description column in the Areas For Growth Report if available" );
            SMUtils.logDescriptionTC( "Verify the teacher can click the Targetted Lesson column content file name link to open the PDF in a new browser tab for that lesson." );
            SMUtils.logDescriptionTC( "Verify the teacher can open the Targetted Lesson column content file as PDF in a new browser tab for that lesson after clicking the link ." );
            areaForGrowthOutputPage.reportOutputComponent.isNextBtnDisplayed();
            areaForGrowthOutputPage.reportOutputComponent.clickNextBtn();
            boolean isTargettedLessonHasValues = areaForGrowthOutputPage.validateTargettedLesson();
            if ( isTargettedLessonHasValues == true ) {
                SMUtils.switchWindow( driver );
                SMUtils.waitForPageLoad( driver );
                SMUtils.waitForSpinnertoDisapper( driver );
                String currentURL = driver.getCurrentUrl();
                Log.assertThat( currentURL.contains( "pdf" ), "PDF File is opened for AFG report", "PDF File is not opened for AFG report" );
                Log.testCaseResult();

            } else {
                Log.message( "No Targetted Lesson Link values found" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Areas For Growth Default Report Output Page UI Components -Reading", groups = { "SMK-63410", "Areas For Growth Report", "AFG" }, priority = 1 )
    public void tcSMAreasForGrowthTest004() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            //Static Teacher User
            String username = "teacher_d12";
            Log.message( "Login in with Teacher: " + username );

            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(username, password);
            SMUtils.waitForSpinnertoDisapper( driver );
            AreaForGrowthPage areaForGrowthPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( areaForGrowthPage.checkReportHeader(), "Areas For Growth Report page Header is displayed in Input Page", "Areas For Growth Report page Header is not displayed  in Input Page" );

            // Input Filters
            boolean subjectDropdown = areaForGrowthPage.reportFilterComponent.isSingleSelectDropDownDisplayed( AFGReportConstants.AFG_SUBJECT_LABEL );
            Log.message( "Is dropdown displayed: " + subjectDropdown );

            areaForGrowthPage.reportFilterComponent.isSingleSelectDropdownExpanded( AFGReportConstants.AFG_SUBJECT_LABEL );
            areaForGrowthPage.reportFilterComponent.isSingleSelectDropdownCollapsed( AFGReportConstants.AFG_SUBJECT_LABEL );

            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( AFGReportConstants.AFG_SUBJECT_LABEL, AFGReportConstants.READING );

            //Optional Filters 
            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( AFGReportConstants.AFG_ADD_GROUPING_LABEL, AFGReportConstants.GROUP );

            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( AFGReportConstants.AFG_DISPLAY_LABEL, AFGReportConstants.STUDENT_USERNAME );

            areaForGrowthPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( AFGReportConstants.AFG_SORT_LABEL, AFGReportConstants.LEVEL );

            //Load output page
            AreaForGrowthOutputPage areaForGrowthOutputPage = areaForGrowthPage.clickRunBtn();
            Log.message( "Areas For Growth Run Report button is displayed and clicked" );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            //Validating Test cases
            SMUtils.logDescriptionTC( "Reading  - Verfiy the legends are displayed in the AFG Output UI " );
            Log.assertThat( areaForGrowthOutputPage.verifyLegendHeaderAndLabelsForReading(), "Legend header and values are displayed as expected for Reading subject", "Legend header and values are not displayed as expected for Reading subject" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the LO Description & Student (First & lastname)  is getting displayed in student column under the skill description in the Areas For Growth Report  incase of Reading subject" );
            Log.assertThat( areaForGrowthOutputPage.getAllStudents().contains( areaForGrowthOutputPage.getAllStudents().get( 0 ) ), "Student Name is displayed", "Student Name is not displayed" );
            Log.assertThat( areaForGrowthOutputPage.getSkillDescription().contains( areaForGrowthOutputPage.getSkillDescription().get( 0 ) ), "LO Description is displayed", "LO Description is not displayed" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify only the options selected in the input screen under  Areas For Growth subtab is getting displayed in the  Areas For Growth report  " );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.getSelectedOptionHeader().equals( AFGReportConstants.SELECTED_OPTION_HEADER ), "Selected Options is getting displayed successfully", "Selected Options is not getting displayed" );
            Log.assertThat( areaForGrowthOutputPage.reportOutputComponent.getSelectedOptionValues().containsAll( areaForGrowthOutputPage.actualSelectedOptions() ), "Selected options is getting displayed properly",
                    "Selected options is not getting displayed properly" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
