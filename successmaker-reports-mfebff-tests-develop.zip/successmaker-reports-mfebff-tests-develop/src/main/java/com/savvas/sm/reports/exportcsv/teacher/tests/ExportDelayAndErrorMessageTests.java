package com.savvas.sm.reports.exportcsv.teacher.tests;

import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v101.network.model.ConnectionType;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.StudentPerformanceOutputPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

public class ExportDelayAndErrorMessageTests extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String reportBFF;
    private String endPoint;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        //Hardcoding the browser version due to the version compatibility for CDP
        browser = "Windows_10_Chrome_100";
        reportBFF = configProperty.getProperty( "AdminReportBFF" );
        endPoint = "/export-csv";

        String teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        HashMap<String, String> assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );

        String studentDetail = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), username );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) ), AssignmentAPIConstants.USERS_TYPE );

        Log.assertThat( assignAssignment.get( Constants.STATUS_CODE ).equals( "200" ), "Assignment assigned properly", "Issue in assigning the assignment!!!" );

        //Initialize the driver
        final WebDriver driver = WebDriverFactory.get( browser );
        String studentUserName = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        Log.message( "Student username " + SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );

        //Login with student users and execute the course
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        studentsPage.executeMathCourse( studentUserName, "Math", "95", "1", "5" );
        studentsPage.logout();

    }

    @Test ( description = "Verify the delay message popup appears after user clicked OK button in the Export Data popup", groups = { "smoke_test_case", "SMK-67461", "exportDelayAndErrorMessage", "exportCsv" }, priority = 1 )
    public void exportDelayAndErrorMessageTest001() throws Exception {

        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the delay message popup appears after user clicked OK button in the Export Data popup" + browser + "]</b></i></small>" );
        try {

            //Login with teacher usernmae
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher( username, password );

            //Navigating to student performance Report input page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            //To click the Run Report Button
            StudentPerformanceOutputPage studentPerformanceOutputPage = studentPerformancePage.clickRunReport();

            //To Click the Export csv button
            ExportPopupComponent exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();

            String responseJson = DevToolsUtils.readJsonResponse( "actualResponse_SMK-67461.txt" );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To click the ok button in the Export CSV popup.
            exportPopup.clickOkButton();

            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest001 : Verify the delay message popup appears after user clicked OK button in the Export Data popup" );
            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest002 : Verify the fields available in the delay message popup" );

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //Verifying the text in the popup
            Log.assertThat( exportPopup.getDownloadingModalPopupText().replace( "\r", "" ).replace( "\n", "" ).equalsIgnoreCase( ReportsUIConstants.DELAY_POPUP_TEXT ), "Popup text is displaying properly!!!",
                    "Popup text is not displaying properly!!! Expected - " + ReportsUIConstants.DELAY_POPUP_TEXT + ". Actual - " + exportPopup.getDownloadingModalPopupText().replace( "\r", "" ).replace( "\n", "" ) );

            Log.assertThat( exportPopup.isCloseButtonDisplayedInDownloadingModalPopup(), "Close button is displaying properly!!", "Close button is not displaying properly in  the delay popup!!!" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify close button and (X) button is disable in delay message popup", groups = { "smoke_test_case", "SMK-67461", "exportDelayAndErrorMessage", "exportCsv" }, priority = 1 )
    public void exportDelayAndErrorMessageTest002() throws Exception {

        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify close button and (X) button is disable in delay message popup" + browser + "]</b></i></small>" );
        try {

            //Login with teacher usernmae
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher( username, password );

            //Navigating to student performance Report input page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            //To click the Run Report Button
            StudentPerformanceOutputPage studentPerformanceOutputPage = studentPerformancePage.clickRunReport();

            //To Click the Export csv button
            ExportPopupComponent exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();

            //Reduce the network speed to 2G
            DevTools devTool = DevToolsUtils.throttleNetwork( driver, ConnectionType.CELLULAR2G );

            //To click the ok button in the Export CSV popup.
            exportPopup.clickOkButton();

            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest003 : Verify close button and (X) button is disable in delay message popup" );
            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest004 : Verify the spinner is loading in the delay message popup" );

            Log.assertThat( !exportPopup.isCloseButtonEnabledInDownloadingModalPopup(), "Close button is disabled while the Spinner is loading!!!", "Close button is enabled while the Spinner is loading!!!" );
            Log.assertThat( !exportPopup.isCloseIconEnabledInDownloadingModalPopup(), "Close Icon is disabled while the Spinner is loading!!!", "Close Icon is enabled while the Spinner is loading!!!" );

            DevToolsUtils.closeMock( devTool );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the success  message popup after CSV file generating is completed", groups = { "smoke_test_case", "SMK-67461", "exportDelayAndErrorMessage", "exportCsv" }, priority = 1 )
    public void exportDelayAndErrorMessageTest003() throws Exception {

        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the success  message popup after CSV file generating is completed" + browser + "]</b></i></small>" );
        try {

            //Login with teacher usernmae
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher( username, password );

            //Navigating to student performance Report input page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            //To click the Run Report Button
            StudentPerformanceOutputPage studentPerformanceOutputPage = studentPerformancePage.clickRunReport();

            //To Click the Export csv button
            ExportPopupComponent exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();

            String responseJson = DevToolsUtils.readJsonResponse( "actualResponse_SMK-67461.txt" );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 200, responseJson );

            //To click the ok button in the Export CSV popup.
            exportPopup.clickOkButton();

            //Waiting for file download to complete
            SMUtils.waitForSpinnertoDisapper( driver, 50 );

            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest005 : Verify the success  message popup after CSV file generating is completed" );
            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest006 :Verify the fields available in the success  message popup" );

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //Verifying the text in the popup
            Log.assertThat( exportPopup.getDownloadingModalPopupText().replace( "\r", "" ).replace( "\n", "" ).equalsIgnoreCase( ReportsUIConstants.DELAY_POPUP_TEXT ), "Popup text is displaying properly!!!",
                    "Popup text is not displaying properly!!! Expected - " + ReportsUIConstants.DELAY_POPUP_TEXT + ". Actual - " + exportPopup.getDownloadingModalPopupText().replace( "\r", "" ).replace( "\n", "" ) );

            Log.assertThat( exportPopup.isCloseButtonDisplayedInDownloadingModalPopup(), "Close button is displaying properly!!", "Close button is not displaying properly in  the delay popup!!!" );

            DevToolsUtils.closeMock( devTool );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest007 : Verify user can click the close button in success message popup" );

            //To click the close button in downloading modal popup
            exportPopup.clickCloseButtonInDownloadingModalPopup();

            Log.assertThat( !exportPopup.isCloseButtonDisplayedInDownloadingModalPopup(), "Delay modal poup closed properly after clicked the close button", "Delay modal poup not closed properly after clicked the close button" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify error message popup when CSV file failed to generate and download", groups = { "smoke_test_case", "SMK-67461", "exportDelayAndErrorMessage", "exportCsv" }, priority = 1 )
    public void exportDelayAndErrorMessageTest004() throws Exception {

        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify error message popup when CSV file failed to generate and download" + browser + "]</b></i></small>" );
        try {

            //Login with teacher usernmae
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher( username, password );

            //Navigating to student performance Report input page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            //To click the Run Report Button
            StudentPerformanceOutputPage studentPerformanceOutputPage = studentPerformancePage.clickRunReport();

            //To Click the Export csv button
            ExportPopupComponent exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();

            //Intercept the response with Unauthorized
            String responseJson = DevToolsUtils.readJsonResponse( "unauthorizedMock_SMK-67461.json" );
            DevTools devTool = DevToolsUtils.setResponse( driver, reportBFF + endPoint, "post", 401, responseJson );

            //To click the ok button in the Export CSV popup.
            exportPopup.clickOkButton();

            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest008 : Verify error message popup when CSV file failed to generate and download" );
            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest009 : Verify the fields available in the error message popup" );

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getErrorModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.DOWNLOAD_ERROR ), "Error message popup loaded properly", "Error message popup not loaded properly" );

            //Verifying the text in the popup
            Log.assertThat( exportPopup.getErrorModalPopupText().replace( "\r", "" ).replace( "\n", "" ).equalsIgnoreCase( ReportsUIConstants.ERROR_POPUP_TEXT ), "Error modal popup text is displaying properly!!!",
                    "Error Popup text is not displaying properly!!! Expected - " + ReportsUIConstants.DELAY_POPUP_TEXT + ". Actual - " + exportPopup.getErrorModalPopupText() );

            Log.assertThat( exportPopup.isCloseButtonDisplayedInErrorModalPopup(), "Close button is displaying properly in error modal popup!!", "Close button is not displaying properly in  the error modal popup!!!" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc_ExportDelayAndErrorMessageTest010 : Verify user can click the close button in error message popup" );

            //To click the close button in downloading modal popup
            exportPopup.clickCloseButtonInErrorModalPopup();

            Log.assertThat( !exportPopup.isCloseButtonDisplayedInErrorModalPopup(), "Delay modal poup closed properly after clicked the close button", "Delay modal poup not closed properly after clicked the close button" );

            DevToolsUtils.closeMock( devTool );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
