package com.savvas.sm.reports.api.tests;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.JsonUtil;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants.SPReportConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.ReportConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;

public class GetSPReportMockOutputTest extends EnvProperties {

    private Response response;
    private String password;
    String teacherDetails;
    String studentDetails;
    String teacherUsername;
    String studentId;
    String expectedJson;
    String keyValueFromActualResponse;
    String keyValueFromExpectedJSON;

    @BeforeClass
    public void initTest() throws Exception {

        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername );
        studentId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
    }

    /**
     * This method is used to test the Get - Demographics List BFF (positive
     * scenarios)
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "getSPReportDataPositiveScenario", groups = { "getSPReportDataBff", "SMK-57951", "P1", "API","SmokeTest" } )
    public void getSPReportDataPositiveScenarios( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> reportDetails = new HashMap<>();
        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );

        switch ( scenario ) {
            case "VALID":
                reportDetails.put( SPReportConstants.STUDENT_ID, studentId );
                reportDetails.put( SPReportConstants.SUBJECT, SPReportConstants.MATH );
                response = getSPReportData( headers, reportDetails );

                Log.message( response.toString() );
                Log.message( response.getBody().asString() );

                //data Validation
                Log.testCaseInfo( "Verify studentId value is displayed in the response for a valid user details" );
                verifyResponseFields( SPReportConstants.STUDENT_ID );
                Log.testCaseInfo( "Verify studentName value is displayed in the response for a valid user details" );
                verifyResponseFields( SPReportConstants.STUDENT_NAME );
                Log.testCaseInfo( "Verify Course Details are displayed in the response for a valid user details" );
                verifyResponseFields( SPReportConstants.COURSES );
                //schema validation
                VerifySchema( CommonAPIConstants.STATUS_CODE_OK, response );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }
        Log.message( response.getBody().asString() );

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + "is not Verified" );

        Log.testCaseResult();

    }

    @DataProvider ( name = "getSPReportDataPositiveScenario" )
    public Object[][] getSPReportDataPositiveScenario() {

        Object[][] inputData = { { "tc_getSPReportData001", "getSPReportData - Verify the status code 200 with respected values are retrieved for District Admin user", "VALID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_getSPReportData002", "getSPReportData - Verify the status code 200 with respected values are retrieved for Sub-district Admin user", "VALID", CommonAPIConstants.STATUS_CODE_OK, Admins.SUBDISTRICTWITHSCHOOL_ADMIN },
                { "tc_getSPReportData003", "getSPReportData - Verify the status code 200 with respected values are retrieved for School Admin user", "VALID", CommonAPIConstants.STATUS_CODE_OK, Admins.SCHOOL_ADMIN }, };

        return inputData;
    }

    @Test ( priority = 2, dataProvider = "getSPReportDataNegativeScenario", groups = { "getSPReportDataBff", "SMK-57951", "P1", "API" } )
    public void getSPReportDataNegativeScenarios( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + " : " + description );

        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        HashMap<String, String> reportDetails = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenario ) {
            case "SAVVAS_ADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                reportDetails.put( SPReportConstants.STUDENT_ID, studentId );
                reportDetails.put( SPReportConstants.SUBJECT, SPReportConstants.MATH );
                response = getSPReportData( headers, reportDetails );
                break;

            case "TEACHER_CREDENTIAL":
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( teacherUsername, password ) );
                reportDetails.put( SPReportConstants.STUDENT_ID, studentId );
                reportDetails.put( SPReportConstants.SUBJECT, SPReportConstants.MATH );
                response = getSPReportData( headers, reportDetails );
                break;

            case "STUDENT_CREDENTIAL":
                String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, "userName" ), password ) );
                reportDetails.put( SPReportConstants.STUDENT_ID, studentId );
                reportDetails.put( SPReportConstants.SUBJECT, SPReportConstants.MATH );
                response = getSPReportData( headers, reportDetails );
                break;

            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token + "invalid" );
                reportDetails.put( SPReportConstants.STUDENT_ID, studentId );
                reportDetails.put( SPReportConstants.SUBJECT, SPReportConstants.MATH );
                response = getSPReportData( headers, reportDetails );
                break;

            case "EMPTY_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER );
                reportDetails.put( SPReportConstants.STUDENT_ID, studentId );
                reportDetails.put( SPReportConstants.SUBJECT, SPReportConstants.MATH );
                response = getSPReportData( headers, reportDetails );
                break;

            case "INVALID_DATA_TYPE":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                String query = SPReportConstants.GET_SPREPORTS_OUTPUT_PAYLOAD;
                query = query.replace( "\\\"" + SPReportConstants.STUDENT_ID_VALUE + "\\\"", studentId );
                query = query.replace( SPReportConstants.SUBJECT_VALUE, SPReportConstants.MATH );
                query = query.replace( SPReportConstants.LANGUAGE_VALUE, SPReportConstants.ENGLISH );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportConstants.REPORT_BFF, headers, query, ReportConstants.GRAPHQL_ENDPOINT );

                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        // Verifying Status code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        // Verifying message from response
        if ( scenario.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenario.equalsIgnoreCase( "SAVVAS_ADMIN" ) || scenario.equalsIgnoreCase( "STUDENT_CREDENTIAL" ) || scenario.equalsIgnoreCase( "TEACHER_CREDENTIAL" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( ReportsAPIConstants.INVALID_AUTHENTICATION_MESSAGE ), "Getting Access Denied message for " + scenario, "Not getting Access Denied message for " + scenario );
        }
    }

    @DataProvider ( name = "getSPReportDataNegativeScenario" )
    public Object[][] getSPReportDataNegativeScenario() {

        Object[][] inputData = {

                { "tc_getSPReportData004", "getSPReportData - Verify the status code 200 for savvas admin user (Access denied error)", "SAVVAS_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.SAVVAS_ADMIN },
                { "tc_getSPReportData005", "getSPReportData - Verify the status code 200 for teacher user (Access denied error)", "TEACHER_CREDENTIAL", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_getSPReportData006", "getSPReportData - Verify the status code 200 for student user (Access denied error)", "STUDENT_CREDENTIAL", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_getSPReportData007", "getSPReportData - Verify the status code 401 and UNAUTHORIZED error message when invalid bearer token is passed in header", "INVALID_BEARER_TOKEN", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_getSPReportData008", "getSPReportData - Verify the status code 401 and UNAUTHORIZED error message when no bearer token is passed in header", "EMPTY_BEARER_TOKEN", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_getSPReportData009", "getSPReportData - Verify the status code 400 Bad Request with BAD_USER_INPUT when non-String value is given as an input", "INVALID_DATA_TYPE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST,
                        Admins.DISTRICT_ADMIN }, };
        return inputData;
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    public void verifyResponseFields( String fieldName ) throws IOException {
        String basePath = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "spReportMockOutput.json";
        expectedJson = SMUtils.convertFileToString( basePath );
        keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getSPReportData" ), fieldName );
        keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( expectedJson, "data" ), "getSPReportData" ), fieldName );
        Log.assertThat( keyValueFromExpectedJSON.equals( keyValueFromActualResponse ), fieldName + " is fetched properly", fieldName + " is not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
    }
    
   
    /**
     * It will verify the schema
     * 
     * @param StatusCode
     * 
     * @param response
     */
    public void VerifySchema( String StatusCode, Response response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( SPReportConstants.GET_SP_REPORT_OUTPUT_SCHEMA, StatusCode, response.getBody().asString() );
            Log.assertThat( isValid, "The schema is valid", "The schema is not valid" );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }


    /**
     * BFF - To Get Student performance report output data
     * 
     * @param headers
     * @param reportDetails
     * @return
     */
    public Response getSPReportData( Map<String, String> headers, HashMap<String, String> reportDetails ) {
        String query = SPReportConstants.GET_SPREPORTS_OUTPUT_PAYLOAD;
        query = query.replace( SPReportConstants.STUDENT_ID_VALUE, reportDetails.get( SPReportConstants.STUDENT_ID ) );
        query = query.replace( SPReportConstants.SUBJECT_VALUE, reportDetails.get( SPReportConstants.SUBJECT ) );
        query = query.replace( SPReportConstants.LANGUAGE_VALUE, SPReportConstants.ENGLISH );
        return RestAssuredAPIUtil.POSTGraphQl( ReportConstants.REPORT_BFF, headers, query, ReportConstants.GRAPHQL_ENDPOINT );
    }

}
