package com.savvas.sm.reports.bff.admin.tests;

import com.learningservices.utils.Log;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.PSRConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import static org.hamcrest.Matchers.*;

@Listeners
public class PSARAdminBFFTestGraphQL extends UserAPI {

    String subject;
    List<String> assignmentIds;
    String orgId;
    List<String> teacherIdList;
    List<String> groupIdList;
    List<Float> targetLevelArray;
    String targetDate;
    int additionalGrouping;
    LocalDate date;
    Response responsePSAR;

    private String districtAdmin;
    private String subDistrictAdmin;
    private String schoolAdmin;
    private String mathId;
    private String mathIdIPON;
    private String mathIPOff;
    private String readingId;
    private String readingIdIPON;
    private String readingIdIPOff;
    private String selectedSchoolId;
    String firstTeacherUserName;
    String studentId;
    List<String> teachersId;
    String teacherID;
    HashMap<String, Object> eachPerfomanceDataPSAR;
    Map<String, Object> eachPerfomanceDataPSR;
    Object currentCourseLevel;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        mathId = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

        mathIdIPON = ReportData.mathSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

        mathIPOff = ReportData.mathSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

        readingId = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

        readingIdIPON = ReportData.readingSettingIPMONAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
        readingIdIPOff = ReportData.readingSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

        districtAdmin = ReportData.districtAdmin;
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        subDistrictAdmin = ReportData.subDistrictAdmin;
        schoolAdmin = ReportData.schoolAdmin;
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray();
        //getStudentId();
    }

    @Test ( dataProvider = "statusValidationData", groups = { "SMK - GraphQL API for PSAR report Admin Status Code Validation", "API", "smoke_test_case", "P1", "Admin PSAR Report Graphql" }, priority = 1 )
    public void getAdminPSAR_report( String tcId, String subjectType, List<String> assignmentIds, String adminUsername, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( tcId );
        HashMap<String, String> headers = new HashMap<>();
        String adminDetails = new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUsername ) );
        JsonPath jsonPathEvaluator = new JsonPath( adminDetails );
        String adminId = jsonPathEvaluator.getString( Constants.USERID );
        String adminOrgId = jsonPathEvaluator.getString( "affiliationInfo[0]." + Constants.ORGANIZATION_ID );

        // Input
        targetLevelArray = new ArrayList<>( Arrays.asList( 2f, 4f, 4f, 4f, 6f, 6f, 7f, 8f, 8.95f, 8.95f, 8.95f, 8.95f, 8.95f ) );

        //Setting date for past 45 days
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
        date = LocalDate.now().plusDays( 45 );
        targetDate = formatter.format( date );

        subject = subjectType;

        teacherIdList = new ArrayList<>( Arrays.asList() );
        groupIdList = new ArrayList<>( Arrays.asList() );
        additionalGrouping = PSRConstants.GROUP_BY_GRADE;

        try {
            if ( scenario.equalsIgnoreCase( "positive" ) ) {

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( adminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, adminId );
                headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            } else if ( scenario.equalsIgnoreCase( "Negative INVALID_ACCESS_TOKEN" ) ) {

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( adminUsername + "INVALID", RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, adminId );
                headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            }

            String payloadPSAR = getBody( selectedSchoolId, subject, assignmentIds, targetDate, targetLevelArray );

            Log.message( "Headers :" + headers );
            Log.message( "Payload : " + payloadPSAR );

            responsePSAR = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payloadPSAR, ReportAPIConstants.GRAPH_QL_ENDPOINT );
            if ( responsePSAR.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || responsePSAR.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                    || responsePSAR.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || responsePSAR.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                for ( int i = 0; i < 5; i++ ) {
                    responsePSAR = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payloadPSAR, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                    if ( !( responsePSAR.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || responsePSAR.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || responsePSAR.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || responsePSAR.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                        break;
                    }
                    Thread.sleep( 5000 );
                }

            }
            Log.message( "\n The respone is " + "\n" + responsePSAR.getBody().asString() );

            // Verifying Status Code
            Log.assertThat( responsePSAR.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + responsePSAR.getStatusCode() + "is the same as expected status code " + statusCode,
                    "The actual status code " + responsePSAR.getStatusCode() + "is not the same as expected status code " + statusCode );

            if ( scenario.contains( "INVALID_ACCESS_TOKEN" ) ) {
                Log.assertThat( responsePSAR.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message displayed as expected",
                        ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message not displayed as expected" );
            }
            if ( scenario.equalsIgnoreCase( "positive" ) ) {
                if ( !responsePSAR.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                    Log.assertThat( new SchemaValidation().isSchemaValid( "PSAR_Admin_Schema", statusCode, responsePSAR.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                } else {
                    Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, responsePSAR.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                }
            }

        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( responsePSAR, "PSAR" );
        }

        Log.testCaseResult();

    }

    @Test ( dataProvider = "dbValidationData", groups = { "SMK - GraphQL API for PSAR report Admin DB Validation ", "P2", "Negative", "Admin PSAR Report Graphql" }, priority = 1 )
    public void getAdminPSAR_report_DBValidation( String tcId, String subjectType, List<String> assignmentIds, String adminUsername, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( tcId );
        HashMap<String, String> headers = new HashMap<>();
        String adminDetails = new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUsername ) );
        JsonPath jsonPathEvaluator = new JsonPath( adminDetails );
        String adminId = jsonPathEvaluator.getString( Constants.USERID );
        String adminOrgId = jsonPathEvaluator.getString( "affiliationInfo[0]." + Constants.ORGANIZATION_ID );

        // Input
        targetLevelArray = new ArrayList<>( Arrays.asList( 2f, 4f, 4f, 4f, 6f, 6f, 7f, 8f, 8.95f, 8.95f, 8.95f, 8.95f, 8.95f ) );

        //Setting date for pst 45 days
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
        date = LocalDate.now().plusDays( 45 );
        targetDate = formatter.format( date );

        subject = subjectType;

        teacherIdList = new ArrayList<>( Arrays.asList() );
        groupIdList = new ArrayList<>( Arrays.asList() );
        additionalGrouping = PSRConstants.GROUP_BY_GRADE;

        if ( scenario.equalsIgnoreCase( "positive" ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( adminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.USERID_SM_HEADER, adminId );
            headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        } else if ( scenario.equalsIgnoreCase( "Negative INVALID_ACCESS_TOKEN" ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( adminUsername + "INVALID", RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.USERID_SM_HEADER, adminId );
            headers.put( Constants.ORGID_SM_HEADER, adminOrgId );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        }

        String payloadPSAR = getBody( selectedSchoolId, subject, assignmentIds, targetDate, targetLevelArray );

        Response responsePSAR = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payloadPSAR, ReportAPIConstants.GRAPH_QL_ENDPOINT );

        Log.message( "\n The respone is " + "\n" + responsePSAR.getBody().asString() );

        String payloadPSR = getBody( selectedSchoolId, subject, assignmentIds, targetDate, targetLevelArray, teachersId, groupIdList, additionalGrouping );
        Response responsePSR = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payloadPSR, ReportAPIConstants.GRAPH_QL_ENDPOINT );
        Log.message( "\n The respone is " + "\n" + responsePSR.getBody().asString() );

        //get response values

        actualValues( responsePSAR );
        actualValuesPSR( responsePSR );

        // Verifying Status Code
        Log.assertThat( responsePSAR.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + responsePSAR.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + responsePSAR.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.contains( "INVALID_ACCESS_TOKEN" ) ) {
            Log.assertThat( responsePSAR.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message not displayed as expected" );
        }

        if ( statusCode.equals( "200" ) && scenario.equalsIgnoreCase( "positive" ) ) {
            if ( subject.equals( PSRConstants.SUBJECT_TYPE_MATH ) ) {
                System.out.println( "Math DB part" );
                dbVerificaionMath( actualValues( responsePSAR ), actualValuesPSR( responsePSR ) );

            } else {
                System.out.println( "Reading DB part" );
                dbVerificaionRead( actualValues( responsePSAR ) );
            }

        }

        Log.testCaseResult();

    }

    @DataProvider
    public Object[][] statusValidationData() {
        return new Object[][] { { "TC-01 Verify the PSAR Output Screen for Output Screen for District Admin", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathId ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-02 Verify the PSAR Output Screen for Output Screen for Sub District Admin", PSRConstants.SUBJECT_TYPE_READING, Arrays.asList( readingId ), subDistrictAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-03 Verify the PSAR Output Screen for Output Screen for School Admin", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathId ), schoolAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-04 Verify the PSAR Output Screen for Math IP On course", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathIdIPON ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-05 Verify the PSAR Output Screen for Math IP OFF course", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathIPOff ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-06 Verify the PSAR Output Screen for Reading IP ON course ", PSRConstants.SUBJECT_TYPE_READING, Arrays.asList( readingIdIPON ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-07 Verify the PSAR Output Screen for Reading IP off course", PSRConstants.SUBJECT_TYPE_READING, Arrays.asList( readingIdIPOff ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-08 Verify the Unauthorized Negative Scenario for PSAR ", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathId ), districtAdmin, "Negative INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK }, };
    }

    @DataProvider
    public Object[][] dbValidationData() {
        return new Object[][] { { "TC-01 Verify the PSAR Output Screen for Output Screen for District Admin", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathId ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-02 Verify the PSAR Output Screen for Output Screen for Sub District Admin", PSRConstants.SUBJECT_TYPE_READING, Arrays.asList( readingId ), subDistrictAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-03 Verify the PSAR Output Screen for Output Screen for School Admin", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathId ), schoolAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-04 Verify the PSAR Output Screen for Math IP On course", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathIdIPON ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-05 Verify the PSAR Output Screen for Math IP OFF course", PSRConstants.SUBJECT_TYPE_MATH, Arrays.asList( mathIPOff ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-06 Verify the PSAR Output Screen for Reading IP ON course ", PSRConstants.SUBJECT_TYPE_READING, Arrays.asList( readingIdIPON ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK },
                { "TC-07 Verify the PSAR Output Screen for Reading IP off course", PSRConstants.SUBJECT_TYPE_READING, Arrays.asList( readingIdIPOff ), districtAdmin, "Positive", CommonAPIConstants.STATUS_CODE_OK }, };
    }

    public String getBody( String orgId, String subject, List<String> assignmentIds, String targetDate,

            List<Float> targetLevelArray ) throws IOException {

        JSONObject variableBody = new JSONObject();

        JSONObject psrResponsBody = new JSONObject();
        //        JSONArray jsonarray = new JSONArray( teacherIdList );

        psrResponsBody.put( PSRConstants.SUBJECT, subject );
        psrResponsBody.put( PSRConstants.TARGET_DATE, targetDate );
        //        psrResponsBody.put( PSRConstants.ADDITIONAL_GROUPING, additionalGrouping );

        // course list
        JSONArray courseList = new JSONArray();
        assignmentIds.stream().forEach( value -> courseList.put( value ) );
        psrResponsBody.put( PSRConstants.COURSE_LIST, courseList );

        //        // teacherList list
        //        JSONArray teacherList = new JSONArray();
        //        teacherIdList.stream().forEach( value -> teacherList.put( value ) );
        //        psrResponsBody.put( PSRConstants.FILTER_BY_TEACHER, teacherList );

        //        // group  list
        //        JSONArray groupList = new JSONArray();
        //        groupIdList.stream().forEach( value -> groupList.put( value ) );
        //        psrResponsBody.put( PSRConstants.FILTER_BY_GROUP, groupList );

        // target level list
        JSONArray targetLevel = new JSONArray();
        targetLevelArray.stream().forEach( value -> targetLevel.put( value ) );
        psrResponsBody.put( PSRConstants.TARGET_LEVEL_ARRAY, targetLevel );

        // filter by school list
        JSONArray orgJson = new JSONArray();
        new ArrayList<>( Arrays.asList( orgId ) ).stream().forEach( value -> orgJson.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_SCHOOL, orgJson );

        //        // filter by Grades
        //        psrResponsBody.put( PSRConstants.FILTER_BY_GRADE, new JSONArray() );

        JSONObject demoJSON = new JSONObject();

        demoJSON.put( PSRConstants.DISABILLITY_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.ENGLISH_LANGUGAGE_PROFICIENCY, new JSONArray() );
        demoJSON.put( PSRConstants.GENDER, new JSONArray() );
        demoJSON.put( PSRConstants.RACE, new JSONArray() );
        demoJSON.put( PSRConstants.ETHINICITY, new JSONArray() );
        demoJSON.put( PSRConstants.SOCIO_ECONOMIC_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.MIGRANT_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.SPECIAL_SERVICES, new JSONArray() );

        psrResponsBody.put( PSRConstants.DEMOGRAPHICS_INPUT, demoJSON );
        variableBody.put( PSRConstants.PRS_REPORT_REQUEST, psrResponsBody );

        Log.message( "\nGraphQL Variable:\n" + variableBody.toString() );
        String requestBody = SMUtils.convertFileToString( new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator
                + "report" + File.separator + "PSARRequestBody.json" );
        String formatted = requestBody.format( requestBody, subject, courseList.toString(), targetDate, targetLevel.toString(), orgJson.toString() );
        Log.message( "PayLoad:\n" + formatted.toString() );
        return formatted;
    }

    public Map<Object, Map<Object, Object>> actualValues( Response response ) {

        // Response Code Validation
        response.then().statusCode( 200 );

        Map<Object, Map<Object, Object>> actValues = new HashMap<Object, Map<Object, Object>>();
        teachersId = new ArrayList<String>();

        List<Object> assignments = response.then().extract().path( "data.getAdminPSAReportData.psaAssignments" );
        Log.message( "\n The Assignment Size is : " + assignments.size() );
        assignments.forEach( assignment -> {

            Map<String, Object> eachAssignment = (Map<String, Object>) assignment;
            Object report_run = eachAssignment.get( PSRConstants.REPORT_RUN );

            Object report_runs = eachAssignment.get( "teacherRows" );

            Object assignmentTitle = eachAssignment.get( PSRConstants.ASSIGNMENT_TITLE );
            Object organizationName = eachAssignment.get( PSRConstants.ORGANIZATION_NAME );

            Object grade = eachAssignment.get( PSRConstants.GRADE );

            // Verify Individually
            Map<Object, Object> eachAssignmentData = new HashMap<Object, Object>();

            eachAssignmentData.put( PSRConstants.ORGANIZATION_NAME, organizationName );

            eachAssignmentData.put( PSRConstants.ASSIGNMENT_TITLE, assignmentTitle );
            eachAssignmentData.put( PSRConstants.GRADE, grade );

            Map<Object, Object> eachStudentData = new HashMap<Object, Object>();

            List<Object> students = (List<Object>) eachAssignment.get( "teacherRows" );

            // list of object of studnet
            // each student - has each value
            List<Map<Object, Object>> teachersData = new ArrayList<Map<Object, Object>>();

            students.forEach( student -> {

                Map<String, Object> eachStudent = (Map<String, Object>) student;

                teacherID = eachStudent.get( PSRConstants.TEACHER_ID ).toString();

                Object teacherName = eachStudent.get( "teacherName" );

                Map<String, Object> teacherData = new HashMap<String, Object>();
                teacherData.put( PSRConstants.TEACHER_ID, teacherID );

                //Add teacher id 
                teachersId.add( teacherID );

                teacherData.put( "teacherName", teacherName );

                teacherData.put( PSRConstants.PERSON_ID, new RBSUtils().getUserIDByUserName( teacherName.toString() ) );

                Map<String, Object> eachPopulationData = (Map<String, Object>) eachStudent.get( "psaPopulation" );

                Object studentsIncluded = eachPopulationData.get( "studentsIncluded" );
                Object studentsNotIncluded = eachPopulationData.get( "studentsNotIncluded" );

                Map<String, Object> populationData = new HashMap<String, Object>();
                populationData.put( "studentsIncluded", studentsIncluded );
                populationData.put( "studentsNotIncluded", studentsNotIncluded );

                Map<String, Object> eachPerformanceData = (Map<String, Object>) eachStudent.get( "psaPerformanceData" );
                Object currentCourseLevelMean = eachPerformanceData.get( "currentCourseLevelMean" );
                Object ipLevelMean = eachPerformanceData.get( "ipLevelMean" );
                Object timeSinceIPMean = eachPerformanceData.get( "timeSinceIPMean" );
                Object percentStudentsWithAP = eachPerformanceData.get( "percentStudentsWithAP" );
                Object percentStudentsAtTargetLevel = eachPerformanceData.get( "percentStudentsAtTargetLevel" );

                Map<String, Object> performanceData = new HashMap<String, Object>();
                performanceData.put( "currentCourseLevelMean", currentCourseLevelMean );
                performanceData.put( "ipLevelMean", ipLevelMean );
                performanceData.put( "timeSinceIPMean", timeSinceIPMean );
                performanceData.put( "percentStudentsWithAP", percentStudentsWithAP );
                performanceData.put( "percentStudentsAtTargetLevel", percentStudentsAtTargetLevel );

                Map<String, Object> eachCurrentForecast = (Map<String, Object>) eachStudent.get( "psaCurrentForecast" );
                Object projectedEndLevelMean = eachCurrentForecast.get( "projectedEndLevelMean" );
                Object percentStudentsToAchieveTargetLevel = eachCurrentForecast.get( "percentStudentsToAchieveTargetLevel" );

                Map<String, Object> currentForecast = new HashMap<String, Object>();
                currentForecast.put( "projectedEndLevelMean", projectedEndLevelMean );
                currentForecast.put( "percentStudentsToAchieveTargetLevel", percentStudentsToAchieveTargetLevel );

                Map<String, Object> eachPrescription = (Map<String, Object>) eachStudent.get( "psaPrescription" );
                Object averageAddlMinDayToTarget = eachPrescription.get( "averageAddlMinDayToTarget" );

                Map<String, Object> prescription = new HashMap<String, Object>();
                prescription.put( "averageAddlMinDayToTarget", averageAddlMinDayToTarget );

                //Adding all Details into one Map for one studnet
                eachStudentData.put( "teacherData", teacherData );
                eachStudentData.put( "populationData", populationData );
                eachStudentData.put( PSRConstants.PERFOMANCE_DATA, performanceData );
                eachStudentData.put( PSRConstants.CURRENT_FORECAST, currentForecast );
                eachStudentData.put( PSRConstants.PRESCRIPTION, prescription );
                teachersData.add( eachStudentData );
            } );

            Map<Object, Object> oneAssignment = new HashMap<Object, Object>();

            oneAssignment.put( "assignmentData", eachAssignmentData );
            oneAssignment.put( "teachersData", teachersData );

            actValues.put( grade + "-" + teacherID, oneAssignment );

        } );

        Log.message( "\n Collected Data is:\n" + actValues.toString() );
        return actValues;
    }

    public void dbVerificaionMath( Map<Object, Map<Object, Object>> actualValues, Map<Object, Map<Object, Object>> psrActualValues ) {
        SoftAssert softAssert = new SoftAssert();

        Set<Object> keyValues = actualValues.keySet();
        Set<Object> psrKeyValues = psrActualValues.keySet();

        List<Object> psrKeyList = new ArrayList<>();
        psrKeyList.addAll( keyValues );

        List<Object> psarKeyList = new ArrayList<>();
        psarKeyList.addAll( psrKeyValues );

        for ( int i = 0; i < psrKeyList.size(); i++ ) {

            for ( int j = 0; j < psarKeyList.size(); j++ ) {
                if ( psrKeyList.get( i ).equals( psarKeyList.get( j ) ) ) {

                    eachPerfomanceDataPSAR = new HashMap<String, Object>();
                    eachPerfomanceDataPSR = new HashMap<String, Object>();

                    //PSAR
                    List<Object> studs = (List<Object>) actualValues.get( psarKeyList.get( j ) ).get( "teachersData" );

                    studs.forEach( student -> {
                        Map<String, Object> eachStudent = (Map<String, Object>) student;
                        // Perfomance data validation
                        Map<String, Object> eachPerfomanceData = (Map<String, Object>) eachStudent.get( PSRConstants.PERFOMANCE_DATA );

                        Object currentCourseLevelMean = eachPerfomanceData.get( "currentCourseLevelMean" );
                        Object ipLevelMean = eachPerfomanceData.get( "ipLevelMean" );
                        Object timeSinceIPMean = eachPerfomanceData.get( "timeSinceIPMean" );

                        eachPerfomanceDataPSAR.put( "currentCourseLevelMean", currentCourseLevelMean );
                        eachPerfomanceDataPSAR.put( "ipLevelMean", ipLevelMean );
                        eachPerfomanceDataPSAR.put( "timeSinceIPMean", timeSinceIPMean );
                    } );

                    List<Object> assignmentData = (List<Object>) psrActualValues.get( psrKeyList.get( i ) ).get( "assignmentData" );
                    assignmentData.forEach( eachAssignments -> {
                        Map<String, Object> eachAssignment = (Map<String, Object>) eachAssignments;

                        targetDate = eachAssignment.get( "targetDate" ).toString();

                    } );
                    //PSR
                    List<Object> studts = (List<Object>) psrActualValues.get( psrKeyList.get( i ) ).get( "studentsData" );

                    studts.forEach( student -> {
                        Map<String, Object> eachStudent = (Map<String, Object>) student;
                        // Perfomance data validation
                        Map<String, Object> eachPerfomanceData = (Map<String, Object>) eachStudent.get( PSRConstants.PERFOMANCE_DATA );

                        Object currentCourseLevel = eachPerfomanceData.get( PSRConstants.CURRENT_COURSE_LEVEL );
                        Object ipLevel = eachPerfomanceData.get( PSRConstants.IP_LEVEL );
                        Object timeSinceIp = eachPerfomanceData.get( PSRConstants.TIME_SINCE_IP );

                        if ( currentCourseLevel.toString().equals( "In IP" ) ) {
                            currentCourseLevel = currentCourseLevel.toString().replaceAll( "In IP", "--" );
                        }
                        eachPerfomanceDataPSR.put( "currentCourseLevelMean", currentCourseLevel );

                        if ( ipLevel.toString().equals( "In IP" ) ) {
                            ipLevel = ipLevel.toString().replace( "In IP", "--" );
                        }
                        eachPerfomanceDataPSR.put( "ipLevelMean", ipLevel );

                        if ( timeSinceIp.toString().equals( "In IP" ) ) {
                            timeSinceIp = timeSinceIp.toString().replace( "In IP", "--" );
                        }
                        eachPerfomanceDataPSR.put( "timeSinceIPMean", timeSinceIp );

                    } );

                    //softAssert.assertEquals(eachPerfomanceDataPSR, eachPerfomanceDataPSAR, "Failed to Verify Grade "+psrKeyList.get(i)+" (Teacher ID) PerfomanceData for PSAR Report");

                    Log.softAssertThat( eachPerfomanceDataPSR.equals( eachPerfomanceDataPSAR ), "Verified Grade " + psrKeyList.get( i ) + " (Teacher ID) PerfomanceData values for PSAR Report",
                            "Failed to Verify Grade " + psrKeyList.get( i ) + " (Teacher ID) Performance value for PSAR Report" );

                    if ( eachPerfomanceDataPSR.equals( eachPerfomanceDataPSAR ) ) {
                        int currentCourseLevelValue = Integer.parseInt( currentCourseLevel.toString() );
                        int targetDateValue = Integer.parseInt( targetDate.toString() );

                        int diff = currentCourseLevelValue - targetDateValue;
                        if ( diff < 3 ) {
                            Log.message( "Students are Included in PSAR Report" );
                        } else {
                            Log.message( "Students are not included in PSAR Report" );
                        }
                    }
                }

            }
        }
    }

    public String getStudentId() {
        StringBuilder studentId = new StringBuilder();
        Object[] array = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray();
        String studentIds[] = new String[array.length];
        studentId.append( '"' );
        for ( int i = 0; i < studentIds.length; i++ ) {
            if ( i < studentIds.length - 1 ) {
                studentId.append( new StringBuilder( "'" + array[i].toString() + "' ," ) );
            } else {
                studentId.append( new StringBuilder( "'" + array[i].toString() + "'" ) );
            }
        }

        studentId.append( '"' );
        System.out.println( studentId.toString() );
        return studentId.toString();
    }

    public void dbVerificaionRead( Map<Object, Map<Object, Object>> actualValues ) {
        SoftAssert softAssert = new SoftAssert();

        Set<Object> keyValues = actualValues.keySet();

        keyValues.forEach( eachAssignment -> {

            Map<Object, Object> assignmentData = (Map<Object, Object>) actualValues.get( eachAssignment ).get( "assignmentData" );

            Object assignmentTitle = assignmentData.get( PSRConstants.ASSIGNMENT_TITLE );
            Object targetLevel = assignmentData.get( PSRConstants.TARGET_LEVEL );
            Object targetDate1 = assignmentData.get( PSRConstants.TARGET_DATE );
            Object daysToTarget = assignmentData.get( PSRConstants.DAYS_TO_TARGET );
            Object organizationName = assignmentData.get( PSRConstants.ORGANIZATION_NAME );
            Object teacherID = assignmentData.get( PSRConstants.TEACHER_ID );
            Object grade = assignmentData.get( PSRConstants.GRADE );
            Log.message( "\n Verifying for the Assignment:" + assignmentTitle + "\n" );

            String assignmentuserIdQuery = "select %s from assignment_user where person_id IN (%s) and  assignment_id in (select assignment_id from assignment where assignment_title = '%s')";
            //  String assignmen_user_query = "select %s from assignment_user where assignment_user_id = %s";
            List<Object> studs = (List<Object>) actualValues.get( eachAssignment ).get( "studentsData" );

            studs.forEach( student -> {
                Map<String, Object> eachStudent = (Map<String, Object>) student;
                Map<String, Object> studentData = (Map<String, Object>) eachStudent.get( "studentData" );

                Object studentName = studentData.get( PSRConstants.STUDENT_NAME );
                Object studentUsername = studentData.get( PSRConstants.STUDENT_USERNAME );

                Log.message( "\n Verifying for Student: " + studentUsername + "\n" );

                Object ipmStatusId = studentData.get( PSRConstants.IPM_STATUS_ID );

                String studentId = new RBSUtils().getUserIDByUserName( studentUsername.toString() );
                String assignmentuserIdFormatted = assignmentuserIdQuery.format( assignmentuserIdQuery, "assignment_user_id", getStudentId(), assignmentTitle );

                Object assignment_user_id = SQLUtil.executeQuery( assignmentuserIdFormatted ).get( 0 )[0];
                String queryForAssignmentUserId = "select %s from assignment_user where assignment_user_id = " + assignment_user_id.toString();
                DecimalFormat twoDForm = new DecimalFormat( "#.00" );

                Object dbIpm_status_id = SQLUtil.executeQuery( queryForAssignmentUserId.format( queryForAssignmentUserId, "ipm_status_id" ) ).get( 0 )[0];
                Object dbipm_end_level = SQLUtil.executeQuery( queryForAssignmentUserId.format( queryForAssignmentUserId, "ipm_end_level" ) ).get( 0 )[0];

                if ( dbipm_end_level == null ) {
                    for ( int i = 0; i < 10; i++ ) {
                        try {
                            Thread.sleep( 1000 );
                            dbipm_end_level = SQLUtil.executeQuery( queryForAssignmentUserId.format( queryForAssignmentUserId, "assignment_start_level" ) ).get( 0 )[0];
                            if ( dbipm_end_level != null ) {
                                break;
                            }
                        } catch ( InterruptedException e ) {

                            //assignment_start_level
                        }
                    }
                }
                Object dbCurrent_cousre_level = SQLUtil.executeQuery( queryForAssignmentUserId.format( queryForAssignmentUserId, "assignment_current_level " ) ).get( 0 )[0];
                // if value is greater than 8.95 is set as 8.95 for calculations
                String db_ip_value = twoDForm.format( Double.parseDouble( dbipm_end_level.toString() ) );
                if ( Double.parseDouble( dbipm_end_level.toString() ) >= 8.95 ) {
                    db_ip_value = "8.95";
                }

                if ( Double.parseDouble( dbCurrent_cousre_level.toString() ) >= 8.95 ) {
                    dbCurrent_cousre_level = "8.95";
                }

                Double gain_unformated = Double.parseDouble( dbCurrent_cousre_level.toString() ) - Double.parseDouble( db_ip_value.toString() );
                String gain = twoDForm.format( gain_unformated );

                String db_current_course_level_formatted = twoDForm.format( Double.parseDouble( dbCurrent_cousre_level.toString() ) );

                // IPM Status Id validation

                // Perfomance data validation
                Map<String, Object> eachPerfomanceData = (Map<String, Object>) eachStudent.get( PSRConstants.PERFOMANCE_DATA );
                Object currentCourseLevel = eachPerfomanceData.get( PSRConstants.CURRENT_COURSE_LEVEL );
                Object ipLevel = eachPerfomanceData.get( PSRConstants.IP_LEVEL );
                Object timeSinceIp = eachPerfomanceData.get( PSRConstants.TIME_SINCE_IP );
                Object skillsPercentMastered = eachPerfomanceData.get( PSRConstants.SKILL_PERCENT_MASTERED );

                // lo completed

                String query = "select count(*) from lo_skill_history where assignment_user_id = " + assignment_user_id.toString() + " and mastery_status_id = 2";
                double db_Lo_completed = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );

                query = "select count(*) from lo_skill_history where assignment_user_id = " + assignment_user_id.toString() + " and mastery_status_id !=1";
                double db_Lo_mastered = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );

                Object db_skill_per_mastered = null;
                if ( (Double) db_Lo_completed == null ) {
                    db_skill_per_mastered = "--";
                } else if ( db_Lo_completed < 20 ) {
                    db_skill_per_mastered = "0%";
                } else {
                    db_skill_per_mastered = (int) ( ( db_Lo_mastered / db_Lo_completed ) * 100 ) + "%";
                }

                // Time since ip
                query = "SELECT total_session_min FROM read_assignment_history  WHERE assignment_user_id = " + assignment_user_id.toString();
                int total_coures_min = Integer.parseInt( ( SQLUtil.executeQuery( query ).get( 0 )[0].toString() ) );

                query = "SELECT ipm_min FROM read_assignment_history WHERE assignment_user_id = " + assignment_user_id.toString();
                int ipm_min = Integer.parseInt( ( SQLUtil.executeQuery( query ).get( 0 )[0].toString() ) );

                int time_since_ip = total_coures_min - ipm_min;

                String time_since_ip_formated = String.format( "%02d:%02d", time_since_ip / 60, time_since_ip % 60 );

                // verification
                softAssert.assertEquals( String.valueOf( ipLevel ), String.valueOf( db_ip_value ), "IPM level is mismatched" );
                softAssert.assertEquals( String.valueOf( currentCourseLevel ), String.valueOf( db_current_course_level_formatted ), "Current Course Level is mismatched" );
                softAssert.assertEquals( String.valueOf( ipmStatusId ), String.valueOf( dbIpm_status_id ), "IPM status Id" );
                softAssert.assertEquals( String.valueOf( timeSinceIp ), String.valueOf( time_since_ip_formated ), "Time Since IP is Mismatched" );
                softAssert.assertEquals( String.valueOf( skillsPercentMastered ), db_skill_per_mastered, "Skill Percent Mastered is mismatched" );

                // Current Rate validation
                Map<String, Object> eachCurrentRate = (Map<String, Object>) eachStudent.get( PSRConstants.CURRENT_RATE );
                Object sessionLength = eachCurrentRate.get( PSRConstants.SESSION_LENGTH );
                Object averageMinDay = eachCurrentRate.get( PSRConstants.AVERAGE_MIN_DAY );
                Object currentLearningRate = eachCurrentRate.get( PSRConstants.CURRENT_LEARNING_RATE );

                // Session length
                query = "SELECT value FROM auser_enrollment_option, enrollment_option WHERE auser_enrollment_option.enrollment_option_id = enrollment_option.enrollment_option_id  AND enrollment_option.option_name = 'pst.enrollment_option.session_length'   AND auser_enrollment_option.assignment_user_id ="
                        + assignment_user_id.toString();
                String ses_len = SQLUtil.executeQuery( query ).get( 0 )[0].toString();

                String dbSessionLength = String.format( "%02d:%02d", Integer.valueOf( ses_len ) / 60, Integer.valueOf( ses_len ) % 60 );

                // Average Min Per Day
                query = "(SELECT * FROM   Countbusinessdays((SELECT Date(Min(session_start_time)) FROM read_session_history WHERE  assignment_user_id = " + assignment_user_id.toString() + "), CURRENT_DATE))";
                Double school_days_since_course_started = Double.parseDouble( ( SQLUtil.executeQuery( query ).get( 0 )[0].toString() ) );

                query = "SELECT ( Trunc(( Sum(Extract(epoch FROM (session_complete_time - session_start_time)))) / 60.0)) FROM read_session_history WHERE assignment_user_id =" + assignment_user_id.toString()
                        + " AND Date(session_start_time) >= (SELECT * FROM Addbusinessdays(CURRENT_DATE, -20))";
                Double totaL_session_minutes_last_20_buisnessDays = Double.parseDouble( ( SQLUtil.executeQuery( query ).get( 0 )[0].toString() ) );

                Double db_avg_min_per_day = null;

                // school_days_since_course_started or 20 is whichever is minimum

                if ( school_days_since_course_started > 20 ) {
                    db_avg_min_per_day = ( totaL_session_minutes_last_20_buisnessDays / 20 );
                } else {
                    try {
                        if ( school_days_since_course_started <= 0 ) {
                            school_days_since_course_started = 1.00;
                        }
                    } catch ( Exception e ) {
                        school_days_since_course_started = 1.00;
                    }

                    db_avg_min_per_day = totaL_session_minutes_last_20_buisnessDays / school_days_since_course_started;
                }

                // converting into hr:mm 

                String db_avg_min_per_day_formatted = String.format( "%02d:%02d", db_avg_min_per_day.intValue() / 60, db_avg_min_per_day.intValue() % 60 );

                Double quantile = null;
                Double current_read_gain_time_min = null;

                // Currnet Learning Rate    
                if ( !( Double.parseDouble( gain ) == 0 ) ) {
                    //current_read_gain_time_min
                    query = "SELECT minutes FROM read_gain_time WHERE gain = " + gain;
                    current_read_gain_time_min = Double.parseDouble( ( SQLUtil.executeQuery( query ).get( 0 )[0].toString() ) );

                    // rate
                    Double rate = time_since_ip / current_read_gain_time_min;
                    String rate_formateed = new DecimalFormat( "#.0000" ).format( rate );

                    // Quantile 
                    if ( time_since_ip > 7 ) {
                        query = "SELECT quantile FROM read_time_multiplier  WHERE time_multiplier = (SELECT max(time_multiplier) from read_time_multiplier  WHERE time_multiplier <= " + rate_formateed + ")";
                        quantile = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );
                    } else {
                        quantile = 0.80;
                    }
                }

                Object dbcurrentLearningRate = null;
                if ( time_since_ip >= ( 7 * 60 ) ) {
                    query = "SELECT learning_rate_level FROM math_learning_rate WHERE percentile_quantile_index_low <= " + quantile + " AND percentile_quantile_index_high >= " + quantile;
                    dbcurrentLearningRate = SQLUtil.executeQuery( query ).get( 0 )[0].toString();
                } else {
                    dbcurrentLearningRate = "Baseline";
                }

                // Verification
                softAssert.assertEquals( String.valueOf( sessionLength ), String.valueOf( dbSessionLength ), "Current Learning - Session Length is mismatched" );
                softAssert.assertEquals( String.valueOf( averageMinDay ), String.valueOf( db_avg_min_per_day_formatted ), "Current Learning - Avg Min per Day is mismatched" );
                softAssert.assertEquals( String.valueOf( currentLearningRate.toString().toLowerCase() ), String.valueOf( dbcurrentLearningRate.toString().toLowerCase() ), "Current Learning rate is mistached" );

                // Current Forecast
                Map<String, Object> eachCurrentForecast = (Map<String, Object>) eachStudent.get( PSRConstants.CURRENT_FORECAST );
                Object time = eachCurrentForecast.get( PSRConstants.TIME );
                Object level = eachCurrentForecast.get( PSRConstants.LEVEL );

                // school days to target
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY/MM/dd" );
                LocalDate tempDate = LocalDate.now().plusDays( 45 );
                String newTargetDate = formatter.format( tempDate );

                query = "(SELECT * FROM Countbusinessdays(CURRENT_DATE + 1,'" + newTargetDate + "'))";

                Double school_days_to_target = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );

                // Proj addl time to end date
                Double proj_addl_time_to_end_date = school_days_to_target * db_avg_min_per_day;

                Double time_multiplier = null;

                // If Current Course Level is 8.95 he should be TOP
                if ( Double.parseDouble( dbCurrent_cousre_level.toString() ) == 8.95 ) {
                    softAssert.assertEquals( String.valueOf( "TOP" ), String.valueOf( level ), "Current Forecast - Current course level is 8.95, Current forecast level should be TOP" );

                } else {

                    // Time mulitplier
                    query = "SELECT time_multiplier FROM read_time_multiplier WHERE quantile = " + quantile;
                    time_multiplier = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );

                    // Projected Gain 1
                    Double pg1 = proj_addl_time_to_end_date / time_multiplier;
                    Double pg2 = pg1 + current_read_gain_time_min;

                    if ( pg2.toString().equalsIgnoreCase( "Infinity" ) ) {
                        pg2 = 0.00;
                    }

                    query = "SELECT Min(gain) FROM   read_gain_time WHERE  minutes = (SELECT Min(minutes) FROM   read_gain_time WHERE minutes > " + pg2 + ")";
                    Double pg3 = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );

                    // Current Forecast Level
                    Double CFL = Double.parseDouble( currentCourseLevel.toString() ) + pg3;
                    String CFL_formattted = twoDForm.format( CFL );
                    softAssert.assertEquals( String.valueOf( level ), String.valueOf( CFL_formattted ), "Current Forecast Level Mismatched" );
                }

                // hours and min

                int hours = (int) Math.floor( Math.ceil( proj_addl_time_to_end_date ) / 60 );
                int min = (int) Math.ceil( proj_addl_time_to_end_date ) % 60;

                String CFT = String.format( "%d:%02d", hours / 60, min % 60 );

                // Verification
                softAssert.assertEquals( String.valueOf( time ), String.valueOf( CFT ), "Current Forecast Time is mismatched" );

                // Presceripton
                Map<String, Object> eachPrescription = (Map<String, Object>) eachStudent.get( PSRConstants.PRESCRIPTION );
                Object addlSessionsToTarget = eachPrescription.get( PSRConstants.ADDL_SESSION_TO_TARGET );
                Object addlTimeToTarget = eachPrescription.get( PSRConstants.ADDL_TIME_TO_TARGET );
                Object addlMinDayToTarget = eachPrescription.get( PSRConstants.ADDL_MIN_DAY_TO_TARGET );

                // getting target level for the for student Grade

                Double student_target_level = null;

                if ( grade.toString().equals( "K" ) ) {
                    student_target_level = Double.valueOf( targetLevelArray.get( 0 ) );
                } else {
                    Integer gradeNumberValue = Integer.parseInt( grade.toString() );
                    student_target_level = Double.valueOf( targetLevelArray.get( gradeNumberValue ) );
                }

                if ( Double.parseDouble( db_current_course_level_formatted ) < student_target_level ) {

                    // db_addl_time_to_reach_target
                    query = "SELECT minutes FROM read_gain_time WHERE  gain = " + gain;
                    Double db_prj_read_gain_time_minutes = Double.parseDouble( SQLUtil.executeQuery( query ).get( 0 )[0].toString() );

                    Double db_addl_time_to_reach_target = ( ( db_prj_read_gain_time_minutes - current_read_gain_time_min ) * time_multiplier ) - proj_addl_time_to_end_date;

                    Double db_addl_min_To_Taraget = Math.ceil( ( Double.parseDouble( db_addl_time_to_reach_target.toString() ) - proj_addl_time_to_end_date ) / school_days_to_target );
                    Double db_addl_session_To_Target = Math.ceil( ( ( Double.parseDouble( db_addl_time_to_reach_target.toString() ) - proj_addl_time_to_end_date ) / ( school_days_to_target * 60 ) ) / Integer.parseInt( ses_len.toString() ) );

                    int total_minutes_of_addl_time_to_target = (int) Math.ceil( ( Math.ceil( db_addl_time_to_reach_target - Double.parseDouble( proj_addl_time_to_end_date.toString() ) ) / ( school_days_to_target * 60 ) ) );

                    String db_addl_time_to_target = String.format( "%02d:%02d", total_minutes_of_addl_time_to_target / 60, total_minutes_of_addl_time_to_target % 60 );

                    softAssert.assertEquals( String.valueOf( addlSessionsToTarget ), String.valueOf( db_addl_session_To_Target ), "Prescription: Addl Session To Target is mismatched" );
                    softAssert.assertEquals( String.valueOf( addlTimeToTarget ), String.valueOf( db_addl_time_to_target ), "Prescription Addl Time To Target is mismatched" );
                    softAssert.assertEquals( String.valueOf( addlMinDayToTarget ), String.valueOf( db_addl_min_To_Taraget ), "Addl MinDay To Target is mismatched " );

                } else {
                    Log.message( "(..) is showing " );
                }
                softAssert.assertAll();

            } );

        } );
    }

    public String getBody( String orgId, String subject, List<String> assignmentIds, String targetDate,

            List<Float> targetLevelArray, List<String> teacherIdList, List<String> groupIdList, int additionalGrouping ) throws IOException {

        JSONObject variableBody = new JSONObject();

        JSONObject psrResponsBody = new JSONObject();
        JSONArray jsonarray = new JSONArray( teachersId );

        psrResponsBody.put( PSRConstants.SUBJECT, subject );
        psrResponsBody.put( PSRConstants.TARGET_DATE, targetDate );
        psrResponsBody.put( PSRConstants.ADDITIONAL_GROUPING, additionalGrouping );

        // course list
        JSONArray courseList = new JSONArray();
        assignmentIds.stream().forEach( value -> courseList.put( value ) );
        psrResponsBody.put( PSRConstants.COURSE_LIST, courseList );

        // teacherList list
        JSONArray teacherList = new JSONArray();
        teacherIdList.stream().forEach( value -> teacherList.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_TEACHER, teacherList );

        // group  list
        JSONArray groupList = new JSONArray();
        groupIdList.stream().forEach( value -> groupList.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_GROUP, groupList );

        // target level list
        JSONArray targetLevel = new JSONArray();
        targetLevelArray.stream().forEach( value -> targetLevel.put( value ) );
        psrResponsBody.put( PSRConstants.TARGET_LEVEL_ARRAY, targetLevel );

        // filter by school list
        JSONArray orgJson = new JSONArray();
        new ArrayList<>( Arrays.asList( orgId ) ).stream().forEach( value -> orgJson.put( value ) );
        psrResponsBody.put( PSRConstants.FILTER_BY_SCHOOL, orgJson );

        // filter by Grades
        psrResponsBody.put( PSRConstants.FILTER_BY_GRADE, new JSONArray() );
        JSONObject demoJSON = new JSONObject();

        demoJSON.put( PSRConstants.DISABILLITY_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.ENGLISH_LANGUGAGE_PROFICIENCY, new JSONArray() );
        demoJSON.put( PSRConstants.GENDER, new JSONArray() );
        demoJSON.put( PSRConstants.RACE, new JSONArray() );
        demoJSON.put( PSRConstants.ETHINICITY, new JSONArray() );
        demoJSON.put( PSRConstants.SOCIO_ECONOMIC_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.MIGRANT_STATUS, new JSONArray() );
        demoJSON.put( PSRConstants.SPECIAL_SERVICES, new JSONArray() );

        psrResponsBody.put( PSRConstants.DEMOGRAPHICS_INPUT, demoJSON );
        variableBody.put( PSRConstants.PRS_REPORT_REQUEST, psrResponsBody );

        Log.message( "\nGraphQL Variable:\n" + variableBody.toString() );
        String requestBody = SMUtils.convertFileToString( new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator
                + "report" + File.separator + "PSRRequestBody.json" );
        String formatted = requestBody.format( requestBody, subject, courseList.toString(), targetDate, targetLevel.toString(), additionalGrouping, orgJson.toString(), teacherList.toString(), groupList.toString() );
        Log.message( "PayLoad:\n" + formatted.toString() );
        return formatted;
    }

    public Map<Object, Map<Object, Object>> actualValuesPSR( Response response ) {

        // Response Code Validation
        response.then().statusCode( 200 );

        Map<Object, Map<Object, Object>> actValues = new HashMap<Object, Map<Object, Object>>();

        List<Object> assignments = response.then().extract().path( "data.getAdminPSReportData.assignments" );
        Log.message( "\n The Assignment Size is : " + assignments.size() );
        assignments.forEach( assignment -> {

            Map<String, Object> eachAssignment = (Map<String, Object>) assignment;
            Object report_run = eachAssignment.get( PSRConstants.REPORT_RUN );

            Object assignmentTitle = eachAssignment.get( PSRConstants.ASSIGNMENT_TITLE );
            Object targetLevel = eachAssignment.get( PSRConstants.TARGET_LEVEL );
            Object targetDate1 = eachAssignment.get( PSRConstants.TARGET_DATE );
            Object daysToTarget = eachAssignment.get( PSRConstants.DAYS_TO_TARGET );
            Object organizationName = eachAssignment.get( PSRConstants.ORGANIZATION_NAME );
            Object teacherID = eachAssignment.get( PSRConstants.TEACHER_ID );
            Object grade = eachAssignment.get( PSRConstants.GRADE );

            // Verify Individually
            Map<Object, Object> eachAssignmentData = new HashMap<Object, Object>();
            eachAssignmentData.put( PSRConstants.TARGET_LEVEL, targetLevel );
            eachAssignmentData.put( PSRConstants.TARGET_DATE, targetDate1 );
            eachAssignmentData.put( PSRConstants.DAYS_TO_TARGET, daysToTarget );
            eachAssignmentData.put( PSRConstants.ORGANIZATION_NAME, organizationName );
            eachAssignmentData.put( PSRConstants.TEACHER_ID, teacherID );
            eachAssignmentData.put( PSRConstants.ASSIGNMENT_TITLE, assignmentTitle );
            eachAssignmentData.put( PSRConstants.GRADE, grade );

            Map<Object, Object> eachStudentData = new HashMap<Object, Object>();

            List<Object> students = (List<Object>) eachAssignment.get( PSRConstants.STUDENTS_ROW );

            // list of object of studnet
            // each student - has each value
            List<Map<Object, Object>> studnetsData = new ArrayList<Map<Object, Object>>();

            students.forEach( student -> {

                Map<String, Object> eachStudent = (Map<String, Object>) student;
                //                Object studentName = eachStudent.get( PSRConstants.STUDENT_NAME );
                //                Object studentUsername = eachStudent.get( PSRConstants.STUDENT_USERNAME );
                //
                //                Object ipmStatusId = eachStudent.get( PSRConstants.IPM_STATUS_ID );
                //
                //                Map<String, Object> studentData = new HashMap<String, Object>();
                //                studentData.put( PSRConstants.STUDENT_NAME, studentName );
                //                studentData.put( PSRConstants.STUDENT_USERNAME, studentUsername );
                //                studentData.put( PSRConstants.PERSON_ID, new RBSUtils().getUserIDByUserName( studentUsername.toString() ) );
                //                studentData.put( PSRConstants.IPM_STATUS_ID, ipmStatusId );

                Map<String, Object> eachPerfomanceData = (Map<String, Object>) eachStudent.get( PSRConstants.PERFOMANCE_DATA );
                Object currentCourseLevel = eachPerfomanceData.get( PSRConstants.CURRENT_COURSE_LEVEL );
                Object ipLevel = eachPerfomanceData.get( PSRConstants.IP_LEVEL );
                Object timeSinceIp = eachPerfomanceData.get( PSRConstants.TIME_SINCE_IP );
                Object skillsPercentMastered = eachPerfomanceData.get( PSRConstants.SKILL_PERCENT_MASTERED );

                Map<String, Object> performanceData = new HashMap<String, Object>();
                performanceData.put( PSRConstants.CURRENT_COURSE_LEVEL, currentCourseLevel );
                performanceData.put( PSRConstants.IP_LEVEL, ipLevel );
                performanceData.put( PSRConstants.TIME_SINCE_IP, timeSinceIp );
                performanceData.put( PSRConstants.SKILL_PERCENT_MASTERED, skillsPercentMastered );

                Map<String, Object> eachCurrentRate = (Map<String, Object>) eachStudent.get( PSRConstants.CURRENT_RATE );
                Object sessionLength = eachCurrentRate.get( PSRConstants.SESSION_LENGTH );
                Object averageMinDay = eachCurrentRate.get( PSRConstants.AVERAGE_MIN_DAY );
                Object currentLearningRate = eachCurrentRate.get( PSRConstants.CURRENT_LEARNING_RATE );

                Map<String, Object> currentRate = new HashMap<String, Object>();
                currentRate.put( PSRConstants.SESSION_LENGTH, sessionLength );
                currentRate.put( PSRConstants.AVERAGE_MIN_DAY, averageMinDay );
                currentRate.put( PSRConstants.CURRENT_LEARNING_RATE, currentLearningRate );

                Map<String, Object> eachCurrentForecast = (Map<String, Object>) eachStudent.get( PSRConstants.CURRENT_FORECAST );
                Object time = eachCurrentForecast.get( PSRConstants.TIME );
                Object level = eachCurrentForecast.get( PSRConstants.LEVEL );

                Map<String, Object> currentForecast = new HashMap<String, Object>();
                currentForecast.put( PSRConstants.TIME, time );
                currentForecast.put( PSRConstants.LEVEL, level );

                Map<String, Object> eachPrescription = (Map<String, Object>) eachStudent.get( PSRConstants.PRESCRIPTION );
                Object addlSessionsToTarget = eachPrescription.get( PSRConstants.ADDL_SESSION_TO_TARGET );
                Object addlTimeToTarget = eachPrescription.get( PSRConstants.ADDL_TIME_TO_TARGET );
                Object addlMinDayToTarget = eachPrescription.get( PSRConstants.ADDL_MIN_DAY_TO_TARGET );

                Map<String, Object> prescription = new HashMap<String, Object>();
                prescription.put( PSRConstants.ADDL_SESSION_TO_TARGET, addlSessionsToTarget );
                prescription.put( PSRConstants.ADDL_TIME_TO_TARGET, addlTimeToTarget );
                prescription.put( PSRConstants.ADDL_MIN_DAY_TO_TARGET, addlMinDayToTarget );

                //Adding all Details into one Map for one studnet
                // eachStudentData.put( "studentData", studentData );
                eachStudentData.put( PSRConstants.PERFOMANCE_DATA, performanceData );
                eachStudentData.put( PSRConstants.CURRENT_RATE, currentRate );
                eachStudentData.put( PSRConstants.CURRENT_FORECAST, currentForecast );
                eachStudentData.put( PSRConstants.PRESCRIPTION, prescription );
                studnetsData.add( eachStudentData );

            } );

            Map<Object, Object> oneAssignment = new HashMap<Object, Object>();

            oneAssignment.put( "assignmentData", eachAssignmentData );
            oneAssignment.put( "studentsData", studnetsData );

            actValues.put( grade + "-" + teacherID, oneAssignment );

        } );

        Log.message( "\n Collected Data is:\n" + actValues.toString() );
        return actValues;
    }

}