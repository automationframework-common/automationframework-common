package com.savvas.sm.reports.ui.pages.teacher;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

public class LeftNavigation {

	private final WebDriver driver;

    // ********* SuccessMaker Launcher/Login Page Elements ***************

    @FindBy ( tagName = "side-nav-bar" )
    WebElement smSideNav;

    @FindBy ( css = "cel-side-navigation[class='side-nav-bar hydrated']" )
    WebElement sideNavigationRoot;

    // ****Child Elements****
    private String childSubNavigationMenu = "cel-side-item";
    private String childSubNavigationButton = "button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public LeftNavigation( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }
    
    public boolean subNavigationMenuisDisplayed( String reportType ) {
        Log.message( "Verifing the sub-navigation " + reportType + " is displayed" );
        SMUtils.waitForElement( driver, sideNavigationRoot );
        List<WebElement> list = SMUtils.getWebElements( driver, sideNavigationRoot, childSubNavigationMenu );
        AtomicBoolean result = new AtomicBoolean( false );
        list.forEach( eachElement -> {
            WebElement reportElement = SMUtils.getWebElement( driver, eachElement, childSubNavigationButton );
            if ( reportElement.getText().equals( reportType ) ) {
                boolean displayed = reportElement.isDisplayed();
                result.set( ( displayed ) );
            }
        } );
        return result.get();
    }

    private void clickSubNavigation( String reportType ) {
        SMUtils.waitForElement( driver, sideNavigationRoot, 5 );

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );

        List<WebElement> list = SMUtils.getWebElements( driver, sideNavigationRoot, childSubNavigationMenu );
        list.forEach( eachElement -> {
            WebElement reportElement = SMUtils.getWebElement( driver, eachElement, childSubNavigationButton );
            if ( reportElement.getText().equals( reportType ) ) {
                wait.until( ExpectedConditions.elementToBeClickable( reportElement ) );
                SMUtils.clickJS( driver, reportElement );
            }
        } );
    }
    

    public PrescriptiveSchedulingPage clickOnPrescriptiveSchedulingPage() {
        Log.message( "Clicking on the Prescriptive Scheduling element in sub-navigation" );
        clickSubNavigation( ReportTypes.PRESCRIPTIVE_SCHEDULING );
        return new PrescriptiveSchedulingPage( driver ).get();
    }
}
