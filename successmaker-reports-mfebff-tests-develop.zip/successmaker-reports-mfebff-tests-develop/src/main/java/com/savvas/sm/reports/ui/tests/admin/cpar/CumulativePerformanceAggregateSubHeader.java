package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CumulativePerformanceAggregateSubHeader extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> org;
    private List<String> courses;

    @BeforeClass( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify sub-header is displayed for District admin while running the report option with Subject as Math and Additional Grouping as None with single organization", groups = { "Smoke", "SMK-61285", "CPAggregate",
    "CPAggregate" }, priority = 1 )
    public void tcCPRAggregateSubheaderOption001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for District admin while running the report option with Subject as Math and Additional Grouping as None with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get( 0 ) ), "Additional grouping text is displayed with none option",
                    "Additional grouping text is not displayed with none option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for District admin while running the report option with Subject as Math and Additional Grouping as Grade with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for District admin while running the report option with Subject as Math and Additional Grouping as Grade with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.ADDITONAL_GROUPING_BY_GRADE ), "Additional grouping text is displayed with grade option",
                    "Additional grouping text is not displayed with grade option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for District admin while running the report option with Subject as Reading and Additional Grouping as None with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for District admin while running the report option with Subject as Reading and Additional Grouping as None with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get( 0 ) ), "Additional grouping text is displayed with none option",
                    "Additional grouping text is not displayed with none option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for District admin while running the report option with Subject as Reading and Additional Grouping as Grade with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for District admin while running the report option with Subject as Reading and Additional Grouping as Grade with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.ADDITONAL_GROUPING_BY_GRADE ), "Additional grouping text is displayed with grade option",
                    "Additional grouping text is not displayed with grade option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Math and Additional Grouping as None with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Math and Additional Grouping as None with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get( 0 ) ), "Additional grouping text is displayed with none option",
                    "Additional grouping text is not displayed with none option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Math and Additional Grouping as Grade with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Math and Additional Grouping as Grade with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.ADDITONAL_GROUPING_BY_GRADE ), "Additional grouping text is displayed with grade option",
                    "Additional grouping text is not displayed with grade option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Reading and Additional Grouping as None with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Reading and Additional Grouping as None with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get( 0 ) ), "Additional grouping text is displayed with none option",
                    "Additional grouping text is not displayed with none option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Reading and Additional Grouping as Grade with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for Sub-District admin while running the report option with Subject as Reading and Additional Grouping as Grade with single organization<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.ADDITONAL_GROUPING_BY_GRADE ), "Additional grouping text is displayed with grade option",
                    "Additional grouping text is not displayed with grade option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for School admin while running the report option with Subject as Math and Additional Grouping as None with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for School admin while running the report option with Subject as Math and Additional Grouping as None with single organizationn<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get( 0 ) ), "Additional grouping text is displayed with none option",
                    "Additional grouping text is not displayed with none option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for School admin while running the report option with Subject as Math and Additional Grouping as Grade with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption010() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for School admin while running the report option with Subject as Math and Additional Grouping as Grade with single organizationn<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Math" ), "Math text is present", "Math text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.ADDITONAL_GROUPING_BY_GRADE ), "Additional grouping text is displayed with grade option",
                    "Additional grouping text is not displayed with grade option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for School admin while running the report option with Subject as Reading and Additional Grouping as None with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption011() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for School admin while running the report option with Subject as Reading and Additional Grouping as None with single organizationn<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "None" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS.get( 0 ) ), "Additional grouping text is displayed with none option",
                    "Additional grouping text is not displayed with none option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-header is displayed for School admin while running the report option with Subject as Reading and Additional Grouping as Grade with single organization", groups = { "SMK-61285", "CPAggregateSubheaderOption",
    "CPAggregateSubheaderOption" }, priority = 1 )
    public void tcCPAggregateSubheaderOption012() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "Verify sub-header is displayed for School admin while running the report option with Subject as Reading and Additional Grouping as None with single organizationn<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList(  RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            CPAReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );
            CPAReport.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow(driver);
            SMUtils.waitForPageLoad(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            ReportOutputComponent reportViewer = new ReportOutputComponent( driver );
            Log.assertThat( reportViewer.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative performance aggregate report viewer page title is displayed successfully!!!",
                    "Cumulative performance aggregate report viewer page title is not displayed properly" );
            Log.assertThat( reportViewer.getSubjectLabel().equals( "Reading" ), "Reading text is present", "Reading text is not present" );
            Log.assertThat( reportViewer.getDateLabel().equals( reportViewer.dateAndTime() ), "Date and time is present", "Date and time is not present" );
            Log.assertThat( reportViewer.getDistrictLabel().equals( "District:" ), "District text is displayed", "District text is not displayed" );
            Log.assertThat( reportViewer.getGradeLabel().equals( "Grade:" ), "Grade text is displayed", "Grade text is not displayed" );
            Log.assertThat( reportViewer.getSelectedOptionLabel().equals( "Selected Options:" ), "Selected Options present", "Selected Options Not present" );
            Log.assertThat( reportViewer.getSelectedOptionsLegend().contains( ReportsUIConstants.CPAReport.ADDITONAL_GROUPING_BY_GRADE ), "Additional grouping text is displayed with grade option",
                    "Additional grouping text is not displayed with grade option" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
