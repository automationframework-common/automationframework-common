package com.savvas.sm.reports.util;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v101.fetch.model.HeaderEntry;
import org.openqa.selenium.devtools.v101.fetch.Fetch;
import org.openqa.selenium.devtools.v101.fetch.model.RequestPattern;
import org.openqa.selenium.devtools.v101.fetch.model.RequestStage;
import org.openqa.selenium.devtools.v101.network.Network;
import org.openqa.selenium.devtools.v101.network.model.ConnectionType;
import org.openqa.selenium.remote.Augmenter;
import org.testng.ITestContext;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.FileUtil;

public class DevToolsUtils {

    /**
     * To intercept the status code and response usig dev tools
     * 
     * @param driver
     * @param reqUrl
     * @param method
     * @param statusCode
     * @param responseBody
     * @return
     */
    public static DevTools setResponse(WebDriver driver, String reqUrl, String method, int statusCode,
            String responseBody) {
        driver = new Augmenter().augment(driver);
        DevTools tool = ((HasDevTools) driver).getDevTools();
        tool.createSession();
        RequestPattern pattern = new RequestPattern(Optional.empty(), Optional.empty(),
                Optional.of(RequestStage.RESPONSE));
        tool.send(Network.setBypassServiceWorker(true));
        tool.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
        tool.send(Fetch.enable(Optional.of(Arrays.asList(pattern)), Optional.empty()));
        tool.addListener(Fetch.requestPaused(), req -> {
            if (req.getRequest().getUrl().equals(reqUrl) && req.getRequest().getMethod().toLowerCase().equals(method)) {
                Log.event("Mock Response - Request matched");
                tool.send(Fetch.fulfillRequest(req.getRequestId(), statusCode, req.getResponseHeaders(),
                        Optional.empty(), Optional.of(Base64.getEncoder().encodeToString(responseBody.getBytes())),
                        Optional.empty()));
                tool.send(Fetch.disable());
                tool.send(Network.setBypassServiceWorker(false));
            } else {
                tool.send(Fetch.continueRequest(req.getRequestId(), Optional.empty(), Optional.empty(),
                        Optional.empty(), Optional.empty(), Optional.empty()));
            }
        });
        return tool;
    }

    public static DevTools setResponse(WebDriver driver, String reqUrl, List<String> requestPayloadMatchers, String method, Map<String, String> responses) {
        driver = (new Augmenter()).augment(driver);
        AtomicReference<DevTools> tool = new AtomicReference<>(((HasDevTools) driver).getDevTools());

        tool.get().createSession();
        RequestPattern pattern = new RequestPattern(Optional.empty(), Optional.empty(), Optional.of(RequestStage.RESPONSE));
        tool.get().send(Network.setBypassServiceWorker(true));
        tool.get().send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
        tool.get().send(Fetch.enable(Optional.of(Arrays.asList(pattern)), Optional.empty()));

        tool.get().addListener(Fetch.requestPaused(), (req) -> {
            List<HeaderEntry> custHeaders = new ArrayList<>();
            custHeaders.add(new HeaderEntry("Access-Control-Allow-Origin", "*"));
            custHeaders.add(new HeaderEntry("Access-Control-Allow-Credentials", "true"));

            AtomicReference<String> reqPayloadMatchingText = new AtomicReference<>(null);
            requestPayloadMatchers.forEach(matcher -> {
                req.getRequest().getPostData().ifPresent(data -> {
                    if (data.contains(matcher)) {
                        reqPayloadMatchingText.set(matcher);
                    }
                });
            });

            if (req.getRequest().getUrl().equalsIgnoreCase(reqUrl) && req.getRequest().getMethod().equalsIgnoreCase(method)) {
                tool.get().send(Fetch.fulfillRequest(req.getRequestId(),
                        200, Optional.of(custHeaders),
                        Optional.empty(),
                        Optional.of(Base64.getEncoder().encodeToString(responses.get(reqPayloadMatchingText.get()).getBytes())),
                        Optional.empty()));
                Log.event( "Mock request matched" );
            } else {
                tool.get().send(Fetch.continueRequest(req.getRequestId(),
                        Optional.empty(),
                        Optional.of(req.getRequest().getMethod()),
                        Optional.empty(),
                        Optional.of(custHeaders),
                        Optional.empty()));
            }
        });
        return tool.get();
    }


    /**
     * To close the response mock
     * 
     * @param devTools
     */
    public static void closeMock(DevTools devTools) {
        devTools.clearListeners();
        devTools.close();
    }

    /**
     * To Read the mock Json Response
     * 
     * @param fileName
     * @return
     * @throws IOException
     */
    public static String readJsonResponse(String fileName) throws IOException {
        String filePath = new File(".").getCanonicalPath() + File.separator + "src" + File.separator + "main"
                + File.separator + "resources" + File.separator + "mockJson" + File.separator + fileName;
        return FileUtil.readTextFile(filePath);
    }

    /**
     * To Throttle The Network
     * 
     * @param driver
     * @param connectionType
     * @return
     */
    public static DevTools throttleNetwork(WebDriver driver, ConnectionType connectionType) {
        driver = new Augmenter().augment(driver);
        DevTools tool = ((HasDevTools) driver).getDevTools();
        tool.createSession();
        tool.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
        tool.send(Network.emulateNetworkConditions(false, 20, 20, 50, Optional.of(connectionType)));
        return tool;
    }

    public static int countLines(String str){
        String[] lines = str.split("\r\n|\r|\n");
        return  lines.length;
    }
    
    
    public static boolean isMock(ITestContext context) {
        if (context != null && context.getIncludedGroups() != null
                && Arrays.stream(context.getIncludedGroups()).anyMatch(group -> group.equals("mock"))) {
            return true;
        } else
            return false;
    }

}