package com.savvas.sm.reports.smoke.admin.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class StudentPerformanceReport extends LoadableComponent<StudentPerformanceReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Student Performance Report']", AI = false )
    public WebElement txtStudentPerformanceReportHeader;

    @IFindBy ( how = How.XPATH, using = " //label[text()='Date at Risk']", AI = false )
    public WebElement txtDateAtRisk;

    @IFindBy ( how = How.XPATH, using = "//label[text()='Language']", AI = false )
    public WebElement txtLanguage;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/

    public String drpDwnDateAtRisk[] = { "cel-accordion-item", "document.querySelector('#date-at-risk').shadowRoot.querySelector('#dropdown')" };
    public String drpDwnLanguage[] = { "cel-accordion-item", "document.querySelector('#language').shadowRoot.querySelector('#dropdown')" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };
    // Radio buttons for student performance report -- Yes
    public String rdYesIncludePerformanceSummary[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(1)').shadowRoot.querySelector('cel-radio-button').shadowRoot.querySelector('#yes')" };
    public String rdYesIncludePerformanceByStrand[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(2)').shadowRoot.querySelector('cel-radio-button').shadowRoot.querySelector('#yes')" };
    public String rdYesIncludeAreasForGrowth[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(3)').shadowRoot.querySelector('cel-radio-button').shadowRoot.querySelector('#yes')" };
    // Radio buttons for student performance report -- No
    public String rdNoIncludePerformanceSummary[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(1)').shadowRoot.querySelector('cel-radio-button:nth-child(2)').shadowRoot.querySelector('#no')" };
    public String rdNoIncludePerformanceByStrand[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(2)').shadowRoot.querySelector('cel-radio-button:nth-child(2)').shadowRoot.querySelector('#no')" };
    public String rdNoIncludeAreasForGrowth[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(3)').shadowRoot.querySelector('cel-radio-button:nth-child(2)').shadowRoot.querySelector('#no')" };
    // label for Radio Buttons
    public String txtIncludePerformanceSummary[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(1)').shadowRoot.querySelector('span')" };
    public String txtIncludePerformanceByStrand[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(2)').shadowRoot.querySelector('span')" };
    public String txtIncludeAreasForGrowth[] = { "cel-accordion-item", "document.querySelector('cel-radio-button-group:nth-child(3)').shadowRoot.querySelector('span')" };
    /* String Title Text For validations */
    public String performanceSummary = "Include Performance Summary";
    public String performanceByStrand = "Include Performance By Strand";
    public String areasForGrowth = "Include Areas For Growth";
    public String language = "Language";
    public String dateAtRisk = "Date at Risk";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtStudentPerformanceReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public StudentPerformanceReport() {}

    public StudentPerformanceReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas Validate Include Performance Summary Element &
     *         Text
     * @throws InterruptedException
     */
    public void validateTxtIncludePerformanceSummary( WebDriver driver ) throws InterruptedException {
        WebElement txtIncludePerformanceSummary = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtIncludePerformanceSummary[0], this.txtIncludePerformanceSummary[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtIncludePerformanceSummary, "Include Performance Summary Element" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtIncludePerformanceSummary, performanceSummary, "Text : Include Performance Summary" );
    }

    /**
     * @author aravindan.srinivas Validate Include Performance By Strand Element
     *         & Text
     * @throws InterruptedException
     */
    public void validateTxtIncludePerformanceByStrand( WebDriver driver ) throws InterruptedException {
        WebElement txtIncludePerformanceByStrand = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtIncludePerformanceByStrand[0], this.txtIncludePerformanceByStrand[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtIncludePerformanceByStrand, "Include Performance By Strand Element" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtIncludePerformanceByStrand, performanceByStrand, "Text : Include Performance By Strand" );
    }

    /**
     * @author aravindan.srinivas Validate Include AreasForGrowth Element & Text
     * @throws InterruptedException
     */
    public void validateTxtIncludeAreasForGrowth( WebDriver driver ) throws InterruptedException {
        WebElement txtIncludeAreasForGrowth = ShadowDOMUtils.retryAndGetWebElement( driver, this.txtIncludeAreasForGrowth[0], this.txtIncludeAreasForGrowth[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, txtIncludeAreasForGrowth, "Include AreasForGrowth Element" );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtIncludeAreasForGrowth, areasForGrowth, "Text : Include AreasForGrowth" );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button No
     *         IncludePerformanceSummary
     * @throws InterruptedException
     */
    public void validateRdNoIncludePerformanceSummary( WebDriver driver ) throws InterruptedException {
        WebElement rdNoIncludePerformanceSummary = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdNoIncludePerformanceSummary[0], this.rdNoIncludePerformanceSummary[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdNoIncludePerformanceSummary, "Include Performance Summary Radio Button -> No" );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button No Include Performance
     *         By Strand
     * @throws InterruptedException
     */
    public void validateRdNoIncludePerformanceByStrand( WebDriver driver ) throws InterruptedException {
        WebElement rdNoIncludePerformanceByStrand = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdNoIncludePerformanceByStrand[0], this.rdNoIncludePerformanceByStrand[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdNoIncludePerformanceByStrand, "Include Performance By Strand Radio Button -> No " );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button No Include
     *         AreasForGrowth
     * @throws InterruptedException
     */
    public void validateRdNoIncludeAreasForGrowth( WebDriver driver ) throws InterruptedException {
        WebElement rdNoIncludeAreasForGrowth = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdNoIncludeAreasForGrowth[0], this.rdNoIncludeAreasForGrowth[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdNoIncludeAreasForGrowth, "Include AreasForGrowth Radio Button -> No" );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button Yes
     *         IncludePerformanceSummary
     * @throws InterruptedException
     */
    public void validateRdYesIncludePerformanceSummary( WebDriver driver ) throws InterruptedException {
        WebElement rdYesIncludePerformanceSummary = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdYesIncludePerformanceSummary[0], this.rdYesIncludePerformanceSummary[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdYesIncludePerformanceSummary, "Include Performance Summary Radio Button -> Yes" );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button Yes Include Performance
     *         By Strand Element
     * @throws InterruptedException
     */
    public void validateRdYesIncludePerformanceByStrand( WebDriver driver ) throws InterruptedException {
        WebElement rdYesIncludePerformanceByStrand = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdYesIncludePerformanceByStrand[0], this.rdYesIncludePerformanceByStrand[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdYesIncludePerformanceByStrand, "Include Performance By Strand Radio Button -> Yes " );
    }

    /**
     * @author aravindan.srinivas Validate Radio Button Yes Include
     *         AreasForGrowth
     * @throws InterruptedException
     */
    public void validateRdYesIncludeAreasForGrowth( WebDriver driver ) throws InterruptedException {
        WebElement rdYesIncludeAreasForGrowth = ShadowDOMUtils.retryAndGetWebElement( driver, this.rdYesIncludeAreasForGrowth[0], this.rdYesIncludeAreasForGrowth[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, rdYesIncludeAreasForGrowth, "Include AreasForGrowth Radio Button -> Yes" );
    }

    /**
     * @author aravindan.srinivas Validate Drop Down Date At Risk & Its Text
     * @throws InterruptedException
     */
    public void validatedrpDwnDateAtRisk( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnDateAtRisk = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnDateAtRisk[0], this.drpDwnDateAtRisk[1] );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtDateAtRisk, dateAtRisk, "Text : Date at Risk" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnDateAtRisk, "Date At Risk Drop Down Field" );
    }

    /**
     * @author aravindan.srinivas Validate Drop Down Language & Its Text
     * @throws InterruptedException
     */
    public void validatedrpDwnLanguage( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnLanguage = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnLanguage[0], this.drpDwnLanguage[1] );
        ReportsBrowserActions.verifyElementTextIsDisplayed( driver, txtLanguage, language, "Text : Language" );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnLanguage, "Language Drop Down Field" );

    }

    /**
     * @author aravindan.srinivas Validate all the fields and headers present in
     *         the Student Performance Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInStudentPerformanceReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtStudentPerformanceReportHeader.getText();
        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        reportsFilterUtils.verifyTextOrganizationsHeader( driver );
        reportsFilterUtils.validateOrgDrpdwnField( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );

        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );

        reportsFilterUtils.verifyTextSelectStudentBy( driver );

        reportsFilterUtils.verifyTextTeacher( driver );
        reportsFilterUtils.validateTeacherDrpdwnField( driver );

        reportsFilterUtils.verifyTextGrade( driver );
        reportsFilterUtils.validateGradeDrpdwnField( driver );

        reportsFilterUtils.verifyTextGroup( driver );
        reportsFilterUtils.validateGroupDrpdwnField( driver );

        reportsFilterUtils.verifyTextDisplay( driver );
        reportsFilterUtils.validateDisplayDrpdwnField( driver );

        reportsFilterUtils.validateMaskCheckBoxField( driver );

        validateTxtIncludePerformanceSummary( driver );
        validateRdYesIncludePerformanceSummary( driver );
        validateRdNoIncludePerformanceSummary( driver );

        validateTxtIncludePerformanceByStrand( driver );
        validateRdYesIncludePerformanceByStrand( driver );
        validateRdNoIncludePerformanceByStrand( driver );

        validateTxtIncludeAreasForGrowth( driver );
        validateRdYesIncludeAreasForGrowth( driver );
        validateRdNoIncludeAreasForGrowth( driver );

        validatedrpDwnDateAtRisk( driver );
        validatedrpDwnLanguage( driver );

        // Demographics Filter
        WebElement txtStudentDemographics = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtStudentDemographicsShadowDOM[0], reportsFilterUtils.txtStudentDemographicsShadowDOM[1] );
        SMUtils.click( driver, txtStudentDemographics );

        reportsFilterUtils.verifyTextDisablityStatus( driver );
        reportsFilterUtils.validateDisabilityStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextEnglishLanguageProficiency( driver );
        reportsFilterUtils.validateEnglishLanguageProficiencyDrpdwnField( driver );

        reportsFilterUtils.verifyTextEthnicity( driver );
        reportsFilterUtils.validateEthnicityDrpdwnField( driver );

        reportsFilterUtils.verifyTextMigrantStatus( driver );
        reportsFilterUtils.validateMigrantStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextRace( driver );
        reportsFilterUtils.validateRaceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSpecialServices( driver );
        reportsFilterUtils.validateSpecialServiceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSocioEconomicStatus( driver );
        reportsFilterUtils.validateSocioEconomicStatusDrpdwnField( driver );
    }

    /**
     * @author sathish.suresh Validate SPR run report
     * @param driver
     * @param flexSchoolId 
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateSPRRunReport( WebDriver driver, String flexSchoolId ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        this.chooseOrganization( driver, flexSchoolId );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sathish.suresh Student Performance saved report Validation
     * @param driver
     * @param flexSchoolId 
     * @throws InterruptedException
     */
    public void validateSPSavedReports( WebDriver driver, String flexSchoolId ) throws InterruptedException {
        Random rnd = new Random();
        int n = 1 + rnd.nextInt();
        String savedReportName = "Automation Validation" + n; // update
        System.out.println( savedReportName );
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Student Performance Report" ), "User Landed On Areas Of Growth Report", "User Not Landed On Areas Of Growth Report" );

        WebElement drpdwnSubjectshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnSubjectshadowDOM[0], reportsFilterUtils.drpdwnSubjectshadowDOM[1] );
        WebElement drpdwnCoursesshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnCoursesshadowDOM[0], reportsFilterUtils.drpdwnCoursesshadowDOM[1] );

        this.chooseOrganization( driver, flexSchoolId );

        SMUtils.click( driver, drpdwnSubjectshadowDOM );
        Log.message( "User Clicked On Subject Drop Down" );
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelect( driver, drpdwnSubjectshadowDOM, "Math", "Course drop Down" );

        Thread.sleep( 2000 );
        reportsFilterUtils.verifyCourseDropDownIsEnabled( driver, drpdwnCoursesshadowDOM );
        ArrayList<String> optionToSelect = new ArrayList<String>( Arrays.asList( "Select All" ) );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", optionToSelect );
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );

    }

    /**
     * @author sakthi.sasi Used to perform Organization choosing
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public StudentPerformanceReport chooseOrganization( WebDriver driver, String orgId ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.nap( 5 );
        System.out.println( orgId );
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, drpOrganizationOptions[0], drpOrganizationOptions[1] );
        drpdwnElement.click();
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelectValue( driver, drpdwnElement, orgId, "Choosing Organization" );
        return this;

    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public StudentPerformanceReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtStudentPerformanceReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to expand optional filters
     * 
     * @param driver
     * @return
     */
    public StudentPerformanceReport clickOptionalFilters( WebDriver driver ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtStudentPerformanceReportHeader );
        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        SMUtils.click( driver, txtOptionalFilter );
        return this;

    }

    public StudentPerformanceReport clickStudentDemographics( WebDriver driver ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtStudentPerformanceReportHeader );
        WebElement txtStudentDemographics = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtStudentDemographicsShadowDOM[0], reportsFilterUtils.txtStudentDemographicsShadowDOM[1] );
        SMUtils.click( driver, txtStudentDemographics );
        return this;

    }

    /**
     * @author sakthi.sasi Used to verify the Organization ID's
     * 
     * @param driver
     * @param districtAdmin
     * @param smUrl
     * @return
     * @throws Exception
     */
    public StudentPerformanceReport verifyOrgIds( WebDriver driver, Admins districtAdmin, String smUrl ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.compareOrganizationElements( driver, districtAdmin, smUrl ), "Organization List Matches", "Organization List doesn't Match" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Organization is available or not
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public StudentPerformanceReport verifyOrg( WebDriver driver, String orgName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.validateOrganizationDropdownValue( driver, orgName ), "Organization is Available", "Organization is not Available" );
        return this;
    }

    /**
     * @author raseem.mohamed
     * @param driver
     * @param admin
     * @param orgIds
     * @param SubjectName
     * @return
     * @throws Exception
     */
    public StudentPerformanceReport verifyCourses( WebDriver driver, Admins admin, List<String> orgIds, String SubjectName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expcourseNames = new ArrayList<String>();
        List<String> actualCourseNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.COURSES );
        Log.message( "Actual Courses Name From UI : " + actualCourseNames );
        if ( SubjectName.equalsIgnoreCase( "reading" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "studentPerformance", "2" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        } else if ( SubjectName.equalsIgnoreCase( "math" ) ) {
            expcourseNames = reportsFilterUtils.verifyCourses( driver, admin, orgIds, "studentPerformance", "1" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        }

        Log.message( "Courses Name From UI : " + actualCourseNames );

        int actualSize = actualCourseNames.size();
        int expectSize = expcourseNames.size();
        String actual = String.valueOf( actualSize );
        String expect = String.valueOf( expectSize );

        boolean validate = false;
        if ( actualSize == expectSize ) {
            for ( int i = 0; i < actualCourseNames.size(); i++ ) {
                validate = actualCourseNames.get( i ).contains( expcourseNames.get( i ) );
                if ( validate == false ) {
                    Log.softAssertThat( validate, "Course " + actualCourseNames + "Value Is Matching", "Course" + actualCourseNames + " Value Is Not Matching" );
                }
            }
        }
        Log.assertThat( actual.equalsIgnoreCase( expect ), "Passed : Courses Are Matching", "Failed : Courses Are Not Matching" );
        return this;

    }

    /**
     * @author raseem.mohamed Used to verify the Teachers in UI matches the
     *         Teaches fetched from RBS
     * 
     * @param driver
     * @param admin
     * @param orgIds
     * @return
     * @throws Exception
     */
    public StudentPerformanceReport verifyTeachers( WebDriver driver, Admins admin, List<String> orgIds ) throws Exception {

        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        List<String> actualTeacherNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.TEACHERS );
        System.out.println( "Actual teacher Name" + actualTeacherNames );
        List<String> actualTeacherID = reportsFilterUtils.getAllTeacherID( reportsFilterUtils.TEACHERS );
        System.out.println( actualTeacherID );
        List<String> expTeacherID = reportsFilterUtils.getTeacherId( driver, admin, orgIds );
        reportsFilterUtils.setValuesForDropdown( reportsFilterUtils.TEACHERS, actualTeacherNames.subList( 1, 3 ) );
        Log.softAssertThat( expTeacherID.containsAll( actualTeacherID ), "Teachers are matching", "Teachers are not matching" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Groups in UI matches the Group
     *         fetched from RBS
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public StudentPerformanceReport verifyGroup( WebDriver driver ) throws Exception {

        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expgroupNames = new ArrayList<String>();
        List<String> actualTeacherNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.TEACHERS );
        reportsFilterUtils.setValuesForDropdown( reportsFilterUtils.TEACHERS, actualTeacherNames.subList( 1, 3 ) );
        expgroupNames = reportsFilterUtils.getGroupListNames( reportsFilterUtils.getGroupIds() );
        List<String> allValuesFromGroupsDropdown = reportsFilterUtils.getGroupNames();
        Collections.sort( expgroupNames );
        Collections.sort( allValuesFromGroupsDropdown );

        Log.softAssertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );

        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Grades
     * 
     * @param driver
     * @return
     * @throws Exception
     */
    public StudentPerformanceReport verifyGrades( WebDriver driver ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> allValuesFromGradesDropdown = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.GRADES );
        Log.assertThat( allValuesFromGradesDropdown.containsAll( Constants.Students.ALL_GRADES ), "The Grade Values is matching", "The Grade Values is matching" );

        reportsFilterUtils.clickSelectAll( reportsFilterUtils.GRADES );
        Log.testCaseInfo( "Verify if the Grade All is selected when ticked All option" );
        Log.softAssertThat( reportsFilterUtils.isSelectAllChecked( reportsFilterUtils.GRADES ), "The Select All option is Checked", "The Select All option is not Checked" );
        reportsFilterUtils.clickGradesDropdown();
        return this;
    }
}
