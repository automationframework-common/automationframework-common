package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.bff.admin.tests.CPARReportAdminGraphQLTest;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPAReport;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

import io.restassured.response.Response;

public class CPAReportAdminMFETest extends EnvProperties {

    private String browser;
    CourseAPI coursesMethod = new CourseAPI();
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String studentId;
    String studentId1;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String firstTeacherOrgID;
    String orgName;
    List<String> courses;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        RBSUtils rbsUtils = new RBSUtils();

        // Teacher UserNames
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        //Selected School Name
        firstTeacherOrgID = ReportData.orgId;
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        //Teacher User ID's
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );

        //Group ID's
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 1 ).toString(), "groupId" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        //Filter By Values - OrgId
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        //School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );

        //Student ID's
        studentId = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[0].toString();
        studentId1 = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[1].toString();
    }

    // Check selecting "Select All" option and Run Report in Demographics

    @Test ( description = "Verify the CPA Report generation with 'Select All' option in Student Demographic", groups = { "SMK-66767", "AdminDashboard", "Reports", "Cumulative Performance Aggregate" }, priority = 1 )
    public void tcCumulativePerformanceAggregate001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformanceAggregate001: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReportPage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CPAReportPage.reportFilterComponent.expandOptionalFilter();
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );
            CPAReportPage.reportFilterComponent.expandStudentDemographics();
            List<String> availableOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            List<String> selectedOptions = Arrays.asList( availableOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, selectedOptions );
            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all disablity options",
                    "Selected disablity options are not checked" );
            Log.testCaseResult();

            // Get English Proficiency List and Select multiple options from drop-down
            List<String> availableEnglishProficiencyOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.message( availableEnglishProficiencyOptionList.toString() );
            List<String> selectedEnglishProficiencyOptions = Arrays.asList( availableEnglishProficiencyOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, selectedEnglishProficiencyOptions );

            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ),
                    "Selected all english language proficiency options", "Selected english language proficiency options are not checked" );
            Log.testCaseResult();

            // Get Ethnicity List and Select multiple options from drop-down
            List<String> EthnicityOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            List<String> selectedEthnicityOptions = Arrays.asList( EthnicityOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, selectedEthnicityOptions );

            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all ethnicity options",
                    "Selected ethnicity options are not checked" );
            Log.testCaseResult();

            // Get Migrant Status List and Select multiple options from drop-down
            List<String> MigrantStatusOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            List<String> selectedMigrantStatusOptions = Arrays.asList( MigrantStatusOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, selectedMigrantStatusOptions );

            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all migrant status options",
                    "Selected migrant status options are not checked" );
            Log.testCaseResult();

            // Get Race List and Select multiple options from drop-down
            List<String> raceOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE );
            List<String> selectedRaceOptions = Arrays.asList( raceOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, selectedRaceOptions );

            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.RACE ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all race options",
                    "Selected race options are not checked" );
            Log.testCaseResult();

            // Get Special Services List and Select multiple options from drop-down
            List<String> specialServicesOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            List<String> selectedSpecialServicesOptions = Arrays.asList( specialServicesOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, selectedSpecialServicesOptions );

            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all special services options",
                    "Selected special services are not displaying" );
            Log.testCaseResult();

            // Get Socioeconomic Status List and Select multiple options from drop-down
            List<String> socioeconomicStatusOptionList = CPAReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            List<String> selectedSocioeconomicStatusOptions = Arrays.asList( socioeconomicStatusOptionList.get( 0 ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, selectedSocioeconomicStatusOptions );

            Log.assertThat( CPAReportPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ALL_OPTION ), "Selected all socioeconomic status options",
                    "Selected socioeconomic status are not displaying" );
            Log.testCaseResult();
            CPAReportViewerPage reportViewerPage = CPAReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify 'the CPR aggregate Report generation with mandatory field'." );
            SMUtils.logDescriptionTC( "Verify the report name is display in the header in CPR aggregate." );
            Log.assertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the CP Report generation with 'Select All' option in Student Demographic", groups = { "SMK-66767", "AdminDashboard", "Reports", "Cumulative Performance Aggregate" }, priority = 1 )
    public void tcCumulativePerformanceAggregate002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformanceAggregate002: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReportPage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CPAReportPage.reportFilterComponent.expandOptionalFilter();
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level (Mean)" );
            CPAReportViewerPage reportViewerPage = CPAReportPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "Verify 'the CPR aggregate Report generation with mandatory field'." );
            SMUtils.logDescriptionTC( "Verify the report name is display in the header in CPR aggregate." );
            Log.assertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Course name, Report run, school, teacher, grade and group are present under the header in CPR aggregate." );
            Log.assertThat( reportViewerPage.getSubjectLabel().equals( Constants.MATH ), "Assignment name is present", "Assignment name is not present" );
            Log.assertThat( reportViewerPage.getDateLabel().equals( reportViewerPage.getDateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( reportViewerPage.getDistrictName().equals( SMUtils.getKeyValueFromResponse( new RBSUtils().getOrg( configProperty.getProperty( "district_ID" ) ), "displayName" ) ), "District name is displayed",
                    "District name is not displayed" );
            Log.assertThat( reportViewerPage.getSelectedOptionLabel().contains( ReportsUIConstants.SELECTED_OPTION_HEADER ), "Selected Options header is present", "Selected Options header is not present" );
            Log.assertThat( reportViewerPage.getSelectedOptionsLegend().containsAll( ReportsUIConstants.CPAReport.SELECTED_OPTIONS_LABELS ), "List of get selected options present", "List of get selected options not present" );
            Log.assertThat( reportViewerPage.verifyLegend(), "Legend values are displayed", "Legend values are not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the available columns in CPR aggregate." );
            Log.assertThat( reportViewerPage.getColumnHeaders().equals( CPAReport.TABLE_HEADER ), "Table column names are displayed as expected", "Table column names are not displayed as expected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the page number in CPR aggregate." );
            Log.assertThat( reportViewerPage.verifyPagination(), "Page number is displayed in CPA report viewer page ", "Page number is not displayed in CPA report viewer page " );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the CPA Report generation with API response Math", groups = { "SMK-66767", "AdminDashboard", "Reports", "Cumulative Performance Aggregate" }, priority = 1 )
    public void tcCumulativePerformanceAggregate003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformanceAggregate003: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReportPage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.testCaseResult();
            CPAReportViewerPage reportViewerPage = CPAReportPage.clickRunReportButton();

            Log.assertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            
            HashMap<String, HashMap<String, String>> responseCPARUI=CPAReportPage.getCPAReportAllDataFromUI( driver );
            HashMap<String, HashMap<String, String>> responseCPAR=getCompleteDataFromBFF(Constants.MATH);
            Log.message( "Data from API :"+ responseCPAR +"\n Data from UI :"+responseCPARUI);
            boolean validation = responseCPAR.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), responseCPARUI.get( entry.getKey() ) ) );
           Log.assertThat( validation, "MFE BFF data verification Successful", "MFE BFF data verification Failed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify the CPA Report generation with API response for Reading", groups = { "SMK-66767", "AdminDashboard", "Reports", "Cumulative Performance Aggregate" }, priority = 1 )
    public void tcCumulativePerformanceAggregate004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformanceAggregate004: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( distAdminUserName, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReportPage = cumulativePerformancePage.navigateToCPAReport();

            CPAReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            CPAReportPage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( "Select All Visible" ) );
            CPAReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.READING );
            CPAReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.testCaseResult();
            CPAReportViewerPage reportViewerPage = CPAReportPage.clickRunReportButton();

            Log.assertThat( reportViewerPage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            
            HashMap<String, HashMap<String, String>> responseCPARUI=CPAReportPage.getCPAReportAllDataFromUI( driver );
            HashMap<String, HashMap<String, String>> responseCPAR=getCompleteDataFromBFF(Constants.READING);
            Log.message( "Data from API :"+ responseCPAR +"\n Data from UI :"+responseCPARUI);
            boolean validation = responseCPAR.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), responseCPARUI.get( entry.getKey() ) ) );
           Log.assertThat( validation, "MFE BFF data verification Successful", "MFE BFF data verification Failed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public HashMap<String, HashMap<String, String>> getCompleteDataFromBFF(String subject) throws Exception {
        HashMap<String, String> filterByValues = new HashMap<>();
        CPARReportAdminGraphQLTest cPARReportAdminGraphQLTest = new CPARReportAdminGraphQLTest();
        response = cPARReportAdminGraphQLTest.getCPARReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, subject, filterByValues );
        Log.message( response.getBody().asString() );
        HashMap<String, HashMap<String, String>> responseFromCPAR=cPARReportAdminGraphQLTest.getDataFromResponseForVerification( response.getBody().asString() );
        return responseFromCPAR;
    }
}