package com.savvas.sm.reports.ui.pages;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.CPAReport;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.utils.SMUtils;

public class ReportOutputComponent {

	private final WebDriver driver;

	// ********* SuccessMaker Report Page Elements ***************

	@FindBy(css = "report-viewer-header h2")
	WebElement pageTitle;

	@FindBy(css = "cel-button.back-btn")
	WebElement btnBackRoot;

	@FindBy(css = "cel-button.next-btn")
	WebElement btnNextRoot;

	@FindBy(css = "div.header-pagination span")
	List<WebElement> paginationText;

	@FindBy(css = "h3.assignment-name")
	WebElement assignmentName;

	@FindBy(css = "dl.ml-3 dt")
	WebElement headerReportRun;

	@FindBy(css = "dl.info dt")
	List<WebElement> headersRowInfo;

	@FindBy(css = "span.ml-2")
	WebElement headerSelectedOptions;

	@FindBy(css = "ul.selected-options li")
	List<WebElement> valuesSelectedOptions;

	@FindBy(css = "input.pagination-text-field")
	WebElement currentPageNumber;

	@FindBy(css = "span.error-message")
	WebElement noPageNumber;

	@FindBy(css = "report-viewer-header .pagination-text-suffix")
	WebElement totalNumberOfPages;

	@FindBy(css = ".reports-data-container p.header")
	WebElement zeroStateSPR;

	@FindBy(css = "report-sub-header .ipsummary dd")
	List<WebElement> initialPlacementValues;

	// Performance Summary

	@FindBy(css = "spr-performance-summary-grid.section-main-header")
	WebElement performanceSummary;

	
	@FindBy(css = "span.section-main-header")
	WebElement performanceSummaryText;
	
	// Performance By Strand - Cumulative
	@FindBy(css = "spr-performance-by-strand .section-main-header")
	WebElement performanceByStrandCumulative;

	@FindBy(css = "spr-performance-by-strand report-grid table")
	List<WebElement> performanceByStrand;

	// Areas For Growth - Since IP
	@FindBy(css = "spr-areas-for-growth .section-main-header")
	WebElement areasForGrowthTitle;


	@FindBy(css = "spr-areas-for-growth section>div")
	List<WebElement> areaForGrowth;

	@FindBy(css = "report-footer cel-button")
	WebElement runReportButton;

    
    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement mathTxt;
    
    @FindBy ( xpath = "//dd" )
    WebElement dateTxt;

    @FindBy ( css = "dl.detail-row.info dt:nth-child(1)" )
    WebElement districtTxt;

    @FindBy ( css = "span.list-head.ml-2" )
    WebElement selectedOptionTxt;
    
    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> selectedOptions;
    
    @FindBy ( css = "dl.detail-row.legends" )
    List<WebElement> legendOptions;
    
    @FindBy ( css = "dl.detail-row.info dd:nth-child(2)" )
    WebElement districtName;
    
    @FindBy ( css = "h2.header" )
    WebElement reportHeader;
    
    @FindBy ( css = "dl.detail-row.legends dt" )
    List<WebElement> legendKeys;

    @FindBy ( css = "dl.detail-row.legends dd" )
    List<WebElement> LegendValues;
    
    @FindBy ( css = "tr.header th" )
    List<WebElement> columnHeaders;
    
    @FindBy ( css = "table tbody tr" )
    List<WebElement> rowValues;
    
    @FindBy ( css = "cel-button.next-btn" )
    WebElement nextBtnRoot;
    
    @FindBy ( css = "div.error p.header" )
    WebElement zeroStateMessage;
    
    @FindBy ( css = "span.pagination-text-suffix" )
    WebElement totalPageCount;
    
    @FindBy ( css = "dl.detail-row.info dd:nth-child(4)" )
    WebElement gradeValue;
    
    @FindBy ( css = "dl.detail-row.info dt:nth-child(3)" )
    WebElement gradeTxt;

    // ****Child Elements****
    private String columnValue = "td:nth-of-type(%s)";


	@FindBy(css = "export-data-modal cel-modal.export-data-modal")
	WebElement btnExportCSVGrantRoot;

	@FindBy(css = "h2.student-name")
	WebElement studentUsername;

	// ****Child Elements****
	private String button = "button.button";
	private String performanceByStrandReportSubHeader = "thead>tr.header th";
	private String performanceByStrandReportSubHeaderChild = "thead>tr.sub-header th";
	private String areaForGrowthSubMainHeaders = ".rectangle-for-subheading span";
	private String areaForGrowthReportSubHeaderChild = "thead>tr.header th";
	private String btnExportCSVRoot = "cel-button";
	private String btnExportCSV = "button";
	public String performanceStrand =".spr-performance-by-strand-grid tbody tr div.cell-data";

	/**
	 * Constructor to invoke the report component
	 * 
	 * @param driver
	 */
	public ReportOutputComponent(WebDriver driver) {
		this.driver = driver;
		// Have Topbar here and init
		PageFactory.initElements(driver, this);
	}

	/**
	 * To get Recent Sessions Report page header
	 * 
	 * @return
	 */
	public String getReportPageTitle() {
		Log.message("Getting Report Title in Report Output Page ");
		SMUtils.waitForElement(driver, pageTitle);
		return pageTitle.getText().trim();
	}

	/**
	 * To check the presence of Back button
	 * 
	 * @return
	 */
	public boolean isBackBtnDisplayed() {
		Log.message("Verifying Back button in the pagination is displayed");
		SMUtils.waitForElement(driver, btnBackRoot);
		return SMUtils.isElementPresent(SMUtils.getWebElementDirect(driver, btnBackRoot, button));
	}

	/**
	 * To check the presence of Next button
	 * 
	 * @return
	 */
	public boolean isNextBtnDisplayed() {
		Log.message("Verifying Next button in the pagination is displayed");
		SMUtils.waitForElement(driver, btnNextRoot);
		return SMUtils.isElementPresent(SMUtils.getWebElementDirect(driver, btnNextRoot, button));
	}

	/**
	 * To click back button in pagination
	 * 
	 * @return
	 */
	public boolean clickBackBtn() {
		if (isBackBtnDisplayed()) {
			SMUtils.waitForElement(driver, btnBackRoot);
			String pageNumberBeforeClick = getCurrentPageNumber();
			SMUtils.click(driver, SMUtils.getWebElementDirect(driver, btnBackRoot, button));
			String pageNumberAfterClick = getCurrentPageNumber();
			pageNumberAfterClick.equals(String.valueOf(Integer.parseInt(pageNumberBeforeClick) - 1));
			Log.message("Page is navigated from " + pageNumberBeforeClick + " to " + pageNumberAfterClick);
			return true;
		} else {
			Log.message("The page is not navigated. There is a problem on clicking Back button");
			return false;
		}
	}

	/**
	 * To click next button in pagination
	 * 
	 * @return
	 */
	public boolean clickNextBtn() {
		if (isNextBtnDisplayed()) {
			SMUtils.waitForElement(driver, btnNextRoot);
			String pageNumberBeforeClick = getCurrentPageNumber();
			SMUtils.click(driver, SMUtils.getWebElementDirect(driver, btnNextRoot, button));
			String pageNumberAfterClick = getCurrentPageNumber();
			pageNumberAfterClick.equals(String.valueOf(Integer.parseInt(pageNumberBeforeClick) + 1));
			Log.message("Page is navigated from " + pageNumberBeforeClick + " to " + pageNumberAfterClick);
			return true;
		} else {
			Log.message("The page is not navigated. There is a problem on clicking Next button");
			return false;
		}
	}

	public boolean isenableNextBtn() {
		if (isNextBtnDisplayed()) {
			SMUtils.waitForElement(driver, btnNextRoot);
			String disbaledorenabled = SMUtils.getWebElementDirect(driver, btnNextRoot, button)
					.getAttribute("aria-disabled");
			Log.message("There is a problem on Back button=" + disbaledorenabled);
			if (disbaledorenabled.equalsIgnoreCase("true")) {
				return true;
			}
			return false;
		} else {
			Log.message("There is a problem on Next button");
			return false;
		}
	}

	public boolean isdisableBackBtn() {
		if (isBackBtnDisplayed()) {
			SMUtils.waitForElement(driver, btnBackRoot);
			WebElement backButton = SMUtils.getWebElementDirect(driver, btnBackRoot, button);
			Log.message("a=" + backButton);
			String disbaledorenabled = backButton.getAttribute("aria-disabled");
			Log.message("There is a problem on Back button=" + disbaledorenabled);
			if (disbaledorenabled.equalsIgnoreCase("true")) {
				return true;
			}
			return false;
		} else {
			Log.message("There is a problem on Back button");
			return false;
		}
	}

	public boolean isDisableOrEnableBtn(String enableordisable, String nextorback) {
		SMUtils.nap(5);
		if (nextorback.equalsIgnoreCase("Back")) {
			SMUtils.waitForElement(driver, btnBackRoot);
			WebElement a = SMUtils.getWebElementDirect(driver, btnBackRoot, button);
			String disbaledorenabled = a.getAttribute("aria-disabled");
			Log.message("Back button=" + disbaledorenabled);
			if (enableordisable.equalsIgnoreCase("enable")) {
				if (disbaledorenabled.equalsIgnoreCase("true"))
					return true;
				else
					return false;
			} else if (enableordisable.equalsIgnoreCase("disable")) {
				if (disbaledorenabled.equalsIgnoreCase("false"))
					return true;
				else
					return false;
			}
			return false;
		} else {
			SMUtils.waitForElement(driver, btnNextRoot);
			WebElement a = SMUtils.getWebElementDirect(driver, btnNextRoot, button);
			String disbaledorenabled = a.getAttribute("aria-disabled");
			Log.message("Next button=" + disbaledorenabled);
			if (enableordisable.equalsIgnoreCase("enable")) {
				if (disbaledorenabled.equalsIgnoreCase("true")) {
					return true;
				} else {
					return false;
				}
			} else if (enableordisable.equalsIgnoreCase("disable")) {
				if (disbaledorenabled.equalsIgnoreCase("true")) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
	}

	/**
	 * To get current page number
	 * 
	 * @return
	 */
	public String getCurrentPageNumber() {
		SMUtils.waitForElement(driver, currentPageNumber);
		Log.message("Getting current page number=" + currentPageNumber.getAttribute("value"));
		return currentPageNumber.getAttribute("value");
	}

	/**
	 * To get the last page
	 * 
	 * @return
	 */
	public String getLastPage() {
		String lastPageNumber = null;
		String regex = "\\d+";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(SMUtils.getTextOfWebElement(totalNumberOfPages, driver));
		while (matcher.find()) {
			lastPageNumber = matcher.group() + "";
		}
		Log.message("Last page number captured from UI is " + SMUtils.getTextOfWebElement(totalNumberOfPages, driver));
		Log.message("Last page number is " + lastPageNumber);
		return lastPageNumber;
	}

	/**
	 * To verify the pagination text
	 * 
	 * @return
	 */
	public boolean verifyPaginationText() {
		Log.message("Verifying pagination text");
		SMUtils.waitForElement(driver, currentPageNumber);
		String totalPage = SMUtils.getTextOfWebElement(paginationText.get(1), driver).split(" ")[1];
		String prefix = SMUtils.getTextOfWebElement(paginationText.get(0), driver);
		String suffix = SMUtils.getTextOfWebElement(paginationText.get(1), driver);

		return String.format(ReportsUIConstants.PAGINATION_TEXT, totalPage).equals(prefix + suffix);
	}

	public int totalPageNo() {
		Log.message("Verifying total page");
		SMUtils.waitForElement(driver, currentPageNumber);
		String totalPage = SMUtils.getTextOfWebElement(paginationText.get(1), driver).split(" ")[1];
		int totalpageno = Integer.parseInt(totalPage);
		Log.message("totalpageno=" + totalpageno);
		SMUtils.nap(5);
		return totalpageno;
	}

	/**
	 * This method is used to enter the page number and navigate to that page
	 * 
	 * @param pageNumber
	 * @return
	 */
	public boolean goToPage(int pageNumber) {
		Log.message("Navigating to the given page number");
		SMUtils.waitForElement(driver, currentPageNumber);
		currentPageNumber.clear();
		currentPageNumber.sendKeys(String.valueOf(pageNumber));
		currentPageNumber.sendKeys(Keys.ENTER);
		SMUtils.nap(5);
		currentPageNumber.sendKeys(Keys.ENTER);
		return getCurrentPageNumber().equals(String.valueOf(pageNumber));
	}

	public boolean goToPageNonNumber(String pageNumber) {
		Log.message("Navigating to the given page number with String values");
		SMUtils.waitForElement(driver, currentPageNumber);
		currentPageNumber.clear();
		currentPageNumber.sendKeys(pageNumber);
		return noPageNumber.getText().equals("Numbers Only");
	}

	public boolean goToPageInvalidNumber(int pageNumber) {
		Log.message("Enter Invalid page number");
		SMUtils.waitForElement(driver, currentPageNumber);
		currentPageNumber.clear();
		currentPageNumber.sendKeys(String.valueOf(pageNumber));
		return noPageNumber.getText().equals("Invalid");
	}

	public boolean goToNoPage() {

		Log.message("No page no is enter");
		SMUtils.waitForElement(driver, currentPageNumber);
		currentPageNumber.clear();
		currentPageNumber.sendKeys(Keys.ENTER);
		SMUtils.nap(5);

		return noPageNumber.getText().equals("Required");

	}

	/**
	 * To get the name of an assignment
	 * 
	 * @return
	 */
	public boolean isAssignmentNameDisplyed() {
		Log.message("Verifying the presence of an assignment name");
		SMUtils.waitForElement(driver, assignmentName);
		return SMUtils.isElementPresent(assignmentName);
	}

	/**
	 * To get the name of an assignment
	 * 
	 * @return
	 */
	public String getAssignmentName() {
		Log.message("Getting an assignment name");
		SMUtils.waitForElement(driver, assignmentName);
		return SMUtils.getTextOfWebElement(assignmentName, driver);
	}

	/**
	 * To get the header of Report Run
	 * 
	 * @return
	 */
	public String getReportRunHeader() {
		Log.message("Getting Report Run header");
		SMUtils.waitForElement(driver, headerReportRun);
		return SMUtils.getTextOfWebElement(headerReportRun, driver);
	}

	/**
	 * To get the info row header
	 * 
	 * @return
	 */
	public List<String> getInfoHeader() {
		Log.message("Getting the headers of School, Teacher, Grade and Group");
		SMUtils.waitForElement(driver, headerReportRun);
		return headersRowInfo.stream().map(element -> SMUtils.getTextOfWebElement(element, driver))
				.collect(Collectors.toList());
	}

	/**
	 * To get the header of Selected Options
	 * 
	 * @return
	 */
	public String getSelectedOptionHeader() {
		Log.message("Getting Selected Options header");
		SMUtils.waitForElement(driver, headerSelectedOptions);
		return SMUtils.getTextOfWebElement(headerSelectedOptions, driver);
	}

	/**
	 * To get the values of Selected Options
	 * 
	 * @return
	 */
	public List<String> getSelectedOptionValues() {
		Log.message("Getting the values of Selected Options");
		SMUtils.waitForElement(driver, headerReportRun);
		return valuesSelectedOptions.stream().map(element -> SMUtils.getTextOfWebElement(element, driver))
				.collect(Collectors.toList());
	}

	/**
	 * To get the status whether back button is enabled
	 */
	public boolean getTheBackButtonStatus() {
		Log.message("Get the status of the back button");
		return SMUtils.getWebElementDirect(driver, btnBackRoot, button).isEnabled();
	}

	/**
	 * To get the status whether back button is enabled
	 */
	public boolean getThNextButtonStatus() {
		Log.message("Get the status of the Next button");
		return SMUtils.getWebElementDirect(driver, btnNextRoot, button).isEnabled();
	}

	/**
	 * To verify the zero state
	 */
	public boolean getTheZeroStateOfSPR() {
		return SMUtils.getTextOfWebElement(zeroStateSPR, driver).equals("No data to display");
	}

	/**
	 * To get all the different IP values
	 */
	public Map<String, String> getIpLevels() {
		List<String> ipValues = new ArrayList<>();
		Map<String, String> ipHashMap = new HashMap<>();
		initialPlacementValues.forEach(element -> ipValues.add(SMUtils.getTextOfWebElement(element, driver)));
		IntStream.range(0, ReportsUIConstants.INITIAL_PLACEMENT_CONSTANTS.size()).forEach(element -> ipHashMap
				.put(ReportsUIConstants.INITIAL_PLACEMENT_CONSTANTS.get(element), ipValues.get(element)));
		return ipHashMap;
	}

	/**
	 * To get title of Performance by Strand - Cumulative
	 */
	public boolean isPerformanceByStrandCumulativeTitleAsExpected() {
		return SMUtils.getTextOfWebElement(performanceByStrandCumulative, driver)
				.equals(ReportsUIConstants.PERFORMANCE_BY_STRAND_CUMULATIVE);
	}

	public boolean isPerformanceSummaryTitleAsExpected() {
		return SMUtils.getTextOfWebElement(performanceSummaryText, driver).equals(ReportsUIConstants.PERFORMANCE_SUMMARY);
	}

	/**
	 * General method for the Performance by Strand - Cumulative table
	 */
	public int toValidatePerformanceByStrandSection(String elmentToBeExtractedFromUI, String childElement) {
		List<String> listOfValues = new ArrayList<>();
		performanceByStrand.stream().distinct()
				.forEach(element -> Optional
						.ofNullable(SMUtils.getTextOfWebElement(
								element.findElement(By.cssSelector(performanceByStrandReportSubHeader)), driver))
						.filter(elementText -> elementText.equalsIgnoreCase(elmentToBeExtractedFromUI))
						.ifPresent(elementText -> {
							if (elementText.equals(elmentToBeExtractedFromUI)) {
								List<WebElement> chileElementToBeExtractedFromUI = element
										.findElements(By.cssSelector(childElement));
								chileElementToBeExtractedFromUI.forEach(finalElement -> {
									listOfValues.add(SMUtils.getTextOfWebElement(finalElement, driver));
								});
							}
						}));
		return listOfValues.size();
	}

	public String getperformanceByStrandReportSubHeaderChild() {
		return this.performanceByStrandReportSubHeaderChild;
	}

	/**
	 * To get title of Areas For Growth - Since IP
	 */
	public boolean isAreasForGrowthTitleAsExpected() {
		return SMUtils.getTextOfWebElement(areasForGrowthTitle, driver)
				.equals(ReportsUIConstants.AREAS_FOR_GROWTH_SINCE_IP);
	}

	
	/**
	 * To get title of Areas For Growth - 24 weeks
	 */
	public boolean isAreasForGrowthTitlefor24Weeks() {
		return SMUtils.getTextOfWebElement(areasForGrowthTitle, driver)
				.equals(ReportsUIConstants.AREAS_FOR_GROWTH_24_WEEKS);
	}


	/**
	 * To get title of Areas For Growth - 24 weeks
	 */
	public boolean isAreasForGrowthTitlefor16Weeks() {
		return SMUtils.getTextOfWebElement(areasForGrowthTitle, driver)
				.equals(ReportsUIConstants.AREAS_FOR_GROWTH_16_WEEKS);
	}

	
	/**
	 * General method for the Areas For Growth table
	 */
	public int toValidateAreaForGrowthSection(String elmentToBeExtractedFromUI, String childElement) {
		List<String> listOfValues = new ArrayList<>();
		areaForGrowth.stream().distinct()
				.forEach(element -> Optional
						.ofNullable(SMUtils.getTextOfWebElement(
								element.findElement(By.cssSelector(areaForGrowthSubMainHeaders)), driver))
						.filter(elementText -> elementText.equalsIgnoreCase(elmentToBeExtractedFromUI))
						.ifPresent(elementText -> {
							SMUtils.scrollDownIntoViewElement(driver, element);
							if (elementText.equals(elmentToBeExtractedFromUI)) {
								List<WebElement> chileElementToBeExtractedFromUI = element
										.findElements(By.cssSelector(childElement));
								chileElementToBeExtractedFromUI.forEach(finalElement -> listOfValues
										.add(SMUtils.getTextOfWebElement(finalElement, driver)));
							}
						}));
		return listOfValues.size();
	}

	public String getAreaForGrowthReportSubHeaderChild() {
		return this.areaForGrowthReportSubHeaderChild;
	}

	public String buildTableDataLocator(String locatorNumber) {
		String areasOfGrowthFirstColumn = "tbody>tr>td:nth-of-type(" + locatorNumber + ")";
		return areasOfGrowthFirstColumn;
	}

	/**
	 * To click the Export csv button
	 * 
	 * @return
	 */
	public ExportPopupComponent clickExportCSVButton() {
		try {
			SMUtils.waitForSpinnertoDisapper(driver, 30);
		} catch (InterruptedException e2) {
			Log.message("Issue in Spinner loading");
		}
		SMUtils.waitForElement(driver, btnExportCSVGrantRoot, 30);
		SMUtils.click(driver,
				SMUtils.getWebElementDirect(driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV));
		ExportPopupComponent exportPopupComponent = null;
		try {
			SMUtils.waitForSpinnertoDisapper(driver, 50);
			SMUtils.waitForElement(driver, btnExportCSVGrantRoot, 30);
			SMUtils.click(driver,
					SMUtils.getWebElementDirect(driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV));
			exportPopupComponent = new ExportPopupComponent(driver).get();
		} catch (Exception e) {
			try {
				Log.message("Getting issue while clicking the csv button...Retrying!!!" + e);
				SMUtils.clickJS(driver,
						SMUtils.getWebElementDirect(driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV));
				exportPopupComponent = new ExportPopupComponent(driver).get();
			} catch (Exception e1) {
				Log.fail("Getting issue while clicking the csv button..." + e1);
			}
		}
		return exportPopupComponent;
	}



	public boolean isPerformanceSummaryDislayed() {
		try {
			return performanceSummary.isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}
	
	public boolean isPerformanceByStrandDisplayed() {
		try {
			return performanceByStrandCumulative.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean isAreaForGrowthDisplayed() {
		try {
			return areasForGrowthTitle.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
	
	

    /**
     * To check the Export csv button is visible or not
     * 
     * @return
     */
    public boolean isExportCSVIconVisible() {
        SMUtils.waitForElement( driver, btnExportCSVGrantRoot, 30 );
        return SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ).isDisplayed();
    }
    
    
    /**
     * To get the Student user Name from Output
     * 
     * @return
     */
    public String getStudentUserName() {
        SMUtils.waitForElement( driver, studentUsername, 10 );
        return studentUsername.getText();
    }
    
    
    /**
     * To get the Subject label from Output
     * 
     * @return
     */
    public String getSubjectLabel() {
        SMUtils.waitForElement( driver, mathTxt, 30 );
        String reportWebElement = SMUtils.getTextOfWebElement( mathTxt, driver );
        return reportWebElement;
    }

    /**
     * To get the Date label from Output
     * 
     * @return
     */
    public String getDateLabel() {
        String timeZoneWebElement = SMUtils.getTextOfWebElement( dateTxt, driver ).substring( 0, 8 );
        return timeZoneWebElement;
    }

    
    /**
     * To get the District label from Output
     * 
     * @return
     */
    public String getDistrictLabel() {
        String districtWebElement = SMUtils.getTextOfWebElement( districtTxt, driver );
        return districtWebElement;
    }

    
    /**
     * To get the Selected Options label from Output
     * 
     * @return
     */
    public String getSelectedOptionLabel() {
        String textOfWebElement = SMUtils.getTextOfWebElement( selectedOptionTxt, driver );
        return textOfWebElement;
    }
    
    
    /**
     * To get Date and Time
     * 
     * @return
     */
    public String dateAndTime() {
        SimpleDateFormat formatter = new SimpleDateFormat( "MM/dd/yy" );
        Date date = new Date();
        Log.message( "Date: "+  formatter.format( date ));
        return formatter.format( date );

    }

    /**
     * To get the Selected Legend option from Output
     * 
     * @return
     */
    public List<String> getSelectedOptionsLegend() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Log.message( "Getting the all the selectced options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( selectedOptions );
        return allTextFromWebElementList;

    }

    /**
     * To get all the Selected Legend option from Output
     * 
     * @return
     */
    public List<String> getLegendOptions() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( legendOptions ) );
        Log.message( "Getting the all the legend options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( legendOptions );
        return allTextFromWebElementList;
    }
    
    /**
     * To get District name
     * 
     * @return
     * @throws InterruptedException
     */
    public String getDistrictName() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, districtName );
        return districtName.getText().trim();
    }
    
    /**
     * To verify the Legend values
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean verifyLegend() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader );
        return legendKeys.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ).equals( CPAReport.LEGEND_KEYS )
                && LegendValues.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ).equals( CPAReport.LEGEND_VALUES );
    }
    
    /**
     * To get the column headers
     *
     * @return
     */
    public List<String> getColumnHeaders() {

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );

        wait.until( ExpectedConditions.visibilityOfAllElements( columnHeaders ) );
        Log.message( "Getting all the column headers..." );
        return SMUtils.getAllTextFromWebElementList( columnHeaders );
    }
    
    
    /**
     * To verify the pagination
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean verifyPagination() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportHeader );
        List<String> list = paginationText.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
        return ( list.get( 0 ) + list.get( 1 ) ).equals( String.format( ReportsUIConstants.PAGINATION_TEXT, "1" ) );
    }
    
    
    /**
     * To get UI grid values
     * 
     * @return
     */
    public boolean sortAndCompareColumnvalues( String columnName ) {
        SMUtils.waitForElement( driver, reportHeader );
        List<String> columnValueList = new ArrayList<>();

        rowValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.SORT_CPAR.indexOf( columnName ) + 1 ) ) );
            IntStream.range( 0, columnData.size() ).forEach( itr -> {
                if ( !columnData.get( itr ).getText().trim().equals( "NA" ) ) {
                    columnValueList.add( columnData.get( itr ).getText().trim() );
                }
            } );
        } );

        if ( columnName.equals( ReportsUIConstants.SORT_CPAR.get( 0 ) ) ) {
            List<String> expList = new ArrayList<>();
            columnValueList.stream().filter( txt -> txt.contains( "K - " ) ).forEach( value -> expList.add( value ) );
            IntStream.rangeClosed( 1, columnValueList.size() ).forEach( itr -> {
                columnValueList.stream().filter( text -> text.contains( "G" + itr + " " ) ).forEach( value -> expList.add( value ) );
            } );
            Log.message( "expList: " + expList );
            Log.message( "columnValueList: " + columnValueList );
            return columnValueList.containsAll( expList );
        } else {
            Log.message( "Sorted: "  + columnValueList.stream().sorted( String.CASE_INSENSITIVE_ORDER ).collect( Collectors.toList()));
            Log.message( "Not Sorted: " + columnValueList );
            return columnValueList.stream().sorted( String.CASE_INSENSITIVE_ORDER ).collect( Collectors.toList() ).containsAll( columnValueList );
        }
    }
    
    
    /**
     * To get all the grade values from report table
     * 
     * @return
     * @throws InterruptedException
     */
    public List<String> getGradeValues() throws InterruptedException {

        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, nextBtnRoot );
        List<String> subHeaderValues = new ArrayList<>();
        if ( !getZeroStateMessage() ) {
            IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
                subHeaderValues.add( gradeValue.getText().trim() );
                WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
                if ( nextBtn.isEnabled() ) {
                    SMUtils.click( driver, nextBtn );
                }
            } );
        }
        return subHeaderValues;
    }
    
    /**
     * To get the Grade label from ReportViewer
     * 
     * @return
     */
    public String getGradeLabel() {

        String districtWebElement = SMUtils.getTextOfWebElement( gradeTxt, driver );
        return districtWebElement;
    }
    
    /**
     * To get the zero state message
     * 
     * @return
     */
    public boolean getZeroStateMessage() {
        try {
            SMUtils.waitForElement( driver, zeroStateMessage );
            return zeroStateMessage.getText().trim().equals( ReportsUIConstants.NO_DATA_TO_DISPLAY );
        } catch ( Exception e ) {
            return false;
        }
    }
    
}
