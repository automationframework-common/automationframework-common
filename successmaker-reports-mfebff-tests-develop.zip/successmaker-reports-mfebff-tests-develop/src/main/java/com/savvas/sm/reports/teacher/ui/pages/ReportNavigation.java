package com.savvas.sm.reports.teacher.ui.pages;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

public class ReportNavigation {
    private final WebDriver driver;
    // ********* SuccessMaker Launcher/Login Page Elements ***************

    @FindBy ( tagName = "side-nav-bar" )
    WebElement smSideNav;

    @FindBy ( css = "cel-side-navigation[class='side-nav-bar hydrated']" )
    WebElement sideNavigationRoot;

    @FindBy ( css = "cel-platform-navbar.hydrated" )
    public WebElement topNavBarwithShadow;

    @FindBy ( css = "cel-side-item.border-bottom.hydrated" )
    public WebElement topNavReportsMenuCSSSelector;

    // ****Child Elements****
    private String childSubNavigationMenu = "cel-side-item";
    private String childSubNavigationButton = "button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public ReportNavigation( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    // ****Child Elements****

    private String allReportSubMenuItemCSSSelector = "span.button-label";
    private String reportsMenuItemsCSSSelectorwithShadow = "cel-dropdown-menu-box.hydrated";

    private void clickSubNavigation( String reportType ) {
        SMUtils.waitForElement( driver, sideNavigationRoot, 5 );

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );

        List<WebElement> list = SMUtils.getWebElements( driver, sideNavigationRoot, childSubNavigationMenu );
        list.forEach( eachElement -> {
            WebElement reportElement = SMUtils.getWebElement( driver, eachElement, childSubNavigationButton );
            if ( reportElement.getText().equals( reportType ) ) {
                wait.until( ExpectedConditions.elementToBeClickable( reportElement ) );
                SMUtils.clickJS( driver, reportElement );
            }
        } );
    }

    public AreaForGrowthReportPage clickAreaForGrowthPage() {
        Log.message( "Clicking on the Areas For Growth element in sub-navigation" );
        clickSubNavigation( ReportTypes.AREAS_FOR_GROWTH );
        return new AreaForGrowthReportPage( driver ).get();
    }

    public StudentPerformanceReportsPages clickStudentPerformancePage() {
        Log.message( "Clicking on the Student Performance element in sub-navigation" );
        clickSubNavigation( ReportTypes.STUDENT_PERFORMANCE );
        return new StudentPerformanceReportsPages( driver ).get();
    }

    public StudentPerformanceReportsPages clickCumulativePerformanceReportPage() {
        Log.message( "Clicking on the Cumulatative Performance element in sub-navigation" );
        clickSubNavigation( ReportTypes.CUMULATIVE_PERFORMANCE );
        return new StudentPerformanceReportsPages( driver ).get();
    }

    public boolean subNavigationMenuisDisplayed( String reportType ) {
        Log.message( "Verifing the sub-navigation " + reportType + " is displayed" );
        SMUtils.waitForElement( driver, sideNavigationRoot );
        List<WebElement> list = SMUtils.getWebElements( driver, sideNavigationRoot, childSubNavigationMenu );
        AtomicBoolean result = new AtomicBoolean( false );
        list.forEach( eachElement -> {
            WebElement reportElement = SMUtils.getWebElement( driver, eachElement, childSubNavigationButton );
            if ( reportElement.getText().equals( reportType ) ) {
                boolean displayed = reportElement.isDisplayed();
                result.set( ( displayed ) );
            }
        } );
        return result.get();
    }

    public CumulativePerformanceReportPage clickOnCumulativePerformanceReportPage() {
        Log.message( "Clicking on the Cumulative Performance element in sub-navigation" );
        clickSubNavigation( ReportTypes.CUMULATIVE_PERFORMANCE );
        SMUtils.nap( 10 );
        return new CumulativePerformanceReportPage( driver ).get();
    }

}
