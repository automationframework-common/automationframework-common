package com.savvas.sm.reports.exportcsv.admin.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.CPARExportCSVConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;

import io.restassured.response.Response;

public class CPARReportBFFAdminExportCSV extends EnvProperties {
    private static String smUrl;
    private static String browser;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    private String districtAdminDetails = null;
    String bearerToken;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        distId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        //District Admin

        districtAdminDetails = ReportDataCollection.districtAdminDetails;
        Log.message( "********" );
        distAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        distAdminuserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        selectedSchoolId = ReportDataCollection.orgId;
        bearerToken = new RBSUtils().getAccessToken( distAdminUserName, password );
    }

    @Test ( dataProvider = "getData", groups = { "Admin_Dashboard", "SMK-66712", "Admin dashboard CPR Export CSV", "API" }, priority = 1 )
    public void adminCPRExportCSVTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );
        Dashboard dashboard = new Dashboard();
        Map<String, String> headers = new HashMap<>();
        Response response = null;
        String requestId = null;
        Map<String, Object> saveReportOptionalFilters = new HashMap<>();
        Map<String, Object> optionalFilter = new HashMap<>();
        Response saveAdminCPReportOptionResponse = null;
        String exportType = "default";
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + bearerToken );
        headers.put( Constants.ORGID_SM_HEADER, distId );
        headers.put( Constants.USERID_SM_HEADER, distAdminuserId );

        switch ( scenarioType ) {
            case "MATH":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

            case "CUSTOM_EXPORT_MATH":
                exportType = "custom";
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), exportType, requestId, "01/23/23 - 11:31 AM", Constants.MATH, CPARExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS, optionalFilter );
                break;

            case "READING":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;

            case "CUSTOM_EXPORT_READING":
                exportType = "custom";
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), exportType, requestId, "01/23/23 - 11:31 AM", Constants.READING, CPARExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS, optionalFilter );
                break;

            case "ADDITIONAL_GROUPING":
                saveReportOptionalFilters.put( "additionalGrouping", "GRADE" );
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                optionalFilter.put( "additionalGrouping", 1 );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

            case "INVALID_AUTHORIZATION":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + "invalidToken" );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

            case "LIMITED_HEADERS":
                exportType = "custom";
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                List<String> filters = Arrays.asList( CPARExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS.get( 0 ), CPARExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS.get( 1 ), CPARExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS.get( 2 ) );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), exportType, requestId, "01/23/23 - 11:31 AM", Constants.MATH, filters, optionalFilter );
                break;

            case "NO_HEADERS":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + "" );
                headers.put( Constants.ORGID_SM_HEADER, "" );
                headers.put( Constants.USERID_SM_HEADER, "" );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

            case "INVALID_USER_ID_HEADER":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                headers.put( Constants.USERID_SM_HEADER, "invalidUserId" );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "INVALID_ORG_ID_HEADER":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                headers.put( Constants.ORGID_SM_HEADER, "invalidOrgId" );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

            case "INVALID_USER_ID_REQUEST_BODY":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                headers.put( Constants.USERID_SM_HEADER, "invalidUserId" );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

            case "INVALID_ORG_ID_REQUEST_BODY":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPAReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                headers.put( Constants.USERID_SM_HEADER, "invalidUserId" );
                response = AdminReportCsv.postCPARExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;

        }

        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

        if ( !scenarioType.contains( "INVALID_AUTHORIZATION" ) && !scenarioType.contains( "NO_HEADERS" ) && !scenarioType.contains( "LIMITED_HEADERS" ) && !scenarioType.contains( "INVALID" ) ) {
            //Verifying Request Id in the upload url and signed Url
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );

            //To get the CSV File
            String csvDataFromBS = null;
            // Get driver
            final WebDriver driver = WebDriverFactory.get( browser );
            try {
                driver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            } catch ( Exception e ) {
                Log.message( "Getting Exception while download the csv file!!!!!" );
            } finally {
                driver.quit();
            }

            Log.assertThat( DevToolsUtils.countLines( csvDataFromBS ) > 0, "Record count is greater than zero", "Record count is zero" );
            Log.assertThat( checkHeader( csvDataFromBS, scenarioType ), "Expected Header is present", "Expected Header is not present" );
            Log.assertThat( countColumn( csvDataFromBS ) > 0, "Column count is " + countColumn( response.getBody().toString() ), "Expected column is not present" );
        } else if ( scenarioType.contains( "LIMITED_HEADERS" ) ) {
            //Verifying Request Id in the upload url and signed Url
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );

            //To get the CSV File
            String csvDataFromBS = null;
            // Get driver
            final WebDriver driver = WebDriverFactory.get( browser );
            try {
                driver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            } catch ( Exception e ) {
                Log.message( "Getting Exception while download the csv file!!!!!" );
            } finally {
                driver.quit();
            }
            Log.assertThat( csvDataFromBS.contains( ReportsAPIConstants.CUSTOM_CSV_HEADERS_CPAR ), "Report Headers value are fetched as expected", "Report Headers value are not fetched as expected" );
        }
    }

    @DataProvider
    public Object[][] getData() {
        Object[][] data = { { "TC:01", "200", "(Admin - CPAR - Default export API) Verify the status code and csv headers (column name) in the response, for Default Export - Math Subject ", "MATH" },
                { "TC:02", "200", "(Admin - CPAR - Default export API) Verify the status code and csv headers (column name) in the response, for Default Export - Reading Subject ", "READING" },
                { "TC:03", "200", "(Admin - CPAR - Custom export API) Verify the status code and csv headers (column name) in the response, for Custom Export - Math Subject ", "CUSTOM_EXPORT_MATH" },
                { "TC:04", "200", "(Admin - CPAR - Custom export API) Verify the status code and csv headers (column name) in the response, for Custom Export - Reading Subject ", "CUSTOM_EXPORT_READING" },
                { "TC:05", "200", "(Admin - CPAR - Default export API) Verify the status code and response when passing (Grade) id in additionalGrouping", "ADDITIONAL_GROUPING" },
                { "TC:06", "401", "(Admin - CPAR - Default export API)  Verify the status code and response if pass the invalid bearer token.", "INVALID_AUTHORIZATION" },
                { "TC:07", "200", "(Admin - CPAR - Default export API) Verify the status code and csv headers (column name) in the response, for Default Export - Math Subject when only few headers are requested in payload", "LIMITED_HEADERS" },
                { "TC:08", "400", "(Admin - CPAR - Default export API) Verify the status code when NO headers are requested in payload", "NO_HEADERS" },
                { "TC:09", "200", "(Admin - CPAR - Default export API)  Verify the status code and response if pass the invalid User ID in header", "INVALID_USER_ID_HEADER" },
                { "TC:10", "200", "(Admin - CPAR - Default export API)  Verify the status code and response if pass the invalid Org ID in header", "INVALID_ORG_ID_HEADER" },
                { "TC:11", "200", "(Admin - CPAR - Default export API)  Verify the status code and response if pass the invalid User ID in Request Body", "INVALID_USER_ID_REQUEST_BODY" },
                { "TC:12", "200", "(Admin - CPAR - Default export API)  Verify the status code and response if pass the invalid Org ID in Request Body", "INVALID_ORG_ID_REQUEST_BODY" }

        };
        return data;
    }

    public boolean checkHeader( String str, String Scenario ) {
        if ( Scenario.contains( "CUSTOM" ) ) {
            return str.contains( ReportsAPIConstants.CUSTOM_CSV_HEADERS_CPAR );
        } else
            return str.contains( ReportsAPIConstants.DEFAULT_CSV_HEADERS_CPAR );
    }

    public int countColumn( String str ) {
        String[] lines = str.split( "\r\n|\r|\n" );
        return lines[0].split( "," ).length;
    }

}