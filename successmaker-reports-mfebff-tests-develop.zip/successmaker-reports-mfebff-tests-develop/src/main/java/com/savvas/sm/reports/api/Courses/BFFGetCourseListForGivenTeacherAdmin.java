package com.savvas.sm.reports.api.Courses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.CourseList;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class BFFGetCourseListForGivenTeacherAdmin extends ReportAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String flexteacherDetails = null;
    private String mathSchoolTeacherDetails = null;
    private String readingSchoolTeacherDetails = null;
    private String mathFocusSchoolTeacherDetails = null;
    private String readingFocusSchoolTeacherDetails = null;
    public Boolean result = null;
    //private String teacherDetails3 = null;
    private String flexschool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String mathschool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String readingschool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String mathfocuschool = RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL );
    private String readingfocuschool = RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL );

    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String accessToken;
    RBSUtils rbs = new RBSUtils();
    public String flexuserId;
    public String username;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    //public String courseID;
    public String flexstudentID;
    public String mathStudentID;
    public String readingStudentID;
    public String mathfocusStudentID;
    public String readingFocusStudentID;
    public String classId;
    public String classId1;
    public String classId2;
    public String classId3;
    public String orgId;
    public String createTeacher;
    HashMap<String, String> assignCourseToTheStudent = new HashMap<String, String>();
    public static String duplicateClassId;
    List<String> classIds = new ArrayList<>();
    List<String> multiOrgAclassIds = new ArrayList<>();
    List<String> multiOrgBclassIds = new ArrayList<>();
    GroupAPI grpApi = new GroupAPI();
    public String adminToken;
    public static List<String> orgIDs = new ArrayList<String>();

    @BeforeTest
    public void BeforeSuite() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        flexteacherDetails = RBSDataSetup.getMyTeacher( flexschool );
        mathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( mathschool );
        readingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingschool );
        mathFocusSchoolTeacherDetails = RBSDataSetup.getMyTeacher( mathfocuschool );
        readingFocusSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingfocuschool );
        //  flexstudentID = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( flexschool, SMUtils.getKeyValueFromResponse( flexteacherDetails, CommonAPIConstants.USER_NAME ) ), Constants.USERID_HEADER );
        mathStudentID = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( mathschool, SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, Constants.USER_NAME ) ), Constants.USERID_HEADER );
        readingStudentID = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( readingschool, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, Constants.USER_NAME ) ), Constants.USERID_HEADER );
        mathfocusStudentID = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( mathfocuschool, SMUtils.getKeyValueFromResponse( mathFocusSchoolTeacherDetails, Constants.USER_NAME ) ), Constants.USERID_HEADER );
        readingFocusStudentID = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( readingfocuschool, SMUtils.getKeyValueFromResponse( readingFocusSchoolTeacherDetails, Constants.USER_NAME ) ), Constants.USERID_HEADER );

        flexuserId = SMUtils.getKeyValueFromResponse( flexteacherDetails, Constants.USERID_HEADER );
        //   username = SMUtils.getKeyValueFromResponse( flexteacherDetails, CommonAPIConstants.USER_NAME );
        orgId = RBSDataSetup.organizationIDs.get( flexschool );

        HashMap<String, String> classDetails = new HashMap<>();
        List<String> stuIDs1 = new ArrayList<String>();
        stuIDs1.add( flexstudentID );
        String className = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( GroupConstants.GROUP_OWNER_ID, flexuserId );
        classDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        classDetails.put( GroupConstants.GROUP_NAME, className );
        HashMap<String, String> c = grpApi.createGroup( smUrl, classDetails, stuIDs1 );
        classId = SMUtils.getKeyValueFromResponse( grpApi.createGroup( smUrl, classDetails, stuIDs1 ).get( CommonAPIConstants.BODY ), "data,groupId" );

        HashMap<String, String> classDetails1 = new HashMap<>();
        List<String> stuIDs2 = new ArrayList<String>();
        stuIDs2.add( mathStudentID );
        String className1 = "Test Class OrgA" + System.nanoTime();
        classDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails1.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, Constants.USERID_HEADER ) );
        classDetails1.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathschool ) );
        classDetails1.put( GroupConstants.GROUP_NAME, className1 );
        classId1 = SMUtils.getKeyValueFromResponse( grpApi.createGroup( smUrl, classDetails1, stuIDs2 ).get( CommonAPIConstants.BODY ), "data,groupId" );

        HashMap<String, String> classDetails2 = new HashMap<>();
        List<String> stuIDs3 = new ArrayList<String>();
        stuIDs3.add( readingStudentID );
        String className2 = "Test Class OrgB" + System.nanoTime();
        classDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails2.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, Constants.USERID_HEADER ) );
        classDetails2.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( readingschool ) );
        classDetails2.put( GroupConstants.GROUP_NAME, className2 );
        classId2 = SMUtils.getKeyValueFromResponse( grpApi.createGroup( smUrl, classDetails2, stuIDs3 ).get( CommonAPIConstants.BODY ), "data,groupId" );

        HashMap<String, String> classDetails3 = new HashMap<>();
        List<String> stuIDs4 = new ArrayList<String>();
        stuIDs4.add( mathfocusStudentID );
        String className3 = "Test Class OrgB" + System.nanoTime();
        classDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathFocusSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails3.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathFocusSchoolTeacherDetails, Constants.USERID_HEADER ) );
        classDetails3.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathfocuschool ) );
        classDetails3.put( GroupConstants.GROUP_NAME, className3 );
        classId3 = SMUtils.getKeyValueFromResponse( grpApi.createGroup( smUrl, classDetails3, stuIDs4 ).get( CommonAPIConstants.BODY ), "data,groupId" );

    }

    @Test ( dataProvider = "validCase", groups = { "SMK-50584", "Admin", "Get Group List for Selected Teacher in the Admin", "P1", "API" } )
    public void tcgetGroupListTest01( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> orgIds = new ArrayList<>();
        List<String> stuIDs = new ArrayList<String>();
        HashMap<String, String> apiDetails = new HashMap<>();
        List<String> courseIDs = new ArrayList<String>();
        HashMap<String, String> response;
        String teacherId = null;
        String adminDetails;
        String adminUserId;
        String adminUserName;
        String teacherAccessToken;
        switch ( scenario ) {

            case "ALL_ASSIGNMENTS":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId );
                stuIDs.add( flexstudentID );
                teacherId = flexuserId;
                courseIDs.add( new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, flexuserId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
                courseIDs.add( new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, flexuserId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
                courseIDs.add( new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, flexuserId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, flexuserId );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, orgId );
                break;

            case "SUB_DISTRICT_ADMIN":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId );
                stuIDs.add( flexstudentID );
                teacherId = flexuserId;
                courseIDs.add( new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, flexuserId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, flexuserId );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, orgId );
                break;

            case "MATH_ONLY_ASSIGNMENT":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( RBSDataSetup.organizationIDs.get( mathschool ) );
                stuIDs.add( mathStudentID );
                teacherId = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, Constants.USERID_HEADER );
                courseIDs.add( ReportAPIConstants.CourseList.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, teacherId );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, RBSDataSetup.organizationIDs.get( mathschool ) );
                break;

            case "READING_ONLY_ASSIGNMENT":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_READING );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( RBSDataSetup.organizationIDs.get( readingschool ) );
                stuIDs.add( readingStudentID );
                teacherId = SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, Constants.USERID_HEADER );
                courseIDs.add( ReportAPIConstants.CourseList.DEFAULT_READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, Constants.USERID_HEADER ) );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, RBSDataSetup.organizationIDs.get( readingschool ) );
                break;

            case "FOCUS_ONLY_ASSIGNMENT":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( mathFocusSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( RBSDataSetup.organizationIDs.get( mathfocuschool ) );
                stuIDs.add( mathfocusStudentID );
                teacherId = SMUtils.getKeyValueFromResponse( mathFocusSchoolTeacherDetails, Constants.USERID_HEADER );
                courseIDs.add( ReportAPIConstants.CourseList.FOCUS_MATH_1 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, teacherId );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, RBSDataSetup.organizationIDs.get( mathfocuschool ) );
                break;

            case "FLEX_SCHOOL":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId );
                teacherId = flexuserId;
                stuIDs.add( flexstudentID );
                courseIDs.add( new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, flexuserId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
                courseIDs.add( new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, flexuserId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, flexuserId );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, RBSDataSetup.organizationIDs.get( flexschool ) );
                break;

            case "NO_DUPLICATE_ASSIGNMENT":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( readingFocusSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId );
                teacherId = flexuserId;
                stuIDs.add( flexstudentID );
                courseIDs.add( ReportAPIConstants.CourseList.FOCUS_READING_1 );
                courseIDs.add( ReportAPIConstants.CourseList.FOCUS_READING_1 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( ReportAPIConstants.CourseList.TEACHER_ID, flexuserId );
                assignmentDetails.put( ReportAPIConstants.CourseList.ORG_ID, RBSDataSetup.organizationIDs.get( flexschool ) );
                break;
        }
        // Validation
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, stuIDs, courseIDs );
        response = getCourseList( orgIds, apiDetails, CourseList.LAST_SESSION );
        // Schema Validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getCourseList", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        // Response Code and Values Validation
        Log.assertThat( validateTheAssignmentWithResponse( response, assignAssignment, teacherId, apiDetails.get( Constants.SUBJECT_TYPE_ID ), orgIds ), "AssignmentDetails Matched with the Response", "Error : Assignment Details Not Matched" );
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "validCase" )
    public Object[][] getGroupList() {
        Object[][] inputData = { { "Verify the response returning, all the assignments from the selected school.", "ALL_ASSIGNMENTS", "200" }, { "Verify the API returning assignmentId in the response", "ALL_ASSIGNMENTS", "200" },
                { "Verify the API returning assignmentTitle in the response", "ALL_ASSIGNMENTS", "200" }, { "Verify the API returning assignerId in the response", "ALL_ASSIGNMENTS", "200" },
                { "Verify the API returning organizationId in the response", "ALL_ASSIGNMENTS", "200" }, { "Verify the API returning organizationName in the response", "ALL_ASSIGNMENTS", "200" },
                { "Verify the API returning assignerFirstName in the response", "ALL_ASSIGNMENTS", "200" }, { "Verify the API returning assignerLastName in the response", "ALL_ASSIGNMENTS", "200" },
                { "Verify the API returning assignerMiddleName in the response", "ALL_ASSIGNMENTS", "200" }, { "Verify the API returning productId in the response", "ALL_ASSIGNMENTS", "200" },
                { "Verify the API returning contentBaseId in the response", "ALL_ASSIGNMENTS", "200" }, { "Verify the API returning productId in the response", "SUB_DISTRICT_ADMIN", "200" },
                { "Verify the admin can able to see Math assignment alone when there is no custom assignment in Math subject", "MATH_ONLY_ASSIGNMENT", "200" },
                { "Verify the admin can see only Reading default assignment when the school licensed with only Reading Subject.", "READING_ONLY_ASSIGNMENT", "200" },
                { "Verify the admin can able to see only Focus assignments when the school having only focus license", "FOCUS_ONLY_ASSIGNMENT", "200" },
                { "Verify the admin can see all assignments from school when the school has flex license.", "FLEX_SCHOOL", "200" },
                { "Verify the admin can see all assignments from school when the school has flex license.", "NO_DUPLICATE_ASSIGNMENT", "200" } };
        return inputData;
    }

    @Test ( dataProvider = "invalidCase", groups = { "SMK-50589", "Admin", "Get Course List for Selected Teacher in the Admin", "P1", "API" } )
    public void tcgetGroupListTest03( String description, String scenario, String statusCode ) throws Exception {
        String errorMessage = null;
        List<String> courseIDs = new ArrayList<String>();
        String teacherId = null;
        String teacherAccessToken;
        List<String> stuIDs = new ArrayList<String>();
        List<String> orgIds = new ArrayList<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        String adminUserName = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        switch ( scenario ) {

            case "INVALID_AUTHORIZATION":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId );
                errorMessage = "UNAUTHORIZED";
                break;

            case "INVALID_INPUT_PARAMETERS":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId + 23 );
                orgIds.add( orgId );
                errorMessage = "404: Not Found";
                break;

            case "INVALID_ORG_ID":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                apiDetails.put( Constants.USERID_HEADER, adminUserId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId + 1 );
                errorMessage = "UNAUTHORIZED";
                break;

            case "INVALID_USERID":
                adminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                accessToken = rbs.getAccessToken( adminUserName, password );
                teacherAccessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( flexteacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                apiDetails.put( Constants.USERID_HEADER, adminUserId + 34 );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, ReportAPIConstants.CourseList.DEFAULT_MATH );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                orgIds.add( orgId );
                errorMessage = "UNAUTHORIZED";
                break;

        }
        // Validation
        HashMap<String, String> response = getCourseList( orgIds, apiDetails, CourseList.LAST_SESSION );
        Log.message( response.toString() );
        Log.assertThat( validateErrorANDExceptionMessage( response, errorMessage, statusCode ), "Status code and Error Message Validated Successfully", "Error : Unexpected Error Message and Status Code" );
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "invalidCase" )
    public Object[][] getGroupList1() {

        Object[][] inputData = { { "Verify the status code 401 and UNAUTHORIZED error message when invalid bearer token is passed in header", "INVALID_AUTHORIZATION", "200" },
                { "Verify the response code as 400 for invalid input parameters", "INVALID_INPUT_PARAMETERS", "200" }, { "Verify the Response for Invalid OrgId id", "INVALID_ORG_ID", "200" },
                { "Verify the Response when Invalid teacher id passed in the teacherIds field", "INVALID_USERID", "200" } };
        return inputData;
    }

    /**
     * Validate the Assignment Details from the Response
     * 
     * @return
     */
    public Boolean validateTheAssignmentWithResponse( HashMap<String, String> response, HashMap<String, String> assignmentResponse, String userId, String subjectTypeId, List<String> orgIds ) {
        Boolean status = false;
        List<String> assignmentId = new ArrayList<>();
        List<String> assignmentName = new ArrayList<>();
        List<String> assignmentIdFromResponse = new ArrayList<>();
        List<String> assignmentNameFromResponse = new ArrayList<>();
        JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
        JSONArray jsonArray = jsonObject.getJSONObject( "data" ).getJSONObject( "getCourseList" ).getJSONArray( "courseList" );
        for ( int iter = 0; iter < jsonArray.length(); iter++ ) {
            if ( jsonArray.getJSONObject( iter ).get( "assignerId" ).toString().equals( userId ) ) {
                assignmentIdFromResponse.add( jsonArray.getJSONObject( iter ).get( Constants.ASSIGNMENT_ID ).toString() );
                assignmentNameFromResponse.add( jsonArray.getJSONObject( iter ).get( "assignmentTitle" ).toString() );
            }
        }
        SqlHelperCourses sqlhelper = new SqlHelperCourses();
        for ( String eachOrg : orgIds ) {
            List<HashMap<String, String>> courseForOrg = sqlhelper.getCourseForOrg( eachOrg, Integer.parseInt( subjectTypeId ) );
            for ( int iter = 0; iter < courseForOrg.size(); iter++ ) {
                if ( courseForOrg.get( iter ).get( "assignment_owner_Id" ).equals( userId ) ) {
                    assignmentName.add( courseForOrg.get( iter ).get( "assignment_title" ) );
                    assignmentId.add( courseForOrg.get( iter ).get( "assignmentId" ) );
                }
            }
        }

        if ( assignmentId.size() == assignmentIdFromResponse.size() && SMUtils.sortList( assignmentId ).equals( SMUtils.sortList( assignmentIdFromResponse ) )
                && ( SMUtils.sortList( assignmentName ).equals( ( SMUtils.sortList( assignmentNameFromResponse ) ) ) ) ) {
            status = true;
            Log.message( "Assignment Details From the Response Are matching as Expected" );
        } else {
            Log.fail( "Assignment Details from the response not matched" );
        }
        return status;
    }

    // Validating the Error Message and Exception
    public Boolean validateErrorANDExceptionMessage( HashMap<String, String> response, String errorMessage, String statusCode ) {
        Boolean status = false;
        String exceptionText = null;
        JSONObject jsonObject = new JSONObject( response.get( CommonAPIConstants.BODY ) );
        JSONArray array = jsonObject.getJSONArray( "errors" );
        exceptionText = array.getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
        if ( exceptionText.equals( errorMessage ) && response.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
            status = true;
        }
        return status;
    }
}
