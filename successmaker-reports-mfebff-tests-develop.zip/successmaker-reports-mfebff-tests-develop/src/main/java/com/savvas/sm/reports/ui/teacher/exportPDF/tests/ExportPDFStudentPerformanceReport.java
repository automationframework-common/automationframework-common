package com.savvas.sm.reports.ui.teacher.exportPDF.tests;

import java.util.Arrays;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.Reports;
import com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.smoke.teacher.pages.StudentPerformanceReport;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

public class ExportPDFStudentPerformanceReport extends EnvProperties {
    AreaForGrowthPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    AreasForGrowthReport afgPage;
    AreasForGrowthReport areasForGrowthReport;
    ReportsViewerPage reportViewerPage;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    String groupID;
    String teacherDetails;
    String browser;
    String username;
    String orgId;
    String teacherId;
    String student1;
    String studentUserName;
    String studentId;
    HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    HashMap<String, String> assignmentIds = new HashMap<>();
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        studentId = SMUtils.getKeyValueFromResponse( student1, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( student1, "userName" );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );

        groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        } catch ( Exception e1 ) {
            Log.message( "Issue in getting access token!!!.Retrying" );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        }

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentId ), Arrays.asList( "1", "2" ) );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        WebDriver driver = WebDriverFactory.get( browser );
        try {
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeMathCourse( studentUserName, "Math", "90", "2", "10" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.message( "Error occured while run the simulator!!!" );
        } finally {
            driver.quit();
        }
        driver = WebDriverFactory.get( browser );
        try {
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeReadingCourse( studentUserName, "Reading", "90", "2", "5" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.message( "Error occured while run the simulator!!!" );
        } finally {
            driver.quit();
        }
    }
  
    @Test ( description = "Verify 'Export PDF' button at the top of the report output screen", groups = { "SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports",  "smoke_test_case"}, priority = 1 )
    public void tcExportReportSPR001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR001: Verify 'Export PDF' button at the top of the report output screen <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
         
            SMUtils.logDescriptionTC( "Verify 'Export PDF' button at the top of the report output screen" );
            Log.assertThat( reportViewerPage.validatePDFIcon(), "PDF icon is displaying", "PDF icon is snot displaying" );
            Log.assertThat( reportViewerPage.getPDFText().equalsIgnoreCase( ReportsUIConstants.PDF_TEXT ), "PDF text is displaying", "PDF text is snot displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user is taken to ' Export Report PDF' Model after clicking the 'Export PDF' button", groups = { "SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports", "smoke_test_case"}, priority = 1 )
    public void tcExportReportSPR002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR002:Verify the user is taken to ' Export Report PDF' Model after clicking the 'Export PDF' button <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            
            SMUtils.logDescriptionTC( "Verify the user is taken to ' Export Report PDF' Model after clicking the 'Export PDF' button" );
            SMUtils.logDescriptionTC( "Verify the title and subtitle names are displayed as below " );
            reportViewerPage.clickOnPDF();
            Log.assertThat( reportViewerPage.validateExportPDFPopUPText().equalsIgnoreCase( ReportsUIConstants.PDF_POP_TEXT ), "Pop up header text is displaying", "Pop up header text is not displaying" );
            Log.assertThat( reportViewerPage.validatePageText().equalsIgnoreCase( ReportsUIConstants.PAGES_TEXT ), "All Pages text is displaying", "All pages text is displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify All Page(s) and current page of two radio button options are displayed below subheader and All Page(s) option radio button is selected as default" );
            Log.assertThat( reportViewerPage.validateCurrentPageText().equalsIgnoreCase( ReportsUIConstants.CURRENT_PAGE_TEXT ), "Current page text is displaying", "Current page text is displaying" );
            Log.assertThat( reportViewerPage.validateAllPageText().equalsIgnoreCase( ReportsUIConstants.ALL_PSGES_TEXT ), "All Pages text is displaying", "All Pages text is displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Cancel and Close button(X) button is displayed in the 'Export PDF File' model ", groups = { "SMK-66277/SMK-69992" , "Teacher Dashboard", "Export Reports",  "smoke_test_case" }, priority = 1 )
    public void tcExportReportSPR003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR003:Verify Cancel and Close button(X) button is displayed in the 'Export PDF File' model <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            
            reportViewerPage.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify Cancel and Close button(X) button is displayed in the 'Export PDF File' model " );
            Log.assertThat( reportViewerPage.validateCancelButton().equalsIgnoreCase( ReportsUIConstants.CANCEL_TEXT ), "Cance button text is displaying", "Cance button text is not displaying" );
            Log.assertThat( reportViewerPage.isCrossIconDisplayed(), "Cross icon is displaying", "Cross icon is not displaying" );
            Log.testCaseResult();
            reportViewerPage.clickCancelButton();
            reportViewerPage.verifyReportPage( driver );
            Log.testCaseResult();

            reportViewerPage.clickOnPDF();
            reportViewerPage.clickCrossIcon();
            reportViewerPage.verifyReportPage( driver );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'", groups = { "SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports", "smoke_test_case" }, priority = 1 )
    public void tcExportReportSPR004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR004:Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            
            reportViewerPage.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'" );
            reportViewerPage.clickOkButton();
            Log.assertThat( reportViewerPage.validateExportPDFPopUPTextForSucces().equalsIgnoreCase( ReportsUIConstants.POP_UP_PDF_FILE ), "Export pdf file text is displaying", "Export pdf file text is displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model" );
            Log.assertThat( reportViewerPage.getSuccessMessage().contains( ReportsUIConstants.DOWNLOADING_TEXT ), "Getting downloading text properly", "Not Getting downloading text properly" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model" );
            Log.assertThat( reportViewerPage.getSuccessMessage().contains( ReportsUIConstants.DOWNLOADING_TEXT_SECOND ), "Getting downloading text properly", "Not Getting downloading text properly" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    @Test ( description = "Verify spinner is showing PDF generation is in-progress and close button on the 'Exporting PDF file' model is disabled", groups = { "SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports",  "smoke_test_case" }, priority = 1 )
    public void tcExportReportSPR005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR005:Verify spinner is showing PDF generation is in-progress and close button on the 'Exporting PDF file' model is disabled<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            
            reportViewerPage.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'" );
            reportViewerPage.clickOkButton();
            reportViewerPage.clickCloseButton();
            SMUtils.logDescriptionTC( "Verify spinner is showing PDF generation is in-progress and close button  'Exporting PDF file' model is disabled" );
            if(!reportViewerPage.verifyCloseButtonEnableOrDisable()) {
                Log.message( "Close button is showing as disabled mode while downloading the pdf" );
            }else {
                Log.message( "Close button is showing as enabled mode" );
            }
            Log.testCaseResult();
           
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
        @Test ( description = "Verify spinner is showing PDF generation is in-progress and CrossButton X on the 'Exporting PDF file' model is disabled", groups = { "SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports" }, priority = 2 )
        public void tcExportReportSPR006() throws Exception {
            // Get driver
            final WebDriver driver = WebDriverFactory.get( browser );

            Log.testCaseInfo( "tcExportReportSPR006:Verify spinner is showing PDF generation is in-progress and CrossButton X on the 'Exporting PDF file' model is disabled<small><b><i>[" + browser + "]</b></i></small>" );
            try {
                smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
                StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
                ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
                reportViewerPage.verifyReportPage( driver );
                reportViewerPage.clickOnPDF();
                
                SMUtils.logDescriptionTC( "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'" );
                reportViewerPage.clickOkButton();
                reportViewerPage.clickCrossButton();
                SMUtils.logDescriptionTC( "Verify spinner is showing PDF generation is in-progress and close button  'Exporting PDF file' model is disabled" );
                if(!reportViewerPage.isCrossButtonDisable()) {
                    Log.message( "Close button is showing as disabled mode while downloading the pdf" );
                }else {
                    Log.message( "Close button is showing as enabled mode" );
                }
                
               Log.testCaseResult();
            } catch ( Exception e ) {
                Log.exception( e, driver );
            } finally {
                Log.endTestCase();
                driver.quit();
            }

    }
    @Test ( description = "Verify 'Close' button and Close(X) button back to active and user is able to close the model by clicking either Close button or from the close (X)", groups = {"SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports",
            }, priority = 2 )
    public void tcExportReportSPR007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR007:Verify 'Close' button and Close(X) button back to active and user is able to close the model by clicking either Close button or from the close (X)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            
            reportViewerPage.clickOnPDF();
            reportViewerPage.clickOkButton();

            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model after report is successfully rendered" );
            SMUtils.nap( 8 );
            Log.assertThat( reportViewerPage.getSuccessMessage().contains( ReportsUIConstants.SUCCESS_TEXT ), "Getting Success text properly", "Not Getting success text properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model after report is successfully rendered" );
            Log.assertThat( reportViewerPage.getSuccessMessage().contains( ReportsUIConstants.SUCCESS_TEXT_SECOND ), "Getting success text properly", "Not Getting success text properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'Close' button and Close(X) button back to active and user is able to close the model by clicking either Close button or from the close (X)" );
            Log.assertThat( reportViewerPage.verifyCloseButtonEnableOrDisable(), "Close button is disable", "Close button is not disable" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "User can able to click on close button" );
            reportViewerPage.clickCloseButton();
            reportViewerPage.verifyReportPage( driver );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly", groups = {"SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports",  "smoke_test_case" }, priority = 1 )
    public void tcExportReportSPR008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR008:Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            reportViewerPage.clickOnPDF();
            
            reportViewerPage.clickOkButton();
            SMUtils.logDescriptionTC( "Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly" );
            Log.assertThat( reportViewerPage.isPDFFileDownloaded(driver), "The export pdf file is downloaded properly", "The export pdf file is not downloaded properly" );
            SMUtils.logDescriptionTC( "Verify file is downloaded in default download folder and File name should be in correct format" );
            Log.assertThat( reportViewerPage.getPdfFileNameFromBS( driver ).contains( "student-performance" ), "The exported pdf file has proper file name.", "The exported pdf has not contain Student Performance name." );
            SMUtils.logDescriptionTC( "Verify file is downloaded with valid file size" );
            Log.assertThat( reportViewerPage.getPdfFileSizeFromBS( driver ) > 0, "The exported pdf file has proper file size.", "The exported pdf not having proper file size ." );
           Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

}
   
    @Test ( description = "Verify user able to downlod the PDF report by selecting 'Current Page' F and the pdf downloaded properly", groups = {"SMK-66277/SMK-69992", "Teacher Dashboard", "Export Reports", "smoke_test_case" }, priority = 1 )
    public void tcExportReportSPR009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcExportReportSPR009:Verify user able to downlod the PDF report by selecting 'Current Page' <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            
            ReportsViewerPage reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            reportViewerPage.clickOnPDF();
            
            reportViewerPage.clickCurrentPageRadioButton();
            reportViewerPage.clickOkButton();
            SMUtils.logDescriptionTC( "Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly" );
            Log.assertThat( reportViewerPage.isPDFFileDownloaded(driver), "The export pdf file is downloaded properly", "The export pdf file is not downloaded properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

}

}
