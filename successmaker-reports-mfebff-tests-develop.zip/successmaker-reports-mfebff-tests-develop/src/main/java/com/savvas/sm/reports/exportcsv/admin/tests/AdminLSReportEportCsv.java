package com.savvas.sm.reports.exportcsv.admin.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import io.restassured.response.Response;

public class AdminLSReportEportCsv extends EnvProperties {

    private String districtAdminUsername;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String browser;
    private String districtAdminUserId;
    private String districtId;
    private String teacherId;
    private String teacherUsername;
    private String flexSchool;
    private String flexSchoolId;

    private String ipClearedStudentUsername;
    private String ipNotClearedStudentUsername;
    private String ipClearedStudentUserId;
    private String ipNotClearedStudentUserId;
    private String ipNotClearedStudentGrade;
    private String groupId;

    private String mathAssignmentData;
    private String readingAssignmentData;

    HashMap<String, String> assignmentIds = new HashMap<>();
    RBSUtils rbsUtils = new RBSUtils();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {

        districtId = configProperty.getProperty( "district_ID" ).trim();
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        flexSchoolId = rbsUtils.getOrganizationIDByName( districtId, flexSchool );
        districtAdminUsername = ReportDataCollection.districtAdmin;
        districtAdminUserId = rbsUtils.getUserIDByUserName( districtAdminUsername );

        teacherUsername = ReportDataCollection.teacherDetails.keySet().toArray()[1].toString();
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );

        // Get Student details
        Map<String, String> studentDetails = ReportDataCollection.defaultMathAssignmentDetails.get( teacherUsername );

        ipClearedStudentUserId = studentDetails.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().get();
        ipNotClearedStudentUserId = studentDetails.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" )
                && !SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "currentLevel" ).contains( "null" ) ).findFirst().get();

        ipClearedStudentUsername = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipClearedStudentUserId ), "userName" );
        ipNotClearedStudentUsername = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipNotClearedStudentUserId ), "userName" );

        ipNotClearedStudentGrade = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( rbsUtils.getUserWithUserService( ipNotClearedStudentUserId ), "userMetaData,grade" ), "defaultGradeLevel" ).replace( "G", "" );
        groupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsername ) ).get( 0 ).toString(), "groupId" );

        //Get Math assignments id
        assignmentIds.put( Constants.MATH, SMUtils.getKeyValueFromResponse( ReportDataCollection.defaultMathAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMONAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.mathStandardAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSkillAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );

        //Get Reading assignments id
        assignmentIds.put( Constants.READING, SMUtils.getKeyValueFromResponse( ReportDataCollection.defaultReadingAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMONAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.readingStandardAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );
        assignmentIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSkillAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), Constants.ASSIGNMENT_ID ) );

        //Get Math and Reading assignment report data
        HashMap<String, String> filterByValues = new HashMap<>();
        filterByValues.put( "{teacherId}", teacherId );
        mathAssignmentData = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.MATH, filterByValues ).getBody().asString();
        readingAssignmentData = Reports.getLSReport( districtAdminUsername, password, districtAdminUserId, districtId, flexSchoolId, Constants.READING, filterByValues ).getBody().asString();

    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "smoke_test_case", "SMK-69108", "LSR Export CSV", "API" }, priority = 1 )
    public void postAdminOrganizationPerformanceTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + " - " + testcaseDescription );
        HashMap<String, String> headers = new HashMap<String, String>();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + rbsUtils.getAccessToken( districtAdminUsername, password ) );
        headers.put( UserConstants.ORGID, districtId );
        headers.put( UserConstants.USERID, districtAdminUserId );
        Map<String, Object> saveReportOptionalFilters = new HashMap<>();
        Response response;
        Response saveResponse;
        String requestId;
        String exportedCsvFile;
        List<Map<String, String>> splitedResponse;
        Map<String, String> graphqlResponse;
        Reports report = new Reports();
        AdminReportCsv exportCsv = new AdminReportCsv();

        switch ( scenarioType ) {
            case "DEFAULT_HEADER_MATH":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 0, requestId );
                exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( getCsvValues( response ) );
                Log.assertThat( ExportCsvConstants.LSR_DEFAULT_MATH_HEADERS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
                break;

            case "DEFAULT_HEADER_READING":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), false, false, null, null, 0, requestId );
                exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( getCsvValues( response ) );
                Log.assertThat( ExportCsvConstants.LSR_DEFAULT_READING_HEADERS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Reading",
                        "All Column header values are not returned for Reading" );
                break;

            case "MATH_IP_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.MATH ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "MATH_IP_NOT_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( "In IP" ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "READING_IP_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.READING ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "READING_IP_NOT_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.READING ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "IP_CLEARED_MATH_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "IP_NOT_CLEARED_MATH_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( "In IP" ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "IP_CLEARED_READING_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "IP_NOT_CLEARED_READING_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "MATH_SETTING_IP_OFF":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ),
                        Arrays.asList( "currentCourseLevel", "exercisesCorrect", "exercisesAttempted", "exercisesPercentCorrect" ) );
                int studentIndex = getStudentIndex( splitedResponse, ipNotClearedStudentUsername );
                Log.assertThat( splitedResponse.get( studentIndex ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected", "IP value mismatch" );
                Log.assertThat( splitedResponse.get( studentIndex ).get( "\"Exercises Correct\"" ).contains( graphqlResponse.get( "exercisesCorrect" ) ), "Exercises Correct is displayed as expected", "Exercises Correct mismatch" );
                Log.assertThat( splitedResponse.get( studentIndex ).get( "\"Exercises Attempted\"" ).contains( graphqlResponse.get( "exercisesAttempted" ) ), "Exercises Attempted is displayed as expected", "Exercises Attempted mismatch" );
                Log.assertThat( splitedResponse.get( studentIndex ).get( "\"Exercises Percent Correct\"" ).contains( graphqlResponse.get( "exercisesPercentCorrect" ) + "%" ), "Exercises Percent Correct is displayed as expected",
                        "Exercises Percent Correct mismatch" );
                break;

            case "READING_SETTING_IP_OFF":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ),
                        Arrays.asList( "currentCourseLevel", "helpUsed", "timeSpent", "totalSessions" ) );
                int index = getStudentIndex( splitedResponse, ipNotClearedStudentUsername );

                Log.assertThat( splitedResponse.get( index ).get( "\"Current Course Level\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected", "IP value mismatch" );
                Log.assertThat( splitedResponse.get( index ).get( "\"Help Used\"" ).contains( graphqlResponse.get( "helpUsed" ) ), "Help Used is displayed as expected", "Exercises Correct mismatch" );
                Log.assertThat( splitedResponse.get( index ).get( "\"Total Sessions\"" ).contains( graphqlResponse.get( "totalSessions" ) ), "Total Sessions is displayed as expected", "Exercises Percent Correct mismatch" );
                break;

            case "MATH_CUSTOM_STAND":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( "NA" ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "READING_CUSTOM_STAND":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( "NA" ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "MATH_CUSTOM_SKILL":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( "NA" ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "READING_CUSTOM_SKILL":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ), false, false, null, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Current Course Level\"" ).contains( "NA" ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            // Custom export csv validation
            case "CUSTOM_HEADER_MATH_CUTOM":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( getCsvValues( response ) );
                Log.assertThat( ExportCsvConstants.LSR_MATH_EXPORT_CSV_FIELDS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
                break;

            case "CUSTOM_HEADER_READING_CUSTOM":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( getCsvValues( response ) );
                Log.assertThat( ExportCsvConstants.LSR_READING_CSV_FIELDS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Reading", "All Column header values are not returned for Reading" );
                break;

            case "CUSTOM_MATH_IP_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), true, false, Arrays.asList( ExportCsvConstants.LSR_EXPORT_CSV_FIELDS.get( 8 ) ), null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.MATH ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.toString().contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "CUSTOM_MATH_IP_NOT_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), true, false, Arrays.asList( ExportCsvConstants.LSR_EXPORT_CSV_FIELDS.get( 8 ) ), null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.MATH ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.toString().contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected", "IP value mismatch" );
                break;

            case "CUSTOM_READING_IP_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), true, false,
                        ExportCsvConstants.LSR_EXPORT_CSV_FIELDS.stream().limit( 12 ).collect( Collectors.toList() ), null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.READING ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_READING_IP_NOT_CLEARED":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), true, false,
                        ExportCsvConstants.LSR_EXPORT_CSV_FIELDS.stream().limit( 12 ).collect( Collectors.toList() ), null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.READING ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_IP_CLEARED_MATH_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0,
                        requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_IP_NOT_CLEARED_MATH_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0,
                        requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_IP_CLEARED_READING_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0,
                        requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_IP_NOT_CLEARED_READING_SETTING_IP_ON":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0,
                        requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_MATH_CUSTOM_IP_OFF":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_READING_CUSTOM_IP_OFF":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipNotClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_MATH_STAND":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_READING_STAND":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0,
                        requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_MATH_SKILL":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( mathAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "CUSTOM_READING_SKILL":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                graphqlResponse = ExportCsvUtils.getValuesFromLSResponse( readingAssignmentData, ipClearedStudentUsername, assignmentIds.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ), Arrays.asList( "currentCourseLevel" ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"currentCourseLevel\"" ).contains( graphqlResponse.get( "currentCourseLevel" ) ), "IP value is displayed as expected",
                        "IP value mismatch" );
                break;

            case "ADDITIONAL_GROUPING_TEACHER":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveReportOptionalFilters.put( "additionalGrouping", "TEACHER" );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 1, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipClearedStudentUsername ) ).get( "\"Teacher\"" ).contains( SMUtils.getKeyValueFromResponse( rbsUtils.getUser( teacherId ), "firstAndLastName" ) ),
                        "Teacher name is displayed", "Teacher name is not displayed" );
                break;

            case "ADDITIONAL_GROUPING_GRADE":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveReportOptionalFilters.put( "additionalGrouping", "GRADE" );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 2, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( ipNotClearedStudentGrade.contains( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Grade\"" ).replaceAll( "\"", "" ) ), "Grade value is displayed",
                        "Grade value is not displayed" );
                break;

            case "ADDITIONAL_GROUPING_GROUP":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 3, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Group\"" ).replaceAll( "\"", "" ).contains( ReportsUIConstants.SM_GROUP ), "Group name is displayed",
                        "Group name is not displayed" );
                break;

            case "FILTER_BY_TEACHER":
                Map<String, List<String>> teacherFilter = new HashMap<>();
                teacherFilter.put( "filterByTeacher", Arrays.asList( teacherId ) );
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveReportOptionalFilters.put( "teachers", Arrays.asList( teacherId ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, teacherFilter, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Student Username\"" ).contains( ipNotClearedStudentUsername ), "Group name is displayed", "Group name is not displayed" );
                break;

            case "FILTER_BY_GRADE":
                Map<String, List<String>> gradeFilter = new HashMap<>();
                gradeFilter.put( "filterByGrade", Arrays.asList( ipNotClearedStudentGrade ) );
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveReportOptionalFilters.put( "grades", Arrays.asList( ipNotClearedStudentGrade ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, gradeFilter, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Student Username\"" ).contains( ipNotClearedStudentUsername ), "Group name is displayed", "Group name is not displayed" );
                break;

            case "FILTER_BY_GROUP":
                Map<String, List<String>> groupFilter = new HashMap<>();
                groupFilter.put( "filterByGroup", Arrays.asList( groupId ) );
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveReportOptionalFilters.put( "groups", Arrays.asList( groupId ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, groupFilter, 0, requestId );
                splitedResponse = ExportCsvUtils.splitCSVData( getCsvValues( response ) );
                Log.assertThat( splitedResponse.get( getStudentIndex( splitedResponse, ipNotClearedStudentUsername ) ).get( "\"Student Username\"" ).contains( ipNotClearedStudentUsername ), "Group name is displayed", "Group name is not displayed" );
                break;

            case "LSR -Math default field":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), false, false, null, null, 0, requestId );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );
                break;

            case "LSR -Reading default field":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), false, false, null, null, 0, requestId );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );
                break;
            case "LSR -Math custom field":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.MATH ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, true, Arrays.asList( assignmentIds.get( Constants.MATH ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );
                break;

            case "LSR -Reading custom field":
                saveReportOptionalFilters.put( "courses", Arrays.asList( assignmentIds.get( Constants.READING ) ) );
                saveResponse = report.saveAdminLSReportOption( headers, flexSchoolId, "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveResponse.getBody().asString() );
                response = exportCsv.GetAdminLastSessionReportCsv( headers, flexSchoolId, false, Arrays.asList( assignmentIds.get( Constants.READING ) ), true, false, ExportCsvConstants.LSR_EXPORT_CSV_FIELDS, null, 0, requestId );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );
                break;

        }

    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC_Admin_LSR_Export_CSV_01", "200", "Verify the status code and csv headers (column name) in the response, for Default Export - Math Subject ", "DEFAULT_HEADER_MATH" },
                { "TC_Admin_LSR_Export_CSV_02", "200", " Verify the status code and csv headers (column name) in the response, for Default Export - Reading Subject ", "DEFAULT_HEADER_READING" },

                { "TC_Admin_LSR_Export_CSV_03", "200", " Verify all the fields in the response for Default math assignment who has cleared the IP.", "MATH_IP_CLEARED" },
                { "TC_Admin_LSR_Export_CSV_04", "200", "Verify all the fields in the response for Default math assignment who has not cleared the IP.", "MATH_IP_NOT_CLEARED" },
                { "TC_Admin_LSR_Export_CSV_05", "200", "Verify all the fields in the response for Default reading assignment who has cleared the IP", "READING_IP_CLEARED" },
                { "TC_Admin_LSR_Export_CSV_06", "200", " Verify all the fields in the response for Default reading assignment who has not cleared the IP.", "READING_IP_NOT_CLEARED" },

                { "TC_Admin_LSR_Export_CSV_07", "200", " Verify all the fields in the response for Math - Custom Setting IP On  assignment who has cleared the IP", "IP_CLEARED_MATH_SETTING_IP_ON" },
                { "TC_Admin_LSR_Export_CSV_08", "200", "Verify all the fields in the response for  Math - Custom Setting IP On assignment who has not cleared the IP.", "IP_NOT_CLEARED_MATH_SETTING_IP_ON" },
                { "TC_Admin_LSR_Export_CSV_09", "200", "Verify all the fields in the response for Reading - Custom Setting IP On  assignment who has cleared the IP.", "IP_CLEARED_READING_SETTING_IP_ON" },
                { "TC_Admin_LSR_Export_CSV_10", "200", "Verify all the fields in the response for  Reading - Custom Setting IP On assignment who has not cleared the IP.", "IP_NOT_CLEARED_READING_SETTING_IP_ON" },

                { "TC_Admin_LSR_Export_CSV_11", "200", "Verify all the fields in the response for Math - Custom Setting IP Off  assignment.", "MATH_SETTING_IP_OFF" },
                { "TC_Admin_LSR_Export_CSV_12", "200", "Verify all the fields in the response for Reading - Custom Setting IP Off assignment.", "READING_SETTING_IP_OFF" },

                { "TC_Admin_LSR_Export_CSV_13", "200", "Verify all the fields in the response for Math - Custom standard assignment.", "MATH_CUSTOM_STAND" },
                { "TC_Admin_LSR_Export_CSV_14", "200", "Verify all the fields in the response for Reading - Custom standard assignment.", "READING_CUSTOM_STAND" },

                { "TC_Admin_LSR_Export_CSV_15", "200", " Verify all the fields in the response for Math - Custom skill assignment.", "MATH_CUSTOM_SKILL" },
                { "TC_Admin_LSR_Export_CSV_16", "200", " Verify all the fields in the response for Reading - Custom skill assignment.", "READING_CUSTOM_SKILL" },

                // Custom Export
                { "TC_Admin_LSR_Export_CSV_17", "200", " Verify the status code and csv headers (column name) in the response, for Custom Export - Math Subject ", "CUSTOM_HEADER_MATH_CUTOM" },
                { "TC_Admin_LSR_Export_CSV_18", "200", " Verify the status code and csv headers (column name) in the response, for Custom Export - Reading Subject ", "CUSTOM_HEADER_READING_CUSTOM" },

                { "TC_Admin_LSR_Export_CSV_19", "200", "Verify all the fields in the response for Custom math assignment who has cleared the IP.", "CUSTOM_MATH_IP_CLEARED" },
                { "TC_Admin_LSR_Export_CSV_20", "200", "Verify all the fields in the response for Custom math assignment who has not cleared the IP.", "CUSTOM_MATH_IP_NOT_CLEARED" },
                { "TC_Admin_LSR_Export_CSV_21", "200", " Verify all the fields in the response for Custom reading assignment who has cleared the IP.", "CUSTOM_READING_IP_CLEARED" },
                { "TC_Admin_LSR_Export_CSV_22", "200", " Verify all the fields in the response for Custom reading assignment who has not cleared the IP.", "CUSTOM_READING_IP_NOT_CLEARED" },

                { "TC_Admin_LSR_Export_CSV_23", "200", "Verify all the fields in the response for Math - Custom Setting IP On  assignment who has cleared the IP.", "CUSTOM_IP_CLEARED_MATH_SETTING_IP_ON" },
                { "TC_Admin_LSR_Export_CSV_24", "200", " Verify all the fields in the response for  Math - Custom Setting IP On assignment who has not cleared the IP.", "CUSTOM_IP_NOT_CLEARED_MATH_SETTING_IP_ON" },
                { "TC_Admin_LSR_Export_CSV_25", "200", "Verify all the fields in the response for Reading - Custom Setting IP On  assignment who has cleared the IP.", "CUSTOM_IP_CLEARED_READING_SETTING_IP_ON" },
                { "TC_Admin_LSR_Export_CSV_26", "200", "Verify all the fields in the response for  Reading - Custom Setting IP On assignment who has not cleared the IP.", "CUSTOM_IP_NOT_CLEARED_READING_SETTING_IP_ON" },

                { "TC_Admin_LSR_Export_CSV_27", "200", "Verify all the fields in the response for Math - Custom Setting IP Off  assignment.", "CUSTOM_MATH_CUSTOM_IP_OFF" },
                { "TC_Admin_LSR_Export_CSV_28", "200", " Verify all the fields in the response for Reading - Custom Setting IP Off assignment.", "CUSTOM_READING_CUSTOM_IP_OFF" },

                { "TC_Admin_LSR_Export_CSV_29", "200", " Verify all the fields in the response for Math - Custom standard assignment.", "CUSTOM_MATH_STAND" },
                { "TC_Admin_LSR_Export_CSV_30", "200", "Verify all the fields in the response for Reading - Custom standard assignment.", "CUSTOM_READING_STAND" },
                { "TC_Admin_LSR_Export_CSV_31", "200", "Verify all the fields in the response for Math - Custom skill assignment.", "CUSTOM_MATH_SKILL" },
                { "TC_Admin_LSR_Export_CSV_32", "200", " Verify all the fields in the response for Reading - Custom skill assignment.", "CUSTOM_READING_SKILL" },

                { "TC_Admin_LSR_Export_CSV_33", "200", "Verify the status code and response when passing 1 id in additionalGrouping", "ADDITIONAL_GROUPING_TEACHER" },
                { "TC_Admin_LSR_Export_CSV_34", "200", "Verify the status code and response when passing 2 id in additionalGrouping", "ADDITIONAL_GROUPING_GRADE" },
                { "TC_Admin_LSR_Export_CSV_35", "200", "Verify the status code and response when passing 3 id in additionalGrouping", "ADDITIONAL_GROUPING_GROUP" },

                { "TC_Admin_LSR_Export_CSV_36", "200", " Verify the status code and response when passing teacher id in filterByTeacher", "FILTER_BY_TEACHER" },
                { "TC_Admin_LSR_Export_CSV_37", "200", " Verify the status code and filterByGradeacher when passing grade in filterByGrade", "FILTER_BY_GRADE" },
                { "TC_Admin_LSR_Export_CSV_38", "200", "Verify the status code and response when passing group id in filterByGroup", "FILTER_BY_GROUP" },

                { "TC_Admin_LSR_Export_CSV_39", "200", "Verify the Last Session report export Bff response for Math subject , if pass single organization and exportType as default", "LSR -Math default field" },
                { "TC_Admin_LSR_Export_CSV_40", "200", "Verify the Last Session report export Bff response for Reading subject , if pass single organization and exportType as default", "LSR -Reading default field" },
                { "TC_Admin_LSR_Export_CSV_41", "200", "Verify the Last Session report export Bff response for Math subject , if pass single organization and exportType as custom", "LSR -Math custom field" },
                { "TC_Admin_LSR_Export_CSV_42", "200", "Verify the Last Session report export Bff response for Math subject , if pass single organization and exportType as default", "LSR -Reading custom field" },

        };
        return data;
    }

    private int getStudentIndex( List<Map<String, String>> response, String studentUsername ) {
        try {
            return IntStream.range( 0, response.size() ).filter( i -> response.get( i ).get( "\"Student Username\"" ).equals( studentUsername ) ).findFirst().getAsInt();
        } catch ( Exception e ) {
            return IntStream.range( 0, response.size() ).filter( i -> response.get( i ).get( "\"studentUsername\"" ).equals( studentUsername ) ).findFirst().getAsInt();
        }
    }

    public String getCsvValues( Response csv ) {
        String csvDataFromBS = null;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            driver.get( SMUtils.getKeyValueFromResponse( csv.getBody().asString(), "signedUrl" ) );
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            driver.quit();
        }
        return csvDataFromBS;
    }

}
