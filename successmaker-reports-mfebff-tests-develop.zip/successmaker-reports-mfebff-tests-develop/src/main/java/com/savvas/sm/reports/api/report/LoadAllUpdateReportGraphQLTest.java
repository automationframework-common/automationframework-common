package com.savvas.sm.reports.api.report;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.util.ReportOptionResponse;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class LoadAllUpdateReportGraphQLTest extends UserAPI {

    private String baseURL = ReportAPIConstants.GRAPG_QL_BASE_URL;
    private String endPoint = ReportAPIConstants.GRAPH_QL_ENDPOINT;
    Map<String, String> queryItem = new HashMap<>();
    HashMap<String, String> headers = new HashMap<>();
    Response response = null;
    String query;
    String payload;
    String requestId;
    String filterName;
    String reportParameters;

    @BeforeTest
    public void beforeTest() throws Exception {
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        queryItem = new HashMap<>();
        payload = getPayload( "getReportOption" );
        queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
        queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
        queryItem.put( ReportAPIConstants.REPORT_TYPE, ReportAPIConstants.TST_REPORT_TYPE );
        query = constructQueryItems( queryItem );
        payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );

        JSONObject responseObject = new JSONObject( response.getBody().asString() );

        JSONObject dataObject = responseObject.getJSONObject( "data" );
        JSONObject queryObject = dataObject.getJSONObject( "getAllReportOption" );
        JSONArray resultsArray = queryObject.getJSONArray( "reports" );
        List<ReportOptionResponse> lst = new Gson().fromJson( resultsArray.toString(), new TypeToken<List<ReportOptionResponse>>() {}.getType() );
        ReportOptionResponse reportResponse = lst.get( 0 );
        requestId = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + reportResponse.getRequestId() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
        filterName = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + reportResponse.getFilterName() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
        reportParameters = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + reportResponse.getReportParameters().replace( "\"", "\\\\\\\"" ) + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;

    }

    @Test ( dataProvider = "getDataforAllSaveReport", groups = { "SMK-59119", "Integrate load/save report GraphQL api to run report button.", "API","SmokeTest" }, priority = 1 )
    public void testGetAllSaveReportAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType, String reportType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        Log.testCaseInfo( testcaseName + testcaseDescription );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();
        String payload = getPayload( "getReportOption" );
        String query;
        Response response = null;
        String requestId;
        String filterName;
        String reportParameters;
        String repsonsereporttype;
        String responseStatusCode = "";
        JSONObject responseObject;
        JSONObject dataObject;
        JSONObject queryObject;
        JSONArray resultsArray;
        List<ReportOptionResponse> lst;

        switch ( scenarioType ) {
            case "ALL_REPORT":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseObject = new JSONObject( response.getBody().asString() );
                dataObject = responseObject.getJSONObject( "data" );
                queryObject = dataObject.getJSONObject( "getAllReportOption" );
                resultsArray = queryObject.getJSONArray( "reports" );
                lst = new Gson().fromJson( resultsArray.toString(), new TypeToken<List<ReportOptionResponse>>() {}.getType() );
                for ( ReportOptionResponse respon : lst ) {
                    requestId = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getRequestId() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    filterName = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getFilterName() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    reportParameters = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getReportParameters().replace( "\"", "\\\\\\\"" ) + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    if ( !"".equalsIgnoreCase( requestId ) )
                        responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                    else {
                        responseStatusCode = ReportsAPIConstants.NOT_FOUND_404;
                        break;
                    }
                }
                break;
            case "ALL_REPORT_WITH_REPORT_TYPE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseObject = new JSONObject( response.getBody().asString() );

                dataObject = responseObject.getJSONObject( "data" );
                queryObject = dataObject.getJSONObject( "getAllReportOption" );
                resultsArray = queryObject.getJSONArray( "reports" );
                lst = new Gson().fromJson( resultsArray.toString(), new TypeToken<List<ReportOptionResponse>>() {}.getType() );
                for ( ReportOptionResponse respon : lst ) {
                    requestId = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getRequestId() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    filterName = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getFilterName() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    reportParameters = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getReportParameters().replace( "\"", "\\\\\\\"" ) + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    if ( !"".equalsIgnoreCase( requestId ) )
                        responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                    else {
                        responseStatusCode = ReportsAPIConstants.NOT_FOUND_404;
                        break;
                    }
                }
                break;
            case "ALL_REPORT_REPORT_TYPE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseObject = new JSONObject( response.getBody().asString() );
                dataObject = responseObject.getJSONObject( "data" );
                queryObject = dataObject.getJSONObject( "getAllReportOption" );
                resultsArray = queryObject.getJSONArray( "reports" );
                lst = new Gson().fromJson( resultsArray.toString(), new TypeToken<List<ReportOptionResponse>>() {}.getType() );
                for ( ReportOptionResponse respon : lst ) {
                    repsonsereporttype = ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION + respon.getReportType() + ReportAPIConstants.BACKWARD_SLASH + ReportAPIConstants.DOUBLE_QUOTATION;
                    if ( reportType.equalsIgnoreCase( repsonsereporttype ) )
                        responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                    else {
                        responseStatusCode = ReportsAPIConstants.NOT_FOUND_404;
                        break;
                    }
                }
                break;
            case "ALL_REPORT_EMPTY_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "ALL_REPORT_EMPTY_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "ALL_REPORT_WITHOUT_ORG_ID":
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "ALL_REPORT_WITHOUT_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "ALL_REPORT_INVALID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.FILTER_NAME, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "ALL_REPORT_INVALID_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
            case "ALL_REPORT_INVALID_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
        }
        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataforAllSaveReport() {
        return new Object[][] {
                { "TC001", "200", "TC001_Verify the 200 code graphql response is obtaining the predictable result with all the fields in the GetAllReportOptionResponse when mandatory fields(orgId and userId) is given for getAllReportOption", "ALL_REPORT",
                        "\\\"MASTERY\\\"" },
                { "TC002", "200", "TC002_Verify the 200 code graphql response is obtaining the predictable result with all the fields in the GetAllReportOptionResponse when all the fields (orgId,userId and reportType) is given for getAllReportOption",
                        "ALL_REPORT_WITH_REPORT_TYPE", "\\\"MASTERY\\\"" },
                { "TC003", "200", "TC003_Verify the 200 code graphql response is obtaining the predictable result for all the fields in the GetAllReportOptionResponse when reportType=\"LS\" is given in getAllReportOption", "ALL_REPORT_REPORT_TYPE",
                        "\\\"LS\\\"" },
                { "TC004", "200", "TC004_Verify the 200 code graphql response is obtaining the predictable result for all the fields in the GetAllReportOptionResponse when reportType=\"ISP\" is given in getAllReportOption", "ALL_REPORT_REPORT_TYPE",
                        "\\\"ISP\\\"" },
                { "TC005", "200", "TC005_Verify the 200 code graphql response is obtaining the predictable result for all the fields in the GetAllReportOptionResponse when reportType=\"CP\" is given in getAllReportOption", "ALL_REPORT_REPORT_TYPE",
                        "\\\"CP\\\"" },
                { "TC006", "200", "TC006_Verify the 200 code graphql response is obtaining the predictable result for all the fields in the GetAllReportOptionResponse when reportType=\"MASTERY\" is given in getAllReportOption", "ALL_REPORT_REPORT_TYPE",
                        "\\\"MASTERY\\\"" },
                { "TC007", "400", "TC007_Verify 400 code and validation error in the graphql response when empty orgId is provided in the query input params", "ALL_REPORT_EMPTY_ORG_ID", "\\\"MASTERY\\\"" },
                { "TC008", "400", "TC008_Verify 400 code and validation error in the graphql response when empty userId is provided in the query input params", "ALL_REPORT_EMPTY_USER_ID", "\\\"MASTERY\\\"" },
                { "TC009", "400", "TC009_Verify 400 code and validation error in the graphql response when mandatory field orgId is not provided in the query input params", "ALL_REPORT_WITHOUT_ORG_ID", "\\\"MASTERY\\\"" },
                { "TC010", "400", "TC010_Verify 400 code and validation error in the graphql response when mandatory field userId is not provided in the query input params", "ALL_REPORT_WITHOUT_USER_ID", "\\\"MASTERY\\\"" },
                { "TC012", "400", "TC012_Verify 400 code and validation error in the graphql response when invalid query params for getAllReportOption is given", "ALL_REPORT_INVALID", "\\\"MASTERY\\\"" },
                { "TC014", "404", "TC014_Verify 404 code and validation error in the graphql response when invalid orgId and valid userId is provided in the query input params", "ALL_REPORT_INVALID_ORG_ID", "\\\"MASTERY\\\"" },
                { "TC015", "404", "TC015_Verify 400 code and validation error in the graphql response when invalid userId and valid orgId is provided in the query input params", "ALL_REPORT_INVALID_USER_ID", "\\\"MASTERY\\\"" }, };
    }

    @Test ( dataProvider = "UpdateSaveReport", groups = { "SMK-59119", "Integrate load/save report GraphQL api to run report button.", "API" }, priority = 1 )
    public void testUpdateSaveReport( String testcaseName, String statusCode, String testcaseDescription, String scenarioType, String reportType ) throws Exception {
        headers = new HashMap<>();
        Log.testCaseInfo( testcaseName + testcaseDescription );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        queryItem = new HashMap<>();
        payload = getPayload( "postReportOption" );
        String responseStatusCode = "";

        switch ( scenarioType ) {

            case "UPDATE_WITH_ALL_PARAM":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "UPDATE_WITHOUT_MANDATORY_PARAM":
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "UPDATE_WITH_INVALID_PARAM":
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.STUDENT_IDS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "UPDATE_WITH_INVALID_AUTHORIZATION":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.INVALID, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "UPDATE_WITH_EMPTY_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "UPDATE_WITH_EMPTY_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "UPDATE_WITH_EMPTY_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "UPDATE_WITH_EMPTY_USERTYPE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "UPDATE_WITH_EMPTY_REPORT_PARAMETERS":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, "\\\"\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "UPDATE_WITH_EMPTY_REPORT_TYPE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "UPDATE_WITH_PERSON_REPORT_FALSE":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.FALSE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = Optional.ofNullable( response.getStatusCode() ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "UPDATE_WITH_INVALID_USER_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
            case "UPDATE_WITH_INVALID_ORG_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, ReportAPIConstants.TST_ORG_ID );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
            case "UPDATE_WITH_INVALID_REQUEST_ID":
                queryItem.put( ReportAPIConstants.ORG_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.USER_ID, ReportAPIConstants.TST_TEACHER_ID );
                queryItem.put( ReportAPIConstants.REPORT_TYPE, reportType );
                queryItem.put( ReportAPIConstants.PERSON_REPORT, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.USER_TYPE, ReportAPIConstants.TEACHER );
                queryItem.put( ReportAPIConstants.FILTER_NAME, filterName );
                queryItem.put( ReportAPIConstants.REQUEST_ID, requestId );
                queryItem.put( ReportAPIConstants.REPORT_PARAMETERS, reportParameters );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.REPORT_OPTION_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportAPIConstants.TST_USERNAME, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = RestAssuredAPIUtil.POSTGraphQl( baseURL, headers, payload, endPoint );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.STATUS );
                break;
        }
        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] UpdateSaveReport() {
        return new Object[][] {
                { "TC016", "200", "TC016_Verify the 200 code graphql response is obtaining the predictable result for all query params for updateReportOption and all output field for UpdateReportOptionResponse", "UPDATE_WITH_ALL_PARAM",
                        "\\\"MASTERY\\\"" },
                { "TC018", "400",
                        "TC018_Verify the 400 code graphql response is obtaining the predictable result when one of the mandatory field(userType,reportParameters,personReport,userId,reportType,orgId,requestId) is not given in query params for updateReportOption",
                        "UPDATE_WITHOUT_MANDATORY_PARAM", "\\\"MASTERY\\\"" },
                { "TC019", "400", "TC019_Verify the 400 code and validation error in the graphql response when invalid query params for updateReportOption is given", "UPDATE_WITH_INVALID_PARAM", "\\\"MASTERY\\\"" },
                { "TC020", "401", "TC020_Verify \"401: UnAuthorized\" message in response when invalid Bearer token is given for updateReportOption", "UPDATE_WITH_INVALID_AUTHORIZATION", "\\\"MASTERY\\\"" },
                { "TC021", "400", "TC021_Verify 400 code and validation error in the graphql response when empty userId is provided in the query input params for updateReportOption", "UPDATE_WITH_EMPTY_USER_ID", "\\\"MASTERY\\\"" },
                { "TC022", "400", "TC022_Verify 400 code and validation error in the graphql response when empty orgId is provided in the query input params for updateReportOption", "UPDATE_WITH_EMPTY_ORG_ID", "\\\"MASTERY\\\"" },
                { "TC023", "400", "TC023_Verify 400 code and validation error in the graphql response when empty requestId is provided in the query input params for updateReportOption", "UPDATE_WITH_EMPTY_REQUEST_ID", "\\\"MASTERY\\\"" },
                { "TC024", "400", "TC024_Verify 400 code and validation error in the graphql response when empty userType is provided in the query input params for updateReportOption", "UPDATE_WITH_EMPTY_USERTYPE", "\\\"MASTERY\\\"" },
                { "TC025", "200", "TC025_Verify 400 code and validation error in the graphql response when empty reportParameters is provided in the query input params for updateReportOption", "UPDATE_WITH_EMPTY_REPORT_PARAMETERS", "\\\"MASTERY\\\"" },
                { "TC026", "400", "TC026_Verify 400 code and validation error in the graphql response when empty reportType is provided in the query input params for updateReportOption", "UPDATE_WITH_EMPTY_REPORT_TYPE", "\\\"MASTERY\\\"" },
                { "TC027", "200", "TC027_Verify the 200 code graphql response is obtaining the predictable result (filtername not updated and retain old value) when personReport is provided as \"false\" with filtername for updateReportOption",
                        "UPDATE_WITH_PERSON_REPORT_FALSE", "\\\"MASTERY\\\"" },
                { "TC029", "404", "TC029_Verify 404 code and validation error in the graphql response when invalid userId is provided in the query input params for updateReportOption", "UPDATE_WITH_INVALID_USER_ID", "\\\"MASTERY\\\"" },
                { "TC030", "400", "TC030_Verify 400 code and validation error in the graphql response when invalid orgId is provided in the query input params for updateReportOption", "UPDATE_WITH_INVALID_ORG_ID", "\\\"MASTERY\\\"" },
                { "TC031", "404", "TC031_Verify 404 code and validation error in the graphql response when invalid requestId is provided in the query input params for updateReportOption", "UPDATE_WITH_INVALID_REQUEST_ID", "\\\"MASTERY\\\"" },

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload( String path ) throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + path + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }

}