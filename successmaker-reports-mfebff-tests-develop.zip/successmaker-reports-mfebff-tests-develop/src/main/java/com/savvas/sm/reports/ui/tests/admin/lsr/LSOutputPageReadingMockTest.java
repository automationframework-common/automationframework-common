package com.savvas.sm.reports.ui.tests.admin.lsr;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.LastSessionReportPage;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

import io.opentelemetry.sdk.autoconfigure.spi.ConfigProperties;
import io.restassured.builder.ResponseBuilder;
import io.restassured.response.Response;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.IntStream;

public class LSOutputPageReadingMockTest extends EnvProperties {

    private String browser;
    private String lsReportsBFF;
    String smReportsUrl;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String distId;
    LastSessionReportPage lsMethod = new LastSessionReportPage();

    @BeforeClass(alwaysRun = true)
    public void initTest(ITestContext context) {
        smReportsUrl = configProperty.getProperty( "LSRMockEnvironmentAdmin" );
        lsReportsBFF = configProperty.getProperty( "AdminReportBFFGraphQL" );
        browser = "Windows_10_Chrome_100";
        
        distAdminUserName = ReportDataCollection.districtAdmin;
        Log.message( "distAdminUserName: " + distAdminUserName );
        distId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, "userId" );

    }


    @Test(description = "LS-Admin Read Mock for 1000 assignemnt Data", groups = {"SMK-67129", "AdminDashboard", "Reports", "Last Session", "Mock-Reading", "mock"}, priority = 1)
    public void tcLSRReadMock001(ITestContext context) throws Exception {

    	 // Get driver
        WebDriver driver = WebDriverFactory.get(browser);
        RecentSessionsPage lsPage = new RecentSessionsPage( driver );
        Map<String, Map<String, String>> outputValues = new HashMap<>();
        String laAdminReadMock = null;
        
        Log.testCaseInfo("LS-Admin Read Mock for 1000 assignemnt Data " + browser + "]</b></i></small>");
        
        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
            if (DevToolsUtils.isMock(context)) {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("GetReportOptionResponse.json");
                laAdminReadMock = DevToolsUtils.readJsonResponse("LSAdminReadMockMax.json");
                responses.put("GetReportOptionResponse", getReportOptionResponseJson);
                responses.put("GetLSAdminReportData", laAdminReadMock);

                List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetLSAdminReportData");
                devTool = DevToolsUtils.setResponse(driver, lsReportsBFF, requestPayloadMatchers, "post", responses);
                devTool.createSessionIfThereIsNotOne();
                Log.message(devTool.getCdpSession().toString());
            }

            LoginWrapper.loginToMasteryMfe(driver, reportUrl, distAdminUserName, password);
            ReportOutputComponent outputPage = new ReportOutputComponent(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            SMUtils.nap(20);

            SMUtils.waitForSpinnertoDisapper(driver);
            Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.LAST_SESSION), "Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
            SMUtils.waitForSpinnertoDisapper(driver, 5);

            Log.message( "TotalPageNo: " + outputPage.totalPageNo() );
            
            //Getting Data from Mock
            Map<String, Map<String, String>> dataFromBFF = lsMethod.getLSDataFromResponse(  laAdminReadMock , false );
            Log.message( "dataFromBFF: " + dataFromBFF );
            
            //Getting Data from UI
            String orgName = lsPage.getOrgNameOutput( driver );
            Log.message( "orgName: " +orgName );
            
            for ( int i=0; i<outputPage.totalPageNo(); i++ ) {
                if ( !outputPage.getAssignmentName().equalsIgnoreCase( Constants.READING ) ) {
                    outputPage.clickNextBtn();
                } else {
                    outputValues = lsMethod.getLSReportAllDataFromUI(driver, false);
                    break;
                }
            }
            
            List<String> assignmentNames  = lsPage.getAllAssignmentNamesFromOutput( driver, outputPage.totalPageNo() );
            Log.message( "assignmentNames: " + assignmentNames);
            
            //Verify and Compare the both values
            Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoHashMap( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                    "MFE Values are not matched with BFF value, Test Failed:(" );
            
            List<String> uiVaues = lsPage.getOutputTableHeadersRead( driver );
            Log.message( "uiValues: " + uiVaues + " expected: " + ReportsUIConstants.OUTPUT_TABLE_HEADERS_READ );
            
            Log.assertThat( lsPage.verifySMLogoandViewer( driver ), "SM Logo and Report viewer is displayed, Test Passed:)", "SM Logo and Report viewer is not displayed, Test Failed:(" );
            Log.assertThat( lsPage.verifyLegendHeaderAndLabelsForReading(), "Legends and Label Values are displayed, Test Passed:)", "Legends and Label Values are displayed, Test Failed:)" );
            Log.assertThat(  lsPage.verifyOutputTableHeadersRead( driver ), "Column headers are matched, Test Passed:)", "Column headers are not matched, Test Failed:(" );
            Log.assertThat( orgName.equalsIgnoreCase( "Chiefs Test Org" ), "Mock orgName is matched! Test Passed:)", "Mock orgName is not matched! Test Failed:(" );
            Log.assertThat(  lsPage.verifyFooterIsDispayed( driver ), "Savvas Footer is displayed, Test passed:)", "Savvas Footer is not displayed, Test Failec:(" );           
            Log.assertThat( outputPage.isNextBtnDisplayed(), "Next Button is displayed, Test passed:)", "Next Button is not displayed, Test Failed:(" );
            Log.assertThat( outputPage.clickNextBtn(), "Next Button is clickable, Test passed:)", "Next Button is not clickable, Test Failed:(" );
            Log.assertThat( outputPage.isBackBtnDisplayed(), "Back Button is displayed, Test passed:)", "Back Button is not displayed, Test Failed:(" );
            Log.assertThat( outputPage.clickBackBtn(), "Back Button is clickable, Test passed:)", "Back Button is not clickable, Test Failed:(" );

            
        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            if (null != devTool) {
                RequestMockUtils.closeMock(devTool);
            }
            driver.quit();
        }
    }

    
    @Test(description = "LS-Admin Read Mock for One assignemnt Data", groups = {"SMK-67129", "AdminDashboard", "Reports", "Last Session", "Mock-Reading", "mock"}, priority = 1)
    public void tcLSRReadMock002(ITestContext context) throws Exception {

        // Get driver
        WebDriver driver = WebDriverFactory.get(browser);
        RecentSessionsPage lsPage = new RecentSessionsPage( driver );
        Map<String, Map<String, String>> outputValues = new HashMap<>();
        String laAdminReadMock = null;
        Log.testCaseInfo("LS-Admin Read Mock for One assignemnt Data" + browser + "]</b></i></small>");
        
        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
            if (DevToolsUtils.isMock(context)) {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("GetReportOptionResponse.json");
                laAdminReadMock = DevToolsUtils.readJsonResponse("LSAdminReadMockMin.json");
                responses.put("GetReportOptionResponse", getReportOptionResponseJson);
                responses.put("GetLSAdminReportData", laAdminReadMock);

                List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetLSAdminReportData");
                devTool = DevToolsUtils.setResponse(driver, lsReportsBFF, requestPayloadMatchers, "post", responses);
                devTool.createSessionIfThereIsNotOne();
                Log.message(devTool.getCdpSession().toString());
            }

            LoginWrapper.loginToMasteryMfe(driver, reportUrl, distAdminUserName, password);
            ReportOutputComponent outputPage = new ReportOutputComponent(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            SMUtils.nap(20);

            SMUtils.waitForSpinnertoDisapper(driver);
            Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.LAST_SESSION), "Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
            SMUtils.waitForSpinnertoDisapper(driver, 5);
            
            Log.message( "TotalPageNo: " + outputPage.totalPageNo() );
            
            //Getting Data from Mock
            Map<String, Map<String, String>> dataFromBFF = lsMethod.getLSDataFromResponse(  laAdminReadMock , false );
            Log.message( "dataFromBFF: " + dataFromBFF );
            
            //Getting Data from UI
            String orgName = lsPage.getOrgNameOutput( driver );
            Log.message( "orgName: " +orgName );
            
            outputValues = lsMethod.getLSReportAllDataFromUI(driver, false);
            
            //Verify and Compare the both values
            Log.assertThat( outputValues.entrySet().stream().anyMatch( entry -> dataFromBFF.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoHashMap( responseData.getValue(), entry.getValue() ) ) ), "MFE Values are matched with BFF value, Test Passed!!",
                    "MFE Values are not matched with BFF value, Test Failed:(" );
            
            lsPage.getAllAssignmentNamesFromOutput( driver, outputPage.totalPageNo() );
            
            //Verify and Compare the both values
            Log.assertThat( lsPage.verifySMLogoandViewer( driver ), "SM Logo and Report viewer is displayed, Test Passed:)", "SM Logo and Report viewer is not displayed, Test Failed:(" );
            Log.assertThat( lsPage.verifyLegendHeaderAndLabelsForReading(), "Legends and Label Values are displayed, Test Passed:)", "Legends and Label Values are not displayed, Test Failed:)" );
            Log.assertThat(  lsPage.verifyOutputTableHeadersRead( driver ), "Column headers are matched, Test Passed:)", "Column headers are not matched, Test Failed:(" );
            Log.assertThat( orgName.equalsIgnoreCase( "Chiefs Test Org" ), "Mock orgName is matched! Test Passed:)", "Mock orgName is not matched! Test Failed:(" );
            Log.assertThat( lsPage.verifyFooterIsDispayed( driver ), "Savvas Footer is displayed, Test passed:)", "Savvas Footer is not displayed, Test Failec:(" );           
            Log.assertThat( outputPage.isNextBtnDisplayed(), "Next Button is displayed, Test passed:)", "Next Button is not displayed, Test Failed:(" );
            Log.assertThat( outputPage.isDisableOrEnableBtn("disable", "next"), "Next Button is in disabled state, Test passed:)", "Next Button is not in disabled state, Test Failed:(" );
            Log.assertThat( outputPage.isBackBtnDisplayed(), "Back Button is displayed, Test passed:)", "ack Button is not displayed, Test Failed:(" );
            Log.assertThat( !outputPage.getTheBackButtonStatus(), "Back Button is in disabled state, Test passed:)", "Back Button is not in disabled state, Test Failed:(" );

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            if (null != devTool) {
                RequestMockUtils.closeMock(devTool);
            }
            driver.quit();
        }
    }
    
    
    
    @Test(description = "Verify LS-Admin Read Mock for Zero state", groups = {"SMK-67129", "AdminDashboard", "Reports", "Last Session", "Mock-Reading", "mock"}, priority = 1)
    public void tcLSRReadMock003(ITestContext context) throws Exception {

        // Get driver
        WebDriver driver = WebDriverFactory.get(browser);
        RecentSessionsPage lsPage = new RecentSessionsPage( driver );
        Log.testCaseInfo("Zero state " + browser + "]</b></i></small>");
        
        DevTools devTool = null;
        String reportUrl = smReportsUrl + UUID.randomUUID();
        try {
            if (DevToolsUtils.isMock(context)) {
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("GetReportOptionResponse.json");
                String laAdminReadMock = DevToolsUtils.readJsonResponse("LSAdminReadMockZeroState.json");
                responses.put("GetReportOptionResponse", getReportOptionResponseJson);
                responses.put("GetLSAdminReportData", laAdminReadMock);

                List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetLSAdminReportData");
                devTool = DevToolsUtils.setResponse(driver, lsReportsBFF, requestPayloadMatchers, "post", responses);
                devTool.createSessionIfThereIsNotOne();
                Log.message(devTool.getCdpSession().toString());
            }

            LoginWrapper.loginToMasteryMfe(driver, reportUrl, distAdminUserName, password);
            ReportOutputComponent outputPage = new ReportOutputComponent(driver);
            SMUtils.waitForSpinnertoDisapper(driver);

            SMUtils.nap(20);

            SMUtils.waitForSpinnertoDisapper(driver);
            Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.LAST_SESSION), "Admin LS Run Report option displayed", "Admin LS Run Report is not clicked");
            SMUtils.waitForSpinnertoDisapper(driver, 5);
            
            Log.assertThat( lsPage.verifySMLogoandViewer( driver ), "SM Logo and Report viewer is displayed, Test Passed:)", "SM Logo and Report viewer is not displayed, Test Failed:(" );
            Log.assertThat(  lsPage.verifyOutputTableHeadersRead( driver ), "Column headers are matched, Test Passed:)", "Column headers are not matched, Test Failed:(" );
            Log.assertThat( lsPage.VerifyLSZeroState( driver ), "Zero state mock is verified! Test passed:)", "Zero state mock is not verified! Test Failed:(" );

            
        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            if (null != devTool) {
                RequestMockUtils.closeMock(devTool);
            }
            driver.quit();
        }
    }
    
}