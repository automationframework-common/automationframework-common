package com.savvas.sm.reports.AFG.dataSetup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
// import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.simulatorrun.SimulatorRun;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class AFGDataSetup extends EnvProperties {
    public String smUrl;

    // Common Variable for Mastery Data Generation
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public static String teacherDetails = null;
    public static String teacherUserName, teacherUserId;
    public static String studentDetails1 = null;
    public static String studentUserName1, studentUserId1;
    public static String studentDetails2 = null;
    public static String studentUserName2, studentUserId2;
    public static String studentDetails3 = null;
    public static String studentUserName3, studentUserId3;
    public static String studentDetails4 = null;
    public static String studentUserName4, studentUserId4;
    public static String orgId;
    public static String districtAdminDetails = null;
    public static String districtAdminUserName, districtAdminUserId;
    public static String schoolAdminDetails = null;
    public static String schoolAdminUserName, schoolAdminUserId;
    public static String multiSchoolAdminDetails = null;
    public static String multiSchoolAdminUserName, multiSchoolAdminUserId;

    public static String math_Assignment = "Math_settings" + System.nanoTime();
    public static String reading_Assignment = "Reading_Settings" + System.nanoTime();
    public static String groupName = com.savvas.sm.utils.Constants.GROUP_NAME;

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    // *******************************************//

    private String browser;
    public HashMap<String, String> GroupDetails = new HashMap<>();
    public HashMap<String, String> AssignmentDetails = new HashMap<>();
    public List<String> StudentRumbaIds = new ArrayList<>();
    public List<String> courseIdsForAssign = new ArrayList<>();
    String teacherBearertoken = null;

    @Test
    public void MasteryDataSetupRun() {
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        orgId = RBSDataSetup.organizationIDs.get( school );

        // Fetching Admin Details
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        districtAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userName" );
        districtAdminUserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" );

        schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        schoolAdminUserName = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "userName" );
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "userId" );

        // Fetching Teacher Details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUserName = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        Log.message( teacherUserName );

        // Fetching Student Details
        studentDetails1 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserId1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userId" );
        studentUserName1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userName" );

        studentDetails2 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserId2 = SMUtils.getKeyValueFromResponse( studentDetails2, "userId" );
        studentUserName2 = SMUtils.getKeyValueFromResponse( studentDetails2, "userName" );

        studentDetails3 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserId3 = SMUtils.getKeyValueFromResponse( studentDetails3, "userId" );
        studentUserName3 = SMUtils.getKeyValueFromResponse( studentDetails3, "userName" );

        studentDetails4 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserId4 = SMUtils.getKeyValueFromResponse( studentDetails4, "userId" );
        try {

            // Madhan- Create group with 3students
            // TODO

            // creating groups with students
            StudentRumbaIds.add( studentUserId1 );
            StudentRumbaIds.add( studentUserId2 );
            StudentRumbaIds.add( studentUserId3 );
            StudentRumbaIds.add( studentUserId4 );

            GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            GroupDetails.put( com.savvas.sm.utils.Constants.GROUP_OWNER_ID, teacherUserId );
            GroupDetails.put( com.savvas.sm.utils.Constants.GROUP_ORG_ID, orgId );
            GroupDetails.put( com.savvas.sm.utils.Constants.GROUP_NAME, groupName );
            if ( new GroupAPI().createGroup( smUrl, GroupDetails, StudentRumbaIds ).get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group created for the student !" );
            }
            teacherBearertoken = new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );

            // creating LO courses for Different Mastery status
            courseIdsForAssign.add( new CourseAPI().createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, reading_Assignment ) );
            courseIdsForAssign.add( new CourseAPI().createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, math_Assignment ) );

            // Assigning the courses to the students
            AssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            AssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
            AssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherBearertoken );
            new AssignmentAPI().assignMultipleAssignments( smUrl, AssignmentDetails, StudentRumbaIds, courseIdsForAssign );

        } catch ( Exception e ) {

        } finally {
            Log.message( "Error in Group Creation and course assigning" );
        }

        // For Mastered Status
        try {
            // First student for Mastered ->Student with zero AFG Report 
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName1, math_Assignment, "1", "100", "20" );
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName1, reading_Assignment, "1", "100", "20" );

            // Second student for AtRisk ->Student with AFG Report
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName2, math_Assignment, "2", "50", "20" );
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName2, reading_Assignment, "2", "50", "20" );

            // Third student for Not Mastered ->Student with  AFG Report
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName3, math_Assignment, "5", "0", "50" );
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName3, reading_Assignment, "5", "0", "50" );

        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
