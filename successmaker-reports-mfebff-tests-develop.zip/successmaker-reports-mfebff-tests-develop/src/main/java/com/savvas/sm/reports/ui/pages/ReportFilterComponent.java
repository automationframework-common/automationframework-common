package com.savvas.sm.reports.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.smoke.admin.pages.ReportsBrowserActions;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.IFindBy;

public class ReportFilterComponent extends LeftNavigationBar {

    private final WebDriver driver;
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public ReportFilterComponent( WebDriver driver ) {
        super( driver );
        this.driver = driver;
    }

    @FindBy ( tagName = "h1" )
    WebElement pageTitle;

    @FindBy ( css = "p.description" )
    WebElement pageDescription;

    @FindBy ( css = "cel-accordion-item[class='hydrated']" )
    WebElement studentDemographicsAccordionRoot;

    @FindBy ( css = "cel-accordion-item.optional-filters-wrapper" )
    WebElement optionalFiltersRoot;

    @FindBy ( css = "div label" )
    List<WebElement> dropdownLabels;

    @FindBy ( css = "multi-select[formcontrolname='groups'] cel-multi-select.hydrated" )
    WebElement GroupdropdownBtnParent;

    @FindBy ( css = "div.report-body-wrapper cel-accordion-item" )
    WebElement optionalFilterRoot;

    @FindBy ( css = "cel-single-select.hydrated" )
    WebElement singleSelectRoot;

    @FindBy ( css = "h2.section-main-title" )
    WebElement selectStudentBy;

    @FindBy ( css = "section.filters-main-section label.section-sub-title" )
    WebElement optionalFieldHeader;

    @FindBy ( css = "#savedReportOptions" )
    WebElement saveOptionFilterRoot;

    @FindBy ( css = "#savedReportOptions" )
    WebElement savedFilterRoot;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    List<WebElement> maskStudentAndRemovepageBreaklblRoot;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    WebElement maskStudentlblRoot;

    @FindBy ( tagName = "cel-icon" )
    WebElement helpIconRoot;

    @FindBy ( css = "div.saved-options-wrapper cel-single-select.hydrated" )
    WebElement savedReportOptions;

    @FindBy ( css = "section.additional-filters-section cel-single-select.hydrated" )
    List<WebElement> optionalFiltersDropdownItems;

    @FindBy ( css = "cel-checkbox-item.hydrated" )
    WebElement maskStudentCheckboxParent;

    @FindBy ( css = "div.section-main-title.mt-3.text-uppercase" )
    WebElement courseSelectionLabel;

    // Student Performance Demographics Elements
    @FindBy ( css = ".demographics-wrapper.hydrated" )
    WebElement studentPerformanceDemographicsAccordionRoot;

    @FindBy ( css = "student-demographics-filter div label" )
    List<WebElement> demographicsDropdownLabel;

    @FindBy ( css = "div.row cel-accordion-item.hydrated" )
    WebElement optionalFilterAccordionRoot;

    @FindBy ( css = "div.report-body-wrapper student-performance cel-accordion-item" )
    WebElement optionalFilterRootStudentPerformance;

    @FindBy ( css = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(1)" )
    WebElement includePerformanceSummarylblRoot;

    @FindBy ( css = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(2)" )
    WebElement includePerformanceStrandlblRoot;

    @FindBy ( css = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(3)" )
    WebElement includeAreasOfGrowthlblRoot;

    @FindBy ( css = "#date-at-risk" )
    WebElement dateAtRisklbl;

    @FindBy ( css = "#language" )
    WebElement languagelbl;

    @FindBy ( css = "#display" )
    WebElement displaylbl;

    @FindBy ( css = "section.additional-filters-section label" )
    List<WebElement> lblStaticDropdownHeading;

    @FindBy ( css = "label[for='savedReportOptions']" )
    WebElement studentPerformanceSavedOptionLabel;

    @FindBy ( css = ".save-report-modal.hydrated" )
    WebElement saveReportBtnRoot;

    @FindBy ( css = "cel-text-field[class='hydrated']" )
    WebElement studentPerformanceSavedOptionTextFieldRoot;

    @FindBy ( css = "save-report-options cel-modal" )
    WebElement saveReportButtonParent;

    @FindBy ( css = "saved-report-options cel-single-select" )
    WebElement existingSavedOptionDropdown;

    @FindBy ( css = "body > app-root:nth-child(1) > div:nth-child(1) > teacher-reports-wrapper:nth-child(2) > div:nth-child(1) > div:nth-child(1) > section:nth-child(2) > teacher-report:nth-child(2) > section:nth-child(1) > section:nth-child(2) > form:nth-child(2) > teacher-report-body:nth-child(1) > div:nth-child(1) > section:nth-child(1) > groups-students-filter:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > multi-select:nth-child(1) > cel-multi-select:nth-child(1)" )
    WebElement multiSelectRoot;

    @FindBy ( css = "span.message" )
    WebElement zeroStateMessage;

    @FindBy ( css = "cel-modal-window.d-none.d-sm-block.hydrated" )
    WebElement closeBtnGrandRoot;

    // @FindBy(css="body > app-root:nth-child(1) > div:nth-child(1) >
    // teacher-reports-wrapper:nth-child(2) > div:nth-child(1) > div:nth-child(1) >
    // section:nth-child(2) > teacher-report:nth-child(2) > section:nth-child(1) >
    // section:nth-child(2) > form:nth-child(2) > teacher-report-body:nth-child(1) >
    // div:nth-child(1) > section:nth-child(1) > groups-students-filter:nth-child(1)
    // > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) >
    // div:nth-child(1) > div:nth-child(2) > multi-select:nth-child(1) >
    // cel-multi-select:nth-child(1)")
    // WebElement multiSelectGroupRoot;

    // Child Elements

    private String multiSelectGroupDropdownParent = ".multi-checkbox.hydrated";

    private String multiSelectDropdownRootGroup = "cel-multi-select:nth-child(1)";
    private String multiSelectGroupDropdownRoot = ".multi.row-between";

    private String buttons = "#accordion-button-undefined";
    // private String button = "#accordion-button-undefined > span";

    private String inputWithCheckbox = "input";

    // private String dropdownplaceHolder = "label.dropdown-label";
    private String dropdownPlaceHolder = "span.label";
    private String dropdown = "select#dropdown";

    private String singleSelectSavedReportDropdownRoot = ".single-container";

    private String singleSaveReportDropdownDropdownItem = "#dropdown";

    private String closeBtnRoot = "cel-button.ok-button";

    /**
     * To get the root Element for multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForGroupDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        SMUtils.nap( 10 );
        List<WebElement> e1 = driver.findElements( By.cssSelector( multiSelectDropdownRoot ) );
        return e1.get( 0 );

    }

    /**
     * To get the root Element for multi-select assignment dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForAssignmentDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        SMUtils.nap( 10 );
        List<WebElement> e1 = driver.findElements( By.cssSelector( multiSelectDropdownRoot ) );
        return e1.get( 2 );

    }

    /**
     * To verify the multi-select dropdown is collapsed or not for assignment
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectAssignmentDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForAssignmentDropdown( dropdownName );
        return parentRoot.getText().equalsIgnoreCase( "(All) Selected" );
    }

    /**
     * To verify the multi-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectGroupDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForGroupDropdown( dropdownName );
        return parentRoot.getText().equalsIgnoreCase( "(All) Selected" );
    }

    /**
     * Expand the multi-select group drop-down-group
     * 
     * @param dropdownName
     */
    public void expandMultiSelectGroupDropdown( String dropdownName ) {
        if ( isMultiSelectGroupDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForGroupDropdown( dropdownName );
            Log.message( parentRoot.getText() );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * Expand the multi-select group drop-down-assignment
     * 
     * @param dropdownName
     */
    public void expandMultiSelectAssignmentDropdown( String dropdownName ) {
        if ( isMultiSelectAssignmentDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForAssignmentDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * Expand the group drop-down
     * 
     * @param dropdownName
     */

    /**
     * To select options in multi-select group dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void selectOptionsFromMultiSelectGroupDropdown( String dropdownName, List<String> options ) throws InterruptedException {
        expandMultiSelectGroupDropdown( dropdownName );
        WebElement parentRoot = getRootElementForGroupDropdown( dropdownName );

        SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> options.contains( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    SMUtils.nap( 10 );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                } );

    }

    /**
     * To select options in multi-select assignment dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void selectOptionsFromMultiSelectAssignmentDropdown( String dropdownName, List<String> options ) throws InterruptedException {
        expandMultiSelectAssignmentDropdown( dropdownName );
        WebElement parentRoot = getRootElementForAssignmentDropdown( dropdownName );

        SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> options.contains( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    SMUtils.nap( 20 );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                } );

    }

    /**
     * To get the selected options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */

    /**
     * To get the selected options in multi-select dropdown with input element
     * group checkbox
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getSelectedOptionsFromMultiSelectDropdownWithInput( String dropdownName ) {
        expandMultiSelectGroupDropdown( dropdownName );
        WebElement parentRoot = getRootElementForGroupDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );

        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputWithCheckbox ).isSelected() ).map( element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );

    }

    /**
     * To get the selected options in multi-select dropdown with input element
     * assignment checkbox
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getSelectedOptionsFromAssignmentMultiSelectDropdown( String dropdownName ) {
        expandMultiSelectAssignmentDropdown( dropdownName );
        WebElement parentRoot = getRootElementForAssignmentDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );

        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputWithCheckbox ).isSelected() ).map( element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );

    }

    /**
     * To get the all options in multi-select dropdown with input element
     * assignment checkbox
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAllOptionsFromAssignmentMultiSelectDropdown( String dropdownName ) {
        expandMultiSelectAssignmentDropdown( dropdownName );
        WebElement parentRoot = getRootElementForAssignmentDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );

        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().map(
                element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );

    }

    /**
     * To select options in single-select dropdown
     * 
     * @param dropdownName
     */
    public void selectOptionsFromSingleSelectSaveReportDropdown( String dropdownName, String options ) {
        expandSingleSelectDropdown( dropdownName );
        SMUtils.nap( 4 );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        List<String> saveReport = SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
        if ( saveReport.contains( "SaveReport_02" ) ) {
            Log.message( "Selected Option in " + dropdownName + " - " + options );
        } else {
            Log.fail( "The saved option is not presented under saved report dropdown!!!" );
        }
    }

    @FindBy ( css = "cel-button.ml-auto" )
    WebElement resetButtonRoot;

    @FindBy ( css = "label[for='savedReportOptions']" )
    WebElement savedOptionLabel;

    @FindBy ( css = ".header-checkbox.hydrated" )
    WebElement checkboxRoot;

    @FindBy ( css = "cel-accordion-item.optional-filters-wrapper.hydrated" )
    WebElement orgParent;

    @FindBy ( css = "report-footer cel-button" )
    WebElement runReportButton;

    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportButtonRoot;

    @FindBy ( css = "input#radioStudents" )
    WebElement studentRadioBtn;

    @FindBy ( css = "section.main-filter-section" )
    WebElement grpStudentCourseSection;

    @FindBy ( css = "cel-single-select.hydrated:nth-child(2)" )
    WebElement psrSubjectdropdownplaceHolder;

    @FindBy ( css = "saved-report-options cel-single-select" )
    WebElement psrSavedOptionDropdownplaceholder;

    @FindBy ( css = "#radioGroups" )
    WebElement groupRadioButton;

    @FindBy ( css = "#radioStudents" )
    WebElement studentRadioButton;

    @FindBy ( css = "cel-modal-window" )
    WebElement studentIDPopupparent;

    @FindBy ( css = "div.report-body-wrapper cel-accordion-item.hydrated" )
    WebElement optionalFilterElement;

    @FindBy ( css = "cel-multi-select.hydrated" )
    List<WebElement> multiSelectDropdownList;

    @FindBy ( css = "#sort" )
    WebElement sortRoot;

    @FindBy ( css = "#additional-grouping" )
    WebElement additionalGroupingRoot;

    // Child Elements
    private String multiSelectDropdownRoot = "cel-multi-select.hydrated";
    private String button = "button";
    // private String button = "#accordion-button-undefined > span";
    private String optionalFilterAccordionChild = ".accordion-item.border-bottom";
    private String childMultiCheckBox = "cel-multi-checkbox";
    private String childMultiCheckBoxItems = "cel-checkbox-item";
    private String grandChildCheckBoxLabel = "span.checkbox-label";
    private String orgDropdownDropdownItem = "select#dropdown";
    private String orgDropdown = "div.single-container";

    private String inputCheckboxAdmin = "input";
    private String multiCheckbox = ".multi-checkbox.hydrated";
    private String headerCheckbox = ".header-checkbox.hydrated";
    private String checkbox = "input[type='checkbox']";

    private String inputCheckbox = "label";
    private String additionalGroupingChild = "#dropdown";

    // private String dropdownplaceHolder = "label.dropdown-label";
    private String dropdownplaceHolder = "span.label";
    private String dropdownplaceHolder1 = "select#dropdown";
    private String singleSelectDropdownRoot = "cel-single-select.hydrated";
    private String singleDropdownDropdownItem = "option";
    private String organizationOption = "option[value='%s']";

    /*
     * private String dropdownplaceHolder = "select#dropdown"; private String
     * singleSelectDropdownRoot =
     * "single-select div cel-single-select.hydrated"; private String
     * singleDropdownDropdownItem = "select option";
     */
    private String singleSelectDropRoot = ".single-icon";
    private String optionalFilter = "span.item-heading";
    private String searchFieldRoot = "cel-search-field.search";
    private String searchfieldChild = "input.search-field";
    private String childHelpIcon = "div.icon-inner";
    private String childSavedReportArrow = "cel-icon";
    private String childOrganizationsSearchIcon = "cel-icon-button";

    private String label1 = "label";
    private String singleLabel = "label.single-item";

    private String label = "input";

    private String celbutton = "cel-button";

    private String savedFilterChild = ".dropdown-label";

    private String savedFilterDisabledChild = "#dropdown";

    private String child1 = "cel-icon.item-icon--left";
    private String child2 = "div.icon-inner";

    private String span = "span";
    private String optionalFilterValuesChild = "div.single-container>button>span";
    private String optionalFilterDropdownArrowChild = "div.single-container>button>cel-icon[data-name='caret-down']";
    private String maskStudentCheckboxChild = "label>span.checkbox-label";

    // Student Performance Child Elements
    // Student demographics
    private String demographicDropdownRoot = "multi-select cel-multi-select";
    private String demographicsDropdownplaceHolder = "span.label";
    private String demographicHeaderLabel = "span.item-heading";

    // Optional Filters
    private String includePerformanceSummaryStudent = ".header";
    private String yesBtnRoot = "div:nth-child(1) > div:nth-child(2) > cel-radio-button:nth-child(1)";
    private String noBtnRoot = "div:nth-child(1) > div:nth-child(2) > cel-radio-button:nth-child(2)";
    private String yesBtnChild = "#yes";
    private String noBtnChild = "#no";
    private String optionalFieldPlaceHolder = ".label";
    private String saveBtnRoot = ".hydrated";
    private String saveButtonRoot = ".ok-button.hydrated";
    private String saveButtonChild = ".button.button--solid.center";
    private String saveBtnChild = ".button.button--text.center";
    private String savedReportTextFieldChild = ".text-field";
    private String div = "div";
    private String subjectDropdownvalue = "div li";
    private String studnetIDPopup = "cel-button.hydrated";
    private String multiOptionDropdown = "span.label";

    @FindBy ( css = "th[colspan='1']" )
    WebElement studentParentHeader;

    @FindBy ( css = "tr[class='header'] th:nth-child(2)" )
    WebElement studentInformationHeader;

    @FindBy ( css = "div" )
    WebElement studentNamesParent;

    public String studentNamesChild = "tbody tr td:nth-child(1) div:nth-child(1)";
    public String studentUsername = "tbody tr td:nth-child(2) div:nth-child(1)";
    public String studentID = "tbody tr td:nth-child(3) div:nth-child(1)";
    public String STUDENT = "Student";

    /**
     * To verify the Reset Button is displayed
     */
    public boolean isResetButtonDisplayed() {
        Log.message( "Verify Reset Button" );
        SMUtils.waitForElement( driver, resetButtonRoot );
        WebElement resetButton = SMUtils.getWebElementDirect( driver, resetButtonRoot, button );
        return resetButton.isDisplayed();
    }

    /**
     * To verify the Reset Button is enabled
     */
    public boolean isResetButtonEnabled() {
        Log.message( "Verify Reset Button" );
        SMUtils.waitForElement( driver, resetButtonRoot );
        WebElement resetButton = SMUtils.getWebElementDirect( driver, resetButtonRoot, button );
        return resetButton.isEnabled();
    }

    /**
     * To verify the Run Report Button is displayed
     */
    public boolean isRunReportButtonDisplayed() {
        Log.message( "Verify Run Report Button" );
        SMUtils.waitForElement( driver, runReportButtonRoot );
        WebElement runReportButton = SMUtils.getWebElementDirect( driver, runReportButtonRoot, button );
        return runReportButton.isDisplayed();

    }

    /**
     * To verify the Run Report Button is enabled
     */
    public boolean isRunReportButtonEnabled() {
        Log.message( "Verify Run Report Button" );
        SMUtils.waitForElement( driver, runReportButtonRoot );
        WebElement runReportButton = SMUtils.getWebElementDirect( driver, runReportButtonRoot, button );
        return runReportButton.isEnabled();

    }

    /**
     * Verify Optional Filters is displaying
     * 
     * @return
     */
    public Boolean isOptionalFilterFilledArrowDisplaying() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterRoot, childSavedReportArrow );
        Log.message( "Verify Optional filter filled arrow is displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * Verify Optional Filters Dropdowns count
     * 
     * @return
     */
    public int verifyOptionalFilterDropdownsCount() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        int count = optionalFiltersDropdownItems.size();
        Log.message( "Verify Optional filter dropdown count" );
        return count;
    }

    private String AdditionalGrouping = "div ul.single-dropdown>li.item";

    /**
     * Verify Default Value of Additional Grouping
     * 
     * @return
     */
    public String verifyAdditionalGroupingValue() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFiltersDropdownItems.get( 0 ), optionalFilterValuesChild );
        Log.message( "Verify Default Value of Additional Grouping" );
        return actualElement.getText().trim();
    }

    /**
     * Verify Default Value of Display Dropdown
     * 
     * @return
     */
    public String verifyDisplayDropdownValue() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFiltersDropdownItems.get( 1 ), optionalFilterValuesChild );
        Log.message( "Verify Default Value of Display Dropdown" );
        return actualElement.getText().trim();
    }

    /**
     * Verify Default Value of Sort Dropdown
     * 
     * @return
     */
    public String verifySortDropdownValue() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFiltersDropdownItems.get( 2 ), optionalFilterValuesChild );
        Log.message( "Verify Default Value of Sort Dropdown" );
        return actualElement.getText().trim();
    }

    /**
     * Verify Default Value of Date At Risk Dropdown
     * 
     * @return
     */
    public String verifyDateAtRiskDropdownValue() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFiltersDropdownItems.get( 3 ), optionalFilterValuesChild );
        Log.message( "Verify Default Value of Date At Risk Dropdown" );
        return actualElement.getText().trim();
    }

    /**
     * Verify Optional Filter Dropdown Arrows Pointing Downward Direction
     * 
     * @return
     */
    public void verifyDropdownArrowDirection() {
        Log.message( "Verify Optional Filter Dropdown Arrows Pointing Downward Direction" );
        SMUtils.waitForElement( driver, optionalFilterRoot );
        for ( int i = 0; i < 4; i++ ) {
            WebElement actualElement = SMUtils.getWebElement( driver, optionalFiltersDropdownItems.get( i ), optionalFilterDropdownArrowChild );
            boolean status = actualElement.isDisplayed();
            if ( i == 0 && status ) {
                Log.message( "Additional Grouping Dropdown Arrows Pointing Downward Direction" );
            } else if ( i == 1 && status ) {
                Log.message( "Display Dropdown Arrows Pointing Downward Direction" );
            } else if ( i == 2 && status ) {
                Log.message( "Sort Dropdown Arrows Pointing Downward Direction" );
            } else if ( i == 3 && status ) {
                Log.message( "Date At Risk Dropdown Arrows Pointing Downward Direction" );
            }
        }

    }

    /**
     * Verify the Check box with the Text Mask Student Display
     * 
     * @return
     */
    public String verifyCheckboxWithMaskStudent() {
        SMUtils.waitForElement( driver, maskStudentCheckboxParent );
        WebElement actualElement = SMUtils.getWebElement( driver, maskStudentCheckboxParent, maskStudentCheckboxChild );
        Log.message( "Verify the Check box with the Text Mask Student Display" );
        return actualElement.getText().trim();
    }

    /**
     * Verify the Dropdown Displayed
     * 
     * @return
     */
    public boolean isDropdownDisplyed( String dropdownName ) {
        boolean flag = false;
        SMUtils.waitForElement( driver, dropdownLabels.get( 0 ) );
        Log.message( "Verify Dropdown is Displayed" );
        for ( int i = 0; i < dropdownLabels.size(); i++ ) {

            flag = dropdownLabels.get( i ).getText().trim().equals( dropdownName );
            if ( flag )
                break;
        }
        return flag;

    }

    /**
     * Verify Saved Report Options Text
     * 
     * @return
     */
    public String getSavedReportOptionsText() {
        SMUtils.waitForElement( driver, savedReportOptions );
        WebElement actualElement = SMUtils.getWebElement( driver, savedReportOptions, dropdownplaceHolder );
        Log.message( "Verify the Check box with the Text Mask Student Display" );
        return actualElement.getText().trim();
    }

    /**
     * To verify the Report title is displaying or not
     * 
     * @return
     */
    public boolean isReportTitleDisplayed() {

        Log.message( "Verifing Report Title is displayed in output Page" );

        SMUtils.waitForElement( driver, pageTitle );
        return pageTitle.isDisplayed();
    }

    /**
     * To get the Report Title
     * 
     * @return
     */
    public String getReportTitle() {
        Log.message( "Getting Report Title" );
        SMUtils.waitForElement( driver, pageTitle );
        return pageTitle.getText().trim();
    }

    /**
     * To get the Report description
     * 
     * @return
     */
    public String getReportDescription() {
        Log.message( "Getting Recent Session Description" );
        SMUtils.waitForElement( driver, pageDescription );
        return pageDescription.getText().trim();
    }

    /**
     * To verify the Report description is displaying or not
     * 
     * @return
     */
    public boolean isReportDescriptionDisplayed() {
        Log.message( "Verifing Recent Session Description is displayed" );
        SMUtils.waitForElement( driver, pageDescription );
        return pageDescription.isDisplayed();
    }

    /**
     * To verify the help icon
     * 
     * @return
     */
    public boolean isHelpIconDisplayed() {
        Log.message( "Verifing reports help icon is displayed" );
        SMUtils.waitForElement( driver, helpIconRoot );
        WebElement iconWebElement = SMUtils.getWebElement( driver, helpIconRoot, childHelpIcon );
        return iconWebElement.isDisplayed();

    }

    /**
     * To Verify the Label is displayed or not
     * 
     * @return
     */
    public boolean isDropdownLabelDisplayed( String dropdownName ) {
        Log.message( "Verifing drodpown Label is displayed" );
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equals( dropdownName ) ).allMatch( WebElement::isDisplayed );
    }

    /**
     * To get the student demographic drop-down labels for
     * 
     * @return
     */
    public List<String> getDropdownLabels() {
        Log.message( "Getting drodown labels!" );
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get the course selection label
     * 
     * @return
     */
    public String getCourseSelectionLabel() {
        Log.message( "Getting Course Selection text" );
        SMUtils.waitForElement( driver, courseSelectionLabel );
        return courseSelectionLabel.getText().trim();
    }

    /**
     * To get the root Element for multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( multiSelectDropdownRoot ) );
    }

    /**
     * To verify the Multi-select is Displaying or not
     * 
     * @return
     */
    public boolean isMultiSelectDropDownDisplayed( String dropdownName ) {
        Log.message( "Verifing " + dropdownName + "Drop Down is displayed" );
        return getRootElementForMultiSelectDropdown( dropdownName ).isDisplayed();
    }

    /**
     * To verify the multi-select dropdown arrow is displayed or not
     * 
     * @return
     */
    public boolean isMultiSelectDropDownArrowDisplayed( String dropdownName ) {
        Log.message( "Verifing  Save Report Option Drop Down Arrow is displayed" );
        return SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), childSavedReportArrow ).isDisplayed();
    }

    /**
     * To get arrow direction for multi select dropdown
     * 
     * @return
     */
    public String getMultiSelectDropdownArrowDirection( String dropdownName ) {
        Log.message( "Getting " + dropdownName + " drop down arrow direction" );
        String value = SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), childSavedReportArrow ).getAttribute( "data-name" ).trim();
        return value.equals( "caret-down" ) ? "Down" : "Up";
    }

    /**
     * To verify the multi-Select dropdown is enabled or not
     * 
     * @return
     */
    public boolean isMultiSelectDropdownEnabled( String dropdownName ) {
        Log.message( "Verifying" + dropdownName + " drop down is enabled" );
        return SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), button ).isEnabled();
    }

    /**
     * To verify the multi-select dropdown is expanded or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectDropdownExpanded( String dropdownName ) {
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return !SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * To verify the multi-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * Expand the multi-select drop-down
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void expandMultiSelectDropdown( String dropdownName ) {
        if ( isMultiSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.waitForElementToBeClickable( parentRoot, driver );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            SMUtils.nap( 5 );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * Expand the group drop-down
     * 
     * @param dropdownName
     */
    public void expandGroupSelectDropdown() {
        WebElement groupDropDown = SMUtils.getWebElementDirect( driver, GroupdropdownBtnParent, div );
        SMUtils.clickJS( driver, groupDropDown );
        Log.message( "Expanded Groups drop-down" );

    }

    /**
     * To Collapse the multi-select drop-down
     * 
     * @param dropdownName
     */
    public void collapseMultiSelectDropdown( String dropdownName ) {
        if ( isMultiSelectDropdownExpanded( dropdownName ) ) {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Collapsed " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get available options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getAvailableOptionsFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 40 );
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.waitForElement( driver, parentRoot );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().map(
                element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To select options in multi-select dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void selectOptionsFromMultiSelectDropdown( String dropdownName, List<String> options ) throws InterruptedException {
        SMUtils.nap( 30 );
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> options.contains( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    SMUtils.nap( 5 );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                } );
    }

    /**
     * To get the selected options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getSelectedOptionsFromMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputCheckboxAdmin ).isSelected() && !SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim().equalsIgnoreCase( ReportsUIConstants.ALL_OPTION ) ).map(
                        element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get the place holder in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder ).getText().trim();
    }

    /**
     * Search Bar for group
     * 
     * @return
     */
    public Boolean isSearchBarDisplay( String dropdowName ) {
        WebElement atualElementParent = SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdowName ), searchFieldRoot );
        WebElement atualElement = SMUtils.getWebElement( driver, atualElementParent, searchfieldChild );
        return atualElement.isDisplayed();
    }

    /**
     * To Verify the search icon in Multi-Select dropdown
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isSearchIconDisplayedForMultiSelectDropdown( String dropdownName ) throws InterruptedException {
        Log.message( "Verifying" + dropdownName + " Drop Down Search Box -> Search Icon is displayed" );
        expandMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElementDirect( driver, getRootElementForMultiSelectDropdown( dropdownName ), searchFieldRoot, childOrganizationsSearchIcon, button ).isDisplayed();

    }

    /**
     * To Verify the place holder in search box
     * 
     * @return
     * @throws InterruptedException
     */
    public String getMultiSelectSearchPlaceHolder( String dropdownName ) throws InterruptedException {
        Log.message( "Getting" + dropdownName + "drop down Search water mark text" );
        expandMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElement( driver, SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdownName ), searchFieldRoot ), inputCheckbox ).getAttribute( "placeholder" );
    }

    /**
     * To get the root Element for single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelectDropdown( String dropdownName ) {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            SMUtils.waitForElement( driver, optionalFilterRoot );
            return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );

        } catch ( InterruptedException e ) {
            Log.message( "Getting Issue while get the Organization dropdown root element!!!" );
            return null;
        }
    }

    /**
     * To get the root Element for single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelect( String dropdownName ) {
        SMUtils.waitForElement( driver, singleSelectRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropRoot ) );
    }

    /**
     * To verify the Single dropdown is Displaying or not
     * 
     * @return
     */
    public boolean isSingleSelectDropDownDisplayed( String dropdownName ) {
        Log.message( "Verifing " + dropdownName + "Drop Down is displayed" );
        return getRootElementForSingleSelectDropdown( dropdownName ).isDisplayed();
    }

    /**
     * To verify the single select dropdown arrow is displayed or not
     * 
     * @return
     */
    public boolean isSingleSelectDropDownArrowDisplayed( String dropdownName ) {
        Log.message( "Verifing " + dropdownName + " Drop Down Arrow is displayed" );
        return SMUtils.getWebElement( driver, getRootElementForSingleSelectDropdown( dropdownName ), childSavedReportArrow ).isDisplayed();
    }

    /**
     * To get arrow direction for single select dropdown
     * 
     * @return
     */
    public String getSingleSelectDropdownArrowDirection( String dropdownName ) {
        Log.message( "Getting " + dropdownName + " drop down arrow direction" );
        String value = SMUtils.getWebElement( driver, getRootElementForSingleSelectDropdown( dropdownName ), childSavedReportArrow ).getAttribute( "data-name" ).trim();
        return value.equals( "caret-down" ) ? "Down" : "Up";
    }

    /**
     * To verify the single-select dropdown is expanded or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownExpanded( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return !SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * To verify the single-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * Expand the single-select drop-down
     * 
     * @param dropdownName
     */
    public void expandSingleSelectDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded" + dropdownName + "drop-down" );

        }
    }

    /**
     * To Collapse the single-select drop-down
     * 
     * @param dropdownName
     */
    public void collapseSingleSelectDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownExpanded( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Collapsed " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get available options in single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAvailableOptionsFromSingleSelectDropdown( String dropdownName ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );

    }

    /**
     * To get water-mark text in single-select save report dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getWatermarkTextForSaveReportDropdown( String dropdownName ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ).get( 0 );

    }

    /**
     * To get placeholder text in single-select Additional Grouping dropdown
     * 
     * @return
     */
    public String getAdditionalGroupingDropdownPlaceholder() {
        WebElement actualElement = SMUtils.getWebElementDirect( driver, additionalGroupingRoot, additionalGroupingChild );
        return actualElement.getAttribute( "data-selected" ).trim();

    }

    /**
     * To get placeholder text in single-select Sort dropdown
     * 
     * @return
     */
    public String getSortDropdownPlaceholder() {
        WebElement actualElement = SMUtils.getWebElementDirect( driver, sortRoot, additionalGroupingChild );
        return actualElement.getAttribute( "data-selected" ).trim();

    }

    /**
     * To get available options in single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getSelectedTextForSaveReportDropdown( String dropdownName ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ).get( 1 );

    }

    /**
     * To get available options in single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAvailableOptionsFromSubjectDropdown() {
        List<String> subDropDownValues = new ArrayList<String>();
        expandSingleSelectDropdown( "Subject" );
        List<WebElement> subValuesList = SMUtils.getWebElementsDirect( driver, psrSubjectdropdownplaceHolder, "li" );
        for ( WebElement e : subValuesList ) {
            subDropDownValues.add( e.getText().toString() );
        }

        return subDropDownValues;
    }

    /**
     * To get available options in single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAvailableOptionsFromSavedReportOptionDropdown() {
        List<String> saveOptionDropDown = new ArrayList<String>();

        List<WebElement> savedList = SMUtils.getWebElementsDirect( driver, psrSavedOptionDropdownplaceholder, "select#dropdown option" );
        for ( WebElement e : savedList ) {
            saveOptionDropDown.add( e.getText().toString() );
        }

        return saveOptionDropDown;
    }

    /**
     * To select options in single-select dropdown
     * 
     * @param dropdownName
     */
    public void selectOptionsFromSingleSelectDropdown( String dropdownName, String options ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement optionElement;

        if ( dropdownName.equals( ReportsUIConstants.ORGANIZATIONS_LABEL ) ) {
            RBSUtils rbsUtils = new RBSUtils();
            String selectedOrgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), options );
            if ( Objects.isNull( selectedOrgId ) ) {
                String subDistrictOrgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1] );
                optionElement = SMUtils.getWebElementDirect( driver, parentRoot, String.format( organizationOption, rbsUtils.getOrganizationIDByName( subDistrictOrgId, options ) ) );
            } else {
                optionElement = SMUtils.getWebElementDirect( driver, parentRoot, String.format( organizationOption, selectedOrgId ) );
            }
        } else {
            optionElement = SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().filter( element -> options.equalsIgnoreCase( element.getText().trim() ) ).findFirst().orElse( null );
        }

        if ( !Objects.isNull( optionElement ) ) {
            SMUtils.click( driver, optionElement );
            Log.message( "Selected Option in " + dropdownName + " - " + options );
        } else {
            Log.fail( "The Selected option " + options + " is not presented under " + dropdownName + "dropdown!!!" );
        }

    }

    /**
     * To select options in single-select save dropdown
     * 
     * @param dropdownName
     */
    public void selectOptionsFromSingleSelectSaveDropdown( String dropdownName, String options ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement optionElement;

        optionElement = SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().filter( element -> options.equalsIgnoreCase( element.getText().trim() ) ).findFirst().orElse( null );

        if ( !Objects.isNull( optionElement ) ) {
            SMUtils.click( driver, optionElement );
            Log.message( "Selected Option in " + dropdownName + " - " + options );
        } else {
            Log.fail( "The Selected option " + options + " is not presented under " + dropdownName + "dropdown!!!" );
        }

    }

    /**
     * To get the place holder in Single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromSingleSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        String orgId = SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder1 ).getAttribute( "value" );
        RBSUtils rbsUtils = new RBSUtils();
        String orgNameFromId = rbsUtils.getOrg( orgId );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder ).getText().trim();

    }

    /**
     * To get the place holder in Single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromSingleSelectDropdownNew( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder1 ).getAttribute( "data-selected" );

    }

    /**
     * To get the place holder in Single-select saved report dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromSingleSelectSaveDropdown() {
        SMUtils.waitForElement( driver, savedFilterRoot );
        String savedPlaceholder = SMUtils.getWebElementDirect( driver, savedFilterRoot, savedFilterChild ).getText();
        return savedPlaceholder;
    }

    /**
     * To get the place holder in Single-select saved report dropdown when
     * disabled
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromSingleSelectDisabledSaveDropdown() {
        SMUtils.waitForElement( driver, savedFilterRoot );
        String savedDisabledPlaceholder = SMUtils.getWebElementDirect( driver, savedFilterRoot, savedFilterDisabledChild ).getText();
        return savedDisabledPlaceholder;
    }

    /**
     * To get the place holder in Single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromSingleSelectSubjectDropdown( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        String subPlaceholder = SMUtils.getWebElementDirect( driver, parentRoot, savedFilterChild ).getText().trim();
        return subPlaceholder;

    }

    /**
     * To get the place holder in Single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getDefaultSubjectFromSingleSelectDropdown() {
        SMUtils.waitForElement( driver, psrSubjectdropdownplaceHolder );
        return SMUtils.getWebElementDirect( driver, psrSubjectdropdownplaceHolder, div ).getText().trim();
    }

    /**
     * Verify Optional Filters is displaying
     * 
     * @return
     */
    public Boolean isOptionalFilterDisplaying() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterRoot, optionalFilter );
        Log.message( "Verify Optional filter is displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * Get Text of select student By
     * 
     * @return
     */
    public String getSelectStudentBy() {
        SMUtils.waitForElement( driver, selectStudentBy );
        Log.message( "Get text of select student by" );
        return selectStudentBy.getText().trim();
    }

    /**
     * Get mask student label
     * 
     * @return
     */
    public List<String> getMaskStudentDisplayAndRemovePageBreaklbl() {
        // SMUtils.waitForElement( driver, selectStudentBy );
        Log.message( "Getting Mask student display and Remove Page Break text" );
        return maskStudentAndRemovepageBreaklblRoot.stream().map( element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get the Student Demographic label
     * 
     * @return
     */
    public String getStudentDemographicsLabel() {
        SMUtils.waitForElement( driver, studentDemographicsAccordionRoot );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, studentDemographicsAccordionRoot, optionalFilter ), driver );
    }

    /**
     * To Expand Student Demographics filters
     * 
     */
    public boolean expandStudentDemographics() {
        SMUtils.waitForElement( driver, studentDemographicsAccordionRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentDemographicsAccordionRoot, button ) );
        SMUtils.scrollDownPage( driver );
        if ( dropdownLabels.stream().allMatch( element -> element.isDisplayed() ) ) {
            Log.message( "Student demographics Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expnad the Student demographics!" );
            return false;
        }
    }

    /**
     * To Expand Student Demographics filters
     * 
     */
    public boolean expandOptionalFilters() {
        SMUtils.waitForElement( driver, optionalFiltersRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, optionalFiltersRoot, button ) );
        SMUtils.scrollDownPage( driver );
        if ( selectStudentBy.isDisplayed() ) {
            Log.message( "Optional Filter Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expanding the Optional Filter!" );
            return false;
        }
    }

    /**
     * To Expand Student Demographics filters
     * 
     */
    public boolean expandDemographicFilters() {
        SMUtils.waitForElement( driver, studentDemographicsAccordionRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentDemographicsAccordionRoot, buttons ) );
        SMUtils.scrollDownPage( driver );
        if ( optionalFieldHeader.isDisplayed() ) {
            Log.message( "Demographic Filter Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expanding the Demographic Filter!" );
            return false;
        }
    }

    // Student Performance Demographics Methods

    /**
     * To get the Student Demographic label
     * 
     * @return
     */
    public String getStudentDemographicsLabelForStudentPerformance() {
        SMUtils.waitForElement( driver, studentPerformanceDemographicsAccordionRoot );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, studentPerformanceDemographicsAccordionRoot, demographicHeaderLabel ), driver );
    }

    /**
     * To Expand Student Demographics filters
     * 
     */
    public boolean expandStudentPerformanceDemographics() {
        SMUtils.waitForElement( driver, studentPerformanceDemographicsAccordionRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentPerformanceDemographicsAccordionRoot, button ) );
        SMUtils.scrollDownPage( driver );
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.visibilityOfAllElements( demographicsDropdownLabel ) );
        if ( demographicsDropdownLabel.stream().allMatch( element -> element.isDisplayed() ) ) {
            Log.message( "Student demographics Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expnad the Student demographics!" );
            return false;
        }

    }

    /**
     * To get the root Element for demographics dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForDemographicsDropdown( String dropdownName ) {
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.visibilityOfAllElements( demographicsDropdownLabel ) );
        return demographicsDropdownLabel.stream().filter( element -> SMUtils.getTextOfWebElement( element, driver ).equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement(
                By.cssSelector( demographicDropdownRoot ) );
    }

    /**
     * To verify the demographic dropdowns is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isDemographicDropdownsCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * Expand the student demographic drop-down
     * 
     * @param dropdownName
     */
    public void expandStudentDemographicsDropdown( String dropdownName ) {
        if ( isDemographicDropdownsCollapsed( dropdownName ) ) {
            SMUtils.scrollToBottomOfPage( driver );
            WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get the student demographic drop-down labels for
     * 
     * @return
     */
    public List<String> getDemographicDropdownLabels() {
        Log.message( "Getting drodown labels!" );
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.visibilityOfAllElements( demographicsDropdownLabel ) );
        return SMUtils.getAllTextFromWebElementList( demographicsDropdownLabel );
    }

    /**
     * To get available options in student demographic dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getAvailableOptionsFromStudentDemographicsDropdown( String dropdownName ) {
        expandStudentDemographicsDropdown( dropdownName );
        WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().map(
                element -> SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ), driver ) ).collect( Collectors.toList() );
    }

    /**
     * To select options in student demographic dropdown
     * 
     * @param dropdownName
     */
    public void selectOptionsFromDemographicsDropdown( String dropdownName, List<String> options ) {
        expandStudentDemographicsDropdown( dropdownName );
        WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
        SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> options.contains( SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ), driver ) ) ).forEach( element -> {
                    SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ), driver ) );
                } );
    }

    /**
     * To verify the demographic dropdowns is expanded or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isDemographicDropdownsExpanded( String dropdownName ) {
        WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
        return !SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * To Collapse the student demographic drop-down
     * 
     * @param dropdownName
     */
    public void collapseStudentDemographicsDropdown( String dropdownName ) {
        if ( isDemographicDropdownsExpanded( dropdownName ) ) {
            SMUtils.scrollToBottomOfPage( driver );
            WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Collapsed " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get the selected options in student demographic dropdown
     * 
     * @param dropdownName
     * @return
     */
    public List<String> getSelectedOptionsFromDemographicsDropdown( String dropdownName ) {
        expandStudentDemographicsDropdown( dropdownName );
        WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputCheckbox ).isSelected() && !SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim().equalsIgnoreCase( ReportsUIConstants.ALL_OPTION ) ).map(
                        element -> SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ), driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get the place holder in student demographic dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromDemographicsDropdown( String dropdownName ) {
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.visibilityOfAllElements( demographicsDropdownLabel ) );
        WebElement parentRoot = getRootElementForDemographicsDropdown( dropdownName );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, parentRoot, demographicsDropdownplaceHolder ), driver );
    }

    // Student Performance Optional Fields Methods
    /**
     * Get mask student label for Student Performance
     * 
     * @return
     */
    public String getMaskStudentDisplaylbl() {
        SMUtils.waitForElement( driver, maskStudentlblRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, maskStudentlblRoot, grandChildCheckBoxLabel );
        Log.message( "Getting Mask student display text" );
        return actualElement.getText().trim();
    }

    /**
     * Verify Optional Filters is displaying for Student Performance
     * 
     * @return
     */
    public Boolean isOptionalFilterDisplayingForStudentPerformance() {
        SMUtils.waitForElement( driver, optionalFilterRootStudentPerformance );
        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterRootStudentPerformance, optionalFilter );
        Log.message( "Optional filter is displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * To get the root Element for single-select dropdown for Student
     * Performance
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelectDropdownStudentPerformance( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRootStudentPerformance );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );
    }

    /**
     * To verify the single-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownCollapsedForStudentPerformance( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdownStudentPerformance( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * Expand the single-select drop-down for student performance optional
     * filter
     * 
     * @param dropdownName
     */
    public void expandSingleSelectDropdownForStudentPerformance( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsedForStudentPerformance( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdownStudentPerformance( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * Get Include Performance Summary Label
     * 
     * @return
     */
    public String getIncludePerformanceSummarylbl() {
        SMUtils.waitForElement( driver, includePerformanceSummarylblRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, includePerformanceSummarylblRoot, includePerformanceSummaryStudent );
        Log.message( "Getting Include Performance Summary text" );
        return actualElement.getText().trim();
    }

    /**
     * Get Include Performance By Strand Label
     * 
     * @return
     */
    public String getIncludePerformanceStrandlbl() {
        SMUtils.waitForElement( driver, includePerformanceStrandlblRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, includePerformanceStrandlblRoot, includePerformanceSummaryStudent );
        Log.message( "Getting Include Performance By Strand text" );
        return actualElement.getText().trim();

    }

    /**
     * Get Include Areas of Growth Label
     * 
     * @return
     */
    public String getIncludeAreasOfGrowthlbl() {
        SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, includePerformanceSummaryStudent );
        Log.message( "Getting Include Areas of Growth text" );
        return actualElement.getText().trim();

    }

    /**
     * Click Yes Radio button
     * 
     * @param dropDownName
     */
    public void clickYesRadioButton( String type ) {
        WebElement yesParentElement;
        if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ) ) {
            SMUtils.waitForElement( driver, includePerformanceSummarylblRoot );
            yesParentElement = SMUtils.getWebElement( driver, includePerformanceSummarylblRoot, yesBtnRoot );
        } else if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ) ) {
            SMUtils.waitForElement( driver, includePerformanceStrandlblRoot );
            yesParentElement = SMUtils.getWebElement( driver, includePerformanceStrandlblRoot, yesBtnRoot );
        } else {
            SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
            yesParentElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, yesBtnRoot );
        }

        WebElement atualElement = SMUtils.getWebElement( driver, yesParentElement, yesBtnChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked Yes Radio Button" );

    }

    /**
     * Click No Radio button
     * 
     * @param dropDownName
     */
    public void clickNoRadioButton( String type ) {
        WebElement noParentElement;
        if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ) ) {
            SMUtils.waitForElement( driver, includePerformanceSummarylblRoot );
            noParentElement = SMUtils.getWebElement( driver, includePerformanceSummarylblRoot, noBtnRoot );
        } else if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ) ) {
            SMUtils.waitForElement( driver, includePerformanceStrandlblRoot );
            noParentElement = SMUtils.getWebElement( driver, includePerformanceStrandlblRoot, noBtnRoot );
        } else {
            SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
            noParentElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, noBtnRoot );
        }

        WebElement atualElement = SMUtils.getWebElement( driver, noParentElement, noBtnChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked No Radio Button" );

    }

    /**
     * To get the root Element for demographics dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForOptionalFilterDropdown( String dropdownName ) {
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.visibilityOfAllElements( lblStaticDropdownHeading ) );
        return demographicsDropdownLabel.stream().filter( element -> SMUtils.getTextOfWebElement( element, driver ).equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement(
                By.cssSelector( demographicDropdownRoot ) );
    }

    /**
     * To get the default items in single select dropdown optional filters
     * 
     * @param type
     */
    public String getDefaultItemsForOptionalReport( String type ) {
        WebElement textElement;
        if ( type.equals( ReportsUIConstants.DISPLAY_LABEL ) ) {
            SMUtils.waitForElement( driver, displaylbl );
            textElement = SMUtils.getWebElement( driver, displaylbl, optionalFieldPlaceHolder );
        } else if ( type.equals( ReportsUIConstants.LANGUAGE ) ) {
            SMUtils.waitForElement( driver, languagelbl );
            textElement = SMUtils.getWebElement( driver, languagelbl, optionalFieldPlaceHolder );
        } else {
            SMUtils.waitForElement( driver, dateAtRisklbl );
            textElement = SMUtils.getWebElement( driver, dateAtRisklbl, optionalFieldPlaceHolder );
        }
        Log.message( textElement.getText() );
        return textElement.getText();
    }

    /**
     * To expand optional filter
     *
     * 
     * @return
     */
    public boolean expandOptionalFilter() {

        SMUtils.waitForElement( driver, optionalFilterElement );

        WebElement actualElement = SMUtils.getWebElement( driver, optionalFilterElement, button );
        SMUtils.click( driver, actualElement );
        SMUtils.scrollDownPage( driver );
        if ( dropdownLabels.stream().allMatch( element -> !element.isDisplayed() ) ) {

            Log.message( "Optional filter Expanded sucessfully!" );
            return true;
        } else {
            Log.message( "Issue in Expand the Optional filter!" );
            return false;
        }

    }

    /**
     * To get the SAVED REPORT OPTIONS label
     * 
     * @return
     */
    public String getSavedReportOptionLabelForStudentPerformance() {
        SMUtils.waitForElement( driver, studentPerformanceSavedOptionLabel );
        return SMUtils.getTextOfWebElement( studentPerformanceSavedOptionLabel, driver );
    }

    /**
     * Click Save Report Option button
     * 
     */
    public void clickSaveReportButton() {
        WebElement saveParentElement;
        SMUtils.waitForElement( driver, saveReportBtnRoot );
        saveParentElement = SMUtils.getWebElement( driver, saveReportBtnRoot, saveBtnRoot );
        WebElement atualElement = SMUtils.getWebElement( driver, saveParentElement, saveBtnChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked Save Report Option Button" );
    }

    /**
     * Click Save Button
     * 
     */
    public void clickSaveButton() {
        WebElement saveBtnParentElement;
        SMUtils.waitForElement( driver, saveReportBtnRoot );
        saveBtnParentElement = SMUtils.getWebElement( driver, saveReportBtnRoot, saveButtonRoot );
        WebElement atualElement = SMUtils.getWebElement( driver, saveBtnParentElement, saveButtonChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked Save Button" );
    }

    /**
     * To enter text in Save Report textbox
     * 
     * @return
     */
    public void enterNameForSaveReport( String title ) {
        SMUtils.waitForElement( driver, studentPerformanceSavedOptionTextFieldRoot );
        WebElement textField = SMUtils.getWebElementDirect( driver, studentPerformanceSavedOptionTextFieldRoot, savedReportTextFieldChild );
        SMUtils.clickJS( driver, textField );
        textField.clear();
        textField.sendKeys( title );
        Log.message( "Entered value as: " + title );

    }

    /**
     * To get the color of place holder in Single-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws Exception
     */
    public boolean getPlaceHolderTextColorForSingleSelectDropdown( String dropdownName ) throws Exception {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement actualElement = SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder );
        Log.message( "Verifying color is displaying" );
        return SMUtils.checkColor( actualElement, ReportsUIConstants.SAVED_REPORT_OPTIONS_TEXT_COLOR );
    }

    /**
     * To click the Save Report options button
     * 
     */
    public SaveReportFilterPopup clickSaveReportOptionButton() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ) );
        return new SaveReportFilterPopup( driver ).get();
    }

    /**
     * To click the Save Report options button
     * 
     * @return
     */
    public String getLabelFromSaveReportOptionButton() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        return SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ).getText().trim();
    }

    /**
     * To verify the save report option button is enabled
     * 
     * @return
     */
    public boolean isSaveReportButtonEnabled() {
        SMUtils.waitForElement( driver, saveReportButtonParent );
        return SMUtils.getWebElementDirect( driver, saveReportButtonParent, celbutton, button ).isEnabled();
    }

    /**
     * To get the SAVED REPORT OPTIONS label
     * 
     * @return
     */
    public String getSavedReportOptionLabel() {
        SMUtils.waitForElement( driver, savedOptionLabel );
        return SMUtils.getTextOfWebElement( savedOptionLabel, driver );
    }

    /**
     * To Click Reset Button
     */
    public void clickResetButton() {
        SMUtils.waitForElement( driver, resetButtonRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, resetButtonRoot, button ) );
        Log.message( "Clicked Reset Button!" );
    }

    /**
     * To Click Run Report Button
     */
    public boolean clickRunReportButton() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, runReportButtonRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, runReportButtonRoot, button ) );
            Log.message( "Clicked Run Report Button!" );
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Clicked Run Report Button Failed" );
            return false;
        }
    }

    private String singleSelectDropdownChildcss = "div.single-container ul#dropdown li.item";

    /**
     * Get Single Select Dropdown Options
     * 
     * @return
     */
    public void getSingleSelectDropdownOptions() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        List<WebElement> dropdownOptions = SMUtils.getWebElements( driver, optionalFiltersDropdownItems.get( 2 ), singleSelectDropdownChildcss );
        // Log.message("Verify Default Value of Date At Risk Dropdown");
        System.out.println( dropdownOptions.get( 1 ).getText() );
    }

    /**
     * Enter Text in Search Bar
     * 
     * @return
     */
    public void enterTextInSearchBar( String dropdowName, String Text ) {
        WebElement atualElementParent = SMUtils.getWebElement( driver, getRootElementForMultiSelectDropdown( dropdowName ), searchFieldRoot );
        WebElement searchBar = SMUtils.getWebElement( driver, atualElementParent, searchfieldChild );
        SMUtils.clickJS( driver, searchBar );
        searchBar.sendKeys( Text );
        Log.message( "Entered value as: " + Text );

    }

    /***
     * Click on Students Radio Btn
     * 
     * @return
     */
    public void checkStudntRadioBtn() {
        SMUtils.waitForElement( driver, studentRadioBtn );
        SMUtils.clickJS( driver, studentRadioBtn );
        Log.message( "Clicked Studnets Radio Button" );

    }

    public void clickGroupRadioButton() {
        SMUtils.waitForElement( driver, groupRadioButton );
        SMUtils.clickJS( driver, groupRadioButton );
        Log.message( "Clicked Group radio button!!!" );
    }

    public boolean isGroupButtonClickable() {
        boolean flag = false;
        try {
            SMUtils.waitForElement( driver, groupRadioButton );
            SMUtils.clickJS( driver, groupRadioButton );
            Log.message( "Clicked Group radio button!!!" );
            flag = true;
        } catch ( Exception e ) {
            Log.message( "The Group Radio Button is not clickable" );
        }
        return flag;
    }

    public void clickStudentRadioButton() {
        SMUtils.waitForElement( driver, studentRadioButton );
        SMUtils.click( driver, studentRadioButton );
        Log.message( "Clicked student radio button!!!" );
    }

    public boolean isStudentRadioButtonClickable() {
        boolean flag = false;
        try {
            SMUtils.waitForElement( driver, studentRadioButton );
            SMUtils.click( driver, studentRadioButton );
            Log.message( "Clicked student radio button!!!" );
            flag = true;
        } catch ( Exception e ) {
            Log.message( "The Group Radio Button is not clickable" );
        }

        return flag;
    }

    public void handleStudentPopup() {
        SMUtils.waitForElement( driver, studentIDPopupparent );
        SMUtils.getWebElementDirect( driver, studentIDPopupparent, studnetIDPopup, button );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, studentIDPopupparent, studnetIDPopup, button ) );

    }

    public List<String> afggetAvailableOptionsFromSingleSelectDropdown( String dropdownName ) {
        expandSingleSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElementsDirect( driver, parentRoot, singleDropdownDropdownItem ).stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );

    }

    @FindBy ( css = "div.spinner-container" )
    WebElement Spinner;

    /**
     * Set the Organization Dropdown Value and return Org Id
     * 
     * @return
     */
    public String setOrganizationDropdown( String organizationName ) {
        try {
            WebElement ddOrganization = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( "#organization > div > cel-single-select" ) ), "#dropdown" );
            Select ddOrg = new Select( ddOrganization );
            ddOrg.selectByVisibleText( organizationName );
            waitForSpinnerToLoadAndDisppear();
            return ddOrg.getAllSelectedOptions().stream().filter( element -> element.getText().trim().equals( organizationName ) ).findFirst().orElse( null ).getAttribute( "value" );
        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * Set the Subject Name as Math or Reading
     * 
     * @return
     */
    public void selectSubject( String SubjectName ) {
        try {
            WebElement ddSubject = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( "#subject > div > cel-single-select" ) ), "#dropdown" );
            Select ddSub = new Select( ddSubject );
            SMUtils.scrollIntoView( driver, ddSubject );
            ddSub.selectByVisibleText( SubjectName );
            waitForSpinnerToLoadAndDisppear();
            Log.message( "Selected Subject: " + SubjectName );

        } catch ( Exception e ) {
            Log.message( "Issue in selecting Subject dropdown" );
        }
    }

    /**
     * Click Select All Options in PSR
     */
    public void setCoursesDropdownSelectAll() {
        try {
            WebElement ddCourseDropdown = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( "#courses > cel-multi-select" ) ), "div > div > button > cel-icon", "div" );
            SMUtils.click( driver, ddCourseDropdown );
            SMUtils.nap( 2 );
            WebElement selectAllOptions = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( "#courses > cel-multi-select" ) ), "#dropdown > cel-multi-checkbox",
                    "div > div.header-container.item-container.border-bottom > cel-checkbox-item", "label" );
            SMUtils.click( driver, selectAllOptions );
            SMUtils.click( driver, ddCourseDropdown );
            waitForSpinnerToLoadAndDisppear();
            Log.message( "Selected All Opton" );

        } catch ( Exception e ) {
            Log.message( "Issue in selecting Courses dropdown" );
        }
    }

    /**
     * Wait for the spinner to Load and Wait for disappear
     */
    public void waitForSpinnerToLoadAndDisppear() {
        SMUtils.waitForElement( driver, Spinner, 3 );
        new WebDriverWait( driver, Duration.ofSeconds( 180 ) ).until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner-container" ) ) );
    }

    /**
     * Expand the single-select org drop-down
     * 
     * @param dropdownName
     */
    public void expandSingleSelectOrgDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, orgDropdown ) );
            Log.message( "Expanded" + dropdownName + "drop-down" );
        }
    }

    /**
     * Collapse the single-select org drop-down
     * 
     * @param dropdownName
     */
    public void collapseSingleSelectOrgDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, orgDropdown ) );
            Log.message( "Collapsed" + dropdownName + "drop-down" );
        }
    }

    /**
     * To select options in org dropdown
     * 
     * @param dropdownName
     */
    public void selectOptionsFromSelectDropdown( String dropdownName, String option ) {
        expandSingleSelectOrgDropdown( dropdownName );
        SMUtils.nap( 4 );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement optionElement = SMUtils.getWebElement( driver, parentRoot, orgDropdownDropdownItem );
        Select select = new Select( optionElement );
        select.selectByVisibleText( option );
        Log.message( "Selected " + option );
    }

    /**
     * To get Dropdown Options
     * 
     * @param dropdownName
     */
    public List<String> getDropdownOptions( String dropdownName ) {
        expandSingleSelectOrgDropdown( dropdownName );
        SMUtils.nap( 4 );
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        WebElement optionElement = SMUtils.getWebElement( driver, parentRoot, orgDropdownDropdownItem );
        List<WebElement> options = optionElement.findElements( By.tagName( "option" ) );
        List<String> option = new ArrayList<>();
        options.stream().map( WebElement::getText ).forEach( option::add );
        return option;

    }

    /**
     * To get the place holder in Teacher multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromTeacherMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElementDirect( driver, parentRoot, multiOptionDropdown ).getText().trim();
    }

    /**
     * To verify the existing Filter option dropdown enabled or not
     * 
     */
    public boolean isExistingReportOptionDropdownEnabled() {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );

        return SMUtils.getWebElementDirect( driver, existingSavedOptionDropdown, dropdown ).isEnabled();

    }

    /**
     * To expand the existing Filter option dropdown
     * 
     */
    public void expandExistingReportOptionDropdown() {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );

        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, existingSavedOptionDropdown, dropdown ) );

        Log.message( "Expanded Existing report option dropdown." );
    }

    /**
     * To select option in the existing Filter option drop-down
     * 
     */
    public void selectOptionInExistingSavedOptiondropdown( String filterName ) {
        expandExistingReportOptionDropdown();
        SMUtils.nap( 4 );
        WebElement optionElement = SMUtils.getWebElement( driver, existingSavedOptionDropdown, dropdown );
        Select select = new Select( optionElement );
        select.selectByVisibleText( filterName );
        Log.message( "Selected " + filterName + "option in dropdown!" );
    }

    /**
     * To sort student name by lastname
     * 
     */
    public void sortStudentNameByLastName() {

        List<WebElement> studentElement = driver.findElements( By.cssSelector( studentNamesChild ) );
        List<String> studentNames = new ArrayList<String>();
        studentNames = studentElement.stream().map( element -> element.getText().toLowerCase().split( " " )[element.getText().split( " " ).length - 1] ).collect( Collectors.toList() );
        studentNames.forEach( s -> Log.message( "orginal value:" + s ) );
        boolean sorted = studentNames.stream().sorted().collect( Collectors.toList() ).equals( studentNames );
        Log.assertThat( sorted, "Student name is sorted by lastname", "Student name is not sorted by lastname" );
        List<String> sortedNames = new ArrayList<String>( studentNames );
        Collections.sort( sortedNames );
        sortedNames.forEach( s -> Log.message( "sorted value:" + s ) );

    }

    /**
     * To verify student lable
     * 
     */
    public String getStudentLabel() {
        SMUtils.waitForElement( driver, studentParentHeader );
        String textOfWebElement = SMUtils.getTextOfWebElement( studentParentHeader, driver );
        return textOfWebElement;
    }

    /**
     * To verify student lable
     * 
     */
    public String getStudentInformationLabel() {
        SMUtils.waitForElement( driver, studentInformationHeader );
        String textOfWebElement = SMUtils.getTextOfWebElement( studentInformationHeader, driver );
        return textOfWebElement;
    }

    /**
     * To sort student ID
     * 
     */
    public void sortStudentByStudentID() {
        List<WebElement> studentElement = driver.findElements( By.cssSelector( studentNamesChild ) );
        List<String> studentID = new ArrayList<String>();
        studentElement.forEach( element -> studentID.add( element.getText() ) );
        studentID.forEach( s -> Log.message( "orginal value:" + s ) );
        boolean sortedID = studentID.stream().sorted().collect( Collectors.toList() ).equals( studentID );
        Log.assertThat( sortedID, "Student ID is sorted ", "Student ID is not sorted " );
        List<String> sortedNames = new ArrayList<String>( studentID );
        Collections.sort( sortedNames );
        sortedNames.forEach( s -> Log.message( "sorted value:" + s ) );

    }

    /**
     * To sort student username
     * 
     */
    public void sortStudentByStudentUsername() {
        List<WebElement> studentElement = driver.findElements( By.cssSelector( studentNamesChild ) );
        List<String> studentUsernames = new ArrayList<String>();
        studentElement.forEach( element -> {
            Log.message( "orginal value :" + element.getText() );
            studentUsernames.add( element.getText() );
        } );
        boolean sortedUsername = studentUsernames.stream().sorted().collect( Collectors.toList() ).equals( studentUsernames );
        Log.assertThat( sortedUsername, "Student username is sorted ", "Student ID is not sorted " );
        List<String> sortedNames = new ArrayList<String>( studentUsernames );
        Collections.sort( sortedNames );
        sortedNames.forEach( s -> Log.message( "sorted value:" + s ) );

    }

    /**
     * To sort username-SEU
     * 
     */
    public void sortStudentByUsername() {
        List<WebElement> studentElement = driver.findElements( By.cssSelector( studentUsername ) );
        List<String> studentUsername = new ArrayList<String>();
        studentElement.forEach( element -> studentUsername.add( element.getText() ) );
        studentUsername.forEach( s -> Log.message( "orginal value:" + s ) );
        Log.message( "Student values:" + studentElement.size() );
        boolean sortedUsernames = studentUsername.stream().sorted().collect( Collectors.toList() ).equals( studentUsername );
        Log.assertThat( sortedUsernames, "Student ID is sorted ", "Student ID is not sorted " );
        List<String> sortedNames = new ArrayList<String>( studentUsername );
        Collections.sort( sortedNames );
        sortedNames.forEach( s -> Log.message( "sorted value:" + s ) );

    }

    /**
     * To sort StudentID-SEU
     * 
     */
    public void sortStudentByID() {
        List<WebElement> studentIDElement = driver.findElements( By.cssSelector( studentID ) );
        List<String> studentId = new ArrayList<String>();
        studentIDElement.forEach( element -> {
            if ( element.getText() != "NA" )
                studentId.add( element.getText() );
        } );
        studentId.forEach( s -> Log.message( "orginal value:" + s ) );
        Log.message( "Student values:" + studentIDElement.size() );
        boolean sortedId = studentId.stream().sorted().collect( Collectors.toList() ).equals( studentId );
        Log.assertThat( sortedId, "Student ID is sorted ", "Student ID is not sorted " );
        List<String> sortedNames = new ArrayList<String>( studentId );
        Collections.sort( sortedNames );
        sortedNames.forEach( s -> Log.message( "sorted value:" + s ) );

    }

    public String verifyZeroStateMessage() {
        SMUtils.waitForElement( driver, zeroStateMessage );
        String message = zeroStateMessage.getText().trim();
        return message;
    }

    public String verifyNoAssignmentsMessage( String dropdownName ) {
        WebElement assignmentDropdownRoot = getRootElementForAssignmentDropdown( dropdownName );
        SMUtils.waitForElement( driver, assignmentDropdownRoot );
        WebElement ele = SMUtils.getWebElement( driver, assignmentDropdownRoot, "button#multiselect-btn span" );
        String message = ele.getText().trim();
        return message;
    }

    /**
     * To get the root Element for multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForMultiSelectDropdownAdmin( String dropdownName ) {
        SMUtils.waitForElement( driver, singleSelectRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( multiSelectDropdownRoot ) );
    }

    /**
     * To get the selected options in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     * @throws InterruptedException
     */
    public List<String> getSelectedOptionsFromMultiSelectDropdownAdmin( String dropdownName ) throws InterruptedException {
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdownAdmin( dropdownName );
        Log.message( "Getting the Selected Options in " + dropdownName + " dropdown" );
        return SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().parallel().filter(
                element -> SMUtils.getWebElementDirect( driver, element, inputCheckboxAdmin ).isSelected() && !SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim().equalsIgnoreCase( ReportsUIConstants.ALL_OPTION ) ).map(
                        element -> SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get the place holder in multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public String getPlaceHolderFromMultiSelectDropdownAdmin( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement parentRoot = getRootElementForMultiSelectDropdownAdmin( dropdownName );
        return SMUtils.getWebElementDirect( driver, parentRoot, dropdownplaceHolder ).getText().trim();
    }

    /**
     * To Click Close button
     */
    public void clickCloseButtonForStudenIDPopup() {
        SMUtils.waitForElement( driver, closeBtnGrandRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, closeBtnGrandRoot, closeBtnRoot, button ) );
        Log.message( "Clicked close button in Student ID popup!" );
    }

}
