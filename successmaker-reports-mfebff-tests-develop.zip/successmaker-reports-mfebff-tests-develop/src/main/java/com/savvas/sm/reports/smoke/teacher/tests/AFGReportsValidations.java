package com.savvas.sm.reports.smoke.teacher.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

public class AFGReportsValidations extends EnvProperties {

    private String smUrl;
    private String browser;
    String teacherDetails;
    private String schoolName = null;
    private static String teacherUsername = null;
    private static String passwordTeacher = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherId;

    @BeforeClass( alwaysRun = true )
    public void init( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        
        HashMap<String, String> courseIds = new HashMap<>();
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        String studentDetail = RBSDataSetup.getMyStudent( schoolName, teacherUsername );
        
        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolName ) );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID,  SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ));
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, new ArrayList<>( Arrays.asList(SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) ) ), new ArrayList<>( courseIds.values() ) );
        Log.message( assignmentResponse.toString() );
        
    }

    @Test ( description = "Areas For Growth Report All Fields Validations", groups = { "smoke_test_case", "reports", "areas_for_growth" }, priority = 1 )
    public void tc001AreasForGrowthReportFieldValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Areas For Growth Report Field Validations" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            areasForGrowthReport.validateAllFieldsInAFGReport( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validation AFG Teacher - 'Saved Report' Value Is Retaining", groups = { "smoke_test_case", "areas_for_growth", "p1" }, priority = 1 )
    public void tc002AFGSavedReportsValidation() throws Exception { 
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation Of AFG Saved Reports Retains " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            areasForGrowthReport.validateSavedReports( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "AFG run Report Validation", groups = { "smoke_test_case", "areas_for_growth", "p3" }, priority = 3 )
    public void tc003AFGRunReportValidationForTeacher() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "AFG run Report Validation" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            ReportsViewerPage reportsViewerPage = areasForGrowthReport.validateAFGTeacherRunReport( driver );
            reportsViewerPage.verifyReportPage( driver );
            reportsViewerPage.validateReportOutputColumns( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validation AFG Teacher- All Values are fetched 'Math'", groups = { "smoke_test_case", "areas_for_growth", "p4" }, priority = 4 )
    public void tc004AFGReportsValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation Of AFG Reports Dynamic field validation " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            areasForGrowthReport.verifyGroup( driver );
            areasForGrowthReport.verifyAssignments( driver, teacherUsername, smUrl, teacherDetails, "mathassignments" );
            areasForGrowthReport.verifyStudents( driver, schoolName, teacherUsername );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validation AFG Teacher- All Values are fetched 'Reading'", groups = { "smoke_test_case", "areas_for_growth", "p5" }, priority = 5 )
    public void tc005AFGReportsValidation() throws Exception { 
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation Of AFG Reports Dynamic field validation " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            areasForGrowthReport.verifyGroup( driver );
            areasForGrowthReport.chooseSubject( driver, "Reading" );
            areasForGrowthReport.verifyAssignments( driver, teacherUsername, smUrl, teacherDetails, "readingassignments" );
            areasForGrowthReport.verifyStudents( driver, schoolName, teacherUsername );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
