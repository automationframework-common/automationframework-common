package com.savvas.sm.reports.ui.tests.teacher.psr;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PrescriptiveSchedulingReportTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String teacherDetails;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeClass( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    

    @Test ( description = "Verify Prescriptive Scheduling  Report without filter Test", groups = { "Smoke", "SMK-57297", "Prescriptive Scheduling  Report", "PSR" }, priority = 1 )
    public void tcSMPrescriptiveSchedulingTest001() throws Exception {
        Log.message( "Login in with Teacher: " + username );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = smLoginPage.loginToSMPSReport( username, password );
            prescriptiveSchedulingPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeader(), "Prescriptive Scheduling  Report page displayed", "Prescriptive Scheduling  Report page not displayed" );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton(), "Prescriptive Scheduling Run Report button displayed", "Prescriptive Scheduling Run Report button not displayed" );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeaderAfterRun(), "Prescriptive Scheduling Report data displayed", "Prescriptive Scheduling Report data not displayed" );
            Log.assertThat( prescriptiveSchedulingPage.clickNextButton(), "Prescriptive Scheduling Report navigate to next page displayed", "Prescriptive Scheduling Report navigate to next page not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Prescriptive Scheduling  Report with filter Test", groups = { "Smoke", "SMK-57297", "Prescriptive Scheduling  Report", "PSR" }, priority = 1 )
    public void tcSMPrescriptiveSchedulingTest002() throws Exception {
        Log.message( "Login in with Teacher: " + username );

        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = smLoginPage.loginToSMPSReport( username, password );
            prescriptiveSchedulingPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeader(), "Prescriptive Scheduling  Report page displayed", "Prescriptive Scheduling  Report page not displayed" );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            //prescriptiveSchedulingPage.fillGrade( "5" );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton(), "Prescriptive Scheduling Run Report button displayed", "Prescriptive Scheduling Run Report button not displayed" );
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeaderAfterRun(), "Prescriptive Scheduling Report data displayed", "Prescriptive Scheduling Report data not displayed" );
            Log.assertThat( prescriptiveSchedulingPage.clickNextButton(), "Prescriptive Scheduling Report navigate to next page displayed", "Prescriptive Scheduling Report navigate to next page not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
