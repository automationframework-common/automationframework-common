package com.savvas.sm.reports.bff.admin.tests;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.LSAdminReportDBQuery;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicValues;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;

import io.restassured.response.Response;

public class LSRReportAdminGraphQLTest extends EnvProperties {

    CourseAPI coursesMethod = new CourseAPI();
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String studentId;
    String studentId1;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String firstTeacherOrgID;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        RBSUtils rbsUtils = new RBSUtils();

        // Teacher UserNames
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        firstTeacherOrgID = ReportData.orgId;

        //Teacher User ID's
        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );

        //Group ID's
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 1 ).toString(), "groupId" );

        //Assignment ID's
        studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );
        studentAssignmentIdReading = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        //Filter By Values - OrgId
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        //School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );

        //Student ID's
        studentId = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[0].toString();
        studentId1 = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[1].toString();

    }

    @DataProvider ( name = "PositiveScenarios" )
    public Object[][] testScenario() {

        Object[][] inputData = { { "tc_LSR_BFF_001", "Verify the 200 status code and valid reponse for the district admin credential", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },
                { "tc_LSR_BFF_002", "Verify the 200 status code and valid reponse for the subdistrict admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT_ADMIN" },
                { "tc_LSR_BFF_003", "Verify the 200 status code and valid reponse for the school admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },
                { "tc_LSR_BFF_004", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with single Teacher, Grade and Group", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_VALUE" },
                { "tc_LSR_BFF_005", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with multiple Teachers, Grades and Groups", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_VALUE" },
                { "tc_LSR_BFF_006", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Teacher", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_TEACHER" },
                { "tc_LSR_BFF_007", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Grade", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GRADE" },
                { "tc_LSR_BFF_008", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Group", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GROUP" },
                { "tc_LSR_BFF_009", "Verify the 200 Status code and the output response when passing single values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE" },
                { "tc_LSR_BFF_010", "Verify the 200 Status code and the output response when passing multiple values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE" }, };
        return inputData;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public Map<String, String> getDataFromResponse( String responseBody ) {

        // Getting data from response
        JSONObject jsonObj = new JSONObject( getKeyValueFromResponseWithArray( responseBody, "data" ) );
        String response = jsonObj.getJSONArray( "getLSAdminReportData" ).getJSONObject( 0 ).toString();

        Map<String, String> lsDetails = new HashMap<>();
        lsDetails.put( "exercisesCorrect", SMUtils.getKeyValueFromResponse( response, "rawPerformance,exercisesCorrect" ) );
        lsDetails.put( "exercisesAttempted", SMUtils.getKeyValueFromResponse( response, "rawPerformance,exercisesAttempted" ) );
        lsDetails.put( "helpUsed", SMUtils.getKeyValueFromResponse( response, "usage,helpUsed" ) );
        lsDetails.put( "totalSessionCount", SMUtils.getKeyValueFromResponse( response, "usage,totalSessions" ) );
        return lsDetails;

    }

    /**
     * To validate response data with DB
     * 
     * @param responseBody
     * @param stdId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public boolean validateResponseDataWithDB( String responseBody, String stdId, String mathAssignmentUserId, String readingAssignmentUserId ) {
        Boolean validation = false;
        if ( responseBody.contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
            Log.message( ReportAPIConstants.NO_DATA_FOUND_MESSAGE );
            validation = true;
        } else {
            // Get data from response
            Map<String, String> dataFromResponse = getDataFromResponse( responseBody );
            Log.message( "Response Body to validate : " + dataFromResponse );
            // Get data from DB
            Map<String, Map<String, String>> lsRdataFromDB = LSRdataFromDB( mathAssignmentUserId );
            Log.message( "DB Response to validate : " + lsRdataFromDB );

            validation = lsRdataFromDB.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), dataFromResponse ) );

        }
        return validation;
    }

    public Map<String, Map<String, String>> LSRdataFromDB( String mathAssignmentIds ) {
        Map<String, Map<String, String>> valuesFromDB = new HashMap<>();
        String query = "Select assignment_user_id,\r\n" + "        current_course_level,\r\n" + "        session_correct as exerciseCorrect,\r\n" + "        session_attempts as exerciseAttempted,\r\n" + "        session_help_count as helpused,\r\n"
                + "        (session_complete_time - session_start_time) as time_spent,\r\n" + "        (Select count(*) from math_session_history where assignment_user_id = rsh.assignment_user_id) as total_session_count\r\n"
                + "            From math_session_history rsh\r\n" + "                where\r\n" + "                    rsh.assignment_user_id in (select assignment_user_id from assignment_user where assignment_id in(" + mathAssignmentIds + ") )\r\n"
                + "                    AND session_start_time =\r\n" + "                                (SELECT MAX(session_start_time) FROM math_session_history last_session\r\n"
                + "                                            WHERE last_session.assignment_user_id = rsh.assignment_user_id)";

        List<Object[]> rowList = SQLUtil.executeQuery( query );
        rowList.forEach( object -> {
            String string = object[0].toString();
            Log.message( "User Id Fetched From DB Query : " + string );
            Map<String, String> values = new HashMap<>();
            values.put( "exercisesCorrect", object[2].toString() );
            values.put( "exercisesAttempted", object[3].toString() );
            char charAt = object[4].toString().charAt( 0 );
            values.put( "helpUsed", String.valueOf( charAt ) );
            values.put( "totalSessionCount", object[6].toString() );
            valuesFromDB.put( object[0].toString(), values );
        } );

        return valuesFromDB;
    }

    /**
     * This method is used to get values from DB
     * 
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromDB( String studentRumbaId, String mathAssignmentUserId, String readingAssignmentUserId ) {

        // Executing queries to get SEU reoirt data from DB
        List<Object[]> mathTimeSpentQuery = SQLUtil.executeQuery( "select total_session_min as Time_Spent from math_assignment_history where assignment_user_id in (" + mathAssignmentUserId + ")" );
        List<Object[]> mathCustomTimeSpentQuery = SQLUtil.executeQuery(
                "select sum(total_session_min) as Time_Spent from math_assignment_history where assignment_user_id in  ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> mathTotalSessionQuery = SQLUtil.executeQuery(
                "select sum(session_presented_count) as Total_Sessions from math_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> readTimeSpentQuery = SQLUtil.executeQuery( "select total_session_min as Time_Spent from read_assignment_history where assignment_user_id in (" + readingAssignmentUserId + ")" );
        List<Object[]> readCustomTimeSpentQuery = SQLUtil.executeQuery(
                "select sum(total_session_min) as Time_Spent from read_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> readTotalSessionQuery = SQLUtil.executeQuery(
                "select sum(session_presented_count) as Total_Sessions from read_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );

        HashMap<String, HashMap<String, String>> dataFromDB = new HashMap<>();
        HashMap<String, String> data = new HashMap<>();
        // Get Tiem Spent and Total Session
        int mathCustomTime = Integer.parseInt( mathCustomTimeSpentQuery.stream().findFirst().get()[0].toString() ) - Integer.parseInt( mathTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int readCustomTime = Integer.parseInt( readCustomTimeSpentQuery.stream().findFirst().get()[0].toString() ) - Integer.parseInt( readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int totalTime = mathCustomTime + readCustomTime + Integer.parseInt( mathTimeSpentQuery.stream().findFirst().get()[0].toString() ) + Integer.parseInt( readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int totalSession = Integer.parseInt( mathTotalSessionQuery.stream().findFirst().get()[0].toString() ) + Integer.parseInt( readTotalSessionQuery.stream().findFirst().get()[0].toString() );

        data.put( "sumDefaultMathTime", mathTimeSpentQuery.stream().findFirst().get()[0].toString() );
        data.put( "sumDefaultReadingTime", readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        data.put( "sumCustomTotalTime", String.valueOf( mathCustomTime + readCustomTime ) );
        data.put( "sumTotalTime", String.valueOf( totalTime ) );
        data.put( "sumTotalSessions", String.valueOf( totalSession ) );
        data.put( "avgTotalTimePerSession", String.valueOf( new DecimalFormat( "#" ).format( (Double) ( totalTime / 10.0 ) / ( totalSession / 10.0 ) ) ) );

        dataFromDB.put( studentRumbaId, data );
        Log.message( "DB Data: " + dataFromDB );
        return dataFromDB;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {

            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();
                //return keyValue;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }

    /**
     * This method used to fetch report data from SEU grapphql
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues - pass the optional filter values in HashMap
     * @return
     * @throws Exception
     */
    public static Response getLSReport( String username, String password, String userId, String userOrgId, String schoolId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generted Dynamic Bearer Token : " + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generted Dynamic Org Id : " + userOrgId );
        Log.message( "Generted Dynamic User Id : " + userId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload   
        String LSPayload = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getLSAdminReportData(\\n    filterParams: {subject: \\\"%s\\\", courseList: [{courseList}], additionalGrouping: {additionalGroupId}, filterBySchool: [\\\"%s\\\"], filterByTeacher: [{teacherId}], filterByGroup: [{groupId}], filterByGrade: [{grade}], filterByDemographics: {disabilityStatus: [{disabilityStatus}], englishLanguageProficiency: [{language}], gender: [{gender}], migrantStatus: [{migrantStatus}], race: [{race}], ethnicity: [{ethnicity}], socioeconomicStatus: [{socioStatus}], specialServices: [{specialServices}]}}\\n    userId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n  ) {\\n    organizationName\\n    grade\\n    assignmentTitle\\n    groupName\\n    teacherID\\n    teacherName\\n    studentName\\n    studentFirstName\\n    studentMiddleName\\n    studentLastName\\n    currentCourseLevel\\n    rawPerformance {\\n      exercisesCorrect\\n      exercisesAttempted\\n      exercisesPercentCorrect\\n    }\\n    usage {\\n      helpUsed\\n      timeSpent\\n      totalSessions\\n      sessionDate\\n    }\\n    exercisesCorrectedAttempted {\\n      instructionalCorrect\\n      instructionalAttempted\\n      independentPracticeCorrect\\n      independentPracticeAttempted\\n      remediationCorrect\\n      remediationAttempted\\n    }\\n  }\\n}\\n\"}";
        String payLoad = String.format( LSPayload, subject, schoolId, userId, userOrgId );
        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().equals( ReportFilters.ADDITIONAL_GROUP_ID_VALUE ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in
            }
        }

        payLoad = payLoad.replace( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "0" ).replace( ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( ReportFilters.GROUP_ID_VALUE, "" ).replace( ReportFilters.ASSIGNMENT_ID,
                "" ).replace( DemographicFilters.DISABILITY_STATUS, "" ).replace( DemographicFilters.ENGLISH_PROFICIENCY, "" ).replace( DemographicFilters.GENDER, "" ).replace( DemographicFilters.MIGRANT_STATUS, "" ).replace( DemographicFilters.RACE,
                        "" ).replace( DemographicFilters.ETHNICITY, "" ).replace( DemographicFilters.SOCIO_STATUS, "" ).replace( DemographicFilters.SPECIAL_SERVICES, "" ).replace( "{courseList}", "" );
        Log.message( "Headers :" + headers );
        Log.message( "Payload : " + payLoad );

        // Getting LSR repport response
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin LS Report Graphql", "SMK-58038", "P1" } )
    public void getAdminLSReport_Positive( String tcId, String description, String statusCode, String scenario ) throws Exception {

        String[] courseList;
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getLSAdminReportData" ) ).get( 0 ).toString(), "assignmentTitle" );
                Log.message( "Subject Name From The Response For District Admin : " + subjectName );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Passed : Subject is displayed as Math For District Admin", "Subject is not displayed as Math" );
                break;

            case "SUB_DISTRICT_ADMIN":

                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );

                response = getLSReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getLSAdminReportData" ) ).get( 0 ).toString(), "assignmentTitle" );
                Log.message( "Subject Fetched From Response For Sub District Admin : " + subjectName );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Passed : Subject is displayed as Math For Sub District Admin", "Subject is not displayed as Math" );
                break;

            case "SCHOOL_ADMIN":

                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );
                response = getLSReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getLSAdminReportData" ) ).get( 0 ).toString(), "assignmentTitle" );
                Log.message( "Subject Name From The Response For School Admin : " + subjectName );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Passed : Subject is displayed as Math For School Admin", "Subject is not displayed as Math" );
                break;

            case "FILTER_BY_SINGLE_VALUE":

                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );
                // Filter by single Teacher, Grade and Group
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02" ); // Only 02 Grade is working here

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, filterByValues.get( "{courseList}" ), studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_VALUE":
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );
                // Filter by single Teacher, Grade and Group
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02,01" );

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, filterByValues.get( "{courseList}" ), studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_TEACHER":
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                // Additional Grouping by Teacher
                filterByValues.put( "{courseList}", courseList[0].toString() );
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, filterByValues.get( "{courseList}" ), studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_GRADE":
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );
                // Additional Grouping by Grade
                filterByValues.put( "{courseList}", courseList[0].toString() );
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, filterByValues.get( "{courseList}" ), studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_GROUP":
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );
                // Additional Grouping by Group
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );
                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, filterByValues.get( "{courseList}" ), studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );
                // Filter by single Teacher, Grade and Group
                filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":
                courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                filterByValues.put( "{courseList}", courseList[0].toString() );
                // Filter by single Teacher, Grade and Group
                filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;
        }

        Log.testCaseResult();

    }

    @Test ( priority = 2, dataProvider = "NegativeScenarios", groups = { "Admin LS Report Graphql", "SMK-58038", "P2" } )
    public void getAdminLSReport_Negative( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        String[] courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

        for ( String courses : courseList ) {
            Log.message( "Course : " + courses );
        }

        switch ( scenario ) {

            case "INVALID_ACCESS_TOKEN":

                response = getLSReport( distAdminUserName + "INVALID", password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_ORG_ID":

                response = getLSReport( distAdminUserName, password, distAdminuserId, distId + "INVALID", selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_USER_ID":

                response = getLSReport( distAdminUserName, password, distAdminuserId + "INVALID", distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "EMPTY_ORG_ID":

                response = getLSReport( distAdminUserName, password, distAdminuserId, "", selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_SUBJECT_TYPE":

                response = getLSReport( distAdminUserName, password, "", distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;
        }

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        } else {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "NegativeScenarios" )
    public Object[][] testNegativeScenario() {

        Object[][] inputData = { { "tc_LSR_BFF_012", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSR_BFF_013", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSR_BFF_014", "Verify  401: UnAuthorized  and response when invalid userId is given in the query ", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSR_BFF_015", "Verify the message in the response when organizationId passed as empty array. ", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_LSR_BFF_016", "Verify the message in the response when invalid subject type passed in the query.", "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin LS Report Graphql", "SMK-58038", "P1", "smoke_test_case" } )
    public void getAdminLSReport_SchemaValidation( String tcId, String description, String statusCode, String scenario ) throws Exception {

        String[] courseList;
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();
        try {
            switch ( scenario ) {

                case "DISTRICT_ADMIN":

                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SUB_DISTRICT_ADMIN":

                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );

                    response = getLSReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SCHOOL_ADMIN":

                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );

                    response = getLSReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_VALUE":

                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_VALUE":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02,01" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_TEACHER":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    // Additional Grouping by Teacher
                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GRADE":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );
                    // Additional Grouping by Grade
                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GROUP":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    // Additional Grouping by Group
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," );

                    filterByValues.put( "{courseList}", courseList[0].toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;
            }
        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( response, "LSR" );
        }

        Log.testCaseResult();

    }

    @Test ( priority = 1, dataProvider = "PositiveScenariosDB", groups = { "Admin LS Report Graphql", "SMK-58038", "P1" } )
    public void getAdminLSReport_DBValidation( String tcId, String description, String statusCode, String scenario ) throws Exception {

        String courseList = null;
        String courseListForDB = null;
        boolean isMath = false;
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();
        try {
            switch ( scenario ) {

                case "DISTRICT_ADMIN":

                    Log.testCaseInfo(
                            "Verify the 200 Status code and  the output response , while pass the any one organization Id with  empty array for TeacherId, empty array for  GroupId, empty array for  Grade, Math subject and multiple assignmentIds " );
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filterByValues.put( "{courseList}", courseList.toString() );
                    Log.message( "CourseList: " + courseList );

                    StringTokenizer courseListDB = new StringTokenizer( courseList, " " );
                    if ( courseListDB.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found for parsing in DB!" );
                    }

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SUB_DISTRICT_ADMIN":

                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filterByValues.put( "{courseList}", courseList.toString() );

                    StringTokenizer courseListDB1 = new StringTokenizer( courseList );
                    if ( courseListDB1.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    response = getLSReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SCHOOL_ADMIN":

                    Log.testCaseInfo(
                            "Verify the 200 Status code and  the output response , while pass the any one organization Id with  empty array for TeacherId, empty array for  GroupId, empty array for  Grade, Math subject and any one assignmentId " );
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB2 = new StringTokenizer( courseList );
                    if ( courseListDB2.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseListForDB );

                    response = getLSReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_VALUE":

                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB3 = new StringTokenizer( courseList );
                    if ( courseListDB3.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_WITH_EMPTY_TEACHER":

                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListEmptyTeacher = new StringTokenizer( courseList );
                    if ( courseListEmptyTeacher.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_WITH_EMPTY_GRADE":

                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDBEmptyGrade = new StringTokenizer( courseList );
                    if ( courseListDBEmptyGrade.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_WITH_EMPTY_GROUPID":

                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDBEmptyGrp = new StringTokenizer( courseList );
                    if ( courseListDBEmptyGrp.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    // Filter by single Teacher, Grade and Empty Group ID
                    filterByValues.put( "{courseList}", courseList.toString() );
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_VALUE":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB4 = new StringTokenizer( courseList );
                    if ( courseListDB4.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02,01" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_TEACHER":
                    isMath = false;
                    courseList = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB5 = new StringTokenizer( courseList );
                    if ( courseListDB5.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    // Additional Grouping by Teacher
                    filterByValues.put( "{courseList}", courseList.toString() );
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GRADE":
                    isMath = false;
                    courseList = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB6 = new StringTokenizer( courseList );
                    if ( courseListDB6.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    // Additional Grouping by Grade
                    filterByValues.put( "{courseList}", courseList.toString() );
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GROUP":
                    isMath = false;
                    courseList = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB7 = new StringTokenizer( courseList );
                    if ( courseListDB7.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Additional Grouping by Group
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB8 = new StringTokenizer( courseList );
                    if ( courseListDB8.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":
                    Log.testCaseInfo( "Verify the 200 Status code and  the output response , while pass the required filters with special services  as \"Gifted/Talented\",\"IEP\",\"Other\",\"NO_Special_services\" & \"Not_Specified\" (multiple options)" );
                    Log.testCaseInfo( "Verify the 200 Status code and  the output response , while pass the required filters with socioeconomic status  as 'Not Economically Disadvantaged' & Not specified (multiple options)" );
                    Log.testCaseInfo( "Verify the 200 Status code and  the output response , while pass the required filters with migrant status  as 'Non Migrant' & not specified (multiple options)" );
                    Log.testCaseInfo( "Verify the 200 Status code and  the output response , while pass the required filters with gender as 'male'  &  'Not specified' (multiple option)" );
                    Log.testCaseInfo( "Verify the 200 Status code and  the output response , while pass the required filters with english Language Proficiency as 'English language learner' and  'Not specified' (multiple options)" );
                    Log.testCaseInfo( "Verify the 200 Status code and  the output response , while pass the required filters with disability status as 'No' and  'Not Specified' (multiple options)" );

                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB9 = new StringTokenizer( courseList );
                    if ( courseListDB9.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( "{courseList}", courseList.toString() );
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );
                    Log.message( "Demogrpahics Values: " + filterByValues );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DISABILITY_VALUE":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDB10 = new StringTokenizer( courseList );
                    if ( courseListDB10.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }
                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.get( 0 ) );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DISABILITY_NO":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDBDisabilityNo = new StringTokenizer( courseList );
                    if ( courseListDBDisabilityNo.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }
                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.get( 1 ) );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_ENGLISH_PROFICIENCY_ENGLISH":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDBEnglish = new StringTokenizer( courseList );
                    if ( courseListDBEnglish.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }
                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.get( 0 ) );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MIGRANT_STATUS_MIGRANT":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDBMigrant = new StringTokenizer( courseList );
                    if ( courseListDBMigrant.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }
                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.get( 0 ) );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_ECONOMIC_DISADVANTAGED":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListDBGender = new StringTokenizer( courseList );
                    if ( courseListDBGender.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }
                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.get( 0 ) );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SPECIAL_SERVICES_504":
                    isMath = true;
                    courseList = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );

                    StringTokenizer courseListSpecial = new StringTokenizer( courseList );
                    if ( courseListSpecial.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found!" );
                    }
                    filterByValues.put( "{courseList}", courseList.toString() );
                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.get( 0 ) );

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "MATH_CUSTOM_BY_SETTINGS":
                    isMath = true;
                    courseList = ReportData.mathSettingIPMOFFAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filterByValues.put( "{courseList}", courseList.toString() );
                    Log.message( "CourseList: " + courseList );

                    StringTokenizer courseListDBSettings = new StringTokenizer( courseList, " " );
                    if ( courseListDBSettings.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found for parsing in DB!" );
                    }

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "MATH_CUSTOM_BY_SKILLS":
                    isMath = true;
                    courseList = ReportData.mathSkillAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filterByValues.put( "{courseList}", courseList.toString() );
                    Log.message( "CourseList: " + courseList );

                    StringTokenizer courseListDBSkills = new StringTokenizer( courseList, " " );
                    if ( courseListDBSkills.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found for parsing in DB!" );
                    }

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "MATH_CUSTOM_BY_STANDARDS":
                    isMath = true;
                    courseList = ReportData.mathStandardAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filterByValues.put( "{courseList}", courseList.toString() );
                    Log.message( "CourseList: " + courseList );

                    StringTokenizer courseListDBStandards = new StringTokenizer( courseList, " " );
                    if ( courseListDBStandards.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found for parsing in DB!" );
                    }

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FOCUS_MATH":
                    isMath = true;
                    courseList = ReportData.mathFocusAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filterByValues.put( "{courseList}", courseList.toString() );
                    Log.message( "CourseList: " + courseList );

                    StringTokenizer courseListDBFocus = new StringTokenizer( courseList, " " );
                    if ( courseListDBFocus.hasMoreTokens() ) {
                        courseListForDB = courseList.split( "," )[0];
                        Log.message( "courseListForDB: " + courseListForDB );
                    } else {
                        Log.message( "No assignment ID's found for parsing in DB!" );
                    }

                    response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getLSReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "LSR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

            }

            if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                //Validating the response data by comparing data from  DB and Response

                // Get data from response
                Map<String, Map<String, String>> dataFromResponse = getLSDataFromResponse( response.getBody().asString() );
                Log.message( "LSR Data From Response-Math: " + dataFromResponse );

                //Get Data From DB
                Map<String, Map<String, String>> dataFromDB = getLSDataFromDB( courseListForDB, isMath );
                Log.message( "LSR Data From DB-Math: " + dataFromDB );

                validateResponseDataWithDBData( response.getBody().asString(), courseListForDB, isMath );
            }

        } catch ( ValidationException e ) {}

        Log.testCaseResult();
    }

    @DataProvider ( name = "PositiveScenariosDB" )
    public Object[][] testScenarioDB() {

        Object[][] inputData = { { "tc_LSR_BFF_DB_001", "Verify the 200 status code and valid reponse for the district admin credential", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },
                { "tc_LSR_BFF_DB_002", "Verify the 200 status code and valid reponse for the subdistrict admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT_ADMIN" },
                { "tc_LSR_BFF_DB_003", "Verify the 200 status code and valid reponse for the school admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },
                { "tc_LSR_BFF_DB_004", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  any one TeacherId, any one GroupId, any one Grade, Math subject and any one assignmentId ",
                        CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_VALUE" },
                { "tc_LSR_BFF_DB_005", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with multiple Teachers, Grades and Groups", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_VALUE" },
                { "tc_LSR_BFF_DB_006", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  additional grouping  as  1 (Teacher), Reading subject and any one reading assignmentId .",
                        CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_TEACHER" },
                { "tc_LSR_BFF_DB_007", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  additional grouping  as  2 (Grade), Reading subject and any one reading assignmentId .",
                        CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GRADE" },
                { "tc_LSR_BFF_DB_008", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  additional grouping  as  3 (Group) , Reading subject and any one reading assignmentId .",
                        CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GROUP" },
                { "tc_LSR_BFF_DB_009", "Verify the 200 Status code and the output response when passing single values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE" },
                { "tc_LSR_BFF_DB_010", "Verify the 200 Status code and the output response when passing multiple values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE" },
                { "tc_LSR_BFF_DB_011", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  any one TeacherId, Empty array for GroupId , any one Grade, Math subject and any one assignmentId ",
                        CommonAPIConstants.STATUS_CODE_OK, "FILTER_WITH_EMPTY_GROUPID" },
                { "tc_LSR_BFF_DB_012", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  any one TeacherId, any one GroupId , empty array for Grade, Math subject and any one assignmentId ",
                        CommonAPIConstants.STATUS_CODE_OK, "FILTER_WITH_EMPTY_GRADE" },
                { "tc_LSR_BFF_DB_013", "Verify the 200 Status code and  the output response , while pass the any one organization Id with  empty array for TeacherId, any one GroupId, any one Grade, Math subject and any one assignmentId ",
                        CommonAPIConstants.STATUS_CODE_OK, "FILTER_WITH_EMPTY_TEACHER" },
                { "tc_LSR_BFF_DB_014", "Verify the 200 Status code and  the output response , while pass the required filters with disability status as 'yes' (single option)", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DISABILITY_VALUE" },
                { "tc_LSR_BFF_DB_015", "Verify the 200 Status code and  the output response , while pass the required filters with disability status as 'No' (single option)", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DISABILITY_NO" },
                { "tc_LSR_BFF_DB_016", "Verify the 200 Status code and  the output response , while pass the required filters with english Language Proficiency as 'English' (single option)", CommonAPIConstants.STATUS_CODE_OK,
                        "FILTER_BY_ENGLISH_PROFICIENCY_ENGLISH" },
                { "tc_LSR_BFF_DB_017", "Verify the 200 Status code and  the output response , while pass the required filters with migrant status  as 'migrant' (single option)", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MIGRANT_STATUS_MIGRANT" },
                { "tc_LSR_BFF_DB_018", "Verify the 200 Status code and  the output response , while pass the required filters with socioeconomic status  as 'Economically Disadvantaged' (single option)", CommonAPIConstants.STATUS_CODE_OK,
                        "FILTER_BY_ECONOMIC_DISADVANTAGED" },
                { "tc_LSR_BFF_DB_019", "Verify the 200 Status code and  the output response , while pass the required filters with special services  as ''504 plan\" (single option)", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SPECIAL_SERVICES_504" },
                { "tc_LSR_BFF_DB_020", "Verify the 200 Status code and  the output response , while pass the Custom by Settings assignment Ids in the query", CommonAPIConstants.STATUS_CODE_OK, "MATH_CUSTOM_BY_SETTINGS" },
                { "tc_LSR_BFF_DB_021", "Verify the 200 Status code and  the output response , while pass the Custom by skills assignment Ids  in the query", CommonAPIConstants.STATUS_CODE_OK, "MATH_CUSTOM_BY_SKILLS" },
                { "tc_LSR_BFF_DB_022", "Verify the 200 Status code and  the output response , while pass the Custom by standard assignment Ids  in the query", CommonAPIConstants.STATUS_CODE_OK, "MATH_CUSTOM_BY_STANDARDS" },
                { "tc_LSR_BFF_DB_023", "Verify the 200 Status code and  the output response , while pass the Focus course assignment Ids  in the query", CommonAPIConstants.STATUS_CODE_OK, "FOCUS_MATH" }, };

        return inputData;
    }

    @Test ( priority = 1, dataProvider = "studentSpecific", groups = { "Admin LS Report Graphql", "SMK-58038", "P2" } )
    public void getLSReportStudentSpecific( String tcId, String description, String statusCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );

        HashMap<String, String> filterByValues = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> contentBase = new HashMap<>();
        HashMap<String, String> contentBaseName = new HashMap<>();
        List<String> courseIDs = new ArrayList<>();
        HashMap<String, String> groupDetails = new HashMap<>();

        String groupName = "SM Test Group";
        String studentUserName = "sm_student_user" + System.nanoTime();

        //Creating Math Assignment
        contentBaseName.put( Constants.MATH, Constants.MATH );
        contentBase.put( Constants.MATH, ReportAPIConstants.COURSE_ID );
        courseIDs.add( contentBase.get( Constants.MATH ) );

        //Creating a student user using user service
        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, studentUserName );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, firstTeacherOrgID );
        String studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
        studentRumbaIds.add( studentID );

        //Updating Student Details
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = generateRequestValues( new RBSUtils().getUser( studentID ), studentInfo, UserConstants.SCHOOLID, firstTeacherOrgID );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, firstTeacherOrgID );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, firstTeacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( firstTeacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( firstTeacherOrgID, RBSDataSetupConstants.DEFAULT_PASSWORD, studentID );

        assignmentDetails.put( LSAdminReportDBQuery.ORG_ID, firstTeacherOrgID );
        assignmentDetails.put( LSAdminReportDBQuery.TEACHER_ID, firstTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( firstTeacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        //Assigning Assignment to the newly created student
        Log.message( "Assigning assignment..." );
        String assignmentResponseDetails = SMUtils.getKeyValueFromResponse( new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs ).get( Constants.REPORT_BODY ), "data,assignmentId" );
        Log.message( "assignmentAssignedresponseDetails: " + assignmentResponseDetails );

        //Creating a group with the above student
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( firstTeacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( LSAdminReportDBQuery.GROUP_OWNER_ID, firstTeacherId );
        groupDetails.put( LSAdminReportDBQuery.GROUP_OWNER_ORG_ID, firstTeacherOrgID );
        groupDetails.put( LSAdminReportDBQuery.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

        switch ( scenario ) {
            case "ASSIGNMENT_NOT_STARTED_STUDENT":

                Log.message( "CourseList: " + assignmentResponseDetails );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, groupId );
                response = getLSReport( distAdminUserName, password, distAdminuserId, distId, firstTeacherOrgID, Constants.MATH, filterByValues );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = getLSReport( distAdminUserName, password, distAdminuserId, distId, firstTeacherOrgID, Constants.MATH, filterByValues );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                            break;
                        }
                        Thread.sleep( 5000 );
                    }
                }
                // Verifying Status Code
                Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                        "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;
        }
    }

    @DataProvider ( name = "studentSpecific" )
    public Object[][] studentSpecific() {

        Object[][] inputData = { { "tc_LSR_BFF_DB_024", "Verify the 200 Status code and zero state response, if the students are not started the selected assignments", CommonAPIConstants.STATUS_CODE_OK, "ASSIGNMENT_NOT_STARTED_STUDENT" }, };
        return inputData;
    }

    /**
     * To validate response data with DB
     * 
     * @param responseBody
     * @param stdId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public boolean validateResponseDataWithDBData( String responseBody, String assignmentId, boolean isMath ) {
        Boolean validation = false;
        if ( responseBody.contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
            Log.message( ReportAPIConstants.NO_DATA_FOUND_MESSAGE );
            validation = true;
        } else {
            // Get data from response
            Map<String, Map<String, String>> dataFromResponse = getLSDataFromResponse( responseBody );

            // Get data from DB
            Map<String, Map<String, String>> lsRdataFromDB = getLSDataFromDB( assignmentId, isMath );

            Log.assertThat( lsRdataFromDB.entrySet().stream().anyMatch( entry -> dataFromResponse.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoHashMap( responseData.getValue(), entry.getValue() ) ) ), "DB values are returned properly",
                    "DB values are not returned properly" );
        }
        return validation;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public Map<String, Map<String, String>> getLSDataFromResponse( String responseBody ) {

        // Getting data from response
        JSONObject jsonObj = new JSONObject( getKeyValueFromResponseWithArray( responseBody, "data" ) );
        JSONArray response = jsonObj.getJSONArray( "getLSAdminReportData" );
        Map<String, Map<String, String>> lsDetails = new HashMap<>();

        IntStream.range( 0, response.length() ).forEach( itr -> {

            String currentCourseLevel = SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "currentCourseLevel" );
            float courseLvlFloat = Float.parseFloat( currentCourseLevel );
            int courseLvl = (int) courseLvlFloat;
            currentCourseLevel = String.valueOf( courseLvl );

            String timeSpent = SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,timeSpent" );
            String hour;
            String min;

            if ( timeSpent.length() == 5 ) {
                hour = timeSpent.substring( 0, 2 );
                min = timeSpent.substring( 3 );

            } else {
                hour = timeSpent.substring( 0, 1 );
                min = timeSpent.substring( 2 );
            }
            int hourInt = Integer.parseInt( hour );
            int minInt = Integer.parseInt( min );
            int timeSpentValue = hourInt * 60 + minInt;

            Map<String, String> values = new HashMap<>();
            values.put( "currentCourseLevel", currentCourseLevel );
            values.put( "exercisesCorrect", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "rawPerformance,exercisesCorrect" ) );
            values.put( "exercisesAttempted", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "rawPerformance,exercisesAttempted" ) );
            values.put( "helpUsed", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,helpUsed" ) );
            values.put( "timeSpent", String.valueOf( timeSpentValue ) );
            values.put( "totalSessionCount", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,totalSessions" ) );
            lsDetails.put( String.valueOf( itr ), values );
        } );
        return lsDetails;
    }

    public Map<String, Map<String, String>> getLSDataFromDB( String assignmentId, boolean isMath ) {
        Map<String, Map<String, String>> valuesFromDB = new HashMap<>();

        String query;
        if ( isMath == true ) {
            Log.message( "Executing Query for Math assignments-->" );
            query = LSAdminReportDBQuery.LS_ADMIN_MATH_QUERY.replace( "mathAssignmentID", assignmentId );
        } else {
            Log.message( "Executing Query for Reading assignments-->" );
            query = LSAdminReportDBQuery.LS_ADMIN_READ_QUERY.replace( "readAssignmentID", assignmentId );
        }

        List<Object[]> rowList = SQLUtil.executeQuery( query );
        rowList.forEach( object -> {

            String string = object[0].toString();
            Log.message( "AU_ID Fetched From DB Query : " + string );

            String courseLevel = object[1].toString();
            float courseLvlFloat = Float.parseFloat( courseLevel );
            int courseLvl = (int) courseLvlFloat;
            courseLevel = String.valueOf( courseLvl );

            Map<String, String> values = new HashMap<>();
            values.put( "currentCourseLevel", courseLevel );
            values.put( "exercisesCorrect", object[2].toString() );
            values.put( "exercisesAttempted", object[3].toString() );
            char charAt = object[4].toString().charAt( 0 );
            values.put( "helpUsed", String.valueOf( charAt ) );
            values.put( "timeSpent", object[5].toString() );
            values.put( "totalSessionCount", object[6].toString() );
            valuesFromDB.put( object[0].toString(), values );
        } );

        return valuesFromDB;
    }

    /**
     * Generating request values
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, "" );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

}