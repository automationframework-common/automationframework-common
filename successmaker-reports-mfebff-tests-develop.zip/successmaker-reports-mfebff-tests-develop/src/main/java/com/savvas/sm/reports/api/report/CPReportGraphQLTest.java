package com.savvas.sm.reports.api.report;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class CPReportGraphQLTest extends UserAPI {

	private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

	String smUrl;
	String teacherDetails;
	String teacherUserName;
	String teacherId;
	String orgId;
	String studentId1;
	String studentId2;
	String studentId3;
	String studentId4;
	String groupId;
	String studentDetails;
	String listOfStuIds;
	String studentId;
	String studentAssignmentIdMath;

	@BeforeTest
	public void initTest() {
		smUrl = configProperty.getProperty( "SMAppUrl" );
		teacherDetails = RBSDataSetup.getMyTeacher( school );
		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
		teacherUserName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
		studentDetails = RBSDataSetup.getMyStudent( school, teacherUserName );
		studentId = SMUtils.getKeyValueFromResponse( teacherUserName, "userId" );
		studentId1 = SMUtils.getKeyValueFromResponse( teacherUserName, "userId" );
		studentId2 = SMUtils.getKeyValueFromResponse( teacherUserName, "userId" );
		studentId3 = SMUtils.getKeyValueFromResponse( teacherUserName, "userId" );
		groupId = SMUtils.getKeyValueFromResponse(studentId, "groupId");
		listOfStuIds = " "+ " " + studentId +studentId1 + " " + studentId2 + " " + studentId3 ;
		Log.message("List of Student ID's: " + listOfStuIds);

	}


	@Test ( dataProvider = "getData", groups = { "SMK-59116 GraphQL API for CP report", "API","SmokeTest" }, priority = 1 )
	public void testCPReportAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
		HashMap<String, String> headers = new HashMap<>();
		Log.testCaseInfo( testcaseName + testcaseDescription );

		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
		Map<String, String> queryItem = new HashMap<>();

		LocalDate now = LocalDate.now();
		Date date = new Date();
		LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.SUNDAY ) );
		String thisWeekStartDay = firstMonday.toString();
		String thisWeekEndDay = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );


		String payload = getPayload();
		String query ;
		Response response = null;
		String responseStatusCode = "";

		switch ( scenarioType ) {

		case "VALID_STUDENT_IDS":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID,  ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.FALSE.toString() );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.FALSE.toString() );
			queryItem.put( ReportAPIConstants.STUDENT_IDS, ReportAPIConstants.BACK_SLASH + studentId +  ReportAPIConstants.BACK_SLASH );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_STUDENT_IDS":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID,  ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.FALSE.toString() );
			queryItem.put( ReportAPIConstants.STUDENT_IDS, ReportAPIConstants.INVALID );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;

		case "VALID_TEACHER_IDS":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID,  ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.FALSE.toString() );
			queryItem.put( ReportAPIConstants.STUDENT_IDS, studentId );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_TEACHER_IDS":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + ReportAPIConstants.INVALID_TEACHER_ID + ReportAPIConstants.BACK_SLASH );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "WITHOUT_TOKEN":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID,  ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
			break;
		case "VALID_SUBJECT":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID,  ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.SUBJECT, ReportAPIConstants.VALID_SUBJECT_ID );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
			
		case "INVALID_SUBJECT":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID,  ReportAPIConstants.BACK_SLASH + orgId +  ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID,  ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.SUBJECT,ReportAPIConstants.INVALID_SUBJECT_ID  );
			query = constructQueryItems( queryItem );
            payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
            responseStatusCode =  Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
            break;

		case "INVALID_SUBJECT_STRING":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH  + orgId + ReportAPIConstants.BACK_SLASH  );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH  + teacherId + ReportAPIConstants.BACK_SLASH  );
            queryItem.put( ReportAPIConstants.SUBJECT,ReportAPIConstants.INVALID  );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;


		case "VALID_GROUP_ID":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH  + orgId + ReportAPIConstants.BACK_SLASH  );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH  + teacherId + ReportAPIConstants.BACK_SLASH  );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.TRUE.toString() );
			queryItem.put( ReportAPIConstants.GROUP_ID,  groupId );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_GROUP_ID":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH);
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.TRUE.toString() );
			queryItem.put( ReportAPIConstants.GROUP_ID, ReportAPIConstants.INVALID_GROUP_IDS );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;    
		case "VALID_LIMIT":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.LIMIT, ReportAPIConstants.VALID_LIMIT );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_LIMIT":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.LIMIT, ReportAPIConstants.INVALID );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_LIMIT_ZERO":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
            queryItem.put( ReportAPIConstants.LIMIT, ReportAPIConstants.INVALID_LIMIT_ZERO );
            query = constructQueryItems( queryItem );
            payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
            responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
            break;
		case "VALID_OFFSET":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.OFFSET, ReportAPIConstants.VALID_OFFSET );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_OFFSET":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.OFFSET, ReportAPIConstants.INVALID );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_IS_GROUP_SELECTED":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, ReportAPIConstants.INVALID );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "VALID_IS_GROUP_SELECTED":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.IS_GROUP_SELECTED, Boolean.FALSE.toString() );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "INVALID_STARTDATE_ENDDATE":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.START_DATE, ReportAPIConstants.INVALID );
			queryItem.put( ReportAPIConstants.END_DATE, ReportAPIConstants.INVALID );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;
		case "VALID_STARTDATE_ENDDATE":
			queryItem.put( ReportAPIConstants.ORGANIZATION_ID, ReportAPIConstants.BACK_SLASH + orgId + ReportAPIConstants.BACK_SLASH );
			queryItem.put( ReportAPIConstants.ID, ReportAPIConstants.BACK_SLASH + teacherId + ReportAPIConstants.BACK_SLASH );
			query = constructQueryItems( queryItem );
			payload = payload.replace( ReportAPIConstants.CP_QUERY , query);
			headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
			responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf(response.getStatusCode()) : ReportAPIConstants.NO_RESPONSE_CODE;
			break;

		}

		Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
		// Validation
		Log.message(response.getBody().asString());
		Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified" ,
				"The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
		if(responseStatusCode.equals( statusCode )){
			Log.pass("Test Passed.");
		}else{
			Log.fail("Test Failed. Check the steps above in red color.");
		}
		Log.endTestCase();
	}
	@DataProvider
	public Object[][] getData() {
		return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body","VALID_STUDENT_IDS" },
			{ "TC002", "400", "Verify the status code 200 for response body for providing only invalid studentIds in request body and validate response message","INVALID_STUDENT_IDS" },
			{ "TC003", "401", "Verify the status code 401 for response body for providing not providing Authorization in header","WITHOUT_TOKEN" },
			{ "TC004", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId and subject in request body ","VALID_SUBJECT" },
			 { "TC005", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and invalid subject in request body ","INVALID_SUBJECT" },
			{ "TC006", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invalid subject in request body ","INVALID_SUBJECT_STRING" },
			{ "TC007", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and limit in request body","VALID_LIMIT" },
			{ "TC008", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald limit in request body","INVALID_LIMIT" },
            { "TC009", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and invald limit (0) in request body","INVALID_LIMIT_ZERO" },
			{ "TC010", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and offset in request body","VALID_OFFSET" },
			{ "TC011", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invald offset in request body","INVALID_OFFSET" },
			{ "TC012", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and isGroupSelected in request body","VALID_IS_GROUP_SELECTED" },
			{ "TC013", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and invalid isGroupSelected  in request body","INVALID_IS_GROUP_SELECTED" },
			{ "TC014", "400", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and  invalid startDate and endDate  in request body", "INVALID_STARTDATE_ENDDATE"},
			{ "TC015", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and  valid startDate and endDate  in request body", "VALID_STARTDATE_ENDDATE"},
			{ "TC016", "200", "Verify the status code 200 for response body for providing valid OrgId and TeacherId  and  valid groupIds  in request body", "VALID_GROUP_ID"},
			{ "TC017", "200", "Verify the status code 400 for response body for providing valid OrgId and TeacherId  and  invalid groupIds  in request body", "INVALID_GROUP_ID"}

		};
	}





	public String constructQueryItems( Map<String, String> queryItem ) {
		return queryItem.entrySet()
				.stream()
				.map(e -> e.getKey()+":"+e.getValue())
				.collect( Collectors.joining(" \\n ") );
	}







	public String getPayload() throws IOException {
		String basePath = (new File(".")).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator +  "report" + File.separator +"CPReportRequest" + ".json";
		File file = new File( basePath );
		try (FileReader fr = new FileReader(file))
		{
			char[] chars  = new char[(int)file.length()];
			int offset = 0;
			while (offset < chars.length)
			{
				int result = fr.read(chars, offset, chars.length - offset);
				if (result == -1) {
					break;
				}
				offset += result;
			}
			return new String(chars);
		}
	}
}
