package com.savvas.sm.reports.ui.tests.admin.spr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class StudentPerformanceDemographicsTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics001: Verify that Student Demographics option is displayed for Student Performance Report", groups = { "Smoke", "SMK-58856", "studentPerformanceReports",
            "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            studentPerformancePage.clickOptionalFilter();

            Log.assertThat( studentPerformancePage.reportFilterComponent.getStudentDemographicsLabelForStudentPerformance().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly",
                    "Student demographics label not displayed properly. Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -" + studentPerformancePage.reportFilterComponent.getStudentDemographicsLabelForStudentPerformance() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click accordion button is displayed in left side of Student demographics" );
            //Expand student demographics 
            Log.assertThat( studentPerformancePage.reportFilterComponent.expandStudentPerformanceDemographics(), "User able to expande the studen demographics accordion", "Issue in expand the Student demographics accordion!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Disability status option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly",
                    "Issue in display th Disability status dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Disability status dropdown and check dropdown option are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Disability status dropdown" );

            //Selecting single option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the Disability status available drop down option is expandable when it is clicked and the select the single field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.DISABLITY_STATUS, Arrays.asList( ReportsUIConstants.STUDENT_DISABILITY_STATUS_OPTIONS.get( 1 ) ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.DISABLITY_STATUS ).equals( Arrays.asList( ReportsUIConstants.STUDENT_DISABILITY_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Disability status available drop down option when it is expandable and the deselect all the field" );
            studentPerformancePage.expanDropdown( studentPerformancePage.DISABLITY_STATUS );
            studentPerformancePage.selectOptionsFromDropdown( studentPerformancePage.DISABLITY_STATUS, Arrays.asList( ReportsUIConstants.STUDENT_DISABILITY_STATUS_OPTIONS.get( 1 ) ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.DISABLITY_STATUS ).isEmpty(), "User able to deselect all the option in disability status dropdown!",
                    "Issue in deselecting all the option in disability status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in disability status dropdown
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.DISABLITY_STATUS, ReportsUIConstants.STUDENT_DISABILITY_STATUS_OPTIONS.subList( 1, 2 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.DISABLITY_STATUS ).equals( ReportsUIConstants.STUDENT_DISABILITY_STATUS_OPTIONS.subList( 1, 2 ) ),
                    "User able to select the multiple option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics002: Verify the Student demographics Option is displayed for Sub-district admin", groups = { "Smoke", "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();

            Log.assertThat( studentPerformancePage.reportFilterComponent.getStudentDemographicsLabelForStudentPerformance().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly for sub-district admin",
                    "Student demographics label not displayed properly for sub-district admin Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -"
                            + studentPerformancePage.reportFilterComponent.getStudentDemographicsLabelForStudentPerformance() );
            Log.testCaseResult();

            //Expand student demographics 
            SMUtils.logDescriptionTC( "Verify the Gender option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.GENDER ), "Gender dropdown label is displayed properly", "Issue in display the gender dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Gender dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in gender drop down" );
            List<String> allValuesGenderDropdown = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.GENDER );
            allValuesGenderDropdown.add( "ALL" );
            Log.assertThat( allValuesGenderDropdown.containsAll( ReportsUIConstants.STUDENT_GENDER_OPTIONS ), "ALL options are displayed properly in Gender dropdown", "Issue in displaying the options in Gender dropdown!" );
            Log.testCaseResult();

            //Selecting single option in gender dropdown
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GENDER, Arrays.asList( ReportsUIConstants.STUDENT_GENDER_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GENDER ).equals( Arrays.asList( ReportsUIConstants.STUDENT_GENDER_OPTIONS.get( 1 ) ) ), "User able to select the single option in Gender dropdown",
                    "Issue in selecting the option in Gender dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the gender available drop down option when it is expandable and the deselect all the field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GENDER, Arrays.asList( ReportsUIConstants.STUDENT_GENDER_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GENDER ).isEmpty(), "User able to deselect all the option in Gender dropdown!", "Issue in deselecting all the option in Gender dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the Gender available drop down option is expandable when it is clicked and the select the multiple field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.GENDER, ReportsUIConstants.STUDENT_GENDER_OPTIONS.subList( 1, 2 ) );
            studentPerformancePage.reportFilterComponent.collapseStudentDemographicsDropdown( ReportsUIConstants.GENDER );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.GENDER ).equals( ReportsUIConstants.STUDENT_GENDER_OPTIONS.subList( 1, 2 ) ), "User able to select the multiple option in gender dropdown",
                    "Issue in selecting the option in gender dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics003: Verify the  Student demographics availbility for school admin", groups = { "Smoke", "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcStudentPerformanceStudentDemographics003: Verify the  Student demographics availbility for sub-district admin <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();

            SMUtils.logDescriptionTC( "Verify the  Student demographics Option is displayed for school admin" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getStudentDemographicsLabelForStudentPerformance().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly for school admin",
                    "Student demographics label not displayed properly for school admin. Expected - " + ReportsUIConstants.STUDENT_DEMOGRAPHICS + " Actual -"
                            + studentPerformancePage.reportFilterComponent.getStudentDemographicsLabelForStudentPerformance() );
            Log.testCaseResult();

            //Expand student demographics 
            SMUtils.logDescriptionTC( "Verify Race option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display the race dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Race dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Race drop down" );

            List<String> allValuesRaceDropdown = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.RACE );
            allValuesRaceDropdown.add( "ALL" );

            Log.assertThat( allValuesRaceDropdown.containsAll( ReportsUIConstants.STUDENT_RACE_OPTIONS ), "ALL options are displayed properly in race dropdown",
                    "Issue in displaying the options in race dropdown! Expected - " + ReportsUIConstants.STUDENT_RACE_OPTIONS + " Actual - " + allValuesRaceDropdown.toString() );
            Log.testCaseResult();

            //Selecting single option in Race dropdown
            SMUtils.logDescriptionTC( "Verify the Race available drop down option is expandable when it is clicked and the select the single field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.RACE, Arrays.asList( ReportsUIConstants.STUDENT_RACE_OPTIONS.get( 1 ) ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.RACE ).equals( Arrays.asList( ReportsUIConstants.STUDENT_RACE_OPTIONS.get( 1 ) ) ), "User able to select the single option in race dropdown",
                    "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Race available drop down option when it is expandable and the deselect all the field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.RACE, Arrays.asList( ReportsUIConstants.STUDENT_RACE_OPTIONS.get( 1 ) ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.RACE ).isEmpty(), "User able to deselect all the option in Race dropdown!", "Issue in deselecting all the option in Race dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in race dropdown
            SMUtils.logDescriptionTC( "Verify the Race available drop down option is expandable when it is clicked and the select the multiple field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.RACE, ReportsUIConstants.STUDENT_RACE_OPTIONS.subList( 1, 3 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.RACE ).equals( ReportsUIConstants.STUDENT_RACE_OPTIONS.subList( 1, 3 ) ), "User able to select the multiple option in race dropdown",
                    "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics004: Verify the SocioEconomic Status dropdown", groups = { "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcStudentPerformanceStudentDemographics004: Verify the SocioEconomic Status dropdown<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();

            //Expand student demographics 
            SMUtils.logDescriptionTC( "Verify SocioEconomic Status option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly",
                    "Issue in display the SocioEconomic Status dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the SocioEconomic Status dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Socioeconomic Status drop down" );

            List<String> allValues = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS );
            allValues.add( "ALL" );

            Log.assertThat( allValues.containsAll( ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS ), "ALL options are displayed properly in SocioEconomic Status dropdown",
                    "Issue in displaying the options in SocioEconomic Status dropdown! Expected - " + ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS + " Actual - " + allValues.toString() );
            Log.testCaseResult();

            //Selecting single option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status available drop down option is expandable when it is clicked and the select the single field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS ).equals( Arrays.asList( ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status available drop down option when it is expandable and the deselect all the field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS ).isEmpty(), "User able to deselect all the option in special services dropdown!",
                    "Issue in deselecting all the option in Special services dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status available drop down option is expandable when it is clicked and the select the multiple field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS, ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS.subList( 1, 3 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.SOCIO_ECONOMIC_STATUS ).equals( ReportsUIConstants.STUDENT_SOCIOECONOMIC_STATUS_OPTIONS.subList( 1, 3 ) ),
                    "User able to select the multiple option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics005:Verify the English langauge proficiency dropdown", groups = { "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcStudentPerformanceStudentDemographics005: Verify the English langauge proficiency Status  dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();

            //Expand student demographics 
            SMUtils.logDescriptionTC( "Verify English langauge proficiency Status option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English langauge proficiency Status  dropdown label is displayed properly",
                    "Issue in display the English langauge proficiency Status  dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the English langauge proficiency dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in English langauge proficiency drop down" );

            List<String> allValues = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY );
            allValues.add( "ALL" );

            Log.assertThat( allValues.containsAll( ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS ), "ALL options are displayed properly in English langauge proficiency Status dropdown",
                    "Issue in displaying the options in English langauge proficiency Status dropdown! Expected - " + ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS + " Actual - " + allValues.toString() );
            Log.testCaseResult();

            //Selecting single option in English langauge proficiency Status dropdown
            SMUtils.logDescriptionTC( "Verify the English langauge proficiency available drop down option is expandable when it is clicked and the select the single field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY ).equals( Arrays.asList( ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in English langauge proficiency Status dropdown", "Issue in selecting the option in English langauge proficiency Status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify the English langauge proficiency available drop down option when it is expandable and the deselect all the field" );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY ).isEmpty(), "User able to deselect all the option in English langauge proficiency status dropdown!",
                    "Issue in deselecting all the option in English langauge proficiency status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in race dropdown
            SMUtils.logDescriptionTC( "Verify the English langauge proficiency available drop down option is expandable when it is clicked and the select the multiple field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY, ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.subList( 1, 2 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY ).equals( ReportsUIConstants.STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.subList( 1, 2 ) ),
                    "User able to select the multiple option in English langauge proficiency Status dropdown", "Issue in selecting the option in English langauge proficiency Status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "tcStudentPerformanceStudentDemographics006: Verify the migrant status dropdown", groups = { "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcStudentPerformanceStudentDemographics006: Verify the  migrant status dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            //Expand student demographics 
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();
            SMUtils.logDescriptionTC( "Verify migrant Status option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), " Migrant status dropdown label is displayed properly",
                    "Issue in display the  migrant status dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the migrant Status dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Migrant drop down" );

            List<String> allValues = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.MIGRANT_STATUS );
            allValues.add( "ALL" );

            Log.assertThat( allValues.containsAll( ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS ), "ALL options are displayed properly in  migrant status dropdown",
                    "Issue in displaying the options in  migrant status dropdown! Expected - " + ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS + " Actual - " + allValues.toString() );
            Log.testCaseResult();

            //Selecting single option in  migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the Migrant available drop down option is expandable when it is clicked and the select the single field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.MIGRANT_STATUS ).equals( Arrays.asList( ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in  migrant status dropdown", "Issue in selecting the option in  migrant status dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Migrant available drop down option when it is expandable and the deselect all the field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.MIGRANT_STATUS ).isEmpty(), "User able to deselect all the option in migrant status dropdown!",
                    "Issue in deselecting all the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in  migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the Migrant available drop down option is expandable when it is clicked and the select the multiple field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.MIGRANT_STATUS, ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS.subList( 1, 2 ) );

            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.MIGRANT_STATUS ).equals( ReportsUIConstants.STUDENT_MIGRANT_STATUS_OPTIONS.subList( 1, 2 ) ),
                    "User able to select the multiple option in  migrant status dropdown", "Issue in selecting the option in  migrant status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics007: Verify the Ethnicity dropdown", groups = { "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcStudentPerformanceStudentDemographics007: Verify the Ethnicity dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            //Expand student demographics 
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();
            SMUtils.logDescriptionTC( "Verify Ethnicity option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Ethnicity dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Ethnicity drop down" );

            List<String> allValues = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.ETHINICIY );
            allValues.add( "ALL" );

            Log.assertThat( allValues.containsAll( ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS ), "ALL options are displayed properly in Ethnicity dropdown",
                    "Issue in displaying the options in Ethnicity dropdown! Expected - " + ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS + " Actual - " + allValues.toString() );
            Log.testCaseResult();

            //Selecting single option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the Ethnicity available drop down option is expandable when it is clicked and the select the single field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.ETHINICIY, Arrays.asList( ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.ETHINICIY ).equals( Arrays.asList( ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Ethnicity available drop down option is expandable when it is clicked and the select the single field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.ETHINICIY, Arrays.asList( ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.ETHINICIY ).isEmpty(), "User able to deselect all the option in Ethnicity dropdown!", "Issue in deselecting all the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the Ethnicity available drop down option is expandable when it is clicked and the select the multiple field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.ETHINICIY, ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS.subList( 1, 2 ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.ETHINICIY ).equals( ReportsUIConstants.STUDENT_ETHNICITY_OPTIONS.subList( 1, 2 ) ), "User able to select the multiple option in Ethnicity dropdown",
                    "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "tcStudentPerformanceStudentDemographics008: Verify the Special Services dropdown", groups = { "SMK-58856", "studentPerformanceReports", "studentDemographics" }, priority = 1 )
    public void tcStudentPerformanceStudentDemographics008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcStudentPerformanceStudentDemographics008: Verify the Special Services dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to the student perfomance report filter page
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            //Expand student demographics 
            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();
            SMUtils.logDescriptionTC( "Verify Special Services option name is displayed in the Student demographics" );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getDemographicDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special Services dropdown label is displayed properly",
                    "Issue in display the Special Services dropdown label!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify and click the Special Services dropdown and check dropdown options are visible" );
            SMUtils.logDescriptionTC( "Verify the available options in Special Services drop down" );

            List<String> allValues = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.SPECIAL_SERVICES );
            allValues.add( "ALL" );

            Log.assertThat( allValues.containsAll( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS ), "ALL options are displayed properly in Special Services dropdown",
                    "Issue in displaying the options in Special Services dropdown! Expected - " + ReportsUIConstants.SPECIAL_SERVICES_OPTIONS + " Actual - " + allValues );
            Log.testCaseResult();

            //Selecting single option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the Special Services dropdown option is expandable when it is clicked and the select the single field" );

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.SPECIAL_SERVICES ).equals( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

            //deselect the previously selected options
            SMUtils.logDescriptionTC( "Verify the Special Services available drop down option when it is expandable and the deselect all the field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.SPECIAL_SERVICES ).isEmpty(), "User able to deselect all the option in Special service dropdown!",
                    "Issue in deselecting all the option in Special service dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the Special Services available drop down option is expandable when it is clicked and the select the multiple field" );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.SPECIAL_SERVICES, ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.subList( 1, 2 ) );
            Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( studentPerformancePage.SPECIAL_SERVICES ).equals( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.subList( 1, 2 ) ),
                    "User able to select the multiple option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
