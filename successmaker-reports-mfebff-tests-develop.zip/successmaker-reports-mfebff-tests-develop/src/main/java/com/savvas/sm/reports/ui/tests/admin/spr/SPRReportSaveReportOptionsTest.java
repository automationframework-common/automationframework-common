package com.savvas.sm.reports.ui.tests.admin.spr;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SPRReportSaveReportOptionsTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        username = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify 'Save Report Option'  button in SPR report page", groups = { "Smoke", "SMK-57946", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions001: Verify the user can navigates to Student Performance Report page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.logDescriptionTC( "Verify 'Save Report Option'  button in SPR report page" );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in SPR report",
                    "The save report option is not displayed in SPR report" );
            Log.assertThat( !StudentPerformancePage.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify user can click the 'Save Report Option' button in SPR report page" );
            SMUtils.logDescriptionTC( "Verify all available fields in 'Save Report Option Popup." );
            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to cancel the in 'Save Report Option ' Popup on SPR report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with new name." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            String filterName2 = "Filter" + System.nanoTime();
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName2 );
            saveReportOptionPopup.clickSaveButton();
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify If User enter more than 50 characters in new custom report configuration text box." );
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            SMUtils.logDescriptionTC( "Verify User can able to click the close button in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)", groups = { "Smoke", "SMK-57946", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions002: Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 0 );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  'since ip' in date at risk Dropdown with Select multiple options in student demographics dropdowns and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DEFAULT_DATE_AT_RISK );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.LANGUAGE_SPANISH );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '24 weeks' in date at risk Dropdown with Select 'english' from languagge drop down" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ), courses.get( 2 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 1 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with all options in all required and optional filters" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with  '16 weeks' in date at risk Dropdown with Select 'english' from languagge drop down" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'student user name ' option in display Dropdown with display on SPR report and load the report", groups = { "SMK-57946", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions003: Verify User can able to save the report option with 'student user name ' option in display Dropdown with display on SPR report and load the report" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'student user name ' option in display Dropdown with display on SPR report and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 0 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 2 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'student  name ' option in display Dropdown with display on SPR report and load the report" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'student id ' option in display Dropdown with display on SPR report and load the report" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );
            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report", groups = { "Smoke", "SMK-57946", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcSPRSaveReportOptions004:Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct (Mean)" );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'No' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report", groups = { "SMK-57946", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions005:Verify User can able to save the report option with 'No' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'No' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();

            SMUtils.logDescriptionTC( "Verify Include Performance Summary should be display ." );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            SMUtils.logDescriptionTC( "Verify Include Performance By Strand should be display ." );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            SMUtils.logDescriptionTC( "Verify Include Areas of Growth should be display ." );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );
            // StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Percent Correct (Mean)" );

            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS,
                    Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ), ReportsUIConstants.GENDER_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,
                    Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Yes' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report", groups = { "SMK-57946", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions006: Verify User can able to save the report option with 'Yes' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Yes' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Assessed (Mean)" );

            SMUtils.logDescriptionTC( "Verify Include Performance Summary should be display ." );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            SMUtils.logDescriptionTC( "Verify Include Performance By Strand should be display ." );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            SMUtils.logDescriptionTC( "Verify Include Areas of Growth should be display ." );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report required fields with Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown.", groups = { "SMK-57946", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions007:Verify User can able to save the report required fields with Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown.<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report required fields with Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown." );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Mastered (Mean)" );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report  with Select 'Female' option in 'Gender' dropdown and 'Migrant' in Migrant status dropdown." );
            // StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Percent Mastered (Mean)" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report  'White' option in Race dropdown and 'Hispanico or Latino' in Ethnicity dropdown." );
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Percent Students With AP" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Select 'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown." );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.size() - 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,
                    Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.size() - 1 ) ) );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = { "Smoke", "SMK-57946", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions008: Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.logDescriptionTC( "Verify the Existing custom report configuration dropdown if the user does not have already saved options" );

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 0 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();

            Log.assertThat( !saveReportOptionPopup.isExistingReportOptionDropdownEnabled(), "Existing custom report configuration dropdown is disabled if the user does not have already saved options",
                    "Existing custom report configuration dropdown is not  disabled if the user does not have already saved options" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Skills Mastered(Mean)' in sort Dropdown, Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown.", groups = { "SMK-57946",
            "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "tcSPRSaveReportOptions009:Verify User can able to save the report option with 'Skills Mastered(Mean)' in sort Dropdown, Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown.<small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Skills Mastered(Mean)' in sort Dropdown, Select 'Yes' option in 'Disability Status' dropdown and 'English' in English Language Proficiency dropdown." );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Mastered (Mean)" );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option  with Select 'Not Specfied' option in 'Gender' dropdown and 'Migrant' in Migrant status dropdown." );
            // StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skills Percent Mastered (Mean)" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report  'Asian' option in Race dropdown and 'Hispanico or Latino' in Ethnicity dropdown." );
            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Percent Students With AP" );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Select 'Not Specified' option in 'Socio economic' dropdown and 'Not Specfied' in special services dropdown." );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.size() - 1 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES,
                    Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.size() - 1 ) ) );

            saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    // reset

    @Test ( description = "Verify the reset functionality on saved reports.", groups = { "Smoke", "SMK-60739", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions010() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions010:Verify the reset functionality on saved reports.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );

            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct (Mean)" );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            // Click on reset button
            StudentPerformancePage.reportFilterComponent.clickResetButton();

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equals( ReportsUIConstants.ZERO_STATE_TEACHER ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_TEACHER,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_TEACHER );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equals( ReportsUIConstants.ZERO_STATE_GRADES ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_GRADES,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_GRADES );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equals( ReportsUIConstants.ZERO_STATE_GROUPS ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_GROUPS,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_GROUPS );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).equals( ReportsUIConstants.DISPLAY.get( 0 ) ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DISPLAY.get( 0 ),
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DISPLAY.get( 0 ) );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ).equals( ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ) ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ),
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ) );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE ).equals( ReportsUIConstants.DEFAULT_LANGUAGE ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DEFAULT_LANGUAGE,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DEFAULT_LANGUAGE );
            // DEMO

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the reset button resetting the whole form when all the values are selected.", groups = { "Smoke", "SMK-60739", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions011() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions011:The mandatory fieldst should go back to default values.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );

            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct (Mean)" );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );

            // Click on reset button
            StudentPerformancePage.reportFilterComponent.clickResetButton();

            Log.testCaseInfo( "Verify the reset button functionality when the user selects any value from teacher dropdown in student performance report.<small><b><i>[" + browser + "]</b></i></small>" );
            Log.testCaseInfo( "Verify the reset button functionality when the user selects any grade  from grade dropdown in student performance report.<small><b><i>[" + browser + "]</b></i></small>" );
            Log.testCaseInfo( "Verify the reset button functionality when the user selects any group  from group dropdown in student performance report.<small><b><i>[" + browser + "]</b></i></small>" );
            Log.testCaseInfo( "Verify the reset button functionality when the user selects values as student id / student user name from group dropdown in student performance report.<small><b><i>[" + browser + "]</b></i></small>" );
            Log.testCaseInfo( "Verify the reset button functionality when the user selects any value from date of risk drop down in student performance report.<small><b><i>[" + browser + "]</b></i></small>" );
            Log.testCaseInfo( "Verify the reset button functionality when the user selects spanish languagge from Languagge drop down in student performance report.<small><b><i>[" + browser + "]</b></i></small>" );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equals( ReportsUIConstants.ZERO_STATE_TEACHER ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_TEACHER,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_TEACHER );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equals( ReportsUIConstants.ZERO_STATE_GRADES ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_GRADES,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_GRADES );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equals( ReportsUIConstants.ZERO_STATE_GROUPS ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_GROUPS,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_GROUPS );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).equals( ReportsUIConstants.DISPLAY.get( 0 ) ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DISPLAY.get( 0 ),
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DISPLAY.get( 0 ) );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ).equals( ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ) ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ),
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ) );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE ).equals( ReportsUIConstants.DEFAULT_LANGUAGE ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DEFAULT_LANGUAGE,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DEFAULT_LANGUAGE );
            // DEMO
            Log.testCaseInfo( "Verify the reset button functionality when the user select all of the demographic field value as not specified  in student performance report .<small><b><i>[" + browser + "]</b></i></small>" );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the reset button functionality when the user select any one of the demographic field value in student performance report ", groups = { "SMK-60739", "SaveReportOption", "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions012() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions010:Verify the reset button functionality when the user select any one of the demographic field value in student performance report .<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with required fields with All options in student demographics dropdowns and load the report and load the report" );
            StudentPerformancePage.reportFilterComponent.expandOptionalFilter();

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 3 ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying", "Mask Student is not displaying" );
            StudentPerformancePage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );

            // Gender alone

            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL ) );

            SaveReportFilterPopup saveReportOptionPopup = StudentPerformancePage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            // Click on reset button
            StudentPerformancePage.reportFilterComponent.clickResetButton();

            Log.testCaseInfo( "Verify the reset button functionality when the user select any one of the demographic field value in student performance report .<small><b><i>[" + browser + "]</b></i></small>" );

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ).equals( ReportsUIConstants.ZERO_STATE_TEACHER ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_TEACHER,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_TEACHER );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL ).equals( ReportsUIConstants.ZERO_STATE_GRADES ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_GRADES,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_GRADES );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL ).equals( ReportsUIConstants.ZERO_STATE_GROUPS ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.ZERO_STATE_GROUPS,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.ZERO_STATE_GROUPS );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).equals( ReportsUIConstants.DISPLAY.get( 0 ) ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DISPLAY.get( 0 ),
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DISPLAY.get( 0 ) );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ).equals( ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ) ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ),
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 0 ) );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE ).equals( ReportsUIConstants.DEFAULT_LANGUAGE ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.DEFAULT_LANGUAGE,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.DEFAULT_LANGUAGE );
            // DEMO

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );

            Log.testCaseInfo( "Verify the reset button functionality when the user select all of the demographic field value as not specified  in student performance report .<small><b><i>[" + browser + "]</b></i></small>" );

            orgName = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 );

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            //courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            //StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Exercises Correct (Mean)" );
            StudentPerformancePage.reportFilterComponent.expandStudentDemographics();
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 3 ) ) );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 6 ) ) );

            // Click on reset button
            StudentPerformancePage.reportFilterComponent.clickResetButton();

            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );
            Log.assertThat( StudentPerformancePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "The  student performance  Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED,
                    "The student performance  Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
