package com.savvas.sm.reports.ui.tests.admin;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.PSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.SystemEnrollmentAndUsagePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class AdminSortingFuctionalityTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private List<String> courses;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify User able  to Sort the student name by LastName for CPR", groups = { "SMK-66316", "AdminDashboard", "Reports", "Cumulative Performance", "Smoke" }, priority = 1 )
    public void tcCumulativePerformance001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCumulativePerformance001: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( cumulativePerformancePage.checkReportHeaderAfterRun(), "Admin Cumulative Performance Run Report option displayed", "Admin Cumulative Performance Run Report is not clicked" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            cumulativePerformancePage.reportFilterComponent.sortStudentNameByLastName();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Student ID for CPR", groups = { "SMK-66316", "AdminDashboard", "Reports", "Cumulative Performance", "Smoke" }, priority = 1 )
    public void tcCumulativePerformance002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcCumulativePerformance002: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.clickOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );
            cumulativePerformancePage.reportFilterComponent.handleStudentPopup();
            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( cumulativePerformancePage.checkReportHeaderAfterRun(), "Admin Cumulative Performance Run Report option displayed", "Admin Cumulative Performance Run Report is not clicked" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            cumulativePerformancePage.reportFilterComponent.sortStudentByStudentID();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Username for CPR", groups = { "SMK-66316", "AdminDashboard", "Reports", "Cumulative Performance", "Smoke" }, priority = 1 )
    public void tcCumulativePerformance003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcCumulativePerformance003: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            cumulativePerformancePage.clickOptionalFilter();
            cumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( cumulativePerformancePage.checkReportHeaderAfterRun(), "The Cumulative Performance Report viewer page is displayed", "The Cumulative Performance Report viewer page is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            cumulativePerformancePage.reportFilterComponent.sortStudentByStudentUsername();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the student name by LastName for LS", groups = { "SMK-66316", "AdminDashboard", "Reports", "Last Session", "Smoke" }, priority = 1 )
    public void tcLastSession004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcLastSession004: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage RecentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            RecentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            RecentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( RecentSessionsPage.checkReportHeaderAfterRun(), "The Last Session Run Report viewer page is displayed", " The Last Session Run Report viewer page is not displayed" );
            Log.assertThat( RecentSessionsPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            RecentSessionsPage.reportFilterComponent.sortStudentNameByLastName();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Student ID for LS", groups = { "SMK-66316", "AdminDashboard", "Reports", "Last Session", "Smoke" }, priority = 1 )
    public void tcLastSession005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcLastSession005: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            recentSessionsPage.reportFilterComponent.expandOptionalFilter();
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );
            recentSessionsPage.reportFilterComponent.handleStudentPopup();
            recentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( recentSessionsPage.checkReportHeaderAfterRun(), "The Last Session Run Report viewer page is displayed", " The Last Session Run Report viewer page is not displayed" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            recentSessionsPage.reportFilterComponent.sortStudentByStudentID();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Username for LS", groups = { "SMK-66316", "AdminDashboard", "Reports", "Last Session", "Smoke" }, priority = 1 )
    public void tcLastSession006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcLastSession006: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            RecentSessionsPage recentSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            recentSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            recentSessionsPage.reportFilterComponent.expandOptionalFilter();
            recentSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            recentSessionsPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( recentSessionsPage.checkReportHeaderAfterRun(), "The Last Session Run Report viewer page is displayed", " The Last Session Run Report viewer page is not displayed" );
            Log.assertThat( recentSessionsPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            recentSessionsPage.reportFilterComponent.sortStudentByStudentUsername();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the student name by LastName for PS", groups = { "SMK-66316", "AdminDashboard", "Reports", "Prescriptive Scheduling", "Smoke" }, priority = 1 )
    public void tcprescriptiveScheduling007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcprescriptiveScheduling007: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            prescriptiveSchedulingPage.fillGrade( "5" );
            prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeaderAfterRun(), "The Prescriptive Scheduling Report viewer page is displayed", " The Prescriptive Scheduling Report viewer page is not displayed" );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            prescriptiveSchedulingPage.reportFilterComponent.sortStudentNameByLastName();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Student Username for PS", groups = { "SMK-66316", "AdminDashboard", "Reports", "Prescriptive Scheduling", "Smoke" }, priority = 1 )
    public void tcprescriptiveScheduling008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcprescriptiveScheduling008: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            prescriptiveSchedulingPage.fillGrade( "5" );
            prescriptiveSchedulingPage.reportFilterComponent.expandOptionalFilter();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Username" );
            prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeaderAfterRun(), "The Prescriptive Scheduling Report viewer page is displayed", " The Prescriptive Scheduling Report viewer page is not displayed" );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            prescriptiveSchedulingPage.reportFilterComponent.sortStudentByStudentUsername();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Student ID for PS", groups = { "SMK-66316", "AdminDashboard", "Reports", "Last Session", "Smoke" }, priority = 1 )
    public void tcprescriptiveScheduling009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcprescriptiveScheduling009: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            PrescriptiveSchedulingPage prescriptiveSchedulingPage = dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, orgName );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            prescriptiveSchedulingPage.selectTargetDateAsCurrentDate();
            prescriptiveSchedulingPage.fillGrade( "5" );
            prescriptiveSchedulingPage.reportFilterComponent.expandOptionalFilter();
            prescriptiveSchedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student ID" );
            prescriptiveSchedulingPage.reportFilterComponent.handleStudentPopup();
            prescriptiveSchedulingPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( prescriptiveSchedulingPage.checkReportHeaderAfterRun(), "The Prescriptive Scheduling Report viewer page is displayed", " The Last Session Run Report viewer page is not displayed" );
            Log.assertThat( prescriptiveSchedulingPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            prescriptiveSchedulingPage.reportFilterComponent.sortStudentByStudentID();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the student name by LastName for SEU", groups = { "SMK-66316", "AdminDashboard", "Reports", "System Enrollment And Usage", "Smoke" }, priority = 1 )
    public void tcSEU010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSEU010: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( systemEnrollmentAndUsageReportPage.checkReportHeaderAfterRun(), "The System Enrollment And Usage Report viewer page is displayed", "The System Enrollment And Usage Report viewer page is not displayed" );
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getStudentLabel().equalsIgnoreCase( "Student" ), "Student Column is displayed!", "Student Column is not displayed !" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.sortStudentNameByLastName();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Username for SEU", groups = { "SMK-66316", "AdminDashboard", "Reports", "System Enrollment And Usage", "Smoke" }, priority = 1 )
    public void tcSEU011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSEU011: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Username (login)" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( systemEnrollmentAndUsageReportPage.checkReportHeaderAfterRun(), "The System Enrollment And Usage Report viewer page is displayed", "The System Enrollment And Usage Report viewer page is not displayed" );
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getStudentInformationLabel().equalsIgnoreCase( "Student Information" ), "Student Information Column is displayed!", "Student Information Column is not displayed !" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.sortStudentByUsername();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User able  to Sort the students by Student ID for SEU", groups = { "SMK-66316", "AdminDashboard", "Reports", "System Enrollment And Usage", "Smoke" }, priority = 1 )
    public void tcSEU012() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSEU012: <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SystemEnrollmentAndUsagePage systemEnrollmentAndUsageReportPage = dashBoardPage.reportFilterComponent.clickOnSystemEnrollmentAndUsagePage();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SEU_SUJECT_LBL, ReportsUIConstants.SEU_ALL_MATH_WITH_CUSTOM );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.expandOptionalFilter();
            systemEnrollmentAndUsageReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Student Id" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( systemEnrollmentAndUsageReportPage.checkReportHeaderAfterRun(), "The System Enrollment And Usage Report viewer page is displayed", "The System Enrollment And Usage Report viewer page is not displayed" );
            Log.assertThat( systemEnrollmentAndUsageReportPage.reportFilterComponent.getStudentInformationLabel().equalsIgnoreCase( "Student Information" ), "Student Information Column is displayed!", "Student Information Column is not displayed !" );
            systemEnrollmentAndUsageReportPage.reportFilterComponent.sortStudentByID();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}