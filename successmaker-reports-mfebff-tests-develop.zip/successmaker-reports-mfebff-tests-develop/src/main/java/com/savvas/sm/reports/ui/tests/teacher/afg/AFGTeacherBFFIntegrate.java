package com.savvas.sm.reports.ui.tests.teacher.afg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.report.bff.teacher.tests.AFGTeacherReportGraphQLTest;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import io.restassured.response.Response;

public class AFGTeacherBFFIntegrate extends UserAPI  {

    public AFGTeacherReportGraphQLTest afgBFF = new AFGTeacherReportGraphQLTest();
    public CourseAPI coursesMethod = new CourseAPI();

    private static List<String> studentRumbaIds = new ArrayList<>();
    private static List<String> courseIDs = new ArrayList<>();
    private static List<String> studentUserName = new ArrayList<>();
    private static List<String> assignmentIds = new ArrayList<>();

    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> assignmenNameandId = new HashMap<>();
    private static HashMap<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> contentBaseName = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();

    private String smUrl;
    private String browser;
    private String teacherDetails = null;
    private String teacherUsername = null;
    private String orgId = null;
    private String teacherId = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    private String student1Id;
    private String student2Id;
    private String student1Detail = null;
    private String student2Detail = null;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        student1Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student2Detail=RBSDataSetup.getMyStudent( school, teacherUsername );

        student1Id= SMUtils.getKeyValueFromResponse( student1Detail, Constants.USERID_HEADER );
        student2Id= SMUtils.getKeyValueFromResponse( student2Detail, Constants.USERID_HEADER );

        studentRumbaIds.add( student1Id );
        studentRumbaIds.add( student2Id );

        studentUserName.add( SMUtils.getKeyValueFromResponse( student1Detail, RBSDataSetupConstants.USERNAME ) );
        studentUserName.add( SMUtils.getKeyValueFromResponse( student2Detail, RBSDataSetupConstants.USERNAME ) );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( Constants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( Constants.GROUP_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( Constants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        HashMap<String, String> groupresponse = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
        Log.message( "GroupDetails: " + groupresponse );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
        Log.message( "contentBase: " +  contentBase );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
        Log.message( "courseIDs: " +  courseIDs );

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details: " + assignAssignment );

        JSONObject jsonObject = new JSONObject( assignAssignment.get( Constants.REPORT_BODY ) );
        JSONArray jsonArray = jsonObject.getJSONArray( Constants.DATA );


        for ( Object assignment : jsonArray ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmenNameandId.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment Name and ID's: " + assignmenNameandId );

        JSONArray assignmentIDJson = jsonObject.getJSONArray( Constants.REPORT_BODY_DATA );

        String mathAssignmentId = assignmenNameandId.get( Constants.MATH );
        String mathSettingsAssignmentId  = assignmenNameandId.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ));
        String readAssignmentId  = assignmenNameandId.get( Constants.READING );
        String readSettingsAssignmentId  = assignmenNameandId.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ));

        assignmentIds = Arrays.asList( mathAssignmentId, mathSettingsAssignmentId, readAssignmentId, readSettingsAssignmentId );
        Log.message( "assignmentIds: " + assignmentIds );

        IntStream.rangeClosed( 0, studentRumbaIds.size()-1).forEach( studentNumber -> {

            String username = studentUserName.get( 0 );
            Log.message("Student taking asssignemnt is ==> " + username);
            try {
                executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
                executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );
                executeCourse( username, "SM Focus Math: Grade 1", true );

                executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
                executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );
                executeCourse( username, "SM Focus Reading: Grade 1", false );

            } catch ( IOException e ) {
                e.printStackTrace();
            }
        } );
    }



    @Test ( description = "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns.", groups = { "SMK-66757", "reports", "Areasforgrowth" }, priority = 1 )
    public void tcAFGIntegrateBFF001() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage afgPage = new AreaForGrowthPage( driver );
        AFGReportViewerPage afgViewerPage = new  AFGReportViewerPage( driver );
        List<String> payloadStudentIds = new ArrayList<>();
        List<String> payloadCourseIds = new ArrayList<>();
        Response response;

        Log.testCaseInfo( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
        try {

            for ( String courseId : assignmentIds ) {
                payloadCourseIds.add( "\"" + courseId + "\"" );
            }

            for ( String studentId : studentRumbaIds ) {
                payloadStudentIds.add( "\"" + studentId + "\"" );
            }

            Log.message( "Payload StudentID: " + payloadStudentIds );
            Log.message( "payload CourseID: " + payloadCourseIds.toString() );


            String payload = afgPage.readJsonResponse( "TeacherAFGPayload.json");
            payload = payload.replace( "teacherUserId", teacherId )
                    .replace( "orgId",  orgId  )
                    .replace( "subjectId", "1"   )
                    .replace( "dateAtRiskValue", "10400" ) //By default Date At Risk value will be 10400
                    .replace( "groupFlag", "false" )
                    .replace( "studentIdValues", payloadStudentIds.toString() )
                    .replace( "groupIdValues", "null" )
                    .replace( "assignmentIdValues", payloadCourseIds.toString() )
                    .replace( "orderByValues", AFGReportConstants.STRAND_CAPS);
            Log.message( "Final Payload: " +  payload );

            response = afgPage.postAFGBFF( payload, teacherId, orgId, teacherUsername );
            Log.message( response.getBody().asString() );

            Map<String, Map<String, String>> dataFromResponse = afgPage.getAFGDataFromResponse( response.getBody().asString(), ReportsUIConstants.MATH, Constants.MATH );
            Log.message( "dataFromResponse: " + dataFromResponse );

            Map<String, List<String>> getstudentsFromResponse = afgPage.getstudentsFromResponse( response.getBody().asString(), ReportsUIConstants.MATH, Constants.MATH );
            Log.message( "getstudentsFromResponse: " + getstudentsFromResponse );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Teacher: " + teacherUsername );
            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD  );

            afgPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            afgPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            
            SMUtils.logDescriptionTC( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
            Log.assertThat( afgViewerPage.getColumnHeaders().containsAll( AFGReportConstants.COLUMN_HEADERS ), "All the column headers are displaying properly", "column headers are not displaying properly!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Student, Date At Risk, Targeted Lesson columns should display under Skill Description." );
            Log.assertThat( afgViewerPage.getColumnSubHeaders().containsAll( AFGReportConstants.COLUMN_SUBHEADERS ), "All the subheaders under the skill description are displaying properly", "All the subheaders under the skill description are not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Skill Desciption, Level and Strand, when student is not mastered (Watch Closely)" );
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level and Strand, when student is At risk. " );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );

            SMUtils.logDescriptionTC( "Verify the title  of the   Areas For Growth Report  is displaying as ' report viewer '   with successmaker logo in the top left of the page" );
            Log.assertThat( afgViewerPage.reportOutputComponent.getReportPageTitle().equalsIgnoreCase( ReportTypes.AREAS_FOR_GROWTH ), "Test Passed!", "Test Failed!!" );
            
            Map<String, Map<String, String>>  dataFromUI = afgViewerPage.getAFGSkillsDetails();
            Log.message( "dataFromUI: " + dataFromUI );
            Map<String, List<String>> getStudentsFromUI  = afgViewerPage.getStudentDetails();
            Log.message( "getStudentsFromUI: " + getStudentsFromUI );
            
            if ( !response.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = dataFromResponse;
                Log.assertThat( afgViewerPage.getAFGSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse;
                Log.assertThat( afgViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }



    @Test ( description = "Verify Skill Desciption,Level  and Strand, for Default Reading course when student is not Mastered", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGIntegrateBFF002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage afgPage = new AreaForGrowthPage( driver );
        AFGReportViewerPage afgViewerPage = new  AFGReportViewerPage( driver );
        List<String> payloadStudentIds = new ArrayList<>();
        List<String> payloadCourseIds = new ArrayList<>();
        Response response;

        Log.testCaseInfo( "Verify Skill Desciption,Level  and Strand, for Default Reading course when student is not Mastered" + browser + "]</b></i></small>" );
        try {

            for ( String courseId : assignmentIds ) {
                payloadCourseIds.add( "\"" + courseId + "\"" );
            }

            for ( String studentId : studentRumbaIds ) {
                payloadStudentIds.add( "\"" + studentId + "\"" );
            }

            Log.message( "Payload StudentID: " + payloadStudentIds );
            Log.message( "Payload CourseID: " + payloadCourseIds.toString() );

            String payload = afgPage.readJsonResponse( "TeacherAFGPayload.json");
            payload = payload.replace( "teacherUserId", teacherId )
                    .replace( "orgId",  orgId  )
                    .replace( "subjectId", "2"   )
                    .replace( "dateAtRiskValue", "10400" ) //By default Date At Risk value will be 10400
                    .replace( "groupFlag", "false" )
                    .replace( "studentIdValues", payloadStudentIds.toString() )
                    .replace( "groupIdValues", "null" )
                    .replace( "assignmentIdValues", payloadCourseIds.toString() )
                    .replace( "orderByValues", AFGReportConstants.STRAND_CAPS);
            Log.message( "Final Payload: " +  payload );

            response = afgPage.postAFGBFF( payload, teacherId, orgId, teacherUsername );
            Log.message( response.getBody().asString() );

            Map<String, Map<String, String>> dataFromResponse = afgPage.getAFGDataFromResponse( response.getBody().asString(), ReportsUIConstants.READING , Constants.READING );
            Log.message( "dataFromResponse: " + dataFromResponse );

            Map<String, List<String>> getstudentsFromResponse = afgPage.getstudentsFromResponse( response.getBody().asString(), ReportsUIConstants.READING , Constants.READING );
            Log.message( "getstudentsFromResponse: " + getstudentsFromResponse );

            //Logging in as a teacher
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Teacher: " + teacherUsername );
            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD  );

            afgPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Selecting Reading Subject
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );

            //To click the run report button 
            afgPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level  and Strand, for Default Reading course when student is not Mastered" );
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level and Strand, for Default Reading course when student is mastred" );

            Log.assertThat( afgViewerPage.reportOutputComponent.getReportPageTitle().equalsIgnoreCase( ReportTypes.AREAS_FOR_GROWTH ), "Test Passed!", "Test Failed!!" );

            Map<String, Map<String, String>>  dataFromUI = afgViewerPage.getAFGSkillsDetails();
            Log.message( "dataFromUI: " + dataFromUI );
            Map<String, List<String>> getStudentsFromUI  = afgViewerPage.getStudentDetails();
            Log.message( "getStudentsFromUI: " + getStudentsFromUI );
            
            if ( !response.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = dataFromResponse;
                Log.assertThat( afgViewerPage.getAFGSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default reading course", "Skills are not displayed properly for default reading course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse;
                Log.assertThat( afgViewerPage.getStudentDetails().entrySet().stream().allMatch( entry ->{
                    List<String> expectedValueFromBFF = studentDetails.get( entry.getKey() );
                    Collections.sort(expectedValueFromBFF);
                    return  expectedValueFromBFF.equals( entry.getValue() );
                }),"All the students are displaying properly for default reading course", "Student details are not displayed properly for default reading course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }



    @Test ( description = "Verify Skill Desciption and Strand, for Math-Custom By Settings course when student is not mastered", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGIntegrateBFF003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage afgPage = new AreaForGrowthPage( driver );
        AFGReportViewerPage afgViewerPage = new  AFGReportViewerPage( driver );
        List<String> payloadStudentIds = new ArrayList<>();
        Response response;

        Log.testCaseInfo( "Verify Skill Desciption and Strand, for Math-Custom By Settings course when student is not mastered" + browser + "]</b></i></small>" );
        try {

            String assignmentName =   contentBaseName.get(  AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ;
            Log.message( "mathSettingsAsgName: " + assignmentName );
            String mathSettingsAsgID =  assignmenNameandId.get( assignmentName );
            mathSettingsAsgID = "\"" + mathSettingsAsgID + "\"";
            mathSettingsAsgID = "[" + mathSettingsAsgID + "]";
            Log.message( "mathSettingsAsgID: " + mathSettingsAsgID );

            for ( String studentId : studentRumbaIds ) {
                payloadStudentIds.add( "\"" + studentId + "\"" );
            }

            String payload = afgPage.readJsonResponse( "TeacherAFGPayload.json");
            payload = payload.replace( "teacherUserId", teacherId )
                    .replace( "orgId",  orgId  )
                    .replace( "subjectId", "1"   )
                    .replace( "dateAtRiskValue", "10400" ) //By default Date At Risk value will be 10400
                    .replace( "groupFlag", "false" )
                    .replace( "studentIdValues", payloadStudentIds.toString() )
                    .replace( "groupIdValues", "null" )
                    .replace( "assignmentIdValues",  mathSettingsAsgID)
                    .replace( "orderByValues", AFGReportConstants.STRAND_CAPS);
            Log.message( "Final Payload: " +  payload );

            response = afgPage.postAFGBFF( payload, teacherId, orgId, teacherUsername );
            Log.message( response.getBody().asString() );

            Map<String, Map<String, String>> dataFromResponse = afgPage.getAFGDataFromResponse( response.getBody().asString(), assignmentName , Constants.MATH );
            Log.message( "dataFromResponse: " + dataFromResponse );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Teacher: " + teacherUsername );
            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD  );

            afgPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //To select the Course 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList( contentBaseName.get(  AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

            //Click Run button
            afgPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "Verify Skill Desciption and Strand, for custom by setting -Math(IP-on) course when student is not mastered" );

            Map<String, Map<String, String>>  dataFromUI = afgViewerPage.getAFGSkillsDetails();
            Log.message( "dataFromUI: " + dataFromUI );
            
            if ( !response.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = dataFromResponse;
                Log.assertThat( afgViewerPage.getAFGSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for Math-Custom By Settings course", "Skills are not displayed properly for custom by setting -Math(IP-on) course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Skill Desciption,Level  and Strand, for Reading-Custom By Settings course when student is at risk", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGIntegrateBFF004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage afgPage = new AreaForGrowthPage( driver );
        AFGReportViewerPage afgViewerPage = new  AFGReportViewerPage( driver );
        List<String> payloadStudentIds = new ArrayList<>();
        Response response;

        Log.testCaseInfo( "Verify Skill Desciption,Level  and Strand, for Reading-Custom By Settings course when student is at risk" + browser + "]</b></i></small>" );
        try {

            String assignmentName =   contentBaseName.get(  AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ;
            Log.message( "assignmentName(readSet): " + assignmentName );

            String readSettingsAsgID =  assignmenNameandId.get( assignmentName );
            readSettingsAsgID = "\"" + readSettingsAsgID + "\"";
            readSettingsAsgID = "[" + readSettingsAsgID + "]";
            Log.message( "readSettingsAsgID: " + readSettingsAsgID );

            for ( String studentId : studentRumbaIds ) {
                payloadStudentIds.add( "\"" + studentId + "\"" );
            }

            String payload = afgPage.readJsonResponse( "TeacherAFGPayload.json");
            payload = payload.replace( "teacherUserId", teacherId )
                    .replace( "orgId",  orgId  )
                    .replace( "subjectId", "2"   )
                    .replace( "dateAtRiskValue", "10400" ) //By default Date At Risk value will be 10400
                    .replace( "groupFlag", "false" )
                    .replace( "studentIdValues", payloadStudentIds.toString() )
                    .replace( "groupIdValues", "null" )
                    .replace( "assignmentIdValues",  readSettingsAsgID)
                    .replace( "orderByValues", AFGReportConstants.STRAND_CAPS);
            Log.message( "Final Payload: " +  payload );

            response = afgPage.postAFGBFF( payload, teacherId, orgId, teacherUsername );
            Log.message( response.getBody().asString() );

            Map<String, Map<String, String>> dataFromResponse = afgPage.getAFGDataFromResponse( response.getBody().asString(), contentBaseName.get(  AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), Constants.READING );
            Log.message( "dataFromResponse: " + dataFromResponse );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Teacher: " + teacherUsername );
            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD  );

            afgPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //To Select the Reading Subject
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_LABEL, Constants.READING );

            //To select the Course 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList( assignmentName ) );

            //Click Run button
            afgPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "Verify Skill Desciption and Strand, for custom by setting -Math(IP-on) course when student is not mastered" );

            Map<String, Map<String, String>>  dataFromUI = afgViewerPage.getAFGSkillsDetails();
            Log.message( "dataFromUI: " + dataFromUI );
            
            if ( !response.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = dataFromResponse;
                Log.assertThat( afgViewerPage.getAFGSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for Reading-Custom By Settings course", "Skills are not displayed properly for custom by setting -Math(IP-on) course!!!" );
                Log.testCaseResult();
            } else {
                Log.assertThat( afgViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    
    @Test ( description = "Verify Skill Desciption, Level and Strand for Math course with sort as Skill Description and Sort as 'Skill Description' and Date at Risk as '24 weeks' ", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGIntegrateBFF005() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage afgPage = new AreaForGrowthPage( driver );
        AFGReportViewerPage afgViewerPage = new  AFGReportViewerPage( driver );
        List<String> payloadStudentIds = new ArrayList<>();
        List<String> payloadCourseIds = new ArrayList<>();
        Response response;

        Log.testCaseInfo( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
        try {

            for ( String courseId : assignmentIds ) {
                payloadCourseIds.add( "\"" + courseId + "\"" );
            }

            for ( String studentId : studentRumbaIds ) {
                payloadStudentIds.add( "\"" + studentId + "\"" );
            }

            Log.message( "Payload StudentID: " + payloadStudentIds );
            Log.message( "payload CourseID: " + payloadCourseIds.toString() );


            String payload = afgPage.readJsonResponse( "TeacherAFGPayload.json");
            payload = payload.replace( "teacherUserId", teacherId )
                    .replace( "orgId",  orgId  )
                    .replace( "subjectId", "1"   )
                    .replace( "dateAtRiskValue", "24" ) //By default Date At Risk value will be 10400
                    .replace( "groupFlag", "false" )
                    .replace( "studentIdValues", payloadStudentIds.toString() )
                    .replace( "groupIdValues", "null" )
                    .replace( "assignmentIdValues", payloadCourseIds.toString() )
                    .replace( "orderByValues", AFGReportConstants.SKILL_DESCRIPTION_CAPS);
            Log.message( "Final Payload: " +  payload );

            response = afgPage.postAFGBFF( payload, teacherId, orgId, teacherUsername );
            Log.message( response.getBody().asString() );

            Map<String, Map<String, String>> dataFromResponse = afgPage.getAFGDataFromResponse( response.getBody().asString(), ReportsUIConstants.MATH, Constants.MATH );
            Log.message( "dataFromResponse: " + dataFromResponse );

            Map<String, List<String>> getstudentsFromResponse = afgPage.getstudentsFromResponse( response.getBody().asString(), ReportsUIConstants.MATH, Constants.MATH );
            Log.message( "getstudentsFromResponse: " + getstudentsFromResponse );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Teacher: " + teacherUsername );
            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD  );

            afgPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            afgPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            
//            SMUtils.logDescriptionTC( "Verify the teacher can able to view the Areas For Growth Report  in a new tab after clicking on \" Run report Button\"" );
//            SMUtils.logDescriptionTC( "Verify the Areas For Growth Report is getting loaded in a new tab when user is clicking on Run Report button in the input screen  based on selections" );
//            Log.assertThat( driver.getWindowHandles().size() ==2, "AFG report viewer page is opened in a new tab, Test passed!", "AFG report viewer page is not opened in a new tab, Test Faield:(" );

            SMUtils.logDescriptionTC( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
            Log.assertThat( afgViewerPage.getColumnHeaders().containsAll( AFGReportConstants.COLUMN_HEADERS ), "All the column headers are displaying properly", "column headers are not displaying properly!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Student, Date At Risk, Targeted Lesson columns should display under Skill Description." );
            Log.assertThat( afgViewerPage.getColumnSubHeaders().containsAll( AFGReportConstants.COLUMN_SUBHEADERS ), "All the subheaders under the skill description are displaying properly", "All the subheaders under the skill description are not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Skill Desciption, Level and Strand, when student is not mastered (Watch Closely)" );
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level and Strand, when student is At risk. " );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );

            SMUtils.logDescriptionTC( "Verify the title  of the   Areas For Growth Report  is displaying as ' report viewer '   with successmaker logo in the top left of the page" );
            Log.assertThat( afgViewerPage.reportOutputComponent.getReportPageTitle().equalsIgnoreCase( ReportTypes.AREAS_FOR_GROWTH ), "Test Passed!", "Test Failed!!" );
            
            Map<String, Map<String, String>>  dataFromUI = afgViewerPage.getAFGSkillsDetails();
            Log.message( "dataFromUI: " + dataFromUI );
            Map<String, List<String>> getStudentsFromUI  = afgViewerPage.getStudentDetails();
            Log.message( "getStudentsFromUI: " + getStudentsFromUI );
            
            if ( !response.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = dataFromResponse;
                Log.assertThat( afgViewerPage.getAFGSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse;
                Log.assertThat( afgViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify Skill Desciption, Level and Strand for Math course with sort as Skill Description and Sort as 'Skill Description' and Date at Risk as '24 weeks' ", groups = { "SMK-57894", "AFG Report Output", "AFGGridIntegration" }, priority = 1 )
    public void tcAFGIntegrateBFF006() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        AreaForGrowthPage afgPage = new AreaForGrowthPage( driver );
        AFGReportViewerPage afgViewerPage = new  AFGReportViewerPage( driver );
        List<String> payloadStudentIds = new ArrayList<>();
        List<String> payloadCourseIds = new ArrayList<>();
        Response response;

        Log.testCaseInfo( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
        try {

            for ( String courseId : assignmentIds ) {
                payloadCourseIds.add( "\"" + courseId + "\"" );
            }

            for ( String studentId : studentRumbaIds ) {
                payloadStudentIds.add( "\"" + studentId + "\"" );
            }

            Log.message( "Payload StudentID: " + payloadStudentIds );
            Log.message( "payload CourseID: " + payloadCourseIds.toString() );


            String payload = afgPage.readJsonResponse( "TeacherAFGPayload.json");
            payload = payload.replace( "teacherUserId", teacherId )
                    .replace( "orgId",  orgId  )
                    .replace( "subjectId", "1"   )
                    .replace( "dateAtRiskValue", "1" ) //By default Date At Risk value will be 10400
                    .replace( "groupFlag", "false" )
                    .replace( "studentIdValues", payloadStudentIds.toString() )
                    .replace( "groupIdValues", "null" )
                    .replace( "assignmentIdValues", payloadCourseIds.toString() )
                    .replace( "orderByValues", AFGReportConstants.LEVEL_CAPS);
            Log.message( "Final Payload: " +  payload );

            response = afgPage.postAFGBFF( payload, teacherId, orgId, teacherUsername );
            Log.message( response.getBody().asString() );

            Map<String, Map<String, String>> dataFromResponse = afgPage.getAFGDataFromResponse( response.getBody().asString(), ReportsUIConstants.MATH, Constants.MATH );
            Log.message( "dataFromResponse: " + dataFromResponse );

            Map<String, List<String>> getstudentsFromResponse = afgPage.getstudentsFromResponse( response.getBody().asString(), ReportsUIConstants.MATH, Constants.MATH );
            Log.message( "getstudentsFromResponse: " + getstudentsFromResponse );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Teacher: " + teacherUsername );
            AreaForGrowthPage dashboardPage = smLoginPage.loginToSMAsTeacher(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD  );

            afgPage = dashboardPage.reportFilterComponent.clickOnAreaForGrowthPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            afgPage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            
//            SMUtils.logDescriptionTC( "Verify the teacher can able to view the Areas For Growth Report  in a new tab after clicking on \" Run report Button\"" );
//            SMUtils.logDescriptionTC( "Verify the Areas For Growth Report is getting loaded in a new tab when user is clicking on Run Report button in the input screen  based on selections" );
//            Log.assertThat( driver.getWindowHandles().size() ==2, "AFG report viewer page is opened in a new tab, Test passed!", "AFG report viewer page is not opened in a new tab, Test Faield:(" );

            SMUtils.logDescriptionTC( "Verify the Areas for growth report table should be display with Strand,Level,Skill Description columns." );
            Log.assertThat( afgViewerPage.getColumnHeaders().containsAll( AFGReportConstants.COLUMN_HEADERS ), "All the column headers are displaying properly", "column headers are not displaying properly!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Student, Date At Risk, Targeted Lesson columns should display under Skill Description." );
            Log.assertThat( afgViewerPage.getColumnSubHeaders().containsAll( AFGReportConstants.COLUMN_SUBHEADERS ), "All the subheaders under the skill description are displaying properly", "All the subheaders under the skill description are not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Skill Desciption, Level and Strand, when student is not mastered (Watch Closely)" );
            SMUtils.logDescriptionTC( "Verify Skill Desciption,Level and Strand, when student is At risk. " );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );
            SMUtils.logDescriptionTC( "Verify targeted lession link should display for math courses" );

            SMUtils.logDescriptionTC( "Verify the title  of the   Areas For Growth Report  is displaying as ' report viewer '   with successmaker logo in the top left of the page" );
            Log.assertThat( afgViewerPage.reportOutputComponent.getReportPageTitle().equalsIgnoreCase( ReportTypes.AREAS_FOR_GROWTH ), "Test Passed!", "Test Failed!!" );
            
            Map<String, Map<String, String>>  dataFromUI = afgViewerPage.getAFGSkillsDetails();
            Log.message( "dataFromUI: " + dataFromUI );
            Map<String, List<String>> getStudentsFromUI  = afgViewerPage.getStudentDetails();
            Log.message( "getStudentsFromUI: " + getStudentsFromUI );
            
            if ( !response.getBody().asString().contains( "Report details not found" ) ) {
                Map<String, Map<String, String>> skillDetails = dataFromResponse;
                Log.assertThat( afgViewerPage.getAFGSkillsDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), skillDetails.get( entry.getKey() ) ) ),
                        "All the skills are displaying properly for default math course", "Skills are not displayed properly for default math course!!!" );

                Map<String, List<String>> studentDetails = getstudentsFromResponse;
                Log.assertThat( afgViewerPage.getStudentDetails().entrySet().stream().allMatch( entry -> SMUtils.compareTwoList( entry.getValue(), studentDetails.get( entry.getKey() ) ) ),
                        "All the students are displaying properly for default math course", "Student details are not displayed properly for default math course!!!" );

                Log.testCaseResult();
            } else {
                Log.assertThat( afgViewerPage.getZeroStateMessage().equals( "No data to display" ), "Zero State message displayed Properly. Slected filter has no data",
                        "Zero State message is not displayed Properly while the selected filter has no data" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        WebDriver chromeDriver = null;
        StudentDashboardPage studentsPage = null;
        boolean flagIsExecutionSuccessfull = false;
        try {
            for ( int i = 0; i < 3; i++ ) {
                try {
                    // Get driver
                    chromeDriver = WebDriverFactory.get( browser );
                    LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                    studentsPage = new StudentDashboardPage( chromeDriver );
                    Log.message( "Student username " + studentUserName );
                } catch ( Exception e ) {
                    Log.message( "Issue occurrred at driver creation and Login , reattempting : " + i );
                    continue;
                }
                if ( isMath ) {
                    try {
                        studentsPage.executeMathCourse( studentUserName, courseName, "0", "2", "180" );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                } else {
                    try {
                        studentsPage.executeReadingCourse( studentUserName, courseName, "2", "2", "55" );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                }
            }
        } finally {
            if ( flagIsExecutionSuccessfull ) {
                Log.message( "Course executed successfully" );
            } else {
                Log.message( "Course execution failed after reattempting : 3" );
            }
            chromeDriver.quit();

        }

    }
}