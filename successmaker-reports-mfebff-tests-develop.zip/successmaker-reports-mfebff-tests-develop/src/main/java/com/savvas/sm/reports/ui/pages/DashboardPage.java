package com.savvas.sm.reports.ui.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

public class DashboardPage extends LoadableComponent<DashboardPage> {

	private final WebDriver driver;
	boolean isPageLoaded;
	public ReportFilterComponent reportFilterComponent;
	
	// ********* SuccessMaker Launcher/Login Page Elements ***************

	@FindBy ( tagName = "h1" )
	WebElement pageTitle;

	@FindBy ( css = "p.description" )
	WebElement description;

	@FindBy (css = "cel-button.pr-2")
	WebElement runReportButtonRoot;

	/**
	 * 
	 * Constructor class for Login page Here we initializing the driver for page
	 * factory objects.
	 * 
	 * @param driver
	 * @param url
	 */
	public DashboardPage( WebDriver driver ) {
		this.driver = driver;
		PageFactory.initElements( driver, this );
		reportFilterComponent = new ReportFilterComponent( driver );
	}


	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForElement( driver, description );

	}

	@Override
	protected void isLoaded() throws Error {
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 30 );
		} catch ( InterruptedException e ) {
			Log.message( "Issue in Spinner Loading" );
		}
		if ( SMUtils.waitForElement( driver, description, 30 ) ) {
			Log.message( "Area For Growth Input Page loaded successfully." );
		} else {
			Log.fail( "Area For Growth Input Page not loaded successfully." );
		}

	}


}














