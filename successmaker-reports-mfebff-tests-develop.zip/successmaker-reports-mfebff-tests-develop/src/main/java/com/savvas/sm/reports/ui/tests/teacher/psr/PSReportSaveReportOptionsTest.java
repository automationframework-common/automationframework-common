package com.savvas.sm.reports.ui.tests.teacher.psr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.teacher.PrescriptiveSchedulingPage;
import com.savvas.sm.reports.ui.pages.teacher.SaveReportFilterPopup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

public class PSReportSaveReportOptionsTest extends EnvProperties {
	private String smUrl;
	private String browser;
	private String username;
	private String teacherDetails;
	private String teacherId;
	public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

	@BeforeClass
	public void initTest() throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID);

		HashMap<String, String> courseIds = new HashMap<>();
		courseIds.put(Constants.MATH, AssignmentAPIConstants.MATH);
		courseIds.put(Constants.READING, AssignmentAPIConstants.READING);
		String studentDetail = RBSDataSetup.getMyStudent(school, username);

		HashMap<String, String> staffDetails = new HashMap<>();
		staffDetails.put(AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get(school));
		staffDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID));
		staffDetails.put(RBSDataSetupConstants.BEARER_TOKEN,
				new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD));

		HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl, staffDetails,
				new ArrayList<>(
						Arrays.asList(SMUtils.getKeyValueFromResponse(studentDetail, RBSDataSetupConstants.USERID))),
				new ArrayList<>(courseIds.values()));
		Log.message(assignmentResponse.toString());
	}

	@Test(description = "Verify 'Save Report Option' button in PS report page", groups = { "Smoke", "SMK-66747",
			"SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions001() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions001: Verify the user can navigates to PS Report page <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.logDescriptionTC("Verify 'Save Report Option'  button in PS report page");

			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getLabelFromSaveReportOptionButton()
							.equalsIgnoreCase(ReportsUIConstants.SAVE_REPORT_OPTIONS),
					"The save report option is displayed in PS report",
					"The save report option is not displayed in CPA report");
			Log.assertThat(!prescriptiveschedulingPage.reportFilterComponent.isSaveReportButtonEnabled(),
					"Save report option button is disabled as default",
					"Save report option button is not disabled as default");
			Log.testCaseResult();

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();

			SMUtils.logDescriptionTC(
					"Verify user can click the 'Save Report Option' button in CPR aggregate report page");
			SMUtils.logDescriptionTC("Verify all available fields in 'Save Report Option Popup.");
			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);
			Log.assertThat(
					saveReportOptionPopup.getLabelForNewCustomReportConfiguration()
							.equalsIgnoreCase(ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL),
					"New Report configuration label is displayed properly",
					"New Report configuration label is not displayed properly! Expected - "
							+ ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - "
							+ saveReportOptionPopup.getLabelForNewCustomReportConfiguration());
			Log.assertThat(
					saveReportOptionPopup.getLabelForExistingReportConfiguration()
							.equalsIgnoreCase(ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL),
					"New Report configuration label is displayed properly",
					"New Report configuration label is not displayed properly! Expected - "
							+ ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - "
							+ saveReportOptionPopup.getLabelForExistingReportConfiguration());
			Log.assertThat(saveReportOptionPopup.isSaveButtonDisplayed(),
					"Save Button is displayed in saved report popup",
					"Save Button is not displayed in saved report popup");
			Log.assertThat(saveReportOptionPopup.isCancelButtonDisplayed(),
					"Cancel Button is displayed in saved report popup",
					"Cancel Button is not displayed in saved report popup");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("Verify if click the save button with empty Name in 'Save Report Option' Popup.");
			Log.assertThat(!saveReportOptionPopup.isSaveButtonEnabled(),
					"Save button is disabled if the user is not entered name in the text box",
					"Save button is not disabled if the user is not entered name in the text box");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify user can able to cancel the in 'Save Report Option ' Popup on PS report page.");
			saveReportOptionPopup.clickCancelButton();
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isReportTitleDisplayed(),
					"The Save Report poup closed properly", "issue in closing the popup");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("Verify User can able to save the report option with new name.");
			SMUtils.logDescriptionTC("Verify User can able to save the report option with default Optional filters.");
			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify If User enter more than 50 characters in new custom report configuration text box.");
			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(ReportsUIConstants.LENGTHY_NAME);
			Log.assertThat(
					saveReportOptionPopup.getErrorMessage()
							.equalsIgnoreCase(ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE),
					"Error Message displayed properly for name exceed maximum length",
					"Error Message is not displayed properly for name exceed maximum length");

			SMUtils.logDescriptionTC("Verify User can able to click the close button in save report option");
			saveReportOptionPopup.clickCloseIcon();
			Log.assertThat(prescriptiveschedulingPage.reportFilterComponent.isReportTitleDisplayed(),
					"The Save Report poup closed properly", "issue in closing the popup");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify if click the save button with already existing name in 'Save Report Option' Popup.");
			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)", groups = {
			"Smoke", "SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions002() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions002: Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.MATH);
			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)");
			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Current course Level(Mean)\" in sort Dropdowm with display on PS Report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Current Course Level");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading)");
			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Time Spent(Mean)' in sort Dropdown with display on PS Report and load the report");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList(ReportsUIConstants.ALL));
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList(ReportsUIConstants.ALL));

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Add`l Sessions To Target");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with single options in all required and optional filters with Subject (Math)");
			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Total Sessions(Mean)' in sort Dropdown with display on PS Report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Add`l Time To Target");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with 'Grade' option in Additional Grouping 'IP Level\" in sort Dropdown with display on PS report and load the report", groups = {
			"SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions003() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions003: Verify User can able to save the report option with 'Grade' option in Additional Grouping 'IP Level(Mean)\" in sort Dropdown with display on PS report and load the report)<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.MATH);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping 'IP/Start Level\" in sort Dropdown with display on PS report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "IP/Start Level");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Add`l Time To Target' in sort Dropdown with display on PS Report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Add`l Time To Target");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping and 'Add`l Min/Day To Target' in sort Dropdown with display on PS Report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Add`l Min/Day To Target");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with 'Recent % of Skills Mastered' in sort Dropdown ", groups = {
			"SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions004() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions004:Verify User can able to save the report option with 'Recent % of Skills Mastered' in sort Dropdown <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.MATH);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping 'Recent % of Skills Mastered\" in sort Dropdown with display on PS report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.SORT_LABEL, "Recent % of Skills Mastered");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with 'Current Learning Rate' in sort Dropdown ", groups = {
			"SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions005() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions005:Verify User can able to save the report option with 'Current Learning Rate' in sort Dropdown <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.MATH);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade Then Group' option in Additional Grouping 'Current Learning Rate\" in sort Dropdown with display on PS report and load the report");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade Then Group");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Current Learning Rate");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Existing custom report configuration dropdown if the user does not have already saved options", groups = {
			"Smoke", "SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 1)
	public void tcPSReportSaveReportOptions006() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions006: Verify the Existing custom report configuration dropdown if the user does not have already saved options<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.MATH);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify the Existing custom report configuration dropdown if the user does not have already saved options");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			Log.assertThat(!saveReportOptionPopup.isExistingReportOptionDropdownEnabled(),
					"Existing custom report configuration dropdown is disabled if the user does not have already saved options",
					"Existing custom report configuration dropdown is not  disabled if the user does not have already saved options");
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with 'Reading' in subject dropdown and 'Recent % of Skills Mastered' in sort Dropdown ", groups = {
			"SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions007() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions007:Verify User can able to save the report option with 'Recent % of Skills Mastered' in sort Dropdown <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.READING);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade Then Group' option in Additional Grouping 'Recent % of Skills Mastered\" in sort Dropdown with display on PS report and load the report");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade Then Group");
			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.SORT_LABEL, "Recent % of Skills Mastered");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with 'Reading' in subject dropdown and 'Student' in sort Dropdown ", groups = {
			"SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions008() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions008:Verify User can able to save the report option with 'Student' in sort Dropdown <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.READING);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping 'Student\" in sort Dropdown with display on PS report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Student");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify User can able to save the report option with 'Math' in subject dropdown and 'Average Min/Day' in sort Dropdown ", groups = {
			"SMK-66747", "SaveReportOption", "PSReportSaveReportOption" }, priority = 2)
	public void tcPSReportSaveReportOptions009() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcPSReportSaveReportOptions009:Verify User can able to save the report option with 'Average Min/Day' in sort Dropdown <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);

			dashBoardPage.reportFilterComponent.clickOnPrescriptiveSchedulingPage();
			PrescriptiveSchedulingPage prescriptiveschedulingPage = new PrescriptiveSchedulingPage(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			prescriptiveschedulingPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL, ReportsUIConstants.READING);

			prescriptiveschedulingPage.selectTargetDateAsCurrentDate();
			prescriptiveschedulingPage.fillTargetLevels("Grade K", "0.8");

			SMUtils.logDescriptionTC(
					"Verify User can able to save the report option with 'Grade' option in Additional Grouping 'Average Min/Day\" in sort Dropdown with display on PS report and load the report");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade");
			prescriptiveschedulingPage.reportFilterComponent
					.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, "Average Min/Day");

			prescriptiveschedulingPage.reportFilterComponent.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					prescriptiveschedulingPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
}
