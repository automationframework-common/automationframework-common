package com.savvas.sm.reports.bff.admin.tests;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicValues;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

import io.restassured.response.Response;

public class CPRReportAdminGraphQLTest extends EnvProperties {

    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String studentId;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;
    String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
    String mathId;
    String readingId;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 1 ).toString(), "groupId" );
        studentId = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[1].toString();
        studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );
        studentAssignmentIdReading = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        // School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );

    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "P1", "Admin CPR Report Graphql" } )
    public void getAdminCPRReport_Positive( String tcId, String description, String statusCode, String scenario ) throws Exception {
        String responseStatusCode = "";
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        mathId = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];

        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.READING, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getAdminCPReportData,orgData" ) ).get( 0 ).toString(), "courseName" );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.READING ), "Subject is displayed as Reading", "Subject is not displayed as Reading" );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                break;

            case "SUB_DISTRICT_ADMIN":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                response = getCPRReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getAdminCPReportData,orgData" ) ).get( 0 ).toString(), "courseName" );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Subject is displayed as Math", "Subject is not displayed as Math" );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );

                break;

            case "SCHOOL_ADMIN":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                response = getCPRReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = getKeyValueFromResponseWithArray( new JSONArray( getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getAdminCPReportData,orgData" ) ).get( 0 ).toString(), "courseName" );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Subject is displayed as Math", "Subject is not displayed as Math" );

                break;

            case "FILTER_BY_SINGLE_VALUE":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02" );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_VALUE":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02,02" );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_TEACHER":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                // Additional Grouping by Teacher
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_GRADE":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                // Additional Grouping by Grade
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_GROUP":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                // Additional Grouping by Group
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                /*
                 * filterByValues.put( DemographicFilters.ETHNICITY,
                 * DemographicValues.NOT_SPECIFIED ); filterByValues.put(
                 * DemographicFilters.SPECIAL_SERVICES,
                 * DemographicValues.NOT_SPECIFIED ); filterByValues.put(
                 * DemographicFilters.DISABILITY_STATUS,
                 * DemographicValues.NOT_SPECIFIED ); filterByValues.put(
                 * DemographicFilters.SOCIO_STATUS,
                 * DemographicValues.NOT_SPECIFIED ); filterByValues.put(
                 * DemographicFilters.ENGLISH_PROFICIENCY,
                 * DemographicValues.NOT_SPECIFIED ); filterByValues.put(
                 * DemographicFilters.MIGRANT_STATUS,
                 * DemographicValues.NOT_SPECIFIED );
                 */

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "STUDENT PERFORMANCE DATES":

                //Filter by course list
                filterByValues.put( "{courseList}", mathId );

                // Filter by Date
                filterByValues.put( "{AllDates}", "true" );

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );

                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;

                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentAssignmentIdMath ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

        }

        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );

        Log.testCaseResult();

    }

    @DataProvider ( name = "PositiveScenarios" )
    public Object[][] testScenario() {

        Object[][] inputData = { { "tc_CPR_BFF_001", "Verify the 200 status code and valid reponse for the district admin credentia", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },
                { "tc_CPR_BFF_002", "Verify the 200 status code and valid reponse for the subdistrict admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT_ADMIN" },
                { "tc_CPR_BFF_003", "Verify the 200 status code and valid reponse for the school admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },
                { "tc_CPR_BFF_004", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with single Teacher, Grade and Group", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_VALUE" },
                { "tc_CPR_BFF_005", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with multiple Teachers, Grades and Groups", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_VALUE" },
                { "tc_CPR_BFF_006", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Teacher", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_TEACHER" },
                { "tc_CPR_BFF_007", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Grade", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GRADE" },
                { "tc_CPR_BFF_008", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Group", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GROUP" },
                { "tc_CPR_BFF_009", "Verify the 200 Status code and the output response when passing single values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE" },
                { "tc_CPR_BFF_010", "Verify the 200 Status code and the output response when passing multiple values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE" },
                { "tc_CPR_BFF_011", "Verify the 200 Status code and the output response when passing student performance all date value filters", CommonAPIConstants.STATUS_CODE_OK, "STUDENT PERFORMANCE DATES" },

        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "NegativeScenarios", groups = { "P2", "Admin CPR Report Graphql" } )
    public void getAdminCPRReport_Negative( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        switch ( scenario ) {

            case "INVALID_ACCESS_TOKEN":

                response = getCPRReport( distAdminUserName + "INVALID", password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_ORG_ID":

                response = getCPRReport( distAdminUserName, password, distAdminuserId, distId + "INVALID", selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "INVALID_USER_ID":

                response = getCPRReport( distAdminUserName, password, distAdminuserId + "INVALID", distId, selectedSchoolId, Constants.MATH, filterByValues );
                break;

            case "EMPTY_ORG_ID":

                response = getCPRReport( distAdminUserName, password, distAdminuserId, "", selectedSchoolId, Constants.READING, filterByValues );
                break;

            case "EMPTY_USER_ID":

                response = getCPRReport( distAdminUserName, password, "", distId, selectedSchoolId, Constants.READING, filterByValues );
                break;
        }

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.UNAUTHORIZED_MESSAGE + " Message not displayed as expected" );
        } else {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message displayed as expected",
                    ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message not displayed as expected" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "NegativeScenarios" )
    public Object[][] testNegativeScenario() {

        Object[][] inputData = { { "tc_CPR_BFF_012", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPR_BFF_013", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPR_BFF_014", "Verify  401: UnAuthorized  and response when invalid userId is given in the query ", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPR_BFF_015", "Verify the message in the response when organizationId passed as empty array. ", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_CPR_BFF_016", "Verify the message in the response when invalid subject type passed in the query.", "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "P1", "Admin CPR Report Graphql", "smoke_test_case" } )
    public void getAdminCPRReport_SchemaValidation( String tcId, String description, String statusCode, String scenario ) throws Exception {
        String responseStatusCode = "";
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        mathId = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
            String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
            return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
        } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" ).split( "," )[0];
        try {
            switch ( scenario ) {

                case "DISTRICT_ADMIN":

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.READING, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.READING, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SUB_DISTRICT_ADMIN":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );
                    response = getCPRReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SCHOOL_ADMIN":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );
                    response = getCPRReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_VALUE":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "07" );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_VALUE":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "02,02" );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_TEACHER":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    // Additional Grouping by Teacher
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GRADE":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    // Additional Grouping by Grade
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GROUP":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    // Additional Grouping by Group
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "STUDENT PERFORMANCE DATES":

                    //Filter by course list
                    filterByValues.put( "{courseList}", mathId );

                    // Filter by Date
                    filterByValues.put( "{AllDates}", "true" );

                    response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = getCPRReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }

                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "CPR_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;
            }
        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( response, "CPR" );
        }

        Log.testCaseResult();

    }

    /**
     * To validate response data with DB
     * 
     * @param responseBody
     * @param stdId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public boolean validateResponseDataWithDB( String responseBody, String mathAssignmentUserId ) {
        Boolean validation;
        if ( response.getBody().asString().contains( "INTERNAL_SERVER_ERROR" ) ) {
            Log.message( "INTERNAL_SERVER_ERROR - Reponse data is null" );
            validation = true;
        } else {
            // Get data from response
            HashMap<String, HashMap<String, String>> dataFromResponse = getDataFromResponse( responseBody, mathAssignmentUserId );
            Log.message( "Data response - " + dataFromResponse );

            Map<String, Map<String, String>> dataFromDB = getDataFromDB( mathAssignmentUserId );
            Log.message( "DB response - " + dataFromDB );
            validation = dataFromResponse.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), dataFromDB.get( entry.getKey() ) ) );
        }

        return validation;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromResponse( String responseBody, String assignmentId ) {
        // Getting data from response
        String jsonObj1 = getKeyValueFromResponseWithArray( responseBody, "data,getAdminCPReportData" );
        String orgData = getKeyValueFromResponseWithArray( jsonObj1, "orgData" );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();

        IntStream.range( 0, new JSONArray( orgData ).length() ).forEach( iter -> {
            String students = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( orgData ).get( iter ).toString(), "studentRows" );

            try {
                IntStream.range( 0, new JSONArray( students ).length() ).forEach( itr -> {
                    String usage = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "usage" );
                    HashMap<String, String> studentReport = new HashMap<>();
                    JSONObject usageJson = new JSONObject( usage );
                    studentReport.put( "timeSpent", usageJson.get( "timeSpent" ).toString() );
                    studentReport.put( "totalSessions", usageJson.get( "totalSessions" ).toString() );

                    String instructionalPerformance = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "instructionalPerformance" );
                    JSONObject instructionJson = new JSONObject( instructionalPerformance );

                    String studentsData = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "levelData" );

                    JSONObject stdJson = new JSONObject( studentsData );

                    studentReport.put( "currentCourseLevel", String.valueOf( Double.parseDouble( new DecimalFormat( "0.0" ).format( Double.valueOf( stdJson.get( "currentCourseLevel" ).toString() ) ) ) ) );

                    String gain = String.valueOf( Math.abs( Double.parseDouble( new DecimalFormat( "0.00" ).format( Double.valueOf( stdJson.get( "gain" ).toString() ) ) ) ) );

                    studentReport.put( "gain", gain );

                    String mastery = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "mastery" );
                    JSONObject masteryJson = new JSONObject( mastery );

                    studentReportDetails.put( gain, studentReport );
                } );
            } catch ( Exception e ) {
                e.printStackTrace();
            }
        } );
        Log.message( "Response Data: " + studentReportDetails );
        return studentReportDetails;
    }

    /**
     * This method used to fetch report data from CP grapphql
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues - pass the optional filter values in HashMap
     * @return
     * @throws Exception
     */
    public static Response getCPRReport( String username, String password, String userId, String userOrgId, String schoolId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload
        String payLoad = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getAdminCPReportData(\\n    organizationId: \\\"%s\\\"\\n    userId: \\\"%s\\\"\\n    filterParams: {subject: \\\"%s\\\", courseList: [{courseList}], additionalGrouping: {additionalGroupId}, filterByGroup: [{groupId}], filterByGrade: [{grade}], filterByTeacher: [{teacherId}], filterBySchool: [\\\"%s\\\"], filterByDemographics: {disabilityStatus: [{disabilityStatus}], englishLanguageProficiency: [{language}], gender: [{gender}], migrantStatus: [{migrantStatus}], race: [{race}], ethnicity: [{ethnicity}], socioeconomicStatus: [{socioStatus}], specialServices: [{specialServices}]}, isAllDates: {AllDates}}\\n  ) {\\n    reportRun\\n    startDate\\n    endDate\\n    orgData {\\n      orgId\\n      organizationName\\n      courseName\\n      teacherName\\n      grade\\n      groupName\\n      studentRows {\\n        studentName\\n        studentFirstName\\n        studentMiddleName\\n        studentLastName\\n        studentUsername\\n        studentID\\n        levelData {\\n          assignedCourseLevel\\n          currentCourseLevel\\n          ipLevel\\n          gain\\n          ipmEndLevel\\n          ipmStatusID\\n          ipmDoneInRange\\n          contentTypeBaseID\\n          formattedCurrentCourseLevel\\n          formattedIpLevel\\n          formattedGain\\n          __typename\\n        }\\n        usage {\\n          timeSpent\\n          totalSessions\\n          __typename\\n        }\\n        instructionalPerformance {\\n          exercisesCorrect\\n          exercisesAttempted\\n          exercisesPercentCorrect\\n          __typename\\n        }\\n        mastery {\\n          skillsAssessed\\n          skillsMastered\\n          skillsPercentMastered\\n          formattedSkillsAssessed\\n          formattedSkillsMastered\\n          formattedSkillsPercentMastered\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}";
        payLoad = String.format( payLoad, userOrgId, userId, subject, schoolId );
        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().equals( ReportFilters.ADDITIONAL_GROUP_ID_VALUE ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
            } // payload in number format
            else if ( values.getKey().equals( "{AllDates}" ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() + ", startDate: \\\"%s\\\", endDate: \\\"%s\\\"" );
                payLoad = String.format( payLoad, getDate( 0 ), getDate( 30 ) );
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in                                                                                            // payload in string                                                                                            // format
            }
        }
        payLoad = payLoad.replace( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "0" ).replace( DemographicFilters.DISABILITY_STATUS, "" ).replace( DemographicFilters.ENGLISH_PROFICIENCY, "" ).replace( DemographicFilters.GENDER, "" ).replace(
                DemographicFilters.MIGRANT_STATUS, "" ).replace( DemographicFilters.RACE, "" ).replace( DemographicFilters.ETHNICITY, "" ).replace( DemographicFilters.SOCIO_STATUS, "" ).replace( DemographicFilters.SPECIAL_SERVICES, "" ).replace(
                        ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( ReportFilters.GROUP_ID_VALUE, "" ).replace( "{courseList}", "" ).replace( "{AllDates}", "false" );
        Log.message( "Headers :" + headers );
        Log.message( "Payload : " + payLoad );

        // Getting CP report response
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     * 
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray( String response, String path ) {
        String[] json_Array = path.split( "," );
        String keyValue = null;
        try {

            if ( json_Array.length <= 1 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                return JsonArrayValue;
            } else if ( json_Array.length == 2 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                keyValue = jsonObj1.get( json_Array[1] ).toString();
                return keyValue;
            } else if ( json_Array.length == 3 ) {
                JSONObject jsonObj = new JSONObject( response );
                String JsonArrayValue = jsonObj.get( json_Array[0] ).toString();
                JSONObject jsonObj1 = new JSONObject( JsonArrayValue );
                String JsonArrayValue2 = jsonObj1.get( json_Array[1] ).toString();
                JSONObject jsonObj2 = new JSONObject( JsonArrayValue2 );
                keyValue = jsonObj2.get( json_Array[2] ).toString();
                //return keyValue;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return keyValue;
        }
        return keyValue;
    }

    /**
     * To verify the schema of the response
     * 
     * @param serviceName
     * @param statusCode
     * @param response
     * @return
     * @throws IOException
     */
    public boolean isSchemaValid( String serviceName, String statusCode, String response ) throws IOException {
        return new SMAPIProcessor().isSchemaValid( serviceName, statusCode, response );
    }

    /**
     * This method is used to get values from DB
     * 
     * @param mathAssignmentIds
     * @return
     */
    public Map<String, Map<String, String>> getDataFromDB( String mathAssignmentIds ) {
        Map<String, Map<String, String>> valuesFromDB = new HashMap<>();
        String query = "SELECT CAST (AVG (CASE WHEN (au.assignment_current_level is null)\r\n" + "THEN au.assignment_current_level\r\n" + "                                 WHEN au.ipm_status_id != 3\r\n" + "THEN null\r\n"
                + "ELSE least(au.assignment_current_level, 8.95)\r\n" + "END) as numeric(10,2)) as currentCourseLevel,\r\n" + "                \r\n" + "                CAST (AVG (CASE WHEN au.ipm_status_id != 3\r\n" + "THEN null\r\n"
                + "ELSE au.ipm_end_level\r\n" + "                END) as numeric(10,2)) as ipmEndLevel,\r\n" + "                \r\n" + "CAST (Avg (CASE WHEN (au.assignment_current_level is null)\r\n"
                + "                                         THEN au.assignment_current_level\r\n" + "                                 WHEN au.ipm_status_id != 3\r\n" + "                                         THEN null\r\n"
                + "                                 ELSE least(au.assignment_current_level, 8.95)\r\n" + "                END - CASE WHEN au.ipm_status_id != 3\r\n" + "                                    THEN null\r\n"

                + "                     ELSE au.ipm_end_level\r\n" + "                END) as numeric(10,2)) as gain,\r\n" + "                CAST(AVG(msh.total_session_min) as numeric(10,2)) as Time_Spent,\r\n" + "                \r\n"
                + "                CAST(AVG(session_presented_count) as numeric(10,2)) as Total_Sessions,\r\n" + "                \r\n" + "                CAST(AVG(CASE WHEN au.ipm_status_id = 3\r\n"
                + "                                            THEN msh.total_correct - COALESCE(msh.ipm_correct, 0)\r\n" + "                                        ELSE msh.total_correct\r\n"
                + "                                                END)as numeric(10,2)) AS totalExercisesCorrect,\r\n" + "                        \r\n" + "                CAST(AVG(CASE WHEN au.ipm_status_id = 3\r\n"
                + "                                            THEN msh.total_attempts - COALESCE(msh.ipm_attempts, 0)\r\n" + "                                        ELSE msh.total_attempts\r\n"
                + "                                            END)as numeric(10,2)) AS totalExercisesAttempted,\r\n" + "                                                \r\n" + "                CAST(AVG((CASE WHEN au.ipm_status_id = 3\r\n"
                + "                                            THEN msh.total_attempts - COALESCE(msh.ipm_attempts, 0)\r\n" + "                                        ELSE msh.total_attempts\r\n"
                + "                                            END  /CASE WHEN au.ipm_status_id = 3\r\n" + "                                            THEN msh.total_correct - COALESCE(msh.ipm_correct, 0)\r\n"
                + "                                        ELSE msh.total_correct\r\n" + "                                                END) *100 ) as numeric(10,2)) AS percentCorrected,\r\n" + "                \r\n"
                + "CAST (AVG (CASE WHEN au.ipm_status_id != 3\r\n" + "THEN null\r\n" + "ELSE msh.total_lo_passed\r\n" + "END) as numeric(10,2)) as skillMastered,\r\n" + "\r\n" + "\r\n" + "\r\n" + "CAST (AVG (CASE WHEN au.ipm_status_id != 3\r\n"
                + "THEN null\r\n" + "ELSE msh.total_lo_completed\r\n" + "END) as numeric(10,2)) as skillAssessed,\r\n" + "\r\n" + "\r\n" + "\r\n" + "CAST (AVG ( CASE WHEN (au.ipm_status_id != 3 OR msh.total_lo_passed = 0)\r\n" + "THEN null\r\n"
                + "ELSE (msh.total_lo_completed *100 ) /msh.total_lo_passed\r\n" + "END ) as numeric(10,2)) as percentMastered\r\n" + "\r\n" + "\r\n" + "\r\n" + "FROM assignment_user au,\r\n" + "math_assignment_history msh\r\n"
                + "WHERE au.assignment_user_id IN (" + mathAssignmentIds + ")\r\n" + "AND msh.assignment_user_id = au.assignment_user_id";

        List<Object[]> rowList = SQLUtil.executeQuery( query );
        rowList.forEach( object -> {

            Map<String, String> values = new HashMap<>();

            values.put( "currentCourseLevel", new DecimalFormat( "0.0" ).format( Double.valueOf( object[0].toString() ) ) );
            values.put( "gain", object[2].toString() );
            values.put( "timeSpent", String.valueOf( (int) Double.parseDouble( object[3].toString() ) ) );
            values.put( "totalSessions", String.valueOf( (int) Double.parseDouble( object[4].toString() ) ) );
            valuesFromDB.put( object[2].toString(), values );

        } );

        return valuesFromDB;
    }

    /**
     * get date
     * 
     * @param day
     * @return
     */
    public static String getDate( int day ) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
        LocalDate date = LocalDate.now().plusDays( day );
        String targetDate = formatter.format( date );
        return targetDate;
    }
    
    /**
     * To get data from given response for UI validation
     * 
     * @param responseBody
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromResponseForVerification( String responseBody ) {
        // Getting data from response
        String jsonObj1 = getKeyValueFromResponseWithArray( responseBody, "data,getAdminCPReportData" );
        String orgData = getKeyValueFromResponseWithArray( jsonObj1, "orgData" );

        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();

        IntStream.range( 0, new JSONArray( orgData ).length() ).forEach( iter -> {
            String students = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( orgData ).get( iter ).toString(), "studentRows" );
            
            String subject = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( orgData ).get( iter ).toString(), "courseName" );
            if ( subject.equalsIgnoreCase( "Math" )|| subject.equalsIgnoreCase( "Reading" ) ) {
                try {
                    IntStream.range( 0, new JSONArray( students ).length() ).forEach( itr -> {
                        String studentName =SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "studentName" );
                        String usage = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "usage" );
                        HashMap<String, String> studentReport = new HashMap<>();
                        JSONObject usageJson = new JSONObject( usage );
                        studentReport.put( "totalSessions", usageJson.get( "totalSessions" ).toString() );

                        String instructionalPerformance = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "instructionalPerformance" );
                        JSONObject instructionJson = new JSONObject( instructionalPerformance );
                        studentReport.put( "exercisesCorrect",instructionJson.get( "exercisesCorrect" ).toString().contains( "null" ) || instructionJson.get( "exercisesCorrect" ).toString().contains( "0" ) ? "NA" : instructionJson.get( "exercisesCorrect" ).toString() );
                        studentReport.put( "exercisesAttempted", instructionJson.get( "exercisesAttempted" ).toString().contains( "null" ) || instructionJson.get( "exercisesAttempted" ).toString().contains( "0" ) ? "NA" : instructionJson.get( "exercisesAttempted" ).toString() );

                        String studentsData = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( students ).get( itr ).toString(), "levelData" );

                        JSONObject stdJson = new JSONObject( studentsData );

                        studentReport.put( "currentCourseLevel", stdJson.get( "formattedCurrentCourseLevel" ).toString() );

                        studentReportDetails.put( studentName, studentReport );
                    } );
                } catch ( Exception e ) {
                    e.printStackTrace();
                }
            }        
        } );
        Log.message( "Response Data: " + studentReportDetails );
        return studentReportDetails;
    }
}