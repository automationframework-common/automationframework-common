package com.savvas.sm.reports.ui.tests.teacher.afg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.admin.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsFilterUtils;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.teacher.ui.pages.ReportNavigation;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.reports.util.JSONParserUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class AFGTeacherReportTest extends EnvProperties {

	private String smUrl;
	private String browser;
	private String sessionCookie;
	private static String username = null;
	String userId;
	private String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String teacherDetails;
	private String studentLastName;
	public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	ReportComponents reportComponents;
	ReportNavigation reportnav;
	String teacherUsername;
	String orgId;
	String endPoint;
	String teacherStaffId;
	String studentDetailsSchool1;
	String courseId;
	String studentDetails;
	String studentIdOne;
	String studentIdTwo;
	HashMap<String, String> assignmentDetails = new HashMap<>();
	String districtId;
	String studentThreeDetails;
	String studentFourDetails;
	String studentFiveDetails;
	String studentIdThree;
	String studentIdFour;
	String studentIdFive;
	String studentTwoDetail;
	List<String> studentRumbaIds = new ArrayList<>();
	Map<String, String> courseIDs = new HashMap<>();
	Map<String, String> contentBase = new HashMap<>();
	HashMap<String, String> courseName = new HashMap<>();
	String assignmentId;
	String firstMathAssignmentUserId;
	String secondMathAssignmentUserId;
	List<String> mathAssignmentUserId = new ArrayList<>();
	private HashMap<String, String> groupDetails = new HashMap<>();
	AreaForGrowthPage dashBoardPage;
	private String configGraphQL;
	DevTools tools = null;

	@BeforeClass(alwaysRun = true)
	public void initTest() throws Exception, IOException {

		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		configGraphQL = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";

		districtId = configProperty.getProperty("district_ID");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, "userName");
		userId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdOne = SMUtils.getKeyValueFromResponse(studentDetails, "userId");

		studentTwoDetail = RBSDataSetup.getMyStudent(school, username);
		studentIdTwo = SMUtils.getKeyValueFromResponse(studentTwoDetail, "userId");

		studentThreeDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdThree = SMUtils.getKeyValueFromResponse(studentThreeDetails, "userId");

		studentFourDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdFour = SMUtils.getKeyValueFromResponse(studentFourDetails, "userId");

		studentFiveDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdFive = SMUtils.getKeyValueFromResponse(studentFiveDetails, "userId");

		orgId = new RBSUtils().getOrganizationIDByName(districtId, school);

		studentRumbaIds.add(studentIdOne);
		studentRumbaIds.add(studentIdTwo);
		studentRumbaIds.add(studentIdThree);
		studentRumbaIds.add(studentIdFour);
		studentRumbaIds.add(studentIdFive);

		contentBase.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH);
		contentBase.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING);

		courseName.put(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE,
				String.format(DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
				String.format(DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
				String.format(DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime()));

		courseIDs.put(Constants.MATH, AssignmentAPIConstants.MATH);
		courseIDs.put(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS,
						courseName.get(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse(
				smUrl, new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
				DataSetupConstants.MATH, userId, orgId, courseName.get(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD,
						courseName.get(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL,
						courseName.get(Constants.CUSTOM_BY_SKILLS_MATH_COURSE)));

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, userId);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));

		HashMap<String, String> mathAssignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, Arrays.asList(studentRumbaIds.get(0)), new ArrayList<>(courseIDs.values()));

		Log.message(mathAssignmentResponse.get("body"));

		// Getting assignment id
		JSONObject mathAssignmentDetailsJson = new JSONObject(mathAssignmentResponse.get(Constants.REPORT_BODY));
		JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray(Constants.DATA);
		JSONObject mathAssignmentInfo = new JSONObject(mathAssignmentList.get(0).toString());

		assignmentId = mathAssignmentInfo.get("assignmentId").toString();
		mathAssignmentUserId.add(new SqlHelperCourses().getAssignmentUserId(studentRumbaIds.get(0), assignmentId));

		courseName.put(Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
				String.format(DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
				String.format(DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SKILLS_READING_COURSE,
				String.format(DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime()));

		courseIDs.put(Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId, DataSetupConstants.SETTINGS,
						courseName.get(Constants.CUSTOM_BY_SETTINGS_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
				new CourseAPI().createCustomBySettingIPMOnCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId,
						courseName.get(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId, DataSetupConstants.STANDARD,
						courseName.get(Constants.CUSTOM_BY_STANDARDS_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SKILLS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userId, orgId, DataSetupConstants.SKILL,
						courseName.get(Constants.CUSTOM_BY_SKILLS_READING_COURSE)));

		HashMap<String, String> readingAssignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, studentRumbaIds, new ArrayList<>(courseIDs.values()));

		Log.message(readingAssignmentResponse.get("body"));

	}

	@Test(description = "Verify Areas For Growth Report should display under Reports menu.", groups = { "SMK-66757",
			"reports", "Areasforgrowth" }, priority = 1)
	public void tcSM_AFG001() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG001: Verify Area for Growth Report (AFG) should display under Reports menu<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page

			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);
			Log.message("AGF log - " + areaForGrowthPage.toString());
			Log.assertThat(reportComponents.subNavigationMenuisDisplayed(ReportTypes.AREAS_FOR_GROWTH),
					"The AFG Page is displaying in Report MFE sub-navigation",
					"The AFG Page is not displaying in Report MFE sub-navigation");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify AFG decription text and availability of AFG Header on reports page", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 2)
	public void tcSM_AFG002() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG002: Verify Areas for growth decription text<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			// Validate Header description of AFG
			Log.assertThat(areaForGrowthPage.reportDescriptionText(ReportsUIConstants.AFG_DESCRIPTIONTEXT),
					"Correct Description is showing in AFG Header", "Incorrect Description is showing in AFG header");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify subject filter availability for AFG and also verifying list of all subjects available in filter", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 3)
	public void tcSM_AFG003() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_AFG003: Verify subject filter availability for AFG<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			// Validate subject filter
			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.SUBJECT_DROPDOWN),
					"Subject filter is displaying", "Subject filter is not displaying");

			Log.assertThat(
					areaForGrowthPage.reportComponents
							.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_DROPDOWN)
							.containsAll(ReportsUIConstants.SUBJECTS),
					"All Subjects are available", "All subjects are not available");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify All fields displayed on Areas for Growth Page", groups = { "SMK-66757", "reports",
			"Areasforgrowth", "mock" }, priority = 4)
	public void tcSM_AFG004(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG004:Verify All fields displayed on AFG Page<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("OneSavedReportOptions.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetAllReportOption", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());

			}
			// Validate All fields on AFG

			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.GROUP_DROPDOWN),
					"Groups header is displaying", "Groups header is not displaying");
			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.STUDENTS_DROPDOWN),
					"Student header is displaying", "Student header is not displaying");

			Log.assertThat(reportComponents.isMSDropdownHeadingPresent(ReportsUIConstants.ASSIGNMENTS_DROPDOWN),
					"Assignments dropdown header is displaying", "Assignments dropdown header is not displaying");
			Log.assertThat(
					reportComponents.isFilterAndReportOptionsHeadingPresent(ReportsUIConstants.OPTIONAL_FILTER_HEADER),
					"Report Options header is displaying", "Report Options header is not displaying");

			Log.assertThat(areaForGrowthPage.isMaskStudentDisplayed(ReportsUIConstants.MASK_STUDENT_DISPLAY),
					"Mask Student header is displaying", "Mask Student header is not displaying");

			Log.assertThat(
					areaForGrowthPage.isMultiSelectDropdownHeadingPresent(ReportsUIConstants.DATESATRISK_DROPDOWN),
					"Date at risk dropdown header is displaying", "Date at risk dropdown header is not displaying");

			Log.assertThat(areaForGrowthPage.isRunReportDisplayed(), "Run report button is displaying",
					"Run report button is not displaying");
			Log.assertThat(areaForGrowthPage.isSaveReportDisplayed(), "Save report options link is displaying",
					"Save report options link is not displaying");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify whether the reading selection of Subject drop down in Areas for Growth Reports Page", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 5)
	public void tcSM_AFG005() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG005:Verify whether the reading selection of Subject drop down in Area for Growth Reports Page<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			areaForGrowthPage.chooseSubject(driver, "Reading");

			// Verify Reading Subject is selected
			Log.assertThat(areaForGrowthPage.chooseSubject(driver, "Reading"), "The 'Reading' subject is selected",
					"The 'Reading' subject is not selected");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify user can select all and de select all assignments through SELECT ALL check box", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 6)
	public void tcSM_AFG006() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG006:Verify user can select all and de select all assignments through SELECT ALL check box<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			Log.assertThat((reportComponents.unclickSelectAll(reportComponents.ASSIGNMENTS)),
					"'SELECT ALL' Checkbox checked and unchecked successfully!",
					"'SELECT ALL' Checkbox has not  unchecked yet");

			Log.assertThat(reportComponents.clickSelectAll(reportComponents.ASSIGNMENTS),
					"'SELECT ALL' Checkbox checked again successfully", "'SELECT ALL' Checkbox has not checked yet");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Display' dropdown should display on AFG page ,verify all list of Display filter", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 8)
	public void tcSM_AFG007() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("tcSM_AFG007:Verify 'Display' dropdown should display on AFG page<small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			Log.assertThat(
					areaForGrowthPage.reportComponents
							.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL)
							.containsAll(ReportsUIConstants.DISPLAY),
					"All Display filter list is available", "All Display filter list is not available");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify all field on Saved Report Window pop up on AFG page Including button and drop down", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 11)
	public void tcSM_AFG008() throws Exception {

		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(
				"tcSM_AFG008:Verify 'Save Report Options' in AFG page<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.logDescriptionTC("Verify 'Save Report Option' button in AFG report page");

			Log.assertThat(
					areaForGrowthPage.reportComponents.getLabelFromSaveReportOptionButton()
							.equalsIgnoreCase(ReportsUIConstants.SAVE_REPORT_OPTIONS),
					"The save report option is displayed in AFG report",
					"The save report option is not displayed in AFG report");
			Log.assertThat(areaForGrowthPage.reportComponents.isSaveReportButtonEnabled(),
					"Save report option button is enabled as default",
					"Save report option button is disabled as default");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Verify user can click the 'Save Report Option' button in AGF aggregate report page");
			areaForGrowthPage.reportComponents.clickSaveReportOptionButton();
			SMUtils.logDescriptionTC("Verify all available fields in 'Save Report Option Popup.");
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);
			Log.assertThat(
					saveReportOptionPopup.getLabelForNewCustomReportConfiguration()
							.equalsIgnoreCase(ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL),
					"New Report configuration label is displayed properly",
					"New Report configuration label is not displayed properly! Expected - "
							+ ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - "
							+ saveReportOptionPopup.getLabelForNewCustomReportConfiguration());
			Log.assertThat(
					saveReportOptionPopup.getLabelForExistingReportConfiguration()
							.equalsIgnoreCase(ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL),
					"New Report configuration label is displayed properly",
					"New Report configuration label is not displayed properly! Expected - "
							+ ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - "
							+ saveReportOptionPopup.getLabelForExistingReportConfiguration());
			Log.assertThat(saveReportOptionPopup.isSaveButtonDisplayed(),
					"Save Button is displayed in saved report popup",
					"Save Button is not displayed in saved report popup");
			Log.assertThat(saveReportOptionPopup.isCancelButtonDisplayed(),
					"Cancel Button is displayed in saved report popup",
					"Cancel Button is not displayed in saved report popup");
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected on AFG", groups = {
			"SMK-66757", "reports", "Areasforgrowth", "mock" }, priority = 12)
	public void tcSM_AFG009(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG0009:Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected on AFG<small><b><i>["
						+ browser + "]</b></i></small>");
		
		try {
			
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			dashBoardPage = smLoginPage.loginToSMAsTeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// navigate to AFG Page
			dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("Math_Assignments.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			
			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			// Uncheck Select All checkbox
			reportFilterComponent.selectOptionsFromMultiSelectDropdown("Assignments",
					Arrays.asList(ReportsUIConstants.ALL));

			List<String> assignmentsList = new ArrayList<>();

			ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);
			List<String> allAssignmentsFromUI = reportFilterComponent
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);

			// Selecting single option in Group Dropdown

			reportFilterComponent.selectOptionsFromMultiSelectDropdown("Assignments",
					Arrays.asList(allAssignmentsFromUI.get(1)));
			// reportComponents.getPlaceHolderFromMultiSelectDropdown( "Assignments" );
			Log.message("Result : " + reportFilterComponent.getPlaceHolderFromMultiSelectDropdown("Assignments"));

			Log.assertThat(
					(reportFilterComponent.getPlaceHolderFromMultiSelectDropdown("Assignments")
							.contains(allAssignmentsFromUI.get(1))),
					"The Selected Assignment is displaying in the dropdown",
					"The Selected Assignment is not displaying in the dropdown");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify 'Additional Grouping' dropdown should display on AFG page ,verify all list of Additional Grouping filter", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 8)
	public void tcSM_AFG010() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(
				"tcSM_AFG010:Verify 'Additional Grouping' dropdown should display on AFG page ,verify all list of Additional Grouping filter<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			Log.assertThat(
					areaForGrowthPage.reportComponents
							.getAvailableOptionsFromSingleSelectDropdown(
									ReportsUIConstants.ADDITIONAL_GROUPING_DROPDOWN)
							.containsAll(ReportsUIConstants.AFG_ADDGROUPS),
					"All Additional Grouping filter list is available",
					"All Additional Grouping filter list is not available");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify List of all 'Date At Risk ' dropdwon list and list of all Language dropdown field options available on AFG", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 14)
	public void tcSM_AFG011() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(
				"tcSM_AFG011:Verify List of all 'Date At Risk ' dropdwon list and list of all Language dropdown field options available on AFG<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			Log.assertThat(
					areaForGrowthPage.reportComponents
							.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.DATESATRISK_DROPDOWN)
							.containsAll(ReportsUIConstants.DATESATRISK),
					"All 'Date at Risk' values are available in the filter list is available",
					"All Date at Risk list is not available");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.", groups = {
			"SMK-66757", "reports", "Areasforgrowth", "mock" }, priority = 15)
	public void tcSM_AFG012(ITestContext context) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG012:Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();

			reportComponents = new ReportComponents(driver);

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("GroupAndStudentDetails.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			areaForGrowthPage.verifyGroup(driver);

		
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify 'students' dropdown field display under Filters option when more than one students are selected.", groups = {
			"SMK-66757", "reports", "AreasforGrowth", "mock" }, priority = 21)
	public void tcSM_AFG013(ITestContext context) throws Exception {

		// Get driver

		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMAFG013:Verify 'students' dropdown field display under Filters option when more than one students are selected.<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// navigate to AFG Page
			dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);
			
			reportComponents = new ReportComponents(driver);

			// Click Student radio button
			reportComponents.checkStudntRadioBtn();

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("GroupAndStudentDetails_ZeroStudents.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			// Uncheck Select All checkbox
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
					Arrays.asList(ReportsUIConstants.ALL));

			List<String> assignmentsList = new ArrayList<>();

			ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);
			List<String> allAssignmentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN);

			// Selecting single option in Group Dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
					Arrays.asList(allAssignmentsFromUI.get(1)));
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN,
					Arrays.asList(allAssignmentsFromUI.get(2)));

			Log.message("Result : "
					+ reportComponents.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN));

			Log.assertThat(
					(reportComponents.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_DROPDOWN)
							.equals(ReportsUIConstants.SELECTED_OPTION)),
					"The Selected 2 Students are displaying in the dropdown",
					"The Selected Students are not displaying in the dropdown");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 22)
	public void tcSM_AFG014() throws Exception {

		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMAFG014:Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			// Uncheck Select All checkbox
			reportComponents.selectOptionsFromMultiSelectDropdown("Assignments", Arrays.asList(ReportsUIConstants.ALL));

			List<String> assignmentsList = new ArrayList<>();

			ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils(driver);
			List<String> allAssignmentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);

			// Selecting single option in Group Dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown("Assignments",
					Arrays.asList(allAssignmentsFromUI.get(1)));
			reportComponents.selectOptionsFromMultiSelectDropdown("Assignments",
					Arrays.asList(allAssignmentsFromUI.get(2)));

			// reportComponents.getPlaceHolderFromMultiSelectDropdown( "Assignments" );
			Log.message("Result : " + reportComponents.getPlaceHolderFromMultiSelectDropdown("Assignments"));

			Log.assertThat(
					(reportComponents.getPlaceHolderFromMultiSelectDropdown("Assignments")
							.equals(ReportsUIConstants.SELECTED_OPTION)),
					"The Selected 2 Assignments are displaying in the dropdown",
					"The Selected Assignments are not displaying in the dropdown");
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify deleted groups should not display under Groups dropdown.", groups = { "SMK-66757",
			"reports", "Areasforgrowth" }, priority = 9)
	public void tcSM_AFG015() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_AFG015:Verify deleted groups should not display under Groups dropdown.<small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			String className = "ClasstoDelete" + System.nanoTime();

			groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
			groupDetails.put(GroupConstants.GROUP_OWNER_ID, userId);
			groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, orgId);
			groupDetails.put(GroupConstants.GROUP_NAME, className);

			HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds);

			String classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");

			String groupName = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY),
					"data,groupName");
			Log.message("The group name is" + groupName);
			String accessCode = new RBSUtils().getAccessToken(username, password);

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			// get WebElements of dropdown option checkboxes
			List<String> allGroupsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);
			Log.message(allGroupsFromUI.toString());

			Log.assertThat((allGroupsFromUI.contains(className)), "Group is created successfully!!",
					"Group is not created");

			// delete group
			HashMap<String, String> deleteGroup = new GroupAPI().deleteGroup(classId, userId, orgId, accessCode);
			Log.message(deleteGroup.toString());

			driver.navigate().refresh();

			// get WebElements of dropdown option checkboxes

			List<String> groupAfterDeletion = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUP_DROPDOWN);

			Log.message(groupAfterDeletion.toString());

			Log.assertThat(!(groupAfterDeletion.contains(groupName)), "Deleted Group is not displayed as expected",
					"Deleted Group is displayed");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify removed assignments should not display under assignment dropdown.", groups = {
			"SMK-66757", "reports", "Areasforgrowth" }, priority = 10)
	public void tcSM_AFG016() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_AFG0016:Verify removed assignments should not display under assignment dropdown.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to AFG Page
			AreaForGrowthReportPage areaForGrowthPage = dashboardPage.reportComponents.clickAreaForGrowthPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			reportComponents = new ReportComponents(driver);

			List<String> assignmentsFromUI = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);

			Log.message(assignmentsFromUI.toString());

			Log.assertThat((assignmentsFromUI.contains(ReportsUIConstants.MATH)),
					"The Assignment is assigned to the student successfully!",
					"The Assignment is not assigned to the student!");

			HashMap<String, String> mathAssignmentDetails = new HashMap<>();

			mathAssignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
			mathAssignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, userId);
			mathAssignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD));
			mathAssignmentDetails.put(AssignmentAPIConstants.COURSE_ID, "1");
			mathAssignmentDetails.put(AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId.get(0));

			HashMap<String, String> deleteAssignment = new AssignmentAPI().deleteAssignment(smUrl,
					mathAssignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL);
			Log.message("Delete Assignment - " + deleteAssignment.get("body"));

			dashboardPage.reportComponents.clickStudentPerformancePage();
			dashboardPage.reportComponents.clickAreaForGrowthPage();

			reportComponents = new ReportComponents(driver);

			List<String> assignmentList = reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL);

			Log.message(assignmentList.toString());

			Log.assertThat(!(assignmentList.contains(ReportsUIConstants.MATH)),
					"The Assignment is removed from the dropdown successfully!",
					"The Assignment is not removed from the dropdown!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}

	}

}
