package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class CPARAdminInputPageMockTest extends EnvProperties {
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String configGraphQL;
    private String firstTeacherUserName;
    private String secondTeacherUserName;
    private String firstTeacherOrgID;
    private String firstTeacherId;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    RBSUtils rbsUtils = new RBSUtils();
    private String distAdminUserName;
    private String distId;
    private String distAdminuserId;
    private String reportUrl;

    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) throws Exception {
        
        configGraphQL = configProperty.getProperty( "AdminReportBFFGraphQL" );
        reportUrl = configProperty.getProperty( "CPRAdminReportMFE" );
        browser = ReportsUIConstants.CHROME_BROWSER_V100;

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

    }

    @Test ( description = "Verify CPAR input screen & UI validation - Mock OrganizationListMax", groups = { "Smoke", "SMK-67109", "CPAR - Admin Input Page", "Reports", "CPAR report", "mock" }, priority = 1 )
    public void tcCPARInputMock001( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cprPage = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify CPAR input screen & UI validation - Mock OrganizationListMax<small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMax.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }
            
            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            CumulativePerformanceAggregatePage  cparPage = cprPage.navigateToCPAReport();
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CPAR page is displayed" );
            Log.assertThat( cparPage.reportFilterComponent.isReportTitleDisplayed(), "The CPAR title is displayed and it is verified", "The CPAR title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isReportDescriptionDisplayed(), "The CPAR description is displayed and it is verified", "The CPAR description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isHelpIconDisplayed(), "The CPAR help icon is displayed and it is verified", "The CPAR help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CPAR report page" );
            Log.assertThat( cparPage.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalOrgz = cparPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            totalOrgz.size();
            Log.message( "totalOrgzMax: " + totalOrgz + " SizeMax: " + totalOrgz.size() );

            String orgName = "Chiefs_Test_Org_1";
            cparPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            Log.assertThat( totalOrgz.contains( orgName ), "Expected orgName is displayed, Mock Passed:)", "Expected orgName is not displayed, Mock Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify CPAR input screen & UI validation - Mock OrganizationListMin", groups = { "Smoke", "SMK-67109", "CPAR - Admin Input Page", "Reports", "CPAR report", "mock" }, priority = 1 )
    public void tcCPARInputMock002( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cprPage = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify CPAR input screen & UI validation - Mock OrganizationListMin <small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMin.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            CumulativePerformanceAggregatePage  cparPage = cprPage.navigateToCPAReport();
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            SMUtils.logDescriptionTC( "TC:03 Verify the title of CPAR page is displayed" );
            Log.assertThat( cparPage.reportFilterComponent.isReportTitleDisplayed(), "The CPAR title is displayed and it is verified", "The CPAR title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isReportDescriptionDisplayed(), "The CPAR description is displayed and it is verified", "The CPAR description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isHelpIconDisplayed(), "The CPAR help icon is displayed and it is verified", "The CPAR help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CPAR report page" );
            Log.assertThat( cparPage.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalOrgz = cparPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            totalOrgz.size();
            Log.message( "totalOrgMin: " + totalOrgz + " SizeMin: " + totalOrgz.size() );

            String orgName = "Chiefs_Test_Org_1";
            cparPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            Log.assertThat( totalOrgz.contains( orgName ), "Expected orgName is displayed, Mock Passed:)", "Expected orgName is not displayed, Mock Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify CPAR input screen & UI validation - Mock OrganizationList - Zero State", groups = { "Smoke", "SMK-67109", "CPAR - Admin Input Page", "Reports", "CPAR report", "mock" }, priority = 1 )
    public void tcCPARInputMock003( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cprPage = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify CPAR input screen & UI validation - Mock OrganizationList - Zero State <small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListZeroState.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            CumulativePerformanceAggregatePage  cparPage = cprPage.navigateToCPAReport();
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CPAR page is displayed" );
            Log.assertThat( cparPage.reportFilterComponent.isReportTitleDisplayed(), "The CPAR title is displayed and it is verified", "The CPAR title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isReportDescriptionDisplayed(), "The CPAR description is displayed and it is verified", "The CPAR description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isHelpIconDisplayed(), "The CPAR help icon is displayed and it is verified", "The CPAR help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CPAR report page" );
            Log.assertThat( cparPage.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            try {
                List<String> totalOrgz = cparPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
                totalOrgz.size();
                Log.message( "totalOrgZeroState: " + totalOrgz + " SizeZeroState: " + totalOrgz.size() );
                Log.assertThat( totalOrgz.size() == 1, "Zero state orgList mocked, Test passed:)", "Zero state orgList not mocked, Test Failed:(" );
            } catch ( Exception e ) {
                // TODO: handle exception
                String actualException = e.toString();
                Log.message( "actualException: " + actualException );
                Log.assertThat( actualException.contains( ReportsUIConstants.JS_EXECUTION_EXCEPTION), "Zero state mock verfied, Test passed:)", "Zero state mock not verfied, Test Failed:(" );
            }
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax", groups = { "SMK-67109", "CPAR - Admin Input Page", "Reports", "CPAR Report", "mock" }, priority = 1 )
    public void tcCPARInputMock004( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax"+ " <small><b><i>[" + browser + "]</b></i></small>" );
        CumulativePerformancePage cprPage = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getAllReportOption = DevToolsUtils.readJsonResponse( "CPARAdminInputGetAllReportOptionsMax.json" );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }
            
            CumulativePerformanceAggregatePage  cparPage = cprPage.navigateToCPAReport();
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The CPAR Save Report Option label is displayed and it is verified",
                    "The CPAR Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cparPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "The CPAR Save Report Option label text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "The CPAR Save Report Option label text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the CPAR page" );
            Log.assertThat( cparPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The CPAR Save Report Option drop down is displayed and it is verified",
                    "The CPAR Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cparPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CPAR Save Report Option drop down arrow is displayed and it is verified",
                    "The CPAR Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cparPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            cparPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersMax: " + totalFilters + " SizeMax: " + totalFilters.size() );

            SMUtils.logDescriptionTC( "TC:16 Verify the Saved report option name is displayed when it is selected" );
            String filterName = "Chiefs_Filter_1";
            cparPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );

            List<String> mockedFilterNames = cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( mockedFilterNames.contains( filterName ), "Mocked Filter name is displayed, Test passed:)", "Mocked Filter name is not displayed, Test Failed:(" );
            Log.assertThat( totalFilters.size()>= 1001, "Save Report Max successfully mocked, Test Passed:)", "Save Report Max not mocked, Test Failed:(" );
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }


    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMin", groups = { "SMK-67109", "CPAR - Admin Input Page", "Reports", "CPAR Report", "mock" }, priority = 1 )
    public void tcCPARInputMock005( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax"+ " <small><b><i>[" + browser + "]</b></i></small>" );
        CumulativePerformancePage cprPage = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getAllReportOption = DevToolsUtils.readJsonResponse( "CPARAdminInputGetAllReportOptionsMin.json" );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }
            
            CumulativePerformanceAggregatePage  cparPage = cprPage.navigateToCPAReport();
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The CPAR Save Report Option label is displayed and it is verified",
                    "The CPAR Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cparPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "The CPAR Save Report Option label text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "The CPAR Save Report Option label text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the CPAR page" );
            Log.assertThat( cparPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The CPAR Save Report Option drop down is displayed and it is verified",
                    "The CPAR Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cparPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CPAR Save Report Option drop down arrow is displayed and it is verified",
                    "The CPAR Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cparPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            cparPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersMin: " + totalFilters + " SizeMin: " + totalFilters.size() );

            SMUtils.logDescriptionTC( "TC:16 Verify the Saved report option name is displayed when it is selected" );
            String filterName = "Chiefs_Filter_1";
            cparPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );

            List<String> mockedFilterNames = cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( mockedFilterNames.contains( filterName ), "Mocked Filter name is displayed, Test passed:)", "Mocked Filter name is not displayed, Test Failed:(" );
            Log.assertThat( totalFilters.size()>= 2, "Save Report Min successfully mocked, Test Passed:)", "Save Report Min not mocked, Test Failed:(" );

        } catch (Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }



    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptions - Zero State", groups = { "SMK-67109", "CPAR - Admin Input Page", "Reports", "CPAR Report", "mock" }, priority = 1 )
    public void tcCPARInputMock006( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax"+ " <small><b><i>[" + browser + "]</b></i></small>" );
        CumulativePerformancePage cprPage = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );
            
            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getAllReportOption = DevToolsUtils.readJsonResponse( "CPRAdminInputGetAllReportOptionsZeroState.json" );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }
            
            CumulativePerformanceAggregatePage  cparPage = cprPage.navigateToCPAReport();
            
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the CPAR Page" );
            Log.assertThat( cparPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The CPAR Save Report Option label is displayed and it is verified",
                    "The CPAR Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cparPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "The CPAR Save Report Option label text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "The CPAR Save Report Option label text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the CPAR page" );
            Log.assertThat( cparPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "The CPAR Save Report Option drop down is displayed and it is verified",
                    "The CPAR Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cparPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CPAR Save Report Option drop down arrow is displayed and it is verified",
                    "The CPAR Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cparPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            cparPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = cparPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersZeroState: " + totalFilters + " SizeZeroState: " + totalFilters.size() );
            Log.assertThat( totalFilters.size()>= 1, "Save Report Zero State successfully mocked, Test Passed:)", "Save Report Zero State not mocked, Test Failed:(" );


        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }

}