package com.savvas.sm.reports.ui.tests.admin.spr;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.UserUIConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentDetailsForGivenTeacherConstants;

public class StudentPerfomanceReportTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    LeftNavigationBar dashBoardPage;
    AdminLauncherPage smLoginPage;

    private HashMap<String, String> organizationDetails = null;
    private HashMap<String, String> allTeacherDetails = null;
    private HashMap<String, String> groupDetails = new HashMap<String, String>();
    private List<String> orgNames = new ArrayList<String>();
    private List<String> expgroupNames = new ArrayList<String>();
    private List<String> expteacherNames = new ArrayList<String>();
    private List<String> teacherIds = new ArrayList<String>();
    private List<String> groupIds = new ArrayList<String>();
    private String flexSchoolName;
    private String subDistrictschoolName;
    private String schoolAdmin;
    private String districtId;
    private String flexSchoolId;
    private String mathSchool;
    private String readingschool;
    private String mathschoolId;
    private String readingSchoolId;
    private String mathReadingSchoolAdmin;
    private String flexSchoolAdmin;
    private String mathFlexAdmin;
    public static String[] schools;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        schools = configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," );

        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        subDistrictschoolName = configProperty.getProperty( "Rumba_subDistrictSchool" );
        schoolAdmin = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );

        // Flex school Admin create
        flexSchoolName = schools[4];
        flexSchoolId = new RBSUtils().getOrganizationIDByName( districtId, flexSchoolName );
        flexSchoolAdmin = "flexschooladmin7686" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) == null ) {
            HashMap<String, String> adminDetails = new HashMap<>();
            adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, flexSchoolName );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, flexSchoolId );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
            adminDetails.put( RBSDataSetupConstants.USERNAME, flexSchoolAdmin );
            boolean createCAUserWithAccess = new RBSUtils().createCAUserWithAccess( adminDetails, true );
        }

        new RBSUtils().resetPassword( flexSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) );

        // Admin create of Math and Reading School
        mathSchool = schools[0];
        mathschoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), mathSchool );

        mathFlexAdmin = "mathFlexadmin1234" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( mathFlexAdmin ) == null ) {
            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, mathFlexAdmin );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, mathschoolId + "\"," + "\"" + flexSchoolId );
            String admin = new RBSUtils().createUser( userDetails );
            new RBSUtils().resetPassword( mathschoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( admin, RBSDataSetupConstants.USERID ) );
        }
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "adminUsernames" )
    public Object[][] positiveData() {
        Object[][] inputData = { { RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), flexSchoolName }, { RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), subDistrictschoolName },
                { RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), flexSchoolName } };
        return inputData;
    }

    @Test ( dataProvider = "adminUsernames", description = "Verify each Admin Test", groups = {"Smoke", "SMK-59890", "Student Perfomance  Report", "SPR" }, priority = 1 )
    public void tcSMStudentPerformanceTest001( String adminUsenames, String school ) throws Exception {
        Log.message( "Loggin in with Admin: " + adminUsenames );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( adminUsenames, password );

            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            HashMap<String, String> orgDetails = studentPerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( orgDetails.keySet() );
            List<String> orgIds = studentPerformancePage.getOrganizationIds();

            List<String> schoolIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsenames );
            List<String> expOrgIds = new RBSUtils().getOrgIdsForReport( schoolIds );

            Collections.sort( expOrgIds );
            Collections.sort( orgIds );

            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( SMUtils.compareTwoList( expOrgIds, orgIds ), "The organization list is mathcing", "The organization list is mathcing is not mathcing for \nExpected:" + expOrgIds.toString() + " \nActual:" + orgIds.toString() );
            Log.testCaseResult();

            studentPerformancePage.setOrganizationsValue( school );
            studentPerformancePage.clickOptionalFilter();

            Log.testCaseInfo( "Verify the Teacher First Name, Last Name for the Teacher is correct" );
            Log.testCaseInfo( "Verify the Teacher Details for single Organization" );

            List<String> actualTeacherNames = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.TEACHERS );
            getTeacherNames( orgDetails.get( school ) );
            Collections.sort( expteacherNames );
            Collections.sort( actualTeacherNames );
            Log.testCaseInfo( "Verify the Teacher Details for all the Techer Details Organization" );
            Log.assertThat( expteacherNames.containsAll( actualTeacherNames ), "All the Teacher is Present", "The teacher is not matched\n Actual" + expteacherNames.toString() + "\nActual :" + actualTeacherNames.toString() );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify if the Group list is showing for the single teacher" );
            if ( !actualTeacherNames.isEmpty() ) {
                studentPerformancePage.setValuesForDropdown( studentPerformancePage.TEACHERS, Arrays.asList( actualTeacherNames.get( 0 ) ) );
            }
            List<String> allValuesFromGroupsDropdown = studentPerformancePage.getGroupNames();
            expgroupNames = getGroupListNames( studentPerformancePage.getGroupIds() );
            Collections.sort( expgroupNames );
            Collections.sort( allValuesFromGroupsDropdown );

            Log.assertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Valid Multiple Teacher is Selected", groups = { "SMK-59890", "Student Perfomance  Report", "SPR" }, priority = 2 )
    public void tcSMStudentPerformanceTest002() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( schoolAdmin, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            HashMap<String, String> orgDetails = studentPerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( orgDetails.keySet() );

            studentPerformancePage.setOrganizationsValue( flexSchoolName );

            studentPerformancePage.clickOptionalFilter();

            Log.testCaseInfo( "Verify if the Grde Dropdown is listed all the grade" );
            Log.testCaseInfo( "Verify if the Grde Dropdown is listed Not specified Grade" );
            List<String> allValuesFromGradesDropdown = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.GRADES );
            Log.assertThat( allValuesFromGradesDropdown.containsAll( Constants.Students.ALL_GRADES ), "The Grade Values is matching", "The Grade Values is matching" );
            Log.testCaseResult();

            studentPerformancePage.expanDropdown( studentPerformancePage.GRADES );
            studentPerformancePage.clickSelectAll( studentPerformancePage.GRADES );
            Log.testCaseInfo( "Verify if the Grade All is selected when ticked All option" );
            Log.assertThat( studentPerformancePage.isSelectAllChecked( studentPerformancePage.GRADES ), "The Select All option is Checked", "The Select All option is not Checked" );
            studentPerformancePage.clickGradesDropdown();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Teacher Details for more thatn one  Teacher is selected" );
            List<String> actualTeacherNames = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.TEACHERS );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.TEACHERS, actualTeacherNames.subList( 1, 3 ) );

            List<String> allValuesFromGroupsDropdown = studentPerformancePage.getGroupNames();
            expgroupNames = getGroupListNames( studentPerformancePage.getGroupIds() );
            Collections.sort( expgroupNames );
            Collections.sort( allValuesFromGroupsDropdown );

            Log.assertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "When All Teacher is Selected", groups = { "SMK-59890", "Student Perfomance  Report", "SPR" }, priority = 3 )
    public void tcSMStudentPerformanceTest003() throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( schoolAdmin, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            HashMap<String, String> organizationDetails = studentPerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( organizationDetails.keySet() );

            studentPerformancePage.setOrganizationsValue( flexSchoolName );
            studentPerformancePage.clickOptionalFilter();

            studentPerformancePage.clickSelectAll( studentPerformancePage.TEACHERS );
            List<String> allValuesFromGroupsDropdown = studentPerformancePage.getGroupNames();

            getGroupListNames( studentPerformancePage.getGroupIds() );
            Collections.sort( expgroupNames );
            Collections.sort( allValuesFromGroupsDropdown );

            Log.testCaseInfo( "Verify if the Group list is showing for the more than teacher" );
            Log.assertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 4, description = "Without SuccessMaker Groups ", groups = { "SMK-59890", "Student Perfomance  Report", "SPR" } )
    public void tcSMStudentPerformanceTest004() throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( mathFlexAdmin, password );
            Log.message( "Loggin in with Admin: " + mathFlexAdmin );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();

            HashMap<String, String> organizationDetails = studentPerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( organizationDetails.keySet() );

            String orgId1 = mathschoolId;
            String orgId2 = flexSchoolId;

            //teacher create - orgId1 orgId2    
            String teacherUsernameCreate = "teacher16546d9" + districtId.substring( 28, 32 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
            String teacherdetailsCreate = null;
            String teacherIdCreate = null;
            try {
                if ( new RBSUtils().getUserIDByUserName( teacherUsernameCreate ) == null ) {
                    Log.message( "username is not present :" + teacherUsernameCreate );
                    teacherdetailsCreate = new UserAPI().createUserWithCustomization( teacherUsernameCreate, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId1, orgId2 ) );
                }
                teacherIdCreate = new RBSUtils().getUserIDByUserName( teacherUsernameCreate );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }

            // student create   orgId1 orgId2
            String studentUsernameCreate = "student14546d667" + districtId.substring( 28, 32 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
            String studentDetailsCreate = null;
            String studentIdCreate = null;
            try {
                if ( new RBSUtils().getUserIDByUserName( studentUsernameCreate ) == null ) {
                    Log.message( "username is not present :" + studentUsernameCreate );
                    studentDetailsCreate = new UserAPI().createUserWithCustomization( studentUsernameCreate, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId1, orgId2 ) );
                }
                studentIdCreate = new RBSUtils().getUserIDByUserName( studentUsernameCreate );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }

            // resetting password
            new RBSUtils().resetPassword( orgId1, password, teacherIdCreate );

            String className = "Group Without SuccessMaker product" + System.nanoTime();
            String accessToken = new RBSUtils().getAccessToken( teacherUsernameCreate, password );

            String createClassWithoutSMProdcut = new RBSUtils().CreateClassWithoutSMProdcut( className, teacherIdCreate, studentIdCreate, orgId1, accessToken );

            // Group create for org1
            String org1Group = "Group for org " + orgId1.substring( 20 );
            accessToken = new RBSUtils().getAccessToken( teacherUsernameCreate, password );
            new RBSUtils().createClassWithMultipleTeacher( org1Group, new ArrayList<>( Arrays.asList( teacherIdCreate ) ), new ArrayList<>( Arrays.asList( studentIdCreate ) ), orgId1, accessToken );

            // Group create for org2
            String org2Group = "Group for org " + orgId2.substring( 20 );
            accessToken = new RBSUtils().getAccessToken( teacherUsernameCreate, password );

            new RBSUtils().createClassWithMultipleTeacher( org2Group, new ArrayList<>( Arrays.asList( teacherIdCreate ) ), new ArrayList<>( Arrays.asList( studentIdCreate ) ), orgId2, accessToken );

            String teacherDetails = new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( teacherUsernameCreate ) );
            StringBuffer FirstNamesLastNames = new StringBuffer();
            FirstNamesLastNames.append( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.FIRSTNAME ) );
            FirstNamesLastNames.append( " " );
            FirstNamesLastNames.append( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.LASTNAME ) );

            // Reading school 

            // Group Verify for org 2
            studentPerformancePage.setOrganizationsValue( flexSchoolName );
            studentPerformancePage.clickOptionalFilter();

            studentPerformancePage.setValuesForDropdown( studentPerformancePage.TEACHERS, Arrays.asList( FirstNamesLastNames.toString() ) );

            // Verifying group for org 2
            List<String> allValuesFromGroupsDropdown = studentPerformancePage.getGroupNames();
            Log.assertThat( allValuesFromGroupsDropdown.contains( org2Group ), "The Groups is not Present for without product", "The Groups is not Present for without product\n" + className + "\nActual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

            // Math School
            studentPerformancePage.setOrganizationsValue( mathSchool );
            studentPerformancePage.setValuesForDropdown( studentPerformancePage.TEACHERS, new ArrayList<>( Arrays.asList( FirstNamesLastNames.toString() ) ) );

            // Verifying group without succesmaker product
            allValuesFromGroupsDropdown = studentPerformancePage.getGroupNames();
            Collections.sort( allValuesFromGroupsDropdown );

            Log.testCaseInfo( "Verify if the Group list is showing for that has No SM prodcut" );
            Log.assertThat( !allValuesFromGroupsDropdown.contains( className ), "The Groups is not Present for without product as expected!",
                    "The Groups is not Present for without product\n" + className + "\nActual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

            // Verifying group for org 1
            Log.assertThat( allValuesFromGroupsDropdown.contains( org1Group ), "The Groups is present for the org1 Teacher",
                    "The Groups is present for the org1 Teacher\n org 1 Group Expected\n" + org1Group + "\nActual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( enabled = true, priority = 1, description = "Verify all the Student Demographic Values Dropdown Test", groups = { "SMK-59890", "Student Perfomance  Report", "SPR" } )
    public void tcSMStudentPerfomanceTest005() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( mathReadingSchoolAdmin, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            studentPerformancePage.waitForSpinnerToLoadAndDisppear();

            studentPerformancePage.clickOptionalFilter();
            studentPerformancePage.clickStudentDemographics();

            // Verifying all the Header is correct

            Log.assertThat( studentPerformancePage.verifyStudentDemographicsHeader(), "The Students Demograhics header is matched!", "The Students Demograhics header is not matched!" );
            HashMap<String, List<String>> drodownValues = new HashMap<>();
            drodownValues.put( studentPerformancePage.DISABLITY_STATUS, ReportsUIConstants.DISABILITY_STATUS_OPTIONS.subList( 1, ReportsUIConstants.DISABILITY_STATUS_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.ENGLISH_LANGUAGE_PROFICIENCY, ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.subList( 1, ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.GENDER, ReportsUIConstants.GENDER_OPTIONS.subList( 1, ReportsUIConstants.GENDER_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.MIGRANT_STATUS, ReportsUIConstants.MIGRANT_STATUS_OPTIONS.subList( 1, ReportsUIConstants.MIGRANT_STATUS_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.RACE, ReportsUIConstants.RACE_OPTIONS.subList( 1, ReportsUIConstants.RACE_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.ETHINICIY, ReportsUIConstants.ETHNICITY_OPTIONS.subList( 1, ReportsUIConstants.ETHNICITY_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.SOCIO_ECONOMIC_STATUS, ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.subList( 1, ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.size() ) );
            drodownValues.put( studentPerformancePage.SPECIAL_SERVICES, ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.subList( 1, ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.size() ) );

            // Verification of Student DemoGraphics Filter  dropdown values
            drodownValues.keySet().stream().forEach( dropDown -> {
                studentPerformancePage.expanDropdown( dropDown );
                Log.testCaseInfo( "Verifying Select All Options: " + dropDown );
                studentPerformancePage.clickSelectAll( dropDown );
                Log.assertThat( studentPerformancePage.isSelectAllChecked( dropDown ), "The Dropdown  Selected All is checked", "The Dropdown  Selected All is not checked" );
                Log.testCaseResult();
                studentPerformancePage.closeDropdown( dropDown );

                List<String> allValuesFromDropdown = studentPerformancePage.getAllValuesFromDropdown( dropDown );
                List<String> expectedValues = drodownValues.get( dropDown );
                Log.message( "Verifying values for the dropdown: " + dropDown );

                Collections.sort( allValuesFromDropdown );
                Collections.sort( expectedValues );

                Log.assertThat( SMUtils.compareTwoList( expectedValues, allValuesFromDropdown ), "All the values in the Dropdown is mathched!",
                        "The dropdown values is not matched! \nExpected " + expectedValues.toString() + "\nActual" + allValuesFromDropdown.toString() );
                Log.testCaseResult();

                Log.testCaseInfo( "Verifying un select All Options: " + dropDown );
                studentPerformancePage.unSelectAll( dropDown );
                Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( dropDown ).isEmpty(), "Unselected All options is working as expected!", "Unselected All options is not working as expected! \nExpected" );
                Log.testCaseResult();

                Log.testCaseInfo( "Verifying Selecting single options for the Dropdown: " + dropDown );
                studentPerformancePage.unSelectAll( dropDown );
                studentPerformancePage.setValuesForDropdown( dropDown, new ArrayList<String>( Arrays.asList( allValuesFromDropdown.get( 0 ) ) ) );
                Log.assertThat( studentPerformancePage.getCheckedValuesForDropdown( dropDown ).equals( Arrays.asList( allValuesFromDropdown.get( 0 ) ) ), "Single Selected options is mathced! for Values: " + allValuesFromDropdown.get( 0 ),
                        "Single Selected options is not mathced!: " + allValuesFromDropdown.get( 0 ) );
                Log.testCaseResult();

                Log.testCaseInfo( "Verifying Selecting Multiple options for the Dropdown: " + dropDown );
                Collections.sort( allValuesFromDropdown );
                studentPerformancePage.setValuesForDropdown( dropDown, allValuesFromDropdown.subList( 0, 2 ) );
                List<String> checkValues = studentPerformancePage.getCheckedValuesForDropdown( dropDown );
                Collections.sort( checkValues );
                Log.assertThat( checkValues.equals( allValuesFromDropdown.subList( 0, 2 ) ), "Multiple selected options is mathced!", "Multiple selected options is not mathced!: " + allValuesFromDropdown.subList( 0, 2 ) );
                Log.testCaseResult();

            } );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, priority = 2, description = "Verify all the other Staic Values Test Data", groups = { "SMK-59890", "Student Perfomance  Report", "SPR" } )
    public void tcSMStudentPerfomanceTest006() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( mathReadingSchoolAdmin, password );
            StudentPerformancePage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            studentPerformancePage.clickOptionalFilter();

            // Language
            SMUtils.logDescriptionTC( "Verify all field available under Language dropdown" );
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdownForStudentPerformance( ReportsUIConstants.LANGUAGE );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE ).containsAll( ReportsUIConstants.LANGUAGE_OPTIONS ), "All the Language option are displaying",
                    "Language option are not displaying" );
            Log.testCaseResult();

            // Date At risk
            SMUtils.logDescriptionTC( "Verify all field available under Date At Risk dropdown" );
            studentPerformancePage.reportFilterComponent.expandSingleSelectDropdownForStudentPerformance( ReportsUIConstants.DATE_AT_RISK );
            Log.assertThat( studentPerformancePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK ).containsAll( ReportsUIConstants.DATE_AT_RISK_OPTIONS ), "All the Date at Risk option are displaying",
                    "Date at Risk option are not displaying" );
            Log.testCaseResult();

            // Display Dropdown
            List<String> actValues = studentPerformancePage.getAllValuesFromDropdown( studentPerformancePage.DISPLAY );
            Log.assertThat( SMUtils.compareTwoList( actValues, ReportsUIConstants.DISPLAY ), "All the values in Display is mathched!", "All the values in Display is not mathched!" + actValues.toString() );
            Log.testCaseResult();

            // mark Student Check box
            studentPerformancePage.clickMaskStudentCheckBox();
            Log.assertThat( studentPerformancePage.isMaskStudentisChecked(), "The Mark Student Check box is diplayed", "The Mark Student Check box is not diplayed" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the Teacher Details From the OrgIds
     * 
     * @param orgIds
     * @return
     */

    public void getTeacherNames( String orgId ) {
        expteacherNames.clear();
        Log.message( "Getting teacher Details..." );
        List<String> teacherUsernames = new ArrayList<>();
        JSONArray teacherJsonArray = new RBSUtils().getAllTeachesForOrg( orgId );
        if ( !teacherJsonArray.equals( new JSONArray() ) ) {
            for ( Object user : teacherJsonArray ) {
                JSONObject userJson = new JSONObject( user.toString() );
                HashMap<String, String> otherDetails = new HashMap<String, String>();
                teacherUsernames.add( userJson.get( ReportsAPIConstants.TNS_FIRSTNAME ).toString() + " " + userJson.get( ReportsAPIConstants.TNS_LASTNAME ).toString() );
            }
        }
        expteacherNames.addAll( teacherUsernames );
    }

    /**
     * Get Group List Name for the GroupIds
     * 
     * @param groupIds
     * @return
     */
    public List<String> getGroupListNames( List<String> groupIds ) {
        expgroupNames.clear();
        Log.message( "Getting Groups Details..." );
        groupIds.forEach( groupId -> {
            String classDetails = new RBSUtils().getClass( groupId );
            expgroupNames.add( new SMAPIProcessor().getKeyValues( new JSONObject( classDetails ), ReportsAPIConstants.CLASSNAME ).get( 0 ) );
        } );

        return expgroupNames;
    }
}
