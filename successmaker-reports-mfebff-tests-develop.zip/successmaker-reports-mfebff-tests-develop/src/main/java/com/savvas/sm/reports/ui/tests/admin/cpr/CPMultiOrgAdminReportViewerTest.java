package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.admin.ui.pages.CumulativePerformanceReportViewerPage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.StudentIDWarningPopupPage;
import com.savvas.sm.utils.Constants.ReportDataCreation;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CPMultiOrgAdminReportViewerTest extends EnvProperties {

    private String smUrl;
    private static String browser;
    private static String adminUsername;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static String flexSchool;
    private static String mathSchool;

    @BeforeClass
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        adminUsername = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify org dropdown exists in report viewer when admin generated CPR with multiple orgs" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest001() throws Exception {

        Log.testCaseInfo( "tc-001: Verify org dropdown exists in report viewer when admin generated CPR with multiple orgs" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify org dropdown exists in report viewer when admin generated CPR with multiple orgs" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );
            cprPage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is displaying properly in CPR report viewer page while run the report for multi school",
                    "Organization dropdown is not displaying properly in CPR report viewer page while run the report for multi school" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify org dropdown in report viewer shows the selected multiple orgs in CPR report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest002() throws Exception {

        Log.testCaseInfo( "tc-002: Verify org dropdown in report viewer shows the selected multiple orgs in CPR report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify org dropdown exists in report viewer when admin generated CPR with multiple orgs" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown().containsAll( Arrays.asList( flexSchool ) ), "The selected organizations are displaying in the organization dropdown!!!",
                    "selected organizations are not displaying properly in the organization dropdown. Expected - " + Arrays.asList( flexSchool ) + ". Actual - " + cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown() );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify org dropdown is not shown  in report viewer when report is generated with single org in CPR report input screen" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest003() throws Exception {

        Log.testCaseInfo( "tc-003: Verify org dropdown is not shown  in report viewer when report is generated with single org in CPR report input screen" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify org dropdown is not shown  in report viewer when report is generated with single org in CPR report input screen" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( !cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is not displaying  in CPR report viewer page while run the report for single school as expected",
                    "Organization dropdown is displaying in CPR report viewer page while run the report for single school. organization dropdown should not display." );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify back button is disabled and next button is enabled in report viewer when CPR report is generated for single org and report is having multiple pages" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest004() throws Exception {

        Log.testCaseInfo( "tc-004: Verify back button is disabled and next button is enabled in report viewer when CPR report is generated for single org and report is having multiple pages" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify back button is disabled and next button is enabled in report viewer when CPR report is generated for single org and report is having multiple pages" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( flexSchool ) );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            //Verify the next and back button
            Log.assertThat( !cpReportViewerPage.reportOutputComponent.isBackBtnEnabled(), "Back button is disabled as expected", "Back button is enabled.It should be disable as default" );
            Log.assertThat( cpReportViewerPage.reportOutputComponent.isNextBtnEnabled(), "Next button is enabled as expected", "Next button is disabled.It should be enable as default" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify back button is disabled and next button is enabled in report viewer when CPR report is generated for single org and report is having multiple pages" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest005() throws Exception {

        Log.testCaseInfo( "tc-005: Verify back button is disabled and next button is enabled in report viewer when CPR report is generated for single org and report is having multiple pages" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify back button is disabled and next button is enabled in report viewer when CPR report is generated for single org and report is having multiple pages" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            //Verify the next and back button
            Log.assertThat( !cpReportViewerPage.reportOutputComponent.isBackBtnEnabled(), "Back button is disabled as expected", "Back button is enabled.It should be disable as default" );
            Log.assertThat( cpReportViewerPage.reportOutputComponent.isNextBtnEnabled(), "Next button is enabled as expected", "Next button is disabled.It should be enable as default" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify Previous school data is loaded in report viewer when page is navigated to last page of first school in report viewer and click on Back button" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest006() throws Exception {

        Log.testCaseInfo( "tc-006: Verify Previous school data is loaded in report viewer when page is navigated to last page of first school in report viewer and click on Back button" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify Previous school data is loaded in report viewer when page is navigated to last page of first school in report viewer and click on Back button" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            //To get the current selected organization in the Report viewer page
            String currentOrganization = cpReportViewerPage.getselectedOrganization();

            //To get the total number of pages for current organization
            String totalPages = cpReportViewerPage.reportOutputComponent.getTotalPageNo();

            //To navigate last page
            cpReportViewerPage.reportOutputComponent.goToPage( totalPages );

            //To click the back button
            cpReportViewerPage.reportOutputComponent.clickBackButton();

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( currentOrganization ), "The previous school data is loading when page is navigated to last page of first school in report viewer and click on Back button",
                    "The previous school data is not loading when page is navigated to last page of first school in report viewer and click on Back button" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify Next school data is loaded in report viewer when page is navigated to last page of first school in report viewer and click on Next button" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest007() throws Exception {

        Log.testCaseInfo( "tc-007: Verify Previous school data is loaded in report viewer when page is navigated to last page of first school in report viewer and click on Back button" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify Previous school data is loaded in report viewer when page is navigated to last page of first school in report viewer and click on Back button" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( mathSchool, flexSchool ) );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            //To get the current selected organization in the Report viewer page
            String currentOrganization = cpReportViewerPage.getselectedOrganization();

            //To get the total number of pages for current organization
            String totalPages = cpReportViewerPage.reportOutputComponent.getTotalPageNo();

            //To navigate last page
            cpReportViewerPage.reportOutputComponent.goToPage( totalPages );

            //To click the back button
            cpReportViewerPage.reportOutputComponent.clickNextButton();

            Log.assertThat( !cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( currentOrganization ) && Arrays.asList( mathSchool, flexSchool ).contains( cpReportViewerPage.getselectedOrganization() ),
                    "The next school data is loading when page is navigated to last page of first school in report viewer and click on next button",
                    "The next school data is not loading when page is navigated to last page of first school in report viewer and click on next button" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify org list dropdown in report viewer is sorted in alphabetical order" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest008() throws Exception {

        Log.testCaseInfo( "tc-008: Verify org list dropdown in report viewer is sorted in alphabetical order" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify org list dropdown in report viewer is sorted in alphabetical order" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Collections.sort( selectedOrgs );
            List<String> availableOrganizations = cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown();

            Log.assertThat( IntStream.range( 0, availableOrganizations.size() ).allMatch( itr -> availableOrganizations.get( itr ).equalsIgnoreCase( selectedOrgs.get( itr ) ) ), "Organization list dropdown in report viewer is sorted in alphabetical order",
                    "Organization list dropdown in report viewer is not sorted in alphabetical order.Actual - " + availableOrganizations + ".Expected - " + selectedOrgs );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify org list dropdown is showing first school from the list by default in report viewer and report page shows the records for the first school" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest009() throws Exception {

        Log.testCaseInfo( "tc-009: Verify org list dropdown is showing first school from the list by default in report viewer and report page shows the records for the first school" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify org list dropdown is showing first school from the list by default in report viewer and report page shows the records for the first school" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Collections.sort( selectedOrgs );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( selectedOrgs.get( 0 ) ),
                    "Organization list dropdown is showing first school from the list by default in report viewer and report page shows the records for the first school",
                    "Organization list dropdown is not showing first school from the list by default in report viewer and report page shows the records for the first school" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify admin can select any school from the org dropdown and report should show the data based on the selected org" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest010() throws Exception {

        Log.testCaseInfo( "tc-010: Verify admin can select any school from the org dropdown and report should show the data based on the selected org" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify admin can select any school from the org dropdown and report should show the data based on the selected org" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Collections.sort( selectedOrgs );

            //To Select the organization
            cpReportViewerPage.selectOrganization( selectedOrgs.get( 1 ) );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( selectedOrgs.get( 1 ) ), "Admin able to select the organization in the organization dropdown",
                    "Getting issue while admin select the orgnization in the organization dropdown." );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify Back button is enabled when admin selects any school from the org dropdown except first school in report viewer" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest011() throws Exception {

        Log.testCaseInfo( "tc-011: Verify Back button is enabled when admin selects any school from the org dropdown except first school in report viewer" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify Back button is enabled when admin selects any school from the org dropdown except first school in report viewer" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Collections.sort( selectedOrgs );

            //To Select the organization
            cpReportViewerPage.selectOrganization( selectedOrgs.get( 1 ) );

            Log.assertThat( cpReportViewerPage.reportOutputComponent.isBackBtnEnabled(), "Back button is enabled  when admin selects any school from the org dropdown except first school in report viewer",
                    "Back button is disabled  when admin selects any school from the org dropdown except first school in report viewer" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify zero state appears and Next button is enabled when first school is not having data and second school is having data" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest012() throws Exception {

        Log.testCaseInfo( "tc-012: Verify zero state appears and Next button is enabled when first school is not having data and second school is having data" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify zero state appears and Next button is enabled when first school is not having data and second school is having data" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( RBSDataSetup.subDistrictwithoutSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Collections.sort( selectedOrgs );

            //To Select the organization
            cpReportViewerPage.selectOrganization( selectedOrgs.get( 1 ) );

            Log.assertThat( cpReportViewerPage.reportOutputComponent.isNextBtnEnabled(), "Next button is enabled when first school is not having data and second school is having data",
                    "Next button is disavled when first school is not having data and second school is having data" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify when selecting single org and course the report viewer page data shows based on the selected org and course" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest013() throws Exception {

        Log.testCaseInfo( "tc-013: Verify when selecting single org and course the report viewer page data shows based on the selected org and course" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify when selecting single org and course the report viewer page data shows based on the selected org and course" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();
            Log.assertThat( !cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is not displaying as expected while admin run the report for single organization",
                    "Organization dropdown is displaying while admin run the report for single organization" );

            Log.assertThat( cpReportViewerPage.reportOutputComponent.getAssignmentName().equalsIgnoreCase( ReportsUIConstants.MATH ) && cpReportViewerPage.reportOutputComponent.getOrganizationName().equalsIgnoreCase( flexSchool ),
                    "Report viewer page is showing the data based on the selected org and course", "Report viewer page is not showing the data based on the selected org and course" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify when selecting multiple org and course the report viewer page data shows based on the selected org and course" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest014() throws Exception {

        Log.testCaseInfo( "tc-014: Verify when selecting multiple org and course the report viewer page data shows based on the selected org and course" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify when selecting single org and course the report viewer page data shows based on the selected org and course" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is displaying as expected while admin run the report for multiple organization",
                    "Organization dropdown is not displaying while admin run the report for multiple organization" );

            Log.assertThat( cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown().containsAll( selectedOrgs ), "All the selected organizations are displaying in the organizaion dropdown.",
                    "All the selected organizations are not displaying in the organizaion dropdown." );

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.reportOutputComponent.getAssignmentName().equalsIgnoreCase( ReportsUIConstants.MATH ) && cpReportViewerPage.reportOutputComponent.getOrganizationName().equalsIgnoreCase( flexSchool ),
                    "Report viewer page is showing the data based on the selected org and course", "Report viewer page is not showing the data based on the selected org and course" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify when selecting multiple schools, single teacher, group and grade the report viewer page data shows based on the selected option" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest015() throws Exception {

        Log.testCaseInfo( "tc-015: Verify when selecting multiple schools, single teacher, group and grade the report viewer page data shows based on the selected option" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify when selecting multiple schools, single teacher, group and grade the report viewer page data shows based on the selected option" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To get the Group list in the dropdown
            List<String> groups = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To Select the Group option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            //To Select the grade option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.GRADE_LABEL + " " + ReportsUIConstants.GRADE_1 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is displaying as expected while admin run the report for multiple organization",
                    "Organization dropdown is not displaying while admin run the report for multiple organization" );

            Log.assertThat( cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown().containsAll( selectedOrgs ), "All the selected organizations are displaying in the organizaion dropdown.",
                    "All the selected organizations are not displaying in the organizaion dropdown." );

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( flexSchool ), "Report viewer page is showing the data based on the selected org and course",
                    "Report viewer page is not showing the data based on the selected org and course" );

            //Verifying sub-header
            List<String> selectedOptions = cpReportViewerPage.reportOutputComponent.getSelectedOptionValues();

            Log.assertThat( selectedOptions.contains( "1 group selected" ), "Selected group count is displaying properly in the Report sub-header",
                    "Selected group count is not displaying properly in the Report sub-header. Expected - 1 group selected. Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "1 grade selected" ), "Selected grade count is displaying properly in the Report sub-header",
                    "Selected grade count is not displaying properly in the Report sub-header. Expected - 1 grade  selected. Actual -" + selectedOptions );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify when selecting multiple schools, multiple teacher, group and grade the report viewer page data shows based on the selected option" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest016() throws Exception {

        Log.testCaseInfo( "tc-016:Verify when selecting multiple schools, multiple teacher, group and grade the report viewer page data shows based on the selected option" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify when selecting multiple schools, multiple teacher, group and grade the report viewer page data shows based on the selected option" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To get the teacher list in the dropdown
            List<String> teachers = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To Select the single option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teachers.get( 1 ), teachers.get( 2 ) ) );

            //To get the Group list in the dropdown
            List<String> groups = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            Set<String> set = new LinkedHashSet<>();
            set.addAll( groups );
            groups.clear();
            groups.addAll( set );

            //To Select the Group option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ), groups.get( 2 ) ) );

            //To Select the grade option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL,
                    Arrays.asList( ReportsUIConstants.GRADE_LABEL + " " + ReportsUIConstants.GRADE_1, ReportsUIConstants.GRADE_LABEL + " " + ReportsUIConstants.GRADE_2 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is displaying as expected while admin run the report for multiple organization",
                    "Organization dropdown is not displaying while admin run the report for multiple organization" );

            Log.assertThat( cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown().containsAll( selectedOrgs ), "All the selected organizations are displaying in the organizaion dropdown.",
                    "All the selected organizations are not displaying in the organizaion dropdown." );

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( flexSchool ), "Report viewer page is showing the data based on the selected org and course",
                    "Report viewer page is not showing the data based on the selected org and course" );

            //Verifying sub-header
            List<String> selectedOptions = cpReportViewerPage.reportOutputComponent.getSelectedOptionValues();

            Log.assertThat( selectedOptions.contains( "2 teachers selected" ) || selectedOptions.contains( "All teachers selected" ), "Selected teacher count is displaying properly in the Report sub-header",
                    "Selected teacher count is not displaying properly in the Report sub-header. Expected - All teachers selected. Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "2 groups selected" ) || selectedOptions.contains( "All groups selected" ), "Selected teacher count is displaying properly in the Report sub-header",
                    "Selected teacher count is not displaying properly in the Report sub-header. Expected - 2 groups selected. Actual -" + selectedOptions );

            Log.assertThat( selectedOptions.contains( "2 grades selected" ), "Selected grade count is displaying properly in the Report sub-header",
                    "Selected grade count is not displaying properly in the Report sub-header. Expected - 2 grades  selected. Actual -" + selectedOptions );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test", "smoke_test_case" }, description = "Verify when selecting multiple schools, all teacher, group and grade the report viewer page data shows based on the selected option" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest017() throws Exception {

        Log.testCaseInfo( "tc-017:Verify when selecting multiple schools, all teacher, group and grade the report viewer page data shows based on the selected option" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify when selecting multiple schools, all teacher, group and grade the report viewer page data shows based on the selected option" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To get the teacher list in the dropdown
            List<String> teachers = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );

            //To Select the single option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To get the Group list in the dropdown
            List<String> groups = cprPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );

            //To Select the Group option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //To Select the grade option
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            Log.assertThat( cpReportViewerPage.isOrganizationDropdownDisplayed(), "Organization dropdown is displaying as expected while admin run the report for multiple organization",
                    "Organization dropdown is not displaying while admin run the report for multiple organization" );

            Log.assertThat( cpReportViewerPage.getAvailableOrganizationsFromOrganizationDropdown().containsAll( selectedOrgs ), "All the selected organizations are displaying in the organizaion dropdown.",
                    "All the selected organizations are not displaying in the organizaion dropdown." );

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( flexSchool ), "Report viewer page is showing the data based on the selected org and course",
                    "Report viewer page is not showing the data based on the selected org and course" );

            //Verifying sub-header
            List<String> selectedOptions = cpReportViewerPage.reportOutputComponent.getSelectedOptionValues();

            Log.assertThat( selectedOptions.contains( "All teachers selected" ), "Selected teacher count is displaying properly in the Report sub-header",
                    "Selected teacher count is not displaying properly in the Report sub-header. Expected - All teachers selected. Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "All groups selected" ), "Selected group count is displaying properly in the Report sub-header",
                    "Selected group count is not displaying properly in the Report sub-header. Expected - All groups selected. Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "All grades selected" ), "Selected grade count is displaying properly in the Report sub-header",
                    "Selected grade count is not displaying properly in the Report sub-header. Expected - All grades  selected. Actual -" + selectedOptions );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user selects multiple schools, additional grouping option as \"teacher\" , display option as \"Student name\" and sort option as \"Student\" " )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest018() throws Exception {

        Log.testCaseInfo( "tc-018:Verify the report viewer page data shows based on the selected option when user selects multiple schools, additional grouping option as \"teacher\" , display option as \"Student name\" and sort option as \"Student\" " );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC(
                    "Verify the report viewer page data shows based on the selected option when user selects multiple schools, additional grouping option as \"teacher\" , display option as \"Student name\" and sort option as \"Student\" " );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select teacher option in addditional Grouping
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 1 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( flexSchool ), "Report viewer page is showing the data based on the selected org and course",
                    "Report viewer page is not showing the data based on the selected org and course" );

            //Verifying sub-header
            List<String> selectedOptions = cpReportViewerPage.reportOutputComponent.getSelectedOptionValues();

            Log.assertThat( selectedOptions.contains( ReportsUIConstants.ADDITIONAL_GROUPING_TEACHER ), "Selected Additional grouping option is displaying properly in the Report sub-header",
                    "Selected Additional grouping option is not displaying properly in the Report sub-header Expected - " + ReportsUIConstants.ADDITIONAL_GROUPING_TEACHER + ". Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "Sort by Student Name" ), "Selected group count is displaying properly in the Report sub-header",
                    "Selected group count is not displaying properly in the Report sub-header. Expected - All group selected. Actual -" + selectedOptions );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected options when user selects multiple schools, additional grouping option as \"grade\" , display option as \"Student Id\" and sort option as \"Assigned course level\" " )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest019() throws Exception {

        Log.testCaseInfo(
                "tc-019:Verify the report viewer page data shows based on the selected options when user selects multiple schools, additional grouping option as \"grade\" , display option as \"Student Id\" and sort option as \"Assigned course level\" " );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC(
                    "Verify the report viewer page data shows based on the selected options when user selects multiple schools, additional grouping option as \"grade\" , display option as \"Student Id\" and sort option as \"Assigned course level\" " );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select teacher option in addditional Grouping
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 2 ) );

            //To select "Student Id"  option in Display
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTID );

            //To close the modal popup
            StudentIDWarningPopupPage popup = new StudentIDWarningPopupPage( driver ).get();
            popup.clickIconbutton();

            //To select "Assigned Course level" option in Display
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_lIST.get( 2 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( flexSchool ), "Report viewer page is showing the data based on the selected org and course",
                    "Report viewer page is not showing the data based on the selected org and course" );

            //Verifying sub-header
            List<String> selectedOptions = cpReportViewerPage.reportOutputComponent.getSelectedOptionValues();

            Log.assertThat( selectedOptions.contains( ReportsUIConstants.ADDITIONAL_GROUPING_GRADE ), "Selected Additional grouping option is displaying properly in the Report sub-header",
                    "Selected Additional grouping option is not displaying properly in the Report sub-header Expected - " + ReportsUIConstants.ADDITIONAL_GROUPING_GRADE + ". Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "Sort by Assigned Course Level" ), "Selected group count is displaying properly in the Report sub-header",
                    "Selected group count is not displaying properly in the Report sub-header. Expected - Sort by Assigned Course Level. Actual -" + selectedOptions );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected options when user selects multiple schools, additional grouping option as \"group\" , display option as \"Student username\" and sort option as \"Current course level\" the report viewer page data shows based on the selected option" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest020() throws Exception {

        Log.testCaseInfo(
                "tc-020:Verify the report viewer page data shows based on the selected options when user selects multiple schools, additional grouping option as \"group\" , display option as \"Student username\" and sort option as \"Current course level\" the report viewer page data shows based on the selected option" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC(
                    "Verify the report viewer page data shows based on the selected options when user selects multiple schools, additional grouping option as \"group\" , display option as \"Student username\" and sort option as \"Current course level\" the report viewer page data shows based on the selected option" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select teacher option in addditional Grouping
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 3 ) );

            //To select "Student Id"  option in Display
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            //To select "Assigned Course level" option in Display
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT_lIST.get( 3 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            Log.assertThat( cpReportViewerPage.getselectedOrganization().equalsIgnoreCase( flexSchool ), "Report viewer page is showing the data based on the selected org and course",
                    "Report viewer page is not showing the data based on the selected org and course" );

            //Verifying sub-header
            List<String> selectedOptions = cpReportViewerPage.reportOutputComponent.getSelectedOptionValues();

            Log.assertThat( selectedOptions.contains( ReportsUIConstants.ADDITIONAL_GROUPING_GROUP ), "Selected Additional grouping option is displaying properly in the Report sub-header",
                    "Selected Additional grouping option is not displaying properly in the Report sub-header Expected - " + ReportsUIConstants.ADDITIONAL_GROUPING_GROUP + ". Actual -" + selectedOptions );
            Log.assertThat( selectedOptions.contains( "Sort by Current Course Level" ), "Selected group count is displaying properly in the Report sub-header",
                    "Selected group count is not displaying properly in the Report sub-header. Expected - Sort by Current Course Level. Actual -" + selectedOptions );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user selects multiple schools, the selected date range option" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest021() throws Exception {

        Log.testCaseInfo( "tc-021:Verify the report viewer page data shows based on the selected option when user selects multiple schools, the selected date range option" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user selects multiple schools, the selected date range option" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();

            //To select the date range
            cprPage.clickSelectedDateRangeButton();
            cprPage.enterCurrentDateInStartAndEndCalendar();

            List<String> selectedDatesFromCalendar = cprPage.getSelectedDatesFromCalendar();
            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            List<String> selectedDatedFromOutputPage = Arrays.asList( cpReportViewerPage.getSelectedDates().split( " - " ) );

            Log.assertThat( selectedDatedFromOutputPage.containsAll( selectedDatesFromCalendar ), "The report viewer page data is showing based on the selected option when user selects multiple schools, the selected date range option",
                    "The report viewer page data is not showing based on the selected option when user selects multiple schools, the selected date range option. Expected -" + selectedDatesFromCalendar + ".Actual -" + selectedDatedFromOutputPage );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user selects multiple schools and select multiple options in all Student Demographics filter" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest022() throws Exception {

        Log.testCaseInfo( "tc-022:Verify the report viewer page data shows based on the selected option when user selects multiple schools and select multiple options in all Student Demographics filter" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user selects multiple schools and select multiple options in all Student Demographics filter" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandStudentDemographics();

            //To select the demographic options
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            Map<String, List<String>> selectedDemographics = cpReportViewerPage.reportOutputComponent.getSelectedDemographics();

            //To verify the demographics in output page
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.DISABILITY_STATUS ).containsAll( Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) ),
                    "Selected Disability status option is displaying properly in report output page", "Selected Disability option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll( Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) ),
                    "Selected English language proficieny option is displaying properly in report output page", "Selected English language proficieny option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.ETHNICITY ).containsAll( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) ), "Selected ethinicity option is displaying properly in report output page",
                    "Selected ethinicity option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.MIGRANT_STATUS ).containsAll( Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) ), "Selected migrant status option is displaying properly in report output page",
                    "Selected migrant option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.RACE ).containsAll( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) ), "Selected Race option is displaying properly in report output page",
                    "Selected Race option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) ),
                    "Selected special service option is displaying properly in report output page", "Selected special service option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) ),
                    "Selected socioeconomic option is displaying properly in report output page", "Selected socioeconomic option is not displaying properly in report output page" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user selects multiple schools and select multiple options in all Student Demographics filter" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest023() throws Exception {

        Log.testCaseInfo( "tc-023:Verify the report viewer page data shows based on the selected option when user selects multiple schools and select multiple options in all Student Demographics filter" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user selects multiple schools and select multiple options in all Student Demographics filter" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandStudentDemographics();

            //To select the demographic options
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            Map<String, List<String>> selectedDemographics = cpReportViewerPage.reportOutputComponent.getSelectedDemographics();

            //To verify the demographics in output page
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.DISABILITY_STATUS ).containsAll( Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) ),
                    "Selected Disability status option is displaying properly in report output page", "Selected Disability option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll(
                            Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) ),
                    "Selected English language proficieny option is displaying properly in report output page", "Selected English language proficieny option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.ETHNICITY ).containsAll( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) ),
                    "Selected ethinicity option is displaying properly in report output page", "Selected ethinicity option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.MIGRANT_STATUS ).containsAll( Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) ),
                    "Selected migrant status option is displaying properly in report output page", "Selected migrant option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.RACE ).containsAll( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) ),
                    "Selected Race option is displaying properly in report output page", "Selected Race option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) ),
                    "Selected special service option is displaying properly in report output page", "Selected special service option is not displaying properly in report output page" );
            Log.assertThat( selectedDemographics.get( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) ),
                    "Selected socioeconomic option is displaying properly in report output page", "Selected socioeconomic option is not displaying properly in report output page" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user selects multiple schools and select all options in all Student Demographics filter" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest024() throws Exception {

        Log.testCaseInfo( "tc-024:Verify the report viewer page data shows based on the selected option when user selects multiple schools and select all options in all Student Demographics filter" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user selects multiple schools and select all options in all Student Demographics filter" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandStudentDemographics();

            //To select the demographic options
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            Map<String, List<String>> selectedDemographics = cpReportViewerPage.reportOutputComponent.getSelectedDemographics();

            //To verify the demographics in output page
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.DISABILITY_STATUS ).containsAll(
                            Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 3 ) ) ),
                    "Selected Disability status option is displaying properly in report output page", "Selected Disability option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll(
                            Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 3 ) ) ),
                    "Selected English language proficieny option is displaying properly in report output page", "Selected English language proficieny option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.ETHNICITY ).containsAll( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 3 ) ) ),
                    "Selected ethinicity option is displaying properly in report output page", "Selected ethinicity option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.MIGRANT_STATUS ).containsAll(
                            Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 3 ) ) ),
                    "Selected migrant status option is displaying properly in report output page", "Selected migrant option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.RACE ).containsAll( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ), ReportsUIConstants.RACE_OPTIONS.get( 3 ),
                            ReportsUIConstants.RACE_OPTIONS.get( 4 ), ReportsUIConstants.RACE_OPTIONS.get( 5 ), ReportsUIConstants.RACE_OPTIONS.get( 6 ), ReportsUIConstants.RACE_OPTIONS.get( 7 ), ReportsUIConstants.RACE_OPTIONS.get( 8 ) ) ),
                    "Selected Race option is displaying properly in report output page", "Selected Race option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ),
                            ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 3 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 4 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 5 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 6 ) ) ),
                    "Selected special service option is displaying properly in report output page", "Selected special service option is not displaying properly in report output page" );
            Log.assertThat(
                    selectedDemographics.get( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll(
                            Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 3 ) ) ),
                    "Selected socioeconomic option is displaying properly in report output page", "Selected socioeconomic option is not displaying properly in report output page" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user select two school and the teacher associative with those two school" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest025() throws Exception {

        Log.testCaseInfo( "tc-025: Verify the report viewer page data shows based on the selected option when user select two school and the teacher associative with those two school" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user select two school and the teacher associative with those two school" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandStudentDemographics();

            //To select the additional grouping options
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 1 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            String multipleSchoolTeacherDetail = ReportDataCollection.sharedTeacherDetails;
            String teacherName = SMUtils.getKeyValueFromResponse( multipleSchoolTeacherDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( multipleSchoolTeacherDetail, "lastName" );

            Map<String, List<String>> allTeachersFromOutPutPage = cpReportViewerPage.reportOutputComponent.getAllTeachersFromOutPutPage();

            Log.assertThat( allTeachersFromOutPutPage.get( flexSchool ).contains( teacherName ), "Multiple school teacher present in the report viewer Page",
                    "Multiple school teacher is not present in the report viewer Page.Expected -" + teacherName + " .Actual-" + allTeachersFromOutPutPage.get( flexSchool ) );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user select two school and the student associative with those two school" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest026() throws Exception {

        Log.testCaseInfo( "tc-027: Verify the report viewer page data shows based on the selected option when user select two school and the student associative with those two school" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user select two school and the teacher associative with those two school" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            String multipleSchoolStudentDetail = ReportDataCollection.sharedStudentDetails;
            String studentName = SMUtils.getKeyValueFromResponse( multipleSchoolStudentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( multipleSchoolStudentDetail, "lastName" );

            List<String> studentsFromOutPutPage = cpReportViewerPage.getStudentnamesFromCurrentReport();

            Log.assertThat( studentsFromOutPutPage.contains( studentName ), "Multiple school student present in the report viewer Page",
                    "Multiple school student is not present in the report viewer Page.Expected -" + studentName + " .Actual-" + studentsFromOutPutPage );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user select single school and the group associative with those two teacher" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest027() throws Exception {

        Log.testCaseInfo( "tc-027: Verify the report viewer page data shows based on the selected option when user select single school and the group associative with those two teacher" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user select single school and the group associative with those two teacher" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( mathSchool, flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandStudentDemographics();

            //To select the additional grouping options
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 3 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            cpReportViewerPage.selectOrganization( flexSchool );

            String sharedGroupname = ReportDataCreation.SHARED_GROUP;

            Map<String, List<String>> allGroupsFromOutPutPage = cpReportViewerPage.reportOutputComponent.getAllGroupsFromOutPutPage();

            Log.assertThat( allGroupsFromOutPutPage.get( flexSchool ).contains( sharedGroupname ), "Shared Group present in the report viewer Page",
                    "Shared Group is not present in the report viewer Page. Expected -" + sharedGroupname + ".Actual-" + allGroupsFromOutPutPage.get( flexSchool ) );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-71301", "Organization- muliOrg Test",
            "smoke_test_case" }, description = "Verify the report viewer page data shows based on the selected option when user select single school, two group and student associative with those two groups" )
    public void tcCPAndCPAReportMultiSelectOrgDropdownTest028() throws Exception {

        Log.testCaseInfo( "Verify the report viewer page data shows based on the selected option when user select single school, two group and student associative with those two groups" );
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );

            SMUtils.logDescriptionTC( "Verify the report viewer page data shows based on the selected option when user select single school, two group and student associative with those two groups" );
            CumulativePerformancePage cprPage = afgPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //To Select multiple organizations
            List<String> selectedOrgs = Arrays.asList( flexSchool );
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, selectedOrgs );

            //To select subject
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );

            //To select Assignments
            cprPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            cprPage.reportFilterComponent.expandOptionalFilter();
            cprPage.reportFilterComponent.expandStudentDemographics();

            //To select the additional grouping options
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.ADDITIONAL_GROUPING.get( 3 ) );
            cprPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );

            CumulativePerformanceReportViewerPage cpReportViewerPage = cprPage.clickRunReportButton();

            List<String> studentsFromOutPutPage = cpReportViewerPage.getStudentnamesFromCurrentReport();

            String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
            String usernameSuffix = envUrl.split( "\\." )[0];
            String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

            Log.assertThat( studentsFromOutPutPage.contains( String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 2, 3, usernameSuffixTest ) ), "Multiple Group student present in the report viewer Page",
                    "Multiple Group student is not present in the report viewer Page.Expected -" + String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 2, 3, usernameSuffixTest ) + " .Actual-" + studentsFromOutPutPage );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
