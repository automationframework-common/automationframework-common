package com.savvas.sm.reports.exportcsv.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.StudentPerformanceReportPage;
import com.savvas.sm.reports.admin.ui.pages.StudentPerformanceReportViewerPage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.Groups;
import com.savvas.sm.utils.Constants.Reports;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.SPRExportCSVConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;

public class AdminStudentPerformanceReportCsv extends EnvProperties {

    private String smUrl;
    private String browser;

    private String districtAdminUsername;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    private String districtAdminUserId;
    private String districtId;
    private String teacherId;
    private String teacherUsername;
    private String teacherName;
    private String flexSchool;
    private String flexSchoolId;

    private String ipClearedStudentUsername;
    private String ipNotClearedStudentUsername;
    private String ipClearedStudentUserId;
    private String ipNotClearedStudentUserId;
    private String groupId;
    private String groupName;
    private static String defaultMathRequestId;
    private static String defaultReadingRequestId;
    private static String customMathRequestId;
    private static String customReadingRequestId;

    private HashMap<String, String> assignmentNames = new HashMap<>();
    RBSUtils rbsUtils = new RBSUtils();

    // Default Math
    private String defaultMathCsvDataUI;
    private List<Map<String, String>> defaultMathCsvDataUISplit;
    private List<Map<String, String>> defaultMathCsvDataAPI;
    // Default Reading
    private String defaultReadingCsvDataUI;
    private List<Map<String, String>> defaultReadingCsvDataUISplit;
    private List<Map<String, String>> defaultReadingCsvDataAPI;

    // Custom Math
    private String customMathCsvDataUI;
    private List<Map<String, String>> customMathCsvDataUISplit;
    private List<Map<String, String>> customMathCsvDataAPI;
    // Custom Reading
    private String customReadingCsvDataUI;
    private List<Map<String, String>> customReadingCsvDataUISplit;
    private List<Map<String, String>> customReadingCsvDataAPI;

    private Map<String, String> headers = new HashMap<>();
    private static String reportRun = "06-12-2022";

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        districtId = configProperty.getProperty( "district_ID" ).trim();
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        flexSchoolId = rbsUtils.getOrganizationIDByName( districtId, flexSchool );

        districtAdminUsername = ReportDataCollection.districtAdmin;
        districtAdminUserId = rbsUtils.getUserIDByUserName( districtAdminUsername );

        teacherUsername = ReportDataCollection.teacherDetails.keySet().toArray()[0].toString();
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );
        teacherName = SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( teacherUsername ), "firstAndLastName" );

        // Get Student details
        Map<String, String> studentDetails = ReportDataCollection.defaultMathAssignmentDetails.get( teacherUsername );

        ipClearedStudentUserId = studentDetails.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().get();
        ipNotClearedStudentUserId = studentDetails.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" )
                && !SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "currentLevel" ).contains( "null" ) ).findFirst().get();

        ipClearedStudentUsername = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipClearedStudentUserId ), "userName" );
        ipNotClearedStudentUsername = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipNotClearedStudentUserId ), "userName" );

        groupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsername ) ).get( 0 ).toString(), "groupId" );
        groupName = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsername ) ).get( 0 ).toString(), "groupName" );

        //Get Math assignments id
        assignmentNames.put( Constants.MATH, SMUtils.getKeyValueFromResponse( ReportDataCollection.defaultMathAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), "courseDetail,name" ) );
        assignmentNames.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMONAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), "courseDetail,name" ) );
        assignmentNames.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), "courseDetail,name" ) );

        //Get Reading assignments id
        assignmentNames.put( Constants.READING, SMUtils.getKeyValueFromResponse( ReportDataCollection.defaultReadingAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), "courseDetail,name" ) );
        assignmentNames.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMONAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), "courseDetail,name" ) );
        assignmentNames.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).get( ipClearedStudentUserId ), "courseDetail,name" ) );

        //Headers
        headers.put( Constants.USERID_SM_HEADER, districtAdminUserId );
        headers.put( Constants.ORGID_SM_HEADER, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        // Fetch Default CSV data for Math and Reading subjects
        getDefaultCsvDataFromUI( Constants.MATH );
        getDefaultCsvDataFromUI( Constants.READING );
        defaultMathCsvDataAPI = getMathAPI();
        defaultReadingCsvDataAPI = getReadingAPI();

        // Fetch Custom CSV data for Math and Reading subjects
        getCustomCsvDataFromUI( Constants.MATH, false, null );
        getCustomCsvDataFromUI( Constants.READING, false, null );
        customMathCsvDataAPI = getCustomMathAPI();
        customReadingCsvDataAPI = getCustomReadingAPI();

        Log.message( "Default Math UI- " + defaultMathCsvDataUI + "\n" );
        Log.message( "Default Math Split- " + defaultMathCsvDataUISplit + "\n" );
        Log.message( "Default Math API- " + defaultMathCsvDataAPI + "\n" );

        Log.message( "Default Reading UI- " + defaultReadingCsvDataUI + "\n" );
        Log.message( "Default Reading Split- " + defaultReadingCsvDataUISplit + "\n" );
        Log.message( "Default Reading API- " + defaultReadingCsvDataAPI + "\n" );

        Log.message( "Custom Math UI- " + customMathCsvDataUI + "\n" );
        Log.message( "Custom Math Split- " + customMathCsvDataUISplit + "\n" );
        Log.message( "Custom Math API- " + customMathCsvDataAPI + "\n" );

        Log.message( "Custom Reading UI- " + customReadingCsvDataUI + "\n" );
        Log.message( "Custom Reading Split- " + customReadingCsvDataUISplit + "\n" );
        Log.message( "Custom Reading API- " + customReadingCsvDataAPI + "\n" );

    }

    @Test ( description = "Verify csv headers (column name) in exported csv file for Default Export - Math Subject", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest001() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv headers (column name) in exported csv file for Default Export - Math Subject" );
        String exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( defaultMathCsvDataUI );
        List<String> expectedHeaders = new ArrayList<>( SPRExportCSVConstants.DEFAULT_MATH_HEADERS );
        expectedHeaders.remove( "\"Student Name\"" );
        Log.assertThat( expectedHeaders.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
    }

    @Test ( description = "Verify csv headers (column name) in exported csv file for Default Export - Reading Subject", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest002() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv headers (column name) in exported csv file for Default Export - Reading Subject" );
        String exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( defaultReadingCsvDataUI );
        List<String> expectedHeaders = new ArrayList<>( SPRExportCSVConstants.DEFAULT_READING_HEADERS );
        expectedHeaders.remove( "\"Student Name\"" );
        Log.assertThat( expectedHeaders.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Reading", "All Column header values are not returned for Reading" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Math Subject and for the student who has completed the IPM.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest003() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Math Subject and for the student who has completed the IPM." );

        Log.assertThat(
                SMUtils.compareTwoHashMap( defaultMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "Student Username" ).equals( ipClearedStudentUsername ) && dataList.get( "Assignment Name" ).equals( Constants.MATH ) ).findFirst().get(),
                        defaultMathCsvDataAPI.stream().filter( list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Reading Subject and for the student who has completed the IPM.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest004() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Reading Subject and for the student who has completed the IPM." );

        Log.assertThat(
                SMUtils.compareTwoHashMap( defaultReadingCsvDataUISplit.stream().filter( dataList -> dataList.get( "Student Username" ).equals( ipClearedStudentUsername ) && dataList.get( "Assignment Name" ).equals( Constants.READING ) ).findFirst().get(),
                        defaultReadingCsvDataAPI.stream().filter( list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( Constants.READING ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Math Subject and for the student who has not completed the IPM.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest005() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Math Subject and for the student who has not completed the IPM." );

        Log.assertThat(
                SMUtils.compareTwoHashMap( defaultMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "Student Username" ).equals( ipNotClearedStudentUsername ) && dataList.get( "Assignment Name" ).equals( Constants.MATH ) ).findFirst().get(),
                        defaultMathCsvDataAPI.stream().filter( list -> list.get( "Student Username" ).equals( ipNotClearedStudentUsername ) && list.get( "Assignment Name" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Reading Subject and for the student who has not completed the IPM.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv",
            "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest006() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Reading Subject and for the student who has not completed the IPM." );

        Log.assertThat(
                SMUtils.compareTwoHashMap(
                        defaultReadingCsvDataUISplit.stream().filter( dataList -> dataList.get( "Student Username" ).equals( ipNotClearedStudentUsername ) && dataList.get( "Assignment Name" ).equals( Constants.READING ) ).findFirst().get(),
                        defaultReadingCsvDataAPI.stream().filter( list -> list.get( "Student Username" ).equals( ipNotClearedStudentUsername ) && list.get( "Assignment Name" ).equals( Constants.READING ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Custom by Setting Math - IPM on course.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest007() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Custom by Setting Math - IPM on course." );

        Log.assertThat(
                SMUtils.compareTwoHashMap(
                        defaultMathCsvDataUISplit.stream().filter(
                                list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) ).findFirst().get(),
                        defaultMathCsvDataAPI.stream().filter(
                                list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Custom by Setting Math - IPM off course.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest008() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Custom by Setting Math - IPM off course." );

        Log.assertThat(
                SMUtils.compareTwoHashMap(
                        defaultMathCsvDataUISplit.stream().filter(
                                listUI -> listUI.get( "Student Username" ).equals( ipClearedStudentUsername ) && listUI.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) ).findFirst().get(),
                        defaultMathCsvDataAPI.stream().filter(
                                list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Custom by Setting Reading - IPM on course.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest009() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Custom by Setting Reading - IPM on course." );

        Log.assertThat(
                SMUtils.compareTwoHashMap(
                        defaultReadingCsvDataUISplit.stream().filter(
                                list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) ).findFirst().get(),
                        defaultReadingCsvDataAPI.stream().filter(
                                list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values in exported csv file for Default Export - Custom by Setting Reading - IPM off course.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest010() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv values in exported csv file for Default Export - Custom by Setting Reading - IPM off course." );

        Log.assertThat(
                SMUtils.compareTwoHashMap(
                        defaultReadingCsvDataUISplit.stream().filter(
                                listUI -> listUI.get( "Student Username" ).equals( ipClearedStudentUsername ) && listUI.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) ).findFirst().get(),
                        defaultReadingCsvDataAPI.stream().filter(
                                list -> list.get( "Student Username" ).equals( ipClearedStudentUsername ) && list.get( "Assignment Name" ).equals( assignmentNames.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    // Verifying Custom Export CSV
    @Test ( description = "Verify csv headers (column name) in exported csv file for custom Export - Math Subject", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest011() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv headers (column name) in exported csv file for custom Export - Math Subject" );

        String exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( customMathCsvDataUI );
        Log.assertThat( SPRExportCSVConstants.CUSTOM_MATH_HEADERS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
    }

    @Test ( description = "Verify csv headers (column name) in exported csv file for custom Export - Reading Subject", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest012() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv headers (column name) in exported csv file for custom Export - Reading Subject" );

        String exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( customReadingCsvDataUI );
        Log.assertThat( SPRExportCSVConstants.CUSTOM_READING_HEADERS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
    }

    @Test ( description = "Verify csv headers (column name) , when selecting the Multiple custom fields.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest013() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv headers (column name) , when selecting the Multiple custom fields." );

        String exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( customMathCsvDataUI );

        //getCustomCsvDataFromUI( Constants.MATH, true, null );
        Log.assertThat( SPRExportCSVConstants.CUSTOM_MATH_HEADERS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
    }

    @Test ( description = "Verify csv headers (column name) , when selecting one custom field", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest014() throws Exception {
        SMUtils.logDescriptionTC( "Verify csv headers (column name) , when selecting one custom field" );

        String exportedCsvFile = ExportCsvUtils.getCsvFileHeasers( customReadingCsvDataUI );
        Log.assertThat( SPRExportCSVConstants.CUSTOM_READING_HEADERS.stream().allMatch( header -> exportedCsvFile.contains( header ) ), "Column headers are resturned as expected for Math", "All Column header values are not returned for Math" );
    }

    @Test ( description = "Verify csv values, when selecting the Mask Student display.", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest015() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            StudentPerformanceReportPage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.waitForSpinnertoDisapper( driver, 30 );
            //To select the organization in the organization dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, flexSchool );
            SMUtils.waitForSpinnertoDisapper( driver, 20 );
            //To select the Subject 
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( Reports.SUBJECT_DROPDOWN, Constants.MATH );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            studentPerformancePage.reportFilterComponent.expandOptionalFilter();
            studentPerformancePage.clickMaskStudentCheckBox();
            //To click the run report button
            StudentPerformanceReportViewerPage studentPerformanceOutputPage = studentPerformancePage.clickRunReportButton();
            SMUtils.nap( 20 ); // Wait time is required for report page loading

            //To Click the Export csv button
            String csvDataFromBS = null;
            ExportPopupComponent exportPopup = null;
            try {
                exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();
                exportPopup.clickOkButton();
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            } catch ( Exception e ) {
                try {
                    exportPopup.clickCloseButtonInErrorModalPopup();
                    exportPopup.clickCloseButtonInDownloadingModalPopup();
                    exportPopup.clickCloseButtonInCsvExportPopup();
                    studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();
                    exportPopup.clickOkButton();
                    csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
                } catch ( Exception e2 ) {
                    Log.message( "Issue on reading CSV file. Check whether CSV file is downloaded." );
                    e.getMessage();
                }
            }

            Log.assertThat( ExportCsvUtils.splitCSVDataFromResponse( csvDataFromBS ).get( 0 ).get( "Student Name" ).contains( "Student 1" ), "Student name count are disaplyed in order when selecting Mask Student display",
                    "Student name count are not disaplyed in order when selecting Mask Student display" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify csv values, when selecting the English language", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest016() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the English language" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the teacher in the teacher filter", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest017() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the English language" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the grade in the grade filter", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest018() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the grade in the grade filter" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the group in the group filter", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest019() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the group in the group filter" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the teacher s, Grade and group in the tecaher, grade and group filter", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest020() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the teacher s, Grade and group in the tecaher, grade and group filter" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the demographic filter", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest021() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the demographic filter" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the includePerformanceSummary as false", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest022() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the includePerformanceSummary as false" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = " Verify csv values, when selecting the includePerformanceByStrand as false", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest023() throws Exception {

        SMUtils.logDescriptionTC( " Verify csv values, when selecting the includePerformanceByStrand as false" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the includeAreasOfDifficulty as false", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest024() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the includeAreasOfDifficulty as false" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    @Test ( description = "Verify csv values, when selecting the includeRecentHistoryData as 2 Weeks", groups = { "smoke_test_case", "SMK-67781", "Admin Student Perfomance Report Export Csv", "UI" }, priority = 1 )
    public void tcAdminSprExportCsvTest025() throws Exception {

        SMUtils.logDescriptionTC( "Verify csv values, when selecting the includeRecentHistoryData as 2 Weeks" );

        Log.assertThat(
                SMUtils.compareTwoHashMap( customMathCsvDataUISplit.stream().filter( dataList -> dataList.get( "studentUsername" ).equals( ipClearedStudentUsername ) && dataList.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get(),
                        customMathCsvDataAPI.stream().filter( list -> list.get( "studentUsername" ).equals( ipClearedStudentUsername ) && list.get( "courseName" ).equals( Constants.MATH ) ).findFirst().get() ),
                "The data displayed in CSV file is same as expected", "The data displayed in CSV file is not same as expected" );
    }

    private List<Map<String, String>> getMathAPI() {
        String csv = AdminReportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( flexSchoolId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), Arrays.asList(), 10400, false, "en", false, true, true, true,
                new ArrayList<>(), defaultMathRequestId ).getBody().asString();
        List<Map<String, String>> csvDataList = new ArrayList<>();
        ExportCsvUtils.splitCSVDataFromResponse( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( csv, "signedUrl" ) ) ).stream().forEach( map -> {
            map.remove( "Group" );
            map.remove( "Report Run" );
            csvDataList.add( map );
        } );
        return csvDataList;
    }

    private List<Map<String, String>> getReadingAPI() {
        String csv = AdminReportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( flexSchoolId ), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), Arrays.asList(), 10400, false, "en", false, true, true, true,
                new ArrayList<>(), defaultReadingRequestId ).getBody().asString();
        List<Map<String, String>> csvDataList = new ArrayList<>();
        ExportCsvUtils.splitCSVDataFromResponse( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( csv, "signedUrl" ) ) ).stream().forEach( map -> {
            map.remove( "Group" );
            map.remove( "Report Run" );
            csvDataList.add( map );
        } );
        return csvDataList;
    }

    private List<Map<String, String>> getCustomMathAPI() {

        String csv = AdminReportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, true, Arrays.asList( flexSchoolId ), Arrays.asList( teacherId ), Arrays.asList( groupId ), new ArrayList<>(), Arrays.asList(), 10400, true, "en", false, false,
                false, true, SPRExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS, customMathRequestId ).getBody().asString();

        List<Map<String, String>> csvDataList = new ArrayList<>();
        ExportCsvUtils.splitCSVDataFromResponse( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( csv, "signedUrl" ) ) ).stream().forEach( map -> {
            map.remove( "reportRun" );
            csvDataList.add( map );
        } );
        return csvDataList;
    }

    private List<Map<String, String>> getCustomReadingAPI() {

        String csv = AdminReportCsv.postAdminStudentPerformanceReportCSV( headers, reportRun, false, Arrays.asList( flexSchoolId ), Arrays.asList( teacherId ), Arrays.asList( groupId ), new ArrayList<>(), Arrays.asList(), 10400, true, "en", false, false,
                false, true, SPRExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS, customReadingRequestId ).getBody().asString();

        List<Map<String, String>> csvDataList = new ArrayList<>();
        ExportCsvUtils.splitCSVDataFromResponse( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( csv, "signedUrl" ) ) ).stream().forEach( map -> {
            map.remove( "reportRun" );
            csvDataList.add( map );
        } );
        return csvDataList;
    }

    private void getDefaultCsvDataFromUI( String subject ) throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            StudentPerformanceReportPage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            SMUtils.waitForSpinnertoDisapper( driver, 30 );
            //To select the organization in the organization dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, flexSchool );
            SMUtils.waitForSpinnertoDisapper( driver, 20 );
            //To select the Subject 
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( Reports.SUBJECT_DROPDOWN, subject );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            studentPerformancePage.reportFilterComponent.expandOptionalFilter();
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            //To click the run report button
            StudentPerformanceReportViewerPage studentPerformanceOutputPage = studentPerformancePage.clickRunReportButton();
            SMUtils.nap( 20 ); // Wait time is required for report page loading

            //To Click the Export csv button

            if ( subject.equals( Constants.MATH ) ) {
                defaultMathRequestId = driver.getCurrentUrl().split( "=" )[1];
            } else {
                defaultReadingRequestId = driver.getCurrentUrl().split( "=" )[1];
            }
            String csvDataFromBS = null;
            ExportPopupComponent exportPopup = null;
            try {
                exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();
                exportPopup.clickOkButton();
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            } catch ( Exception e ) {
                try {
                    exportPopup.clickCloseButtonInErrorModalPopup();
                    exportPopup.clickCloseButtonInDownloadingModalPopup();
                    exportPopup.clickCloseButtonInCsvExportPopup();
                    studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();
                    exportPopup.clickOkButton();
                    csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
                } catch ( Exception e2 ) {
                    Log.message( "Issue on reading CSV file. Check whether CSV file is downloaded." );
                    e.getMessage();
                }
            }
            List<Map<String, String>> csvDataList = new ArrayList<>();
            if ( subject.equalsIgnoreCase( Constants.MATH ) ) {
                defaultMathCsvDataUI = csvDataFromBS;
                ExportCsvUtils.splitCSVDataFromResponse( csvDataFromBS ).stream().forEach( map -> {
                    map.remove( "Group" );
                    map.remove( "Report Run" );
                    csvDataList.add( map );
                } );
                defaultMathCsvDataUISplit = csvDataList;
            } else {
                defaultReadingCsvDataUI = csvDataFromBS;
                ExportCsvUtils.splitCSVDataFromResponse( csvDataFromBS ).stream().forEach( map -> {
                    map.remove( "Group" );
                    map.remove( "Report Run" );
                    csvDataList.add( map );
                } );
                defaultReadingCsvDataUISplit = csvDataList;
            }
            if ( Objects.nonNull( csvDataList ) ) {
                Log.message( subject + " default CSV data are fetched successfully!!!" );
            } else {
                Log.message( "Issue on fetching " + subject + " default CSV data" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    private void getCustomCsvDataFromUI( String subject, boolean isMultiSelection, List<String> fields ) throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            StudentPerformanceReportPage studentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();
            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            //To select the organization in the organization dropdown
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, flexSchool );
            SMUtils.waitForSpinnertoDisapper( driver, 20 );
            //To select the Subject 
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( Reports.SUBJECT_DROPDOWN, subject );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            // Selecting dropdown values in Optional Filters
            studentPerformancePage.reportFilterComponent.expandOptionalFilter();
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherName ) );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( Groups.GRADE_NOT_SPECIFIED ) );
            studentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( Reports.GROUP, Arrays.asList( groupName ) );
            studentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );
            studentPerformancePage.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );
            studentPerformancePage.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            //To click the run report button 
            StudentPerformanceReportViewerPage studentPerformanceOutputPage = studentPerformancePage.clickRunReportButton();
            SMUtils.nap( 20 ); // Wait time is required for report page loading

            if ( subject.equals( Constants.MATH ) ) {
                customMathRequestId = driver.getCurrentUrl().split( "=" )[1];
            } else {
                customReadingRequestId = driver.getCurrentUrl().split( "=" )[1];
            }
            //To Click the Export csv button
            String csvDataFromBS = null;
            ExportPopupComponent exportPopup = null;
            try {
                exportPopup = studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();
                exportPopup.clickCustomizeExportRadioButton();
                if ( isMultiSelection ) {
                    exportPopup.selectAvailableColumns( fields );
                } else {
                    exportPopup.clickChevronDoubleRightButton();
                }
                exportPopup.clickOkButton();
                exportPopup.isCloseButtonEnabledInDownloadingModalPopup();
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            } catch ( Exception e ) {
                try {
                    exportPopup.clickCloseButtonInErrorModalPopup();
                    exportPopup.clickCloseButtonInDownloadingModalPopup();
                    exportPopup.clickCloseButtonInCsvExportPopup();
                    studentPerformanceOutputPage.reportOutputComponent.clickExportCSVButton();
                    exportPopup.clickCustomizeExportRadioButton();
                    if ( isMultiSelection ) {
                        exportPopup.selectAvailableColumns( fields );
                    } else {
                        exportPopup.clickChevronDoubleRightButton();
                    }
                    exportPopup.clickOkButton();
                    SMUtils.nap( 30 );
                    csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
                } catch ( Exception e2 ) {
                    Log.message( "Issue on reading CSV file. Check whether CSV file is downloaded." );
                    e.getMessage();
                }
            }
            List<Map<String, String>> csvDataList = new ArrayList<>();
            if ( subject.equalsIgnoreCase( Constants.MATH ) ) {
                customMathCsvDataUI = csvDataFromBS;
                ExportCsvUtils.splitCSVDataFromResponse( csvDataFromBS ).stream().forEach( map -> {
                    map.remove( "reportRun" );
                    csvDataList.add( map );
                } );
                customMathCsvDataUISplit = csvDataList;
            } else {
                customReadingCsvDataUI = csvDataFromBS;
                ExportCsvUtils.splitCSVDataFromResponse( csvDataFromBS ).stream().forEach( map -> {
                    map.remove( "reportRun" );
                    csvDataList.add( map );
                } );
                customReadingCsvDataUISplit = csvDataList;
            }
            if ( Objects.nonNull( csvDataList ) ) {
                Log.message( subject + " custom CSV data are fetched successfully!!!" );
            } else {
                Log.message( "Issue on fetching " + subject + " custom CSV data" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public String getCSVFileFromSignedUrl( String signedUrl ) {
        //To get the CSV File
        String csvDataFromBS = null;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            driver.get( signedUrl );
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            driver.quit();
        }
        return csvDataFromBS;
    }

}