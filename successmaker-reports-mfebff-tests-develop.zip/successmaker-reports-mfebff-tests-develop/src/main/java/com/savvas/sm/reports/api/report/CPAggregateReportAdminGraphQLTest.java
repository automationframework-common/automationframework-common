package com.savvas.sm.reports.api.report;

import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class CPAggregateReportAdminGraphQLTest extends UserAPI {
    @Test ( dataProvider = "getCPAggregateReportPositiveScenario", groups = { "SMK-61278 GraphQL API for CP AggregateReport Admin", "API","SmokeTest" }, priority = 1 )
    public void getCPAggregateReportPositiveScenarios( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        String payload = getPayload( "CPAAdminReportData" );
        String query;
        Response response = null;
        String responseStatusCode = "";
        switch ( scenarioType ) {
            case "LANGUAGE_PROFICIENCY":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "englishLanguageProficiency: []", "englishLanguageProficiency: [\\\"ENGLISH_LANGUAGE_LEARNER\\\", \\\"NOT_SPECIFIED\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                Log.softAssertThat( new SMAPIProcessor().isSchemaValid( "admin_CPAggregate", "200", response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;
            case "GENDER_FEMALE":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "gender: []", "gender: [\\\"FEMALE\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "GENDER_MALE":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "gender: []", "gender: [\\\"MALE\\\", \\\"NOT_SPECIFIED\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "MIGRANT":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "migrantStatus: []", "migrantStatus: [\\\"MIGRANT\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "NON_MIGRANT":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "migrantStatus: []", "migrantStatus: [\\\"NON_MIGRANT\\\", \\\"NOT_SPECIFIED\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SOCIO_ECONOMICALLY":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "socioeconomicStatus: []", "socioeconomicStatus: [\\\"ECONOMICALLY_DISADVANTAGED\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "ADDITIONALGROUPING":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                Log.message( "payload=" + payload );
                payload = payload.replace( "Math", "Reading" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "DISABILITY":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload.replace( "disabilityStatus: []", "disabilityStatus: [\\\"YES\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "VALID_DIST_ADMIN":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "VALID_SCHOOL_ADMIN":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a72019a7f90ca06017fb5b542c41014\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff623ad7bbbaa845002e41ff17\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "filterBySchool: []", "filterBySchool: [\\\"8a72019a7f90ca06017fb5b542c41014\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "sm_hb_flexAdmin001", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72019a7f90ca06017fb5b542c41014" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff623ad7bbbaa845002e41ff17" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "VALID_SUBDIST_ADMIN":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a72019a7f90ca06017f962de1830086\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff621dc51a4d2d9c00307dc3db\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "filterBySchool: []", "filterBySchool: [\\\"8a72019a7f90ca06017f96302efb008e\\\"]" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "basicsubdistrictadmin2", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72019a7f90ca06017f962de1830086" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff621dc51a4d2d9c00307dc3db" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "NO_DATA_DIST_ADMIN":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7206a97f2c9d3a017f4e63bd3e07f4\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62827b20941f11002f36a47d\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "filterBySchool: []", "filterBySchool: [\\\"8a72003b8113cc8201811baa1ad00b96\\\"]" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "rvc_subdist_admin", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7206a97f2c9d3a017f4e63bd3e07f4" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62827b20941f11002f36a47d" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "NO_ADDITIONAL_GROUPING":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "filterBySchool: []", "filterBySchool: [\\\"8a72003b8113cc8201811baa1ad00b96\\\"]" );
                payload = payload.replace( "additionalGrouping: 2", "additionalGrouping: -1" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "DISABILITY_STATUS_NO":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "disabilityStatus: []", "disabilityStatus: [\\\"No\\\", \\\"Not Specified\\\"]" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "LANGUAGE_PROFICIENCY_ENGLISH":
                payload = getPayload( "CPAAdminReportData" );
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485321a067c\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c2d41aeef50900329a47ff\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                Log.message( "payload=" + payload );
                payload = payload.replace( "englishLanguageProficiency: []", "englishLanguageProficiency: [\\\"English\\\"]" );
                Log.message( "payload1=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "schooladminauto_rvc", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a7200f77de565ac017e2485321a067c" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c2d41aeef50900329a47ff" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.softAssertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @Test ( dataProvider = "getCPAggregateReportNegativeScenario", groups = { "SMK-61278 GraphQL API for CP AggregateReport Admin", "API" }, priority = 1 )
    public void getCPAggregateReportNegativeScenarios( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();

        String payload = getPayload( "CPAAdminReportData" );
        String query;
        Response response = null;
        String responseStatusCode = "";
        switch ( scenarioType ) {
            case "EMPTY_ORG_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, " " );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c301ea5dae540030f8fa3f\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "smdistrictadmin", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72042d81a3e1270181c53f3006007f" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c301ea5dae540030f8fa3f" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                Log.softAssertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", "400", response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "EMPTY_USER_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a72042d81a3e1270181c53f3006007f\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "smdistrictadmin", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72042d81a3e1270181c53f3006007f" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c301ea5dae540030f8fa3f" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                Log.softAssertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", "400", response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "EMPTY_FILTER_BY_SCHOOL":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a72042d81a3e1270181c53f3006007f\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c301ea5dae540030f8fa3f\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_AR_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "filterBySchool: []", "filterBySchool: []" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "smdistrictadmin", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72042d81a3e1270181c53f3006007f" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c301ea5dae540030f8fa3f" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "INVALID_SUBJECT_TYPE":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a72042d81a3e1270181c53f3006007f\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c301ea5dae540030f8fa3f\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "subject: \\\"Reading\\\"\\n", "subject: \\\"INVALID_SUBJECT_TYPE\\\"\\n" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "smdistrictadmin", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72042d81a3e1270181c53f3006007f" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c301ea5dae540030f8fa3f" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                Log.softAssertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", "400", response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "EMPTY_ADDITIONAL_GROUPING":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a72042d81a3e1270181c53f3006007f\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff62c301ea5dae540030f8fa3f\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                payload = payload.replace( "additionalGrouping: 2\\n", "additionalGrouping: []\\n" );
                Log.message( "payload=" + payload );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "smdistrictadmin", "password1" ) );
                headers.put( Constants.ORGID_SM_HEADER, "8a72042d81a3e1270181c53f3006007f" );
                headers.put( Constants.USERID_SM_HEADER, "ffffffff62c301ea5dae540030f8fa3f" );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                Log.message( "response=" + response.getBody().asString() );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                Log.softAssertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", "400", response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "WITHOUT_TOKEN":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                //responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_ORG_ID":
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_USER_ID":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_FILTER_PARAM":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "INVALID_START_DATE":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER.replace( "2022-03-29", ReportAPIConstants.INVALID ) );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;

            case "INVALID_END_DATE":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER.replace( "2022-04-30", ReportAPIConstants.INVALID ) );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;

            case "SUBJECT_MATH":
                queryItem.put( ReportAPIConstants.ORGANIZATION_ID, "\\\"8a7200f77de565ac017e2485554d0684\\\"" );
                queryItem.put( ReportAPIConstants.USER_ID, "\\\"ffffffff620cdd5cfe4bbc00309e6288\\\"" );
                queryItem.put( ReportAPIConstants.FILTER_PARAMS, ReportAPIConstants.CP_REPORT_ADMIN_FILTER.replace( Constants.READING, Constants.MATH ) );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.CP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "districtadmin_rvc", "password1" ) );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.softAssertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getCPAggregateReportPositiveScenario() {
        return new Object[][] { { "TC001", "200", "Verify the 200 status code and valid reponse for the district admin credential.", "VALID_DIST_ADMIN" },
                { "TC002", "200", "Verify the 200 status code and valid reponse for the school admin credential.", "VALID_SCHOOL_ADMIN" },
                { "TC003", "200", "Verify the 200 status code and valid reponse for the subdistrict admin credential.", "VALID_SUBDIST_ADMIN" },
                { "TC004", "200", "Verify the 200 Status code and zero state response, if the students are not started the selected assignments", "NO_DATA_DIST_ADMIN" },
                { "TC009", "200", "Verify the 200 Status code and  the output response , while passing any one organization Id with additionalGrouping as None, Math subject and Math assignment id", "NO_ADDITIONAL_GROUPING" },
                { "TC011", "200", "Verify the 200 Status code and  the output response , while pass the required filters with disability status as 'No' and  'Not Specified' (multiple options)", "DISABILITY_STATUS_NO" },
                { "TC012", "200", "Verify the 200 Status code and  the output response , while pass the required filters with English language Proficiency as 'English' (single option)", "LANGUAGE_PROFICIENCY_ENGLISH" },
                { "TC013", "200", "Verify the status code 200 for response body for providing english Language Proficiency as 'English language learner' and  'Not specified  in request body", "LANGUAGE_PROFICIENCY" },
                { "TC014", "200", "Verify the status code 200 for response body for providing gender as 'Female' in request body", "GENDER_FEMALE" },
                { "TC015", "200", "Verify the status code 200 for response body for providing gender as 'Female' in request body", "GENDER_MALE" },
                { "TC016", "200", "Verify the status code 200 for response body for providing gender as 'Female' in request body", "MIGRANT" },
                { "TC017", "200", "Verify the status code 200 for response body for providing gender as 'Female' in request body", "NON_MIGRANT" },
                { "TC018", "200", "Verify the status code 200 for response body for providing gender as 'Female' in request body", "SOCIO_ECONOMICALLY" }

        };
    }

    @DataProvider
    public Object[][] getCPAggregateReportNegativeScenario() {
        return new Object[][] { { "TC022", "400", "Verify the status code 400 for response body for not providing token in header", "WITHOUT_TOKEN" },
                { "TC023", "400", "Verify the status code 400 for response body for not providing orgId in request body", "WITHOUT_ORG_ID" },
                { "TC024", "400", "Verify the status code 400 for response body for not providing userId in request body", "WITHOUT_USER_ID" },
                { "TC005", "400", "Verify the status code 400 for response body for not providing filterParam in request body", "WITHOUT_FILTER_PARAM" },
                { "TC025", "400", "Verify the message in the response when organizationId passed as empty array.", "EMPTY_ORG_ID" }, { "TC026", "400", "Verify the message in the response when userId passed as empty array.", "EMPTY_USER_ID" },
                { "TC027", "200", "Verify the message in the response when organizationId passed as empty array in filterBySchool", "EMPTY_FILTER_BY_SCHOOL" },
                { "TC028", "400", "Verify the message in the response when invalid subject type passed in the query.", "INVALID_SUBJECT_TYPE" },
                { "TC029", "400", "Verify the message in the response when additionalGrouping passed as empty array.", "EMPTY_ADDITIONAL_GROUPING" }

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload( String filename ) throws IOException {

        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + filename + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }
}
