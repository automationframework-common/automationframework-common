package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class CPRAdminInputPageMockTest extends EnvProperties {
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String configGraphQL;
    private String firstTeacherUserName;
    private String secondTeacherUserName;
    private String firstTeacherOrgID;
    private String firstTeacherId;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    RBSUtils rbsUtils = new RBSUtils();
    private String distAdminUserName;
    private String distId;
    private String distAdminuserId;
    private String reportUrl;

    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) throws Exception {

        configGraphQL = configProperty.getProperty( "AdminReportBFFGraphQL" );
        browser = "Windows_10_Chrome_100";
        reportUrl = configProperty.getProperty( "CPRAdminReportMFE" );

        // Teacher UserNames
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        //Selected School Name
        firstTeacherOrgID = ReportData.orgId;

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

    }

    @Test ( description = "Verify LS input screen & UI validation - Mock OrganizationListMax", groups = { "Smoke", "SMK-67110", "CP - Admin Input Page", "Reports", "CP report", "mock" }, priority = 1 )
    public void tcCPRInputMock001( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify LS input screen & UI validation - Mock OrganizationListMax<small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMax.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalOrgz = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            totalOrgz.size();
            Log.message( "totalOrgzMax: " + totalOrgz + " SizeMax: " + totalOrgz.size() );

            String orgName = "Chiefs_Test_Org_1";
            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            Log.assertThat( totalOrgz.contains( orgName ), "Expected orgName is displayed, Mock Passed:)", "Expected orgName is not displayed, Mock Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify LS input screen & UI validation - Mock OrganizationListMin", groups = { "Smoke", "SMK-67110", "CP - Admin Input Page", "Reports", "CP report", "mock" }, priority = 1 )
    public void tcCPRInputMock002( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify LS input screen & UI validation - Mock OrganizationListMin <small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMin.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalOrgz = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            totalOrgz.size();
            Log.message( "totalOrgMin: " + totalOrgz + " SizeMin: " + totalOrgz.size() );

            String orgName = "Chiefs_Test_Org_1";
            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( orgName ) );
            Log.assertThat( totalOrgz.contains( orgName ), "Expected orgName is displayed, Mock Passed:)", "Expected orgName is not displayed, Mock Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify LS input screen & UI validation - Mock OrganizationList - Zero State", groups = { "Smoke", "SMK-67110", "CP - Admin Input Page", "Reports", "CP report", "mock" }, priority = 1 )
    public void tcCPRInputMock003( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify LS input screen & UI validation - Mock OrganizationList - Zero State <small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListZeroState.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            try {
                List<String> totalOrgz = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
                totalOrgz.size();
                Log.message( "totalOrgZeroState: " + totalOrgz + " SizeZeroState: " + totalOrgz.size() );
                Log.assertThat( totalOrgz.size() == 1, "Zero state orgList mocked, Test passed:)", "Zero state orgList not mocked, Test Failed:(" );
            } catch ( Exception e ) {
                // TODO: handle exception
                String actualException = e.toString();
                Log.message( "actualException: " + actualException );
                Log.assertThat( actualException.contains( ReportsUIConstants.JS_EXECUTION_EXCEPTION), "Zero state mock verfied, Test passed:)", "Zero state mock not verfied, Test Failed:(" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock004( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax"+ " <small><b><i>[" + browser + "]</b></i></small>" );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMin.json" );
                String getAllReportOption = DevToolsUtils.readJsonResponse( "CPRAdminInputGetAllReportOptionsMax.json" );
                responses.put( "GetOrganizationList", getOrganizationList );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList", "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option label is displayed and it is verified",
                    "The CP Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ),
                    "The CP Save Report Option label text is displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS,
                    "The CP Save Report Option label text is not displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the CP page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option drop down is displayed and it is verified",
                    "The CP Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option drop down arrow is displayed and it is verified",
                    "The CP Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cpReport.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersMax: " + totalFilters + " SizeMax: " + totalFilters.size() );

            SMUtils.logDescriptionTC( "TC:16 Verify the Saved report option name is displayed when it is selected" );
            String filterName = "Chiefs_Filter_1";
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );

            List<String> mockedFilterNames = cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( mockedFilterNames.contains( filterName ), "Mocked Filter name is displayed, Test passed:)", "Mocked Filter name is not displayed, Test Failed:(" );
            Log.assertThat( totalFilters.size()>= 1001, "Save Report Max successfully mocked, Test Passed:)", "Save Report Max not mocked, Test Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }


    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMin", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock005( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMin"+" <small><b><i>[" + browser + "]</b></i></small>" );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMax.json" );
                String getAllReportOption = DevToolsUtils.readJsonResponse( "CPRAdminInputGetAllReportOptionsMin.json" );
                responses.put( "GetOrganizationList", getOrganizationList );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList", "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option label is displayed and it is verified",
                    "The CP Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ),
                    "The CP Save Report Option label text is displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS,
                    "The CP Save Report Option label text is not displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the CP page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option drop down is displayed and it is verified",
                    "The CP Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option drop down arrow is displayed and it is verified",
                    "The CP Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cpReport.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersMin: " + totalFilters + " SizeMin: " + totalFilters.size() );

            SMUtils.logDescriptionTC( "TC:16 Verify the Saved report option name is displayed when it is selected" );
            String filterName = "Chiefs_Filter_1";
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );

            List<String> mockedFilterNames = cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( mockedFilterNames.contains( filterName ), "Mocked Filter name is displayed, Test passed:)", "Mocked Filter name is not displayed, Test Failed:(" );
            Log.assertThat( totalFilters.size()>= 2, "Save Report Min successfully mocked, Test Passed:)", "Save Report Min not mocked, Test Failed:(" );

        } catch (Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }



    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptions - Zero State", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock006( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptions - Zero State <small><b><i>[" + browser + "]</b></i></small>" );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;
        try {

            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOrganizationListMin.json" );
                String getAllReportOption = DevToolsUtils.readJsonResponse( "CPRAdminInputGetAllReportOptionsZeroState.json" );
                responses.put( "GetOrganizationList", getOrganizationList );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList", "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option label is displayed and it is verified",
                    "The CP Save Report Option label is not displayed and it is verified" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ),
                    "The CP Save Report Option label text is displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS,
                    "The CP Save Report Option label text is not displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the CP page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option drop down is displayed and it is verified",
                    "The CP Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The CP Save Report Option drop down arrow is displayed and it is verified",
                    "The CP Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( cpReport.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersZeroState: " + totalFilters + " SizeZeroState: " + totalFilters.size() );
            Log.assertThat( totalFilters.size()>= 1, "Save Report Zero State successfully mocked, Test Passed:)", "Save Report Zero State not mocked, Test Failed:(" );


        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }


    @Test ( description = "Verify the subject label and drop down(Read) - Mock - getCourseList - Max", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock007( ITestContext context ) throws Exception {

        // Get driver
        Log.testCaseInfo( "Verify the subject label and drop down(Read) - Mock - getCourseList - Max <small><b><i>[" + browser + "]</b></i></small>" );
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:07 Verify the Subject label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:08 Verify the Subject drop down is displayed in the CP report Page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getCourseList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetCourseListReadMax.json" );
                responses.put( "GetCourseList", getCourseList );

                List<String> requestPayloadMatchers = Arrays.asList(  "GetCourseList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:10 Verify the drop down values of the Subject drop down values" );
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.READING );
            Log.testCaseResult();

            List<String> readCourses = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.message( "readCourses: " + readCourses );
            Log.message( "Read CourseMax Size: " + readCourses.size() );
            Log.assertThat( readCourses.size() >= 1001, "Mocked CourseList(ReadMax) is displayed, Test Passed:)", "Mocked CourseList(ReadMax) is not displayed, Test Failed:(" );

            try {
                cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( "Reading" , "Reading2", "Reading3", "Reading4"));
                List<String>  selectedUIValues = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CPR_COURSES_LABEL );
                Log.message( "selectedUIValues: "+selectedUIValues );
                List<String> actualValues = Arrays.asList( "Reading" , "Reading2", "Reading3", "Reading4");
                Log.assertThat( selectedUIValues.containsAll( actualValues ), "Selected course values are matched, Test Pass:)", "Selected course values are not matched, Test Fail:)" );
                Log.pass( "Mocked course is selected in UI, Test passed!!" );

            } catch ( Exception e ) {
                Log.fail( "Mocked course is not selected in UI, Test Failed!!" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }



    @Test ( description = "Verify the subject label and drop down(Read) - Mock - getCourseList - Min", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock008( ITestContext context ) throws Exception {

        // Get driver
        Log.testCaseInfo( "Verify the subject label and drop down(Read) - Mock - getCourseList - Min <small><b><i>[" + browser + "]</b></i></small>" );
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:07 Verify the Subject label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:08 Verify the Subject drop down is displayed in the CP report Page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getCourseList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetCourseListReadMin.json" );
                responses.put( "GetCourseList", getCourseList );

                List<String> requestPayloadMatchers = Arrays.asList(  "GetCourseList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:10 Verify the drop down values of the Subject drop down values" );
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.READING );
            Log.testCaseResult();

            List<String> readCourses = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.message( "readCourses: " + readCourses );
            Log.message( "Read CourseMin Size: " + readCourses.size() );

            Log.assertThat( readCourses.size() >= 2, "Mocked CourseList(ReadMax) is displayed, Test Passed:)", "Mocked CourseList(ReadMax) is not displayed, Test Failed:(" );
            try {
                cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.READING ));
                List<String>  selectedUIValues = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CPR_COURSES_LABEL );
                selectedUIValues.remove( 0 ); // Removing 'Select All' option from the course List
                List<String> actualValues = Arrays.asList( Constants.READING );
                Log.assertThat( selectedUIValues.containsAll( actualValues ), "Selected course values are matched, Test Pass:)", "Selected course values are not matched, Test Fail:)" );
                Log.pass( "Mocked course is selected in UI, Test passed!!" );
            } catch ( Exception e ) {
                Log.fail( "Mocked course is not selected in UI, Test Failed!!" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }
    }



    @Test ( description = "Verify the subject label and drop down - Mock - getCourseList - Zero State", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock009( ITestContext context ) throws Exception {

        // Get driver
        Log.testCaseInfo( "Verify the subject label and drop down(Read) - Mock - getCourseList - Zero State <small><b><i>[" + browser + "]</b></i></small>" );
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:07 Verify the Subject label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:08 Verify the Subject drop down is displayed in the CP report Page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getCourseList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetCourseListZeroState.json" );
                responses.put( "GetCourseList", getCourseList );

                List<String> requestPayloadMatchers = Arrays.asList(  "GetCourseList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:10 Verify the drop down values of the Subject drop down values" );
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.READING );
            Log.testCaseResult();

            try {
                List<String> readCourses = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
                Log.message( "ZeroStateCourses: " + readCourses );
                Log.message( "CourseList ZeroState Size: " + readCourses.size() );
            } catch ( Exception e ) {
                // TODO: handle exception
                String actualException = e.toString();
                Log.message( "actualException: " + actualException );
                Log.assertThat( actualException.contains( ReportsUIConstants.JS_EXECUTION_EXCEPTION), "Zero state mock verfied, Test passed:)", "Zero state mock not verfied, Test Failed:(" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }
    }


    @Test ( description = "Verify the subject label and drop down(Math) - Mock - getCourseList - Max", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock010( ITestContext context ) throws Exception {

        // Get driver
        Log.testCaseInfo( "Verify the subject label and drop down(Math) - Mock - getCourseList - Max <small><b><i>[" + browser + "]</b></i></small>" );
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:07 Verify the Subject label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:08 Verify the Subject drop down is displayed in the CP report Page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getCourseList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetCourseListMathMax.json" );
                responses.put( "GetCourseList", getCourseList );

                List<String> requestPayloadMatchers = Arrays.asList(  "GetCourseList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:10 Verify the drop down values of the Subject drop down values" );
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.MATH );
            Log.testCaseResult();

            List<String> mathCourses = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.message( "mathCourses: " + mathCourses );
            Log.message( "Math CourseMax Size: " + mathCourses.size() );
            Log.assertThat( mathCourses.size() >= 1001, "Mocked CourseList is displayed, Test Passed:)", "Mocked CourseList is not displayed, Test Failed:(" );
            try {
                cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( "Math3" , "Math7", "Math4", "Math5", "Math6" ));
                List<String>  selectedUIValues = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CPR_COURSES_LABEL );
                Log.message( "selectedUIValues: " + selectedUIValues );
                List<String> actualValues = Arrays.asList( "Math3" , "Math7", "Math4", "Math5", "Math6" );
                Log.assertThat( selectedUIValues.containsAll( actualValues ), "Selected course values are matched, Test Pass:)", "Selected course values are not matched, Test Fail:)" );
                Log.pass( "Mocked course is selected in UI, Test passed!!" );
            } catch ( Exception e ) {
                Log.fail( "Mocked course is not selected in UI, Test Failed!!" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }



    @Test ( description = "Verify the subject label and drop down(Math) - Mock - getCourseList - Min", groups = { "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report", "mock" }, priority = 1 )
    public void tcCPRInputMock011( ITestContext context ) throws Exception {

        // Get driver
        Log.testCaseInfo( "Verify the subject label and drop down(Math) - Mock - getCourseList - Min <small><b><i>[" + browser + "]</b></i></small>" );
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of CP page is displayed" );
            Log.assertThat( cpReport.reportFilterComponent.isReportTitleDisplayed(), "The CP title is displayed and it is verified", "The CP title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isReportDescriptionDisplayed(), "The CP description is displayed and it is verified", "The CP description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the CP Page" );
            Log.assertThat( cpReport.reportFilterComponent.isHelpIconDisplayed(), "The CP help icon is displayed and it is verified", "The CP help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:06 Verify the Course Selection label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:07 Verify the Subject label is displayed in the CP report page" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( cpReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:08 Verify the Subject drop down is displayed in the CP report Page" );
            Log.assertThat( cpReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getCourseList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetCourseListMathMin.json" );
                responses.put( "GetCourseList", getCourseList );

                List<String> requestPayloadMatchers = Arrays.asList(  "GetCourseList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:10 Verify the drop down values of the Subject drop down values" );
            cpReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, Constants.READING );
            Log.testCaseResult();

            List<String> mathCourses = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            Log.message( "mathCourses: " + mathCourses );
            Log.message( "Math CourseMin Size: " + mathCourses.size() );
            Log.assertThat( mathCourses.size() >= 2, "Mocked CourseList is displayed, Test Passed:)", "Mocked CourseList is not displayed, Test Failed:(" );
            try {
                cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( Constants.MATH ));
                List<String>  selectedUIValues = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CPR_COURSES_LABEL );
                selectedUIValues.remove( 0 ); // Removing 'Select All' option from the course List
                List<String> actualValues = Arrays.asList( Constants.MATH );
                Log.assertThat( selectedUIValues.containsAll( actualValues ), "Selected course values are matched, Test Pass:)", "Selected course values are not matched, Test Fail:)" );
                Log.pass( "Mocked course is selected in UI, Test passed!!" );
            } catch ( Exception e ) {
                Log.fail( "Mocked course is not selected in UI, Test Failed!!" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }
    }



    @Test ( description = "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Max", groups = { "Smoke", "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report" , "mock" }, priority = 1 )
    public void tcCPRInputMock012( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            Log.testCaseInfo( "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Max <small><b><i>[" + browser + "]</b></i></small>" );

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOptionalFilters = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOptionalFiltersMax.json" ).replace( "orgId", firstTeacherOrgID );
                responses.put( "GetOptionalFilters", getOptionalFilters );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOptionalFilters" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            cpReport.reportFilterComponent.expandOptionalFilter();
            
            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getGroupList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetGroupsListMax.json" ).replace( "orgId", firstTeacherOrgID );
                responses.put( "GetGroupList", getGroupList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetGroupList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:18 Verify Teacher Dropdown should display under CP Report " );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.TEACHER_LABEL ), "Teacher dropdown label is displayed under CPR", "Teacher dropdown label is not displayed under CPR!" );
            List<String> tecValues = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValuesMax: " + tecValues + "  sizeMax: "+ tecValues.size() );
            Log.assertThat( tecValues.size() >= 1001, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:)" );
            tecValues.remove( "Select All" );
            Collections.sort( tecValues );

            String selectedTeacherName1 = tecValues.get( 0 );
            String selectedTeacherName2 = tecValues.get( 1 );
            String selectedTeacherName3 = tecValues.get( 2 );
            String selectedTeacherName4 = tecValues.get( 3 );
            String selectedTeacherName5 = tecValues.get( 4 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.TEACHER_LABEL , Arrays.asList( selectedTeacherName1, selectedTeacherName2, selectedTeacherName3, selectedTeacherName4, selectedTeacherName5 ) );
            List<String> selectedValuesTec = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "selectedValuesTec: " + selectedValuesTec );
            List<String> actualValuesTec = Arrays.asList( selectedTeacherName1, selectedTeacherName2, selectedTeacherName3, selectedTeacherName4, selectedTeacherName5 );
            Log.message( "actualValuesTec: " + actualValuesTec );
            Log.assertThat( selectedValuesTec.containsAll( actualValuesTec ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:19 Verify Group Dropdown should display under CP Report" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CP_GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            List<String> grpValues = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "grpValuesMax: " + grpValues + "  sizeMax: "+ grpValues.size());
            Log.assertThat( grpValues.size() >= 1001, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:)" );
            grpValues.remove( "Select All" );
            Collections.sort( grpValues );

            String selectedGroupName1 = grpValues.get(0);
            String selectedGroupName2 = grpValues.get(1);
            String selectedGroupName3 = grpValues.get(2);
            String selectedGroupName4 = grpValues.get(3);
            String selectedGroupName5 = grpValues.get(4);

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.CP_GROUP_LABEL , Arrays.asList( selectedGroupName1, selectedGroupName2, selectedGroupName3, selectedGroupName4, selectedGroupName5 ) );
            List<String> selectedValues = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "selectedValues: " + selectedValues );
            List<String> actualValues = Arrays.asList( selectedGroupName1, selectedGroupName2, selectedGroupName3, selectedGroupName4, selectedGroupName5);
            Log.message( "actualValues: " + actualValues );
            Log.assertThat( selectedValues.containsAll( actualValues ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:20 Verify Grade Dropdown should display under CP Report" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.GRADE_LABEL ), "Grade header is displaying", "Grade header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:21 Verify Additional Grouping Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:26 Verify all field available under additional grouping dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:22 Verify Display Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:27 Verify all field available under Display dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:24 Verify Sort Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:28 Verify all field available under Sort dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "Sort Label header is displaying", "Sort Label header is not displaying:(" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).containsAll( ReportsUIConstants.SORT_lIST ), "All the sort option are displaying as expected",
                    "Sort option values are not displaying as expected!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test ( description = "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Min", groups = { "Smoke", "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report" , "mock" }, priority = 1 )
    public void tcCPRInputMock013( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            Log.testCaseInfo( "Verify all field available under Optional Filters field - Mock -getOptionalFilters - Min <small><b><i>[" + browser + "]</b></i></small>" );

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOptionalFilters = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOptionalFiltersMin.json" ).replace( "orgId", firstTeacherOrgID );
                responses.put( "GetOptionalFilters", getOptionalFilters );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOptionalFilters" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList(RBSDataSetup.getSchools( Schools.FLEX_SCHOOL )));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            cpReport.reportFilterComponent.expandOptionalFilter();
            
            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getGroupList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetGroupsListMin.json" ).replace( "orgId", firstTeacherOrgID );
                responses.put( "GetGroupList", getGroupList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetGroupList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:18 Verify Teacher Dropdown should display under CP Report " );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.TEACHER_LABEL ), "Teacher dropdown label is displayed under CPR", "Teacher dropdown label is not displayed under CPR!" );
            List<String> tecValues = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValuesMin: " + tecValues + "  sizeMin: "+ tecValues.size() );
            Log.assertThat( tecValues.size() >= 2, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:)" );

            String selectedTeacherName = tecValues.get( 1 );
            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.TEACHER_LABEL , Arrays.asList( selectedTeacherName ) );
            List<String> selectedValuesTec = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.TEACHER_LABEL );
            selectedValuesTec.remove( 0 ); // Removing the 'Select All' option from list
            Log.message( "selectedValuesTec: " + selectedValuesTec );
            List<String> actualValuesTec = Arrays.asList( selectedTeacherName );
            Log.message( "actualValuesTec: " + actualValuesTec );
            Log.assertThat( selectedValuesTec.containsAll( actualValuesTec ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:19 Verify Group Dropdown should display under CP Report" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CP_GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            List<String> grpValues = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "grpValuesMin: " + grpValues + "  sizeMin: "+ grpValues.size() );
            Log.assertThat( grpValues.size() >= 2, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:)" );

            String selectedGroupName = grpValues.get( 1 );
            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.CP_GROUP_LABEL , Arrays.asList( selectedGroupName ) );
            List<String> selectedValues = cpReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CP_GROUP_LABEL );
            selectedValues.remove( 0 ); // Removing the 'Select All' option from list
            Log.message( "selectedValues: " + selectedValues );
            List<String> actualValues = Arrays.asList( selectedGroupName );
            Log.message( "actualValues: " + actualValues );
            Log.assertThat( selectedValues.containsAll( actualValues ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:20 Verify Grade Dropdown should display under CP Report" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.GRADE_LABEL ), "Grade header is displaying", "Grade header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:21 Verify Additional Grouping Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:26 Verify all field available under additional grouping dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:22 Verify Display Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:27 Verify all field available under Display dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:24 Verify Sort Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:28 Verify all field available under Sort dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "Sort Label header is displaying", "Sort Label header is not displaying:(" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).containsAll( ReportsUIConstants.SORT_lIST ), "All the sort option are displaying as expected",
                    "Sort option values are not displaying as expected!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test ( description = "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Zero State", groups = { "Smoke", "SMK-67110", "CP - Admin Input Page", "Reports", "CP Report" , "mock" }, priority = 1 )
    public void tcCPRInputMock014( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        CumulativePerformancePage cpReport = new CumulativePerformancePage( driver );
        DevTools tools = null;

        try {

            Log.testCaseInfo( "Verify all field available under Optional Filters field - Mock -getOptionalFilters - Zero State <small><b><i>[" + browser + "]</b></i></small>" );

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOptionalFilters = DevToolsUtils.readJsonResponse( "CPRAdminInputGetOptionalFiltersZeroState.json" );
                responses.put( "GetOptionalFilters", getOptionalFilters );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOptionalFilters" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            cpReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ));
            cpReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            cpReport.reportFilterComponent.expandOptionalFilter();
            
            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getGroupList = DevToolsUtils.readJsonResponse( "CPRAdminInputGetGroupsListZeroState.json" );
                responses.put( "GetGroupList", getGroupList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetGroupList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:18 Verify Teacher Dropdown should display under CP Report " );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.TEACHER_LABEL ), "Teacher dropdown label is displayed under CPR", "Teacher dropdown label is not displayed under CPR!" );
            List<String> tecValues = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValuesZeroState: " + tecValues + " sizeZeroState: " + tecValues.size() );
            Log.assertThat( tecValues.size()>=1, "Mock zero state verified, Test passed:)", "Mock zero state not verified, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:19 Verify Group Dropdown should display under CP Report" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CP_GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            List<String> grpValues = cpReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "grpValuesZeroState: " + grpValues +  " sizeZeroState: " + grpValues.size());
            Log.assertThat( grpValues.size()>=1, "Mock zero state verified, Test passed:)", "Mock zero state not verified, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:20 Verify Grade Dropdown should display under CP Report" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.GRADE_LABEL ), "Grade header is displaying", "Grade header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:21 Verify Additional Grouping Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:26 Verify all field available under additional grouping dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:22 Verify Display Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:27 Verify all field available under Display dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).containsAll( ReportsUIConstants.DISPLAY ), "All the display option are displaying",
                    "Display option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:24 Verify Sort Dropdown should display under CP Report" );
            SMUtils.logDescriptionTC( "TC:28 Verify all field available under Sort dropdown" );
            Log.assertThat( cpReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "Sort Label header is displaying", "Sort Label header is not displaying:(" );
            cpReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            Log.assertThat( cpReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).containsAll( ReportsUIConstants.SORT_lIST ), "All the sort option are displaying as expected",
                    "Sort option values are not displaying as expected!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}