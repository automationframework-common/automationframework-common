package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class CumulativePerformanceAggregateTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass(alwaysRun=true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the user can navigates to Cumulativer Performance Aggregate page", groups = { "Smoke", "SMK-57814", "CumulativePerformanceAggregateReport", "studentDemographics" }, priority = 1 )
    public void tcCPRAggregateStudentDemographics001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateStudentDemographics001: Verify the user can navigates to Cumulativer Performance Aggregate page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            //navigate to Cumulative Performance sub menu
            SMUtils.logDescriptionTC( "Verify the Cumulative Performance Menu is available in Sub Navigation menu" );
            Log.assertThat( dashBoardPage.reportFilterComponent.subNavigationMenuisDisplayed( ReportTypes.CUMULATIVE_PERFORMANCE ), "The Cumulative Performance is displayed in Report MFE sub-navigation",
                    "The Cumulative Performance is displayed in Report MFE sub-navigation" );
            Log.testCaseResult();

            //navigate to Cumulative Performance Aggregate 
            SMUtils.logDescriptionTC( "Verify the user should navigates to Cumulative Performance Aggregate page" );
            Log.assertThat( CPAReport.isCPAReportSelected(), "The user navigates to Cumulative Performance Aggregate page successfully!", " The user not navigates to Cumulative Performance Aggregate page properly!" );

            SMUtils.logDescriptionTC( "Verify Student Demographics label is displayed in the Cumulative Performance Aggregate Page" );
            CPAReport.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( CPAReport.reportFilterComponent.getStudentDemographicsLabel().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly",
                    "Student demographics label not displayed properly. Expected - " );

            //Expand the student demographics 
            SMUtils.logDescriptionTC( "Verify the Disability Status, Gender, Race, SocioEconomic Status, English Language Proficiency, Migrant Status, Ethnicity, Special seivices option are displayed under the Student demographics field" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly", "Issue in display th Disability status dropdown label!" );
            //Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GENDER ), "Gender dropdown label is displayed properly", "Issue in display th Gender dropdown label!" );
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display th Race dropdown label!" );
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly", "Issue in display the SocioEconomic Status dropdown label!" );
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English Language Proficiency dropdown label is displayed properly",
                    "Issue in display the English Language Proficiency dropdown label!" );
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), "Migrant Status dropdown label is displayed properly", "Issue in display the Migrant Status dropdown label!" );
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );
            Log.assertThat( CPAReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special seivices option dropdown label is displayed properly",
                    "Issue in display the Special seivices option dropdown label!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics availbility of Disability status & Gender dropdown", groups = { "SMK-57814", "CumulativePerformanceAggregateReport", "studentDemographics" }, priority = 1 )
    public void tcCPRAggregateStudentDemographics002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateStudentDemographics002: Verify the Student demographics availbility of Disability status & Gender dropdown<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            //Disability status dropdown
            SMUtils.logDescriptionTC( "Verify the Disability status dropdown option contains values" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).containsAll( ReportsUIConstants.DISABILITY_STATUS_OPTIONS ),
                    "ALL options properly in disability status are displayed successfully!", "ALL options properly in disability status are not displayed properly" );

            //Selecting all option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select all option in Disability status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).containsAll( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );

            //deselect all option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the Disability status drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in disability status dropdown!", "Issue in deselecting all the option in disability status dropdown!" );
            Log.testCaseResult();

            //Selecting single option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in Disability status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in disability status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in Disability status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            Log.assertThat(
                    CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

            //Gender dropdown
            SMUtils.logDescriptionTC( "Verify the Gender dropdown option contains values" );
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).containsAll( ReportsUIConstants.GENDER_OPTIONS ), "ALL options properly in gender are displayed successfully!",
                    "ALL options properly in gender are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in Gender drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).containsAll( ReportsUIConstants.GENDER_OPTIONS.subList( 1, 4 ) ), "User able to select the all option in gender dropdown",
                    "Issue in selecting the option in gender dropdown!" );

            //deselect all option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the Gender drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ), "User able to deselect all the option in gender dropdown!",
                    "Issue in deselecting all the option in gender dropdown!" );
            Log.testCaseResult();

            //Selecting single option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in Gender drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.GENDER );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in gender dropdown", "Issue in selecting the option in gender dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in gender dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in Gender drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER, Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ), ReportsUIConstants.GENDER_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.GENDER );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.GENDER ).equals( Arrays.asList( ReportsUIConstants.GENDER_OPTIONS.get( 1 ), ReportsUIConstants.GENDER_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in gender dropdown", "Issue in selecting the option in gender dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics availbility of Race & SocioEconomic Status dropdown", groups = { "SMK-57814", "CumulativePerformanceAggregateReport", "studentDemographics" }, priority = 1 )
    public void tcCPRAggregateStudentDemographics003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateStudentDemographics003: Verify the Student demographics availbility of Race & SocioEconomic Status dropdown<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            //Race dropdown
            SMUtils.logDescriptionTC( "Verify the Race dropdown option contains values" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).containsAll( ReportsUIConstants.RACE_OPTIONS ), "ALL options properly in race are displayed successfully!",
                    "ALL options properly in race are not displayed properly" );

            //Selecting all option in race dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in race drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).containsAll( ReportsUIConstants.RACE_OPTIONS.subList( 1, 8 ) ), "User able to select the all option in race dropdown",
                    "Issue in selecting the option in race dropdown!" );

            //deselect all option in race dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the race drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ), "User able to deselect all the option in race dropdown!",
                    "Issue in deselecting all the option in race dropdown!" );
            Log.testCaseResult();

            //Selecting single option in race dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in race drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) ), "User able to select the single option in race dropdown",
                    "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in race dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in race drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in race dropdown", "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the Socioeconomic Status  dropdown option contains values" );
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS ),
                    "ALL options properly in SocioEconomic Status are displayed successfully!", "ALL options properly in SocioEconomic Status are not displayed properly" );

            //Selecting all option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in SocioEconomic Status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );

            //deselect all option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the SocioEconomic Status drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in SocioEconomic Status dropdown!", "Issue in deselecting all the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //Selecting single option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in SocioEconomic Status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in SocioEconomic Status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            Log.assertThat(
                    CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics availbility of English language proficiency & Migrant status dropdown", groups = { "SMK-57814", "CumulativePerformanceAggregateReport", "studentDemographics" }, priority = 1 )
    public void tcCPRAggregateStudentDemographics004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateStudentDemographics004: Verify the Student demographics availbility of English language proficiency & Migrant status dropdown<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            //English language proficiency dropdown
            SMUtils.logDescriptionTC( "Verify the English Language Proficiency dropdown option contains values" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS ),
                    "ALL options properly in english language proficiency are displayed successfully!", "ALL options properly in english language proficiency are not displayed properly" );

            //Selecting all option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in english language proficiency drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in english language proficiency dropdown", "Issue in selecting the option in english language proficiency dropdown!" );

            //deselect all option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the english language proficiency drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in english language proficiency dropdown!", "Issue in deselecting all the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //Selecting single option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in english language proficiency drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in english language proficiency dropdown", "Issue in selecting the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in english language proficiency drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.assertThat(
                    CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals(
                            Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in english language proficiency dropdown", "Issue in selecting the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //Migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the Migrant dropdown option contains values" );
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).containsAll( ReportsUIConstants.MIGRANT_STATUS_OPTIONS ),
                    "ALL options properly in migrant status are displayed successfully!", "ALL options properly in migrant status are not displayed properly" );

            //Selecting all option in migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in migrant status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).containsAll( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in migrant status dropdown", "Issue in selecting the option in migrant status dropdown!" );

            //deselect all option in migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the migrant status drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in migrant status dropdown!", "Issue in deselecting all the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Selecting single option in migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in migrant status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in migrant status dropdown", "Issue in selecting the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in migrant status dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in migrant status drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            Log.assertThat(
                    CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in migrant status dropdown ", "Issue in selecting the option in migrant status dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student demographics availbility of Ethnicity & Special services dropdown", groups = { "SMK-57814", "CumulativePerformanceAggregateReport", "studentDemographics" }, priority = 1 )
    public void tcCPRAggregateStudentDemographics005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRAggregateStudentDemographics005: Verify the Student demographics availbility of ethnicity & Special services dropdown<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            //Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the Ethnicity dropdown option contains values" );
            CPAReport.reportFilterComponent.expandStudentDemographics();
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).containsAll( ReportsUIConstants.ETHNICITY_OPTIONS ), "ALL options properly in ethnicity are displayed successfully!",
                    "ALL options properly in ethnicity are not displayed properly" );

            //Selecting all option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in Ethnicity drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).containsAll( ReportsUIConstants.ETHNICITY_OPTIONS.subList( 1, 3 ) ),
                    "User able to select the all option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );

            //deselect all option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the Ethnicity drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in Ethnicity dropdown!", "Issue in deselecting all the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Selecting single option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in Ethnicity drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in Ethnicity drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in Ethnicity dropdown ", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Special Services
            SMUtils.logDescriptionTC( "Verify the Special Services dropdown option contains values" );
            Log.assertThat( CPAReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS ),
                    "ALL options properly in special services are displayed successfully!", "ALL options properly in special services are not displayed properly" );

            //Selecting all option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select All option in Special Services drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.subList( 1, 7 ) ),
                    "User able to select the all option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );

            //deselect all option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the default text of the Special Services drop down when admin deselect all the option" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            Log.assertThat( CPAReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in Special Services dropdown!", "Issue in deselecting all the option in Special Services dropdown!" );
            Log.testCaseResult();

            //Selecting single option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select single option in Special Services drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            Log.assertThat( CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equals( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Special Services dropdown
            SMUtils.logDescriptionTC( "Verify the admin can select multiple option in Special Services drop down" );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL_OPTION ) );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );
            CPAReport.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            Log.assertThat(
                    CPAReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equals(
                            Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in Special Services dropdown ", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
