package com.savvas.sm.reports.bff.admin.tests;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicValues;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

import io.restassured.response.Response;

public class SEUReportAdminGraphQLTest extends EnvProperties {

    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String subDistAdminUserName;
    String subDistAdminUserId;
    String subDistId;
    String schoolUnderSubDistrictId;
    String schoolAdminUserName;
    String schoolAdminUserId;
    String adminSchoolId;
    String subjectName;
    String firstTeacherUserName;
    String secondTeacherUserName;
    String firstTeacherId;
    String secondTeacherId;
    String firstGroupId;
    String secondGroupId;
    String studentId;
    String studentAssignmentIdMath;
    String studentAssignmentIdReading;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        firstTeacherId = rbsUtils.getUserIDByUserName( firstTeacherUserName );
        secondTeacherId = rbsUtils.getUserIDByUserName( secondTeacherUserName );
        firstGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 0 ).toString(), "groupId" );
        secondGroupId = SMUtils.getKeyValueFromResponse( new JSONArray( ReportData.teacherGroupDetails.get( firstTeacherUserName ) ).get( 1 ).toString(), "groupId" );
        studentId = ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).keySet().toArray()[0].toString();
        studentAssignmentIdMath = SMUtils.getKeyValueFromResponse( ReportData.defaultMathAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );
        studentAssignmentIdReading = SMUtils.getKeyValueFromResponse( ReportData.defaultReadingAssignmentDetails.get( firstTeacherUserName ).get( studentId ), "studentAssignmentId" );

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

        // Sub district admin details
        subDistAdminUserName = ReportData.subDistrictAdmin;
        subDistAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" );
        subDistId = SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" );
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );

        //School admin details
        schoolAdminUserName = ReportData.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" );

    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin SEU Report Graphql", "SMK-58038", "P1" } )
    public void getAdminSEUReport_Positive( String tcId, String description, String statusCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                subjectName = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSEUAdminReportData" ) ).get( 0 ).toString(), ReportAPIConstants.SUBJECT );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.MATH ), "Subject is displayed as Math", "Subject is not displayed as Math" );
                break;

            case "SUB_DISTRICT_ADMIN":

                response = ReportAPI.getSEUReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                subjectName = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSEUAdminReportData" ) ).get( 0 ).toString(), ReportAPIConstants.SUBJECT );
                Log.assertThat( subjectName.equalsIgnoreCase( ReportAPIConstants.BOTH ), "Subject is displayed as Both", "Subject is not displayed as Both" );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );

                break;

            case "SCHOOL_ADMIN":

                response = ReportAPI.getSEUReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.READING, filterByValues );
                subjectName = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "data,getSEUAdminReportData" ) ).get( 0 ).toString(), ReportAPIConstants.SUBJECT );
                Log.assertThat( subjectName.equalsIgnoreCase( Constants.READING ), "Subject is displayed as Reading", "Subject is not displayed as Reading" );
                break;

            case "ASSIGNMENT_NOT_STARTED":
                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );

                break;

            case "FILTER_BY_SINGLE_VALUE":

                // Filter by single Teacher, Grade and Group
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01" );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_VALUE":

                // Filter by single Teacher, Grade and Group
                filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01,02" );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_TEACHER":

                // Additional Grouping by Teacher
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_GRADE":

                // Additional Grouping by Grade
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "ADDITIONAL_GROUPING_BY_GROUP":

                // Additional Grouping by Group
                filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":

                // Filter by single Teacher, Grade and Group
                filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;

            case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":

                // Filter by single Teacher, Grade and Group
                filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                Log.assertThat( validateResponseDataWithDB( response.getBody().asString(), studentId, studentAssignmentIdMath, studentAssignmentIdReading ), "Report data are same as DB data", "Report data are not same as DB data" );
                break;
        }
        if ( !response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
            Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }
        Log.testCaseResult();

    }

    @DataProvider ( name = "PositiveScenarios" )
    public Object[][] testScenario() {

        Object[][] inputData = { { "tc_SEUR_BFF_001", "Verify the 200 status code and valid reponse for the district admin credentia", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },
                { "tc_SEUR_BFF_002", "Verify the 200 status code and valid reponse for the subdistrict admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT_ADMIN" },
                { "tc_SEUR_BFF_003", "Verify the 200 status code and valid reponse for the school admin credential.", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },
                { "tc_SEUR_BFF_004", "Verify the 200 Status code and zero state response, if the students are not started the selected assignments", CommonAPIConstants.STATUS_CODE_OK, "ASSIGNMENT_NOT_STARTED" },
                { "tc_SEUR_BFF_005", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with single Teacher, Grade and Group", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_VALUE" },
                { "tc_SEUR_BFF_006", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject along with multiple Teachers, Grades and Groups", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_VALUE" },
                { "tc_SEUR_BFF_007", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Teacher", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_TEACHER" },
                { "tc_SEUR_BFF_008", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Grade", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GRADE" },
                { "tc_SEUR_BFF_009", "Verify the 200 Status code and response data when passing an organization Id with Math/Reading subject and Adddition Grouping as Group", CommonAPIConstants.STATUS_CODE_OK, "ADDITIONAL_GROUPING_BY_GROUP" },
                { "tc_SEUR_BFF_010", "Verify the 200 Status code and the output response when passing single values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE" },
                { "tc_SEUR_BFF_011", "Verify the 200 Status code and the output response when passing multiple values for all Demographic filters", CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE" },

        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "NegativeScenarios", groups = { "Admin SEU Report Graphql", "SMK-58038", "P2" } )
    public void getAdminSEUReport_Negative( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        switch ( scenario ) {

            case "INVALID_ACCESS_TOKEN":

                response = ReportAPI.getSEUReport( distAdminUserName + "INVALID", password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "INVALID_ORG_ID":

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId + "INVALID", selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "INVALID_USER_ID":

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId + "INVALID", distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "EMPTY_ORG_ID":

                response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, "", selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                break;

            case "EMPTY_USER_ID":

                response = ReportAPI.getSEUReport( distAdminUserName, password, "", distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                break;
        }

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        } else {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "NegativeScenarios" )
    public Object[][] testNegativeScenario() {

        Object[][] inputData = { { "tc_SEUR_BFF_012", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SEUR_BFF_013", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SEUR_BFF_014", "Verify  401: UnAuthorized  and response when invalid userId is given in the query ", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SEUR_BFF_015", "Verify the message in the response when organizationId passed as empty array. ", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_SEUR_BFF_016", "Verify the message in the response when invalid subject type passed in the query.", "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    /**
     * To validate response data with DB
     * 
     * @param responseBody
     * @param stdId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public boolean validateResponseDataWithDB( String responseBody, String stdId, String mathAssignmentUserId, String readingAssignmentUserId ) {
        Boolean validation;
        if ( responseBody.contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
            Log.message( ReportAPIConstants.NO_DATA_FOUND_MESSAGE );
            validation = true;
        } else {
            // Get data from response
            HashMap<String, HashMap<String, String>> dataFromResponse = getDataFromResponse( responseBody );
            Log.message( stdId + ": " + dataFromResponse.get( stdId ) );

            // Get data from DB
            HashMap<String, HashMap<String, String>> dataFromDB = getDataFromDB( stdId, mathAssignmentUserId, readingAssignmentUserId );
            validation = SMUtils.compareTwoHashMap( dataFromResponse.get( stdId ), dataFromDB.get( stdId ) );
        }
        return validation;
    }

    /**
     * To get data from given response
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromResponse( String responseBody ) {

        // Getting data from response
        String jsonObj = SMUtils.getKeyValueFromResponseWithArray( responseBody, "data,getSEUAdminReportData" );
        HashMap<String, HashMap<String, String>> studentReportDetails = new HashMap<>();

        IntStream.range( 0, new JSONArray( jsonObj ).length() ).forEach( iter -> {
            String student = SMUtils.getKeyValueFromResponseWithArray( new JSONArray( jsonObj ).get( iter ).toString(), "students" );

            IntStream.range( 0, new JSONArray( student ).length() ).forEach( itr -> {

                String studentDetails = new JSONArray( student ).get( itr ).toString();
                JSONObject stdJson = new JSONObject( studentDetails );

                HashMap<String, String> studentReport = new HashMap<>();
                studentReport.put( "sumDefaultMathTime", stdJson.get( "sumDefaultMathTime" ).toString() );
                studentReport.put( "sumDefaultReadingTime", stdJson.get( "sumDefaultReadingTime" ).toString() );
                studentReport.put( "sumCustomTotalTime", stdJson.get( "sumCustomTotalTime" ).toString() );
                studentReport.put( "sumTotalTime", stdJson.get( "sumTotalTime" ).toString() );
                studentReport.put( "sumTotalSessions", stdJson.get( "sumTotalSessions" ).toString() );
                studentReport.put( "avgTotalTimePerSession", new DecimalFormat( "#" ).format( Double.parseDouble( stdJson.get( "avgTotalTimePerSession" ).toString() ) ) );

                studentReportDetails.put( stdJson.get( "personId" ).toString(), studentReport );
            } );
        } );
        Log.message( "Response Data: " + studentReportDetails );
        return studentReportDetails;
    }

    /**
     * This method is used to get values from DB
     * 
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public HashMap<String, HashMap<String, String>> getDataFromDB( String studentRumbaId, String mathAssignmentUserId, String readingAssignmentUserId ) {

        // Executing queries to get SEU reoirt data from DB
        List<Object[]> mathTimeSpentQuery = SQLUtil.executeQuery( "select total_session_min as Time_Spent from math_assignment_history where assignment_user_id in (" + mathAssignmentUserId + ")" );
        List<Object[]> mathCustomTimeSpentQuery = SQLUtil.executeQuery(
                "select sum(total_session_min) as Time_Spent from math_assignment_history where assignment_user_id in  ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> mathTotalSessionQuery = SQLUtil.executeQuery(
                "select sum(session_presented_count) as Total_Sessions from math_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> readTimeSpentQuery = SQLUtil.executeQuery( "select total_session_min as Time_Spent from read_assignment_history where assignment_user_id in (" + readingAssignmentUserId + ")" );
        List<Object[]> readCustomTimeSpentQuery = SQLUtil.executeQuery(
                "select sum(total_session_min) as Time_Spent from read_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );
        List<Object[]> readTotalSessionQuery = SQLUtil.executeQuery(
                "select sum(session_presented_count) as Total_Sessions from read_assignment_history where assignment_user_id in ( select assignment_user_id from assignment_user where person_id = '" + studentRumbaId + "')" );

        HashMap<String, HashMap<String, String>> dataFromDB = new HashMap<>();
        HashMap<String, String> data = new HashMap<>();
        // Get Tiem Spent and Total Session
        int mathCustomTime = Integer.parseInt( mathCustomTimeSpentQuery.stream().findFirst().get()[0].toString() ) - Integer.parseInt( mathTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int readCustomTime = Integer.parseInt( readCustomTimeSpentQuery.stream().findFirst().get()[0].toString() ) - Integer.parseInt( readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int totalTime = mathCustomTime + readCustomTime + Integer.parseInt( mathTimeSpentQuery.stream().findFirst().get()[0].toString() ) + Integer.parseInt( readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        int totalSession = Integer.parseInt( mathTotalSessionQuery.stream().findFirst().get()[0].toString() ) + Integer.parseInt( readTotalSessionQuery.stream().findFirst().get()[0].toString() );

        data.put( "sumDefaultMathTime", mathTimeSpentQuery.stream().findFirst().get()[0].toString() );
        data.put( "sumDefaultReadingTime", readTimeSpentQuery.stream().findFirst().get()[0].toString() );
        data.put( "sumCustomTotalTime", String.valueOf( mathCustomTime + readCustomTime ) );
        data.put( "sumTotalTime", String.valueOf( totalTime ) );
        data.put( "sumTotalSessions", String.valueOf( totalSession ) );
        data.put( "avgTotalTimePerSession", String.valueOf( new DecimalFormat( "#" ).format( (Double) ( totalTime / 10.0 ) / ( totalSession / 10.0 ) ) ) );

        dataFromDB.put( studentRumbaId, data );
        Log.message( "DB Data: " + dataFromDB );
        return dataFromDB;
    }

    @Test ( priority = 1, dataProvider = "PositiveScenarios", groups = { "Admin SEU Report Graphql", "SMK-58038", "P1", "API", "smoke_test_case" } )
    public void getAdminSEUReport( String tcId, String description, String statusCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );
        HashMap<String, String> filterByValues = new HashMap<>();

        try {
            switch ( scenario ) {

                case "DISTRICT_ADMIN":

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, Constants.MATH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SUB_DISTRICT_ADMIN":

                    response = ReportAPI.getSEUReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( subDistAdminUserName, password, subDistAdminUserId, subDistId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SCHOOL_ADMIN":

                    response = ReportAPI.getSEUReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.READING, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( schoolAdminUserName, password, schoolAdminUserId, adminSchoolId, selectedSchoolId, Constants.READING, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ASSIGNMENT_NOT_STARTED":

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_VALUE":

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "03" );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_VALUE":

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( ReportFilters.TEACHER_ID_VALUE, firstTeacherId + "," + secondTeacherId );
                    filterByValues.put( ReportFilters.GROUP_ID_VALUE, firstGroupId + "," + secondGroupId );
                    filterByValues.put( ReportFilters.GRADE_ID_VALUE, "01,02" );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_TEACHER":

                    // Additional Grouping by Teacher
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "1" );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GRADE":

                    // Additional Grouping by Grade
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "2" );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ADDITIONAL_GROUPING_BY_GROUP":

                    // Additional Grouping by Group
                    filterByValues.put( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "3" );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_SINGLE_DEMOGRAPHIC_VALUE":

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.NOT_SPECIFIED );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.NOT_SPECIFIED );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_MULTI_DEMOGRAPHIC_VALUE":

                    // Filter by single Teacher, Grade and Group
                    filterByValues.put( DemographicFilters.RACE, DemographicValues.RACE.toString() );
                    filterByValues.put( DemographicFilters.ETHNICITY, DemographicValues.ETHNICITY.toString() );
                    filterByValues.put( DemographicFilters.SPECIAL_SERVICES, DemographicValues.SPECIAL_SERVICES.toString() );
                    filterByValues.put( DemographicFilters.DISABILITY_STATUS, DemographicValues.DISABILITY_STATUS.toString() );
                    filterByValues.put( DemographicFilters.SOCIO_STATUS, DemographicValues.SOCIOECONOMIC_STATUS.toString() );
                    filterByValues.put( DemographicFilters.ENGLISH_PROFICIENCY, DemographicValues.ENGLISH_LANGUAGE.toString() );
                    filterByValues.put( DemographicFilters.MIGRANT_STATUS, DemographicValues.MIGRANT_STATUS.toString() );

                    response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = ReportAPI.getSEUReport( distAdminUserName, password, distAdminuserId, distId, selectedSchoolId, ReportAPIConstants.BOTH, filterByValues );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportAPIConstants.INTERNAL_SERVER_ERROR ) || response.getBody().asString().contains( ReportAPIConstants.UNAUTHORIZED_MESSAGE ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !( response.getBody().asString().contains( ReportAPIConstants.NO_DATA_FOUND_MESSAGE ) ) ) {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "getSEUReportGraphQL", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;
            }
        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( response, "SEU" );
        }

        Log.testCaseResult();

    }
}
