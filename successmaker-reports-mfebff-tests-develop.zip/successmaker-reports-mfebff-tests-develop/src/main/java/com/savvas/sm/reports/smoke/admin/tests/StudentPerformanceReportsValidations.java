package com.savvas.sm.reports.smoke.admin.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.smoke.admin.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.admin.pages.ReportsViewerPage;
import com.savvas.sm.reports.smoke.admin.pages.StudentPerformanceReport;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StudentPerformanceReportsValidations extends EnvProperties {

    private String adminUsername;
    private String subDistrictschoolName;
    private String flexSchoolName;
    private String schoolAdmin;
    private String flexSchoolId;
    private String mathSchool;
    private String mathschoolId;
    private String districtId;
    private String mathFlexAdmin;
    private String flexSchoolAdmin;
    private List<String> expgroupNames = new ArrayList<String>();
    private List<String> expteacherNames = new ArrayList<String>();
    private List<String> teacherIds = new ArrayList<String>();
    private List<String> groupIds = new ArrayList<String>();
    public static String[] schools;
    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeTest ( alwaysRun = true )
    public void init( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        adminUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        subDistrictschoolName = configProperty.getProperty( "Rumba_subDistrictSchool" );
        schoolAdmin = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
        schools = configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," );
        // Flex school Admin create
        flexSchoolName = schools[4];
        flexSchoolId = new RBSUtils().getOrganizationIDByName( districtId, flexSchoolName );
        flexSchoolAdmin = "flexschooladmin7686" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) == null ) {
            HashMap<String, String> adminDetails = new HashMap<>();
            adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, flexSchoolName );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, flexSchoolId );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
            adminDetails.put( RBSDataSetupConstants.USERNAME, flexSchoolAdmin );
            boolean createCAUserWithAccess = new RBSUtils().createCAUserWithAccess( adminDetails, true );
        }

        new RBSUtils().resetPassword( flexSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) );
        // Admin create of Math and Reading School
        mathSchool = schools[0];
        mathschoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), mathSchool );
        mathFlexAdmin = "mathFlexadmin1234" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( mathFlexAdmin ) == null ) {
            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, mathFlexAdmin );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, mathschoolId + "\"," + "\"" + flexSchoolId );
            String admin = new RBSUtils().createUser( userDetails );
            new RBSUtils().resetPassword( mathschoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( admin, RBSDataSetupConstants.USERID ) );
        }
    }

    @Test ( description = "Student Performance Report Field Validations", groups = { "smoke_test_case", "reports", "student_performance" }, priority = 1 )
    public void tc001StudentPerformanceReportFieldValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Student Performance Report Field Validations" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport =  smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            StudentPerformanceReport spr = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Student Performance" );
            spr.validateAllFieldsInStudentPerformanceReport( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Student Performance - 'Saved Report' Value Is Retaining ", groups = { "smoke_test_case", "reports", "student_performance" }, priority = 2 )
    public void tc002SPRSavedReportsValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Student Performance - 'Saved Report' Value Is Retaining " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport =  smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Student Performance" );
            studentPerformanceReport.validateSPSavedReports( driver ,flexSchoolId );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Student Performance run Report Validation", groups = { "smoke_test_case", "reports", "student_performance" }, priority = 3 )

    public void tc003SPRRunReportValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Student Performance run Report Validation" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport =  smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Student Performance" );
            ReportsViewerPage reportsViewerPage = studentPerformanceReport.validateSPRRunReport( driver ,flexSchoolId );
            reportsViewerPage.verifyReportPage( driver );
            reportsViewerPage.validateReportOutputColumns( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
            Log.endTestCase();
            Log.testCaseResult();
        }
    }

    @Test ( description = "Validation of Student Performance Report Field Validations - All Drop down validations", groups = { "smoke_test_case", "reports", "student_performance" }, priority = 4 )
    public void tc004StudentPerformanceValidationReading() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation of Student Performance Report Field Validations" + browser + "]</b></i></small>" );
        try {
            List<String> orgId = new ArrayList<String>();
            orgId.add( flexSchoolId );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Student Performance" );
            studentPerformanceReport.verifyOrgIds( driver, Admins.DISTRICT_ADMIN, smUrl );
            studentPerformanceReport.chooseOrganization( driver, flexSchoolId );
            studentPerformanceReport.chooseSubject( driver, "Reading" );
            studentPerformanceReport.verifyCourses( driver, Admins.DISTRICT_ADMIN, orgId, "Reading" );
            studentPerformanceReport.clickOptionalFilters( driver );
            studentPerformanceReport.verifyTeachers( driver, Admins.DISTRICT_ADMIN, orgId );
            studentPerformanceReport.verifyGroup( driver );
            studentPerformanceReport.verifyGrades( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validation of Student Performance Report Field Validations - All Drop down validations", groups = { "smoke_test_case", "reports", "student_performance" }, priority = 2 )
    public void tc005StudentPerformanceValidationMath() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Validation of Student Performance Report Field Validations" + browser + "]</b></i></small>" );
        try {
            List<String> orgId = new ArrayList<String>();
            orgId.add( flexSchoolId );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsAdmin( adminUsername, password );
            StudentPerformanceReport studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, "Student Performance" );
            studentPerformanceReport.verifyOrgIds( driver, Admins.DISTRICT_ADMIN, smUrl );
            studentPerformanceReport.chooseOrganization( driver, flexSchoolId );
            studentPerformanceReport.chooseSubject( driver, "Math" );
            studentPerformanceReport.verifyCourses( driver, Admins.DISTRICT_ADMIN, orgId, "Math" );
            studentPerformanceReport.clickOptionalFilters( driver );
            studentPerformanceReport.verifyTeachers( driver, Admins.DISTRICT_ADMIN, orgId );
            studentPerformanceReport.verifyGroup( driver );
            studentPerformanceReport.verifyGrades( driver );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
