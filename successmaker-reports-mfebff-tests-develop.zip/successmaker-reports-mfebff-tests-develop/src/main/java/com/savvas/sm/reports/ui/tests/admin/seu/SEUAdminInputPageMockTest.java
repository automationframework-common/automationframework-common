package com.savvas.sm.reports.ui.tests.admin.seu;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.SEUReportConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.SystemEnrollmentAndUsagePage;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class SEUAdminInputPageMockTest extends EnvProperties {
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String configGraphQL;
    private String firstTeacherUserName;
    private String secondTeacherUserName;
    private String firstTeacherOrgID;
    private String firstTeacherId;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    RBSUtils rbsUtils = new RBSUtils();
    private String distAdminUserName;
    private String distId;
    private String distAdminuserId;
    private String reportUrl;

    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) throws Exception {

        configGraphQL = configProperty.getProperty( "AdminReportBFFGraphQL" );
        reportUrl = configProperty.getProperty( "SEUAdminReportMFE" );
        browser = ReportsUIConstants.CHROME_BROWSER_V100;

        // Teacher UserNames
        firstTeacherUserName = ReportData.teacherDetails.keySet().toArray()[0].toString();
        secondTeacherUserName = ReportData.teacherDetails.keySet().toArray()[1].toString();

        //Selected School Name
        firstTeacherOrgID = ReportData.orgId;

        // District admin details
        distAdminUserName = ReportData.districtAdmin;
        distId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "primaryOrgId" );
        distAdminuserId = SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" );

    }

    @Test ( description = "Verify SEU input screen & UI validation - Mock OrganizationListMax", groups = { "Smoke", "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU report", "mock" }, priority = 1 )
    public void tcSEUInputMock001( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify SEU input screen & UI validation - Mock OrganizationListMax<small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOrganizationListMax.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of SEU page is displayed" );
            Log.assertThat( seuReport.reportFilterComponent.isReportTitleDisplayed(), "The SEU title is displayed and it is verified", "The SEU title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isReportDescriptionDisplayed(), "The SEU description is displayed and it is verified", "The SEU description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isHelpIconDisplayed(), "The SEU help icon is displayed and it is verified", "The SEUn help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalOrgs = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            totalOrgs.size();
            Log.message( "totalOrgMax: " + totalOrgs + " SizeMax: " + totalOrgs.size() );

            String orgName = "Chiefs_Test_Org_1";
            seuReport.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            Log.assertThat( totalOrgs.contains( orgName ), "Expected orgName is displayed, Mock Passed:)", "Expected orgName is not displayed, Mock Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify SEU input screen & UI validation - Mock OrganizationListMin", groups = { "Smoke", "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU report", "mock" }, priority = 1 )
    public void tcSEUInputMock002( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify SEU input screen & UI validation - Mock OrganizationListMin <small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOrganizationListMin.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of SEU page is displayed" );
            Log.assertThat( seuReport.reportFilterComponent.isReportTitleDisplayed(), "The SEU title is displayed and it is verified", "The SEU title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isReportDescriptionDisplayed(), "The SEU description is displayed and it is verified", "The SEU description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isHelpIconDisplayed(), "The SEU help icon is displayed and it is verified", "The SEU help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalOrgz = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
            totalOrgz.size();
            Log.message( "totalOrgMin: " + totalOrgz + " SizeMin: " + totalOrgz.size() );

            String orgName = "Chiefs_Test_Org_1";
            seuReport.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, orgName );
            Log.assertThat( totalOrgz.contains( orgName ), "Expected orgName is displayed, Mock Passed:)", "Expected orgName is not displayed, Mock Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify SEU input screen & UI validation - Mock OrganizationList - Zero State", groups = { "Smoke", "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU report", "mock" }, priority = 1 )
    public void tcSEUInputMock003( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;
        try {

            Log.testCaseInfo( "Verify LS input screen & UI validation - Mock OrganizationList - Zero State <small><b><i>[" + browser + "]</b></i></small>" );

            //Mocking Org GraphQL
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOrganizationListZeroState.json" );
                responses.put( "GetOrganizationList", getOrganizationList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:03 Verify the title of SEU page is displayed" );
            Log.assertThat( seuReport.reportFilterComponent.isReportTitleDisplayed(), "The SEU title is displayed and it is verified", "The SEU title is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify the page description is displayed below the title of the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isReportDescriptionDisplayed(), "The SEU description is displayed and it is verified", "The SEU description is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:05 Verify the help icon (?) is displayed along with the title of the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isHelpIconDisplayed(), "The SEU help icon is displayed and it is verified", "The SEU help icon is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            try {
                List<String> totalOrgz = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL );
                totalOrgz.size();
                Log.message( "totalOrgZeroState: " + totalOrgz + " SizeZeroState: " + totalOrgz.size() );
                Log.assertThat( totalOrgz.size() == 1, "Zero state orgList mocked, Test passed:)", "Zero state orgList not mocked, Test Failed:(" );
            } catch ( Exception e ) {
                // TODO: handle exception
                String actualException = e.toString();
                Log.message( "actualException: " + actualException );
                Log.assertThat( actualException.contains( ReportsUIConstants.JS_EXECUTION_EXCEPTION), "Zero state mock verfied, Test passed:)", "Zero state mock not verfied, Test Failed:(" );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax", groups = { "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU Report", "mock" }, priority = 1 )
    public void tcSEUInputMock004( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMax"+ " <small><b><i>[" + browser + "]</b></i></small>" );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;
        try {

            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOrganizationListMin.json" );
                String getAllReportOption = DevToolsUtils.readJsonResponse( "SEUAdminInputGetAllReportOptionsMax.json" );
                responses.put( "GetOrganizationList", getOrganizationList );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList", "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option label is displayed and it is verified",
                    "The SEU Save Report Option label is not displayed and it is verified" );
            Log.assertThat( seuReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ),
                    "The SEU Save Report Option label text is displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS,
                    "The SEU Save Report Option label text is not displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the SEU page" );
            Log.assertThat( seuReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option drop down is displayed and it is verified",
                    "The SEU Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( seuReport.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option drop down arrow is displayed and it is verified",
                    "The SEU Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( seuReport.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersMax: " + totalFilters + " SizeMax: " + totalFilters.size() );

            SMUtils.logDescriptionTC( "TC:16 Verify the Saved report option name is displayed when it is selected" );
            String filterName = "Chiefs_Filter_1";
            seuReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );

            List<String> mockedFilterNames = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( mockedFilterNames.contains( filterName ), "Mocked Filter name is displayed, Test passed:)", "Mocked Filter name is not displayed, Test Failed:(" );
            Log.assertThat( totalFilters.size()>= 1001, "Save Report Max successfully mocked, Test Passed:)", "Save Report Max not mocked, Test Failed:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }


    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMin", groups = { "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU Report", "mock" }, priority = 1 )
    public void tcSEUInputMock005( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptionsMin"+" <small><b><i>[" + browser + "]</b></i></small>" );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;
        try {

            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOrganizationListMax.json" );
                String getAllReportOption = DevToolsUtils.readJsonResponse( "SEUAdminInputGetAllReportOptionsMin.json" );
                responses.put( "GetOrganizationList", getOrganizationList );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList", "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option label is displayed and it is verified",
                    "The SEU Save Report Option label is not displayed and it is verified" );
            Log.assertThat( seuReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ),
                    "The SEU Save Report Option label text is displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS,
                    "The SEU Save Report Option label text is not displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the SEU page" );
            Log.assertThat( seuReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option drop down is displayed and it is verified",
                    "The SEU Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( seuReport.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option drop down arrow is displayed and it is verified",
                    "The SEU Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( seuReport.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersMin: " + totalFilters + " SizeMin: " + totalFilters.size() );

            SMUtils.logDescriptionTC( "TC:16 Verify the Saved report option name is displayed when it is selected" );
            String filterName = "Chiefs_Filter_1";
            seuReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );

            List<String> mockedFilterNames = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( mockedFilterNames.contains( filterName ), "Mocked Filter name is displayed, Test passed:)", "Mocked Filter name is not displayed, Test Failed:(" );
            Log.assertThat( totalFilters.size()>= 2, "Save Report Min successfully mocked, Test Passed:)", "Save Report Min not mocked, Test Failed:(" );

        } catch (Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }



    @Test ( description = "Verify the functionality of Save Report Option drop down - Mock SaveReportOptions - Zero State", groups = { "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU Report", "mock" }, priority = 1 )
    public void tcSEUInputMock006( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the functionality of Save Report Option drop down - Mock SaveReportOptions - Zero State <small><b><i>[" + browser + "]</b></i></small>" );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;
        try {

            //Mocking Already Saved Report Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOrganizationList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOrganizationListMin.json" );
                String getAllReportOption = DevToolsUtils.readJsonResponse( "SEUAdminInputGetAllReportOptionsZeroState.json" );
                responses.put( "GetOrganizationList", getOrganizationList );
                responses.put( "GetAllReportOption", getAllReportOption );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOrganizationList", "GetAllReportOption" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            SMUtils.logDescriptionTC( "TC:11 Verify Saved Report Option label is displayed in the SEU Page" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option label is displayed and it is verified",
                    "The SEU Save Report Option label is not displayed and it is verified" );
            Log.assertThat( seuReport.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ),
                    "The SEU Save Report Option label text is displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS,
                    "The SEU Save Report Option label text is not displayed as " + ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:12 Verify Saved Report Option drop down is displayed in the SEU page" );
            Log.assertThat( seuReport.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option drop down is displayed and it is verified",
                    "The SEU Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:14 Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( seuReport.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The SEU Save Report Option drop down arrow is displayed and it is verified",
                    "The SEU Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( seuReport.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.SAVED_REPORT_OPTIONS ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:15 Verify the Saved Report option drop down is listed with saved report options" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            Log.assertThat( seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).size() > 0, "The saved options values are displayed", "The saved options values are not displayed" );
            Log.testCaseResult();

            SMUtils.nap( 20 );
            List<String> totalFilters = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            totalFilters.size();
            Log.message( "totalFiltersZeroState: " + totalFilters + " SizeZeroState: " + totalFilters.size() );
            Log.assertThat( totalFilters.size()>= 1, "Save Report Zero State successfully mocked, Test Passed:)", "Save Report Zero State not mocked, Test Failed:(" );


        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != tools ) {
                RequestMockUtils.closeMock( tools );
            }
            driver.quit();
        }

    }



    @Test ( description = "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Max", groups = { "Smoke", "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU Report" , "mock" }, priority = 1 )
    public void tcSEUInputMock007( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;

        try {

            Log.testCaseInfo( "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Max <small><b><i>[" + browser + "]</b></i></small>" );

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOptionalFilters = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOptionalFiltersMax.json" );
                responses.put( "GetOptionalFilters", getOptionalFilters );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOptionalFilters" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            seuReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            seuReport.reportFilterComponent.expandOptionalFilter();

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getGroupList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetGroupsListMax.json" );
                responses.put( "GetGroupList", getGroupList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetGroupList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:18 Verify Teacher Dropdown should display under SEU Report " );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.TEACHER_LABEL ), "Teacher dropdown label is displayed under LSR", "Teacher dropdown label is not displayed under LSR!" );
            List<String> tecValues = seuReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValuesMax: " + tecValues + "  sizeMax: "+ tecValues.size() );
            Log.assertThat( tecValues.size() >= 1001, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:(" );

            String selectedTeacherName1 = "FName_1 LName_1";
            String selectedTeacherName2 = "FName_2 LName_2";
            String selectedTeacherName3 = "FName_3 LName_3";
            String selectedTeacherName4 = "FName_4 LName_4";
            String selectedTeacherName5 = "FName_5 LName_5";

            seuReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.TEACHER_LABEL , Arrays.asList( selectedTeacherName1, selectedTeacherName2, selectedTeacherName3, selectedTeacherName4, selectedTeacherName5 ) );
            List<String> selectedValuesTec = seuReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "selectedValuesTec: " + selectedValuesTec );
            List<String> actualValuesTec = Arrays.asList( selectedTeacherName1, selectedTeacherName2, selectedTeacherName3, selectedTeacherName4, selectedTeacherName5 );
            Log.message( "actualValuesTec: " + actualValuesTec );
            Log.assertThat( SMUtils.compareTwoList( selectedValuesTec, actualValuesTec ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:19 Verify Group Dropdown should display under SEU Report" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CP_GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            List<String> grpValues = seuReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "grpValuesMax: " + grpValues + "  sizeMax: "+ grpValues.size());
            Log.assertThat( grpValues.size() >= 1001, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:(" );

            seuReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.CP_GROUP_LABEL , Arrays.asList( "Chiefs_Test_Group_1", "Chiefs_Test_Group_2", "Chiefs_Test_Group_3", "Chiefs_Test_Group_4", "Chiefs_Test_Group_5" ) );
            List<String> selectedValues = seuReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "selectedValues: " + selectedValues );
            List<String> actualValues = Arrays.asList( "Chiefs_Test_Group_1", "Chiefs_Test_Group_2", "Chiefs_Test_Group_3", "Chiefs_Test_Group_4", "Chiefs_Test_Group_5" );
            Log.message( "actualValues: " + actualValues );
            Log.assertThat( SMUtils.compareTwoList( selectedValues, actualValues ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:20 Verify Grade Dropdown should display under SEU Report" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.GRADE_LABEL ), "Grade header is displaying", "Grade header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:21 Verify Additional Grouping Dropdown should display under SEU Report" );
            SMUtils.logDescriptionTC( "TC:26 Verify all field available under additional grouping dropdown" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:24 Verify Sort Dropdown should display under SEU Report" );
            SMUtils.logDescriptionTC( "TC:28 Verify all field available under Sort dropdown" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "Sort Label header is displaying", "Sort Label header is not displaying:(" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            List<String> sortValues = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            sortValues.remove( 0 );
            Log.message( "sortValues: " + sortValues );
            Log.assertThat( sortValues.containsAll( SEUReportConstants.SORT ), "All the sort option are displaying as expected",
                    "Sort option values are not displaying as expected!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test ( description = "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Min", groups = { "Smoke", "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU Report" , "mock" }, priority = 1 )
    public void tcSEUInputMock008( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;

        try {

            Log.testCaseInfo( "Verify all field available under Optional Filters field - Mock -getOptionalFilters - Min <small><b><i>[" + browser + "]</b></i></small>" );

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOptionalFilters = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOptionalFiltersMin.json" );
                responses.put( "GetOptionalFilters", getOptionalFilters );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOptionalFilters" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            seuReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            seuReport.reportFilterComponent.expandOptionalFilter();
            
           //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getGroupList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetGroupsListMin.json" );
                responses.put( "GetGroupList", getGroupList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetGroupList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:18 Verify Teacher Dropdown should display under SEU Report " );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.TEACHER_LABEL ), "Teacher dropdown label is displayed under LSR", "Teacher dropdown label is not displayed under LSR!" );
            List<String> tecValues = seuReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValuesMin: " + tecValues + "  sizeMin: "+ tecValues.size() );
            Log.assertThat( tecValues.size() >= 2, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:(" );

            String selectedTeacherName = "FName_1 LName_1";
            seuReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.TEACHER_LABEL , Arrays.asList( selectedTeacherName ) );
            List<String> selectedValuesTec = seuReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.TEACHER_LABEL );
            selectedValuesTec.remove( 0 ); // Removing the 'Select All' option from list
            Log.message( "selectedValuesTec: " + selectedValuesTec );
            List<String> actualValuesTec = Arrays.asList( selectedTeacherName );
            Log.message( "actualValuesTec: " + actualValuesTec );
            Log.assertThat( SMUtils.compareTwoList( selectedValuesTec, actualValuesTec ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:19 Verify Group Dropdown should display under SEU Report" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CP_GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            List<String> grpValues = seuReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "grpValuesMin: " + grpValues + "  sizeMin: "+ grpValues.size() );
            Log.assertThat( tecValues.size() >= 2, "Mocked values are displayed, Test pass:)", "Mocked values are not displayed, Test Fail:(" );

            seuReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown(  ReportsUIConstants.CP_GROUP_LABEL , Arrays.asList( "Chiefs_Test_Group_1" ) );
            List<String> selectedValues = seuReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.CP_GROUP_LABEL );
            selectedValues.remove( 0 ); // Removing the 'Select All' option from list
            Log.message( "selectedValues: " + selectedValues );
            List<String> actualValues = Arrays.asList( "Chiefs_Test_Group_1" );
            Log.message( "actualValues: " + actualValues );
            Log.assertThat( SMUtils.compareTwoList( selectedValues, actualValues ), "Mocked values are selected, Test Passed:)", "Mocked values are not selected, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:20 Verify Grade Dropdown should display under SEU Report" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.GRADE_LABEL ), "Grade header is displaying", "Grade header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:21 Verify Additional Grouping Dropdown should display under SEU Report" );
            SMUtils.logDescriptionTC( "TC:26 Verify all field available under additional grouping dropdown" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );
            Log.testCaseResult();


            SMUtils.logDescriptionTC( "TC:24 Verify Sort Dropdown should display under SEU Report" );
            SMUtils.logDescriptionTC( "TC:28 Verify all field available under Sort dropdown" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "Sort Label header is displaying", "Sort Label header is not displaying:(" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            List<String> sortValues = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            sortValues.remove( 0 );
            Log.message( "sortValues: " + sortValues );
            Log.assertThat( sortValues.containsAll( SEUReportConstants.SORT ), "All the sort option are displaying as expected",
                    "Sort option values are not displaying as expected!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test ( description = "Verify all field available under Optional Filters field. - Mock -getOptionalFilters - Zero State", groups = { "Smoke", "SMK-67112", "SEU - Admin Input Page", "Reports", "SEU Report" , "mock" }, priority = 1 )
    public void tcSEUInputMock009( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        SystemEnrollmentAndUsagePage seuReport = new SystemEnrollmentAndUsagePage( driver );
        DevTools tools = null;

        try {

            Log.testCaseInfo( "Verify all field available under Optional Filters field - Mock -getOptionalFilters - Zero State <small><b><i>[" + browser + "]</b></i></small>" );

            //Login to Reports MFE
            LoginWrapper.loginToMasteryMfe( driver, reportUrl, distAdminUserName, password );
            Log.message( "Login with distAdminUserName: " + distAdminUserName + " password: " + password );

            //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getOptionalFilters = DevToolsUtils.readJsonResponse( "SEUAdminInputGetOptionalFiltersZeroState.json" );
                responses.put( "GetOptionalFilters", getOptionalFilters );

                List<String> requestPayloadMatchers = Arrays.asList( "GetOptionalFilters" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.waitForSpinnertoDisapper( driver, 10 );
            SMUtils.nap( 15 );

            seuReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ORGANIZATIONS_LABEL, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
            Log.message("orgName: " + RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            seuReport.reportFilterComponent.expandOptionalFilter();
            
           //Mocking Optional Filters GraphQL BFF
            if ( DevToolsUtils.isMock( context ) ) {
                Map<String, String> responses = new HashMap();
                String getGroupList = DevToolsUtils.readJsonResponse( "SEUAdminInputGetGroupsListZeroState.json" );
                responses.put( "GetGroupList", getGroupList );

                List<String> requestPayloadMatchers = Arrays.asList( "GetGroupList" );
                tools = DevToolsUtils.setResponse( driver, configGraphQL, requestPayloadMatchers, "post", responses );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            SMUtils.logDescriptionTC( "TC:18 Verify Teacher Dropdown should display under SEU Report " );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.TEACHER_LABEL ), "Teacher dropdown label is displayed under LSR", "Teacher dropdown label is not displayed under LSR!" );
            List<String> tecValues = seuReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            Log.message( "tecValuesZeroState: " + tecValues + " sizeZeroState: " + tecValues.size() );
            Log.assertThat( tecValues.size()>=1, "Mock zero state verified, Test passed:)", "Mock zero state not verified, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:19 Verify Group Dropdown should display under SEU Report" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CP_GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            List<String> grpValues = seuReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CP_GROUP_LABEL );
            Log.message( "grpValuesZeroState: " + grpValues +  " sizeZeroState: " + grpValues.size());
            Log.assertThat( grpValues.size()>=1, "Mock zero state verified, Test passed:)", "Mock zero state not verified, Test Failed:(" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:20 Verify Grade Dropdown should display under SEU Report" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.GRADE_LABEL ), "Grade header is displaying", "Grade header is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:21 Verify Additional Grouping Dropdown should display under SEU Report" );
            SMUtils.logDescriptionTC( "TC:26 Verify all field available under additional grouping dropdown" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL );
            Log.assertThat( seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).containsAll( ReportsUIConstants.ADDITIONAL_GROUPING ), "All the additional grouping option are displaying",
                    "Additional grouping option are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:24 Verify Sort Dropdown should display under SEU Report" );
            SMUtils.logDescriptionTC( "TC:28 Verify all field available under Sort dropdown" );
            Log.assertThat( seuReport.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "Sort Label header is displaying", "Sort Label header is not displaying:(" );
            seuReport.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            List<String> sortValues = seuReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL );
            sortValues.remove( 0 );
            Log.message( "sortValues: " + sortValues );
            Log.assertThat( sortValues.containsAll( SEUReportConstants.SORT ), "All the sort option are displaying as expected",
                    "Sort option values are not displaying as expected!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}