package com.savvas.sm.reports.ui.tests.teacher.cpr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.reports.admin.ui.pages.AdminReportFilterComponent;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.reports.teacher.ui.pages.CumulativePerformanceReportPage;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.reports.util.JSONParserUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants.GroupAPIEndPoints;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CumulativePerformanceReport extends BaseTest {
	private String smUrl;
	private String browser;
	private String username;
	private String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String teacherDetails;
	public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String userID;
	String orgId;
	String endPoint;
	String teacherStaffId;
	String studentDetailsSchool1;
	String courseId;
	String studentDetails;
	String studentIdOne;
	String studentIdTwo;
	HashMap<String, String> assignmentDetails = new HashMap<>();
	String districtId;
	String studentThreeDetails;
	String studentFourDetails;
	String studentFiveDetails;
	String studentIdThree;
	String studentIdFour;
	String studentIdFive;
	String studentTwoDetail;
	List<String> studentRumbaIds = new ArrayList<>();
	Map<String, String> courseIDs = new HashMap<>();
	Map<String, String> contentBase = new HashMap<>();
	HashMap<String, String> courseName = new HashMap<>();
	String assignmentId;
	String firstMathAssignmentUserId;
	String secondMathAssignmentUserId;
	List<String> mathAssignmentUserId = new ArrayList<>();
	private HashMap<String, String> groupDetails = new HashMap<>();

	String className = "ClasstoDelete" + System.nanoTime();
	private String configGraphQL;
	DevTools tools = null;

	@BeforeClass(alwaysRun = true)
	public void initTest() throws Exception {

		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");

		configGraphQL = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";
		districtId = configProperty.getProperty("district_ID");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		userID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdOne = SMUtils.getKeyValueFromResponse(studentDetails, "userId");

		studentTwoDetail = RBSDataSetup.getMyStudent(school, username);
		studentIdTwo = SMUtils.getKeyValueFromResponse(studentTwoDetail, "userId");

		studentThreeDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdThree = SMUtils.getKeyValueFromResponse(studentThreeDetails, "userId");

		studentFourDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdFour = SMUtils.getKeyValueFromResponse(studentFourDetails, "userId");

		studentFiveDetails = RBSDataSetup.getMyStudent(school, username);
		studentIdFive = SMUtils.getKeyValueFromResponse(studentFiveDetails, "userId");

		orgId = new RBSUtils().getOrganizationIDByName(districtId, school);

		studentRumbaIds.add(studentIdOne);
		studentRumbaIds.add(studentIdTwo);
		studentRumbaIds.add(studentIdThree);
		studentRumbaIds.add(studentIdFour);
		studentRumbaIds.add(studentIdFive);

		contentBase.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH);
		contentBase.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING);

		courseName.put(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE,
				String.format(DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
				String.format(DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
				String.format(DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime()));

		courseIDs.put(Constants.MATH, AssignmentAPIConstants.MATH);
		courseIDs.put(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userID, orgId, DataSetupConstants.SETTINGS,
						courseName.get(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse(
				smUrl, new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
				DataSetupConstants.MATH, userID, orgId, courseName.get(Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userID, orgId, DataSetupConstants.STANDARD,
						courseName.get(Constants.CUSTOM_BY_STANDARDS_MATH_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.MATH, userID, orgId, DataSetupConstants.SKILL,
						courseName.get(Constants.CUSTOM_BY_SKILLS_MATH_COURSE)));

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, userID);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));

		HashMap<String, String> mathAssignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, Arrays.asList(studentRumbaIds.get(0)), new ArrayList<>(courseIDs.values()));

		Log.message(mathAssignmentResponse.get("body"));

		// Getting assignment id
		JSONObject mathAssignmentDetailsJson = new JSONObject(mathAssignmentResponse.get(Constants.REPORT_BODY));
		JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray(Constants.DATA);
		JSONObject mathAssignmentInfo = new JSONObject(mathAssignmentList.get(0).toString());

		assignmentId = mathAssignmentInfo.get("assignmentId").toString();
		mathAssignmentUserId.add(new SqlHelperCourses().getAssignmentUserId(studentRumbaIds.get(0), assignmentId));

		courseName.put(Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
				String.format(DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
				String.format(DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime()));
		courseName.put(Constants.CUSTOM_BY_SKILLS_READING_COURSE,
				String.format(DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime()));

		courseIDs.put(Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userID, orgId, DataSetupConstants.SETTINGS,
						courseName.get(Constants.CUSTOM_BY_SETTINGS_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE,
				new CourseAPI().createCustomBySettingIPMOnCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userID, orgId,
						courseName.get(Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userID, orgId, DataSetupConstants.STANDARD,
						courseName.get(Constants.CUSTOM_BY_STANDARDS_READING_COURSE)));
		courseIDs.put(Constants.CUSTOM_BY_SKILLS_READING_COURSE,
				new CourseAPI().createCourse(smUrl,
						new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD),
						DataSetupConstants.READING, userID, orgId, DataSetupConstants.SKILL,
						courseName.get(Constants.CUSTOM_BY_SKILLS_READING_COURSE)));

		HashMap<String, String> readingAssignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, studentRumbaIds, new ArrayList<>(courseIDs.values()));

		Log.message(readingAssignmentResponse.get("body"));

	}

	@Test(description = "Verify Cumulative performance Report (CPR) should display under Reports menu.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport" }, priority = 1)
	public void tcSMCPR001() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR001: Verify Cumulative performance Report (CPR) should display under Reports menu. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Verify Cumulative Performance Sub menu
			Log.assertThat(
					dashBoardPage.reportComponents.subNavigationMenuisDisplayed(ReportTypes.CUMULATIVE_PERFORMANCE),
					"The Cumulative performance report is displayed in Report MFE sub-navigation",
					"The Cumulative performance report is not displayed in Report MFE sub-navigation");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify all available fields in CPR page", groups = { "SMK-66755", "reports",
			"cumulativePerformanceReport", "mock" }, priority = 1)
	public void tcSMCPR002(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcSMCPR002: Verify all available fields in CPR page <small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("CPR_GroupAndStudentDetails.json");
				tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message("CDP Session : " + tools.getCdpSession().toString());
			}

			// navigate to CPR Page
			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			// Verify CPR header
			Log.assertThat(cumulativePerformance.reportComponents.isCPRReportTitleDisplayed(),
					"The Cumulative Performance Report is displayed and it is verified",
					"The Cumulative Performance Report  is not displayed and it is verified");

			// Verify Filters heading
			Log.assertThat(cumulativePerformance.optionalFilterValidate().equals(ReportsUIConstants.OPTIONFILTERS),
					"Filters heading is present in the CPR Page", "Filters heading is not present in the CPR Page");

			// Verify Select Groups or Students heading
			Log.assertThat(
					cumulativePerformance.reportComponents
							.isGroupsAndStudentsHeadingPresent(ReportsUIConstants.GROUP_OR_STUDENT_HEADER),
					"Select Groups or Students heading is present in the CPR Page",
					"Select Groups or Students heading is not present in the CPR Page");

			// Verify group radiobutton heading
			Log.assertThat(
					cumulativePerformance.reportComponents.radioGropsandStudentsHeadingPresent(
							ReportsUIConstants.GROUPS_HEADER_BUTTON),
					"Group radio button is present in the CPR Page",
					"Group radio button is not present in the CPR Page");

			// Verify student radiobutton heading
			Log.assertThat(
					cumulativePerformance.reportComponents
							.radioGropsandStudentsHeadingPresent(ReportsUIConstants.STUDENTS_HEADER_BUTTON),
					"Students radio button is present in the CPR Page",
					"Students radio button is not present in the CPR Page");

			// Verify course selection heading
			Log.assertThat(
					cumulativePerformance.reportComponents.isCourseSelectionHeadingPresent(
							ReportsUIConstants.COURSE_SELECTION),
					"Course selection heading is present in the CPR Page",
					"Course selection heading is not present in the CPR Page");

			// Verify Subject heading
			Log.assertThat(
					cumulativePerformance.reportComponents.courseSelectionDropdownHeadingPresent(
							ReportsUIConstants.SUBJECT_HEADING),
					"Subject selection heading is present in the CPR Page",
					"Subject selection heading is not present in the CPR Page");

			// Verify Assignment heading
			Log.assertThat(
					cumulativePerformance.reportComponents
							.courseSelectionDropdownHeadingPresent(ReportsUIConstants.ASSIGNMENT_HEADING),
					"Assignment selection heading is present in the CPR Page",
					"Assignment selection heading is not present in the CPR Page");

			// Verify Optional filters Additional Grouping heading
			Log.assertThat(
					cumulativePerformance.reportComponents
							.isAdditionalGroupingHeadingPresent(ReportsUIConstants.ADDITIONAL_GROUPING_HEADER),
					"Optional filter Additional Grouping heading is present in the CPR Page",
					"Optional filter Additional Grouping heading is not present in the CPR Page");

			// Verify Optional filters Display heading
			Log.assertThat(
					cumulativePerformance.reportComponents.isDisplayHeadingPresent(ReportsUIConstants.DISPLAY_HEADER),
					"Optional filter Display heading is present in the CPR Page",
					"Optional filter Display heading is not present in the CPR Page");

			// Verify Optional filters Sort heading
			Log.assertThat(cumulativePerformance.reportComponents.isSortHeadingPresent(ReportsUIConstants.SORT_HEADER),
					"Optional filter Sort heading is present in the CPR Page",
					"Optional filter Sort heading is not present in the CPR Page");

			// Verify mask student field
			Log.assertThat(
					cumulativePerformance.reportComponents.isMaskStudentDisplayDisplayed(
							ReportsUIConstants.MASK_STUDENT),
					"Mask student field is present in the CPR page",
					"Mask student field is not present in the CPR page");

			cumulativePerformance.reportComponents.checkOrUncheckBoxMaskstudent();
			Log.message("Mask student chekbox clicked");

			cumulativePerformance.reportComponents.checkOrUncheckBoxMaskstudent();
			Log.message("Mask student chekbox Unclicked");

			// Verify Mask student performance field
			Log.assertThat(
					cumulativePerformance.reportComponents
							.isStudentPerformanceDatesPresent(ReportsUIConstants.STUDENT_PERFORMANCE_DATES),
					"student performance dates display is present in the CPR page",
					"student performance dates display field is not present in the CPR page");

			// Verify "all date" field
			Log.assertThat(cumulativePerformance.isAllDatesPresent(ReportsUIConstants.CPR_ALL_DATES),
					"All Date field is present in the CPR page", "All Date field is not present in the CPR page");

			// Verify "Selected date Range" field
			Log.assertThat(
					cumulativePerformance.isSelectedDateRangesPresent(ReportsUIConstants.CPR_SELECTED_DATE_RANGE),
					"Selected date Range field is present in the CPR page",
					"Selected date Range field is not present in the CPR page");

			// Verify Save Report Option button
			Log.assertThat(cumulativePerformance.getSaveReportOptionButton(ReportsUIConstants.SAVE_REPORTOPTIONS),
					"Saved Report option button is present", "Saved Report option button is not present!");

			// Verify Run Report
			Log.assertThat(cumulativePerformance.getRunReportOption(ReportsUIConstants.RUN_REPORT),
					"Run report button present!", "Run report not button present!");

			// Verify Run Report
			Log.assertThat(cumulativePerformance.getResetOption(ReportsUIConstants.RESET), "Reset button present!",
					"Reset not button present!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify 'CPR description text' available on CPR Page.", groups = { "SMK-66755", "reports",
			"cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR003() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR003: Verify 'CPR description text' available on CPR Page. <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Verify Cumulative Performance Sub menu
			Log.assertThat(
					dashBoardPage.reportComponents.subNavigationMenuisDisplayed(ReportTypes.CUMULATIVE_PERFORMANCE),
					"The Cumulative performance report is displayed in Report MFE sub-navigation",
					"The Cumulative performance report is not displayed in Report MFE sub-navigation");

			// Verifying CPR Report Description report
			Log.assertThat(cumulativePerformance.isReportDescriptionPresent(),
					"Cumulative Performance Report description is present and display expected text",
					"Cumulative Performance Report description is not Present or display wrong text");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify fields available after clicking on Filters option.", groups = { "SMK-66755", "reports",
			"cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR004() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR004: Verify fields available after clicking on Filters option. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Verify Optional filters Additional Grouping heading
			Log.assertThat(
					cumulativePerformance.reportComponents
							.isAdditionalGroupingHeadingPresent(ReportsUIConstants.ADDITIONAL_GROUPING_HEADER),
					"Optional filter Additional Grouping heading is present in the CPR Page",
					"Optional filter Additional Grouping heading is not present in the CPR Page");

			// Verify Optional filters Display heading
			Log.assertThat(
					cumulativePerformance.reportComponents.isDisplayHeadingPresent(ReportsUIConstants.DISPLAY_HEADER),
					"Optional filter Display heading is present in the CPR Page",
					"Optional filter Display heading is not present in the CPR Page");

			// Verify Optional filters Sort heading
			Log.assertThat(cumulativePerformance.reportComponents.isSortHeadingPresent(ReportsUIConstants.SORT_HEADER),
					"Optional filter Sort heading is present in the CPR Page",
					"Optional filter Sort heading is not present in the CPR Page");

			// Verify mask student field
			Log.assertThat(
					cumulativePerformance.reportComponents.isMaskStudentDisplayDisplayed(
							ReportsUIConstants.MASK_STUDENT),
					"Mask student field is present in the CPR page",
					"Mask student field is not present in the CPR page");

			cumulativePerformance.reportComponents.checkOrUncheckBoxMaskstudent();
			Log.message("Mask student chekbox clicked");

			cumulativePerformance.reportComponents.checkOrUncheckBoxMaskstudent();
			Log.message("Mask student chekbox Unclicked");

			// Verify Mask student performance field
			Log.assertThat(
					cumulativePerformance.reportComponents
							.isStudentPerformanceDatesPresent(ReportsUIConstants.STUDENT_PERFORMANCE_DATES),
					"student performance dates display is present in the CPR page",
					"student performance dates display field is not present in the CPR page");

			// Verify "all date" field
			Log.assertThat(cumulativePerformance.isAllDatesPresent(ReportsUIConstants.CPR_ALL_DATES),
					"All Date field is present in the CPR page", "All Date field is not present in the CPR page");

			// Verify "Selected date Range" field
			Log.assertThat(
					cumulativePerformance.isSelectedDateRangesPresent(ReportsUIConstants.CPR_SELECTED_DATE_RANGE),
					"Selected date Range field is present in the CPR page",
					"Selected date Range field is not present in the CPR page");
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Groups' dropdown field display under Filters option when only one Group is selected.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR005() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR005: Verify 'Groups' dropdown field display under Filters option when only one Group is selected. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			// Uncheck Select All checkbox
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUPS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			// get all values in dropdown
			List<String> availableOptionsFromMultiSelectDropdown = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
			Log.message(cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON).toString());

			List<String> groupOptions = new ArrayList<>();
			// groups.add("4-8 Group");

			cumulativePerformance.reportComponents
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON, groupOptions);

			// Verify the Dropdown text after selecting one Group
			if (availableOptionsFromMultiSelectDropdown.size() > 1) {
				groupOptions.add(availableOptionsFromMultiSelectDropdown.get(1));
				Log.message(groupOptions.toString());
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON, groupOptions);
				Log.assertThat(groupOptions.contains(availableOptionsFromMultiSelectDropdown.get(1)),
						"Selected group name is Displayed", "Selected group name is not Displayed");
			} else if (availableOptionsFromMultiSelectDropdown.size() == 1) {
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SELECTED_GROUPS2, groupOptions);
				Log.assertThat(
						availableOptionsFromMultiSelectDropdown
								.contains(availableOptionsFromMultiSelectDropdown.get(1)),
						"Selected group name is Displayed", "Selected group name is not Displayed");
			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();

			driver.quit();
		}
	}

	@Test(description = "Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport", "mock" }, priority = 2)
	public void tcSMCPR006(ITestContext context) throws Exception {
		// Get driver
	    WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

	
		Log.testCaseInfo(
				"tcSMCPR006: Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			
			String json = DevToolsUtils.readJsonResponse("CPR_GroupAndStudentDetails_MinimumGroup.json");
			tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);
			
			// Uncheck Select All checkbox
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUPS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			// get WebElements of dropdown option checkboxes
			List<String> allGroupsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);

			// Verify the Dropdown text after selecting multiple Groups
			List<String> groupOptions = new ArrayList<>();

			if (allGroupsFromUI.size() > 2) {
				groupOptions.add(allGroupsFromUI.get(0));
				groupOptions.add(allGroupsFromUI.get(1));
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON, groupOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
				Log.message("counted test list1:" + selectedCount);
				Log.assertThat(
						selectedCount
								.equals(ReportsUIConstants.SELECTED_DROPDOWN.replace("{{Selectedcount}}", "Choose one or more groups")),
						"Count of selected group is Displayed", "count of selected group name is not Displayed");
			} else if (allGroupsFromUI.size() == 2) {
				groupOptions.add(allGroupsFromUI.get(0));
				groupOptions.add(allGroupsFromUI.get(1));
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON, groupOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
				Log.message("counted test list2"+selectedCount);
				Log.assertThat(
						selectedCount.equals(ReportsUIConstants.SELECTED_ALL_GROUPS3
								.replace("({selected_count})", "Choose one or more groups")),
						"Count of selected group is Displayed", "count of selected group name is not Displayed");
			} else {
				Log.message("Given teacher has less than one goup");
			}
			
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify deleted groups should not display under Groups dropdown.", groups = { "SMK-66755",
			"reports", "cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR007() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR007: Verify deleted groups should not display under Groups dropdown. <small><b><i>["
				+ browser + "]</b></i></small>");
		try {

			groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
			groupDetails.put(GroupConstants.GROUP_OWNER_ID, userID);
			groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, orgId);
			groupDetails.put(GroupConstants.GROUP_NAME, className);

			HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds);

			String classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");

			String groupName = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY),
					"data,groupName");
			Log.message("The group name is" + groupName);
			String accessCode = new RBSUtils().getAccessToken(username, password);

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			
			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// get WebElements of dropdown option checkboxes
			List<String> allGroupsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
		
			Log.message(allGroupsFromUI.toString());

			Log.assertThat((allGroupsFromUI.contains(className)), "Group is created successfully!!",
					"Group is not created");

			// delete group
			HashMap<String, String> deleteGroup = deleteGroup(classId, userID, orgId, accessCode);
			Log.message(deleteGroup.toString());

			driver.navigate().refresh();

			// get WebElements of dropdown option checkboxes
			List<String> groupsAfterDeletion = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
			Log.message(groupsAfterDeletion.toString());

			Log.assertThat((!groupsAfterDeletion.contains(className)), "Deleted Group is not displayed as expected",
					"Deleted Group is displayed");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			
			driver.quit();
		}
	}

	@Test(description = "Verify 'students' dropdown field display under Filters option when more than one students are selected.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR008() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR008: Verify 'students' dropdown field display under Filters option when more than one students are selected. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			cumulativePerformance.reportComponents.clickStudentRadioButton();
			// Uncheck Select All checkbox
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.STUDENTS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			// get WebElements of dropdown option checkboxes
			List<String> allStudentsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON);

			List<String> studentOptions = new ArrayList<>();
			// Verify the Dropdown text after selecting multiple Students
			if (allStudentsFromUI.size() > 3) {
				studentOptions.add(allStudentsFromUI.get(1));
				studentOptions.add(allStudentsFromUI.get(2));
				cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
						ReportsUIConstants.STUDENTS_HEADER_BUTTON, studentOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON);
				Log.message(selectedCount);
				Log.assertThat(
						selectedCount.equals(ReportsUIConstants.SELECTED_DROPDOWN
								.replace(ReportsUIConstants.SELECTED_COUNT2, "(2)")),
						"Count of selected group is Displayed", "count of selected group name is not Displayed");
			} else if (allStudentsFromUI.size() == 3) {
				studentOptions.add(allStudentsFromUI.get(1));
				studentOptions.add(allStudentsFromUI.get(2));
				cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
						ReportsUIConstants.STUDENTS_HEADER_BUTTON, studentOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON);
				Log.message(selectedCount);
				Log.assertThat(
						selectedCount.equals(ReportsUIConstants.SELECTED_ALL_STUDENTS2
								.replace(ReportsUIConstants.SELECTED_COUNT2, "ALL")),
						"All Students text and count of the Students is Display Properly",
						"AllStudents text or count of the Students is not Display Properly");
			} else {
				Log.message("Given teacher has less than one student");
			}

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();

			driver.quit();
		}
	}

	@Test(description = "Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport", "mock" }, priority = 2)
	public void tcSMCPR009(ITestContext context) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR009: Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			if (DevToolsUtils.isMock(context)) {
				String minimumStudentJson = DevToolsUtils.readJsonResponse("CPR_Minimum_Math_Assignments.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", minimumStudentJson);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			// Uncheck Select All checkbox
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));

			// get WebElements of dropdown option checkboxes
			List<String> allAssignmentsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);

			List<String> assignmentOptions = new ArrayList<>();
			// Verify the Dropdown text after selecting multiple Students
			if (allAssignmentsFromUI.size() > 1) {
				assignmentOptions.add(allAssignmentsFromUI.get(1));
				Log.message(assignmentOptions.toString());
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING, assignmentOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);
				Log.message(selectedCount);
				Log.assertThat(assignmentOptions.contains(allAssignmentsFromUI.get(1)),
						"Selected Assignment name is Displayed", "Selected Assignment name is not Displayed");

			} else if (allAssignmentsFromUI.size() == 1) {
				assignmentOptions.add(allAssignmentsFromUI.get(1));
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING, assignmentOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);
				Log.message(selectedCount);
				Log.assertThat(
						selectedCount.equals(ReportsUIConstants.SELECTED_ALL_ASSIGNMENTS2
								.replace(ReportsUIConstants.SELECTED_COUNT2, "(All)")),
						"All Students text and count of the Students is Display Properly",
						"All Students text or count of the Students is not Display Properly");
			} else {
				Log.message("Given teacher has less than one assignment");
			}

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport", "mock" }, priority = 2)
	public void tcSMCPR010(ITestContext context) throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcSMCPR010: Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			if (DevToolsUtils.isMock(context)) {
				String json = DevToolsUtils.readJsonResponse("CPR_Maximum_Math_Assignments.json");
				tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "Assignments", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message("CDP Session : " + tools.getCdpSession().toString());
			}

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);

			// Uncheck Select All checkbox
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));

			// get WebElements of dropdown option checkboxes
			List<String> allAssignmentsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);

			List<String> assignmentOptions = new ArrayList<>();
			
			// Verify the Dropdown text after selecting multiple Students
			if (allAssignmentsFromUI.size() > 2) {
				assignmentOptions.add(allAssignmentsFromUI.get(1));
				assignmentOptions.add(allAssignmentsFromUI.get(2));
				Log.message(assignmentOptions.toString());
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING, assignmentOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);
				Log.message(selectedCount);
				Log.assertThat(
						selectedCount.equals(ReportsUIConstants.SELECTED_DROPDOWN
								.replace(ReportsUIConstants.SELECTED_COUNT2, "(2)")),
						"Count of selected group is Displayed", "count of selected group name is not Displayed");
			} else if (allAssignmentsFromUI.size() == 2) {
				assignmentOptions.add(allAssignmentsFromUI.get(1));
				assignmentOptions.add(allAssignmentsFromUI.get(2));
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING, assignmentOptions);
				String selectedCount = cumulativePerformance.reportComponents
						.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);
				Log.message(selectedCount);
				Log.assertThat(
						selectedCount.equals(ReportsUIConstants.SELECTED_ALL_ASSIGNMENTS2
								.replace(ReportsUIConstants.SELECTED_COUNT2, "ALL")),
						"All Students text and count of the Students is Display Properly",
						"AllStudents text or count of the Students is not Display Properly");

			}
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify removed assignments should not display under assignment dropdown.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport"}, priority = 2)
	public void tcSMCPR011() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR011: Verify removed assignments should not display under assignment dropdown. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
            
			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);
			
			// get WebElements of dropdown option checkboxes
			List<String> assignmentsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);
			Log.message(assignmentsFromUI.toString());

			Log.assertThat((assignmentsFromUI.contains(ReportsUIConstants.MATH)),
					"The Assignment is assigned to the student successfully!",
					"The Assignment is not assigned to the student!");

			HashMap<String, String> mathAssignmentDetails = new HashMap<>();

			mathAssignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
			mathAssignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, userID);
			mathAssignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken(username, RBSDataSetupConstants.DEFAULT_PASSWORD));
			mathAssignmentDetails.put(AssignmentAPIConstants.COURSE_ID, "1");
			mathAssignmentDetails.put(AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId.get(0));

			HashMap<String, String> deleteAssignment = new AssignmentAPI().deleteAssignment(smUrl,
					mathAssignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL);
			Log.message("Delete Assignment - " + deleteAssignment.get("body"));

			driver.navigate().refresh();
			List<String> assignmentList = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);

			Log.message(assignmentList.toString());

			Log.assertThat(!(assignmentList.contains(ReportsUIConstants.MATH)),
					"The Assignment is removed from the dropdown successfully!",
					"The Assignment is not removed from the dropdown!");
			RequestMockUtils.closeMock(tools);

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			
			driver.quit();
		}
	}

	@Test(description = "Verify count of all Groups/Students and Assignments should display beside filters,if filters has collapsed.", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport", "mock" }, priority = 2)
	public void tcSMCPR012(ITestContext context) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR012: Verify count of all Groups/Students and Assignments should display beside filters,if filters has collapsed. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			
			if (DevToolsUtils.isMock(context)) {
				
			String minimumStudentJson = DevToolsUtils.readJsonResponse("CPR_GroupAndStudentDetails_MinimumStudent.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post",
					minimumStudentJson);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());
			}
			
			// Uncheck Select All checkbox In Groups
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUPS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			// get all values in dropdown
			List<String> groupsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
			Log.message(cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON).toString());

			List<String> groupOptions = new ArrayList<>();

			cumulativePerformance.reportComponents
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON, groupOptions);

			if (groupsFromUI.size() > 1) {
				groupOptions.add(groupsFromUI.get(1));
				Log.message(groupOptions.toString());
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON, groupOptions);
				Log.assertThat(groupOptions.contains(groupsFromUI.get(1)), "Selected group name is Displayed",
						"Selected group name is not Displayed");

			} else {
				Log.message("Teacher don't have enough group");
			}

			// Uncheck Select All checkbox
			Log.message("Un-select all");
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUPS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			Log.message("select all option");
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.GROUPS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			String selectedCount = cumulativePerformance.reportComponents
					.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
			Log.message("count list"+selectedCount);
			Log.assertThat(

					selectedCount.equals(
							ReportsUIConstants.SELECTED_ALL_GROUPS2.replace("{selected_count}", "All")),

				
					"All Groups text and count of the Students is Display Properly",
					"All Groups is not Display Properly");

			// students filter
			cumulativePerformance.reportComponents.clickStudentRadioButton();

			// Uncheck Select All checkbox In Students
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.STUDENTS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			// get all values in dropdown
			List<String> studentsFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON);
			Log.message(cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON).toString());

			List<String> studentOptions = new ArrayList<>();

			cumulativePerformance.reportComponents
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON, groupOptions);

			if (studentsFromUI.size() > 1) {
				studentOptions.add(studentsFromUI.get(1));
				Log.message(studentOptions.toString());
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON, groupOptions);
				Log.assertThat(studentOptions.contains(studentsFromUI.get(1)), "Selected Student name is Displayed",
						"Selected Student name is not Displayed");

			} else {
				Log.message("Teacher don't have enough Student");
			}

			// Uncheck Select All checkbox
			Log.message("Un-select all");
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.STUDENTS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			Log.message("select all option");
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.STUDENTS_HEADER_BUTTON, Arrays.asList(ReportsUIConstants.ALL));

			String studentselectedCount = cumulativePerformance.reportComponents
					.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
			Log.message(studentselectedCount);
			Log.assertThat(
					studentselectedCount.equals(ReportsUIConstants.SELECTED_ALL_STUDENTS2
							.replace("({selected_count})", "(All)")),
					"All Students text and count of the Students is Display Properly",
					"All Students is not Display Properly");

			// Assignment filter
			cumulativePerformance.reportComponents.clickStudentRadioButton();

			// Uncheck Select All checkbox In Students
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));

			// get all values in dropdown
			List<String> assignmentFromUI = cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING);
			Log.message(cumulativePerformance.reportComponents
					.getAvailableOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING).toString());

			List<String> assignmentOptions = new ArrayList<>();

			cumulativePerformance.reportComponents
					.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING, groupOptions);

			if (assignmentFromUI.size() > 1) {
				assignmentOptions.add(assignmentFromUI.get(1));
				Log.message(assignmentOptions.toString());
				cumulativePerformance.reportComponents
						.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENT_HEADING, groupOptions);
				Log.assertThat(assignmentOptions.contains(assignmentFromUI.get(1)),
						"Selected Assignment name is Displayed", "Selected Assignment name is not Displayed");

			} else {
				Log.message("Teacher don't have enough Student");
			}

			// Uncheck Select All checkbox
			Log.message("Un-select all");
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));

			Log.message("select all option");
			cumulativePerformance.reportComponents.selectOptionsFromMultiSelectDropdown(
					ReportsUIConstants.ASSIGNMENT_HEADING, Arrays.asList(ReportsUIConstants.ALL));

			// cumulativePerformance.reportComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.STUDENTS_HEADER_BUTTON,
			// studentOptions);
			String assignmentselectedCount = cumulativePerformance.reportComponents
					.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GROUPS_HEADER_BUTTON);
			Log.message(assignmentselectedCount);
			Log.assertThat(
					assignmentselectedCount.equals(ReportsUIConstants.SELECTED_ALL_STUDENTS2
							.replace("{selected_count}", "All")),
					"All Assignments text and count of the Students is Display Properly",
					"All Assignments is not Display Properly");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify 'Additional Grouping' dropdown should display on CPR page.", groups = { "SMK-66755",
			"reports", "cumulativePerformanceReport"}, priority = 2)
	public void tcSMCPR013() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR013: Verify 'Additional Grouping' dropdown should display on CPR page. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Getting values for Additional grouping
			cumulativePerformance.reportComponents
					.expandSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_DROPDOWN);
			List<String> availableOptionsFromAdditionalGrouping = cumulativePerformance.reportComponents
					.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_DROPDOWN);
			Log.message(availableOptionsFromAdditionalGrouping.toString());

			// Validation for Additional grouping
			Log.assertThat((availableOptionsFromAdditionalGrouping).equals((ReportsUIConstants.ADDITION_GROUPING)),
					"Additional grouping information loaded successfully!",
			
			"Additional grouping information not loaded properly!");
			
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			
			driver.quit();
		}
	}

	@Test(description = "Verify 'Display' dropdown should display on CPR page", groups = { "SMK-66755", "reports",
			"cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR014() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR014: Verify 'Display' dropdown should display on CPR page <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Getting values for Display
			cumulativePerformance.reportComponents.expandSingleSelectDropdown(ReportsUIConstants.DISPLAY_HEADER);
			List<String> availableOptionsFromDisplayDropdown = cumulativePerformance.reportComponents
					.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_HEADER);
			Log.message(availableOptionsFromDisplayDropdown.toString());

			// Validation for Sort
			Log.assertThat((availableOptionsFromDisplayDropdown).equals(ReportsUIConstants.DISPLAY_lIST),
					"Display information loaded successfully!", "Display information not loaded properly!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Sort' drop down should display on CPR page.", groups = { "SMK-66755", "reports",
			"cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR015() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR015: Verify 'Sort' drop down should display on CPR page. <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Getting values for Sort
			cumulativePerformance.reportComponents.expandSingleSelectDropdown(ReportsUIConstants.SORT_HEADER);
			List<String> availableOptionsFromSortDropdown = cumulativePerformance.reportComponents
					.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_HEADER);
			Log.message(availableOptionsFromSortDropdown.toString());

			// Validation for Sort
			Log.assertThat((availableOptionsFromSortDropdown).equals((ReportsUIConstants.SORT_lIST)),
					"Sort information loaded successfully!", "Sort information not loaded properly!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify 'Start date' and 'End date'should display on CPR page.", groups = { "SMK-66755",
			"reports", "cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR016() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR016: Verify 'Start date' and 'End date'should display on CPR page. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Verify "Selected date Range" field
			Log.assertThat(
					cumulativePerformance.isSelectedDateRangesPresent(ReportsUIConstants.CPR_SELECTED_DATE_RANGE),
					"Selected date Range field is present in the CPR page",
					"Selected date Range field is not present in the CPR page");
			cumulativePerformance.reportComponents
					.clickSelectedDateRangesPresent(ReportsUIConstants.CPR_SELECTED_DATE_RANGE);
			Log.message("Expanded selected Range");

			// Verify From date field
			Log.assertThat(
					cumulativePerformance.reportComponents.isFromDateHeaderPresent(ReportsUIConstants.CPR_FROM_DATE),
					"From Date field is available in CPR Page.", "From Date field is not available in CPR Page.");
			// Verify To date field
			Log.assertThat(cumulativePerformance.reportComponents.isToHeaderPresent(ReportsUIConstants.CPR_TO_DATE),
					"To Date field is available in CPR Page.", "To Date field is not available in CPR Page.");
			// verify date picker for from date field
			Log.assertThat(cumulativePerformance.reportComponents.isDatePickerDisplayedForFomDAte(),
					"Date picker is available for From date", "Date picker is not available for From date");
			// verify date picker for To date field
			Log.assertThat(cumulativePerformance.reportComponents.isDatePickerDisplayedForFomDAte(),
					"Date picker is available for To date", "Date picker is not available for To date");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify default selection of subject dropdown", groups = { "SMK-66755", "reports",
			"cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR017() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSMCPR017: Verify default selection of subject dropdown <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Getting values for Subject
			cumulativePerformance.reportComponents.expandSingleSelectDropdown(ReportsUIConstants.SUBJECT_HEADING);
			List<String> availableOptionsFromSortDropdown = cumulativePerformance.reportComponents
					.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_HEADING);
			Log.message(availableOptionsFromSortDropdown.toString());

			cumulativePerformance.reportComponents.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH);

			// Verify default subject
			Log.assertThat(availableOptionsFromSortDropdown.contains(ReportsUIConstants.MATH),
					"Default option is checked", "Default option is not checked");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();

			driver.quit();
		}
	}

	@Test(description = "Verify the availablity and Options  of Subject dropdown in Subject filter in Cumulative Reports Page", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport" }, priority = 2)
	public void tcSMCPR018() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR018: Verify the option of Subject drop down is displayed in Cumulative Report Page <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			// Getting values for Subject
			cumulativePerformance.reportComponents.expandSingleSelectDropdown(ReportsUIConstants.SUBJECT_HEADING);
			List<String> availableOptionsFromSubjectDropdown = cumulativePerformance.reportComponents
					.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_HEADING);
			Log.message(availableOptionsFromSubjectDropdown.toString());

			Log.assertThat((availableOptionsFromSubjectDropdown).equals((ReportsUIConstants.SUBJECT_DROPDOWN_LIST)),
					"Subject information loaded successfully!", "Subject information not loaded properly!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Cumulative Performance Report Page", groups = {
			"SMK-66755", "reports", "cumulativePerformanceReport", "mock" }, priority = 1)
	public void tcSMCPR019(ITestContext context) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSMCPR019: Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Cumulative Performance Report Page <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

			if (DevToolsUtils.isMock(context)) {
				
			String minimumSavedReportJson = DevToolsUtils.readJsonResponse("CPRMinimumSavedReportOptions.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetAllReportOption", "post",
					minimumSavedReportJson);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			}
			// Getting values for Subject
			cumulativePerformance.reportComponents.expandSingleSelectDropdown(ReportsUIConstants.SUBJECT_HEADING);
			List<String> availableOptionsFromSubjectDropdown = cumulativePerformance.reportComponents
					.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_HEADING);
			Log.message(availableOptionsFromSubjectDropdown.toString());

			// get WebElements of dopdown option checkboxes
			List<String> subjectOption = new ArrayList<>();

			// Select Math from subject dropdown
			cumulativePerformance.reportComponents.selectOptionsFromSingleSelectDropdown(
					ReportsUIConstants.SUBJECT_HEADING, ReportsUIConstants.READING);

			cumulativePerformance.reportComponents.clickSaveReportOptionButton();
			SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);

			String filterName = "Filter" + System.nanoTime();
			new ReportFilterComponent(driver).enterNameForSaveReport(filterName);
			saveReportOptionPopup.clickSaveButton();
			Log.assertThat(
					cumulativePerformance.reportComponents.getAvailableOptionsFromSingleSelectDropdown(
							ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),
					"Report filter options saved successfully", "issue in saving the filter options");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
			driver.quit();
		}

	}

	@Test(description = "Verify zero state saved report option, SavedReportOption", groups = { "reports",
			"CumulativePerformanceReport", "mock" }, priority = 1)
	private void tcSM_SPR020() throws Exception {
		// Get driver
		WebDriver chromeDriver = WebDriverFactory.get(browser);
		EventFiringWebDriver driver = new EventFiringWebDriver(chromeDriver);

		Log.testCaseInfo(
				"tcSMCPR020-Verify zero state saved report option.<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			String zeroSavedReportJson = DevToolsUtils.readJsonResponse("CPRZeroSavedReportOptions.json");
			tools = RequestMockUtils.setResponse(chromeDriver, configGraphQL, "GetAllReportOption", "post",
					zeroSavedReportJson);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			SMUtils.waitForSpinnertoDisapper(driver);

		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	@Test(description = "Verify the Zero State Message for the Zero group state, GroupsandStudents", groups = {
			"reports", "CumulativePerformanceReport", "mock" }, priority = 1)
	private void tcSM_SPR021() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_SPR021 : Verify zero group option.<small><b><i>[" + browser + "]</b></i></small>");

		try {
			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			String json = DevToolsUtils.readJsonResponse("CPR_GroupAndStudentDetails_ZeroGroup.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message(tools.getCdpSession().toString());

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();

		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	@Test(description = "Verify Math assignment zero state, Assignments", groups = { "reports",
			"CumulativePerformanceReport", "mock" }, priority = 1)
	private void tcSM_SPR022() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo(
				"tcSM_SPR022: Verify Math assignment zero state.<small><b><i>[" + browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashBoardPage = smLoginPage.loginToSMATeacher(username, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			String json = DevToolsUtils.readJsonResponse("CPR_Zero_Math_Assignments.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportComponents
					.clickOnCumulativePerformanceReportPage();
			
			ReportComponents reportComponents = new ReportComponents(driver);

			String zeroStateSaveReportMessage = "No Saved report options [...]";
			Log.assertThat(reportComponents.verifyZeroStateSaveReportOption().contains(zeroStateSaveReportMessage),
					"Zero State verified!", "Zero State not verified!");

		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	@Test(description = "Verify the Zero State Message for the Zero mocked studnets data", groups = { "SMK-67096",
			"reports", "CumulativePerformanceReport", "mock" }, priority = 1)
	public void tcSM_SPR023() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("tcSM_SPR023: Verify the Zero State Message for the Zero mocked studnets data. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();
			AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMAsTeacher("teacher_ic", "password1");

			SMUtils.logDescriptionTC("Verify the Zero State Message for the Zero mocked studnets data");

			String json = DevToolsUtils.readJsonResponse("CPR_GroupAndStudentDetails_ZeroStudents.json");
			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
			tools.createSessionIfThereIsNotOne();
			Log.message("CDP Session : " + tools.getCdpSession().toString());

			// navigate to LSR Page
			CumulativePerformanceReportPage cumulativePerformance = dashBoardPage.reportFilterComponent
					.clickOnCumulativePerformanceReportPage();

			ReportFilterComponent reportFilterComponent = new ReportFilterComponent(driver);

			String zeroStateMessage = "No students exist in the database. Once students are available, you will be able to use the Reports feature.";
			Log.assertThat(reportFilterComponent.verifyZeroStateMessage().contains(zeroStateMessage),
					"Zero State verified!", "Zero State not verified.");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != tools) {
				RequestMockUtils.closeMock(tools);
			}
		}
	}

	/**
	 * delete Group
	 * 
	 * @param groupId
	 * @param teacherId
	 * @param orgId
	 * @param accessToken
	 * @return
	 */
	public HashMap<String, String> deleteGroup(String groupId, String teacherId, String orgId, String accessToken) {
		try {

			// Endpoint
			String endpoint = GroupAPIEndPoints.DELETE_GROUP_ENDPOINT;
			endpoint = endpoint.replace(GroupConstants.GROUP_ID, groupId);

			// headers
			Map<String, String> headers = new HashMap<String, String>();
			headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.AUTHORIZATION, "Bearer " + accessToken);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			headers.put(Constants.USERID_SM_HEADER, teacherId);

			// Input Parameters
			HashMap<String, String> params = new HashMap<>();

			// Make DELETE Call
			Log.message("Making DELETE Call - " + configProperty.getProperty("SMAppUrl")
					+ GroupAPIEndPoints.DELETE_GROUP_ENDPOINT);
			HashMap<String, String> response;
			try {
				response = RestHttpClientUtil.DELETE(configProperty.getProperty("SMAppUrl"), endpoint, headers, params);
				if (!response.get(Constants.STATUS_CODE).startsWith("2")) {
					Log.event("Status code : " + response.get(Constants.STATUS_CODE));
					Log.event("Response : " + response.get(Constants.REPORT_BODY));
					throw new Exception();
				}
			} catch (Exception e) {
				Log.message("Getting issue while delete the group!!!");
				Thread.sleep(3000);
				response = RestHttpClientUtil.DELETE(configProperty.getProperty("SMAppUrl"), endpoint, headers, params);
			}
			return response;
		} catch (Exception e) {
			return null;

		}
	}

}
