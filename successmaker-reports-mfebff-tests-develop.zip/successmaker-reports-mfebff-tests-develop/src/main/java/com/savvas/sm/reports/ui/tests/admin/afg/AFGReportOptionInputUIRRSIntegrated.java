package com.savvas.sm.reports.ui.tests.admin.afg;

import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class AFGReportOptionInputUIRRSIntegrated extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    List<String> getSelectedOptioUI;
    List<String> groups;
    List<String> grades;
    AreaForGrowthPage areasForGrowthReportPage;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with default option ", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth", "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_001 :Verify the selected option field in report viewer page if user select the option with default option  <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();
            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with 'Teacher' in additional grouping dropdown and 'level' in sort dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_002 :Verify the selected option field in report viewer page if user select the option with 'Teacher' in additional grouping dropdown and 'level' in sort dropdown <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Level" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_SECOND_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with 'Grade' in additional grouping dropdown and 'Skill Description' in sort dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_003() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_003 :Verify the selected option field in report viewer page if user select the option with 'Grade' in additional grouping dropdown and 'Skill Description' in sort dropdown <small><b><i>["
                + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Grade" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Skill Description" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_THIRD_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with 'group' in additional grouping dropdown and '24 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_004() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_004 :Verify the selected option field in report viewer page if user select the option with 'group' in additional grouping dropdown and '24 weeks' in Dates at risk dropdown <small><b><i>["
                + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Group" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "24 Weeks" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_FORTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with single group in group dropdown and '20 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_005() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_005 : Verify the selected option field in report viewer page if user select the option with single group in group dropdown and '20 weeks' in Dates at risk dropdown<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            groups = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "20 Weeks" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_FIFTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with multiple group in group dropdown and '16weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_006() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_006 :Verify the selected option field in report viewer page if user select the option with multiple group in group dropdown and '16weeks' in Dates at risk dropdown <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();
            groups = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groups.get( 1 ), groups.get( 2 ) ) );

            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "16 Weeks" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_SIXTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with all group in group dropdown and '12 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_007() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_007 :Verify the selected option field in report viewer page if user select the option with all group in group dropdown and '12 weeks' in Dates at risk dropdown<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            groups = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "12 Weeks" );
            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_SEVENTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with single grade in grade dropdown and '8 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_008() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_008 : Verify the selected option field in report viewer page if user select the option with single grade in grade dropdown and '8 weeks' in Dates at risk dropdown<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            grades = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( grades.get( 1 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "8 Weeks" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_EIGHT_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with multiple grade in grade dropdown and '4 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_009() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_009 : Verify the selected option field in report viewer page if user select the option with multiple grade in grade dropdown and '4 weeks' in Dates at risk dropdown<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            grades = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( grades.get( 1 ), grades.get( 2 ) ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "4 Weeks" );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_NINTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the option with all grade in grade dropdown and '2 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_010() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_010 : Verify the selected option field in report viewer page if user select the option with all grade in grade dropdown and '2 weeks' in Dates at risk dropdown<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            grades = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "2 Weeks" );
            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_TENTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the all option in student demographics  ", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_011() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_011 :Verify the selected option field in report viewer page if user select the all option in student demographics  <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( "Select All" ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( "Select All" ) );
            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_ELEVENTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Disability Status: yes'", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_012() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "SMAFGOptionIntegratedInputOptions_012 :Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Disability Status: yes' <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();

            List<String> availableOptionList = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            List<String> selectedOptions = Arrays.asList( availableOptionList.get( 1 ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, selectedOptions );
            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_TWELVETH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Disability Status: No','Ethnicity: Hispanic or Latino'", groups = { "SMK- 57895 / SMK- 57896",
            "AreasForGrowth", "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_013() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo(
                "SMAFGOptionIntegratedInputOptions_013 :Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Disability Status: No','Ethnicity: Hispanic or Latino' <small><b><i>["
                        + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();
            List<String> availableOptionList = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            List<String> selectedOptions = Arrays.asList( availableOptionList.get( 2 ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, selectedOptions );

            List<String> EthnicityOptionList = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            List<String> selectedEthnicityOptions = Arrays.asList( EthnicityOptionList.get( 1 ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, selectedEthnicityOptions );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_ELEVENTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'English Language Proficiency: 'Not Specified", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_014() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_014 :Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'English Language Proficiency: 'Not Specified <small><b><i>["
                + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();

            List<String> availableEnglishProficiencyOptionList = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            List<String> selectedEnglishProficiencyOptions = Arrays.asList( availableEnglishProficiencyOptionList.get( 3 ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, selectedEnglishProficiencyOptions );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_ELEVENTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Special Services: 'No Special Services'", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_015() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_015 : Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Special Services: 'No Special Services'<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();

            List<String> specialServicesOptionList = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            List<String> selectedSpecialServicesOptions = Arrays.asList( specialServicesOptionList.get( 5 ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, selectedSpecialServicesOptions );

            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_TWELVETH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Socioeconomic Status:All'", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth",
            "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_016() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_016 :Verify the selected option field in report viewer page if user select filter option Students by Demographics is selected as 'Socioeconomic Status:All' <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( "Select All" ) );
            AFGReportViewerPage reportviewrPage = areasForGrowthReportPage.clickRunReportButton();

            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_TWELVETH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selected option field in report viewer page if user select the single option in student demographics and '1 weeks' in Dates at risk dropdown", groups = { "SMK- 57895 / SMK- 57896", "AreasForGrowth", "AreasForGrowthReportOptionIntegratedInputUI" }, priority = 1 )
    public void SMAFGOptionIntegratedInputOptions_017() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "SMAFGOptionIntegratedInputOptions_017 :Verify the selected option field in report viewer page if user select the single option in student demographics and '1 weeks' in Dates at risk dropdown<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
            areasForGrowthReportPage = dashBoardPage.reportFilterComponent.clickOnAreaForGrowthPage();

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, "AFGReportSchool1" );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.expandOptionalFilter();

            areasForGrowthReportPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Select All" ) );

            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, "1 Week" );
            areasForGrowthReportPage.reportFilterComponent.expandStudentDemographics();
            List<String> availableOptionList = areasForGrowthReportPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            List<String> selectedOptions = Arrays.asList( availableOptionList.get( 1 ) );
            areasForGrowthReportPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, selectedOptions );

            AFGReportViewerPage reportviewrPage = dashBoardPage.clickRunReportButton();
            getSelectedOptioUI = reportviewrPage.getSelectedOptionsLegend();

            Log.assertThat( getSelectedOptioUI.containsAll( ReportsUIConstants.SELECTED_OPTIONS_LABELS_AFG_THIRTEENTH_CASE ), "All the options are showing correctly for selected option", "All select options are not showing properly" );
            Log.testCaseResult();
        
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
