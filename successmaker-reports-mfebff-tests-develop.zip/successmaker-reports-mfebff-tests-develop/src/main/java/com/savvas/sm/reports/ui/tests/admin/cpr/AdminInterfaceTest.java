package com.savvas.sm.reports.ui.tests.admin.cpr;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class AdminInterfaceTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        username = "auto_savvas_districtadmin";

    }

    @Test ( enabled = true, description = "Admin Interface Test", groups = { "SMK-30544", "Admin Interface - student multiple entry check", "AIR" }, priority = 1 )
    public void tcSMAdminInterfaceTest001(  ) throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, RBSDataSetupConstants.PASSWORD+1 );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();


            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( cumulativePerformancePage.selectOrganization("SM Regression Auto School 7" ), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();


            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( cumulativePerformancePage.selectSubject( "Reading" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.COURSES );
            cumulativePerformancePage
                    .setValuesForDropdown( cumulativePerformancePage.COURSES, coursesName.stream()
                            .filter( c->(c.contains( "Miller Rivera" ) || c.contains( "Gomez Dodson" ) ) ).collect( Collectors.toList()) );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            cumulativePerformancePage.clickOptionalFilter();


            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(cumulativePerformancePage.checkReportHeaderAfterRun(), "Cumulative Performance Report data displayed",
                    "Cumulative Performance Report data not displayed" );
            List<String> studentCourseLst = new ArrayList<>();
            int totalPage = cumulativePerformancePage.countPage();
            IntStream.range( 1,totalPage ).forEach( i -> {
                    String assignment = cumulativePerformancePage.getAssignmentName();
                    String student = cumulativePerformancePage.getStudentName();
                    studentCourseLst.add( assignment+student );
                    cumulativePerformancePage.clickNextButton();
                try {
                    SMUtils.waitForSpinnertoDisapper( driver);
                } catch ( InterruptedException e ) {
                    e.printStackTrace();
                }
            } );
            Set<String> studentSet = new HashSet<>(studentCourseLst);
            Log.assertThat(studentCourseLst.size() == studentSet.size(), "All the students are unique and no duplicate entry",
                    "Duplicate entry of students are present" );


           Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, description = "Admin Interface Test", groups = { "SMK-30544", "Admin Interface - Group By Teacher", "AIR" }, priority = 2 )
    public void tcSMAdminInterfaceTest002(  ) throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, RBSDataSetupConstants.PASSWORD+1 );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();


            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( cumulativePerformancePage.selectOrganization("SM Regression Auto School 7" ), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();


            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( cumulativePerformancePage.selectSubject( "Reading" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.COURSES );
            cumulativePerformancePage
                    .setValuesForDropdown( cumulativePerformancePage.COURSES, coursesName.stream()
                            .filter( c->(c.contains( "Miller Rivera" ) || c.contains( "Gomez Dodson" ) ) ).collect( Collectors.toList()) );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            cumulativePerformancePage.clickOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );
            cumulativePerformancePage.selectAdditionalGrouping("Teacher" );
            SMUtils.waitForSpinnertoDisapper( driver );
            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(cumulativePerformancePage.checkReportHeaderAfterRun(), "Cumulative Performance Report data displayed",
                    "Cumulative Performance Report data not displayed" );
            List<String> studentCourseLst = new ArrayList<>();
            int totalPage = cumulativePerformancePage.countPage();
            for(int i=1 ; i<=totalPage; i++){
                String student = cumulativePerformancePage.getStudentName();
                studentCourseLst.add( student );
                cumulativePerformancePage.clickNextButton();
                try {
                    SMUtils.waitForSpinnertoDisapper( driver);
                } catch ( InterruptedException e ) {
                    e.printStackTrace();
                }
            }
            Set<String> studentSet = new HashSet<>(studentCourseLst);
            Log.assertThat(studentCourseLst.size() != studentSet.size(), "same student displayed while grouping by teacher",
                    "same student not displayed while grouping by teacher" );


            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, description = "Admin Interface Test", groups = { "SMK-30544", "Admin Interface - Grouping By Group", "AIR" }, priority = 3 )
    public void tcSMAdminInterfaceTest003(  ) throws Exception {

        Log.message( "Loggin in with Admin:=> " );

        //Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, RBSDataSetupConstants.PASSWORD+1 );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();


            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( cumulativePerformancePage.selectOrganization("SM Regression Auto School 7" ), "Organization dropdown have value and selected", "Organization dropdown don't have any value" );
            Log.testCaseResult();


            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseInfo( "Verify the Subject list" );
            Log.assertThat( cumulativePerformancePage.selectSubject( "Reading" ), "Subject dropdown have value and subject is selected", "Subject dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Course list" );
            List<String> coursesName = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.COURSES );
            cumulativePerformancePage
                    .setValuesForDropdown( cumulativePerformancePage.COURSES, coursesName.stream()
                            .filter( c->(c.contains( "Miller Rivera" ) || c.contains( "Gomez Dodson" ) ) ).collect( Collectors.toList()) );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !coursesName.isEmpty(), "Course dropdown have value and course is selected", "Course dropdown don't have any value" );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.testCaseResult();

            cumulativePerformancePage.clickOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver );
            cumulativePerformancePage.selectAdditionalGrouping( "Group" );
            SMUtils.waitForSpinnertoDisapper( driver );
            cumulativePerformancePage.reportFilterComponent.clickRunReportButton();
            SMUtils.switchWindow( driver );
            SMUtils.waitForPageLoad( driver );
            SMUtils.waitForSpinnertoDisapper( driver);
            Log.assertThat(cumulativePerformancePage.checkReportHeaderAfterRun(), "Cumulative Performance Report data displayed",
                    "Cumulative Performance Report data not displayed" );
            List<String> studentCourseLst = new ArrayList<>();
            int totalPage = cumulativePerformancePage.countPage();
            for(int i=1 ; i<=totalPage; i++){
                String student = cumulativePerformancePage.getStudentName();
                studentCourseLst.add( student );
                cumulativePerformancePage.clickNextButton();
                try {
                    SMUtils.waitForSpinnertoDisapper( driver);
                } catch ( InterruptedException e ) {
                    e.printStackTrace();
                }
            }
            Set<String> studentSet = new HashSet<>(studentCourseLst);
            Log.assertThat(studentCourseLst.size() != studentSet.size(), "same student displayed while grouping by group",
                    "same student not displayed while grouping by group" );


            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


}
