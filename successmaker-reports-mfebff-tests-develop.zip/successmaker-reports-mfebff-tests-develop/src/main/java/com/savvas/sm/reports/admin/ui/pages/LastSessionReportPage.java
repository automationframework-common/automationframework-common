package com.savvas.sm.reports.admin.ui.pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.bff.admin.tests.LSRReportAdminGraphQLTest;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class LastSessionReportPage extends LoadableComponent<LastSessionReportPage> {

    WebDriver driver;
    boolean isPageLoaded;
    public AdminReportFilterComponent reportFilterComponent;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @IFindBy ( how = How.CSS, using = "report-title p.description", AI = false )
    WebElement description;

    /******************* Child Elements ******************************/

    public LastSessionReportPage() {}

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public LastSessionReportPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        reportFilterComponent = new AdminReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, description );
    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, description, 50 ) ) {
            Log.message( "Last Session Page loaded successfully." );
        } else {
            Log.fail( "Last Session Page not loaded successfully." );
        }
        elementLayer = new ElementLayer( driver );
    }

    public Map<String, Map<String, String>> getLSReportAllDataFromUI( WebDriver driver, boolean isMath ) throws InterruptedException {
        RecentSessionsPage LSPage = new RecentSessionsPage( driver );
        Map<String, Map<String, String>> lsDetails = new HashMap<>();
        SMUtils.waitForSpinnertoDisapper( driver, 5 );
        Log.message( "Getting Data From output.." );

        if ( isMath == true ) {

            List<String> studentNames = LSPage.getOutputStudentNames( driver );
            studentNames.remove( studentNames.size() - 1 );
            List<String> currentCourseLevel = LSPage.getoutputCurentCourseLevel( driver );
            currentCourseLevel.remove( currentCourseLevel.size() - 1 );
            List<String> exerciseCorrect = LSPage.getoutputExercisesCorrect( driver );
            exerciseCorrect.remove( exerciseCorrect.size() - 1 );
            List<String> exerciseAttempted = LSPage.getoutputExercisesAttempted( driver );
            exerciseAttempted.remove( exerciseAttempted.size() - 1 );
            List<String> helpUsed = LSPage.getoutputHelpUsed( driver );
            helpUsed.remove( helpUsed.size() - 1 );
            List<String> timeSpent = LSPage.getoutputTimeSpent( driver );
            timeSpent.remove( timeSpent.size() - 1 );
            List<String> totalSessions = LSPage.getoutputTotalSessions( driver );
            totalSessions.remove( totalSessions.size() - 1 );
            List<String> sessionDate = LSPage.getoutputSessionDate( driver );
            timeSpent.remove( timeSpent.size() - 1 );
            sessionDate.remove( sessionDate.size() - 1 );

            IntStream.range( 0, timeSpent.size() ).forEach( itr -> {

                List<Integer> hoursTS = timeSpent.stream().map( s -> Integer.parseInt( s.substring( 0, 2 ) ) * 60 ).collect( Collectors.toList() );

                List<Integer> minTS = timeSpent.stream().map( s -> Integer.parseInt( s.substring( 3 ).replace( "*", "" ) ) ).collect( Collectors.toList() );

                List<Integer> totalTimeSpentInt = IntStream.range( 0, hoursTS.size() ).mapToObj( i -> hoursTS.get( i ) + minTS.get( i ) ).collect( Collectors.toList() );

                List<String> totalTimeSpent = convertIntListToStringList( totalTimeSpentInt, s -> String.valueOf( s ) );

                Map<String, String> values = new HashMap<>();
                values.put( "currentCourseLevel", currentCourseLevel.get( itr ).toString() );
                values.put( "exercisesCorrect", exerciseCorrect.get( itr ).toString() );
                values.put( "exercisesAttempted", exerciseAttempted.get( itr ).toString() );
                values.put( "helpUsed", helpUsed.get( itr ).toString() );
                values.put( "timeSpent", totalTimeSpent.get( itr ).toString() );
                values.put( "totalSessionCount", totalSessions.get( itr ).toString() );
                values.put( "sessionDate", sessionDate.get( itr ).toString() );
                lsDetails.put( studentNames.get( itr ), values );
            } );
            Log.message( "Final UI Details: " + lsDetails );
            return lsDetails;

        } else {

            List<String> studentNames = LSPage.getOutputStudentNames( driver );
            studentNames.remove( studentNames.size() - 1 );
            List<String> currentCourseLevel = LSPage.getoutputCurentCourseLevel( driver );
            currentCourseLevel.remove( currentCourseLevel.size() - 1 );
            List<String> exerciseCorrect = LSPage.getoutputExercisesCorrect( driver );
            exerciseCorrect.remove( exerciseCorrect.size() - 1 );
            List<String> exerciseAttempted = LSPage.getoutputExercisesAttempted( driver );
            exerciseAttempted.remove( exerciseAttempted.size() - 1 );
            List<String> helpUsed = LSPage.getoutputHelpUsedRead( driver );
            helpUsed.remove( helpUsed.size() - 1 );
            List<String> timeSpent = LSPage.getoutputTimeSpentRead( driver );
            timeSpent.remove( timeSpent.size() - 1 );
            List<String> totalSessions = LSPage.getoutputTotalSessionsRead( driver );
            totalSessions.remove( totalSessions.size() - 1 );
            List<String> sessionDate = LSPage.getoutputSessionDateRead( driver );
            timeSpent.remove( timeSpent.size() - 1 );
            sessionDate.remove( sessionDate.size() - 1 );

            IntStream.range( 0, timeSpent.size() ).forEach( itr -> {

                List<Integer> hoursTS = timeSpent.stream().map( s -> Integer.parseInt( s.substring( 0, 2 ) ) * 60 ).collect( Collectors.toList() );

                List<Integer> minTS = timeSpent.stream().map( s -> Integer.parseInt( s.substring( 3 ).replace( "*", "" ) ) ).collect( Collectors.toList() );

                List<Integer> totalTimeSpentInt = IntStream.range( 0, hoursTS.size() ).mapToObj( i -> hoursTS.get( i ) + minTS.get( i ) ).collect( Collectors.toList() );

                List<String> totalTimeSpent = convertIntListToStringList( totalTimeSpentInt, s -> String.valueOf( s ) );

                Map<String, String> values = new HashMap<>();
                values.put( "currentCourseLevel", currentCourseLevel.get( itr ).toString() );
                values.put( "exercisesCorrect", exerciseCorrect.get( itr ).toString() );
                values.put( "exercisesAttempted", exerciseAttempted.get( itr ).toString() );
                values.put( "helpUsed", helpUsed.get( itr ).toString() );
                values.put( "timeSpent", totalTimeSpent.get( itr ).toString() );
                values.put( "totalSessionCount", totalSessions.get( itr ).toString() );
                values.put( "sessionDate", sessionDate.get( itr ).toString() );
                lsDetails.put( studentNames.get( itr ), values );
            } );
            Log.message( "Final UI Details: " + lsDetails );
            return lsDetails;
        }
    }

    // Generic function to convert List of String to List of String
    public static <T, U> List<U> convertIntListToStringList( List<T> listOfInteger, Function<T, U> function ) {
        return Lists.transform( listOfInteger, function );
    }

    /**
     * To get data from given response for MFE Integration
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public Map<String, Map<String, String>> getLSDataFromResponse( String responseBody, boolean isSkillStandardCourse ) {

        // Getting data from response
        LSRReportAdminGraphQLTest LSRObject = new LSRReportAdminGraphQLTest();
        JSONObject jsonObj = new JSONObject( LSRObject.getKeyValueFromResponseWithArray( responseBody, "data" ) );
        JSONArray response = jsonObj.getJSONArray( "getLSAdminReportData" );
        Map<String, Map<String, String>> lsDetails = new HashMap<>();

        IntStream.range( 0, response.length() ).forEach( itr -> {
            //Formatting Time Spent Values into Seconds
            String timeSpent = SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,timeSpent" );
            String hour;
            String min;
            if ( timeSpent.length() == 5 ) {
                hour = timeSpent.substring( 0, 2 );
                min = timeSpent.substring( 3 );

            } else {
                hour = timeSpent.substring( 0, 1 );
                min = timeSpent.substring( 2 );
            }
            int hourInt = Integer.parseInt( hour );
            int minInt = Integer.parseInt( min );
            int timeSpentValue = hourInt * 60 + minInt;

            //Formatting Session Date Values into MM/YY/YYYY format
            String sessionDate = SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,sessionDate" );

            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern( "yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.ENGLISH );
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern( "MM/dd/yyyy", Locale.ENGLISH );
            LocalDate date = LocalDate.parse( sessionDate, inputFormatter );
            String formattedDate = outputFormatter.format( date );
            Log.message( "formattedDate: " + formattedDate );

            Map<String, String> values = new HashMap<>();

            if ( isSkillStandardCourse == false ) {
                values.put( "currentCourseLevel", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "currentCourseLevel" ) );
                values.put( "exercisesCorrect", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "rawPerformance,exercisesCorrect" ) );
                values.put( "exercisesAttempted", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "rawPerformance,exercisesAttempted" ) );
                values.put( "helpUsed", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,helpUsed" ) );
                values.put( "timeSpent", String.valueOf( timeSpentValue ) );
                values.put( "totalSessionCount", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,totalSessions" ) );
                values.put( "sessionDate", formattedDate );
                lsDetails.put( String.valueOf( itr ), values );
            } else {
                values.put( "currentCourseLevel", "NA" );
                values.put( "exercisesCorrect", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "rawPerformance,exercisesCorrect" ) );
                values.put( "exercisesAttempted", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "rawPerformance,exercisesAttempted" ) );
                values.put( "helpUsed", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,helpUsed" ) );
                values.put( "timeSpent", String.valueOf( timeSpentValue ) );
                values.put( "totalSessionCount", SMUtils.getKeyValueFromResponse( response.get( itr ).toString(), "usage,totalSessions" ) );
                values.put( "sessionDate", formattedDate );
                lsDetails.put( String.valueOf( itr ), values );
            }

        } );
        return lsDetails;
    }

    /**
     * To Click the Run Report button
     * 
     * @return
     */
    public LastSessionReportViewerPage clickRunReportButton() {
        reportFilterComponent.clickRunReportButton();
        return new LastSessionReportViewerPage( driver ).get();
    }

    public String getAssignmentNameWithTeacerName( String assignmentTitle ) {
        RBSUtils rbsUtils = new RBSUtils();
        String queryLS = adminLSRConstants.GET_ASSIGNMENT_OWNER_ID + "'" + assignmentTitle + "'";
        Log.message( "queryLS: " + queryLS );
        List<String> assignmentownerID = new ArrayList<String>();
        List<Object[]> rowList = SQLUtil.executeQuery( queryLS );

        rowList.forEach( object -> {
            assignmentownerID.add( object[0].toString() );
        } );

        Log.message( "assignmentOwnerId: " + assignmentownerID.get( 0 ) );
        String assignmentOwnerName = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( assignmentownerID.get( 0 ) ), "firstAndLastName" );
        String assignmentName = assignmentTitle + " " + "(" + assignmentOwnerName + ")";
        Log.message( "assignmentName: " + assignmentName );
        return assignmentName;
    }

}