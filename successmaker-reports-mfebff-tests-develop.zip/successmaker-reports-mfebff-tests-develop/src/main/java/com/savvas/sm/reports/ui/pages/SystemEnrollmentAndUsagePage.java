package com.savvas.sm.reports.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

public class SystemEnrollmentAndUsagePage extends LoadableComponent<SystemEnrollmentAndUsagePage> {

	private final WebDriver driver;
	boolean isPageLoaded;
	public ReportFilterComponent reportFilterComponent;

	// *********Login Page Elements ***************

	@FindBy(tagName = "h1")
	WebElement pageTitle;

	@FindBy(css = "cel-checkbox-item.hydrated")
	WebElement checkBoxParent;

	@FindBy(css = "cel-tab-panel.tab-panel")
	WebElement toggleButton;

	@FindBy(css = "report-footer cel-button")
	WebElement runReportButton;

	/************************** Child Elements *******************************/

	public static String maskStudentCheckBoxCSS = "label.form-control input";
	private String selectedButton = "button.selected";

	String button = "button";

	/**
	 * 
	 * Constructor class for Login page Here we initializing the driver for page
	 * factory objects.
	 * 
	 * @param driver
	 * @param url
	 */
	public SystemEnrollmentAndUsagePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		reportFilterComponent = new ReportFilterComponent(driver);
	}

	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForElement(driver, pageTitle);

	}

	@Override
	protected void isLoaded() throws Error {
		try {
			SMUtils.waitForSpinnertoDisapper(driver, 30);
		} catch (InterruptedException e) {
			Log.message("Issue in Spinner Loading");
		}
		if (SMUtils.waitForElement(driver, pageTitle, 30)) {
			Log.message("System Enrollment And Usage Page loaded successfully.");
		} else {
			Log.fail("System Enrollment And Usage Page not loaded successfully.");
		}

	}

	/**
	 * click check box Mask Student CheckBox
	 */
	public void clickMaskStudentCheckBox() {
		SMUtils.waitForElement(driver, checkBoxParent, 10);
		WebElement element = SMUtils.getWebElementDirect(driver, checkBoxParent, maskStudentCheckBoxCSS);
		SMUtils.scrollIntoView(driver, element);
		SMUtils.click(driver, element);
		Log.message("Mask Student Checkbox is checked");
	}

	/**
	 * Mask student selected or not validation
	 * 
	 * @return
	 */
	public Boolean isMaskStudentSelected() {
		SMUtils.waitForElement(driver, checkBoxParent);
		WebElement element = SMUtils.getWebElementDirect(driver, checkBoxParent, maskStudentCheckBoxCSS);
		Log.message("Mask student checkbox checked successfully ");
		return element.isSelected();
	}

	/**
	 * To verify the sub navigation is selected or not
	 * 
	 * @return
	 */
	public boolean isAFGReportSelected() {
		// TODO Auto-generated method stub
		Log.message("Verifing  Areas For Growth Report is selected");
		return SMUtils.getWebElementDirect(driver, toggleButton, selectedButton).getText().trim()
				.equalsIgnoreCase(ReportTypes.AREAS_FOR_GROWTH);

	}

	/**
	 * To get all Selected Filters in SEU Report Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> getAllSelectedFilters() throws Exception {

		SMUtils.nap(0.6); // It is required to load all element after saving report

		HashMap<String, String> selectedFilters = new HashMap<String, String>();
		selectedFilters.put(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, this.reportFilterComponent
				.getPlaceHolderFromSingleSelectSubjectDropdown(ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL));
		selectedFilters.put(ReportsUIConstants.SEU_SUJECT_LBL, this.reportFilterComponent
				.getPlaceHolderFromSingleSelectSubjectDropdown(ReportsUIConstants.SEU_SUJECT_LBL));
		selectedFilters.put(ReportsUIConstants.SORT_LABEL, this.reportFilterComponent
				.getPlaceHolderFromSingleSelectSubjectDropdown(ReportsUIConstants.SORT_LABEL));
		selectedFilters.put(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, this.reportFilterComponent
				.getPlaceHolderFromSingleSelectSubjectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL));
		selectedFilters.put(ReportsUIConstants.DISABILITY_STATUS,
				this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS));
		selectedFilters.put(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, this.reportFilterComponent
				.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY));
		selectedFilters.put(ReportsUIConstants.ETHNICITY,
				this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY));
		selectedFilters.put(ReportsUIConstants.MIGRANT_STATUS,
				this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS));
		selectedFilters.put(ReportsUIConstants.RACE,
				this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.RACE));
		selectedFilters.put(ReportsUIConstants.SPECIAL_SERVICES,
				this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES));
		selectedFilters.put(ReportsUIConstants.SOCIOECONOMIC_STATUS, this.reportFilterComponent
				.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS));

		if (isMaskStudentSelected())
			selectedFilters.put(ReportsUIConstants.MASK_STUDENT_DISPLAY, "Checked");
		else
			selectedFilters.put(ReportsUIConstants.MASK_STUDENT_DISPLAY, "unchecked");

		return selectedFilters;
	}

	/**
	 * To Click RunReport Button
	 * 
	 * @return
	 */
	public SystemEnrollmentAndUsageReportViewerPage clickRunReportButton() {
		try {
			WebElement webElementDirect = SMUtils.getWebElementDirect(driver, runReportButton, button);
			SMUtils.clickJS(driver, webElementDirect);
			Log.message("Clicked Run report Button");
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
			wait.until(ExpectedConditions.numberOfWindowsToBe(3));
			ArrayList<String> child = new ArrayList<>(driver.getWindowHandles());
			driver.switchTo().window(child.get(2));
		} catch (Exception e) {
			Log.message("Unable to click the run report button!!!");
		}
		return new SystemEnrollmentAndUsageReportViewerPage(driver).get();
	}
	
	 public boolean checkReportHeaderAfterRun() {
	        try {
	            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( "h2.header" ), 10000 );
	            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( "h2.header" ) ), 5000 );
	            WebElement heading = driver.findElement( By.cssSelector( "h2.header" ) );
	            return heading.getText().equals( "System Enrollment and Usage" );
	        } catch ( Exception e ) {
	            e.printStackTrace();
	            Log.message( "Header not found" );
	        }
	        return false;
	    }

}
