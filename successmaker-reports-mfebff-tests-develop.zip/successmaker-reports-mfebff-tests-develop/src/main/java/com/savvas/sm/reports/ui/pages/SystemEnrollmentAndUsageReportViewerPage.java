package com.savvas.sm.reports.ui.pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportSubHeader;
import com.savvas.sm.reports.constants.ReportsUIConstants.SEUReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.SEUReportSelectedOptions;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;

public class SystemEnrollmentAndUsageReportViewerPage extends LoadableComponent<SystemEnrollmentAndUsageReportViewerPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    // *********Report Viewer Page Elements ***************

    @FindBy ( tagName = "h2" )
    WebElement pageTitle;

    @FindBy ( css = ".report-sub-header" )
    WebElement subHeader;

    @FindBy ( css = "dl.info dt" )
    List<WebElement> subHeaderFields;

    @FindBy ( css = "dl.info dd" )
    List<WebElement> subHeaderFieldValues;

    @FindBy ( css = "span.pagination-text-suffix" )
    WebElement totalPageCount;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement nextBtnRoot;

    @FindBy ( css = "table.system-enrollment-and-usage" )
    WebElement reportTable;

    @FindBy ( css = "thead .header th" )
    List<WebElement> tableHeaders;

    @FindBy ( css = "thead .sub-header th" )
    List<WebElement> tableSubHeaders;

    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> selectedOptions;

    @FindBy ( css = "table tbody tr" )
    List<WebElement> gridValues;

    @FindBy ( css = "demographic-details dd" )
    List<WebElement> demographicValues;

    @FindBy ( css = "demographic-details dt" )
    List<WebElement> demographicFilters;

    @FindBy ( css = "report-grid error" )
    WebElement noDataToDisplay;

    /************************** Child Elements *******************************/

    String tabledata = "td";
    String columnValue = "td:nth-of-type(%s)";
    String button = "button.button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public SystemEnrollmentAndUsageReportViewerPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "System Enrollment And Usage output page loaded successfully." );
        } else {
            Log.fail( "System Enrollment And Usage output page is not loaded successfully." );
        }
    }

    /**
     * To verify Sub Header is displayed
     * 
     * @return
     */
    public boolean verifySubHeaderIsDisplayed() {
        SMUtils.waitForElement( driver, subHeader );
        return SMUtils.isElementPresent( subHeader );
    }

    /**
     * To get Sub Header fields
     * 
     * @return
     */
    public List<String> getSubHeaderFields() {
        SMUtils.waitForElement( driver, subHeader );
        return subHeaderFields.stream().map( text -> SMUtils.getTextOfWebElement( text, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get report table header fields
     * 
     * @return
     */
    public List<String> getReportTableHeaderFields() {
        SMUtils.waitForElement( driver, subHeader );
        return tableHeaders.stream().map( text -> SMUtils.getTextOfWebElement( text, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get report table Sub Header fields
     * 
     * @return
     */
    public List<String> getReportTableSubHeaderFields() {
        SMUtils.waitForElement( driver, subHeader );
        return tableSubHeaders.stream().map( text -> SMUtils.getTextOfWebElement( text, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To get Sub Header filed values
     * 
     * @param value
     * @return
     * @throws InterruptedException
     */
    public List<String> getSubHeaderValues( ReportSubHeader value ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable );
        List<String> subHeaderValues = new ArrayList<>();
        IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
            subHeaderValues.add( subHeaderFieldValues.get( value.ordinal() ).getText().trim() );
            WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
            if ( nextBtn.isEnabled() ) {
                SMUtils.click( driver, nextBtn );
            }
        } );
        return subHeaderValues;
    }

    /**
     * To get Selected Option text
     * 
     * @param value
     * @return
     */
    public String getSelectedOptions( SEUReportSelectedOptions value ) {
        SMUtils.waitForElement( driver, reportTable );
        return selectedOptions.get( value.ordinal() ).getText().trim();
    }

    /**
     * To get UI grid values
     * 
     * @return
     */
    public Map<String, Map<String, String>> getGridvalues() {
        SMUtils.waitForElement( driver, reportTable );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();

            gridValue.put( "Student Name", columnData.get( 0 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 2 ), columnData.get( 2 ).getText().trim().equals( "NA" ) ? "" : columnData.get( 2 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 3 ), SEUReportConstants.NO_DATA.contains( columnData.get( 3 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 3 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 4 ), SEUReportConstants.NO_DATA.contains( columnData.get( 4 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 4 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 5 ), SEUReportConstants.NO_DATA.contains( columnData.get( 5 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 5 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 6 ), SEUReportConstants.NO_DATA.contains( columnData.get( 6 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 6 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 7 ), SEUReportConstants.NO_DATA.contains( columnData.get( 7 ).getText().trim() ) ? "0" : columnData.get( 7 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 8 ), SEUReportConstants.NO_DATA.contains( columnData.get( 8 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 8 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 9 ), SEUReportConstants.NO_DATA.contains( columnData.get( 9 ).getText().trim() ) ? "0" : dateFormat( columnData.get( 9 ).getText() ) );

            allGridValues.put( columnData.get( 1 ).getText().trim(), gridValue );
        } );
        Log.message( "Grid values: " + allGridValues );
        return allGridValues;
    }

    /**
     * To get UI grid values for Math
     * 
     * @return
     */
    public Map<String, Map<String, String>> getGridvaluesForMath() {
        SMUtils.waitForElement( driver, reportTable );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();

            gridValue.put( "Student Name", columnData.get( 0 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 2 ), columnData.get( 2 ).getText().trim().equals( "NA" ) ? "" : columnData.get( 2 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 3 ), SEUReportConstants.NO_DATA.contains( columnData.get( 3 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 3 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 5 ), SEUReportConstants.NO_DATA.contains( columnData.get( 4 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 4 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 6 ), SEUReportConstants.NO_DATA.contains( columnData.get( 5 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 5 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 7 ), SEUReportConstants.NO_DATA.contains( columnData.get( 6 ).getText().trim() ) ? "0" : columnData.get( 6 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 8 ), SEUReportConstants.NO_DATA.contains( columnData.get( 7 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 7 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 9 ), SEUReportConstants.NO_DATA.contains( columnData.get( 8 ).getText().trim() ) ? "0" : dateFormat( columnData.get( 8 ).getText() ) );

            allGridValues.put( columnData.get( 1 ).getText().trim(), gridValue );

        } );
        Log.message( "Grid values: " + allGridValues );
        return allGridValues;
    }

    /**
     * To get UI grid values for Reading
     * 
     * @return
     */
    public Map<String, Map<String, String>> getGridvaluesForReading() {
        SMUtils.waitForElement( driver, reportTable );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();

            gridValue.put( "Student Name", columnData.get( 0 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 2 ), columnData.get( 2 ).getText().trim().equals( "NA" ) ? "" : columnData.get( 2 ).getText().trim() );

            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 4 ), SEUReportConstants.NO_DATA.contains( columnData.get( 3 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 3 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 5 ), SEUReportConstants.NO_DATA.contains( columnData.get( 4 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 4 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 6 ), SEUReportConstants.NO_DATA.contains( columnData.get( 5 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 5 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 7 ), SEUReportConstants.NO_DATA.contains( columnData.get( 6 ).getText().trim() ) ? "0" : columnData.get( 6 ).getText().trim() );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 8 ), SEUReportConstants.NO_DATA.contains( columnData.get( 7 ).getText().trim() ) ? "0" : convertHoursToMinutes( columnData.get( 7 ).getText() ) );
            gridValue.put( SEUReportConstants.SUB_HEADERS.get( 9 ), SEUReportConstants.NO_DATA.contains( columnData.get( 8 ).getText().trim() ) ? "0" : dateFormat( columnData.get( 8 ).getText() ) );

            allGridValues.put( columnData.get( 1 ).getText().trim(), gridValue );

        } );
        Log.message( "Grid values: " + allGridValues );
        return allGridValues;
    }

    /**
     * To convert hours to minutes
     * 
     * @param time
     * @return
     */
    public String convertHoursToMinutes( String time ) {
        String totalMinute = null;
        try {
            String[] splitTime = time.trim().split( ":" );
            int hour = Integer.parseInt( splitTime[0] );
            int min = Integer.parseInt( splitTime[1] );
            totalMinute = String.valueOf( hour * 60 + min );
        } catch ( Exception e ) {
            Log.message( "Given date is an invalid time format: " + time );
        }
        return totalMinute;

    }

    /**
     * To format the given date as yyyy-MM-dd
     * 
     * @param date
     * @return
     */
    public String dateFormat( String date ) {
        String formatedDate = null;
        try {
            SimpleDateFormat actualDateFormat = new SimpleDateFormat( "MM/dd/yyyy" );
            SimpleDateFormat expectedDateFormat = new SimpleDateFormat( "yyyy-MM-dd" );
            formatedDate = expectedDateFormat.format( actualDateFormat.parse( date ) );
        } catch ( Exception e ) {
            Log.message( "Given date is an invalid date format: " + date );
        }
        return formatedDate;
    }

    /**
     * To get UI grid values
     * 
     * @return
     */
    public boolean sortAndCompareColumnvalues( String columnName ) {
        SMUtils.waitForElement( driver, reportTable );
        List<String> columnValueList = new ArrayList<>();

        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, SEUReportConstants.SORT.indexOf( columnName ) + 1 ) ) );
            IntStream.range( 0, columnData.size() ).forEach( itr -> {
                if ( !SEUReportConstants.NO_DATA.contains( columnData.get( itr ).getText().trim() ) ) {
                    columnValueList.add( columnData.get( itr ).getText().trim() );
                }
            } );
        } );
        if ( columnName.equals( SEUReportConstants.SORT.get( 6 ) ) ) {
            return columnValueList.stream().map( x -> Integer.parseInt( x ) ).sorted().collect( Collectors.toList() ).toString().equals( columnValueList.toString() );
        } else {
            return columnValueList.stream().sorted( String.CASE_INSENSITIVE_ORDER ).collect( Collectors.toList() ).equals( columnValueList );
        }
    }

    /**
     * To verify demographic filter values
     * 
     * @param demographicName
     * @param selectedDemographics
     * @return
     * @throws InterruptedException
     */
    public boolean verifyDemographicValues( String demographicName, List<String> selectedDemographics ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable );
        List<String> demographicFilter = demographicFilters.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
        String[] split = demographicValues.get( demographicFilter.indexOf( demographicName + ":" ) ).getText().trim().split( ", " );
        boolean allMatch = IntStream.range( 0, split.length ).allMatch( itr -> selectedDemographics.get( itr ).equals( split[itr] ) );
        return allMatch;
    }

    /**
     * To verify zero state message is displayed
     * 
     * @return
     */
    public boolean isZeroStateMessageDisplayed() {
        boolean flag;
        try {
            SMUtils.waitForElement( driver, noDataToDisplay );
            flag = noDataToDisplay.isDisplayed();
            Log.message( noDataToDisplay.getText().trim() );
        } catch ( Exception e ) {
            Log.message( "Zero state message is not dislpayed" );
            flag = false;
        }
        return flag;
    }

}