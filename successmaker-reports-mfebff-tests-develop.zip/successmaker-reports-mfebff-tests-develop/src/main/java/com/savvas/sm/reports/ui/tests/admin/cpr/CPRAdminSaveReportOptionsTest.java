package com.savvas.sm.reports.ui.tests.admin.cpr;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants.LSAdminReportDBQuery;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;

public class CPRAdminSaveReportOptionsTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgName;
    private String subDistrictOrgName;
    private String orgId;
    private String subDistId;
    private List<String> courses;
    private String groupId;
    private String firstTeacherOrgID;
    private String firstTeacherUserName;
    private String firstTeacherId;
    private String specificFilterName;
    private String subDistAdminUserName;
    private String schoolUnderSubDistrictId;
    private String orgNameUnderSubDist;
    private String schoolAdminUserName;
    private String schoolAdminUserId;
    private String adminSchoolId;
    private String orgNameUnderSchool;
    RBSUtils rbs = new RBSUtils();
    CourseAPI coursesMethod = new CourseAPI();


    @BeforeClass
    public void initTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        //District Admin Details
        username = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        orgId = ReportDataCollection.orgId;

        //Selected School Name
        orgName = SMUtils.getKeyValueFromResponse(rbs.getOrg(orgId), "name") ;

        //Sub-District Admin Details
        subDistAdminUserName = ReportDataCollection.subDistrictAdmin;
        subDistId = SMUtils.getKeyValueFromResponse( ReportDataCollection.subDistrictAdminDetails, "primaryOrgId" );
        subDistrictOrgName = SMUtils.getKeyValueFromResponse(rbs.getOrg(subDistId), "name") ;
        schoolUnderSubDistrictId = new RBSUtils().getOrganizationIDByName( subDistId, configProperty.getProperty( "Rumba_subDistrictSchool" ) );
        orgNameUnderSubDist = configProperty.getProperty( "Rumba_subDistrictSchool" );

        //School Admin Details
        schoolAdminUserName = ReportDataCollection.schoolAdmin;
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.schoolAdminDetails, "userId" );
        adminSchoolId = SMUtils.getKeyValueFromResponse( ReportDataCollection.schoolAdminDetails, "primaryOrgId" );
        orgNameUnderSchool = SMUtils.getKeyValueFromResponse(rbs.getOrg(adminSchoolId), "name") ;

        //Teacher Details
        firstTeacherOrgID =ReportDataCollection.orgId;
        firstTeacherUserName = ReportDataCollection.teacherDetails.keySet().toArray()[0].toString();
        firstTeacherId = rbs.getUserIDByUserName( firstTeacherUserName );

        Log.message("BeforeTest Logs: " + new RBSUtils().getOrg(subDistId) );
        Log.message("BeforeTest Logs: " + username);
        Log.message("BeforeTest Logs: " + password);
        Log.message("BeforeTest Logs: " + orgId);
        Log.message("BeforeTest Logs: " + orgName);
        Log.message("BeforeTest Logs: " + subDistId);
        Log.message("BeforeTest Logs: " + subDistrictOrgName);

        specificFilterName = "SpecficFilter" + System.nanoTime();
    }


    @Test ( description = "Verify 'Save Report Option'  button in Cumulative Performance Report page", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRSaveReportOptions001: Verify 'Save Report Option'  button in Cumulative Performance Report page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Admin User: " + username );
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC001: Verify 'Save Report Option'  button in Cumulative Performance Report page" );
            SMUtils.logDescriptionTC( "TC026: Verify User can able to save the report option with Single options in all required and optional filters with Subject(Reading) " );
            Log.assertThat( CPReport.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in CP report","The save report option is not displayed in CP report" );
            Log.assertThat( !CPReport.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );
            Log.testCaseResult();

            //Organization, Subject and Course Drop downs
            SMUtils.logDescriptionTC( "TC022: Verify User can able to save the report option with default Optional filters." );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );

            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 0 ) ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Student Demographic Drop-downs
            CPReport.reportFilterComponent.expandStudentDemographics();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 0 ) ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 0 ) ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 0 ) ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 0 ) ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 0 ) ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 0 ) ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 0 ) ) );

            SMUtils.logDescriptionTC( "TC002: Verify user can click the 'Save Report Option'  button in Cumulative Performance Report page" );
            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC003: Verify all available fields in 'Save Report Option  Popup for CP Admin Report" );
            SMUtils.logDescriptionTC( "TC004: Verify Save Report Header is getting displayed in the Save Report Option popup for CP report" );
            SMUtils.logDescriptionTC( "TC005: Verify \"Name and save this new custom report configuration.\" title is displayed above the new report filter textbox  in the Save Report Option popup modal for CP report" );
            SMUtils.logDescriptionTC( "TC006: Verify Help icon(?) along with Save Report Options  title is displayed  in the Save Report Option popup modal for CP report" );
            Log.assertThat( saveReportOptionPopup.isSaveReportOptionsHeaderDisplayed(), "Save Report Option Header is displayed as expected!", "Save Report Option Header is not displayed as expected!!" );
            Log.assertThat( saveReportOptionPopup.isHelpIconInHeaderDisplayed(), "Help Icon(?) in Header is displayed as expected!", "Help Icon(?) in Header is not displayed !!!" );
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly","New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );

            SMUtils.logDescriptionTC( "TC007: Verify \"Name new custom report configuration\" placeholder is getting displayed inside the textbox for the new save Report option textbox in the Save Report Option popup modal for CP Report" );
            Log.assertThat( saveReportOptionPopup.ValidateNewReportFilterPlaceholder( "Name new custom report configuration" ), "Expected text is present Save Report options dialog box","Expected text is Not Present in Save Report options dialog box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC008: Verify \"Select an existing custom report configuration to be replaced/updated.\" title is displayed above the existing report filers dropdown in the Save Report option popup modal for CP Report " );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly","New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC010: Verify that \"Save\" button is in disabled state by default when user enters into the Save Report option popup  of CPR repor" );
            SMUtils.logDescriptionTC( "TC011: Verify if click the save button with empty Name in 'Save Report Option' Popup for CP Report" );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC018: Verify User can able to click the cancel in save report option of CP Report" );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat(  CPReport.reportFilterComponent.isReportTitleDisplayed(), "The Save Report popup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC014: Verify User can able to save the report option with new name for CP report" );
            SMUtils.logDescriptionTC( "TC020: Verify If User enter less than 50 characters in new custom report configuration text box of CP Report." );
            saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = specificFilterName;
            Log.message("Filter Name: " + filterName);
            saveReportOptionPopup.enterNameForSaveReport( filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat( CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );

            SMUtils.logDescriptionTC( "TC038: Verify User can able to save the report with same name after selecting the existing saved report filter from CP report input page" );
            SMUtils.nap( 5 );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            
            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            SMUtils.logDescriptionTC( "TC030: Verify User can able to save the report option with Additional grouping as 'Teacher' , Display as 'Student ID' with Mask student display disbabled and Sort as 'Current Course Level' with all the available other optional filters " );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT.get( 1 ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            
            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            SMUtils.logDescriptionTC("TC029: Verify User can able to save the report option with Additional grouping as 'None' , Display as 'Student Name' with Mask student display enabled and Sort as 'Student' with all the available other optional filters ");
            try {
                CPReport.clickMaskStudentCheckBox();
                Log.message( "Clicked Mask Student Radio button" );
            } catch ( Exception e ) {
                Log.message( "Issue in clicking Mask student Radio button" );
            }
           
            CPReport.reportFilterComponent.clickSaveReportOptionButton();
            SMUtils.waitForSpinnertoDisapper( driver );
            saveReportOptionPopup.clickSaveButton();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }



    @Test ( description = "Verify User can able to save the report option with single options in all required and optional filters  with Subject (Math)", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcCPRSaveReportOptions002: Verify User can able to save the report option with single options in all required and optional filters  with Subject (Math)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            Log.message( "Login in with Admin User: " + username );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );

            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SMUtils.logDescriptionTC( "TC015: Verify User can able to save the report option with special characters, String, Integer  for CP report" );
            SMUtils.logDescriptionTC( "TC024: Verify User can able to save the report option with single options in all required and optional filters  with Subject (Math)" );
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "!@#$%^&*()_+`~-=;':{}|[];',.<>SAVE" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "TC016: Verify the newly saved report filter is getting displayed with the filter name  in the \"SAVED REPORT OPTIONS\" dropdown of CP Report input page" );
            Log.assertThat(  CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully","issue in saving the filter options" );
            Log.testCaseResult();

            CPReport.reportFilterComponent.clickResetButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );

            SMUtils.logDescriptionTC( "TC012: Verify if user clicks the save button with already existing name in 'Save Report Option' Popup for CP Report" );
            saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();

            SMUtils.logDescriptionTC( "TC009: Verify \"Select existing custom report configuration\" placeholder is getting displayed inside the existing Report filter dropdown in the Save Report Option popup modal for CP Report" );
            Log.assertThat( saveReportOptionPopup.ValidateExistingReportFilterPlaceholder( "Select existing custom report configuration" ), "Expected text is present Save Report options dialog box","Expected text is Not Present in Save Report options dialog box" );
            Log.message("Filter Name: " + filterName);
            saveReportOptionPopup.enterNameForSaveReport( filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name","Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            CPReport.reportFilterComponent.clickResetButton();
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 )) );

            SMUtils.logDescriptionTC( "TC021: Verify If User enter more than 50 characters in new custom report configuration text box of CP Report." );
            saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameForSaveReport( ReportsUIConstants.LENGTHY_NAME );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length","Error Message is not displayed properly for name exceed maximum length" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC019: Verify User can able to click the close button(X icon) in save report option of CP Report." );
            saveReportOptionPopup.clickCloseIcon();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat(  CPReport.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC013: Verify user can able to select the option in Existing custom report configuration dropdown for CP Report" );
            SMUtils.logDescriptionTC( "TC017: Verify the newly saved report filter is getting displayed with the filter name  in the \"Existing custom report configuration\" dropdown of Saved Report Option popup modal" );
            SMUtils.logDescriptionTC( "TC039: Verify User can able to save the report with new name after selecting the existing saved report filter from CP report input page" );
            saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown( filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            String newFilterName = "New"+System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(newFilterName);
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat( CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( newFilterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify User can able to save the report option with multiple options in all required and optional filters  with Subject (Math)", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        SMUtils.logDescriptionTC( "TC025: Verify User can able to save the report option with multiple options in all required and optional filters  with Subject (Math)" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( schoolAdminUserName, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgNameUnderSchool ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 1 ) ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT.get( 0 ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 0 ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Student Demographic Drop-downs
            CPReport.reportFilterComponent.expandStudentDemographics();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPR_All_Math" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat( CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading)", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcCPRSaveReportOptions004: Verify User can able to save the report option with multiple options in all required and optional filters  with Subject (Reading) " + browser + "]</b></i></small>" );
        try {
            Log.testCaseInfo( "verify after the previously selected values are being displayed after selecting the new save report option.(Reading)" );
            SMUtils.logDescriptionTC( "TC037: Verify the save Report filter by selcting 'All Dates' checkbox in 'STUDENT PERFORMANCE DATES' of CP Report" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            SMUtils.logDescriptionTC( "TC027: Verify User can able to save the report option with multiple options in all required and optional filters with Subject(Reading) " );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(  ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Student Demographic Drop-downs
            CPReport.reportFilterComponent.expandStudentDemographics();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPFilter_All" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat(  CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            Log.testCaseResult();

            CPReport.reportFilterComponent.clickResetButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName  );

            //Values selected while creating a filter - Placeholder
            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL,  Arrays.asList( ReportsUIConstants.ZERO_STATE_TEACHER ));
            beforeSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ZERO_STATE_GRADES ) );
            beforeSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS , Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )   );
            Log.message( "beforeSavedFilterValues--> " + beforeSavedFilterValues);

            //Getting the values from the saved filter
            List<String>  teacherGroupingValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) );
            List<String>  gradeGroupingValues = Arrays.asList(CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GRADE_LABEL));
            List<String>  disbailityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
            List<String>  englishValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
            List<String>  migrantValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
            List<String>  raceValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
            List<String>  ethnicityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
            List<String>  socioValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );
            List<String>  specialServicesValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );

            HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
            afterSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL, teacherGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, gradeGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS, disbailityValues );
            afterSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, englishValues );
            afterSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, migrantValues );
            afterSavedFilterValues.put( ReportsUIConstants.RACE, raceValues );
            afterSavedFilterValues.put( ReportsUIConstants.ETHNICITY, ethnicityValues );
            afterSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, socioValues );
            afterSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES, specialServicesValues );
            Log.message( "afterSavedFilterValues--> " + afterSavedFilterValues);

            Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                    "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify new teacher, group, assignments are not saved to the existing saved report filter", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> studUserDetails = new HashMap<>();
        HashMap<String, String> studentInfo = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> contentBase = new HashMap<>();
        HashMap<String, String> contentBaseName = new HashMap<>();
        List<String> courseIDs = new ArrayList<>();

        String groupName = "ChiefsTestGroup" + System.nanoTime();
        String teacherUserName = "chiefsteacher_user" + System.nanoTime();
        String studentUserName = "chiefsstudent_user" + System.nanoTime();

        Log.testCaseInfo( "tcCPRSaveReportOptions005: Verify new teacher, group, assignments are not saved to the existing saved report filter " + browser + "]</b></i></small>" );
        try {
            SMUtils.logDescriptionTC( "TC023: Verify that if the user chooses the existing report filter then those existing saved report options are getting retained in the Report input page" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            Log.message( "Login with User: " + username + "/" + password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Org, Subject, Courses - Drop-downs
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL, Arrays.asList( orgName )  );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL,  Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL  ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            SMUtils.logDescriptionTC( "TC032: Verify User can able to save the report option with 'Group' option in Additional Grouping and  'Exercises Attempted' in sort Dropdown with All options in student demographics dropdowns " );
            SMUtils.logDescriptionTC( "TC033: Verify User can able to save the report option with  'Student username' in Display Dropdown with Select multiple options in student demographics dropdowns" );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT.get( 3 ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            String beforeCourse = CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdownAdmin( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            String beforeTeacher = CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdownAdmin( ReportsUIConstants.TEACHER_LABEL );
            String beforeGroup = CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdownAdmin( ReportsUIConstants.GROUP_LABEL );

            Log.message( "Before_Courses-> " + beforeCourse );
            Log.message( "Before_Teacher-> " + beforeTeacher );
            Log.message( "Before_Group---> " + beforeGroup );

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPR_Filter_All_Options" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            SMUtils.waitForSpinnertoDisapper( driver );

            /*
             * Creating Teacher, Student, Group, Assignments and Validating with
             * Saved Report Options Filter
             */

            //Creating a Teacher user using user service
            SMUtils.logDescriptionTC( "TC034: Verify if newly created teacher is not get retained in Saved Report Filter  for the organization after saved  the filter option with any one teacher" );
            SMUtils.logDescriptionTC( "TC036: Verify if new Group created by the teacher after saved  the filter option with any one of the Group" );
            SMUtils.logDescriptionTC( "TC031: Verify if delete the Group, after saved the filters options with the groups" );
            SMUtils.logDescriptionTC( "TC035: Verify that the newly created assignment is not get retained in existing saved report filter which has Course values selected 'All'" );
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, teacherUserName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );

            String teacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
            new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, teacherID );
            Log.message( "Teacher_ID is: " + teacherID );
            Log.message( "Teacher_Username is: " + teacherUserName );
            Log.message( "Student_Username is: " + studentUserName );
            Log.message( "Teacher_Details: " + rbs.getUser( teacherID ) );
            Log.message( "Teacher_FullName: " + SMUtils.getKeyValueFromResponse( rbs.getUser( teacherID ), "firstAndLastName" ) );

            //Creating a student user using user service
            studUserDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
            studUserDetails.put( RBSDataSetupConstants.USERNAME, studentUserName );
            studUserDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            studUserDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
            String studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( studUserDetails ), RBSDataSetupConstants.USERID );
            studentRumbaIds.add( studentID );
            Log.message( "Created_studentID: " + studentID );

            //Updating Student Details
            studentInfo = generateRequestValues( new RBSUtils().getUser( studentID ), studentInfo, UserConstants.SCHOOLID, orgId );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherID );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                    new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
            new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, studentID );

            //Creating Math Assignment
            String token = new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            String readSettingCourseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() );
            contentBaseName.put( ReportAPIConstants.CPReport.READING_COURSE + ReportAPIConstants.CPReport.SETTINGS_COURSE, readSettingCourseName );
            contentBase.put( ReportAPIConstants.CPReport.READING_COURSE + ReportAPIConstants.CPReport.SETTINGS_COURSE,
                    coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherID.toString(), orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName.get( ReportAPIConstants.CPReport.READING_COURSE + ReportAPIConstants.CPReport.SETTINGS_COURSE ) ) );
            courseIDs.add( contentBase.get(  ReportAPIConstants.CPReport.READING_COURSE  + ReportAPIConstants.CPReport.SETTINGS_COURSE ) );
            Log.message( "courseIDs: " + courseIDs );

            //Creating a group with the above student
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            groupDetails.put( LSAdminReportDBQuery.GROUP_OWNER_ID, teacherID );
            groupDetails.put( LSAdminReportDBQuery.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( LSAdminReportDBQuery.GROUP_NAME, groupName );
            groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );
            Log.message( "Created groupId: " + groupId + " Created Group Name: " + groupName );

            assignmentDetails.put( LSAdminReportDBQuery.ORG_ID, orgId );
            assignmentDetails.put( LSAdminReportDBQuery.TEACHER_ID, teacherID );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

            //Assigning Assignment to the newly created student
            Log.message( "Assigning assignment..." );
            String assignmentResponseDetails =  new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs  ).get(Constants.REPORT_BODY);
            Log.message("assignmentAssignedresponseDetails: " +  assignmentResponseDetails);
            Log.message( "AssignmentName: " +  readSettingCourseName);

            /*
             * Completed new teacher, student, group, assignment setup
             */            

            CPReport.reportFilterComponent.clickResetButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName  );
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.nap( 10);
            CPReport.reportFilterComponent.expandOptionalFilter();

            List<String> selectedCourseValues = CPReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            List<String> selectedTeacherValues = CPReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.TEACHER_LABEL );
            List<String> selectedGroupValues = CPReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.GROUP_LABEL );

            int groupTotalSize = selectedGroupValues.size() ;

            Log.message( "Selected_Courses_Values-> " + selectedCourseValues );
            Log.message( "Selected_Teacher Values-> " + selectedTeacherValues );
            Log.message( "Selected_Group Values---> " + selectedGroupValues );
            Log.message( "TotalGroupSize: " + groupTotalSize );

            Log.assertThat( !selectedCourseValues.contains( readSettingCourseName ), "Newly created course is not selected into existing saved filter, Test Passed!", "Newly created course is selected into existing saved filter, Test Failed:(" );
            Log.assertThat( !selectedTeacherValues.contains( SMUtils.getKeyValueFromResponse( rbs.getUser( teacherID ), "firstAndLastName" ) ), "Newly created teacher is not selected into existing saved filter, Test Passed!", "Newly created teacher is selected into existing saved filter, Test Failed:(" );
            Log.assertThat( !selectedGroupValues.contains( groupName ), "Newly created group is not selected into existing saved filter, Test Passed!", "Newly created group is selected into existing saved filter, Test Failed:(" );

            //Deleting Group
            CPReport.reportFilterComponent.clickResetButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Org, Subject, Courses - Drop-downs
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            //            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  orgName );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL,  Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL  ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            filterName = "CPRDeleteGrpBefore" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            CPReport.reportFilterComponent.clickResetButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver , 20);
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName  );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Delete Group
            GroupAPI groupMethod = new GroupAPI();
            groupMethod.deleteGroup( groupId, teacherID, orgId, new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            Log.message( "Deleted groupId: " + groupId + "Deleted Group Name: " + groupName );
            SMUtils.nap( 5 );

            //Reset and select the above saved filter
            CPReport.reportFilterComponent.clickResetButton();
            driver.navigate().refresh();
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName  );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            CPReport.reportFilterComponent.expandOptionalFilter();
            List<String >selectedGroupValuesAfterDelete = CPReport.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdownAdmin( ReportsUIConstants.GROUP_LABEL );
            Log.message( "After group deletion: " + selectedGroupValuesAfterDelete );

            int finalGroupSize = selectedGroupValues.size();
            Log.message( "finalGroupSize: " + finalGroupSize );

            Log.assertThat( (groupTotalSize == finalGroupSize), "Selected All options doesn't reatin deleted group, Test Passed!!", "Selected All options reatins deleted group, Test Failed :(" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }



    @Test ( description = "Verify 'Save Report Option'  button in Selected Date Range", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcCPRSaveReportOptions006: Verify 'Save Report Option'  button in Cumulative Performance Report page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            SMUtils.logDescriptionTC( "TC028:  Verify the save Report filter by selcting 'Selected Date Range' checkbox with start date and End date in 'STUDENT PERFORMANCE DATES' of CP Report" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            Log.message( "Login in with Admin User: " + username );
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            Log.assertThat( CPReport.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS ), "The save report option is displayed in CP report","The save report option is not displayed in CP report" );
            Log.assertThat( !CPReport.reportFilterComponent.isSaveReportButtonEnabled(), "Save report option button is disabled as default", "Save report option button is not disabled as default" );

            //Organization, Subject and Course Drop downs
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( courses.get( 0 ) ) );

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            CPReport.clickSelectedDateRangeButton();
            SMUtils.waitForSpinnertoDisapper( driver , 20);
            CPReport.enterCurrentDateInStartCalendar();
            SMUtils.waitForSpinnertoDisapper( driver );
            CPReport.enterCurrentDateInToCalendar();

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPR_NEW_" + System.nanoTime();
            Log.message("Filter Name: " + filterName);
            saveReportOptionPopup.enterNameForSaveReport( filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat( CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }



    @Test ( description = "verify after the previously selected values are being displayed after selecting the new save report option.(Math)", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "verify after the previously selected values are being displayed after selecting the new save report option.(Math) " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(  ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT.get( 1 ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Student Demographic Drop-downs
            CPReport.reportFilterComponent.expandStudentDemographics();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPFilter_All" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat(  CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            Log.testCaseResult();

            CPReport.reportFilterComponent.clickResetButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, filterName  );

            //Values selected while creating a filter - Placeholder
            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL,  Arrays.asList( ReportsUIConstants.ZERO_STATE_TEACHER ));
            beforeSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ZERO_STATE_GRADES ) );
            beforeSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS , Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )   );
            Log.message( "beforeSavedFilterValues--> " + beforeSavedFilterValues);

            //Getting the values from the saved filter
            List<String>  teacherGroupingValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) );
            List<String>  gradeGroupingValues = Arrays.asList(CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GRADE_LABEL));
            List<String>  disbailityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
            List<String>  englishValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
            List<String>  migrantValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
            List<String>  raceValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
            List<String>  ethnicityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
            List<String>  socioValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );
            List<String>  specialServicesValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );

            HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
            afterSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL, teacherGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, gradeGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS, disbailityValues );
            afterSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, englishValues );
            afterSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, migrantValues );
            afterSavedFilterValues.put( ReportsUIConstants.RACE, raceValues );
            afterSavedFilterValues.put( ReportsUIConstants.ETHNICITY, ethnicityValues );
            afterSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, socioValues );
            afterSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES, specialServicesValues );
            Log.message( "afterSavedFilterValues--> " + afterSavedFilterValues);

            Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                    "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify the values are not changed after saving the report with values.(Math)", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the values are not changed after saving the report with values.(Math)" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(  ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT.get( 1 ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Student Demographic Drop-downs
            CPReport.reportFilterComponent.expandStudentDemographics();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPFilter_All" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat(  CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            Log.testCaseResult();

            //Values selected while creating a filter - Placeholder
            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL,  Arrays.asList( ReportsUIConstants.ZERO_STATE_TEACHER ));
            beforeSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ZERO_STATE_GRADES ) );
            beforeSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS , Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )   );
            Log.message( "beforeSavedFilterValues--> " + beforeSavedFilterValues);

            //Getting the values from the saved filter
            List<String>  teacherGroupingValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) );
            List<String>  gradeGroupingValues = Arrays.asList(CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GRADE_LABEL));
            List<String>  disbailityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
            List<String>  englishValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
            List<String>  migrantValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
            List<String>  raceValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
            List<String>  ethnicityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
            List<String>  socioValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );
            List<String>  specialServicesValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );

            HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
            afterSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL, teacherGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, gradeGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS, disbailityValues );
            afterSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, englishValues );
            afterSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, migrantValues );
            afterSavedFilterValues.put( ReportsUIConstants.RACE, raceValues );
            afterSavedFilterValues.put( ReportsUIConstants.ETHNICITY, ethnicityValues );
            afterSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, socioValues );
            afterSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES, specialServicesValues );
            Log.message( "afterSavedFilterValues--> " + afterSavedFilterValues);

            Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                    "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    @Test ( description = "Verify the values are not changed after saving the report with values.(Reading)", groups = { "Smoke", "SMK-66740", "SaveReportOption", "CPRSaveReportOption" }, priority = 1 )
    public void tcCPRSaveReportOptions009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the values are not changed after saving the report with values.(Math)" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( username, password );
            CumulativePerformancePage CPReport = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ORGANIZATIONS_LABEL,  Arrays.asList( orgName ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            courses = CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList(  ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Teacher, Grade, Group Drop-downs
            CPReport.reportFilterComponent.expandOptionalFilter();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Optional Filters -> Additional Grouping, Sort, Display Drop-downs
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ReportsUIConstants.SORT.get( 1 ) );
            CPReport.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            //Student Demographic Drop-downs
            CPReport.reportFilterComponent.expandStudentDemographics();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
            CPReport.reportFilterComponent.selectOptionsFromDemographicsDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
            SMUtils.waitForSpinnertoDisapper( driver , 10);

            SaveReportFilterPopup saveReportOptionPopup =  CPReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "CPFilter_All" + System.nanoTime();
            saveReportOptionPopup.enterNameForSaveReport(filterName );
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            saveReportOptionPopup.clickSaveButton();
            SMUtils.waitForSpinnertoDisapper( driver , 10);
            Log.assertThat(  CPReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Saved Report Filter is successfully displayed in Input Page!", "Saved Report Filter is not displayed in Input Page:(" );
            Log.testCaseResult();

            //Values selected while creating a filter - Placeholder
            HashMap<String, List<String>> beforeSavedFilterValues = new HashMap<>();
            beforeSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL,  Arrays.asList( ReportsUIConstants.ZERO_STATE_TEACHER ));
            beforeSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.ZERO_STATE_GRADES ) );
            beforeSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS , Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )  );
            beforeSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SELECTED_ALL_OPTION )   );
            Log.message( "beforeSavedFilterValues--> " + beforeSavedFilterValues);

            //Getting the values from the saved filter
            List<String>  teacherGroupingValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL ) );
            List<String>  gradeGroupingValues = Arrays.asList(CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown(ReportsUIConstants.GRADE_LABEL));
            List<String>  disbailityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
            List<String>  englishValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
            List<String>  migrantValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
            List<String>  raceValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
            List<String>  ethnicityValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
            List<String>  socioValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );
            List<String>  specialServicesValues = Arrays.asList( CPReport.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );

            HashMap<String, List<String>> afterSavedFilterValues = new HashMap<>();
            afterSavedFilterValues.put( ReportsUIConstants.TEACHER_LABEL, teacherGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.GRADE_LABEL, gradeGroupingValues );
            afterSavedFilterValues.put( ReportsUIConstants.DISABILITY_STATUS, disbailityValues );
            afterSavedFilterValues.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, englishValues );
            afterSavedFilterValues.put( ReportsUIConstants.MIGRANT_STATUS, migrantValues );
            afterSavedFilterValues.put( ReportsUIConstants.RACE, raceValues );
            afterSavedFilterValues.put( ReportsUIConstants.ETHNICITY, ethnicityValues );
            afterSavedFilterValues.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, socioValues );
            afterSavedFilterValues.put( ReportsUIConstants.SPECIAL_SERVICES, specialServicesValues );
            Log.message( "afterSavedFilterValues--> " + afterSavedFilterValues);

            Log.assertThat( afterSavedFilterValues.entrySet().stream().allMatch( entry -> beforeSavedFilterValues.entrySet().stream().anyMatch( responseData -> SMUtils.compareTwoList( responseData.getValue(), entry.getValue() ) ) ),
                    "Saved Report Options are Retained properly!!", "Saved Report Options are not Retained properly:(" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


    /**
     * Generating request values
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, "" );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        return generatedStudentDetails;
    }
}