package com.savvas.sm.reports.ui.tests.teacher.psr;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.Reports;
import com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.teacher.ui.pages.PrescriptiveSchedulingReport;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.teacher.SaveReportFilterPopup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

public class PSRTeacherMFETest extends EnvProperties {

    private String smUrl;
    private String browser;
    String teacherDetails;
    private String schoolName = null;
    private static String teacherUsername = null;
    private static String passwordTeacher = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherId;
    private String orgId;
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static List<String> studentUserName = new ArrayList<>();

    @BeforeClass( alwaysRun = true )
    public void init( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( schoolName );
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        
        HashMap<String, String> courseIds = new HashMap<>();
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        String studentDetail = RBSDataSetup.getMyStudent( schoolName, teacherUsername );
        String studentUserName = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        String studentId = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID );
        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolName ) );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID,  SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ));
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, new ArrayList<>( Arrays.asList(studentId ) ), new ArrayList<>( courseIds.values() ) );
        Log.message( "Assignment Response :"+ assignmentResponse );
        executeCourse( studentUserName, Constants.MATH, true, "100", "6", "40" );
        executeCourse( studentUserName, Constants.READING, false, "100", "4", "35" );
        
    }
    
    @Test ( description = "Prescriptive Scheduling Report Field Validations", groups = { "SMK-66762", "reports", "prescriptive_scheduling_report" }, priority = 1 )
    public void tc001PrescriptiveSchedulingReportFieldValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Prescriptive Scheduling Report Field Validations" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
           AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
           PrescriptiveSchedulingReport psr = (PrescriptiveSchedulingReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.PRESCRIPTIVE_SCHEDULING );
           psr.validateAllFieldsInPrescriptiveSchedulingReport( driver );
           Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Prescriptive Scheduling - 'Saved Report' Value Is Retaining ", groups = { "SMK-66762", "reports", "prescriptive_scheduling_report" }, priority = 1 )
    public void tc002PSRSavedReportsValidation() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Prescriptive Scheduling - 'Saved Report' Value Is Retaining " + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            PrescriptiveSchedulingReport perspectiveSchedulingReport = (PrescriptiveSchedulingReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.PRESCRIPTIVE_SCHEDULING );
            SMUtils.logDescriptionTC("Verify 'Save Report Option'  button in PS report page");

            Log.assertThat(perspectiveSchedulingReport.reportFilterComponent.getLabelFromSaveReportOptionButton().equalsIgnoreCase(ReportsUIConstants.SAVE_REPORT_OPTIONS),"The save report option is displayed in PS report",  "The save report option is not displayed in CPA report");
            Log.assertThat(!perspectiveSchedulingReport.reportFilterComponent.isSaveReportButtonEnabled(),"Save report option button is disabled as default","Save report option button is not disabled as default");
            Log.testCaseResult();

            perspectiveSchedulingReport.selectTargetDateAsCurrentDate();

            SMUtils.logDescriptionTC("Verify user can click the 'Save Report Option' button in CPR aggregate report page");
            SMUtils.logDescriptionTC("Verify all available fields in 'Save Report Option Popup.");
            perspectiveSchedulingReport.reportFilterComponent.clickSaveReportOptionButton();
            SaveReportFilterPopup saveReportOptionPopup = new SaveReportFilterPopup(driver);
            Log.assertThat(saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase(ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL),"New Report configuration label is displayed properly","New Report configuration label is not displayed properly! Expected - "+ ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - "+ saveReportOptionPopup.getLabelForNewCustomReportConfiguration());
            Log.assertThat(saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase(ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL),"New Report configuration label is displayed properly","New Report configuration label is not displayed properly! Expected - "+ ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - "+ saveReportOptionPopup.getLabelForExistingReportConfiguration());
            Log.assertThat(saveReportOptionPopup.isSaveButtonDisplayed(),"Save Button is displayed in saved report popup","Save Button is not displayed in saved report popup");
            Log.assertThat(saveReportOptionPopup.isCancelButtonDisplayed(),"Cancel Button is displayed in saved report popup","Cancel Button is not displayed in saved report popup");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Verify if click the save button with empty Name in 'Save Report Option' Popup.");
            Log.assertThat(!saveReportOptionPopup.isSaveButtonEnabled(),"Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Verify user can able to cancel the in 'Save Report Option ' Popup on PS report page.");
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat(perspectiveSchedulingReport.reportFilterComponent.isReportTitleDisplayed(),"The Save Report poup closed properly", "issue in closing the popup");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Verify User can able to save the report option with new name.");
            SMUtils.logDescriptionTC("Verify User can able to save the report option with default Optional filters.");
            perspectiveSchedulingReport.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(filterName);
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat(perspectiveSchedulingReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),"Report filter options saved successfully", "issue in saving the filter options");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Verify If User enter more than 50 characters in new custom report configuration text box.");
            perspectiveSchedulingReport.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterTextInNewReportFilterConfigurationTextBox(ReportsUIConstants.LENGTHY_NAME);
            Log.assertThat(saveReportOptionPopup.getErrorMessage().equalsIgnoreCase(ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE),"Error Message displayed properly for name exceed maximum length","Error Message is not displayed properly for name exceed maximum length");

            SMUtils.logDescriptionTC("Verify User can able to click the close button in save report option");
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat(perspectiveSchedulingReport.reportFilterComponent.isReportTitleDisplayed(),"The Save Report poup closed properly", "issue in closing the popup");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Verify if click the save button with already existing name in 'Save Report Option' Popup.");
            perspectiveSchedulingReport.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.selectOptionInExistingSavedOptiondropdown(filterName);
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat(perspectiveSchedulingReport.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown(ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL).contains(filterName),"Report filter options saved successfully", "issue in saving the filter options");
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "PSR run Report Validation", groups = { "SMK-66762", "reports", "prescriptive_scheduling_report"}, priority = 1 )
    public void tc003PSRRunReportValidationForTeacher() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "PSR run Report Validation" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            PrescriptiveSchedulingReport prescriptiveSchedulingReport = (PrescriptiveSchedulingReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.PRESCRIPTIVE_SCHEDULING );
            ReportsViewerPage reportsViewerPage = prescriptiveSchedulingReport.validatePSRTeacherRunReport(driver);
            reportsViewerPage.verifyReportPage( driver );
            reportsViewerPage.validateReportOutputColumns( driver );
            Log.testCaseResult();
        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify Prescriptive Scheduling  Report Output screen with BFF data - Math", groups = { "SMK-66762","prescriptive_scheduling_report" }, priority = 1 )
    public void tc004PSRReportsValidation( ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            PrescriptiveSchedulingReport prescriptiveSchedulingReport = (PrescriptiveSchedulingReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.PRESCRIPTIVE_SCHEDULING );
            prescriptiveSchedulingReport.reportFilterComponent.selectSubject( "Math" );
            prescriptiveSchedulingReport.verifyGroup( driver );
            prescriptiveSchedulingReport.verifyAssignments( driver, teacherUsername, smUrl, teacherDetails, "mathassignments" );
            prescriptiveSchedulingReport.selectTargetDateAsCurrentDate();
            prescriptiveSchedulingReport.reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            prescriptiveSchedulingReport.reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            
            HashMap<String, HashMap<String, String>> uiValues = prescriptiveSchedulingReport.getValuesFromUI( driver );

            // Setting date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
            LocalDate date = LocalDate.now();
            String targetDate = formatter.format( date );
            HashMap<String, HashMap<String, String>> apiResponse =  prescriptiveSchedulingReport.getDataFromBFF( teacherUsername, passwordTeacher, orgId, teacherId, "math" );
            boolean validation = apiResponse.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), uiValues.get( entry.getKey() ) ) );
            Log.softAssertThat( validation, "MFE BFF data verification Successful", "MFE BFF data verification Failed" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( description = "Verify Prescriptive Scheduling  Report Output screen with BFF data - Reading", groups = { "SMK-66762", "prescriptive_scheduling_report" }, priority = 1 )
    public void tc005PSRReportsValidation( ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreasForGrowthReport areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( teacherUsername, passwordTeacher );
            PrescriptiveSchedulingReport prescriptiveSchedulingReport = (PrescriptiveSchedulingReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.PRESCRIPTIVE_SCHEDULING );

            prescriptiveSchedulingReport.verifyGroup( driver );
            prescriptiveSchedulingReport.reportFilterComponent.selectSubject( "Reading" );
            prescriptiveSchedulingReport.verifyAssignments( driver, teacherUsername, smUrl, teacherDetails, "readingassignments" );
            prescriptiveSchedulingReport.selectTargetDateAsCurrentDate();
            prescriptiveSchedulingReport.reportFilterComponent.clickRunReportButton();

            SMUtils.nap( 3 );

            SMUtils.switchWindow( driver );
            prescriptiveSchedulingReport.reportFilterComponent.waitForSpinnerToLoadAndDisppear();
            
            HashMap<String, HashMap<String, String>> uiValues = prescriptiveSchedulingReport.getValuesFromUI( driver );

            // Setting date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
            LocalDate date = LocalDate.now();
            String targetDate = formatter.format( date );
            HashMap<String, HashMap<String, String>> apiResponse =  prescriptiveSchedulingReport.getDataFromBFF( teacherUsername, passwordTeacher, orgId, teacherId, "reading" );
            boolean validation = apiResponse.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), uiValues.get( entry.getKey() ) ) );
            Log.softAssertThat( validation, "MFE BFF data verification Successful", "MFE BFF data verification Failed" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public  void executeCourse( String studentUserName, String courseName, boolean isMath, String percent, String session, String LO ) throws IOException {
        EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
        String smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        String browser = configProperty.getProperty( "BrowserPlatformToRun" );
        WebDriver chromeDriver = null;
        StudentDashboardPage studentsPage = null;
        boolean flagIsExecutionSuccessfull = false;
        try {
            for ( int i = 0; i < 3; i++ ) {
                try {
                    // Get driver
                    chromeDriver = WebDriverFactory.get( browser );
                    LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                    studentsPage = new StudentDashboardPage( chromeDriver );
                    Log.message( "Student username " + studentUserName );
                } catch ( Exception e ) {
                    Log.message( "Issue occurrred at driver creation and Login , reattempting : " + i );
                    continue;
                }
                if ( isMath ) {
                    try {
                        studentsPage.executeMathCourse( studentUserName, courseName, percent, session, LO );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!",chromeDriver );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                } else {
                    try {
                        studentsPage.executeReadingCourse( studentUserName, courseName, percent, session, LO );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" ,chromeDriver);
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                }
            }
        } finally {
            if ( flagIsExecutionSuccessfull ) {
                Log.message( "Course executed successfully" );
            } else {
                Log.message( "Course execution failed after reattempting : 3" );
            }
            chromeDriver.quit();

        }

    }
}
