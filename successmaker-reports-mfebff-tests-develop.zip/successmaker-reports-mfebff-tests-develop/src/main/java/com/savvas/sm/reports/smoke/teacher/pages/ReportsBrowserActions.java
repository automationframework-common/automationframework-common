package com.savvas.sm.reports.smoke.teacher.pages;

import java.time.Duration;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;

public class ReportsBrowserActions {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public static boolean waitForElement( WebDriver driver, WebElement element, int... maxWaitArray ) {
        int maxWait = maxWaitArray.length > 0 ? maxWaitArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        boolean statusOfElementToBeReturned = false;
        long startTime = StopWatch.startTime();
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( maxWait ) );
        try {
            wait.until( ExpectedConditions.visibilityOf( element ) );
            statusOfElementToBeReturned = true;
        } catch ( TimeoutException e ) {
            Log.event( "Unable to find a element after " + StopWatch.elapsedTime( startTime ) + " sec" );
        }
        return statusOfElementToBeReturned;
    }

    public static void verifyElementIsDisplayed( WebDriver driver, WebElement webElement, String elementDescription, int... timeOutArray ) {
        int timeout = timeOutArray.length > 0 ? timeOutArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        try {
            if ( !waitForElement( driver, webElement, timeout ) )
                throw new NoSuchElementException( elementDescription + " not found in page!!" );
            Log.assertThat( webElement.isDisplayed(), elementDescription + " is displayed", elementDescription + " is not displayed", driver );
        } catch ( NoSuchElementException e ) {
            Log.fail( elementDescription + " is not displayed" + e, driver );
        }
    }

    public static void verifyElementTextIsDisplayed( WebDriver driver, WebElement webElement, String expectedText, String elementDescription, int... timeOutArray ) {
        int timeout = timeOutArray.length > 0 ? timeOutArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        try {
            if ( !waitForElement( driver, webElement, timeout ) )
                throw new NoSuchElementException( elementDescription + " not found in page!!" );
            String actualText = webElement.getText();
            Log.assertThat( actualText.trim().equals( expectedText.trim() ), elementDescription + " inner text \"" + actualText + "\" is matching",
                    elementDescription + " inner text is not matching. Actual text: " + actualText + " Expected: " + expectedText, driver );
        } catch ( NoSuchElementException e ) {
            Log.fail( elementDescription + " is not displayed" + e, driver );
        }
    }

    public static void waitForSpinnerToBeVisible( WebDriver driver, int... timeOutArray ) {
        int timeout = timeOutArray.length > 0 ? timeOutArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( timeout ) );
            wait.until( ExpectedConditions.visibilityOfElementLocated( By.xpath( "//cel-icon[@aria-label='spinner']" ) ) );
            Log.message( "Page loading spinner is visible" );
        } catch ( TimeoutException e ) {
            Log.message( "Page loading spinner is not visible" + e, driver );
        }
    }

    public static void waitForSpinnerToBeInvisible( WebDriver driver, int... timeOutArray ) {
        int timeout = timeOutArray.length > 0 ? timeOutArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( timeout ) );
            wait.until( ExpectedConditions.invisibilityOfElementLocated( By.xpath( "//cel-icon[@aria-label='spinner']" ) ) );
            Log.message( "Page loading spinner is invisible" );
        } catch ( TimeoutException e ) {
            Log.message( "Page loading spinner is still visible" + e, driver );
        }
    }

    /**
     * To wait for the specific element on the page
     *
     * @param driver - WebDriver
     * @param element - WebElement to wait for
     * @param maxWait - Max wait duration
     * @return statusOfElementToBeReturned - return true if element is present
     *         else return false
     */
    public static boolean waitForElementByIgnoringNoSuchElement( WebDriver driver, WebElement element, int... maxWaitArray ) {
        int maxWait = maxWaitArray.length > 0 ? maxWaitArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        boolean statusOfElementToBeReturned = false;
        long startTime = StopWatch.startTime();
        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>( driver ).withTimeout( Duration.ofSeconds( maxWait ) ).pollingEvery( Duration.ofSeconds( 500 ) ).ignoring( NoSuchElementException.class );
            wait.until( new Function<WebDriver, Boolean>() {
                public Boolean apply( WebDriver driver ) {
                    return element.isDisplayed();
                }
            } );
            statusOfElementToBeReturned = true;
        } catch ( TimeoutException e ) {
            Log.event( "Unable to find a element after " + StopWatch.elapsedTime( startTime ) + " sec" );
        }
        return statusOfElementToBeReturned;
    }

    /**
     * Click on element
     * 
     * @param driver
     * @param btn
     * @param elementDescription
     * @param timeOutArray
     */
    public static void click( WebDriver driver, WebElement btn, String elementDescription, int... timeOutArray ) {
        int timeout = timeOutArray.length > 0 ? timeOutArray[0] : Integer.parseInt( configProperty.getProperty( "maxElementWait" ) );
        if ( !waitForElementByIgnoringNoSuchElement( driver, btn, timeout ) )
            throw new NoSuchElementException( elementDescription + " not found in page!!" );
        try {
            btn.click();
            Log.message( "Clicked on " + elementDescription, driver );
        } catch ( NoSuchElementException e ) {
            Log.fail( "Failed to click on " + elementDescription + " " + e, driver );
        } catch ( ElementClickInterceptedException e2 ) {
            ( (JavascriptExecutor) driver ).executeScript( "arguments[0].click();", btn );
            Log.message( "Clicked on using JS " + elementDescription, driver );
        }
    }

}
