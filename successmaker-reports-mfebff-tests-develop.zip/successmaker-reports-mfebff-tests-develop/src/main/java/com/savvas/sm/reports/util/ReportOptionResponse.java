package com.savvas.sm.reports.util;

public class ReportOptionResponse {
    String requestId;
    String reportType;
    String personId;
    String organizationId;
    String filterName;
    String reportParameters;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId( String requestId ) {
        this.requestId = requestId;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType( String reportType ) {
        this.reportType = reportType;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId( String personId ) {
        this.personId = personId;
    }

    public String getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId( String organizationId ) {
        this.organizationId = organizationId;
    }

    public String getFilterName() {
        return filterName;
    }

    public void setFilterName( String filterName ) {
        this.filterName = filterName;
    }

    public String getReportParameters() {
        return reportParameters;
    }

    public void setReportParameters( String reportParameters ) {
        this.reportParameters = reportParameters;
    }
}