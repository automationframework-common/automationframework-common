package com.savvas.sm.reports.exportcsv.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.admin.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.admin.ui.pages.LastSessionReportPage;
import com.savvas.sm.reports.admin.ui.pages.LastSessionReportViewerPage;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.LSRExportCsv;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;

import io.restassured.response.Response;

public class AdminLastSessionReportExportCsvTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtAdminUsername;
    private String districtAdminUserId;
    private String districtId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String schoolName;
    private String orgId;
    Map<String, String> headers = new HashMap<>();
    private List<String> teacherUsernames;
    private Map<String, String> teacherUserIds = new HashMap<>();
    List<String> gradeIds = new ArrayList<>();
    private Map<String, String> teacherNames = new HashMap<>();
    Map<String, String> groupDetail = new HashMap<>();
    String[] studentGrades;

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        //To fetch the admin details from Report data
        try {
            districtAdminUsername = ReportDataCollection.districtAdmin;
            districtAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
            districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        } catch ( Exception e ) {
            Log.failsoft( "Getting issue while fetch the admin details from Report data" );
        }
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = ReportDataCollection.orgId;

        //To get teacher Details
        teacherUsernames = new ArrayList<>( ReportDataCollection.teacherDetails.keySet() );
        teacherUsernames.stream().forEach( userName -> teacherUserIds.put( userName, SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), Constants.USERID ) ) );
        teacherUsernames.stream().forEach( userName -> teacherNames.put( userName,
                SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), "firstName" ) + " " + SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), "lastName" ) ) );

        //To get group Detail
        IntStream.range( 0, 2 ).forEach( itr -> groupDetail.put( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( itr ).toString(), "groupId" ),
                SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( itr ).toString(), "groupName" ) ) );

        //To get gradeIds
        studentGrades = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( 0 ).toString(), "studentGradeIds" ).replace( "[", "" ).replace( "]", "" ).split( "," );
        for ( String grade : studentGrades ) {
            if ( grade.length() > 1 ) {
                gradeIds.add( grade );
            } else if ( grade.equals( "k" ) ) {
                gradeIds.add( "KG" );
            } else {
                gradeIds.add( "0" + grade );
            }

        }
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, districtAdminUserId );
        headers.put( Constants.ORGID_SM_HEADER, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify Export Report Export Report CSV link appears on top right corner of the report ouput screen" )
    public void tcAdminLSRExportCsv001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv001 - (Admin LSR)Verify Export Report Export Report CSV link appears on top right corner of the report ouput screen" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            SMUtils.logDescriptionTC( "tc001 - (Admin LSR)Verify Export Report Export Report CSV link appears on top right corner of the report ouput screen" );
            Log.assertThat( lastSessionOutpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();

            SMUtils.logDescriptionTC( "tc002 - (Admin LSR)Verify Export Report CSV popup appears after user click on Export Report CSV link" );
            //Verifying the Export Report CSV popup header
            Log.assertThat( exportPopup.getExportReportCsvPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORT_DATA_HEADER ), "Export Report CSV popup loaded properly after clicked the ecport CSV button",
                    "Export Report CSV popup not loaded properly after clicked the ecport CSV button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc003 - (Admin LSR)Verify the fields available in the Export Report CSV popup" );
            Log.assertThat( exportPopup.getExportTypeLabels().containsAll( Arrays.asList( ReportsUIConstants.EXPORT_DEFAULT, ReportsUIConstants.CUSTOMIZE_EXPORT ) ), "Both Default and custom export labels are present in Export Report CSV popup",
                    " Default and custom export labels are not displaying in Export Report CSV popup. Expected - " + Arrays.asList( ReportsUIConstants.EXPORT_DEFAULT, ReportsUIConstants.CUSTOMIZE_EXPORT ) + ". Actual -"
                            + exportPopup.getExportTypeLabels() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc004 - (Admin LSR)Verify the option selected by default in Export Report CSV popup" );
            Log.assertThat( exportPopup.isDefaultExportRadioButtonSelected(), "Default export radio button is selected by default", "Default export radio button is not selected by default" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc005 - (Admin LSR)Verify clicking on Cancel button button will close the Export Report CSV popup" );
            exportPopup.clickCancelButtonInExportReportCSVPopup();
            Log.assertThat( !exportPopup.isCloseButtonDisplayedInExportReportCSVPopup(), "The Export Report CSV popup closed after clicked the cancel button", "The Export Report CSV popup not closed after clicked the cancel button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc006 - (Admin LSR)Verify clicking on on OK button in Export Report CSV popup will download the current report data" );
            exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();
            Log.assertThat( ExportCsvUtils.isCsvFileDownloaded( driver ), "CSV file downloaded properly after clicked the ok Button", "CSV file not downloaded properly after clicked the ok Button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc007 - (Admin LSR)Verify the file name of the downloaded csv for Reading subject" );
            Log.assertThat( ExportCsvUtils.getCsvFileNameFromBS( driver ).contains( "Last Session" ), "The exported csv file has proper file name.", "The exported csv has not contain Last Session name." );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify Export Report Export Report CSV link appears when zero state report is generated" )
    public void tcAdminLSRExportCsv002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv002 - (Admin LSR)Verify Export Report Export Report CSV link appears when zero state report is generated" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To select the Grade
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( "Not Specified" ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc008 - (Admin LSR)Verify Export Report Export Report CSV link appears when zero state report is generated" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Log.assertThat( exportedCSVFromUI.isEmpty(), "CSV downloaded properly for zeros tate", "CSV is not downloaded properly for zero state" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the columns available in exported csv for math assignments" )
    public void tcAdminLSRExportCsv003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv003 - (Admin LSR)Verify the columns available in exported csv for math assignments" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To select the Teachers
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            String requestId = driver.getCurrentUrl().split( "=" )[1];

            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), new HashMap<>(), 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );

            SMUtils.logDescriptionTC( "tc009 - (Admin LSR)Verify the columns available in exported csv for math assignments" );
            Log.assertThat( columnsFromResponse.containsAll( LSRExportCsv.DEFAULT_MATH_HEADERS ), "All colum headers are fetched properly for Math Assignment",
                    "All colum headers are not fetched properly for Math Assignment. Expected -" + LSRExportCsv.DEFAULT_MATH_HEADERS + ".Actual - " + columnsFromResponse );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc010 - (Admin LSR)Verify the column values are matching with report data for math assignment" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File for math assignments",
                    "Student's report details are not fetching properly for math assignments in downloaded csv File. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the columns available in exported csv for reading assignments" )
    public void tcAdminLSRExportCsv004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv004 - (Admin LSR)Verify the columns available in exported csv for reading assignments" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To select the Teachers
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, false, assignmentIds, false, false, new ArrayList<>(), new HashMap<>(), 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );

            SMUtils.logDescriptionTC( "tc011 - (Admin LSR)Verify the column values are matching with report data for reading assignment" );
            Log.assertThat( columnsFromResponse.containsAll( LSRExportCsv.DEFAULT_READING_HEADERS ), "All colum headers are fetched properly for Reading Assignment",
                    "All colum headers are not fetched properly for Reading Assignment. Expected -" + LSRExportCsv.DEFAULT_MATH_HEADERS + ".Actual - " + columnsFromResponse );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc012 - (Admin LSR)Verify the column values are matching with report data for reading assignment" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File for reading assignments",
                    "Student's report details are not fetching properly for reading assignments in downloaded csv File. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv005 - (Admin LSR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To select the Teachers
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ) ) );
            //To select the Groups
            String groupId = groupDetail.keySet().toArray()[0].toString();
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groupDetail.get( groupId ) ) );
            //To select the Grade
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.GRADE_LABEL + " " + ( studentGrades[0].equals( "13" ) ? studentGrades[1] : studentGrades[0] ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            filterValues.put( ExportCsvConstants.FILTER_BY_TEACHER, Arrays.asList( teacherUserIds.get( teacherUsernames.get( 0 ) ) ) );
            filterValues.put( ExportCsvConstants.FILTER_BY_GRADE, Arrays.asList( gradeIds.get( 0 ).equals( "13" ) ? gradeIds.get( 1 ) : gradeIds.get( 0 ) ) );
            filterValues.put( ExportCsvConstants.FILTER_BY_GROUP, Arrays.asList( groupId ) );

            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc013 - (Admin LSR)Verify the exported csv when user selected single teacher, grade and group in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while select single options in teacher,Grade and Groups filter",
                    "Student's report details are not fetching properly while select single options in teacher,Grade and Groups filter. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected multiple teacher, grade and group in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv006 - (Admin LSR)Verify the exported csv when user selected multiple teacher, grade and group in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To select the Teachers
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );
            //To select the Groups
            Object[] groupId = groupDetail.keySet().toArray();
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( groupDetail.get( groupId[0].toString() ), groupDetail.get( groupId[1].toString() ) ) );
            //To select the Grade
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.GRADE_LABEL + " " + ( studentGrades[0].equals( "13" ) ? studentGrades[1] : studentGrades[0] ),
                    ReportsUIConstants.GRADE_LABEL + " " + ( studentGrades[1].equals( "13" ) ? studentGrades[2] : studentGrades[1] ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            filterValues.put( ExportCsvConstants.FILTER_BY_TEACHER, Arrays.asList( teacherUserIds.get( teacherUsernames.get( 0 ) ), teacherUserIds.get( teacherUsernames.get( 1 ) ) ) );
            filterValues.put( ExportCsvConstants.FILTER_BY_GRADE, Arrays.asList( gradeIds.get( 0 ).equals( "13" ) ? gradeIds.get( 1 ) : gradeIds.get( 0 ), gradeIds.get( 1 ).equals( "13" ) ? gradeIds.get( 2 ) : gradeIds.get( 1 ) ) );
            filterValues.put( ExportCsvConstants.FILTER_BY_GROUP, Arrays.asList( groupId[0].toString(), groupId[1].toString() ) );

            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc014 - (Admin LSR)Verify the exported csv when user selected multiple teacher, grade and group in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while select multiple options in teacher,Grade and Groups filter",
                    "Student's report details are not fetching properly while select multiple options in teacher,Grade and Groups filter. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected all teacher, grade and group in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv007() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv007 - (Admin LSR)Verify the exported csv when user selected all teacher, grade and group in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //To select the Groups
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            //To select the Grade
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc015 - (Admin LSR)Verify the exported csv when user selected all teacher, grade and group in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while select all options in teacher,Grade and Groups filter",
                    "Student's report details are not fetching properly while select all options in teacher,Grade and Groups filter. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected additional grouping option as \"Teacher\" in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv008() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv008 - (Admin LSR)Verify the exported csv when user selected additional grouping option as \"Teacher\" in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //To select the teacher option in Additional Grouping
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.TEACHER_LABEL );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 1, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc016 -(Admin LSR)Verify the exported csv when user selected additional grouping option as \"Teacher\" in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while run the report with additional grouping as teacher",
                    "Student's report details are not fetching properly while while run the report with additional grouping as teacher. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected additional grouping option as \"Group\" in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv009() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv009 - (Admin LSR)Verify the exported csv when user selected additional grouping option as \"Group\" in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //To select the teacher option in Additional Grouping
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 3, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc017 -(Admin LSR)Verify the exported csv when user selected additional grouping option as \\\"Group\\\" in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while run the report with additional grouping as group",
                    "Student's report details are not fetching properly while run the report with additional grouping as group. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected additional grouping option as \"Grade\" in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv010() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv010 - (Admin LSR)Verify the exported csv when user selected additional grouping option as \"Grade\" in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //To select the teacher option in Additional Grouping
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 2, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student Username\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc018 -(Admin LSR)Verify the exported csv when user selected additional grouping option as \"Grade\" in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while run the report with additional grouping as grade",
                    "Student's report details are not fetching properly while run the report with additional grouping as grade. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the exported csv when user selected display option in optional filter is used for fetching report" )
    public void tcAdminLSRExportCsv011() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv011 - (Admin LSR)Verify the exported csv when user selected display option in optional filter is used for fetching report" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );
            //To select the student username option in display dropdown
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.STUDENTUSERNAME );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            //To get the report details from API
            Map<String, List<String>> filterValues = new HashMap<>();
            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, new ArrayList<>(), filterValues, 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );
            exportedCSVFromAPI.forEach( exportCSVFromAPI -> {
                exportCSVFromAPI.remove( "\"Report Run\"" );
                exportCSVFromAPI.remove( "\"Student ID\"" );
                exportCSVFromAPI.remove( "\"Student\"" );
            } );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc019 -(Admin LSR)Verify the exported csv when user selected display option in optional filter is used for fetching report" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            exportedCSVFromUI.forEach( exportCSVFromUI -> {
                exportCSVFromUI.remove( "\"Report Run\"" );
            } );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's report details are present in downloaded csv File while select the student username in Display option",
                    "Student's report details are not fetching properly while select the student username in Display option. Expected -" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the fields available in the available columns for reading assignment  for custom export" )
    public void tcAdminLSRExportCsv012() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv012 - (Admin LSR)Verify the fields available in the available columns for reading assignment - Custom Export" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();

            exportPopup.clickCustomizeExportRadioButton();

            SMUtils.logDescriptionTC( "tc020 -(Admin LSR)Verify the fields available in the available columns for reading assignment for custom export" );
            List<String> availableColumnsFromUI = exportPopup.getAllAvailableColumns();
            Log.message( availableColumnsFromUI.toString() );
            Log.assertThat( availableColumnsFromUI.containsAll( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS ), "All the custom fields are available for reading",
                    "custom fields are not displaying properly for reading.Expected - " + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS + ".Actual -" + availableColumnsFromUI );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc021 -(Admin LSR)Verify the two colums (chevron- double) button is enable or disable by default" );
            Log.assertThat( exportPopup.isChevronDoubleRightButtonEnabled(), "Chevron double - right arrow is enabled by default", "Chevron double - right arrow is disabled by default" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc022 -(Admin LSR)Verify the user can select the values in available column" );
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            Log.assertThat( exportPopup.getCheckedAvailableColumns().containsAll( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) ),
                    "User able to select the options in available columns", "Getting issue while select the available columns!!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc023 -(Admin LSR)Verify the user can transfer the available columns values to selected columns by clicking the Chevorons-right button" );
            exportPopup.clickChevronDoubleRightButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().containsAll( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS ), "Selected fields are transffered to selected columns from available columns",
                    "Selected fields are not transffered to selected columns from available columns!!! Expected -" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS + ".Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            exportPopup.clickChevronDoubleLeftButton();
            SMUtils.logDescriptionTC( "tc024 -(Admin LSR)Verify the user can transfer selected single values from available columns to selected columns by clicking the Chevoron-right button" );
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ) );
            exportPopup.clickChevronRightButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 0 ).equals( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ) || exportPopup.getAllSelectedColumns().size() == 1,
                    "Selected field is transffered to selected columns from available columns",
                    "Selected fields is not transffered to selected columns from available columns!!! Expected -" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) + ".Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            exportPopup.clickChevronDoubleLeftButton();
            SMUtils.logDescriptionTC( "tc025 -(Admin LSR)Verify the user can transfer selected multiple values from available columns to selected columns by clicking the Chevoron-right button" );
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronRightButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().containsAll( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) ),
                    "Selected field is  transffered to selected columns from available columns", "Selected fields is not transffered to selected columns from available columns!!! Expected -" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) + ","
                            + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) + ".Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            exportPopup.clickChevronDoubleLeftButton();
            SMUtils.logDescriptionTC( "tc026 -(Admin LSR)Verify the user can transfer selected all values from available columns to selected columns by clicking the Chevoron-right button" );
            exportPopup.selectAvailableColumns( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS );
            exportPopup.clickChevronRightButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().containsAll( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS ), "Selected field is  transffered to selected columns from available columns",
                    "Selected fields is not transffered to selected columns from available columns!!! Expected -" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS + ".Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc027 -(Admin LSR)Verify the user can transfer the selected columns values to available columns by clicking the Chevorons-left button" );
            exportPopup.clickChevronDoubleLeftButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().isEmpty(), "Selected field is transffered to availble columns from selected columns",
                    "Selected fields is not transffered to available columns from selected columns!!! Expected -" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS + ".Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc028 -(Admin LSR)Verify the user can transfer selected single values from selected columns values to available columns by clicking the Chevoron-left button" );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.selectSelectedColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ) );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( !exportPopup.getAllSelectedColumns().contains( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ), "Single Selected field is transffered to availble columns from selected columns",
                    "Single Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc029 -(Admin LSR)Verify the user can transfer selected multiple values from selected columns values to available columns by clicking the Chevoron-left button" );
            exportPopup.selectSelectedColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( !exportPopup.getAllSelectedColumns().containsAll( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) ),
                    "Multiple Selected field is transffered to availble columns from selected columns", "Multiple Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc030 -(Admin LSR)Verify the user can transfer selected all values from selected columns values to available columns by clicking the Chevoron-left button" );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.selectSelectedColumns( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().isEmpty(), "All Selected field is transffered to available columns from selected columns",
                    "All Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc031 -(Admin LSR)Verify the user can move the selected values upwords by clicking Cheron-up in Selected columns" );
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 0 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.selectSelectedColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronUpButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 0 ).equals( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ), "user able to move the selected fields upwards by clicking chevron up button",
                    "user unable to move the selected fields upwards by clicking chevron up button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc032 -(Admin LSR)Verify the user can move the selected values downwords by clicking Chevron-down in Selected columns" );
            exportPopup.clickChevronDownButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 1 ).equals( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ), "user able to move the selected fields upwards by clicking chevron down button",
                    "user unable to move the selected fields upwards by clicking chevron down button" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the Selected columns available in exported csv for math assignments" )
    public void tcAdminLSRExportCsv013() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv013 - (Admin LSR)Verify the Selected columns available in exported csv for math assignments" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, true, false,
                    Arrays.asList( LSRExportCsv.MATH_CUSTOM_SELECTED_FILTERS.get( 1 ), LSRExportCsv.MATH_CUSTOM_SELECTED_FILTERS.get( 2 ) ), new HashMap<>(), 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();

            //To select custom export radio button
            exportPopup.clickCustomizeExportRadioButton();
            //To select the custom selcted fields
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.clickOkButton();

            //To Get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            SMUtils.logDescriptionTC( "tc033 -(Admin LSR)Verify the Selected columns available in exported csv for math assignments" );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );
            Log.assertThat( columnsFromResponse.containsAll( Arrays.asList( "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) + "\"", "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) + "\"" ) ),
                    "Selected Columns are exported in the downloaded csv", "Selected Columns are not exported in the downloaded csv.Expected -"
                            + Arrays.asList( "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) + "\"", "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) + "\"" ) + ".Actual -" + columnsFromResponse );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc034 -(Admin LSR)Verify the multiple values in Selected columns is available in exported csv for math assignments" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "Custom Exported csv downloaded for multiple selected fields - Math Assignment",
                    "Custom Exported csv is not downloaded for multiple selected fields - Math Assignment" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the Selected columns values available in exported csv for Reading assignments" )
    public void tcAdminLSRExportCsv014() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv014 - (Admin LSR)Verify the Selected columns values available in exported csv for Reading assignments" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, false, assignmentIds, true, false,
                    Arrays.asList( LSRExportCsv.MATH_CUSTOM_SELECTED_FILTERS.get( 1 ), LSRExportCsv.MATH_CUSTOM_SELECTED_FILTERS.get( 2 ) ), new HashMap<>(), 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();

            //To select custom export radio button
            exportPopup.clickCustomizeExportRadioButton();
            //To select the custom selcted fields
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ), LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.clickOkButton();

            //To Get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            SMUtils.logDescriptionTC( "tc035 -(Admin LSR)Verify the Selected columns values available in exported csv for Reading assignments" );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );
            Log.assertThat( columnsFromResponse.containsAll( Arrays.asList( "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) + "\"", "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) + "\"" ) ),
                    "Selected Columns are exported in the downloaded csv", "Selected Columns are not exported in the downloaded csv.Expected -"
                            + Arrays.asList( "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) + "\"", "\"" + LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 2 ) + "\"" ) + ".Actual -" + columnsFromResponse );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc036 -(Admin LSR)Verify the multiple values in Selected columns is available in exported csv for Reading assignments" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "Custom Exported csv downloaded for multiple selected fields - Reading Assignment",
                    "Custom Exported csv is not downloaded properly for multiple selected fields - Reading Assignment" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the single values in Selected columns is available in exported csv for math assignments" )
    public void tcAdminLSRExportCsv015() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv015 - (Admin LSR)Verify the single values in Selected columns is available in exported csv for math assignments" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, true, false, Arrays.asList( LSRExportCsv.MATH_CUSTOM_SELECTED_FILTERS.get( 1 ) ), new HashMap<>(), 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();

            //To select custom export radio button
            exportPopup.clickCustomizeExportRadioButton();
            //To select the custom selcted fields
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.clickOkButton();

            //To Get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc037 -(Admin LSR)Verify the single values in Selected columns is available in exported csv for math assignments" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "Custom Exported csv downloaded for single selected fields - Math Assignment",
                    "Custom Exported csv is not downloaded for single selected fields - Math Assignment" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-67581", "LSR - Export csv", "smoke_test_case" }, description = "(Admin LSR)Verify the single values in Selected columns is available in exported csv for Reading assignments" )
    public void tcAdminLSRExportCsv016() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminLSRExportCsv016 - (Admin LSR)Verify the single values in Selected columns is available in exported csv for Reading assignments" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginSMReportsAsAdmin( districtAdminUsername, password );

            //Navigate to LSR Page
            LastSessionReportPage lastSessionsPage = AFGPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields - selecting organization
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, schoolName );
            //To select the Subject 
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment 
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.expandOptionalFilter();
            //To Expand optional filter
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( teacherNames.get( teacherUsernames.get( 0 ) ), teacherNames.get( teacherUsernames.get( 1 ) ) ) );

            //Click Run Report button
            LastSessionReportViewerPage lastSessionOutpage = lastSessionsPage.clickRunReportButton();

            //To get the assignment Ids
            List<String> assignmentIds = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
            } ).collect( Collectors.toList() );

            String requestId = driver.getCurrentUrl().split( "=" )[1];
            Response getAdminLastSessionReportCsv = AdminReportCsv.GetAdminLastSessionReportCsv( headers, orgId, true, assignmentIds, false, false, Arrays.asList( LSRExportCsv.MATH_CUSTOM_SELECTED_FILTERS.get( 1 ) ), new HashMap<>(), 0, requestId );
            List<Map<String, String>> exportedCSVFromAPI = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( getAdminLastSessionReportCsv.getBody().asString(), "signedUrl" ) ) );

            //Click Export CSV Button
            ExportPopupComponent exportPopup = lastSessionOutpage.reportOutputComponent.clickExportCSVButton();

            //To select custom export radio button
            exportPopup.clickCustomizeExportRadioButton();
            //To select the custom selcted fields
            exportPopup.selectAvailableColumns( Arrays.asList( LSRExportCsv.READING_CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.clickOkButton();

            //To Get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc038 -(Admin LSR)Verify the single values in Selected columns is available in exported csv for Reading assignments" );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );

            //Comparing both API and UI data
            Log.assertThat( exportedCSVFromAPI.stream().allMatch( dataFromAPI -> exportedCSVFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "Custom Exported csv downloaded for single selected fields - Reading Assignment",
                    "Custom Exported csv is not downloaded for single selected fields - Reading Assignment" + exportedCSVFromAPI.toString() + ".Actual -" + exportedCSVFromUI.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public String getCSVFileFromSignedUrl( String signedUrl ) {
        //To get the CSV File
        String csvDataFromBS = null;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            driver.get( signedUrl );
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            driver.quit();
        }
        return csvDataFromBS;
    }
}
