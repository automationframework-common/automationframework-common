package com.savvas.sm.reports.ui.tests.teacher;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.teacher.ui.pages.StudentPerformanceReportsPages;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.ReportOutputComponent;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import io.restassured.response.Response;

public class SPRTeacherIntegrateBFFWithMFE extends EnvProperties {

	private String browser;
	CourseAPI coursesMethod = new CourseAPI();
	RBSUtils rbsUtils = new RBSUtils();
	private String flexSchool = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String smUrl;
	String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	private static HashMap<String, String> assignmentIds = new HashMap<String, String>();
	String selectedSchoolId;
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	String subjectName;
	String teacherUsername;
	String teacherName;
	String teacherId;
	String studentAssignmentIdMath;
	String studentAssignmentIdReading;
	String orgID;
	String orgName;
	private String groupID;
	String groupName;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();
	Response response = null;
	private List<String> studentRumbaIds = new ArrayList<>();
	String studentDetails1;
	String studentDetails2;
	public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String teacherDetails;
	String studentId1;
	String studentId2;
	String studentDetails3;
	String studentUsername3;
	String studentUserId3;
	String studentName3;
	private List<String> courseIDs = new ArrayList<>();
	String smReportsUrl;
	String configGraphQL;

	@BeforeClass(alwaysRun = true)
	public void initTest() throws Exception {

		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherUsername = SMUtils.getKeyValueFromResponse(teacherDetails, "userName");
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		studentDetails1 = RBSDataSetup.getMyStudent(school, teacherUsername);
		studentDetails2 = RBSDataSetup.getMyStudent(school, teacherUsername);
		orgID = RBSDataSetup.organizationIDs.get(school);
		studentId1 = SMUtils.getKeyValueFromResponse(studentDetails1, "userId");
		studentId2 = SMUtils.getKeyValueFromResponse(studentDetails2, "userId");
		studentDetails3 = RBSDataSetup.getMyStudent(school, teacherUsername);
		studentUsername3 = SMUtils.getKeyValueFromResponse(studentDetails3, Constants.USER_NAME);
		studentUserId3 = SMUtils.getKeyValueFromResponse(studentDetails3, Constants.USERID_HEADER);
		studentName3 = SMUtils.getKeyValueFromResponse(rbsUtils.getUser(studentUserId3), "firstAndLastName");
		Log.message("Student Name: " + studentName3);

		smReportsUrl = configProperty.getProperty("SPRMockEnvironmentTeacher");
		configGraphQL = "https://sm-reports-bff-srv-stack-stage.smdemo.info/graphql";
		
		studentRumbaIds.add(studentUserId3);

		studentRumbaIds.add(
				SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student1"), "userId"));
		studentRumbaIds.add(
				SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student2"), "userId"));
		String token = new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, "userName"), RBSDataSetupConstants.DEFAULT_PASSWORD));
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, "groupName");

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get(school));
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, "userName"), RBSDataSetupConstants.DEFAULT_PASSWORD));
		Log.message("Created Group" + new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds));
		HashMap<String, String> groupDetail = new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds);
		groupID = SMUtils.getKeyValueFromResponse(groupDetail.get(Constants.REPORT_BODY), "data,groupId");

		contentBaseName.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE);

		contentBaseName.put(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime()));

		contentBaseName.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE);
		contentBaseName.put(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				String.format(DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime()));

		Log.message("contentbasename" + contentBaseName);
		contentBase.put(AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH);
		contentBase.put(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS,
				AssignmentAPIConstants.FOCUS_MATH);
		contentBase.put(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				new CourseAPI().createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
						orgID.toString(), DataSetupConstants.SETTINGS, contentBaseName
								.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));

		contentBase.put(AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING);
		contentBase.put(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS,
				AssignmentAPIConstants.FOCUS_READING);
		contentBase.put(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				new CourseAPI().createCourse(smUrl, token, DataSetupConstants.READING, teacherId.toString(),
						orgID.toString(), DataSetupConstants.SETTINGS, contentBaseName
								.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));

		courseIDs.add(contentBase.get(AssignmentAPIConstants.MATH_COURSE));
		courseIDs.add(contentBase.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE));

		courseIDs.add(contentBase.get(AssignmentAPIConstants.READING_COURSE));
		courseIDs.add(contentBase.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE));

		Log.message("Assigning assignment...");

		HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
				assignmentDetails, studentRumbaIds, courseIDs);
		Log.message("Assignment Details" + assignmentResponse);
		String username = SMUtils.getKeyValueFromResponse(studentDetails3, Constants.USER_NAME);
		Log.message("username:" + username);
		try {
			executeCourse(studentUsername3, contentBaseName.get(AssignmentAPIConstants.MATH_COURSE), true);
			executeCourse(studentUsername3,
					contentBaseName.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE),
					true);

			executeCourse(studentUsername3, contentBaseName.get(AssignmentAPIConstants.READING_COURSE), false);
			executeCourse(studentUsername3,
					contentBaseName.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE),
					false);

		} catch (IOException e) {
			e.printStackTrace();
		}

		JSONObject assignmentDetailsJson = new JSONObject(assignmentResponse.get(Constants.REPORT_BODY));
		Log.message("assignmentDetailsJson" + assignmentDetailsJson);
		JSONArray assignmentList = assignmentDetailsJson.getJSONArray(Constants.DATA);

		for (Object assignment : assignmentList) {
			JSONObject assignmentInfo = new JSONObject(assignment.toString());
			assignmentIds.put(assignmentInfo.get("assignmentName").toString(),
					assignmentInfo.get("assignmentId").toString());
		}
		Log.message("Assignment IDs - " + assignmentIds);

	}

	@Test(description = " Verify and compare report output with BFF response for Teacher with default Math", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE001() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE001: Verify and compare report output with BFF response for Teacher user <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page
			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			while (!outputPage.getStudentUserName().equalsIgnoreCase(studentUsername3)) {
				outputPage.clickNextBtn();

				Log.message(
						"Student name is not matched! Expected-> " + studentUsername3 + " , Clicking Next Button!!");
			}

			StudentPerformanceReportsPages studentPerformancePages = new StudentPerformanceReportsPages(driver);
			List<String> strandDataFromUi = studentPerformancePages.getStrandDataFromUi(driver).stream().map(data -> data.replace(" ", ""))
					.collect(Collectors.toList());
			Log.message("Data from UI: " + strandDataFromUi);

			List<String> stRandDetailsFromApi = getStrandDetailsFromApi(res, "Math").stream()
					.map(data -> data.replace(" ", "")).collect(Collectors.toList());
			Log.message("Data from BFF: " + stRandDetailsFromApi);

			// Verify and Compare the both values
			Log.assertThat(stRandDetailsFromApi.containsAll(strandDataFromUi), "MFE Values are matched with BFF value",
					"MFE Values are not matched with BFF value");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = " Verify and compare report output with BFF response for Teacher with default Reading", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE002() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE002: Verify and compare report output with BFF response for Teacher user <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int readingAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.READING_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 2, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(readingAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.READING);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Reading"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			StudentPerformanceReportsPages studentPerformancePages = new StudentPerformanceReportsPages(driver);
			List<String> strandDataFromUi = studentPerformancePages.getStrandDataFromUi(driver).stream().map(data -> data.replace(" ", ""))
					.collect(Collectors.toList());
			Log.message("Data from UI: " + strandDataFromUi);

			List<String> stRandDetailsFromApi = getStrandDetailsFromApi(res, "Reading").stream()
					.map(data -> data.replace(" ", "")).collect(Collectors.toList());
			Log.message("Data from BFF: " + stRandDetailsFromApi);

			Log.assertThat(strandDataFromUi.containsAll(stRandDetailsFromApi), "MFE Values are matched with BFF value",
					"MFE Values are not matched with BFF value");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = " Verify and compare report output with BFF response for Teacher with Math-custom settings", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE003() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE003: Verify and compare report output with BFF response for Teacher user <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer.parseInt(getAssignmentId(
					contentBaseName.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, new ArrayList<>(),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));

			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL, Arrays.asList(
					contentBaseName.get(AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			StudentPerformanceReportsPages studentPerformancePages = new StudentPerformanceReportsPages(driver);
			List<String> strandDataFromUi = studentPerformancePages.getStrandDataFromUi(driver).stream().map(data -> data.replace(" ", ""))
					.collect(Collectors.toList());
			Log.message("Data from UI: " + strandDataFromUi);

			List<String> stRandDetailsFromApi = getStrandDetailsFromApi(res, "Math").stream()
					.map(data -> data.replace(" ", "")).collect(Collectors.toList());
			Log.message("Data from BFF: " + stRandDetailsFromApi);

			// Verify and Compare the both values
			Log.assertThat(stRandDetailsFromApi.containsAll(strandDataFromUi), "MFE Values are matched with BFF value",
					"MFE Values are not matched with BFF value");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = " Verify and compare report output with BFF response for Teacher with Reading-custom settings", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE004() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE004: Verify and compare report output with BFF response for Teacher user <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int readingAssignmentId = Integer.parseInt(getAssignmentId(contentBaseName
					.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 2, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(readingAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.READING);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(contentBaseName
							.get(AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE)));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			StudentPerformanceReportsPages studentPerformancePages = new StudentPerformanceReportsPages(driver);
			List<String> strandDataFromUi = studentPerformancePages.getStrandDataFromUi(driver).stream().map(data -> data.replace(" ", ""))
					.collect(Collectors.toList());
			Log.message("Data from UI: " + strandDataFromUi);

			List<String> stRandDetailsFromApi = getStrandDetailsFromApi(res, "Reading").stream()
					.map(data -> data.replace(" ", "")).collect(Collectors.toList());
			Log.message("Data from BFF: " + stRandDetailsFromApi);

			// Verify and Compare the both values
			Log.assertThat(stRandDetailsFromApi.containsAll(strandDataFromUi), "MFE Values are matched with BFF value",
					"MFE Values are not matched with BFF value");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = " Verify the Student Username is displaying in the report output screen when Display is selected as 'Student username'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE005() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE005: Verify and compare report output with BFF response for Teacher user <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.getStudentUserName().equalsIgnoreCase(studentUsername3),
					"Student username is matched with the Output Page!",
					"Student username is not matched with the Output Page! Expected-> " + studentUsername3);

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the Student ID is displaying in the report output screen when Display is selected as 'Student ID' ", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE006() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE006: Verify the Student ID is displaying in the report output screen when Display is selected as 'Student ID'  <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int MathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(MathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();
			String studentId = getStudentId(res);

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(1));

			reportComponents.handleStudentPopup();

			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.getStudentUserName().equalsIgnoreCase(studentId),
					"Student ID is matched with the Output Page!",
					"Student ID is not matched with the Output Page! Expected-> " + studentId);

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Performance Summary' Column in the Student Performance report output page when clicking Include Performance Summary as 'Yes'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE007() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE007: Verify the 'Performance Summary' Column in the Student Performance report output page when clicking Include Performance Summary as 'Yes' <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.isPerformanceSummaryTitleAsExpected(),
					"The Performance Summary is included in the Output Page",
					"The Performance Summary has  not been included in the Output Page");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Performance Summary' Column not visible in the Student Performance report output page when clicking Include Performance Summary as 'No'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE008() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE008: Verify the 'Performance Summary' Column not visible in the Student Performance report output page when clicking Include Performance Summary as 'No' <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickNoRadioButton(ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY);
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(!outputPage.isPerformanceSummaryDislayed(),
					"PASS: The Performance Summary is not included in the Output Page",
					"FAIL: The Performance Summary has been included in the Output Page");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Performance by Strand' column in the Student Performance report output page when clicking 'Include Performance by Strand' as 'Yes'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE009() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE009: Verify the 'Performance by Strand' column in the Student Performance report output page when clicking 'Include Performance by Strand' as 'Yes'  <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.isPerformanceByStrandCumulativeTitleAsExpected(),
					"Title for Performance by Strand is as expected",
					"Title for Performance by Strand is not as expected");
			Log.softAssertThat(
					outputPage.toValidatePerformanceByStrandSection(ReportsUIConstants.COMPUTATION_STRANDS,
							outputPage.getperformanceByStrandReportSubHeaderChild()) == 5,
					"Size is as expected", "Size is not as expected");
			Log.softAssertThat(
					outputPage.toValidatePerformanceByStrandSection(ReportsUIConstants.APPLICATION_STRANDS,
							outputPage.getperformanceByStrandReportSubHeaderChild()) == 5,
					"Size is as expected", "Size is not as expected");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Performance by Strand' column is not visible in the Student Performance report output page when clicking 'Include Performance by Strand' as 'No'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE010() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE010: Verify the 'Performance by Strand' column is not visible in the Student Performance report output page when clicking 'Include Performance by Strand' as 'No' <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));

			reportComponents.clickNoRadioButton(ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND);
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(!outputPage.isPerformanceByStrandDisplayed(),
					"Pass: The Performance By Strand is not included in the output page",
					"FAIL: The Performance By Strand is included in the output page");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Areas For Growth' column in the Student Performance report output page when selecting 'Include Areas For Growth' as 'Yes'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE011() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE011: Verify the 'Areas For Growth' column in the Student Performance report output page when selecting 'Include Areas For Growth' as 'Yes'  <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int mathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(mathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));

			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.isAreasForGrowthTitleAsExpected(), "The Areas for Growth title is as expected",
					"The Areas for Growth title is as not expected");
			Log.softAssertThat(
					outputPage.toValidateAreaForGrowthSection(ReportsUIConstants.SKILLS_IN_DELAYED_PRESENTATION,
							outputPage.getAreaForGrowthReportSubHeaderChild()) == 4,
					"Size is as expected", "Size is not as expected");
			Log.softAssertThat(
					outputPage.toValidateAreaForGrowthSection(ReportsUIConstants.SKILLS_NOT_MASTERED,
							outputPage.getAreaForGrowthReportSubHeaderChild()) == 4,
					"Size is as expected", "Size is not as expected");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Areas For Growth' column is not visible in the Student Performance report output page when selecting 'Include Areas For Growth' as 'No'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE012() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE012: Verify the 'Areas For Growth' column is not visible in the Student Performance report output page when selecting 'Include Areas For Growth' as 'No'<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int MathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(MathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.clickNoRadioButton(ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH);
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(!outputPage.isAreaForGrowthDisplayed(),
					"The Areas for Growth title is not included as expected", "The Areas for Growth title is included");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Areas For Growth' Column in the Student Performance report output page when selecting the 'Date at Risk as '24 weeks'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE013() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE013: Verify the 'Areas For Growth' Column in the Student Performance report output page when selecting the 'Date at Risk as '24 weeks'<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int MathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(MathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DATE_AT_RISK, "24 Weeks");
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.isAreasForGrowthTitlefor24Weeks(),
					"The Areas for Growth title is included as expected",
					"The Areas for Growth title has not included");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the 'Areas For Growth' Column in the Student Performance report output page when selecting the 'Date at Risk as '16 weeks'", groups = {
			"SMK-68048", "TeacherDashboard", "Reports", "Student Performance", "Smoke" }, priority = 1)
	public void tcSPRIntegrateBFFWithMFE014() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);

		HashMap<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken(teacherUsername, password));

		Log.testCaseInfo(
				"tcSPRIntegrateBFFWithMFE014: Verify the 'Areas For Growth' Column in the Student Performance report output page when selecting the 'Date at Risk as '16 weeks'<small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			int MathAssignmentId = Integer
					.parseInt(assignmentIds.get(contentBaseName.get(AssignmentAPIConstants.MATH_COURSE)));

			String payload = getResponseBody(teacherId, orgID, 1, false, Arrays.asList(groupID),
					Arrays.asList(studentUserId3), Arrays.asList(MathAssignmentId));
			response = RestAssuredAPIUtil.POSTGraphQl(ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload,
					ReportAPIConstants.GRAPH_QL_ENDPOINT);
			Log.message("response :" + response.getBody().asString());

			String res = response.getBody().asString();

			AdminLauncherPage smLoginPage = new AdminLauncherPage(driver, smUrl).get();

			AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher(teacherUsername, password);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to SPR Page

			StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents
					.clickStudentPerformancePage();

			Log.message("Login with TeacherUserName: " + teacherUsername + " password: " + password);//
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			ReportComponents reportComponents = new ReportComponents(driver);
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SUBJECT_LABEL,
					ReportsUIConstants.MATH);

			// De-select selectAll Assignments dropdown
			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList(ReportsUIConstants.SELECT_ALL));

			reportComponents.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ASSIGNMENTS_LBL,
					Arrays.asList("Math"));

			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DISPLAY_LABEL,
					ReportsUIConstants.DISPLAY.get(2));
			reportComponents.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.DATE_AT_RISK, "16 Weeks");
			reportComponents.clickRunReportButton();

			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.switchWindow(driver);
			SMUtils.waitForPageLoad(driver);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(20);

			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);
			SMUtils.waitForSpinnertoDisapper(driver, 20);

			Log.assertThat(outputPage.isAreasForGrowthTitlefor16Weeks(),
					"The Areas for Growth title is included as expected",
					"The Areas for Growth title has not included");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "SPR-Teacher Math Mock for 1 assignemnt Data", groups = { "mock" ,"TeacherDashboard", "Reports", "Student Performance", "Smoke","SMK-67107" })
	private void tcSPRIntegrateBFFWithMFE015(ITestContext context) throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("SPR-Teacher Math Mock for 1 assignemnt Data " + browser + "]</b></i></small>");

		String mathMock = null;
		DevTools devTool = null;
		String reportUrl = smReportsUrl + UUID.randomUUID();
		try {
			if (DevToolsUtils.isMock(context)) {
				Map<String, String> responses = new HashMap();
				String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("SPRGetReportOptionResponse.json");
				mathMock = DevToolsUtils.readJsonResponse("SPRTeacherMathMock.json");
				responses.put("GetReportOptionResponse", getReportOptionResponseJson);
				responses.put("GetISPReportData", mathMock);

				List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetISPReportData");
				devTool = DevToolsUtils.setResponse(driver, configGraphQL, requestPayloadMatchers, "post", responses);
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			}
			LoginWrapper.loginToMasteryMfe(driver, reportUrl, teacherUsername, password);
			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(20);

			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);

			Log.message("TotalPageNo: " + outputPage.totalPageNo());
			StudentPerformanceReportsPages studentPerformancePages = new StudentPerformanceReportsPages(driver);
			List<String> strandDataFromUi = studentPerformancePages.getStrandDataFromUi(driver).stream().map(data -> data.replace(" ", ""))
					.collect(Collectors.toList());
			Log.message("Data from UI: " + strandDataFromUi);

			List<String> stRandDetailsFromApi = getStrandDetailsFromApi(mathMock, "Math").stream()
					.map(data -> data.replace(" ", "")).collect(Collectors.toList());
			Log.message("Data from BFF: " + stRandDetailsFromApi);

			// Verify and Compare the both values
			Log.assertThat(stRandDetailsFromApi.containsAll(strandDataFromUi), "MFE Values are matched with BFF value",
					"MFE Values are not matched with BFF value");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != devTool) {
				RequestMockUtils.closeMock(devTool);
			}
			driver.quit();
		}
	}

	@Test(description = "SPR-Teacher Math Mock for 30 assignemnt Data", groups = { "mock","TeacherDashboard", "Reports", "Student Performance", "Smoke","SMK-67102"  })
	private void tcSPRIntegrateBFFWithMFE016() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("SPR-Teacher Math Mock for 30 assignemnt Data " + browser + "]</b></i></small>");

		String mathMock = null;
		DevTools devTool = null;
		String reportUrl = smReportsUrl + UUID.randomUUID();
		try {

			Map<String, String> responses = new HashMap();
			String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("SPRGetReportOptionResponse.json");
			mathMock = DevToolsUtils.readJsonResponse("SPRMath30.json");
			responses.put("GetReportOptionResponse", getReportOptionResponseJson);
			responses.put("GetISPReportData", mathMock);

			List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetISPReportData");
			devTool = DevToolsUtils.setResponse(driver, configGraphQL, requestPayloadMatchers, "post", responses);
			devTool.createSessionIfThereIsNotOne();
			Log.message(devTool.getCdpSession().toString());

			LoginWrapper.loginToMasteryMfe(driver, reportUrl, teacherUsername, password);
			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(20);

			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);

			Log.assertThat((outputPage.totalPageNo() == 30), "The report has mocked with 30 student data", "The report doesn't contain 30 student data");

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != devTool) {
				RequestMockUtils.closeMock(devTool);
			}
			driver.quit();
		}
	}

	@Test(description = "SPR-Teacher Math Mock for max assignemnt Data", groups = { "mock","TeacherDashboard", "Reports", "Student Performance", "Smoke","SMK-67102"  })
	private void tcSPRIntegrateBFFWithMFE017() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("SPR-Teacher Math Mock for max assignemnt Data " + browser + "]</b></i></small>");

		String mathMock = null;
		DevTools devTool = null;
		String reportUrl = smReportsUrl + UUID.randomUUID();
		try {
			
				Map<String, String> responses = new HashMap();
				String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("SPRGetReportOptionResponse.json");
				mathMock = DevToolsUtils.readJsonResponse("SPRMathMax.json");
				responses.put("GetReportOptionResponse", getReportOptionResponseJson);
				responses.put("GetISPReportData", mathMock);

				List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetISPReportData");
				devTool = DevToolsUtils.setResponse(driver, configGraphQL, requestPayloadMatchers, "post", responses);
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			
			LoginWrapper.loginToMasteryMfe(driver, reportUrl, teacherUsername, password);
			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(20);

			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);

			Log.message("TotalPageNo: " + outputPage.totalPageNo());

			Log.assertThat((outputPage.totalPageNo() == 1000), "The report has been mocked with 1000 students",
					"The report hasn't been mocked with 1000 students.");
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != devTool) {
				RequestMockUtils.closeMock(devTool);
			}
			driver.quit();
		}
	}

	@Test(description = "Verify SPR Teacher Math Mock for Zero state", groups = { "mock" ,"TeacherDashboard", "Reports", "Student Performance", "Smoke","SMK-67102" })
	private void tcSPRIntegrateBFFWithMFE018(ITestContext context) throws Exception {

		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("Verify SPR Teacher Math Mock for Zero state" + browser + "]</b></i></small>");

		String mathMock = null;
		DevTools devTool = null;
		String reportUrl = smReportsUrl + UUID.randomUUID();
		try {
			if (DevToolsUtils.isMock(context)) {
				Map<String, String> responses = new HashMap();
				String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("SPRGetReportOptionResponse.json");
				mathMock = DevToolsUtils.readJsonResponse("ZeroMathMock.json");
				responses.put("GetReportOptionResponse", getReportOptionResponseJson);
				responses.put("GetISPReportData", mathMock);

				List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetISPReportData");
				devTool = DevToolsUtils.setResponse(driver, configGraphQL, requestPayloadMatchers, "post", responses);
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			}
			LoginWrapper.loginToMasteryMfe(driver, reportUrl, teacherUsername, password);
			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(20);

			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);

			StudentPerformanceReportsPages studentPerformancePage = new StudentPerformanceReportsPages(driver);
			Log.assertThat(studentPerformancePage.noDataDisplayed().equalsIgnoreCase("No data to display"),
					"Zero state Verified!", "Zero state Not Verified!");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != devTool) {
				RequestMockUtils.closeMock(devTool);
			}
			driver.quit();
		}
	}

	@Test(description = "SPR-Teacher Math Read for min assignment Data", groups = {"mock","TeacherDashboard", "Reports", "Student Performance", "Smoke","SMK-67107"})
	private void tcSPRIntegrateBFFWithMFE019() throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("SPR-Teacher Math Read for min assignment Data " + browser + "]</b></i></small>");

		String readMock = null;
		DevTools devTool = null;
		String reportUrl = smReportsUrl + UUID.randomUUID();
		try {
				Map<String, String> responses = new HashMap();
				String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("SPRGetReportOptionResponse.json");
				readMock = DevToolsUtils.readJsonResponse("SPRReadMockMin.json");
				responses.put("GetReportOptionResponse", getReportOptionResponseJson);
				responses.put("GetISPReportData", readMock);

				List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetISPReportData");
				devTool = DevToolsUtils.setResponse(driver, configGraphQL, requestPayloadMatchers, "post", responses);
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			LoginWrapper.loginToMasteryMfe(driver, reportUrl, teacherUsername, password);
			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(20);

			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 10);

			Log.message("TotalPageNo: " + outputPage.totalPageNo());
			
			Log.assertThat(outputPage.totalPageNo()==1, "The report has been mocked with single student data", "The report doesn't contain any student data");

			Log.testCaseResult();


		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != devTool) {
				RequestMockUtils.closeMock(devTool);
			}
			driver.quit();
		}
	}

	@Test(description = "SPR-Teacher Math Read for max assignemnt Data", groups = { "mock","TeacherDashboard", "Reports", "Student Performance", "Smoke","SMK-67107" })
	private void tcSPRIntegrateBFFWithMFE020(ITestContext context) throws Exception {
		final WebDriver driver = WebDriverFactory.get(browser);

		Log.testCaseInfo("SPR-Teacher Math Read for max assignemnt Data " + browser + "]</b></i></small>");

		String mathMock = null;
		DevTools devTool = null;
		String reportUrl = smReportsUrl + UUID.randomUUID();
		try {
			if (DevToolsUtils.isMock(context)) {
				Map<String, String> responses = new HashMap();
				String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("SPRGetReportOptionResponse.json");
				mathMock = DevToolsUtils.readJsonResponse("ReadingMaxData.json");
				responses.put("GetReportOptionResponse", getReportOptionResponseJson);
				responses.put("GetISPReportData", mathMock);

				List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetISPReportData");
				devTool = DevToolsUtils.setResponse(driver, configGraphQL, requestPayloadMatchers, "post", responses);
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			}
			LoginWrapper.loginToMasteryMfe(driver, reportUrl, teacherUsername, password);
			ReportOutputComponent outputPage = new ReportOutputComponent(driver);
			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(20);

			SMUtils.waitForSpinnertoDisapper(driver);
			Log.assertThat(outputPage.getReportPageTitle().equalsIgnoreCase(ReportTypes.STUDENT_PERFORMANCE),
					"Teacher SPR Run Report option displayed", "Teacher SPR Run Report is not clicked");
			SMUtils.waitForSpinnertoDisapper(driver, 5);

			Log.message("TotalPageNo: " + outputPage.totalPageNo());
			
			Log.assertThat(outputPage.totalPageNo()==1000, "The report has mocked with 1000 student data", "The report doesn't contain 1000 data");
			

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			if (null != devTool) {
				RequestMockUtils.closeMock(devTool);
			}
			driver.quit();
		}
	}

	// Get response body
	public String getResponseBody(String userId, String orgId, int subject, boolean isGroupSelected,
			List<String> groupIds, List<String> studentIds, List<Integer> assignmentIds) {
		AtomicReference<String> requestBody = new AtomicReference<>();
		try {

			String basePath = (new File(".")).getCanonicalPath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson"
					+ File.separator + "report" + File.separator + "ISPReportRequestAll" + ".json";
			requestBody.set(SMUtils.convertFileToString(basePath));

			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.organizationId", orgId));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.teacherId", userId));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.isGroupSelected", isGroupSelected));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.subject", subject));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.studentIds", studentIds));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.groupIds", groupIds));
			requestBody.set(JSONUtil.setProperty(requestBody.get(), "variables.assignmentIds", assignmentIds));

			Log.message("Payload : " + requestBody.get());
			Log.message(""
					+ "************************************************************************************************\n");
		} catch (Exception e) {
			Log.message(e.getMessage());
		}
		return requestBody.get();
	}

	/**
	 * To execute the course
	 * 
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void executeCourse(String studentUserName, String courseName, boolean isMath) throws IOException {
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.message("Student username " + studentUserName);
		LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUserName,
				RBSDataSetupConstants.DEFAULT_PASSWORD);
		StudentDashboardPage studentsPage = new StudentDashboardPage(driver);

		if (isMath) {
			try {
				studentsPage.executeMathCourse(studentUserName, courseName, "100", "3", "30");
				studentsPage.logout();
				driver.close();
			} catch (Exception e) {
				driver.close();
			}
		} else {
			try {
				studentsPage.executeReadingCourse(studentUserName, courseName, "100", "3", "35");
				studentsPage.logout();
				driver.close();
			} catch (Exception e) {
				driver.close();
			}
		}

	}

	private List<String> getStrandDetailsFromApi(String response, String subject) {
		String keyValueFromResponse = SMUtils.getKeyValueFromResponse(response, "data");
		String valueFromResponse = SMUtils.getKeyValueFromResponse(keyValueFromResponse, "getISPReportData");
		String responseData = SMUtils.getKeyValueFromResponse(valueFromResponse, "ispReportResponse");
		JSONArray jsArray = new JSONObject(responseData).getJSONArray("strandRows");
		String strandName = subject.equals("Math") ? "strandDescription" : "cttypeName";
		List<String> strandData = new ArrayList<>();
		IntStream.range(0, jsArray.length()).forEach(itr -> {
			if (!strandData.contains(SMUtils.getKeyValueFromResponse(jsArray.get(itr).toString(), strandName))) {
				strandData.add(SMUtils.getKeyValueFromResponse(jsArray.get(itr).toString(), strandName));
				strandData.add(SMUtils.getKeyValueFromResponse(jsArray.get(itr).toString(), "formattedStrandLevel"));
				strandData.add(SMUtils.getKeyValueFromResponse(jsArray.get(itr).toString(), "formattedStrandCorrect"));
				strandData.add(SMUtils.getKeyValueFromResponse(jsArray.get(itr).toString(), "formattedStrandAttempts"));
				strandData.add(SMUtils.getKeyValueFromResponse(jsArray.get(itr).toString(), "percentSkillsMastered"));
			}
		});

		return strandData;

	}


	private String getStudentId(String response) {
		String keyValueFromResponse = SMUtils.getKeyValueFromResponse(response, "data");
		String valueFromResponse = SMUtils.getKeyValueFromResponse(keyValueFromResponse, "getISPReportData");
		String responseData = SMUtils.getKeyValueFromResponse(valueFromResponse, "ispReportResponse");
		JSONArray jsArray = new JSONObject(responseData).getJSONArray("psRows");
		return SMUtils.getKeyValueFromResponse(jsArray.get(0).toString(), "sisUserId");
	}

	private String getAssignmentId(String assignmentName) throws Exception {
		String assignmentByStudent = new AssignmentAPI().getAssignmentByStudent(smUrl,
				new RBSUtils().getAccessToken(teacherUsername, password), studentUserId3, orgID, teacherId);
		Log.message(assignmentByStudent);

		String keyValueFromResponse = SMUtils.getKeyValueFromResponse(assignmentByStudent, "data");

		JSONArray jsonArray = new JSONArray(keyValueFromResponse);
		List<String> assignmentIds = new ArrayList<>();

		jsonArray.forEach(assignments -> {
			if (new JSONObject(new JSONObject(assignments.toString()).get("courseDetail").toString()).get("name")
					.toString().equalsIgnoreCase(assignmentName)) {
				assignmentIds.add(new JSONObject(assignments.toString()).get("assignmentId").toString());
			}
		});

		Log.message("Assignment id for " + assignmentName + " is " + assignmentIds.get(0));
		return assignmentIds.get(0);
	}

}
