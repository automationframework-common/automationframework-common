package com.savvas.sm.reports.admin.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class StudentPerformanceReportPage extends LoadableComponent<StudentPerformanceReportPage> {

    WebDriver driver;
    boolean isPageLoaded;
    public AdminReportFilterComponent reportFilterComponent;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;

    @IFindBy ( how = How.CSS, using = "report-title p.description", AI = false )
    WebElement description;

    @IFindBy ( how = How.CSS, using = "section.additional-filters-section checkbox-item > cel-checkbox-item", AI = false )
    WebElement checkBoxParent;

    @IFindBy ( how = How.CSS, using = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(1)", AI = false )
    WebElement includePerformanceSummarylblRoot;

    @IFindBy ( how = How.CSS, using = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(2)", AI = false )
    WebElement includePerformanceStrandlblRoot;

    @IFindBy ( how = How.CSS, using = "performance-inclusion cel-radio-button-group[class='row hydrated']:nth-child(3)", AI = false )
    WebElement includeAreasOfGrowthlblRoot;

    /******************* Child Elements ******************************/
    private static String maskStudentCheckBoxCSS = "label > input[type=checkbox]";
    private static String noBtnRoot = "div:nth-child(1) > div:nth-child(2) > cel-radio-button:nth-child(2)";
    private String noBtnChild = "#no";

    public StudentPerformanceReportPage() {}

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public StudentPerformanceReportPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        reportFilterComponent = new AdminReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, description );
    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, description, 50 ) ) {
            Log.message( "Student Performance report Page loaded successfully." );
        } else {
            Log.fail( "Student Performance report not loaded successfully." );
        }
        elementLayer = new ElementLayer( driver );
    }

    /**
     * To Click the Run Report button
     * 
     * @return
     */
    public StudentPerformanceReportViewerPage clickRunReportButton() {
        reportFilterComponent.clickRunReportButton();
        return new StudentPerformanceReportViewerPage( driver ).get();
    }

    /**
     * click checkbox Mask Student CheckBox
     */
    public void clickMaskStudentCheckBox() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }

    /**
     * Click No Radio button
     * 
     * @param dropDownName
     */
    public void clickNoRadioButton( String type ) {
        WebElement noParentElement;
        if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ) ) {
            SMUtils.waitForElement( driver, includePerformanceSummarylblRoot );
            noParentElement = SMUtils.getWebElement( driver, includePerformanceSummarylblRoot, noBtnRoot );
        } else if ( type.equals( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ) ) {
            SMUtils.waitForElement( driver, includePerformanceStrandlblRoot );
            noParentElement = SMUtils.getWebElement( driver, includePerformanceStrandlblRoot, noBtnRoot );
        } else {
            SMUtils.waitForElement( driver, includeAreasOfGrowthlblRoot );
            noParentElement = SMUtils.getWebElement( driver, includeAreasOfGrowthlblRoot, noBtnRoot );
        }

        WebElement atualElement = SMUtils.getWebElement( driver, noParentElement, noBtnChild );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked No Radio Button" );

    }

}