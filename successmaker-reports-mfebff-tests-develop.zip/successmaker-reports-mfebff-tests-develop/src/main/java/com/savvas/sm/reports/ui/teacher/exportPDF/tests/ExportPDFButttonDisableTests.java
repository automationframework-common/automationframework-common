package com.savvas.sm.reports.ui.teacher.exportPDF.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.Reports;
import com.savvas.sm.reports.smoke.teacher.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.teacher.pages.CumulativePerformanceReport;
import com.savvas.sm.reports.smoke.teacher.pages.LastSessionReport;
import com.savvas.sm.reports.smoke.teacher.pages.ReportsViewerPage;
import com.savvas.sm.reports.smoke.teacher.pages.StudentPerformanceReport;
import com.savvas.sm.reports.ui.pages.AFGReportViewerPage;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CPAReportViewerPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

public class ExportPDFButttonDisableTests extends EnvProperties {

    AreaForGrowthPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    CumulativePerformanceReport cprPage;
    AreasForGrowthReport areasForGrowthReport;
    ReportsViewerPage reportViewerPage;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    String groupID;
    String teacherDetails;
    String browser;
    String username;
    String orgId;
    String teacherId;
    String student1;
    String studentUserName;
    String studentId;
    HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    HashMap<String, String> assignmentIds = new HashMap<>();
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    AreasForGrowthReport afgPage;
    LastSessionReport lsrPage;
    StudentPerformanceReport studentPerformanceReport;
    AFGReportViewerPage afgReportViewerPage;
    private String adminUsername;;
    private String districtAdminDetails = null;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        studentId = SMUtils.getKeyValueFromResponse( student1, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( student1, "userName" );
        adminUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        HashMap<String, String> groupDetail = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );

        groupID = SMUtils.getKeyValueFromResponse( groupDetail.get( Constants.REPORT_BODY ), "data,groupId" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        } catch ( Exception e1 ) {
            Log.message( "Issue in getting access token!!!.Retrying" );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        }

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentId ), Arrays.asList( "1", "2" ) );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher CPR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport001: Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher CPR<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            cprPage = (CumulativePerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.CUMULATIVE_PERFORMANCE );
            reportViewerPage = cprPage.validateCPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            reportViewerPage.launchURLWithWrongRequestID();
            Log.message( reportViewerPage.getPDFButtonDisabled() );
            Log.assertThat( reportViewerPage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher AFG", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport002: Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher AFG<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            afgPage = (AreasForGrowthReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.AREAS_FOR_GROWTH );
            reportViewerPage = afgPage.validateAFGTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );

            reportViewerPage.launchURLWithWrongRequestID();
            Log.message( reportViewerPage.getPDFButtonDisabled() );
            Log.assertThat( reportViewerPage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher LSR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport003:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher LSR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            lsrPage = (LastSessionReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.LAST_SESSION );
            reportViewerPage = lsrPage.validateLSTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            reportViewerPage.launchURLWithWrongRequestID();
            Log.message( reportViewerPage.getPDFButtonDisabled() );
            Log.assertThat( reportViewerPage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher SPR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport004:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher SPR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            areasForGrowthReport = smLoginPage.loginSMReportsAsTeacher( username, password );
            studentPerformanceReport = (StudentPerformanceReport) areasForGrowthReport.selectReportFromSideNavigation( driver, Reports.STUDENT_PERFORMANCE );
            reportViewerPage = studentPerformanceReport.validateSPRTeacherRunReport( driver );
            reportViewerPage.verifyReportPage( driver );
            reportViewerPage.launchURLWithWrongRequestID();
            Log.message( reportViewerPage.getPDFButtonDisabled() );
            Log.assertThat( reportViewerPage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin afg", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport005:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher SPR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage afgPage = smLoginPage.loginToSM( adminUsername, password );

            //To select the organization in the organization dropdown
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, school );

            //To select the Subject 
            afgPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );

            //To select the subject 
            afgPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //To click the run report button 
            afgReportViewerPage = afgPage.clickRunReportButton();

            afgReportViewerPage.launchURLWithWrongRequestID();
            Log.message( afgReportViewerPage.getPDFButtonDisabled() );
            Log.assertThat( afgReportViewerPage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.assertThat( afgReportViewerPage.getCSVButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "CSV button is showing disable mode when error message pops up", "CSV button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin LSR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport006:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher SPR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( adminUsername, password );

            //Navigate to LSR Page
            RecentSessionsPage lastSessionsPage = dashBoardPage.reportFilterComponent.clickOnLastSessionsPage();

            //Selecting required fields
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, school );
            lastSessionsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            lastSessionsPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            lastSessionOutpage.launchURLWithWrongRequestID();
            Log.message( lastSessionOutpage.getPDFButtonDisabled() );
            Log.assertThat( lastSessionOutpage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.assertThat( lastSessionOutpage.getCSVButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "CSV button is showing disable mode when error message pops up", "CSV button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin CPAR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport007:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher SPR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSMReports( adminUsername, password );

            CumulativePerformancePage CumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Selecting required fields
            CumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( school ) );
            CumulativePerformancePage.reportFilterComponent.clickResetButton();
            CumulativePerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, Constants.MATH );
            CumulativePerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );
            RecentSessionsPage lastSessionsPage = new RecentSessionsPage( driver );
            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            lastSessionOutpage.launchURLWithWrongRequestID();
            Log.message( lastSessionOutpage.getPDFButtonDisabled() );
            Log.assertThat( lastSessionOutpage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.assertThat( lastSessionOutpage.getCSVButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "CSV button is showing disable mode when error message pops up", "CSV button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin SPR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport008:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin SPR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( adminUsername, password );

            StudentPerformancePage StudentPerformancePage = dashBoardPage.reportFilterComponent.clickOnStudentPerformancePage();

            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, school );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            List<String> courses = StudentPerformancePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            StudentPerformancePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            RecentSessionsPage lastSessionsPage = new RecentSessionsPage( driver );
            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();

            lastSessionOutpage.launchURLWithWrongRequestID();
            Log.message( lastSessionOutpage.getPDFButtonDisabled() );
            Log.assertThat( lastSessionOutpage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.assertThat( lastSessionOutpage.getCSVButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "CSV button is showing disable mode when error message pops up", "CSV button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin CPR", groups = { "SMK-69993/SMK-68622 ", "Teacher Dashboard", "Export Reports", "" }, priority = 1 )
    public void tcDisabledExportPDFReport009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcDisabledExportPDFReport009:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for admin CPR <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( adminUsername, password );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage CPAReport = cumulativePerformancePage.navigateToCPAReport();

            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( school ) );
            CPAReport.reportFilterComponent.clickResetButton();
            CPAReport.reportFilterComponent.selectOptionsFromSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            CPAReport.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "Select All" ) );
            RecentSessionsPage lastSessionsPage = new RecentSessionsPage( driver );
            //Click Run Report button
            RecentSessionsOutputPage lastSessionOutpage = lastSessionsPage.clickRunBtn();
            lastSessionOutpage.launchURLWithWrongRequestID();
            Log.message( lastSessionOutpage.getPDFButtonDisabled() );
            Log.assertThat( lastSessionOutpage.getPDFButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.assertThat( lastSessionOutpage.getCSVButtonDisabled().contains( ReportsUIConstants.DISABLED_STATUS ), "CSV button is showing disable mode when error message pops up", "CSV button is not showing disable mode when error message pops up" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
