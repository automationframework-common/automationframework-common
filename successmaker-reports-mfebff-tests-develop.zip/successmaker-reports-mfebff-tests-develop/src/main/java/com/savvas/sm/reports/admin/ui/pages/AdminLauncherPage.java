package com.savvas.sm.reports.admin.ui.pages;

import static org.testng.AssertJUnit.assertTrue;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AdminLauncherPage extends LoadableComponent<AdminLauncherPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    WebDriver driver;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public ElementLayer elementLayer;
    private String smUrl;
    private String browser;

    // ********* SuccessMaker Launcher/Login Page Elements ***************
    @IFindBy ( how = How.ID, using = "launchButton", AI = false )
    WebElement smLaunchButton;

    @IFindBy ( how = How.ID, using = "username", AI = false )
    WebElement elementUsername;

    @IFindBy ( how = How.ID, using = "password", AI = false )
    WebElement elementPassword;

    @IFindBy ( how = How.CLASS_NAME, using = "btn-submit", AI = false )
    WebElement elementSignInButton;

    @IFindBy ( how = How.ID, using = "splashImg", AI = false )
    WebElement imgSuccessMaker;

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public AdminLauncherPage( WebDriver driver, String url ) {
        this.driver = driver;
        smUrl = url;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Override
    protected void isLoaded() {

        assertTrue( "HomePage is not loaded!", driver.getCurrentUrl().contains( smUrl ) );
        if ( SMUtils.waitForElement( driver, smLaunchButton ) ) {
            Log.message( "SM Pre-Login page loaded successfully!" );
        } else {
            Log.fail( "SM pre-login page did not load." );
        }
        elementLayer = new ElementLayer( driver );
    }

    @Override
    protected void load() {
        driver.get( smUrl );
        Log.message( "Hit the SM Instance Url - " + smUrl );
    }

    /***
     * Click Enter here to launch the SSO Login Page
     * 
     */
    private void launchSM() {
        try {
            SMUtils.waitForElement( driver, smLaunchButton, 15 );
            SMUtils.clickJS( driver, smLaunchButton );

            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 20 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 2 ) );

            SMUtils.switchWindow( driver );
            Log.message( "Enter Here in launcher Page is clicked Successfully" );
        } catch ( Exception e ) {
            Log.message( "Unable to click Enter Here button in Launcher Page" );
        }
    }

    /**
     * To enter the credentials in SM application
     * 
     * @param username
     * @param password
     */
    private void enterCredentials( String username, String password ) {
        try {

            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 30 ) );
            wait.until( ExpectedConditions.visibilityOf( elementUsername ) );
            elementUsername.clear();
            elementUsername.sendKeys( username );
            Log.event( "Entered userName - " + username );

            wait.until( ExpectedConditions.visibilityOf( elementPassword ) );
            elementPassword.clear();
            elementPassword.sendKeys( password );
            Log.event( "Entered Password - " + password );

            wait.until( ExpectedConditions.elementToBeClickable( elementSignInButton ) );
            SMUtils.clickJS( driver, elementSignInButton );
        } catch ( Exception e ) {
            Log.message( "Unable to login to the SM Application" );
        }

    }

    /**
     * @param adminUsername
     * @param adminPassword
     * @return AreasForGrowthPage
     * @throws InterruptedException
     */
    public AreaForGrowthPage loginSMReportsAsAdmin( String adminUsername, String adminPassword ) throws InterruptedException {
        launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        enterCredentials( adminUsername, adminPassword );
        SMUtils.nap( 5 );
        loadMFEAdminPage();
        SMUtils.waitForSpinnertoDisapper( driver );
        return new AreaForGrowthPage( driver ).get();
    }

    /**
     * To load MFE page
     *
     */
    private void loadMFEAdminPage() {
        try {
            driver.get( ReportsUIConstants.ADMIN_REPORT_MFE_URL );
            Log.message( "Admin report MFE page is loaded" );
        } catch ( Exception e ) {
            Log.message( "Admin report MFE page is loaded" );
        }
    }

}