package com.savvas.sm.reports.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.json.JSONObject;

public class JSONParserUtils {

	/**
	 * Used to read from JSON file
	 * @param filename - JSON file name
	 * @return json content in string format
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public static String readFileFromJsonFile(String filename) throws URISyntaxException, IOException {
	    StringWriter writer = new StringWriter();
	    IOUtils.copy(JSONParserUtils.class.getResourceAsStream("/mockjson/" +  filename), writer, StandardCharsets.UTF_8);
	    return writer.toString();  
	}

    public static JsonObject getJSONData(String data) {
        return JsonParser.parseString(data).getAsJsonObject();
    }

    public static JsonObject getJSONData(File data) throws Exception {
        return new Gson().fromJson(new BufferedReader(new FileReader(data)), JsonObject.class);
    }

    public static JsonObject getJsonObject(JsonObject jsonData, String key) {
        return jsonData.getAsJsonObject(key);
    }

    public static JsonObject getJsonObject(JsonArray jsonArray, int index) {
        return jsonArray.get(index).getAsJsonObject();
    }

    public static JsonArray getJsonArray(JsonObject jsonData, String key) {
        return jsonData.getAsJsonArray(key);
    }

    public static String getValue(JsonObject jsonData, String key) {
        return jsonData.get(key).getAsString();
    }

    public static List<String> getSearchTitles(String json) {
    	List<String> titles = new ArrayList<String>();
    	JsonArray contentList = JSONParserUtils.getJsonArray(JSONParserUtils.getJsonObject(JSONParserUtils.getJsonObject(JSONParserUtils.getJSONData(json), "data"), "getContentById"), "contentItems");
    	for(int i = 0; i < contentList.size(); i++) {
    		titles.add(i, JSONParserUtils.getValue(JSONParserUtils.getJsonObject(contentList, i), "title"));
    	}
    	return titles;
    }

    public static List<String> getSearchContent(String json) {
    	List<String> titles = new ArrayList<String>();
    	JsonArray contentList = JSONParserUtils.getJsonArray(JSONParserUtils.getJsonObject(JSONParserUtils.getJsonObject(JSONParserUtils.getJSONData(json), "data"), "getSearchResult"), "contents");
    	for(int i = 0; i < contentList.size(); i++) {
    		titles.add(i, JSONParserUtils.getValue(JSONParserUtils.getJsonObject(contentList, i), "title"));
    	}
    	return titles;
    }

	public static Map<String, Object> getJsonMapFromFile(String fileName) throws IOException{
		StringWriter writer = new StringWriter();
		IOUtils.copy(JSONParserUtils.class.getResourceAsStream("/testdata/schemaJson/" +  fileName), writer, StandardCharsets.UTF_8);
		JsonParser.parseString(writer.toString()).getAsJsonObject();
		return new ObjectMapper().readValue(writer.toString(), new TypeReference<Map<String, Object>>(){});
	}

	public static Map<String, Object> replaceValue( Map<String, Object> map, String key, Object value ) {
		if ( key.contains( "." ) ) {
			List<String> keyLst = Arrays.asList( key.split( "\\.", 2 ) );
			if(map.keySet().contains( keyLst.get( 0 ) )){
				replaceValue( (Map<String, Object>) map.get( keyLst.get( 0 ) ), keyLst.get( 1 ), value );
			}else{
				map.put( keyLst.get( 0 ),new HashMap<String, Object>());
				replaceValue( (Map<String, Object>) map.get( keyLst.get( 0 ) ), keyLst.get( 1 ), value );
			}
		} else {
			map.put( key, value );
		}
		return map;
	}

	public static String convertMapToJson(Map<String, Object> jsonMap){
		return new JSONObject(jsonMap).toString();
	}
}
