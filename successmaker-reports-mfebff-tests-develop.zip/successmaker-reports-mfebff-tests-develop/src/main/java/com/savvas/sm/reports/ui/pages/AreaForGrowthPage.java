package com.savvas.sm.reports.ui.pages;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.bff.admin.tests.LSRReportAdminGraphQLTest;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.reports.smoke.admin.pages.AreasForGrowthReport;
import com.savvas.sm.reports.smoke.admin.pages.ReportsFilterUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.FileUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import io.restassured.response.Response;

public class AreaForGrowthPage extends LoadableComponent<AreaForGrowthPage> {

    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    // ********* SuccessMaker Launcher/Login Page Elements ***************

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;

    // ********* SM - AFG Report Page Elements ***************

    /***************** POM for Page **************************/

    @FindBy ( css = "saved-report-options label" )
    WebElement saveReportOptionLabel;

    @FindBy ( tagName = "h1.report-heading" )
    WebElement pageTitle;

    @FindBy ( css = "cel-tab-panel.tab-panel" )
    WebElement toggleButton;

    @FindBy ( css = "p.description" )
    WebElement description;

    @FindBy ( css = ".layout-one>.layout-heading" )
    // @FindBy (css="div[class='card layouts layout-one'] div[class='layout-heading']")
    WebElement coursesWidgetTitle;

    @FindBy ( css = "cel-checkbox-item[class='hydrated']" )
    WebElement checkBoxParent;

    @FindBy ( css = "div.additional-filters-section cel-accordion-item" )
    WebElement studentDemographicsAccordionRoot;

    @FindBy ( css = "cel-platform-navbar[class='hydrated']" )
    WebElement topNavBarwithShadow;

    @FindBy ( css = "cel-side-navigation.side-nav-bar" )
    WebElement parentsidebarMenu;

    @FindBy ( css = "input#radioGroups" )
    WebElement groupsRadioBtn;

    @FindBy ( css = "input#radioStudents" )
    WebElement studentRadioBtn;

    @FindBy ( css = "cel-multi-select.hydrated" )
    WebElement celMultiSelect;

    @FindBy ( css = "nav-bar-item" )
    WebElement topNavBar;

    @FindBy ( css = "div.col-sm-9 > multi-select#assignments > cel-multi-select" )
    WebElement parentassignmentSelect;

    @FindBy ( css = "teacher-courses-filter>section>div" )
    WebElement courseSelectionHeader;

    //@FindBy ( css = "single-select#subject >div > cel-single-select.hydrated" )
    @FindBy ( css = "cel-single-select:nth-child(2)" )
    WebElement subjectDropdownparent;

    // @FindBy ( css = "multi-select[formcontrolname='groups'] > cel-multi-select" )
    @FindBy ( css = "cel-multi-select:nth-child(1)" )
    WebElement groupDropdownparent;

    @FindBy ( css = "cel-icon.contextual-help-icon" )
    WebElement helpIconlink;

    @FindBy ( css = "cel-modal.save-report-modal.hydrated" )
    WebElement parentSaveIconlink;

    @FindBy ( css = "h2.header" )
    WebElement reportHeader;

    @FindBy ( css = "span.pagination-text-prefix" )
    WebElement gotoPage;

    @FindBy ( css = "div.text-field-container" )
    WebElement userEnter;

    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportButtonRoot;

    @FindBy ( css = "[alt='successmaker']" )
    WebElement smLogo;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[1]/th[1]" )
    WebElement strandColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[1]/th[2]" )
    WebElement levelColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[1]/th[3]" )
    WebElement skillDescColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[2]/th[3]" )
    WebElement studentColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[2]/th[4]" )
    WebElement dateAtRiskColumn;

    @FindBy ( css = "cel-single-select.hydrated" )
    WebElement singleSelectDropDowns;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[2]/th[5]" )
    WebElement targettedLessonColumn;

    @FindBy ( xpath = "//table[@id='table']/tbody[1]/tr[2]/td[2]/div[1]" )
    WebElement dateFormat;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement btnNextRoot;

    @FindBy ( css = "cel-button.back-btn" )
    WebElement btnBackRoot;

    @FindBy ( css = "div.header-pagination span" )
    List<WebElement> paginationText;

    @FindBy ( css = "input.pagination-text-field" )
    WebElement currentPageNumber;

    @FindBy ( css = "div .col-3 .list-head" )
    List<WebElement> headerLegend;

    @FindBy ( css = "div .col-3 .list-info" )
    WebElement headerLegendValue;

    @FindBy ( css = "dl.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;

    @FindBy ( css = "dl.ml-3 dt" )
    WebElement headerReportRun;

    @FindBy ( css = "dl.info dt" )
    List<WebElement> headersRowInfo;

    @FindBy ( xpath = "//span[@class='error-message']/span[.='Invalid']" )
    WebElement invalidGoToPage;

    @FindBy ( xpath = "//div[@class='text-field-container']" )
    WebElement requiredGoToPage;

    @FindBy ( xpath = "//span[@class='pagination-text-suffix']" )
    WebElement totalNoOfPages;

    @FindBy ( xpath = "//p[@class='risk-label mr-20']//span[1]" )
    WebElement totalSkillsAtRisk;

    @FindBy ( xpath = "//p[@class='risk-label']//span[1]" )
    WebElement totalStudentsAtRisk;

    @FindBy ( css = "cel-icon-button.file.hydrated" )
    WebElement pdfButton;

    @FindBy ( css = " cel-icon-button.file-doc.hydrated" )
    WebElement docButton;

    @FindBy ( css = "td.skill-description" )
    List<WebElement> allSkillsDesc;

    @FindBy ( css = "div.section-risk p:nth-child(1)" )
    WebElement totalSkillsCount;

    @FindBy ( css = "div.section-risk p:nth-child(2) span" )
    WebElement totalAtRiskCount;

    @FindBy ( css = "tr.students td:nth-child(1)" )
    List<WebElement> distinctStudents;

    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement assignmentName;

    @FindBy ( css = "span.ml-2" )
    WebElement headerSelectedOptions;

    @FindBy ( css = "li:nth-of-type(1)" )
    WebElement noAdditionalGrouping;

    @FindBy ( css = "li:nth-of-type(2)" )
    WebElement sortByStrand;

    @FindBy ( css = "li:nth-of-type(3)" )
    WebElement showAllDatesAtRisk;

    @FindBy ( css = "li:nth-of-type(4)" )
    WebElement noOfGroupsSelected;

    @FindBy ( css = "p.header.mt-1.mb-1" )
    WebElement noDataToDisplay;

    @FindBy ( css = "cel-single-select.hydrated" )
    WebElement singleSelectRoot;

    @FindBy ( css = "div.report-body-wrapper cel-accordion-item" )
    WebElement optionalFilterRoot;

    @FindBy ( css = "div label" )
    List<WebElement> dropdownLabels;

    @FindBy ( css = "div.d-flex cel-button.pr-2" )
    WebElement runReportButton;
    
    @FindBy ( css = "report-grid td:nth-child(4)")
    List<WebElement> targettedLessonLink;
    
    @FindBy ( css = "report-grid td:nth-child(3)")
    List<WebElement> skillDescription;
    

    /**************** Child Elements *******************/

    public String fontFamily = "Poppins-SemiBold";
    private static String cprAggregateChild = "div.tab-container button.selected";

    private String button = ".button";

    private String selectedButton = "button.selected";
    public static String maskStudentCheckBoxCSS = "input[type='checkbox']";
    private String topNavReportsMenuCSSSelector = "#Reports";
    private String reportsMenuItemsCSSSelectorwithShadow = "cel-dropdown-menu-box.hydrated";
    //private String multiselectBoxChildCSSSelector = "div.multi-container>button.multi.row-between";
    private String multiselectBoxChildCSSSelector = "div.multi-container>div>button.multi.row-between";
    private String groupsSearchBoxCSSSelector = "div.multi-container div#dropdown cel-search-field.hydrated";
    private String groupsSearchPlaceholderChild = "div.search-field-container div>form>input.search-field";
    private String assignmentSelectchild = "div.multi-container > button.multi.row-between > span.label";
    //private String subjectDropdownchild = "div.single-container > button.single.row-between > span";
    private String subjectDropdownchild = "option[value='1']";
    private String readingSubjectDropdownchild = "option[value='2']";
    // private String groupDropdownchild = "div.multi-container > button.multi.row-between > span";
    private String groupDropdownchild = ".multi.row-between";
    private String saveIconchild = "cel-icon[data-name='question-circle']";

    private String childMultiCheckBox = "cel-multi-checkbox";
    private String childMultiCheckBoxItems = "cel-checkbox-item";
    private String grandChildCheckBoxLabel = "span.checkbox-label";
    private String inputCheckbox = "label";
    public String studentNameCSS = "#table > tbody > tr.areas-for-growth-row.students > td:nth-child(1) > div";

    @FindBy ( css = "cel-side-navigation[class='side-nav-bar hydrated']" )
    WebElement sideNavigationRoot;

    @FindBy ( xpath = "//span[text()='Report viewer']" )
    WebElement reportViewer;

    // ****Child Elements****
    private String childSubNavigationMenu = "cel-side-item[data-label='Areas For Growth']";
    private String childSubNavigationButton = "button";
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };

    private String singleSelectDropdownRoot = "cel-single-select.hydrated";
    private String multiSelectDropdownRoot = "cel-multi-select.hydrated";
    private String singleDropdownDropdownItem = "option";
	public Object reportComponents;

    /**
     *
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */
    public AreaForGrowthPage( WebDriver driver ) {
        this.driver = driver;
        this.reportFilterComponent = new ReportFilterComponent( driver );
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, description, 10 ) ) {
            Log.message( "Area For Growth Page loaded successfully." );
        } else {
            Log.fail( "Area For Growth Page not loaded successfully." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, description );

    }

    /**
     * To validate the AFG report option in Report Input Filter Page
     * 
     * @return
     */
    public boolean checkReportHeader() {
        try {
            WebElement heading = driver.findElement( By.cssSelector( "h1.report-heading" ) );
            return heading.getText().equals( AFGReportConstants.REPORT_HEADER_INPUT );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Header not found in Input Page" );
        }
        return false;
    }

    /**
     * To Click Run Report Button
     */
    public AreaForGrowthOutputPage clickRunBtn() {
        SMUtils.waitForElement( driver, runReportButtonRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, runReportButtonRoot, button ) );
        Log.message( "Clicked RUN button in Report Input page" );
        return new AreaForGrowthOutputPage( driver ).get();
    }

    /**
     * Checks and returns the visibility state of Courses Widget
     *
     * @return
     */
    public boolean isCoursesWidgetDisplayed() {
        new WebDriverWait( driver, Duration.ofSeconds( 30 ) ).until( ExpectedConditions.visibilityOfAllElements( coursesWidgetTitle ) );
        SMUtils.waitForElement( driver, coursesWidgetTitle );
        SMUtils.fluentWaitForElement( driver, coursesWidgetTitle );
        return coursesWidgetTitle.isDisplayed();
    }

    /***
     * Navigate to Reports Tab
     *
     * @return
     */
    public void navigateToReports() {
        SMUtils.waitForElement( driver, topNavBar );
        WebElement Reports = SMUtils.getWebElementDirect( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        SMUtils.clickJS( driver, Reports );
        Log.message( "Navigate to the Reports Page" );
        SMUtils.nap( 2 ); // page to be loaded

    }

    /***
     * Verify Groups Radio Btn
     * 
     * @return
     */
    public boolean verifyGroupsBtnSelected() {
        Log.message( "Verifying Groups Radio Button Status" );
        SMUtils.waitForElement( driver, groupsRadioBtn );
        boolean status = groupsRadioBtn.isSelected();
        return status;

    }

    /***
     * Click on Students Radio Btn
     * 
     * @return
     */
    public void checkStudntRadioBtn() {
        SMUtils.waitForElement( driver, studentRadioBtn );
        SMUtils.clickJS( driver, studentRadioBtn );
        Log.message( "Clicked Studnets Radio Button" );

    }

    /***
     * Verify Studnets Multiselect Box
     *
     * @return
     */
    public void verifyStudnetMultiSelect() {
        SMUtils.waitForElement( driver, celMultiSelect );
        WebElement studnetsBtn = SMUtils.getWebElementDirect( driver, celMultiSelect, multiselectBoxChildCSSSelector );
        SMUtils.clickJS( driver, studnetsBtn );
        Log.message( "Clicked on studnets select box" );

    }

    /***
     * Verify Students Search View Box
     *
     * @return
     */
    public boolean verifyStudentsSearchBox() {
        SMUtils.waitForElement( driver, celMultiSelect );
        WebElement studentSearchBoxParent = SMUtils.getWebElementDirect( driver, celMultiSelect, groupsSearchBoxCSSSelector );
        WebElement studentSearchBox = SMUtils.getWebElementDirect( driver, studentSearchBoxParent, groupsSearchPlaceholderChild );
        boolean status = studentSearchBox.isDisplayed();
        Log.message( "Student Search box is present" );
        return status;

    }

    /***
     * Verify Groups Multiselect Box
     *
     * @return
     */
    public void verifyGroupsMultiSelect() {
        WebElement groupsBtn = SMUtils.getWebElementDirect( driver, celMultiSelect, multiselectBoxChildCSSSelector );
        SMUtils.clickJS( driver, groupsBtn );
        Log.message( "Clicked on groups multiselect box" );

    }

    /***
     * Verify Student Multiselect Box
     *
     * @return
     */
    public void verifyStudentMultiSelect() {
        WebElement groupsBtn = SMUtils.getWebElementDirect( driver, celMultiSelect, multiselectBoxChildCSSSelector );
        SMUtils.clickJS( driver, groupsBtn );
        Log.message( "Clicked on Student multiselect box" );

    }

    /***
     * Verify Groups Search View Box
     *
     * @return
     */
    public boolean verifyGroupsSearchBox() {
        WebElement groupsSearchBoxParent = SMUtils.getWebElementDirect( driver, celMultiSelect, groupsSearchBoxCSSSelector );
        WebElement groupsSearchBox = SMUtils.getWebElementDirect( driver, groupsSearchBoxParent, groupsSearchPlaceholderChild );
        boolean status = groupsSearchBox.isDisplayed();
        Log.message( "Groups Search box is present" );
        return status;
    }

    /**
     * To Click RunReport Button
     * 
     * @return
     */
    public AFGReportViewerPage clickRunReportButton() {
        try {

            WebElement webElementDirect = SMUtils.getWebElementDirect( driver, runReportButton, button );
            SMUtils.clickJS( driver, webElementDirect );
            Log.message( "Clicked Run report Button" );

            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 120 ) );

            WebDriverWait wait1 = new WebDriverWait( driver, Duration.ofSeconds( 80 ) );
            wait1.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );

            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Unable to click the run report button!!!" );
        }
        return new AFGReportViewerPage( driver ).get();
    }

    /**
     * To verify the sub navigation is selected or not
     * 
     * @return
     */

    public boolean isAFGReportSelected() {
        // TODO Auto-generated method stub
        Log.message( "Verifing  Areas For Growth Report is selected" );
        return SMUtils.getWebElementDirect( driver, toggleButton, selectedButton ).getText().trim().equalsIgnoreCase( ReportTypes.AREAS_FOR_GROWTH );

    }

    /**
     * Get text for AFG Report
     * 
     * @return
     */
    public String getAFGReportHeaderText() {

        SMUtils.waitForElement( driver, pageTitle );
        Log.message( "Get AGF Report Header text" );
        return pageTitle.getText().trim();
    }

    /**
     * click check box Mask Student CheckBox
     */
    public void clickMaskStudentCheckBox() {
        SMUtils.waitForElement( driver, checkBoxParent, 10 );
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }

    public boolean isAFGSubNavigationSelected() {
        Log.message( "Verifing Recent Session Sub navigation is selected" );
        WebElement rootElement = SMUtils.getWebElement( driver, sideNavigationRoot, childSubNavigationMenu );
        WebElement recentSessionSubNav = SMUtils.getWebElement( driver, rootElement, childSubNavigationButton );
        return recentSessionSubNav.getAttribute( "class" ).contains( "side-item side-item-active" );
    }

    /**
     * Mask student selected or not validation
     * 
     * @return
     */
    public Boolean isMaskStudentSelected() {
        //SMUtils.waitForElement( driver, studentDemographicsAccordionRoot );
        //SMUtils.scrollIntoView( driver, studentDemographicsAccordionRoot );
        SMUtils.waitForElement( driver, checkBoxParent, 10 );
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        Log.message( "Is Mask student selected" );
        return element.isSelected();
    }

    /**
     * To get all Selected Filters in AFG Report Page
     * 
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAllSelectedFilters() throws Exception {

        SMUtils.nap( 0.6 ); // It is required to load all element after saving report

        HashMap<String, String> selectedFilters = new HashMap<String, String>();
        selectedFilters.put( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, this.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ) );
        selectedFilters.put( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, this.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ) );
        selectedFilters.put( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ) );
        selectedFilters.put( ReportsUIConstants.DISPLAY_LABEL, this.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.DISPLAY_LABEL ) );
        selectedFilters.put( ReportsUIConstants.SORT_LABEL, this.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.SORT_LABEL ) );
        selectedFilters.put( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, this.reportFilterComponent.getPlaceHolderFromSingleSelectSubjectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ) );
        selectedFilters.put( ReportsUIConstants.DISABILITY_STATUS, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ) );
        selectedFilters.put( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ) );
        selectedFilters.put( ReportsUIConstants.ETHNICITY, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ) );
        selectedFilters.put( ReportsUIConstants.MIGRANT_STATUS, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ) );
        selectedFilters.put( ReportsUIConstants.RACE, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ) );
        selectedFilters.put( ReportsUIConstants.SPECIAL_SERVICES, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ) );
        selectedFilters.put( ReportsUIConstants.SOCIOECONOMIC_STATUS, this.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ) );

        if ( isMaskStudentSelected() )
            selectedFilters.put( ReportsUIConstants.MASK_STUDENT_DISPLAY, "Checked" );
        else
            selectedFilters.put( ReportsUIConstants.MASK_STUDENT_DISPLAY, "unchecked" );

        return selectedFilters;
    }

    /***
     * Assignment Selectes as Default
     * 
     * @return
     */
    public boolean isAssignmentDefaultSelected() {
        SMUtils.waitForElement( driver, parentassignmentSelect );
        WebElement assignmentSelect = SMUtils.getWebElementDirect( driver, parentassignmentSelect, assignmentSelectchild );
        String assignmentSelected = assignmentSelect.getText();
        return assignmentSelected.contains( "Selected" );

    }

    public String getCourseSelectionHeader() {
        SMUtils.waitForElement( driver, courseSelectionHeader, 10 );
        return courseSelectionHeader.getText();
    }

    public String getSubjectDefaultSelected() {
        WebElement defaultSubject = SMUtils.getWebElementDirect( driver, subjectDropdownparent, subjectDropdownchild );
        return defaultSubject.getText();
    }

    public String getReadingSubjectDefaultSelected() {
        WebElement defaultSubject = SMUtils.getWebElementDirect( driver, subjectDropdownparent, readingSubjectDropdownchild );
        return defaultSubject.getText();
    }

    public String getGroupDefaultSelected() {
        WebElement defaultSubject = SMUtils.getWebElementDirect( driver, groupDropdownparent, groupDropdownchild );
        System.out.println( defaultSubject.getText() );
        return defaultSubject.getText().trim();
    }

    /***
     * Click Help Icon
     * 
     * @return
     */
    public void clickHelpIcon() {
        // WebElement helpIcon = SMUtils.getWebElementDirect( driver, helpIconlink, helpIconchild );
        SMUtils.clickJS( driver, helpIconlink );
        Log.message( "Navigate to the Help Page" );
        SMUtils.nap( 3 ); // page to be loaded

    }

    /***
     * Verify question mark
     * 
     * @return
     */
    public boolean isdisplayedQuestionmark() {
        WebElement saveIcon = SMUtils.getWebElementDirect( driver, parentSaveIconlink, saveIconchild );
        boolean questionMark = saveIcon.isDisplayed();
        return questionMark;
        // page to be loaded

    }

    /***
     * Click Save Icon
     * 
     * @return
     */
    public void clickQuestionIcon() {
        WebElement saveIcon = SMUtils.getWebElementDirect( driver, parentSaveIconlink, saveIconchild );
        SMUtils.clickJS( driver, saveIcon );
        Log.message( "Navigate to the Save Reports Page" );
        SMUtils.nap( 3 ); // page to be loaded

    }

    public String getReportPageTitle() {
        Log.message( "Getting Areas For Growth Report page Title" );
        SMUtils.waitForElement( driver, reportHeader );
        return reportHeader.getText().trim();
    }

    public String getGoToPageTitile() {
        Log.message( "Getting Go To Text Box page Title" );
        SMUtils.waitForElement( driver, gotoPage );
        return gotoPage.getText().trim();
    }

    public String getTextBox() {
        Log.message( "Getting User Enter Text Box" );
        SMUtils.waitForElement( driver, userEnter );
        return userEnter.getText().trim();
    }

    public String getCurrentPageNumber() {
        Log.message( "Getting Current Page Number" );
        SMUtils.waitForElement( driver, currentPageNumber );
        Log.message( "Page number" + currentPageNumber.getText().trim() );
        return currentPageNumber.getAttribute( "value" );
    }

    /**
     * To select options in multi-select dropdown
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void selectOptionsFromMultiSelectDropdown( String dropdownName, List<String> options ) throws InterruptedException {
        expandMultiSelectDropdown( dropdownName );
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        SMUtils.getWebElementsDirect( driver, SMUtils.getWebElementDirect( driver, parentRoot, childMultiCheckBox ), childMultiCheckBoxItems ).stream().filter(
                element -> options.contains( SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() ) ).forEach( element -> {
                    SMUtils.scrollIntoView( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element, inputCheckbox ) );
                    Log.message( "Selected Option in " + dropdownName + " - " + SMUtils.getWebElementDirect( driver, element, grandChildCheckBoxLabel ).getText().trim() );
                } );
    }

    /***
     * To get current page number
     * 
     * @return
     */
    public int totalPageNo() {
        Log.message( "Verifying total page" );
        SMUtils.waitForElement( driver, currentPageNumber );
        String totalPage = SMUtils.getTextOfWebElement( paginationText.get( 1 ), driver ).split( " " )[1];
        int totalpageno = Integer.parseInt( totalPage );
        Log.message( "totalpageno=" + totalpageno );
        Log.message( "Verify the 'Go to' text box and page number in the report viewer page.!!!" );
        SMUtils.nap( 5 );
        return totalpageno;
    }

    /**
     * This method is used to enter the page number and navigate to that page
     * 
     * @param pageNumber
     * @return
     */
    public boolean goToPage( int pageNumber ) {
        Log.message( "Navigating to the given page number" );
        SMUtils.waitForElement( driver, currentPageNumber );
        currentPageNumber.clear();
        currentPageNumber.sendKeys( String.valueOf( pageNumber ) );
        currentPageNumber.sendKeys( Keys.ENTER );
        SMUtils.nap( 2 );
        currentPageNumber.sendKeys( Keys.ENTER );
        return getCurrentPageNumber().equals( String.valueOf( pageNumber ) );
    }

    /**
     * To get the root Element for single-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForSingleSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );
    }

    /**
     * Expand the single-select drop-down
     * 
     * @param dropdownName
     */
    public void expandSingleSelectDropdown( String dropdownName ) {
        if ( isSingleSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded" + dropdownName + "drop-down" );
        }
    }

    /**
     * Expand the multi-select drop-down
     * 
     * @param dropdownName
     * @throws InterruptedException
     */
    public void expandMultiSelectDropdown( String dropdownName ) {
        if ( isMultiSelectDropdownCollapsed( dropdownName ) ) {
            WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
            SMUtils.scrollDownIntoViewElement( driver, parentRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentRoot, button ) );
            Log.message( "Expanded " + dropdownName + "drop-down" );
        }
    }

    /**
     * To get the root Element for multi-select dropdown
     * 
     * @param dropdownName
     * @return
     */
    public WebElement getRootElementForMultiSelectDropdown( String dropdownName ) {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( multiSelectDropdownRoot ) );
    }

    /**
     * To verify the multi-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isMultiSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForMultiSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, childMultiCheckBox ).isEmpty();
    }

    /**
     * To verify the single-select dropdown is collapsed or not
     * 
     * @param dropdownName
     * @return
     */
    public boolean isSingleSelectDropdownCollapsed( String dropdownName ) {
        WebElement parentRoot = getRootElementForSingleSelectDropdown( dropdownName );
        return SMUtils.getWebElements( driver, parentRoot, singleDropdownDropdownItem ).isEmpty();
    }

    /**
     * Verify whether Run Button is enabled or not
     * 
     * @return
     * @throws InterruptedException
     */
    public boolean isRunButtonEnabled() {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, runReportButton, 3 );
            return SMUtils.getWebElementDirect( driver, runReportButton, button ).isEnabled();
        } catch ( Exception e ) {
            return false;
        }
    }
    /**
     * @author sakthi.sasi Used to perform Organization choosing
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public AreaForGrowthPage chooseOrganization( WebDriver driver, String orgId ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.nap( 5 );
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, drpOrganizationOptions[0], drpOrganizationOptions[1] );
        drpdwnElement.click();
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelectValue( driver, drpdwnElement, orgId, "Choosing Organization" );
        return this;
    }
    
    /**
     * To Read the Json Response from mockjson folder
     * 
     * @param fileName
     * @return
     * @throws IOException
     */
    public String readJsonResponse(String fileName) throws IOException {
        String filePath = new File(".").getCanonicalPath() + File.separator + "src" + File.separator + "main"
                + File.separator + "resources" + File.separator + "mockJson" + File.separator + fileName;
        return FileUtil.readTextFile(filePath);
    }
    
    public Response postAFGBFF( String payload, String teacherUserId, String orgId,  String teacherUsername) throws IOException {
        HashMap<String, String> headers = new HashMap<>();
        Response response;
        
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        headers.put( "user-id", teacherUserId );
        headers.put( "org-id", orgId );
        
        response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_AFG_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
        Log.message( "Response: " + response );
        Log.message(  "ResponsetoString: " + response.getBody().asString() );
        return response;
    }
    
    
    /**
     * To get data from given response for MFE Integration
     * 
     * @param responseBody
     * @param studentRumbaId
     * @param mathAssignmentUserId
     * @param readingAssignmentUserId
     * @return
     */
    public Map<String, Map<String, String>> getAFGDataFromResponse( String response, String assignmentName, String subject ) {
        Map<String, Map<String, String>> SkillDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), "getAFGReportData" ) ).getJSONArray("assignmentRow" );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                skillDetails.put( AFGReportConstants.STRAND, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_NAME ) );
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                Log.message( "SkillDetails: " + skillDetails );
                SkillDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), skillDetails );
            } );

        } );
        return SkillDetailFromResponse;
    }
    
    
    /**
     * To get the student details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, List<String>> getstudentsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, List<String>> studentDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), "getAFGReportData") ).getJSONArray( "assignmentRow" );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.stream().forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                Log.message( "SkillDetails: " + skillDetails );
                List<String> students = new ArrayList<>();
                JSONArray stduentArray = new JSONObject( skillDetail.toString() ).getJSONArray( AFGReportConstants.STUDENT_ROWS );
                List<String> studentDetailList = new ArrayList<>();
                IntStream.range( 0, stduentArray.length() ).forEach( itr -> studentDetailList.add( stduentArray.get( itr ).toString() ) );

                studentDetailList.stream().forEach( student -> {
                    String[] dateArray = SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.FAILED_DATE ).substring( 0, 10 ).split( "-" );
                    String dateAtRisk = dateArray[1] + "/" + dateArray[2] + "/" + dateArray[0];
                    students.add( SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.STUDENT_NAME ) + " - " + dateAtRisk );
                } );

                studentDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), students );
                Log.message( "studentDetailFromResponse: " + studentDetailFromResponse );
            } );

        } );
        return studentDetailFromResponse;
    }


}