package com.savvas.sm.reports.ui.pages;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportSubHeader;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.IFindBy;

public class AFGReportViewerPage extends LoadableComponent<AFGReportViewerPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportOutputComponent reportOutputComponent;

    @FindBy ( css = "h2.header" )
    WebElement reportHeader;

    @FindBy ( css = "tr.header th" )
    List<WebElement> columnHeaders;

    @FindBy ( css = "tr.sub-header th" )
    List<WebElement> columnSubHeaders;

    @FindBy ( css = "tbody tr.areas-for-growth-row " )
    List<WebElement> gridValues;

    @FindBy ( css = "div p.header" )
    WebElement zeroState;

    @FindBy ( css = "div.pl-0 .list-head" )
    WebElement headerLegend;

    @FindBy ( css = "dl.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement mathTxt;

    @FindBy ( xpath = "//dd" )
    WebElement dateTxt;

    @FindBy ( css = "dl.detail-row.info" )
    WebElement districtTxt;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;

    @FindBy ( css = "p.risk-label" )
    List<WebElement> totalSkillsAndStudentsAtRisk;

    @FindBy ( css = "span.list-head.ml-2" )
    WebElement selectedOptionTxt;

    @FindBy ( css = "ul.selected-options li" )
    List<WebElement> selectedOptions;

    @FindBy ( css = "dl.detail-row.legends" )
    List<WebElement> legendOptions;

    @FindBy ( css = "dl.detail-row.info dt:nth-child(3)" )
    WebElement gradeTxt;

    @FindBy ( css = "section.report-sub-header" )
    WebElement subHeader;

    @FindBy ( css = "table.areas-for-growth" )
    WebElement reportTable;

    @FindBy ( css = "span.pagination-text-suffix" )
    WebElement totalPageCount;

    @FindBy ( css = "h3.assignment-name" )
    WebElement assignmentName;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement nextBtnRoot;

    @FindBy ( css = "dl.info dd" )
    List<WebElement> subHeaderFieldValues;

    @FindBy ( css = "tbody tr.students td:nth-of-type(1)" )
    List<WebElement> studentNames;

    @FindBy ( css = "tbody tr.last-student td:nth-of-type(1)" )
    List<WebElement> rowValues;

    @FindBy ( css = "demographic-details dd" )
    List<WebElement> demographicValues;

    @FindBy ( css = "demographic-details dt" )
    List<WebElement> demographicFilters;

    @FindBy ( css = "div.section-risk p.mr-20 :nth-child(1)" )
    WebElement skilText;

    @IFindBy ( how = How.CSS, using = "div.error p.header", AI = false )
    WebElement errorMessage;

    @FindBy ( css = "export-pdf-modal cel-modal.export-pdf-modal" )
    WebElement exportPDFs;
    
    @FindBy ( css = "export-data-modal cel-modal.export-data-modal" )
    WebElement exportCSV;
    
    /************************** Child Elements *******************************/

    String tabledata = "td";
    String button = "button.button";
    String columnValue = "td:nth-of-type(%s)";
    public static String childPDF = "cel-button";
    public static String gChildPDF = "cel-icon";
    public static String gGrandChildPDF = "svg";
    

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public AFGReportViewerPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportOutputComponent = new ReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, reportHeader );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, reportHeader, 30 ) ) {
            Log.message( "Area For Growth report viewer Page loaded successfully." );
        } else {
            Log.fail( "Area For Growth Page report viewer not loaded successfully." );
        }

    }

    /**
     * To get the column headers
     * 
     * @return
     */
    public List<String> getColumnHeaders() {

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( columnHeaders ) );
        Log.message( "Getting all the column headers..." );
        return SMUtils.getAllTextFromWebElementList( columnHeaders );
    }

    /**
     * To get the column sub-headers
     * 
     * @return
     */
    public List<String> getColumnSubHeaders() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( columnSubHeaders ) );
        Log.message( "Getting all the column headers..." );
        return SMUtils.getAllTextFromWebElementList( columnSubHeaders );
    }

    /**
     * @return
     */
    public Map<String, Map<String, String>> getSkillsDetails() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( columnSubHeaders ) );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();
        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();
            if ( row.getAttribute( "class" ).contains( "skills" ) ) {
                gridValue.put( AFGReportConstants.STRAND, columnData.get( 0 ).getText().trim() );
                gridValue.put( AFGReportConstants.LEVEL, columnData.get( 1 ).getText().trim() );
                gridValue.put( AFGReportConstants.SKILL_DESCRIPTION, columnData.get( 2 ).getText().trim() );
                gridValue.put( AFGReportConstants.TARGETED_LESSON, columnData.get( 3 ).getText().trim() );
                allGridValues.put( gridValue.get( AFGReportConstants.LEVEL ) + "-" + gridValue.get( AFGReportConstants.SKILL_DESCRIPTION ), gridValue );
            }
        } );
        return allGridValues;
    }

    /**
     * To get all the grid values
     * 
     * 
     * @return
     */
    public Map<String, List<String>> getStudentDetails() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( columnSubHeaders ) );
        Map<String, List<String>> studentDetails = new HashMap<>();
        Map<String, String> gridValue = new HashMap<>();
        List<String> student = new ArrayList<>();
        for ( WebElement row : gridValues ) {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            if ( row.getAttribute( "class" ).contains( "skills" ) ) {
                gridValue.put( AFGReportConstants.LEVEL, columnData.get( 1 ).getText().trim() );
                gridValue.put( AFGReportConstants.SKILL_DESCRIPTION, columnData.get( 2 ).getText().trim() );

            } else if ( row.getAttribute( "class" ).contains( "students" ) ) {
                student.add( columnData.get( 0 ).getText().trim() + " - " + columnData.get( 1 ).getText().trim() );
                if ( row.getAttribute( "class" ).contains( "last-student" ) ) {
                    studentDetails.put( gridValue.get( AFGReportConstants.LEVEL ) + "-" + gridValue.get( AFGReportConstants.SKILL_DESCRIPTION ), student );
                    student = new ArrayList<>();
                }
            }
        }
        return studentDetails;
    }

    /**
     * To get the Zero State message
     * 
     * @return
     */
    public String getZeroStateMessage() {
        SMUtils.waitForElement( driver, zeroState );
        return zeroState.getText().trim();
    }

    /**
     * Get Subject label
     * 
     * @return
     */
    public String getSubjectLabel() {
        SMUtils.waitForElement( driver, mathTxt, 30 );
        String reportWebElement = SMUtils.getTextOfWebElement( mathTxt, driver );
        Log.message( "Get subject label text" );
        return reportWebElement;
    }

    /**
     * Get Date label
     * 
     * @return
     */
    public String getDateLabel() {
        String timeZoneWebElement = SMUtils.getTextOfWebElement( dateTxt, driver ).substring( 0, 8 );
        Log.message( "Get date label text" );
        return timeZoneWebElement;
    }

    /**
     * Get Selected options
     * 
     * @return
     */
    public String getSelectedOptionLabel() {
        String textOfWebElement = SMUtils.getTextOfWebElement( selectedOptionTxt, driver );
        Log.message( "Get selected options label text" );
        return textOfWebElement;
    }

    /**
     * Get Selected option
     * 
     * @return
     */
    public List<String> getSelectedOptionsLegend() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( selectedOptions ) );
        Log.message( "Getting the all the selectced options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( selectedOptions );
        return allTextFromWebElementList;

    }

    /**
     * Get Legends options
     * 
     * @return
     */
    public List<String> getLegendOptions() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( legendOptions ) );
        Log.message( "Getting the all the legend options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( legendOptions );
        return allTextFromWebElementList;
    }

    /**
     * To get all Student Name
     * 
     * 
     * @return
     */
    public List<String> getStudentNameDetails() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( columnSubHeaders ) );
        List<String> student = new ArrayList<>();
        for ( WebElement row : gridValues ) {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            if ( row.getAttribute( "class" ).contains( "skills" ) ) {
                if ( row.getAttribute( "class" ).contains( "students" ) ) {
                    student.add( columnData.get( 0 ).getText().trim() + " - " + columnData.get( 1 ).getText().trim() );
                }
            }
        }
        return student;
    }

    /**
     * To get District label
     * 
     * @return
     */

    public String getDistrictLabel() {
        String districtWebElement = SMUtils.getTextOfWebElement( districtTxt, driver );
        return districtWebElement;
    }

    /**
     * To get Date and Time
     * 
     * @return
     */
    public String dateAndTime() {
        SimpleDateFormat formatter = new SimpleDateFormat( "MM/dd/yy" );
        Date date = new Date();
        return formatter.format( date );

    }

    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabels() {
        Log.message( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = true;
        if ( SMUtils.waitForElement( driver, headerLegend ) ) {
            Log.assertThat( SMUtils.getTextOfWebElement( headerLegend, driver ).equals( ReportsUIConstants.LEGEND_HEADER ), "Legend header is displayed successfully!!!", "Legend header is not displayed" );
            Log.assertThat( IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS.get( itr ) ) ), "All the labels of the legend are displayed",
                    "All the labels of the legend are not displayed" );
            Log.assertThat( IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_VALUES.get( itr ) ) ),
                    "All the label values of the legend are displayed", "All the label values of the legend are not displayed" );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }

    /**
     * To verify the total at risk label values
     * 
     * @return
     */
    public String getTotalSkillAtRiskValues() {
        String districtWebElement = SMUtils.getTextOfWebElement( totalSkillsAndStudentsAtRisk.get( 0 ), driver );
        return districtWebElement;
    }

    /**
     * To verify the total at risk label values
     * 
     * @return
     */
    public String getTotalStudentsAtRiskValues() {
        String districtWebElement = SMUtils.getTextOfWebElement( totalSkillsAndStudentsAtRisk.get( 1 ), driver );
        return districtWebElement;
    }

    /**
     * To check the visibility of sub header
     * 
     * @return
     */
    public boolean isSubHeaderDisplayed() {
        SMUtils.waitForElement( driver, subHeader );
        return subHeader.isDisplayed();
    }

    /**
     * To get assignment names
     * 
     * @return
     * @throws InterruptedException
     */
    public List<String> getAssignmentName() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        List<String> assignmentNameList = new ArrayList<>();
        IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
            assignmentNameList.add( assignmentName.getText().trim() );
            WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
            if ( nextBtn.isEnabled() ) {
                SMUtils.click( driver, nextBtn );
            }
        } );
        return assignmentNameList;
    }

    /**
     * To get Sub Header filed values
     * 
     * @param value
     * @return
     * @throws InterruptedException
     */
    public List<String> getSubHeaderValues( ReportSubHeader value ) {
        List<String> subHeaderValues = new ArrayList<>();
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, reportTable, 10 );
            SMUtils.waitForElement( driver, reportHeader );
            IntStream.rangeClosed( 1, Integer.parseInt( totalPageCount.getText().trim().split( " " )[1] ) ).forEach( itr -> {
                subHeaderValues.add( subHeaderFieldValues.get( value.ordinal() ).getText().trim() );
                WebElement nextBtn = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
                if ( nextBtn.isEnabled() ) {
                    SMUtils.click( driver, nextBtn );
                }
            } );
        } catch ( InterruptedException e ) {
            e.printStackTrace();
        }
        return subHeaderValues;
    }

    /**
     * To get Student names
     * 
     * @return
     * @throws InterruptedException
     */
    public List<String> getStudentNames() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable );
        return studentNames.stream().map( name -> name.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get UI grid values
     * 
     * @return
     */
    public boolean sortAndCompareColumnvalues( String columnName ) {
        SMUtils.waitForElement( driver, reportTable );
        List<String> columnValueList = new ArrayList<>();

        rowValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( String.format( columnValue, ReportsUIConstants.AFG_SORT.indexOf( columnName ) + 1 ) ) );
            IntStream.range( 0, columnData.size() ).forEach( itr -> columnValueList.add( columnData.get( itr ).getText().trim() ) );
        } );
        return columnValueList.stream().sorted( String.CASE_INSENSITIVE_ORDER ).collect( Collectors.toList() ).equals( columnValueList );
    }

    /**
     * To verify demographic filter values
     * 
     * @param demographicName
     * @param selectedDemographics
     * @return
     * @throws InterruptedException
     */
    public boolean verifyDemographicValues( String demographicName, List<String> selectedDemographics ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable );
        List<String> demographicFilter = demographicFilters.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
        String[] split = demographicValues.get( demographicFilter.indexOf( demographicName + ":" ) ).getText().trim().split( ", " );
        boolean allMatch = IntStream.range( 0, split.length ).allMatch( itr -> selectedDemographics.get( itr ).equals( split[itr] ) );
        return allMatch;
    }

    /**
     * To get Selected Option text
     * 
     * @param value
     * @return
     * @throws InterruptedException
     */
    public List<String> getSelectedOptions() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 10 );
        return selectedOptions.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * Get student at risk count
     * 
     * @return
     */
    public String getSkillRiskText() {
        Log.message( "Get Students At Risk count" );
        SMUtils.waitForElement( driver, skilText );
        return skilText.getText().trim();

    }

    public boolean nextButtonIsDisable() {
        SMUtils.waitForElement( driver, reportTable );
        WebElement nextButton = SMUtils.getWebElementDirect( driver, nextBtnRoot, button );
        return nextButton.isEnabled();

    }

    /**
     * Get current URL for report viewer page
     * 
     * @return
     */
    public String getReportViewerURL() {

        String URL = driver.getCurrentUrl();
        String actualURL = URL + System.nanoTime();
        Log.message( "Getting URL for report viewr page" );
        return actualURL;
    }

    /**
     * Launching report viewr page again
     */
    public void launchURLWithWrongRequestID() {

        SMUtils.nap( 2 );// This wait is required to load report viewr page
        String launchingURL = getReportViewerURL();
        Log.message( "Launching URL again after adding wrong request ID in URL" );
        driver.navigate().to( launchingURL );

    }

    /**
     * Getting status of PDF button when error message pops up
     * 
     * @return
     */
    public String getPDFButtonDisabled() {

        SMUtils.waitForElement( driver, exportPDFs );
        String attributeValue = exportPDFs.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }
    
    /**
     * Getting status of CSV button when error message pops up
     * 
     * @return
     */
    public String getCSVButtonDisabled() {

        SMUtils.waitForElement( driver, exportCSV );
        String attributeValue = exportCSV.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }
    
    
    /**
     * To get the AFF Data values from the report output UI
     * @return
     */
    public Map<String, Map<String, String>> getAFGSkillsDetails() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( columnSubHeaders ) );
        Map<String, Map<String, String>> allGridValues = new HashMap<>();
        gridValues.stream().forEach( row -> {
            List<WebElement> columnData = row.findElements( By.cssSelector( tabledata ) );
            Map<String, String> gridValue = new HashMap<>();
            if ( row.getAttribute( "class" ).contains( "skills" ) ) {
                gridValue.put( AFGReportConstants.STRAND, columnData.get( 0 ).getText().trim() );
                gridValue.put( AFGReportConstants.LEVEL, columnData.get( 1 ).getText().trim() );
                gridValue.put( AFGReportConstants.SKILL_DESCRIPTION, columnData.get( 2 ).getText().trim() );
                allGridValues.put( gridValue.get( AFGReportConstants.LEVEL ) + "-" + gridValue.get( AFGReportConstants.SKILL_DESCRIPTION ), gridValue );
            }
        } );
        return allGridValues;
    }
    
}