package com.savvas.sm.reports.api.report;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import io.restassured.response.Response;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class SPReportAdminGraphQLTest extends UserAPI {
    @Test ( dataProvider = "getData", groups = { "SMK-65180 Student Performance Report: Admin - Create GraphQL API", "API" }, priority = 1 )
    public void testSPRepostAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, String> queryItem = new HashMap<>();


        String payload = getPayload();
        String query;
        Response response = null;
        String responseStatusCode = "";
        String orgId = "8a72042d81a3e1270181c53f3006007f";
        String userId = "ffffffff62c315d380cd3d002fee6e79";
        String targetDate = "";
        switch ( scenarioType ) {
            case "VALID_SCENARIO":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "WITHOUT_TOKEN":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
				responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
			case "WITHOUT_ORG_ID_HEADER":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
				break;
			case "WITHOUT_USER_ID_HEADER":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
				break;
            case "WITHOUT_ORG_ID":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_STUDENT_ID":
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SUBJECT_MATH":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "SUBJECT_READING":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"reading\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_COURSE_LIST":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;
            case "WITHOUT_LANGUAGE":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_SUBJECT":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_INC_PERF_SUM":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_INC_PERF_BY_STRAND":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_AOD":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_HIST_DATA, "10000" );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;
            case "WITHOUT_INC_HIST_DATA":
                queryItem.put( ReportAPIConstants.SPReport.STUDENT_ID, "\\\"\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.LANGUAGE, "\\\"en\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.SUBJECT, "\\\"math\\\"" );
                queryItem.put( ReportAPIConstants.SPReport.COURSE_LST, "[\\\"1743\\\", \\\"1744\\\"]");
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_SUM, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_PERF_BY_STRAND, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.INC_AOD, Boolean.TRUE.toString() );
                queryItem.put( ReportAPIConstants.SPReport.FILTER_SCHOOL, "[\\\"8a720ac081d73ed30182436ef84303db\\\"]");
                query = constructQueryItems( queryItem );
                payload = payload.replace( ReportAPIConstants.SPReport.SP_QUERY, query );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( "demo_sm_admin01", "testing123$" ) );
                headers.put( Constants.ORGID_SM_HEADER, orgId );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPH_QL_SRV_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), ReportAPIConstants.ERROR ), ReportAPIConstants.CODE );
                break;


        }

        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        Log.message( response.getBody().asString() );
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_SCENARIO" },
                { "TC002", "401", "Verify the status code 401 for response body for not providing token in header", "WITHOUT_TOKEN" },
				{ "TC003", "200", "Verify the status code 400 for response body for not providing orgId in request body", "WITHOUT_ORG_ID" },
				{ "TC004", "400", "Verify the status code 400 for response body for not providing userId in request body", "WITHOUT_STUDENT_ID" },
                { "TC005", "UNAUTHENTICATED", "Verify the status code 400 for response body for not providing orgId in header", "WITHOUT_ORG_ID_HEADER" },
                { "TC006", "UNAUTHENTICATED", "Verify the status code 400 for response body for not providing userId in header", "WITHOUT_USER_ID_HEADER" },
                { "TC007", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_MATH" },
                { "TC008", "200", "Verify the status code 200 for response body for providing Math subject in request body", "SUBJECT_READING" },
                { "TC009", "200", "Verify the status code 400 for response body for not providing course list in request body", "WITHOUT_COURSE_LIST" },
                { "TC010", "GRAPHQL_VALIDATION_FAILED", "Verify the status code 400 for response body for not providing language  in request body", "WITHOUT_LANGUAGE"},
                { "TC011", "GRAPHQL_VALIDATION_FAILED", "Verify the status code 200 for response body for not providing subject  in request body", "WITHOUT_SUBJECT"},
                { "TC012", "GRAPHQL_VALIDATION_FAILED", "Verify the status code 200 for response body for not providing WITHOUT_INC_PERF_SUM in request body","WITHOUT_INC_PERF_SUM" },
                { "TC013", "GRAPHQL_VALIDATION_FAILED", "Verify the status code 400 for response body for not providing WITHOUT_INC_PERF_BY_STRAND in request body","WITHOUT_INC_PERF_BY_STRAND" },
                { "TC014", "GRAPHQL_VALIDATION_FAILED", "Verify the status code 400 for response body for not providing WITHOUT_AOD in request body","WITHOUT_AOD" },
                { "TC015", "GRAPHQL_VALIDATION_FAILED", "Verify the status code 200 for response body for not providing WITHOUT_INC_HIST_DATA offset in request body","WITHOUT_INC_HIST_DATA" }

        };
    }

    public String constructQueryItems( Map<String, String> queryItem ) {
        return queryItem.entrySet().stream().map( e -> e.getKey() + ":" + e.getValue() ).collect( Collectors.joining( " \\n " ) );
    }

    public String getPayload() throws IOException {
        String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report" + File.separator
                + "SPReportAdminRequest" + ".json";
        File file = new File( basePath );
        try (FileReader fr = new FileReader( file )) {
            char[] chars = new char[(int) file.length()];
            int offset = 0;
            while ( offset < chars.length ) {
                int result = fr.read( chars, offset, chars.length - offset );
                if ( result == -1 ) {
                    break;
                }
                offset += result;
            }
            return new String( chars );
        }
    }
}
