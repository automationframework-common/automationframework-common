package com.savvas.sm.reports.ui.tests.admin.lsr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsOutputPage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;


public class LastSessionSubHeader extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String organizationName;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        
    }

    @Test ( description = "Verify selected option as 'None,Teacher and Group' in Additional grouping field and selected option as'Student and Exercises Correct' in Sort options field", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
    public void smLSRSubHeader_001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smLSRSubHeader_001: Verify selected option as 'None,Teacher and Group' in Additional grouping field and selected option as'Student and Exercises Correct' in Sort options field. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

            //Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'None' is selected in Additional grouping and 'Student' is selected in Sort options" );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            lastSession.reportFilterComponent.expandOptionalFilter();
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.DEFAULT_ADDITIONAL_GROUPING);
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(0));

            outputPage.clickRunReportButton();
            
            Log.assertThat(outputPage.getOrganization().equals(organizationName), "The selected organization name is displaying successfully", "The selected organization name is not displaying properly");
            Log.assertThat( outputPage.verifiedLegendField(), "The Legent field is displaying successfully", "The Legent field is not displaying properly" );
            Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
            Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
            Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
            Log.assertThat( outputPage.getAssignmentName(), "The Assignment name is displaying successfully", "The Assignment name is not displaying properly" );
         
            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );                   
            driver.close();
            driver.switchTo().window( child.get( 1 ) );
            
            SMUtils.logDescriptionTC( "Verify the Teacher name is displaying in the sub header while selecting additional grouping as 'Teacher'" );
            //Selecting option from report input page
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.TEACHER_LABEL );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(1));
           
            //Getting teacher drop down values 
            List<String> teacherDropdownName = lastSession.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            teacherDropdownName.remove( "Select All" );
            
            outputPage.clickRunReportButton();
            
            String sortOptionAsCurrentCourseLevel = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(1));
            Log.assertThat(outputPage.getOrganization().equals(organizationName), "The selected organization name is displaying successfully", "The selected organization name is not displaying properly");
            Log.assertThat( outputPage.verifiedLegendField(), "The Legent field is displaying successfully", "The Legent field is not displaying properly" );
            Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_TEACHER), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
            Log.assertThat(outputPage.getSelectedSortOption().equals(sortOptionAsCurrentCourseLevel),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
            Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
            Log.assertThat( outputPage.getAssignmentName(), "The Assignment name is displayed successfully", "The Assignment name is not displayed properly" );
           	Set<String> selectedTeacherName = outputPage.getTeachertName();
           	List<String> teacherName = new ArrayList<>( selectedTeacherName );
           	Log.assertThat( teacherName.containsAll( teacherDropdownName ), "The teacher name is displaying correct", "The teacher name is not displaying correct" );
           
           	// Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );
                  
            //Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'Group' is selected in Additional grouping and 'Exercises Correct' is selected in Sort options" );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GROUP_LABEL );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(2));

            List<String> groupDropdownName = lastSession.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            groupDropdownName.remove( "Select All" );

            outputPage.clickRunReportButton();

            String sortOptionAsExercisesCorrect = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(2));
            Log.assertThat(outputPage.getOrganization().equals(organizationName), "The selected organization name is displaying successfully", "The selected organization name is not displaying properly");
            Log.assertThat( outputPage.verifiedLegendField(), "The Legent field is displaying successfully", "The Legent field is not displaying properly" );
            Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_GROUP), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
            Log.assertThat(outputPage.getSelectedSortOption().equals(sortOptionAsExercisesCorrect),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
            Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
            Log.assertThat( outputPage.getAssignmentName(), "The Assignment name is displayed successfully", "The Assignment name is not displayed properly" );
            Set<String> selectedgroupname = outputPage.getGroupName();
            List<String> groupName = new ArrayList<>( selectedgroupname );
            Log.assertThat( groupName.containsAll( groupDropdownName ), "The group name is displaying successfully", "The group name is not displaying properly" );

        } catch (Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify selected option as 'Grade' in Additional grouping field and selected option as'Exercises Attempt, Percent Correct and Help Used' in Sort options field", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
    public void smLSRSubHeader_002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "smLSRSubHeader_002:Verify selected option as 'Grade' in Additional grouping field and selected option as'Exercises Attempt, Percent Correct and Help Used' in Sort options field. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

            RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
            RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );
            
            //Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'Grade' is selected in Additional grouping and 'Exercise Attempt' is selected in Sort options" );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
            lastSession.reportFilterComponent.expandOptionalFilter();
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.GRADE_LABEL );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(3));
            //Getting grade drop down values
            List<String> gradeDropdownName = lastSession.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            gradeDropdownName.remove( "Select All" );
            
            outputPage.clickRunReportButton();

            String sortOptionAsExerciseAttempt = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(3));
            
            Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_GRADE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
            Log.assertThat(outputPage.getSelectedSortOption().equals(sortOptionAsExerciseAttempt),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
            Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
            Set<String> selectedGrade = outputPage.getGrade();
            List<String> grade = new ArrayList<>( selectedGrade );
            Log.assertThat( ReportsUIConstants.SUB_HEADER_GRADE.containsAll( grade ), "The Grade is displaying successfully", "The Grade is not displaying properly" );
        
            // Navigating to report filter page
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );                   
            driver.close();
            driver.switchTo().window( child.get( 1 ) );
           
            //Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated LS report when  'Percent Correct' is selected in Sort options" );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ReportsUIConstants.DEFAULT_ADDITIONAL_GROUPING);
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(4));
            
            outputPage.clickRunReportButton();
             
            Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
            Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_PERCENT_CORRECT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
            Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
         
            // Navigating to report filter page
            driver.close();
            driver.switchTo().window( child.get( 1 ) );
            
            //Selecting option from report input page
            SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'None' is selected in Additional grouping and 'Help Used' is selected in Sort options" );
            lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(5));

            outputPage.clickRunReportButton();
             
            String sortOption = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(5));
            Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
            Log.assertThat(outputPage.getSelectedSortOption().equals(sortOption),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
            Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");

            } catch ( Exception e ) {
                Log.exception( e, driver );
            } finally {
                Log.endTestCase();
                driver.quit();
            }
        }
       
            @Test ( description = "Verify the Report with Sort options field", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
            public void smLSRSubHeader_003() throws Exception {
                final WebDriver driver = WebDriverFactory.get( browser );

                Log.testCaseInfo( "smLSRSubHeader_003:Verify the Report with Sort options field.<small><b><i>[" + browser + "]</b></i></small>" );
                try {
                    AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                    AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                    RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                    RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );
                    
                    //Selecting option from report input page
                    SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'None' is selected in Additional grouping and 'Time Spent' is selected in Sort options" );
                    lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                    lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                    lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                    lastSession.reportFilterComponent.expandOptionalFilter();
                    lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(6));

                    outputPage.clickRunReportButton();
                     
                    String sortOption = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(6));
                    Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                    Log.assertThat(outputPage.getSelectedSortOption().equals(sortOption),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                    Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                    
                 // Navigating to report filter page
                    ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );                   
                    driver.close();
                    driver.switchTo().window( child.get( 1 ) );
                    
                    //Selecting option from report input page
                    SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'None' is selected in Additional grouping and 'Total Session' is selected in Sort options" );
                    lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(7));

                    outputPage.clickRunReportButton();
                    
                    String sortOptionAsTotalSession = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(7));
                    Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                    Log.assertThat(outputPage.getSelectedSortOption().equals(sortOptionAsTotalSession),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                    Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                    
                 // Navigating to report filter page
                    driver.close();
                    driver.switchTo().window( child.get( 1 ) );
                    
                    //Selecting option from report input page
                    SMUtils.logDescriptionTC( "Verify report filter in generated LS report when 'None' is selected in Additional grouping and 'Session Date' is selected in Sort options" );
                    lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown(ReportsUIConstants.SORT_LABEL, ReportsUIConstants.LAST_SESSION_SORT.get(8));

                    outputPage.clickRunReportButton();
                        
                    String sortOptionAsSessionDate = String.format(ReportsUIConstants.SELECTED_OPTION_SORT,ReportsUIConstants.LAST_SESSION_SORT.get(8));
                    Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                    Log.assertThat(outputPage.getSelectedSortOption().equals(sortOptionAsSessionDate),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                    Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_NOT_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
 

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
                
                @Test ( description = "Verify the report with Students Demographics is selected as 'Disability Status-option'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_004() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_004:Verify the report with Students Demographics is selected as 'Disability Status-option'. <small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
                        

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Disability Status-All'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS, Arrays.asList(ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get(0)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page                    
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Disability Status:Yes'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS,Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get(1)));
                        
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                       // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get(2)));
                        
                        outputPage.clickRunReportButton();                        
 
                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Disability Status:No'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.DISABILITY_STATUS,Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get(3)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    
    
                @Test ( description = "Verify the report with Students Demographics is selected as 'English Language Proficiency: option'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_005() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_005:Verify the report with Students Demographics is selected as 'English Language Proficiency: option'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'English Language Proficiency: All'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get(0)));
                        
                        outputPage.clickRunReportButton();
 
                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );   
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'English Language Proficiency: English'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get(1)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                        
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'English Language Proficiency: English Language Learner'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,Arrays.asList(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get(2)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'English Language Proficiency:Not Specified'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get(3)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
                @Test ( description = "Verify the report with Students Demographics is selected as 'Migrant Status: option'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_006() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_006:Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Migrant Status: option'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Migrant Status: All'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS,Arrays.asList(ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get(0)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                        
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );   
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Migrant Status: Migrant'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS,Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get(1)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                     // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );   
                        
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Migrant Status: Not Migrant'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS,Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get(2)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                     // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );   
                                                
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Migrant Status: Not Specified'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.MIGRANT_STATUS,Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get(3)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    
                @Test ( description = "Verify the report with Students Demographics is Selected as 'Race : All, White, Black or African American'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_007() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_007:Verify the report with Students Demographics is Selected as 'Race : All, White and Black or African American'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : All'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(0)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );   
                                                
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : White'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(1)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );        
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : Black or African American'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(2)));
                        
                        outputPage.clickRunReportButton();                        

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    
    
                @Test ( description = "Verify the report with Students Demographics is Selected as 'Race : Asian, American Native or Alaskan Native and Native Hawaiian or Pacific Islander '", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_008() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_008:Verify the report with Students Demographics is Selected as 'Race : Asian, American Native or Alaskan Native and Native Hawaiian or Pacific Islander '<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : Asian'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(3)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
                     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );   
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : American Native or Alaskan Native'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(4)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );  
                        
                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : Native Hawaiian or Pacific Islander'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(5)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                                            
                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    

                @Test ( description = "Verify the report with Students Demographics is Selected as 'Race : Hispanic/Latino, Unknown and Not Specified'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_009() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_009:Verify the report with Students Demographics is Selected as 'Race : Hispanic/Latino, Unknown and Not Specified'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        //Selecting option from report input page
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : Hispanic/Latino'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList(ReportsUIConstants.RACE_OPTIONS.get(6)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );  
                        
                        //Selecting option from report input page                       
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : Unknown'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(7)));
                        
                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) ); 
                        
                        //Selecting option from report input page                       
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Race : Not Specified'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.RACE,Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get(8)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    
                @Test ( description = "Verify the report with Students Demographics is selected as 'Ethnicity :option'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_010() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_010:Verify the report with Students Demographics is selected as 'Ethnicity :option'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        //Selecting option from report input page   
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Ethnicity :All'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY,Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get(0)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) ); 
                        
                        //Selecting option from report input page   
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Ethnicity :Hispanic or Latino'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY,Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get(1)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) ); 
                        
                        //Selecting option from report input page   
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Ethnicity :Not Hispanic or Latino'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY,Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get(2)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) ); 
                        
                        //Selecting option from report input page   
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Ethnicity :Not Specified'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get(3)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
                @Test ( description = "Verify the report with Students Demographics is selected as 'Special Services:All,504 Plan and Gifted / Talented'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_011() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_011:Verify the report with Students Demographics is selected as 'Special Services:All,504 Plan and Gifted / Talented'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services:All'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(0)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                     // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) ); 
                        
                        //Selecting option from report input page                         
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services: 504 Plan'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(1)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services: Gifted / Talented'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(2)));
                        
                        outputPage.clickRunReportButton();
                        
                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    
                @Test ( description = "Verify the report with Students Demographics is selected as 'Special Services: IEP, Other, No Special Services and Not Specified'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_012() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_012:Verify the report with Students Demographics is selected as 'Special Services: IEP, Other, No Special Services and Not Specified'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();

                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services: IEP'" );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(3)));

                        outputPage.clickRunReportButton();
                        
                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services: Other'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(4)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services: No Special Services'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(5)));

                        outputPage.clickRunReportButton();
 
                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS report when Filter Students by Demographics is selected as 'Special Services: Not Specified'" );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SPECIAL_SERVICES,Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get(6)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }
    
                @Test ( description = "Verify the report with Students Demographics is selected as 'Socioeconomic status:option'", groups = { "SMK-57828", "Last Session", "Sub Header" }, priority = 1 )
                public void smLSRSubHeader_013() throws Exception {
                    final WebDriver driver = WebDriverFactory.get( browser );

                    Log.testCaseInfo( "smLSRSubHeader_013:Verify the report with Students Demographics is selected as 'Socioeconomic status:option'<small><b><i>[" + browser + "]</b></i></small>" );
                    try {
                        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                        AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( username, password );

                        RecentSessionsPage lastSession = dashBoardPage.reportFilterComponent.clickOnRecentSessionsPage();
                        RecentSessionsOutputPage outputPage = new RecentSessionsOutputPage( driver );

                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS  report when Filter Students by Demographics is selected as 'Socioeconomic status:All'");
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, organizationName );
                        lastSession.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.expandOptionalFilter();
                        lastSession.reportFilterComponent.expandStudentDemographics();
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS,Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get(0)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                        
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS  report when Filter Students by Demographics is selected as 'Socioeconomic status: Economically disadvantaged'");
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS,Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get(1)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     
                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                                                
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS  report when Filter Students by Demographics is selected as 'Socioeconomic status: NOt Economically disadvantaged'");
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS,Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get(2)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");

                        // Navigating to report filter page
                        driver.close();
                        driver.switchTo().window( child.get( 1 ) );
                                                
                        
                        //Selecting option from report input page 
                        SMUtils.logDescriptionTC( "Verify report filter in generated LS  report when Filter Students by Demographics is selected as 'Socioeconomic status: Not Specified'");
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.ALL ) );
                        lastSession.reportFilterComponent.selectOptionsFromMultiSelectDropdown(ReportsUIConstants.SOCIOECONOMIC_STATUS,Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get(3)));

                        outputPage.clickRunReportButton();

                        Log.assertThat(outputPage.getSelectedAdditionalGrouping().equals(ReportsUIConstants.ADDITIONAL_GROUPING_NONE), "The selected additional grouping option is displaying successfully", "The selected additional grouping option is not displaying properly");
                        Log.assertThat(outputPage.getSelectedSortOption().equals(ReportsUIConstants.SORT_AS_STUDENT),"The selected sort option is displaying successfully", "The selected sort option is not displaying properly");
                        Log.assertThat(outputPage.selectedOptionDemographic().equals(ReportsUIConstants.DEMOGRAPHIC_FILTERS_USED), "The demographic fliter flied is displaying successfully", "The demographic fliter flied is not displaying properly");
                        Log.assertThat(outputPage.getDemographicValue(), "The selected option demographic fliter flied is displaying successfully", "The selected option demographic fliter flied is not displaying properly");
     

                    } catch (Exception e ) {
                        Log.exception( e, driver );
                    } finally {
                        Log.endTestCase();
                        driver.quit();
                    }
                }    
        }   		


