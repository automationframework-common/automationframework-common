package com.savvas.sm.reports.ui.tests.teacher.spr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.teacher.ui.pages.AreaForGrowthReportPage;
import com.savvas.sm.reports.teacher.ui.pages.ReportComponents;
import com.savvas.sm.reports.teacher.ui.pages.StudentPerformanceReportsPages;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.SaveReportFilterPopup;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SPRTeacherSaveReportOption extends EnvProperties {
    private String smUrl;

    private String browser;
    private String username;
    private String password;
    private String teacherDetails;
    private String teacherDetails1;
    private String teacherUsername;
    private String teacherUsername1;
    private String username1;
    private String password1;
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    RBSUtils rbs = new RBSUtils();
    CourseAPI coursesMethod = new CourseAPI();
    ReportComponents reportComponents;
    private List<String> courses;
    private String districtId;
    private String userId;
    private String userId1;
    private String studentDetails;
    private String studentIdOne;
    private String studentTwoDetail;
    private String studentIdTwo;
    private String studentThreeDetails;
    private String studentIdThree;
    private String studentFourDetails;
    private String studentIdFour;
    private String studentFiveDetails;
    private String studentIdFive;
    String orgId;
    List<String> studentRumbaIds = new ArrayList<String>();
    List<String> studentRumbaIds2 = new ArrayList<>();
    HashMap<String, String> contentBase = new HashMap<String, String>();
    HashMap<String, String> courseName = new HashMap<String, String>();
    HashMap<String, String> courseIDs = new HashMap<String, String>();
    HashMap<String, String> assignmentDetails = new HashMap<String, String>();
    List<String> studentRumbaIds1 = new ArrayList<String>();

    @BeforeClass
    public void initTest() throws Exception, IOException {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        districtId = configProperty.getProperty( "district_ID" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "userName" );
        userId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentIdOne = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );

        studentTwoDetail = RBSDataSetup.getMyStudent( school, username );
        studentIdTwo = SMUtils.getKeyValueFromResponse( studentTwoDetail, "userId" );

        studentThreeDetails = RBSDataSetup.getMyStudent( school, username );
        studentIdThree = SMUtils.getKeyValueFromResponse( studentThreeDetails, "userId" );

        studentFourDetails = RBSDataSetup.getMyStudent( school, username1 );
        studentIdFour = SMUtils.getKeyValueFromResponse( studentFourDetails, "userId" );

        studentFiveDetails = RBSDataSetup.getMyStudent( school, username1 );
        studentIdFive = SMUtils.getKeyValueFromResponse( studentFiveDetails, "userId" );

        orgId = new RBSUtils().getOrganizationIDByName( districtId, school );

        studentRumbaIds.add( studentIdOne );
        studentRumbaIds.add( studentIdTwo );
        studentRumbaIds.add( studentIdThree );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

        courseIDs.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIDs.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS,
                courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId,
                courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD,
                courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL,
                courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

        HashMap<String, String> mathAssignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentRumbaIds.get( 0 ) ), new ArrayList<>( courseIDs.values() ) );

        Log.message( mathAssignmentResponse.get( "body" ) );

        studentRumbaIds2.add( studentIdOne );
        studentRumbaIds2.add( studentIdTwo );
        studentRumbaIds2.add( studentIdThree );

        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

        courseIDs.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId,
                DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId,
                courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId,
                DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId, orgId, DataSetupConstants.SKILL,
                courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

        HashMap<String, String> readingAssignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds2, new ArrayList<>( courseIDs.values() ) );

        Log.message( readingAssignmentResponse.get( "body" ) );

        studentRumbaIds1.add( studentIdFour );
        studentRumbaIds1.add( studentIdFive );

        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

        courseIDs.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1, orgId,
                DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1,
                orgId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1, orgId,
                DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        courseIDs.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( username1, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, userId1, orgId, DataSetupConstants.SKILL,
                courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId1 );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username1, password ) );

        HashMap<String, String> readingAssignmentResponse1 = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds1, new ArrayList<>( courseIDs.values() ) );

        Log.message( readingAssignmentResponse1.get( "body" ) );

    }

    @Test ( description = "Verify Save Report Option with Mandatory fields with math in SPR Teacher and check the saved values are retained", groups = { "SMK-66748", "reports", "StudentPerformanceReport - Save Report Options" }, priority = 1 )
    public void tcSPRSaveReportOptions001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions001:Verify Save Report Option with Mandatory with math fields and check the saved values are retained <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to SPR Page
            StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents.clickStudentPerformancePage();

            reportComponents = new ReportComponents( driver );

            SaveReportFilterPopup saveReportOptionPopup = studentPerformanceReportsPage.reportComponents.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( studentPerformanceReportsPage.reportComponents.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );

            Log.testCaseInfo( "Verify the Saved Report option drop down is listed with saved report options" );
            studentPerformanceReportsPage.reportFilterComponent.expandSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();
            
            Log.testCaseInfo( "Verify the all the saved options are retained for math subject" );
            Log.testCaseInfo( "Verify the Saved report option name is displayed when it is selected" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_DROPDOWN1 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_GROUP_OPTION ),
                    "User is retained with select All Groups from Group Dropdown", "User is not retained with select All Groups from Group Dropdown" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SUBJECT_DROPDOWN ).equalsIgnoreCase( "1" ), "User is retained with Selected Subject Math",
                    "User is not retained with Selected Subject Math" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_DROPDOWN ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ASSIGNMENTS_OPTION ),
                    "User is retained with Selected Assignments", "User is not retained with Selected Assignments" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DISPLAY_LABEL ).equalsIgnoreCase( ReportsUIConstants.DISPLAY1.get( 0 ) ),
                    "Display Name Values Student Name is Retained Successfully", "Display Name Value Student Name not retained Successfully" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DATE_AT_RISK ).equalsIgnoreCase( ReportsUIConstants.DATE_AT_RISK_OPTIONS1.get( 0 ) ),
                    "Date At Risk is Retained Successfully", "Date At Risk not retained Successfully" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.LANGUAGE ).equalsIgnoreCase( ReportsUIConstants.DEFAULT_LANGUAGE1 ), "Language is Retained Successfully",
                    "Language not retained Successfully" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Save Report Option with Mandatory fields with Reading in SPR Teacher and check the saved values are retained", groups = { "SMK-66748", "reports", "StudentPerformanceReport - Save Report Options" }, priority = 1 )
    public void tcSPRSaveReportOptions002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions002:Verify Save Report Option with Mandatory with Reading fields and check the saved values are retained <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to SPR Page
            StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents.clickStudentPerformancePage();

            reportComponents = new ReportComponents( driver );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SUBJECT_DROPDOWN, ReportsUIConstants.READING );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 1 ) );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.DEFAULT_LANGUAGE1 );

            SaveReportFilterPopup saveReportOptionPopup = studentPerformanceReportsPage.reportComponents.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( studentPerformanceReportsPage.reportComponents.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );

            Log.testCaseInfo( "Verify the Saved Report option drop down is listed with saved report options" );
            studentPerformanceReportsPage.reportFilterComponent.expandSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the all the saved options are retained for reading subject" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_DROPDOWN1 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_GROUP_OPTION ),
                    "User is retained with select All Groups from Group Dropdown", "User is not retained with select All Groups from Group Dropdown" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SUBJECT_DROPDOWN ).equalsIgnoreCase( "2" ), "User is retained with Selected Subject Reading",
                    "User is not retained with Selected Subject Reading" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_DROPDOWN ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ASSIGNMENTS_OPTION ),
                    "User is retained with Selected Assignments", "User is not retained with Selected Assignments" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DISPLAY_LABEL ).equalsIgnoreCase( ReportsUIConstants.DISPLAY1.get( 1 ) ),
                    "Display Name Values Student Name is Retained Successfully", "Display Name Value Student Name not retained Successfully" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DATE_AT_RISK ).equalsIgnoreCase( ReportsUIConstants.DATE_AT_RISK_OPTIONS1.get( 1 ) ),
                    "Date At Risk is Retained Successfully", "Date At Risk not retained Successfully" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.LANGUAGE ).equalsIgnoreCase( ReportsUIConstants.DEFAULT_LANGUAGE1 ), "Language is Retained Successfully",
                    "Language not retained Successfully" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the all functionality and options validated in Save Report Option for SPR Teacher", groups = { "SMK-66748", "reports", "StudentPerformanceReport - Save Report Options" }, priority = 1 )
    public void tcSPRSaveReportOptions003() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions003:Verify the all functionality and options validated in Save Report Option for SPR Teacher<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            // Navigate to SPR Page
            StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents.clickStudentPerformancePage();

            reportComponents = new ReportComponents( driver );

            Log.testCaseInfo( "Verify Saved Report Option label is displayed in the Student Performance Report Page" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ), "The Student Performance Save Report Option label is displayed and it is verified",
                    "Student Performance Report Save Report Option label is not displayed and it is verified" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "Student Performance Report Save Report Option label text is displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL,
                    "Student Performance Report Save Report Option label text is not displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify Saved Report Option drop down is displayed in the Student Performance Report" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_LABEL ),
                    "Student Performance Report Save Report Option drop down is displayed and it is verified", "Student Performance Report Save Report Option drop down is not displayed and it is verified" );
            Log.testCaseResult();

            String savedReport = "SavedReport" + System.nanoTime();
            SaveReportFilterPopup saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( savedReport );
            saveReportOptionPopup.clickSaveButton();
            Log.testCaseInfo( "Verify the default text in the displayed in the Saved Report Option drop down" );
            Log.message( studentPerformanceReportsPage.reportFilterComponent.getWatermarkTextForSaveReportDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ) );
            Log.assertThat(
                    studentPerformanceReportsPage.reportFilterComponent.getWatermarkTextForSaveReportDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).equals(
                            ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER ),
                    "Student Performance Report Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER,
                    "Student Performance Report Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.LAST_SESSION_SAVE_REPORT_OPTION_DISABLED_PLACEHOLDER );
            Log.testCaseResult();

            
            Log.testCaseInfo( "Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.isSingleSelectDropDownArrowDisplayed( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ),
                    "The Student Performance Save Report Option drop down arrow is displayed and it is verified", "The Student Performance Save Report Option drop down arrow is not displayed and it is verified" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ),
                    "The arrow is in downward direction when it is collapsed", "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Saved Report option drop down is listed with saved report options" );
            studentPerformanceReportsPage.reportFilterComponent.expandSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Saved report option name is displayed when it is selected" );

            Log.testCaseInfo( "Verify user can click the 'Save Report Option' button in Student Performance report page" );
            Log.testCaseInfo( "Verify all available fields in 'Save Report Option Popup." );
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.assertThat( saveReportOptionPopup.getLabelForNewCustomReportConfiguration().equalsIgnoreCase( ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.NEW_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForNewCustomReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.getLabelForExistingReportConfiguration().equalsIgnoreCase( ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL ), "New Report configuration label is displayed properly",
                    "New Report configuration label is not displayed properly! Expected - " + ReportsUIConstants.EXISTING_REPORT_CONFIGURATION_LABEL + " Actual - " + saveReportOptionPopup.getLabelForExistingReportConfiguration() );
            Log.assertThat( saveReportOptionPopup.isSaveButtonDisplayed(), "Save Button is displayed in saved report popup", "Save Button is not displayed in saved report popup" );
            Log.assertThat( saveReportOptionPopup.isCancelButtonDisplayed(), "Cancel Button is displayed in saved report popup", "Cancel Button is not displayed in saved report popup" );
            Log.testCaseResult();
            driver.navigate().refresh();
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            Log.testCaseInfo( "Verify if click the save button with empty Name in 'Save Report Option' Popup." );
            Log.assertThat( !saveReportOptionPopup.isSaveButtonEnabled(), "Save button is disabled if the user is not entered name in the text box", "Save button is not disabled if the user is not entered name in the text box" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify user can able to cancel the in 'Save Report Option ' Popup on Student Performance report page." );
            saveReportOptionPopup.clickCancelButton();
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify User can able to save the report option with new name." );
            Log.testCaseInfo( "Verify User can able to save the report option with default Optional filters." );
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "SavedReport" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            String filterName2 = "SavedReport" + System.nanoTime();
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName2 );
            saveReportOptionPopup.clickSaveButton();
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify if click the save button with already existing name in 'Save Report Option' Popup." );
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.ALREADY_EXISTS_ERROR_MESSAGE ), "Error Message displayed properly for already existing name",
                    "Error Message is not displayed properly for already existing name" );
            saveReportOptionPopup.clickCancelButton();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify If User enter more than 50 characters in new custom report configuration text box." );
            saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( ReportsUIConstants.LENGTHY_NAME );
            Log.assertThat( saveReportOptionPopup.getErrorMessage().equalsIgnoreCase( ReportsUIConstants.NAME_EXCEED_ERROR_MESSAGE ), "Error Message displayed properly for name exceed maximum length",
                    "Error Message is not displayed properly for name exceed maximum length" );

            Log.testCaseInfo( "Verify User can able to click the close button in save report option" );
            saveReportOptionPopup.clickCloseIcon();
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.isReportTitleDisplayed(), "The Save Report poup closed properly", "issue in closing the popup" );
            driver.navigate().refresh();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify If User enter optional filter for display name and create new save report." );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 1 ) );
            reportComponents = new ReportComponents( driver );
            SaveReportFilterPopup saveReportOptionPopup1 = studentPerformanceReportsPage.reportComponents.clickSaveReportOptionButton();
            String filterName1 = "Filter" + System.nanoTime();
            saveReportOptionPopup1.enterNameInNewReportFilterConfigurationTextBox( filterName1 );
            saveReportOptionPopup1.clickSaveButton();
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            studentPerformanceReportsPage.reportFilterComponent.clickResetButton();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'student user name ' option in display Dropdown with display on SPR report and load the report", groups = { "SMK-66748", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions004: Verify User can able to save the report option with 'student user name ' option in display Dropdown with display on SPR report and load the report" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents.clickStudentPerformancePage();
            reportComponents = new ReportComponents( driver );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'student user name ' option in display Dropdown with display on SPR report and load the report" );

            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, ReportsUIConstants.DISPLAY.get( 2 ) );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DATE_AT_RISK, ReportsUIConstants.DATE_AT_RISK_OPTIONS.get( 1 ) );
            studentPerformanceReportsPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.LANGUAGE, ReportsUIConstants.LANGUAGE_SPANISH );

            SaveReportFilterPopup saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();
            
            Log.testCaseInfo( "Verify the Saved Report option drop down is listed with saved report options" );
            studentPerformanceReportsPage.reportFilterComponent.expandSingleSelectDropdown( "SAVED REPORT OPTIONS" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL ).size() > 0, "The saved options values are displayed",
                    "The saved options values are not displayed" );
            Log.testCaseResult();
            
            Log.testCaseInfo( "Verify the all the saved options are retained" );
            
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.GROUP_DROPDOWN1 ).equalsIgnoreCase( ReportsUIConstants.SELECTED_GROUP_OPTION ),
                    "User is retained with select All Groups from Group Dropdown", "User is not retained with select All Groups from Group Dropdown" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.SUBJECT_DROPDOWN ).equalsIgnoreCase( "1" ), "User is retained with Selected Subject Math",
                    "User is not retained with Selected Subject Math" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromTeacherMultiSelectDropdown( ReportsUIConstants.ASSIGNMENTS_DROPDOWN ).equalsIgnoreCase( ReportsUIConstants.SELECTED_ASSIGNMENTS_OPTION ),
                    "User is retained with Selected Assignments", "User is not retained with Selected Assignments" );

            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DISPLAY_LABEL ).equalsIgnoreCase( ReportsUIConstants.DISPLAY1.get( 2 ) ),
                    "Display Name Values Student Name is Retained Successfully", "Display Name Value Student Name not retained Successfully" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.DATE_AT_RISK ).equalsIgnoreCase( ReportsUIConstants.DATE_AT_RISK_OPTIONS1.get( 1 ) ),
                    "Date At Risk is Retained Successfully", "Date At Risk not retained Successfully" );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdownNew( ReportsUIConstants.LANGUAGE ).equalsIgnoreCase( ReportsUIConstants.LANGUAGE_SPANISH ), "Language is Retained Successfully",
                    "Language not retained Successfully" );


        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'No' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report", groups = { "SMK-66748", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions005:Verify User can able to save the report option with 'No' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents.clickStudentPerformancePage();
            reportComponents = new ReportComponents( driver );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'No' Dropdown with in  performance summary report" );

            SMUtils.logDescriptionTC( "Verify Include Performance Summary should be display ." );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying and No option clicked",
                    "Include Performance Summary is not displaying and No option is clicked" );
            studentPerformanceReportsPage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            SMUtils.logDescriptionTC( "Verify Include Performance By Strand should be display ." );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance Strand is displaying and No option clicked",
                    "Include Performance Strand is not displaying and No option is clicked" );
            studentPerformanceReportsPage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            SMUtils.logDescriptionTC( "Verify Include Areas of Growth should be display ." );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying and No option is clicked",
                    "Include Areas of Growth is not displaying and No option is not clicked" );
            studentPerformanceReportsPage.reportFilterComponent.clickNoRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );
            SaveReportFilterPopup saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();

            Log.assertThat( !studentPerformanceReportsPage.reportComponents.isSaveReportButtonEnabled(), "Save button is disabled if the user is not entered name in the text box",
                    "Save button is not disabled if the user is not entered name in the text box" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with 'Yes' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report", groups = { "SMK-66748", "SaveReportOption",
            "SPRSaveReportOption" }, priority = 1 )
    public void tcSPRSaveReportOptions006() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSPRSaveReportOptions006: Verify User can able to save the report option with 'Yes' Dropdown with in  performance summary with multiple options in student demographics dropdowns and load the report <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            AreaForGrowthReportPage dashboardPage = smLoginPage.loginToSMATeacher( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );

            StudentPerformanceReportsPages studentPerformanceReportsPage = dashboardPage.reportComponents.clickStudentPerformancePage();
            reportComponents = new ReportComponents( driver );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Yes' Dropdown with in  Include Performance Summary Include Performance Strand and AOG " );
            studentPerformanceReportsPage.reportFilterComponent.expandOptionalFilter();

            SMUtils.logDescriptionTC( "Verify Include Performance Summary should be display ." );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getIncludePerformanceSummarylbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY ), "Include Performance Summary is displaying",
                    "Include Performance Summary is not displayed" );
            studentPerformanceReportsPage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_SUMMARY );

            SMUtils.logDescriptionTC( "Verify Include Performance By Strand should be display ." );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getIncludePerformanceStrandlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND ), "Include Performance By Strand is displaying",
                    "Include Performance By Strand is not displayed" );
            studentPerformanceReportsPage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_PERFORMANCE_STRAND );

            SMUtils.logDescriptionTC( "Verify Include Areas of Growth should be display ." );
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getIncludeAreasOfGrowthlbl().equalsIgnoreCase( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH ), "Include Areas of Growth is displaying",
                    "Include Areas of Growth is not displayed" );
            studentPerformanceReportsPage.reportFilterComponent.clickYesRadioButton( ReportsUIConstants.INCLUDE_AREAS_OF_GROWTH );

            SaveReportFilterPopup saveReportOptionPopup = studentPerformanceReportsPage.reportFilterComponent.clickSaveReportOptionButton();
            String filterName = "Filter" + System.nanoTime();
            saveReportOptionPopup.enterNameInNewReportFilterConfigurationTextBox( filterName );
            saveReportOptionPopup.clickSaveButton();
            Log.assertThat( studentPerformanceReportsPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).contains( filterName ), "Report filter options saved successfully",
                    "issue in saving the filter options" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
