package com.savvas.sm.reports.smoke.admin.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class CumulativePerformanceAggregateReport extends LoadableComponent<CumulativePerformanceAggregateReport> {

    WebDriver driver;
    private boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    @IFindBy ( how = How.XPATH, using = "//h1[text()='Cumulative Performance Report']", AI = false )
    public WebElement txtCumulativePerformanceAggregateReportHeader;

    /***********************************************************************************************************
     ************************************ ShadowDOM ************************************************************
     ***********************************************************************************************************/
    public String drpDwnSortshadowDOM[] = { "cel-accordion-item", "document.querySelector('#sort').shadowRoot.querySelector('#dropdown')" };
    public String drpOrganizationOptions[] = { "#organization > div > cel-single-select", "document.querySelector('#organization > div > cel-single-select').shadowRoot.querySelector('#dropdown');" };
    public String txtSortDrpdwn = "School";

    @Override
    protected void load() {
        isPageLoaded = true;
        Utils.waitForPageLoad( driver );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        if ( isPageLoaded && !( Utils.waitForElement( driver, txtCumulativePerformanceAggregateReportHeader ) ) ) {
            Log.fail( "Page did not open up. Site might be down.", driver );
        }
        elementLayer = new ElementLayer( driver );
    }

    public CumulativePerformanceAggregateReport() {}

    public CumulativePerformanceAggregateReport( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    /**
     * @author aravindan.srinivas validate Sort drop down Field
     * @param driver
     * @throws InterruptedException
     */
    public void validateSortDrpdwnField( WebDriver driver ) throws InterruptedException {
        WebElement drpDwnSortshadowDOM = ShadowDOMUtils.retryAndGetWebElement( driver, this.drpDwnSortshadowDOM[0], this.drpDwnSortshadowDOM[1] );
        ReportsBrowserActions.verifyElementIsDisplayed( driver, drpDwnSortshadowDOM, "Sort Drop Down Field" );
        String attributeValue = drpDwnSortshadowDOM.getAttribute( "data-selected" );
        Log.assertThat( attributeValue.trim().equalsIgnoreCase( txtSortDrpdwn ), "Selected '" + attributeValue + "' as default value in Sort Drpdwn Field", "'" + attributeValue + "' is not a default value in Sort Drpdwn Field" );
    }

    /**
     * @author aravindan.srinivas Validate all the fields and headers present in
     *         the Cumulative Performance Aggregate Report
     * @param driver
     * @throws InterruptedException
     */
    public void validateAllFieldsInCumulativePerformanceAggregateReport( WebDriver driver ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );

        WebElement txtOptionalFilter = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtOptionalFiltershadowDOM[0], reportsFilterUtils.txtOptionalFiltershadowDOM[1] );
        String currentReportName = txtCumulativePerformanceAggregateReportHeader.getText();
        reportsFilterUtils.verifyTextSavedReportOptionsHeader( driver );
        reportsFilterUtils.validateSavedReportOptionsDrpdwnField( driver );

        reportsFilterUtils.verifyTextOrganizationsHeader( driver );
        reportsFilterUtils.validateOrgDrpdwnField( driver );

        reportsFilterUtils.verifyTextCourseSelectionHeader( driver );

        reportsFilterUtils.verifyTextSubjectDropDownHeader( driver, currentReportName );
        reportsFilterUtils.validateSubjectDrpdwnField( driver );

        reportsFilterUtils.validateOptionalFilterHeaderField( driver );

        // Option Filter
        SMUtils.click( driver, txtOptionalFilter );

        reportsFilterUtils.verifyTextAdditionalGrouping( driver );
        reportsFilterUtils.validateAdditionalGroupingDrpdwnField( driver );

        reportsFilterUtils.verifyTextSortInAdditionalGrouping( driver );
        validateSortDrpdwnField( driver );

        // Demographics Filter
        WebElement txtStudentDemographics = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.txtStudentDemographicsShadowDOM[0], reportsFilterUtils.txtStudentDemographicsShadowDOM[1] );
        SMUtils.click( driver, txtStudentDemographics );

        reportsFilterUtils.verifyTextDisablityStatus( driver );
        reportsFilterUtils.validateDisabilityStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextEnglishLanguageProficiency( driver );
        reportsFilterUtils.validateEnglishLanguageProficiencyDrpdwnField( driver );

        reportsFilterUtils.verifyTextEthnicity( driver );
        reportsFilterUtils.validateEthnicityDrpdwnField( driver );

        reportsFilterUtils.verifyTextMigrantStatus( driver );
        reportsFilterUtils.validateMigrantStatusDrpdwnField( driver );

        reportsFilterUtils.verifyTextRace( driver );
        reportsFilterUtils.validateRaceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSpecialServices( driver );
        reportsFilterUtils.validateSpecialServiceDrpdwnField( driver );

        reportsFilterUtils.verifyTextSocioEconomicStatus( driver );
        reportsFilterUtils.validateSocioEconomicStatusDrpdwnField( driver );
    }

    /**
     * @author sathish.suresh Validate CP Aggregate run report
     * @param driver
     * @return
     * @throws InterruptedException
     */
    public ReportsViewerPage validateCPAggregateRunReport( WebDriver driver, String flexSchoolId ) throws InterruptedException {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        this.chooseOrganization( driver, flexSchoolId );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", "Math" );
        List<String> valuesList = new ArrayList<String>();
        valuesList.add( "Select All" );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", valuesList );
        ReportsViewerPage ReportsViewerPage = reportsFilterUtils.clickRunReport( driver );
        return new ReportsViewerPage( driver );
    }

    /**
     * @author sathish.suresh CP Aggregate saved report Validation
     * @param driver
     * @throws InterruptedException
     */
    public void validateCPAggregateSavedReports( WebDriver driver , String flexSchoolId ) throws InterruptedException {
        Random rnd = new Random();
        int n = 1 + rnd.nextInt();
        String savedReportName = "Automation Validation" + n; // update
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.assertThat( SMUtils.verifyWebElementTextEquals( reportsFilterUtils.txtReportsHeading, "Cumulative Performance Report" ), "User Landed On Areas Of Growth Report", "User Not Landed On Areas Of Growth Report" );

        WebElement drpdwnSubjectshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnSubjectshadowDOM[0], reportsFilterUtils.drpdwnSubjectshadowDOM[1] );
        WebElement drpdwnCoursesshadowDOM = ShadowDOMUtils.getWebElement( driver, reportsFilterUtils.drpdwnCoursesshadowDOM[0], reportsFilterUtils.drpdwnCoursesshadowDOM[1] );

        this.chooseOrganization( driver, flexSchoolId );
        SMUtils.click( driver, drpdwnSubjectshadowDOM );
        Log.message( "User Clicked On Subject Drop Down" );
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelect( driver, drpdwnSubjectshadowDOM, "Math", "Course drop Down" );

        Thread.sleep( 2000 );
        reportsFilterUtils.verifyCourseDropDownIsEnabled( driver, drpdwnCoursesshadowDOM );
        ArrayList<String> optionToSelect = new ArrayList<String>( Arrays.asList( "Select All" ) );
        reportsFilterUtils.selectOptionFromMultiSelectDropDown( driver, "courses", optionToSelect );
        reportsFilterUtils.clickSavedReportOptionsButton( driver );
        reportsFilterUtils.EnterCustomReportConfigurationName( driver, savedReportName );
        reportsFilterUtils.clickSaveButtonForCustomReportConfiguration( driver );
        Log.assertThat( reportsFilterUtils.verifySavedReportOptionRetains( driver, savedReportName ), "PASSED : Saved Report Option Drop Down Retained The Saved Report Configuration",
                "FAILED : Saved Report Option Drop Down Not Retained The Saved Report Configuration" );
    }

    /**
     * @author sakthi.sasi Used to perform Organization choosing
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public CumulativePerformanceAggregateReport chooseOrganization( WebDriver driver, String orgId ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.nap( 5 );
        WebElement drpdwnElement = ShadowDOMUtils.getWebElement( driver, drpOrganizationOptions[0], drpOrganizationOptions[1] );
        drpdwnElement.click();
        reportsFilterUtils.selectOptionFromSingleSelectDropDownUsingSelectValue( driver, drpdwnElement, orgId, "Choosing Organization" );
        return this;

    }

    /**
     * @author sakthi.sasi Used to perform Subject choosing
     * 
     * @param driver
     * @param subjectName
     * @return
     */
    public CumulativePerformanceAggregateReport chooseSubject( WebDriver driver, String subjectName ) {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        SMUtils.waitForElement( driver, txtCumulativePerformanceAggregateReportHeader );
        reportsFilterUtils.selectOptionFromSingleSelectDropDown( "subject", subjectName );
        return this;

    }

    /**
     * @author sakthi.sasi Used to verify the Organization ID's
     * 
     * @param driver
     * @param districtAdmin
     * @param smUrl
     * @return
     * @throws Exception
     */
    public CumulativePerformanceAggregateReport verifyOrgIds( WebDriver driver, Admins districtAdmin, String smUrl ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.compareOrganizationElements( driver, districtAdmin, smUrl ), "Organization List Matches", "Organization List doesn't Match" );
        return this;
    }

    /**
     * @author sakthi.sasi Used to verify the Organization is available or not
     * 
     * @param driver
     * @param orgId
     * @return
     */
    public CumulativePerformanceAggregateReport verifyOrg( WebDriver driver, String orgName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        Log.softAssertThat( reportsFilterUtils.validateOrganizationDropdownValue( driver, orgName ), "Organization is Available", "Organization is not Available" );
        return this;
    }

    /**
     * @author raseem.mohamed Used to verify the Courses
     * @param driver
     * @param admin
     * @param orgIds
     * @param SubjectName
     * @return
     * @throws Exception
     */
    public CumulativePerformanceAggregateReport verifyCourses( WebDriver driver, Admins admin, List<String> orgIds, String SubjectName ) throws Exception {
        ReportsFilterUtils reportsFilterUtils = new ReportsFilterUtils( driver );
        List<String> expcourseNames = new ArrayList<String>();
        List<String> actualCourseNames = reportsFilterUtils.getAllValuesFromDropdown( reportsFilterUtils.COURSES );
        Log.message( "Actual Courses Name From UI : " + actualCourseNames );
        if ( SubjectName.equalsIgnoreCase( "reading" ) ) {
            expcourseNames = Arrays.asList( "Reading" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        } else if ( SubjectName.equalsIgnoreCase( "math" ) ) {
            expcourseNames = Arrays.asList( "Math" );
            Log.message( "Courses Name From DataBase : " + expcourseNames );
        }
        Log.message( "Courses Name From UI : " + actualCourseNames );

        int actualSize = actualCourseNames.size();
        int expectSize = expcourseNames.size();
        String actual = String.valueOf( actualSize );
        String expect = String.valueOf( expectSize );

        boolean validate = false;
        if ( actualSize == expectSize ) {
            for ( int i = 0; i < actualCourseNames.size(); i++ ) {
                validate = actualCourseNames.get( i ).contains( expcourseNames.get( i ) );
                if ( validate == false ) {
                    Log.softAssertThat( validate, "Course " + actualCourseNames + "Value Is Matching", "Course" + actualCourseNames + " Value Is Not Matching" );
                }
            }
        }
        Log.assertThat( actual.equalsIgnoreCase( expect ), "Passed : Courses Are Matching", "Failed : Courses Are Not Matching" );
        return this;
    }

}
