package com.savvas.sm.reports.exportcsv.admin.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.util.DevToolsUtils;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.CPRExportCSVConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;

import io.restassured.response.Response;

public class AdminCPRExportCSVTest extends EnvProperties {
    private static String smUrl;
    private static String browser;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String selectedSchoolId;
    String distId;
    String districtAdminDetails;
    String teacherId;
    String bearerToken;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        distId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        //District Admin

        districtAdminDetails = ReportDataCollection.districtAdminDetails;
        Log.message( "********" );
        distAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        distAdminuserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        selectedSchoolId = ReportDataCollection.orgId;
        bearerToken = new RBSUtils().getAccessToken( distAdminUserName, password );
    }

    @Test ( dataProvider = "getData", groups = { "Admin_Dashboard", "SMK-66712", "Admin dashboard CPR Export CSV", "API" }, priority = 1 )
    public void adminCPRExportCSVTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );
        Map<String, String> headers = new HashMap<>();
        Response response = null;
        String requestId = null;
        Map<String, Object> saveReportOptionalFilters = new HashMap<>();
        Map<String, Object> optionalFilter = new HashMap<>();
        Response saveAdminCPReportOptionResponse = null;
        String exportType = "default";
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + bearerToken );
        headers.put( Constants.ORGID_SM_HEADER, distId );
        headers.put( Constants.USERID_SM_HEADER, distAdminuserId );

        switch ( scenarioType ) {
            case "CWD_MATH":
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "CUSTOM_MATH":
                exportType = "custom";
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "custom", requestId, "01/23/23 - 11:31 AM", Constants.MATH, CPRExportCSVConstants.CUSTOM_MATH_SELECTED_FILTERS, optionalFilter );
                break;
            case "CUSTOM_READING":
                exportType = "custom";
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "custom", requestId, "01/23/23 - 11:31 AM", Constants.READING, CPRExportCSVConstants.CUSTOM_READING_SELECTED_FILTERS, optionalFilter );
                break;
            case "MATH_GROUP_TEACHER":
                saveReportOptionalFilters.put( "additionalGrouping", "TEACHER" );
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                optionalFilter.put( "additionalGrouping", 1 );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "READING_GROUP_GRADE":
                saveReportOptionalFilters.put( "additionalGrouping", "GRADE" );
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "2", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                optionalFilter.put( "additionalGrouping", 2 );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.READING, null, optionalFilter );
                break;
            case "MATH_GROUP_GROUP":
                saveReportOptionalFilters.put( "additionalGrouping", "GROUP" );
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                optionalFilter.put( "additionalGrouping", 3 );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "FILTER_GRADE":
                saveReportOptionalFilters.put( "grades", Arrays.asList( "KG", "01" ) );
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                optionalFilter.put( "filterByGrade", Arrays.asList( "KG", "01" ) );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "default", requestId, "01/23/23 - 11:31 AM", Constants.MATH, null, optionalFilter );
                break;
            case "NO_REPORT_HEADER":
                exportType = "custom";
                saveAdminCPReportOptionResponse = Reports.saveAdminCPReportOption( headers, Arrays.asList( selectedSchoolId ), "1", saveReportOptionalFilters, false, "" );
                requestId = Reports.getRequestIdFromResponse( saveAdminCPReportOptionResponse.getBody().asString() );
                response = AdminReportCsv.postCPRExportCSVAPI( headers, Arrays.asList( selectedSchoolId ), "custom", requestId, "01/23/23 - 11:31 AM", Constants.MATH, new ArrayList<>(), optionalFilter );
                break;

        }
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

        if ( !scenarioType.equals( "NO_REPORT_HEADER" ) ) {
            //Verifying Request Id in the upload url and signed Url
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );

            //To get the CSV File
            String csvDataFromBS = null;
            // Get driver
            final WebDriver driver = WebDriverFactory.get( browser );
            try {
                driver.get( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "signedUrl" ) );
                csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            } catch ( Exception e ) {
                Log.message( "Getting Exception while download the csv file!!!!!" );
            } finally {
                driver.quit();
            }

            Log.assertThat( DevToolsUtils.countLines( csvDataFromBS ) > 0, "Record count is greater than zero", "Record count is zero" );
            Log.assertThat( checkHeader( csvDataFromBS, exportType ), "Expected Header is present", "Expected Header is not present" );
            Log.assertThat( countColumn( csvDataFromBS ) > 0, "Column count is " + countColumn( response.getBody().toString() ), "Expected column is not present" );
        }
    }

    @DataProvider
    public Object[][] getData() {
        Object[][] data = { { "TC:01", "200", "Verify 200 status code and response in case of Course with data - Default math", "CWD_MATH" },
                { "TC:02", "200", "Verify 200 status code and response in case of Custom Export Course with data - Math", "CUSTOM_MATH" },
                { "TC:03", "200", "Verify 200 status code and response in case of Custom Export Course with data - Reading", "CUSTOM_READING" },
                { "TC:04", "200", "Verify 200 status code and response in case of Course with data - Math Grouping by teacher", "MATH_GROUP_TEACHER" },
                { "TC:05", "200", "Verify 200 status code and response in case of Course with data - Reading Grouping by grade", "READING_GROUP_GRADE" },
                { "TC:06", "200", "Verify 200 status code and response in case of Course with data - Math Grouping by group", "MATH_GROUP_GROUP" },
                { "TC:07", "200", "Verify 200 status code and response in case of Course with data - Filter By grade", "FILTER_GRADE" },
                { "TC:08", "500", "Verify 500 status code and response in case of No report header pass in payload", "NO_REPORT_HEADER" } };
        return data;
    }

    public boolean checkHeader( String str, String exportType ) {
        if ( exportType.equals( "default" ) ) {
            return str.contains( "School Name" );
        } else {
            return str.contains( "organizationName" );
        }
    }

    public int countColumn( String str ) {
        String[] lines = str.split( "\r\n|\r|\n" );
        return lines[0].split( "," ).length;
    }

}
