package com.savvas.sm.reports.bff.admin.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.json.JSONArray;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;

import io.restassured.response.Response;

public class CPRMultiOrgList extends EnvProperties {

    String smUrl;
    Response response;
    String distAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String distAdminuserId;
    String districtId;
    String subDistUserName;
    String subDistAdminuserId;
    String subDistrictId;
    String schoolAdminUserName;
    String schoolAdminuserId;
    String subDistrictAdminDetails;
    String schoolAdminDetails;
    String schoolAdminId;
    List<String> schoolId = new ArrayList<>();
    List<String> schoolName = new ArrayList<>();
    Reports reports = new Reports();

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = "https://sm-reports-bff-srv-stack-dev.smdemo.info";

        RBSUtils rbsUtils = new RBSUtils();
        // Getting District admin username and password

        distAdminUserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        subDistUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        schoolAdminUserName = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );

        districtId = configProperty.getProperty( "district_ID" ).trim();
        subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );

        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        schoolName.add( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        schoolName.add( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );

        schoolId.add( rbsUtils.getOrganizationIDByName( districtId, schoolName.get( 0 ) ) );

        distAdminuserId = rbsUtils.getUserIDByUserName( distAdminUserName );

        subDistrictId = RBSDataSetup.subDistrictwithSchoolId;
        schoolAdminId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" );
        schoolId.add( rbsUtils.getOrganizationIDByName( districtId, schoolName.get( 1 ) ) );
        subDistAdminuserId = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, "userId" );
        schoolAdminuserId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "userId" );

    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-70208,SMK-69552", "Multi Org Selection", "API" }, priority = 1 )
    public void postAdminMultiOrgListTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + " - " + testcaseDescription );
        HashMap<String, String> headers = new HashMap<String, String>();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( distAdminUserName, password ) );
        headers.put( Constants.ORGID_SM_HEADER, districtId );
        headers.put( Constants.USERID_SM_HEADER, distAdminuserId );
        Response response = null;
        switch ( scenarioType ) {
            case "PASSING_SINGLE_ORGID":
                response = reports.getOrgNameList( smUrl, headers, schoolOrgId( Arrays.asList( schoolId.get( 0 ) ) ) );
                Log.message( response.getBody().asString() );
                Log.assertThat( schoolId.containsAll( getOrgDetails( response ).get( "orgId" ) ), "The Organization Id is displaying successfully", "The Organization Id is not displayed properly" );
                Log.assertThat( schoolName.containsAll( getOrgDetails( response ).get( "orgName" ) ), "The Organization Name  is displaying successfully", "The Organization Name is not displayed properly" );
                break;
            case "PASSING_MULTI_ORGID":
                response = reports.getOrgNameList( smUrl, headers, schoolOrgId( schoolId ) );
                Log.assertThat( schoolId.containsAll( getOrgDetails( response ).get( "orgId" ) ), "The Organization Id is displaying successfully", "The Organization Id is not displayed properly" );
                Log.assertThat( schoolName.containsAll( getOrgDetails( response ).get( "orgName" ) ), "The Organization Name  is displaying successfully", "The Organization Name is not displayed properly" );
                break;
            case "PASSING_ORGID_IN_SUB-DISTRICTADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subDistUserName, password ) );
                headers.put( Constants.ORGID_SM_HEADER, subDistrictId );
                headers.put( Constants.USERID_SM_HEADER, subDistAdminuserId );
                response = reports.getOrgNameList( smUrl, headers, schoolOrgId( Arrays.asList( schoolId.get( 0 ) ) ) );
                Log.assertThat( schoolId.containsAll( getOrgDetails( response ).get( "orgId" ) ), "The Organization Id is displaying successfully", "The Organization Id is not displayed properly" );
                Log.assertThat( schoolName.containsAll( getOrgDetails( response ).get( "orgName" ) ), "The Organization Name  is displaying successfully", "The Organization Name is not displayed properly" );
                break;
            case "PASSING_ORGID_IN_SCHOOLADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( schoolAdminUserName, password ) );
                headers.put( Constants.ORGID_SM_HEADER, schoolAdminId );
                headers.put( Constants.USERID_SM_HEADER, schoolAdminuserId );
                response = reports.getOrgNameList( smUrl, headers, schoolOrgId( Arrays.asList( schoolId.get( 0 ) ) ) );
                Log.assertThat( schoolId.containsAll( getOrgDetails( response ).get( "orgId" ) ), "The Organization Id is displaying successfully", "The Organization Id is not displayed properly" );
                Log.assertThat( schoolName.containsAll( getOrgDetails( response ).get( "orgName" ) ), "The Organization Name  is displaying successfully", "The Organization Name is not displayed properly" );
                break;
        }
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The Status code is expected " + expected_StatusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + expected_StatusCode + " and actual " + response.getStatusCode() + "is not Verified" );
        // Verifying schema in the Response body
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "adminCPRMultiOrg", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-70208,SMK-69552", "Multi Org Selection", "API" }, priority = 2 )
    public void postAdminMultiOrgListTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + " - " + testcaseDescription );
        HashMap<String, String> headers = new HashMap<String, String>();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( distAdminUserName, password ) );
        headers.put( Constants.ORGID_SM_HEADER, districtId );

        Response response = null;
        switch ( scenarioType ) {
            case "PASSING_EMPTY_USERID":
                response = reports.getOrgNameList( smUrl, headers, schoolOrgId( schoolId ) );
                Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message displayed as expected",
                        ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message not displayed as expected" );
                break;
            case "PASSING_EMPTY_ORGID_IN_HEADER":
                headers.put( Constants.USERID_SM_HEADER, distAdminuserId );
                headers.remove( Constants.ORGID_SM_HEADER );
                response = reports.getOrgNameList( smUrl, headers, schoolOrgId( schoolId ) );
                Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message displayed as expected",
                        ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE + " Message not displayed as expected" );
                break;
            case "PASSING_EMPTY_ORGID_IN_BODY":
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, distAdminuserId );
                response = reports.getOrgNameList( smUrl, headers, "" );
                Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.INVALID_MESSAGE_FOR_ORGID ), ReportsAPIConstants.INVALID_MESSAGE_FOR_ORGID + " Message displayed as expected",
                        ReportsAPIConstants.INVALID_MESSAGE_FOR_ORGID + " Message not displayed as expected" );
                break;

        }
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The Status code is expected " + expected_StatusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + expected_StatusCode + " and actual " + response.getStatusCode() + "is not Verified" );

    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC_Admin_Multi_Org_List_01", "200", "Verify state code and response when passing single orgId in request body.", "PASSING_SINGLE_ORGID" },
                { "TC_Admin_Multi_Org_List_02", "200", "Verify state code and response when passing multiple orgIds in request body.", "PASSING_MULTI_ORGID" },
                { "TC_Admin_Multi_Org_List_03", "200", "Verify state code and response for sub-district admin when passing orgId(s) in request body.", "PASSING_ORGID_IN_SUB-DISTRICTADMIN" },
                { "TC_Admin_Multi_Org_List_04", "200", "Verify state code and response for school admin when passing orgId(s) in request body.", "PASSING_ORGID_IN_SCHOOLADMIN" }, };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC_Admin_Multi_Org_List_05", "200", "Verify state code and response when passing empty user-id in header.", "PASSING_EMPTY_USERID" },
                { "TC_Admin_Multi_Org_List_06", "200", "Verify state code and response when passing empty org-id in header.", "PASSING_EMPTY_ORGID_IN_HEADER" },
                { "TC_Admin_Multi_Org_List_07", "200", "Verify state code and response when passing empty orgId in request body.", "PASSING_EMPTY_ORGID_IN_BODY" }, };

        return data;
    }

    /**
     * 
     * @param orgId
     * @return
     */
    public String schoolOrgId( List<String> orgId ) {
        String schlorgId = null;
        for ( int i = 0; i < orgId.size(); i++ ) {
            if ( Objects.isNull( schlorgId ) ) {
                schlorgId = "\"" + orgId.get( i ) + "\"";
            } else {
                schlorgId += ",\"" + orgId.get( i ) + "\"";
            }
        }
        Log.message( "Passing SchoolID in response body" + schlorgId );
        return schlorgId;
    }

    /**
     * 
     * @param response
     * @return
     */
    public HashMap<String, List<String>> getOrgDetails( Response response ) {
        String body = response.getBody().asString();
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( body, "data" );
        String keyVlu = SMUtils.getKeyValueFromResponse( keyValueFromResponse, "getOrganizationNameList" );
        JSONArray ja = new JSONArray( keyVlu );
        HashMap<String, List<String>> responseBody = new HashMap<>();
        List<String> bodyOrgId = new ArrayList<>();
        List<String> bodyOrgName = new ArrayList<>();

        for ( int i = 0; i < ja.length(); i++ ) {
            bodyOrgId.add( ja.getJSONObject( i ).get( "orgId" ).toString() );
            bodyOrgName.add( ja.getJSONObject( i ).get( "orgName" ).toString() );

        }
        responseBody.put( "orgId", bodyOrgId );
        responseBody.put( "orgName", bodyOrgName );
        return responseBody;
    }

}