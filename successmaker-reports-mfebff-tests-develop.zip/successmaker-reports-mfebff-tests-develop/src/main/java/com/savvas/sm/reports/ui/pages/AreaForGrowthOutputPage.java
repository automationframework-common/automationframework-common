package com.savvas.sm.reports.ui.pages;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.ReportTypes;
import com.savvas.sm.utils.SMUtils;

public class AreaForGrowthOutputPage extends LoadableComponent<AreaForGrowthOutputPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportOutputComponent reportOutputComponent;

    // ********* SM - AFG Report Page Elements ***************

    @FindBy ( css = "//h2[@class='header']" )
    WebElement page_title;

    @FindBy ( css = "p.description" )
    WebElement description;

    @FindBy ( css = "[alt='successmaker']" )
    WebElement smLogo;

    @FindBy ( xpath = "//span[text()='Report viewer']" )
    WebElement reportViewer;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[1]/th[1]" )
    WebElement strandColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[1]/th[2]" )
    WebElement levelColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[1]/th[3]" )
    WebElement skillDescColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[2]/th[3]" )
    WebElement studentColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[2]/th[4]" )
    WebElement dateAtRiskColumn;

    @FindBy ( xpath = "//table[@id='table']/thead[1]/tr[2]/th[5]" )
    WebElement targettedLessonColumn;
    
    @FindBy ( css = "dl.detail-row.legends" )
    List<WebElement> legendOptions;
    
    @FindBy ( xpath = "//table[@id='table']/tbody[1]/tr[1]/td[4]/div[1]" )
    WebElement targettedLessonFirstValue;

    @FindBy ( xpath = "//table[@id='table']/tbody[1]/tr[2]/td[2]/div[1]" )
    WebElement dateFormat;

    @FindBy ( css = ".ml-3.detail-row > dd" )
    WebElement reportRunDate;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement btnNextRoot;

    @FindBy ( css = "cel-button.back-btn" )
    WebElement btnBackRoot;

    @FindBy ( css = "div.header-pagination span" )
    List<WebElement> paginationText;

    @FindBy ( css = "input.pagination-text-field" )
    WebElement currentPageNumber;

    @FindBy ( css = "div .col-3 .list-head" )
    List<WebElement> headerLegend;

    @FindBy ( css = "div .col-3 .list-info" )
    WebElement headerLegendValue;

    @FindBy ( css = "dl.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;

    @FindBy ( css = "dl.ml-3 dt" )
    WebElement headerReportRun;

    @FindBy ( css = "dl.info dt" )
    List<WebElement> headersRowInfo;

    @FindBy ( css = "tbody > tr:nth-of-type(1) > td:nth-of-type(2) > .cell-data" )
    WebElement levelRisk;

    @FindBy ( css = "tbody > tr:nth-of-type(1) > .col-highlight > .cell-data" )
    WebElement strandName;

    @FindBy ( css = "tr.sub-header:nth-child(2)" )
    WebElement subHeaders;

    @FindBy ( css = "tr.areas-for-growth-row.skills:nth-child(n) > td:nth-child(4) a" )
    List<WebElement> targetedLessonValue;

    @FindBy ( xpath = "//span[@class='error-message']/span[.='Invalid']" )
    WebElement invalidGoToPage;

    @FindBy ( xpath = "//div[@class='text-field-container']" )
    WebElement requiredGoToPage;

    @FindBy ( xpath = "//span[@class='pagination-text-suffix']" )
    WebElement totalNoOfPages;

    @FindBy ( xpath = "//p[@class='risk-label mr-20']//span[1]" )
    WebElement totalSkillsAtRisk;

    @FindBy ( xpath = "//p[@class='risk-label mr-20']" )
    WebElement totalSkillsAtRiskHeader;

    @FindBy ( xpath = "//p[@class='risk-label']//span[1]" )
    WebElement totalStudentsAtRisk;

    @FindBy ( css = "p:nth-of-type(2)" )
    WebElement totalStudentsAtRiskHeader;

    @FindBy ( css = "cel-icon-button.file.hydrated" )
    WebElement pdfButton;

    @FindBy ( css = " cel-icon-button.file-doc.hydrated" )
    WebElement docButton;

    @FindBy ( css = "td.skill-description" )
    List<WebElement> allSkillsDesc;

    @FindBy ( xpath = "(//div[@class='cell-data'])[1]" )
    WebElement firstSkillDesc;

    @FindBy ( css = "div.section-risk p:nth-child(1)" )
    WebElement totalSkillsCount;

    @FindBy ( css = "div.section-risk p:nth-child(2) span" )
    WebElement totalAtRiskCount;

    @FindBy ( css = "tr.students td:nth-child(1)" )
    List<WebElement> distinctStudents;

    @FindBy ( xpath = "//tbody[1]/tr[2]/td[1]/div[@class='cell-data']" )
    WebElement firstStudentName;

    @FindBy ( css = "h3.assignment-name.ml-3" )
    WebElement assignmentName;

    @FindBy ( css = "span.ml-2" )
    WebElement headerSelectedOptions;

    @FindBy ( css = "li:nth-of-type(1)" )
    WebElement noAdditionalGrouping;

    @FindBy ( css = "li:nth-of-type(2)" )
    WebElement sortByStrand;

    @FindBy ( css = "li:nth-of-type(3)" )
    WebElement showAllDatesAtRisk;

    @FindBy ( css = "tr.students td:nth-child(2)" )
    List<WebElement> dateAtRiskValues;

    @FindBy ( css = "li:nth-of-type(4)" )
    WebElement noOfGroupsSelected;

    @FindBy ( css = "p.header.mt-1.mb-1" )
    WebElement noDataToDisplay;

    @FindBy ( css = ".info > dd:nth-of-type(1)" )
    WebElement schoolName;

    @FindBy ( css = ".info > dd:nth-of-type(2)" )
    WebElement teacherName;

    @FindBy ( css = ".info > dd:nth-of-type(3)" )
    WebElement gradesSelected;

    @FindBy ( css = ".info > dd:nth-of-type(4)" )
    WebElement groupsSelected;

    @FindBy ( css = "//span[contains(.,'SMMA_LO')]" )
    List<WebElement> loNumbers;

    public String fontFamily = "Poppins-SemiBold";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public AreaForGrowthOutputPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportOutputComponent = new ReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, description );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, description, 30 ) ) {
            Log.message( "Area For Growth Page loaded successfully." );
        } else {
            Log.fail( "Area For Growth Page not loaded successfully." );
        }

    }

    /**
     * Verifying the Areas for Growth Report page
     */
    public boolean isAreasForGrowthReportPageLoaded() {
        boolean flag = false;
        if ( SMUtils.isElementPresent( page_title ) ) {
            flag = true;
            Log.message( "Areas For Growth Report OutputPage is loaded Successfully!!" );
        }
        return flag;
    }

    /**
     * To verify the Report Title in the Output Page
     */
    public boolean checkReportTitleAndFontAfterRun() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.xpath( "//h2[@class='header']" ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.xpath( "//h2[@class='header']" ) ), 5000 );
            WebElement outputTitle = driver.findElement( By.xpath( "//h2[@class='header']" ) );
            String outputTitleFont = SMUtils.getFontFamily( outputTitle );
            Log.assertThat( outputTitle.getText().equals( ReportTypes.AREAS_FOR_GROWTH ), "AFG Ttile is displayed in Output Page", "AFG Ttile is not displayed in Output Page" );
            Log.assertThat( outputTitleFont.equals( fontFamily ), "AFG Ttile is displayed as Bold in Output Page", "AFG Ttile is not displayed as Bold in Output Page" );
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Header not found" );
        }
        return false;
    }

    /**
     * To verify the presence of 'report viewer' text in the Output Page
     */
    public boolean checkReportViewer() {
        Boolean status = false;
        SMUtils.waitForElement( driver, reportViewer );
        String reportViewerText = "Report Viewer";
        if ( SMUtils.verifyWebElementTextEqualsIgnoreCase( reportViewer, reportViewerText ) ) {
            Log.message( "Report Viewer Text is getting displayed" );
            status = true;

        } else {
            Log.message( "Report Viewer Text is not getting displayed" );
        }
        return status;
    }

    /**
     * To verify the presence of SM Logo text in the Output Page
     */
    public boolean checkSMLogo() {
        SMUtils.waitForElement( driver, smLogo );
        try {
            SMUtils.isElementPresent( smLogo );
            Log.message( "SM Logo Found!" );
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "SM Logo Not Found" );
        }
        return false;
    }

    /**
     * To verify the presence of "Strand, Level and Skill Description" columns
     * in the Output Page
     */
    public boolean isParentColumnsdisplayed() {
        SMUtils.waitForElement( driver, strandColumn );
        SMUtils.waitForElement( driver, levelColumn );
        SMUtils.waitForElement( driver, skillDescColumn );
        try {
            SMUtils.isElementPresent( strandColumn );
            Log.message( "Strand Column is getting displayed!" );
            SMUtils.isElementPresent( levelColumn );
            Log.message( "Level Column is getting displayed!" );
            SMUtils.isElementPresent( skillDescColumn );
            Log.message( "Skill Description Column is getting displayed!" );
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Strand, Level and Skill Description columns are not displayed " );
        }
        return false;
    }

    /**
     * To verify the presence of "Student. Date At Risk and Targetted Lesson"
     * columns in the Output Page
     */
    public boolean ischildColumnsdisplayed() {
        SMUtils.waitForElement( driver, studentColumn );
        SMUtils.waitForElement( driver, dateAtRiskColumn );
        SMUtils.waitForElement( driver, targettedLessonColumn );
        try {
            SMUtils.isElementPresent( studentColumn );
            Log.message( "Student Column is getting displayed!" );
            SMUtils.isElementPresent( levelColumn );
            Log.message( "Date at Risk Column is getting displayed!" );
            SMUtils.isElementPresent( targettedLessonColumn );
            Log.message( "Targetted Lesson Column is getting displayed!" );
            return true;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Student, Date at Risk and Targetted Lesson columns are not displayed " );
        }
        return false;
    }

    /**
     * To verify the Date Format of Date at Risk in the Output Page
     */
    public boolean validateDateFormat() {
        SMUtils.waitForElement( driver, dateFormat );
        List<String> dateAtRisk = SMUtils.getAllTextFromWebElementList( dateAtRiskValues );
        String actualDateFormat = dateAtRisk.get( 0 );
        Log.message( "Actual Date Format is:" + actualDateFormat );
        DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendPattern( "MM/dd/yyyy" ).toFormatter();
        LocalDate localDate = LocalDate.parse( actualDateFormat, formatter );
        Log.message( localDate.format( formatter ) );
        return true;
    }

    /**
     * To check the background color of Back button
     */
    public boolean checkColorOfBackButton() {
        Log.message( "Verifying the background color of the Back button" );
        SMUtils.waitForElement( driver, btnBackRoot );
        try {
            SMUtils.checkBackgroundColor( btnBackRoot, ReportsUIConstants.AFGReportConstants.BG_COLOR_BACK_BUTTON );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Error in getting bg color of the back button! " );
        }
        return true;
    }

    /**
     * To check the background color of Next button
     * 
     */
    public boolean checkColorOfNextButton() {
        Log.message( "Verifying the background color of the Next button" );
        SMUtils.waitForElement( driver, btnNextRoot );
        try {
            SMUtils.checkBackgroundColor( btnNextRoot, ReportsUIConstants.AFGReportConstants.BG_COLOR_NEXT_BUTTON );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Error in getting bg color of the next button! " );
        }
        return true;
    }

    /**
     * To check the active state of Back button
     * 
     */
    public boolean isBackButtonDisabled() {
        Boolean status = true;
        SMUtils.waitForElement( driver, btnBackRoot );
        try {
            status = false;
            SMUtils.isElementEnabled( btnBackRoot );
            Log.message( "Is Back Button Enabled  " + status );
        } catch ( Exception e ) {
            Log.message( "Is Back Button Disabled  " + status );
            status = true;
        }
        return status;
    }

    /**
     * To check the active state of Next button
     * 
     */
    public boolean isNextButtonDisabled() {
        Boolean status = true;
        SMUtils.waitForElement( driver, btnNextRoot );
        try {
            status = false;
            SMUtils.isElementEnabled( btnNextRoot );
            Log.message( "Is Next Button Enabled  " + status );
        } catch ( Exception e ) {
            Log.message( "Is Next Button Disabled  " + status );
            status = true;
        }
        return status;
    }

    /**
     * To verify total number of pages in the Report Output
     * 
     * @return totalReportPages
     */
    public int totalPages() {
        Log.message( "Checking Total available pages in Report" );
        SMUtils.waitForElement( driver, currentPageNumber );
        String totalPage = SMUtils.getTextOfWebElement( paginationText.get( 1 ), driver ).split( " " )[1];
        Log.message( "Total No of Pages:" + totalPage );
        String prefix = SMUtils.getTextOfWebElement( paginationText.get( 0 ), driver );
        String suffix = SMUtils.getTextOfWebElement( paginationText.get( 1 ), driver );
        String.format( ReportsUIConstants.PAGINATION_TEXT, totalPage ).equals( prefix + suffix );
        int totalReportPages = Integer.parseInt( totalPage );
        return totalReportPages;
    }

    /**
     * To verify the Invalid message get displayed when wrong inputs is given in
     * Pagination
     * 
     */
    public boolean isInvalidMsgDisplayed() {
        Log.message( "Validating 'invalid' message in the Go To Pagination" );
        SMUtils.waitForElement( driver, invalidGoToPage );
        return SMUtils.isElementPresent( invalidGoToPage );
    }

    /**
     * To verify the Total Skills At Risk is get displayed in output Page
     * 
     */
    public boolean isTotalSkillsAtRiskDisplayed() {
        SMUtils.waitForElement( driver, totalSkillsAtRisk );
        SMUtils.isElementPresent( totalSkillsAtRiskHeader );
        String toTalSkillsRisk = SMUtils.getTextOfWebElement( totalSkillsAtRisk, driver );
        Log.message( "Total Skills At Risk :  " + toTalSkillsRisk );
        return SMUtils.isElementPresent( totalSkillsAtRisk );
    }

    /**
     * To verify the Total Students At Risk is get displayed in output Page
     * 
     */
    public boolean isTotalStudentsAtRiskDisplayed() {
        SMUtils.waitForElement( driver, totalStudentsAtRisk );
        SMUtils.isElementPresent( totalStudentsAtRiskHeader );
        String toTalStudentsRisk = SMUtils.getTextOfWebElement( totalStudentsAtRisk, driver );
        Log.message( "Total Students At Risk:  " + toTalStudentsRisk );
        return SMUtils.isElementPresent( totalStudentsAtRisk );
    }

    /**
     * To get the Total Skills At Risk in output Page
     * 
     * @return totalSkillsAtRiskCount
     */
    public int getTotalSkillsAtRiskValue() {
        SMUtils.waitForElement( driver, totalSkillsAtRisk );
        String toTalSkillsRisk = SMUtils.getTextOfWebElement( totalSkillsAtRisk, driver );
        int totalSkillsAtRiskCount = Integer.parseInt( toTalSkillsRisk );
        Log.message( "Total Skills At Risk :  " + toTalSkillsRisk );
        return totalSkillsAtRiskCount;
    }

    /**
     * To validate the name of an assignment is displayed in output page
     * 
     * @return
     */
    public boolean isAssignmentNameDisplayed() {
        Log.message( "Verifying the presence of an assignment name" );
        SMUtils.waitForElement( driver, assignmentName );
        String nameOfAssignment = SMUtils.getTextOfWebElement( assignmentName, driver );
        Log.message( "Assignment Name is :  " + nameOfAssignment );
        return SMUtils.isElementPresent( assignmentName );
    }

    /**
     * To verify the Required message get displayed when no inputs is given in
     * Pagination
     * 
     * @return
     */
    public boolean isRequiredMsgDisplayed() {
        Log.message( "Validating 'required' message in the Go To Pagination" );
        SMUtils.waitForElement( driver, currentPageNumber );
        currentPageNumber.clear();
        SMUtils.waitForElement( driver, requiredGoToPage );
        return SMUtils.isElementPresent( requiredGoToPage );
    }

    /**
     * To verify the PDF icon is getting displayed in output page
     * 
     * @return
     */
    public boolean isPDFIconDisplayed() {
        Log.message( "Validating 'PDF Icon'next to the Go To Pagination" );
        SMUtils.waitForElement( driver, pdfButton );
        return SMUtils.isElementPresent( pdfButton );
    }

    /**
     * To verify the DOC icon is getting displayed in output page
     * 
     * @return
     */
    public boolean isDOCIconDisplayed() {
        Log.message( "Validating 'Doc Icon'next to the Go To Pagination" );
        SMUtils.waitForElement( driver, docButton );
        return SMUtils.isElementPresent( docButton );
    }

    /**
     * To list the default actual selected options is present in output page
     * 
     * @return actlistOfSelectedOptions
     */
    public ArrayList<String> defaultSelectedOptions() {
        String actAddtlGrouping = AFGReportConstants.NO_ADDITIONAL_GROUPING;
        String actSortStrand = AFGReportConstants.SORT_BY_STRAND;
        String actDatesAtRisk = AFGReportConstants.SHOW_ALL_DATES_AT_RISK;
        //String actNoOfgrps = AreasForGrowthConstants.NUMBER_OF_GROUPS_SELECTED;
        ArrayList<String> actlistOfSelectedOptions = new ArrayList<String>();
        actlistOfSelectedOptions.add( actAddtlGrouping );
        actlistOfSelectedOptions.add( actSortStrand );
        actlistOfSelectedOptions.add( actDatesAtRisk );
        //actlistOfSelectedOptions.add(actNoOfgrps);
        Log.message( "List of Actual Options: " + actlistOfSelectedOptions );
        return actlistOfSelectedOptions;
    }

    /**
     * To list the default actual selected options is present in output page
     * 
     * @return actlistOfSelectedOptions
     */
    public ArrayList<String> actualSelectedOptions() {
        String actAddtlGrouping = AFGReportConstants.ADDITIONAL_GROUPING_BY_GROUP;
        String actSortStrand = AFGReportConstants.SORT_BY_LEVEL;
        ArrayList<String> actlistOfSelectedOptions = new ArrayList<String>();
        actlistOfSelectedOptions.add( actAddtlGrouping );
        actlistOfSelectedOptions.add( actSortStrand );
        Log.message( "List of Actual Options: " + actlistOfSelectedOptions );
        return actlistOfSelectedOptions;
    }

    /**
     * To get the Zero state message present in output page
     * 
     * @return actlistOfSelectedOptions
     */
    public String getZeroStateMessage() {
        SMUtils.waitForElement( driver, noDataToDisplay );
        SMUtils.isElementPresent( noDataToDisplay );
        String zeroStateMsg = SMUtils.getTextOfWebElement( noDataToDisplay, driver );
        Log.message( "Zero State Msg is :  " + zeroStateMsg );
        return zeroStateMsg;
    }

    /**
     * To get the Levels and the Strands
     * 
     * @return
     * @return
     */
    public boolean isLevelandStrandsDisplayed() {
        String levelValue = SMUtils.getTextOfWebElement( levelRisk, driver );
        String strandValue = SMUtils.getTextOfWebElement( strandName, driver );
        Log.message( "Level Value is: " + levelValue + "  Strand Value is: " + strandValue );
        return true;
    }

    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabelsForMath() {
        Log.event( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if ( SMUtils.waitForElement( driver, headerLegendValue ) ) {
            SMUtils.getAllTextFromWebElementList( headerLegend ).containsAll( ReportsUIConstants.AFGReportConstants.LEGEND_HEADERS );
            String lablesOfMath = SMUtils.getTextOfWebElement( headerLegendValue, driver );
            lablesOfMath.equals( ReportsUIConstants.AFGReportConstants.LEGEND_VALUE );
            IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.AFGReportConstants.MATH_LEGEND_LABELS.get( itr ) ) );
            IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.AFGReportConstants.MATH_LEGEND_LABELS_VALUES.get( itr ) ) );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }

    
    /**
     * Get Legends options
     * 
     * @return
     */
    public List<String> getLegendOptions() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( legendOptions ) );
        Log.message( "Getting the all the legend options" );
        List<String> allTextFromWebElementList = SMUtils.getAllTextFromWebElementList( legendOptions );
        return allTextFromWebElementList;}
        
    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabelsForReading() {
        Log.event( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if ( SMUtils.waitForElement( driver, headerLegendValue ) ) {
            SMUtils.getAllTextFromWebElementList( headerLegend ).containsAll( ReportsUIConstants.AFGReportConstants.LEGEND_HEADERS );
            String labelsOfReading = SMUtils.getTextOfWebElement( headerLegendValue, driver );
            labelsOfReading.equals( ReportsUIConstants.AFGReportConstants.LEGEND_VALUE );
            IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.AFGReportConstants.READING_LEGEND_LABELS.get( itr ) ) );
            IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.AFGReportConstants.READING_LEGEND_LABELS_VALUES.get( itr ) ) );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }

    /**
     * To verify the Info Header values are displaying
     */
    public boolean isInfoHeaderValuesDisplaying() {
        SMUtils.isElementPresent( schoolName );
        SMUtils.isElementPresent( teacherName );
        SMUtils.isElementPresent( gradesSelected );
        SMUtils.isElementPresent( groupsSelected );
        String schoolValue = SMUtils.getTextOfWebElement( schoolName, driver );
        String teacherValue = SMUtils.getTextOfWebElement( teacherName, driver );
        String selcetedGradesValue = SMUtils.getTextOfWebElement( gradesSelected, driver );
        String selectedGroupsValue = SMUtils.getTextOfWebElement( groupsSelected, driver );
        Log.message( "Info Header Values are:  " + schoolValue + "  " + teacherValue + "  " + selcetedGradesValue + "  " + selectedGroupsValue );
        return true;
    }

    /**
     * To get Skills Description values
     */
    public List<String> getSkillDescription() {
        List<String> allSkillsDescription = SMUtils.getAllTextFromWebElementList( allSkillsDesc );
        Log.message( "List of Skills Description: " + allSkillsDescription );
        return allSkillsDescription;
    }

    /**
     * To get first Skills Description value
     * 
     * @return
     */
    public String getFirstSkillDesc() {
        Log.message( "Validating Skill Desc Names are present or not" );
        SMUtils.waitForElement( driver, firstSkillDesc );
        String firstSkillDescValue = SMUtils.getTextOfWebElement( firstSkillDesc, driver );
        return firstSkillDescValue;
    }

    /**
     * To get Report Run Date
     * 
     * @return
     */
    public String getReportRunDate() {
        SMUtils.waitForElement( driver, reportRunDate );
        String reportRunDateValue = SMUtils.getTextOfWebElement( reportRunDate, driver );
        return reportRunDateValue;
    }

    /**
     * To validate Report Run Date is in Prescribed Format
     * 
     * @return
     */
    public boolean validateReportRunDate() {
        SMUtils.waitForElement( driver, reportRunDate );
        String reportRunDate1 = SMUtils.getTextOfWebElement( reportRunDate, driver );
        Log.message( "Report Timestamp: " + reportRunDate1 );
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "MM/dd/yy '-' hh:mm a" );
        Log.message( "Formatted Date : " + formatter.format( OffsetDateTime.now() ) );
        // Change it to contains method when sometimes Report Run time in BS is different than the local one
        Log.assertThat( formatter.format( OffsetDateTime.now() ).equalsIgnoreCase( reportRunDate1 ), "ReportRun Date and Time is Matching", "ReportRun Date and Time is not Matching" );
        return true;
    }

    /**
     * To validate whether LO number is displayed in output page
     * 
     * @return
     */
    public boolean isLONumberDisplayed() {
        List<String> allSkillsDescription = SMUtils.getAllTextFromWebElementList( allSkillsDesc );
        try {
            SMUtils.getMachingTextElementFromList( allSkillsDesc, "LO" );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return true;

    }

    /**
     * To get Skills count value
     */
    public WebElement getTotalSkillsCount() {
        Log.message( "List of skills Description:  " + totalSkillsAtRisk );
        return totalSkillsAtRisk;
    }

    /**
     * To get List of all students in Report output page
     */
    public List<String> getAllStudents() {
        List<String> allStudents = SMUtils.getAllTextFromWebElementList( distinctStudents );
        Log.message( "List of Students : " + allStudents );
        return allStudents;
    }

    /**
     * To get Skills count value in Report output page
     */
    public WebElement getAtRiskSkillsCount() {
        return totalAtRiskCount;
    }

    /**
     * To get All Date at Risk Values in Report output page
     */
    public List<String> getAllDateAtRisk() {
        List<String> dateAtRisk = SMUtils.getAllTextFromWebElementList( dateAtRiskValues );
        Log.message( "List of Date At Risk Values : " + dateAtRisk );
        return dateAtRisk;
    }

    /**
     * To get All Targeted Lesson Values in Output Page
     */
    public List<String> targetedLessonColumn() {
        Log.message( "Getting Targeted Lessons" );
        SMUtils.waitForElement( driver, subHeaders );
        return targetedLessonValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /**
     * To Validate Targeted Lesson related scenarios
     */
    public boolean validateTargettedLesson() {
        SMUtils.waitForElement( driver, subHeaders );
        boolean isRoleExpected = false;
        List<String> valuesOfTargettedLessons = targetedLessonValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
        Log.message( "Values of Targetted Lessons: " + valuesOfTargettedLessons );
        if ( valuesOfTargettedLessons.isEmpty() ) {
            Log.message( "Targetted Lessons has no Values!" );

        } else {
            Log.message( "Targetted Lessons has Values!" );
            isRoleExpected = SMUtils.verifyCssPropertyForElement( targettedLessonFirstValue, AFGReportConstants.ROLE_CSS_PROPERTY, AFGReportConstants.ROLE_CSS_VALUE );
            Log.message( "Role of TargettedLesson is Link" );
            SMUtils.clickJS( driver, targetedLessonValue.get( 0 ) );
        }
        return isRoleExpected;
    }

}
