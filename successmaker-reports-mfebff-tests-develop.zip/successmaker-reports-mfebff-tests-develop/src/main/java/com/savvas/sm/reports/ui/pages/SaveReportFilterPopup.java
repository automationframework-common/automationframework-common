package com.savvas.sm.reports.ui.pages;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Select;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

public class SaveReportFilterPopup extends LoadableComponent<SaveReportFilterPopup> {

    private final WebDriver driver;
    boolean isPageLoaded;

    @FindBy ( css = " cel-modal.save-report-modal" )
    WebElement saveReportPopup;

    @FindBy ( css = "div.new-report cel-text-field" )
    WebElement newReportConfigurationLabel;
    
    @FindBy ( css = "cel-text-field[class='hydrated']" )
    WebElement savedOptionTextFieldRoot;

    @FindBy ( css = "cel-text-field.hydrated" )
    WebElement saveReportTextRoot;

    @FindBy ( css = "div.existing-report label" )
    WebElement existingReportConfigurationLabel;

    @FindBy ( css = "#savedReportSelect > div > cel-single-select" )
    WebElement existingSavedOptionDropdown;

    @FindBy ( css = "cel-modal.save-report-modal" )
    WebElement saveReportPopupParent;

    @FindBy ( css = "div.or-line span" )
    WebElement or_line;
    
    @FindBy ( css = "cel-text-field[class='hydrated']" )
    WebElement studentPerformanceSavedOptionTextFieldRoot;
    
    // child elements
    private String label = "label";
    private String input = "div>label input";
    private String cancelButtonRoot = "cel-button.cancel-button";
    private String saveButtonRoot = "cel-button.ok-button";
    private String button = "button";
    private String dropdown = "select#dropdown";
    private String errorMessage = "span.error-message";
    private String dropdownOptions = "cel-single-select-item";
    private String closeIcon = "cel-icon-button.close-button";
    private String saveReportPopupHeaderChild = "h1.header";
    private String errorMessageChildCSS = "span.error-message";
    private String existingSavedReportsCSS = "ul.single-dropdown li.item";
    private String childSavedReportArrow = "cel-icon";
    private String savedReportTextFieldChild = ".text-field";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public SaveReportFilterPopup( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, saveReportPopup );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, saveReportPopup, 30 ) ) {
            Log.message( "Save Report popup loaded successfully." );
        } else {
            Log.fail( "Save Report popup not loaded successfully." );
        }
    }

    /**
     * To get the label for new custom report configuration
     * 
     * @return
     */
    public String getLabelForNewCustomReportConfiguration() {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        return SMUtils.getWebElementDirect( driver, newReportConfigurationLabel, label ).getText().trim();
    }

    /**
     * To get the label for existing report configuration
     * 
     * @return
     */
    public String getLabelForExistingReportConfiguration() {
        SMUtils.waitForElement( driver, existingReportConfigurationLabel );
        return existingReportConfigurationLabel.getText().trim();
    }

    /**
     * To verify the cancel button is displayed or not
     * 
     * @return
     */
    public boolean isCancelButtonDisplayed() {
        SMUtils.waitForElement( driver, saveReportPopup );
        return SMUtils.getWebElementDirect( driver, saveReportPopup, cancelButtonRoot, button ).isDisplayed();
    }

    /**
     * To verify the Save button is displayed or not
     * 
     * @return
     */
    public boolean isSaveButtonDisplayed() {
        SMUtils.waitForElement( driver, saveReportPopup );
        return SMUtils.getWebElementDirect( driver, saveReportPopup, saveButtonRoot, button ).isDisplayed();
    }

    /**
     * To verify the Save button is Enabled or not
     * 
     * @return
     */
    public boolean isSaveButtonEnabled() {
        SMUtils.waitForElement( driver, saveReportPopup );
        return SMUtils.getWebElementDirect( driver, saveReportPopup, saveButtonRoot, button ).isEnabled();
    }

    /**
     * To click cancel button
     * 
     * @return
     */
    public void clickCancelButton() {
        SMUtils.waitForElement( driver, saveReportPopup );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, saveReportPopup, cancelButtonRoot, button ) );
        Log.message( "Clicked cancel button in save report popup" );
    }

    /**
     * To click Save button
     * 
     * @return
     */
    public void clickSaveButton() {
        SMUtils.waitForElement( driver, saveReportPopup );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, saveReportPopup, saveButtonRoot, button ) );
        Log.message( "Clicked Save button in save report popup" );
    }

    /**
     * To click Text Box
     * 
     * @return
     */
    public void clickTextBox() {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, newReportConfigurationLabel, input ) );
        Log.message( "Clicked save report popup textbox" );
    }

    /**
     * To Enter text in new report configuration text box
     * 
     */
    public void enterTextInNewReportFilterConfigurationTextBox( String text ) {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        WebElement textBox = SMUtils.getWebElementDirect( driver, newReportConfigurationLabel, input);
        WebElement textBox1 = SMUtils.getWebElement( driver, newReportConfigurationLabel, input);
        while ( true ) {
        	SMUtils.waitForElement(driver, textBox1);
            SMUtils.enterValue( textBox1 , text );
            if ( textBox1.getAttribute( "value" ).equals( text ) ) {
                break;
            }
        }
    }
    
    /**
     * Enter Text in Search Bar
     * 
     * @return
     */
    public void enterTextInSearchBar( String text ) {
        WebElement searchBar = SMUtils.getWebElement( driver, newReportConfigurationLabel, input );
   //     WebElement searchBar = SMUtils.getWebElement( driver, atualElementParent, searchfieldChild );
        SMUtils.clickJS( driver, searchBar );
        searchBar.clear();
        searchBar.sendKeys( text );
        Log.message( "Entered value as: " + text );

 

    }
    
    /**
     * To enter text in Save Report textbox
     * 
     * @return
     */
    public void enterNameInNewReportFilterConfigurationTextBox( String title ) {
        SMUtils.waitForElement( driver, savedOptionTextFieldRoot );
        WebElement textField = SMUtils.getWebElementDirect( driver, savedOptionTextFieldRoot, savedReportTextFieldChild );
        SMUtils.clickJS( driver, textField );
        textField.clear();
        textField.sendKeys( title );
        Log.message( "Entered value as: " + title );

    }

    /**
     * To get the error message
     * 
     * @return
     */
    public String getErrorMessage() {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        return SMUtils.getWebElementDirect( driver, newReportConfigurationLabel, errorMessage ).getText().trim();
    }

    /**
     * To get the error message
     * 
     * @return
     */
    public String getSaveErrorMessage() {
        SMUtils.waitForElement( driver, saveReportTextRoot );
        return SMUtils.getWebElementDirect( driver, saveReportTextRoot, errorMessage ).getText().trim();
    }

    /**
     * To verify the existing Filter option dropdown enabled or not
     * 
     */
    public boolean isExistingReportOptionDropdownEnabled() {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );

        return SMUtils.getWebElementDirect( driver, existingSavedOptionDropdown, dropdown ).isEnabled();

    }

    /**
     * To expand the existing Filter option dropdown
     * 
     */
    public void expandExistingReportOptionDropdown() {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );

        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, existingSavedOptionDropdown, dropdown ) );

        Log.message( "Expanded Existing report option dropdown." );
    }

    /**
     * To select option in the existing Filter option drop-down
     * 
     */
    public void selectOptionInExistingSavedOptiondropdown( String filterName ) {
        expandExistingReportOptionDropdown();
        SMUtils.nap( 4 );
        WebElement optionElement = SMUtils.getWebElement( driver, existingSavedOptionDropdown, dropdown );
        Select select = new Select( optionElement );
        select.selectByVisibleText( filterName );
        Log.message( "Selected " + filterName + "option in dropdown!" );
    }

    /**
     * To Click Close icon
     */
    public void clickCloseIcon() {
        SMUtils.waitForElement( driver, saveReportPopup );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, saveReportPopup, closeIcon, button ) );
        Log.message( "Clicked cancel icon(x) in save report popup!" );
    }

    /**
     * Get Save Report Option Header Text
     */
    public String getReportPopupHeaderText() {
        SMUtils.waitForElement( driver, saveReportPopupParent );
        WebElement header = SMUtils.getWebElementDirect( driver, saveReportPopupParent, saveReportPopupHeaderChild );
        return header.getText().trim();
    }

    /**
     * verify the Text in new report configuration text box
     * 
     */
    public boolean verifyTextFromNewReportFilterConfigurationTextBox( String text ) {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        return SMUtils.getWebElementDirect( driver, newReportConfigurationLabel, input ).getAttribute( "aria-placeholder" ).equals( text );
    }

    /**
     * verify the horizontal line with the text "OR" Present
     * 
     */
    public boolean verifyHorizontalLineWithTextOR( String Text ) {
        SMUtils.waitForElement( driver, or_line );
        return or_line.getText().trim().equals( Text );
    }

    /**
     * To verify the existing Filter option dropdown isdisplayed or not
     * 
     */
    public boolean isExistingReportOptionDropdownDisplayed() {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );
        return SMUtils.getWebElementDirect( driver, existingSavedOptionDropdown, button ).isDisplayed();
    }

    /**
     * To click cancel button
     * 
     * @return
     */
    public String verifyCancleButtonColor() {
        SMUtils.waitForElement( driver, saveReportPopup );
        WebElement CancleBtn = SMUtils.getWebElementDirect( driver, saveReportPopup, cancelButtonRoot, button );
        String btnColor = CancleBtn.getCssValue( "color" );
        String hexColor = Color.fromString( btnColor ).asHex();
        Log.message( "Hex color of Cancle Button is : " + hexColor );
        return hexColor;
    }

    /**
     * To Return the error message
     * 
     * @return
     */
    public String verifyErrorMessage() {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        WebElement errorMessage = SMUtils.getWebElementDirect( driver, newReportConfigurationLabel, errorMessageChildCSS );
        String color = errorMessage.getCssValue( "color" );
        String hexColor = Color.fromString( color ).asHex();
        Log.message( "Hex color of Error Message Text is : " + hexColor );
        return errorMessage.getText().trim();
    }

    /**
     * To expand the existing Filter option dropdown
     * 
     */
    public List<WebElement> getExistingReportOptionFromDropdown() {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );
        List<WebElement> savedReportOptions = SMUtils.getWebElementsDirect( driver, existingSavedOptionDropdown, existingSavedReportsCSS );
        Log.message( "Getting Saved Report Options." );
        return savedReportOptions;
    }
    
    
    /**
     * To verify the Help Icon(?) in Save Report Option Pop-up modal
     * 
     * @return
     */
    public boolean isHelpIconInHeaderDisplayed() {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        JavascriptExecutor jse =(JavascriptExecutor)driver;
        WebElement textBox = (WebElement)jse.executeScript("return document.querySelector('cel-modal').shadowRoot.querySelector('div > cel-icon').shadowRoot.querySelector('div > svg')" );
        return textBox.isDisplayed();
    }
    
    
    /**
     * To verify the Save Report Options Header in Save Report Option Pop-up modal
     * 
     * @return
     */
    public boolean isSaveReportOptionsHeaderDisplayed() {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        JavascriptExecutor jse =(JavascriptExecutor)driver;
        WebElement textBox = (WebElement)jse.executeScript("return document.querySelector('cel-modal').shadowRoot.querySelector('div > h1')" );
        Log.message( "Header Value in 'Save Report Option' is: " + textBox.getText() );
        Log.message( "Header CSS property in 'Save Report Option' is: " + textBox.getCssValue( "display" ) );
        textBox.getCssValue( "display" ).equalsIgnoreCase( "block" );
        return  textBox.getText().equalsIgnoreCase( ReportsUIConstants.SAVE_REPORT_OPTIONS );
    }
    
    
    /**
     * To get the value from New Report Filter input Text Box in the Save Report Option pop-up modal
     * 
     * @return
     */
    public boolean ValidateNewReportFilterPlaceholder(String value) {
        SMUtils.waitForElement( driver, newReportConfigurationLabel );
        JavascriptExecutor jse =(JavascriptExecutor)driver;
        WebElement textBox = (WebElement)jse.executeScript("return document.querySelector('cel-text-field').shadowRoot.querySelector('input')" );
        String placeHolderValue = textBox.getAttribute( "aria-placeholder" );
        Log.message( "New Report Filter PlaceHolder Value From UI: " + placeHolderValue );
        return textBox.getAttribute( "aria-placeholder" ).equalsIgnoreCase( value );
    }

    
    /**
     * To enter text in Save Report textbox
     * 
     * @return
     */
    public void enterNameForSaveReport( String title ) {
        SMUtils.waitForElement( driver, studentPerformanceSavedOptionTextFieldRoot );
        WebElement textField = SMUtils.getWebElementDirect( driver, studentPerformanceSavedOptionTextFieldRoot, savedReportTextFieldChild );
        SMUtils.clickJS( driver, textField );
        textField.clear();
        textField.sendKeys( title );
        Log.message( "Entered value as: " + title );
    }

    
    /**
     * To click Text Box in the Save Report Option pop-up modal
     * 
     * @return
     */
    public boolean ValidateExistingReportFilterPlaceholder(String value) {
        SMUtils.waitForElement( driver, existingSavedOptionDropdown );
        JavascriptExecutor jse =(JavascriptExecutor)driver;
        WebElement textBox = (WebElement)jse.executeScript("return document.querySelector('#savedReportSelect > div > cel-single-select').shadowRoot.querySelector('#dropdown > option:nth-child(1)')" );
        String placeHolderValue = textBox.getText();
        Log.message( "Existing Report Filter PlaceHolder Value From UI: " + placeHolderValue );
        return placeHolderValue.equalsIgnoreCase( value );
    }
    
    public boolean isSaveButtonDisabled() {
        SMUtils.waitForElement( driver, saveReportPopup );
        WebElement textBox = SMUtils.getWebElementDirect( driver, saveReportPopup, saveButtonRoot, button );
        boolean check = false;
        if(textBox.equals( null )) {
            check = true;
           
        }
        return check;
    }
}
