package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class CPABuildMockedReportTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String org;

    @BeforeTest
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        org = "AFG Report Testing Settings";
        org = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );

        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the user can navigates to Cumulativer Performance Aggregate page", groups = { "SMK-61279", "AdminReports", "Cumulative performance Aggregate report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );

            SMUtils.logDescriptionTC( "TC:01 Verify the admin is navigated to Cumulative Performance page by default" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "TC:02 Verify the Cumulative Performance is selected in the toggle by default" );
            cumulativePerformancePage.isCPRSelected();
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "TC:03 Verify the Cumulative Performance Aggregate is not selected by default" );
            cumulativePerformancePage.isnotCPAReportSelected();
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "TC:04 Verify the toggle between Cumulative Performance and Cumulative Performance Aggregate navigating to CPA page" );
            cumulativePerformancePage.getCPRAggregatePage();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The save report options label is displayed", "The save report options label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL ), "The Organization label is displayed", "The Organization label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CPR_COURSE_SELECTION_LABEL ), "The course selection label is displayed", "The course selection label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CPR_SUBJECT_LABEL ), "The subject label is displayed", "The subject label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ), "The courses label is displayed", "The courses label is not displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "The courses label is displayed", "The courses label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SORT_LABEL ), "The courses label is displayed", "The courses label is not displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandStudentDemographics(), "student demographics filter is expanded", "student demographics Filter is not expanded" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly",
                    "Issue in display th Disability status dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display th Race dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly",
                    "Issue in display the SocioEconomic Status dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English Language Proficiency dropdown label is displayed properly",
                    "Issue in display the English Language Proficiency dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), "Migrant Status dropdown label is displayed properly", "Issue in display the Migrant Status dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special seivices option dropdown label is displayed properly",
                    "Issue in display the Special seivices option dropdown label!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user can toggle to Cumulativer Performance  page", groups = { "SMK-61279", "AdminReports", "Cumulative performance report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );

            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            SMUtils.logDescriptionTC( "TC:05 Verify the toggle between Cumulative Performance Aggregate and Cumulative Performance navigating to CPA page" );
            cumulativePerformancePage.navigateToCPAReport();
            cumulativePerformancePage.isNavigateToCPReport();
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "The save report options label is displayed", "The save report options label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL ), "The Organization label is displayed", "The Organization label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CPR_COURSE_SELECTION_LABEL ), "The course selection label is displayed", "The course selection label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CPR_SUBJECT_LABEL ), "The subject label is displayed", "The subject label is not displayed" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.CPR_COURSES_LABEL ), "The courses label is displayed", "The courses label is not displayed" );
            Log.assertThat( dashBoardPage.reportFilterComponent.isOptionalFilterDisplaying(), "Optional filter is displaying", "Optional Filter is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying",
                    "Select student by is not displaying. Expected: " + ReportsUIConstants.SELECT_STUDENT_BY + ".Actual:" + dashBoardPage.reportFilterComponent.getSelectStudentBy() );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.TEACHER_LABEL ), "Teacher label is displaying", "Teacher label is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GRADE_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GROUP_LABEL ), "Group label is not displaying", "Group lebel is displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getMaskStudentDisplayAndRemovePageBreaklbl().get( 0 ).equals( ReportsUIConstants.MASK_STUDENT_DISPLAY ), "Mask Student is displaying", "Mask Student is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandStudentDemographics(), "student demographics filter is expanded", "student demographics Filter is not expanded" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly",
                    "Issue in display th Disability status dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display th Race dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly",
                    "Issue in display the SocioEconomic Status dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English Language Proficiency dropdown label is displayed properly",
                    "Issue in display the English Language Proficiency dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), "Migrant Status dropdown label is displayed properly", "Issue in display the Migrant Status dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );
            Log.assertThat( cumulativePerformancePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special seivices option dropdown label is displayed properly",
                    "Issue in display the Special seivices option dropdown label!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can toggle to Cumulativer Performance aggregate  page", groups = { "SMK-61279", "AdminReports", "Cumulative performance aggregate report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );
            SMUtils.logDescriptionTC( "TC06: Verify the selection reset to default in new page when the user toggle from CPR to CPA page" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.isNavigateToCPReport();
            new ReportFilterComponent( driver ).selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying",
                    "Select student by is not displaying. Expected: " + ReportsUIConstants.SELECT_STUDENT_BY + ".Actual:" + dashBoardPage.reportFilterComponent.getSelectStudentBy() );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.TEACHER_LABEL ), "Teacher label is displaying", "Teacher label is not displaying" );
            new ReportFilterComponent( driver ).selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GRADE_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GROUP_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "display header is displaying", "display header is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Name" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "sort header is displaying", "sort header is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level" );
            cumulativePerformancePage.clickAllDatesButton();
            Log.assertThat( dashBoardPage.reportFilterComponent.expandStudentDemographics(), "student demographics filter is expanded", "student demographics Filter is not expanded" );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            cumulativePerformancePage.getCPRAggregatePage();
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).contains( "None" ), "None additional grouping option is displaying",
                    "None Additional grouping option is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).contains( "School" ), "School sorts filter option is displaying", "School Sort filter option is not displaying" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selection reset to default in new page when the user toggle from CPA to CPR page", groups = { "SMK-61279", "AdminReports", "Cumulative performance aggregate report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );
            SMUtils.logDescriptionTC( "TC07: Verify the selection reset to default in new page when the user toggle from CPR to CPA page" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.getCPRAggregatePage();
            new ReportFilterComponent( driver ).selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, ( ReportsUIConstants.ADDITIONAL_GROUPING_CPAR.get( 1 ) ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "sort header is displaying", "sort header is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, ( ReportsUIConstants.SORT_CPAR.get( 1 ) ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandStudentDemographics(), "student demographics filter is expanded", "student demographics Filter is not expanded" );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            cumulativePerformancePage.navigateToCPReport();
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).contains( "None" ), "None additional grouping option is displaying",
                    "None Additional grouping option is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).contains( "Student Name" ), "Student Name display option is displaying",
                    "Student Name Display option is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).contains( "Student" ), "Student sorts filter option is displaying",
                    "Student Sort filter option is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the load report selection reset to default when the user navigate from the CPR to CPA page", groups = { "SMK-61279", "AdminReports", "Cumulative performance report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );
            SMUtils.logDescriptionTC( "TC08:Verify the load report selection reset to default when the user navigate from the CPR to CPA page" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.navigateToCPReport();
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "Save Report Option label text is displayed", "Save Report Option label text is not displayed" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            String selectingOption = dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).get( 0 );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, selectingOption );
            cumulativePerformancePage.getCPRAggregatePage();
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.afggetAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).contains( "None" ), "None additional grouping option is displaying",
                    "None Additional grouping option is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.afggetAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).contains( "School" ), "School sorts filter option is displaying",
                    "School Sort filter option is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the load report selection reset to default when the user navigate from the CPA to CPR page", groups = { "SMK-61279", "AdminReports", "Cumulative performance report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );
            SMUtils.logDescriptionTC( "TC09:Verify the load report selection reset to default when the user navigate from the CPA to CPR page" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.getCPRAggregatePage();
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SAVED_REPORT_OPTIONS ), "Save Report Option label text is displayed", "Save Report Option label text is not displayed" );
            dashBoardPage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS );
            String selectingOption = dashBoardPage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS ).get( 0 );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SAVED_REPORT_OPTIONS, selectingOption );
            cumulativePerformancePage.navigateToCPReport();
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.afggetAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ).contains( "None" ), "None additional grouping option is displaying",
                    "None Additional grouping option is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "Displaying header is displaying", "Displaying header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.afggetAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL ).contains( "Student Name" ), "Student Name display option is displaying",
                    "Student Name Display option is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "Sort header is displaying", "Sort header is not displaying" );
            Log.assertThat( dashBoardPage.reportFilterComponent.afggetAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL ).contains( "Student" ), "Student sorts filter option is displaying",
                    "Student Sort filter option is not displaying" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the toggle is displayed for subdistrict admin", groups = { "SMK-61279", "AdminReports", "Cumulative performance report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "basicsubdistrictadmin2", "password1" );
            SMUtils.logDescriptionTC( "TC10:Verify the toggle is displayed for subdistrict admin" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.navigateToCPReport();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the toggle is displayed for school admin", groups = { "SMK-61279", "AdminReports", "Cumulative performance report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "schooladmin_rvc", "password1" );
            SMUtils.logDescriptionTC( "TC11:Verify the toggle is displayed for school admin" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.navigateToCPReport();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the click on the toggle is not resetting the values selected in the filters", groups = { "SMK-61279", "AdminReports", "Cumulative performance report" }, priority = 1 )
    public void tcCumulativePerformanceAggregate009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );
            SMUtils.logDescriptionTC( "TC12:Verify the click on the toggle is not resetting the values selected in the filters" );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.navigateToCPReport();
            new ReportFilterComponent( driver ).selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.MATH );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandOptionalFilter(), "Optional filter is expanded", "Optional Filter is not expanded" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getSelectStudentBy().equalsIgnoreCase( ReportsUIConstants.SELECT_STUDENT_BY ), "Select student by is displaying",
                    "Select student by is not displaying. Expected: " + ReportsUIConstants.SELECT_STUDENT_BY + ".Actual:" + dashBoardPage.reportFilterComponent.getSelectStudentBy() );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.TEACHER_LABEL ), "Teacher label is displaying", "Teacher label is not displaying" );
            new ReportFilterComponent( driver ).selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( org ) );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.TEACHER_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GRADE_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GRADE_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.GROUP_LABEL ), "Grade lebel is displaying", "Grade Label is not displaying" );
            dashBoardPage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.GROUP_LABEL, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ADDITIONAL_GROUPING_LBL ), "Additional grouping is displaying", "Additional grouping is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.ADDITIONAL_GROUPING_LBL, "Teacher" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISPLAY_LABEL ), "display header is displaying", "display header is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.DISPLAY_LABEL, "Student Name" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SORT_LABEL ), "sort header is displaying", "sort header is not displaying" );
            dashBoardPage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.SORT_LABEL, "Current Course Level" );
            Log.assertThat( dashBoardPage.reportFilterComponent.expandStudentDemographics(), "student demographics filter is expanded", "student demographics Filter is not expanded" );
            dashBoardPage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            cumulativePerformancePage.navigateToCPReport();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
