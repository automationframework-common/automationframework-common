package com.savvas.sm.reports.api.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;

/**
 * This class is used to fetching the groups and students in groups and filter dropdown under a teacher
 * 
 * @author madhan.nagarathinam
 */

import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class GetGroupAndStudentDetailsTest extends EnvProperties {
	private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
	String teacherDetails = null;
	String teacherId;
	String orgId;
	private String smUrl;
	String studentDetails=null;
	String studentUserId;
	String studentUserName;
	String schoolAdminDetails = null;
	String schoolAdminUserName;
	String schoolAdminUserId;

	    @BeforeTest( alwaysRun = true )
	    public void BeforeTest() {
	        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
	        teacherDetails = RBSDataSetup.getMyTeacher( school ); 
	        teacherId =SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ); 
	        orgId =RBSDataSetup.organizationIDs.get( school );
	        studentDetails = RBSDataSetup.getMyStudent(school, SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ));
			studentUserId = SMUtils.getKeyValueFromResponse(studentDetails, "userId");
			studentUserName = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
			schoolAdminDetails = RBSDataSetup.adminDetails.get(Admins.SCHOOL_ADMIN);
			schoolAdminUserName = SMUtils.getKeyValueFromResponse(schoolAdminDetails, "userName");
			schoolAdminUserId = SMUtils.getKeyValueFromResponse(schoolAdminDetails, "userId");

			 
	    }
	
	    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-60693", "(Automation) As a teacher I should be able to choose which groups or students related reports I want to generate", "GraphQL", "BFF","SmokeTest" }, priority = 1 )
	    public void getGroupAndStudentDetailsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
	    	 // headers
	        Map<String, String> headers = new HashMap<String, String>();
	       headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(  SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD) );

	        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, orgId);
	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, teacherId);
	        
	        String payload = null;
	    	
	      //For Constructing QueryItems in request PayLoad
	        List<String> queryItems = new ArrayList<String>();
	        String queryItem = null;

	        Log.testCaseInfo( testcaseName + testcaseDescription );
	        switch ( scenarioType ) {
	        case "SINGLE_QUERY_SET":
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}"+"}"+"}");
	        	queryItem = constructQueryItems(queryItems);
	        break;
	        
	        case "MULTIPLE_QUERY_SET":
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}"+"}"+"}");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STUDENT_DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.PERSONID+"}");
	        	queryItem = constructQueryItems(queryItems);
	        break;

	        case "ALL_QUERY_ITEMS":
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION_INFO+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION_NAME);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATIONID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ROSTERSOURCE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.AUTOROSTERED);

	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STUDENTS+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STUDENTPIID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STUDENTENROLLMENTID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.BEGINDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ENDDATE+"}");

	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STAFF+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STAFFPIID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STAFFASSIGNMENTID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.BEGINDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ENDDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.TEACHEROFRECORD);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.TEACHERASSIGNMENT+"}"+"}"+"}"+"}"+"}");

	        	
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SYSTEM+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.LIFECYCLE+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DELETED);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.CREATEDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.MODIFIEDDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.CREATED_BY);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.UPDATEDBY+"}"+"}");

	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DISTRICTS+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}");

	        	
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.METADATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ATTRIBUTEKEY);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ATTRIBUTEVALUE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.LMSNAME+"}"+"}");

	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.STUDENT_DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.PERSONID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USERID);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.FIRSTNAME);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.LASTNAME);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.MIDDLENAME);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DISPLAYNAME);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.GENDER);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.CREATEDDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.LASTUPDATEDDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.LASTUPDATEDBY);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.CREATED_BY);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USERNAME);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ENCRYPTIONTYPE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.AUTHENTICATIONTYPE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.TITLE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.BIRTHDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.LANGUAGE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USERSTATUS);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.RESETFLAG);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.PASSWARDEXPIRYDATE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.PREFFEREDTIMEZONE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.BUSSINESSRULESET);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.AUTOGENERATED);
 	
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USERMETADATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.GRADES+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.GRADELEVEL);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.PLATFORM+"}");
	
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DEMOGRAPHICS+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SPECIALSERVICES);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ECONOMICDISADVANTAGE);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.HASDISABILTIY);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ENGLISHPROFIENCY);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.MIGRANT);
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ETHNICITY+"}"+"}"+"}");
	        	queryItem = constructQueryItems(queryItems);
	        	break;

	        }
	        payload =String.format( ReportsAPIConstants.getGroupAndStudentDetailsConstants.REQ_PAYLOAD, "ffffffff62a884da31eba2002f8029cd", queryItem);
	        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportsAPIConstants.REPORT_BFF, headers, payload, ReportsAPIConstants.GRAPHQL_ENDPOINT );
	        Log.message("Response" + response.getBody().asString());
	        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupAndStudentDetails", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

	    }
	        
	    
	    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-60693", "(Automation) As a teacher I should be able to choose which groups or students related reports I want to generate", "GraphQL", "BFF" }, priority = 1 )
	    public void getGroupAndStudentDetailsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
	    	 // headers
	        Map<String, String> headers = new HashMap<String, String>();
	       // headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(  SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD) );
	       
	        String payload = null;
	    	
	      //For Constructing QueryItems in request PayLoad
	        List<String> queryItems = new ArrayList<String>();
	        String queryItem = null;

	        Log.testCaseInfo( testcaseName + testcaseDescription );
	        switch ( scenarioType ) {
	        case "INVALID_AUTH":
	 	       headers.put( Constants.AUTHORIZATION,  new RBSUtils().getAccessToken(  SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD) );
	 	        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, orgId);
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, teacherId);
	 	        
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}"+"}"+"}");
	        	queryItem = constructQueryItems(queryItems);
	       
	        break;
	       
	        case "CA_USER":
	 	       headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( schoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD) );
	 	        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, orgId);
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, schoolAdminUserId);
	 	        
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}"+"}"+"}");
	        	queryItem = constructQueryItems(queryItems);
	       
	        break;
	        
	        case "STUDENT_USER":
	 	       headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(  studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD) );
	 	        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, orgId);
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, studentUserId);
	 	        
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}"+"}"+"}");
	        	queryItem = constructQueryItems(queryItems);
	       
	        break;
	        
	        case "INVALID_QUERY":
	 	       headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken(  SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD) );
	 	        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ORGANIZATION_ID, orgId);
	 	        headers.put(ReportsAPIConstants.getGroupAndStudentDetailsConstants.USER_ID, teacherId);
	 	        
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.DATA+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.SECTION+"{");
	        	queryItems.add(ReportsAPIConstants.getGroupAndStudentDetailsConstants.ID+"}"+"}");
	        	queryItem = constructQueryItems(queryItems);
	        break; 
	        }

	        payload =String.format( ReportsAPIConstants.getGroupAndStudentDetailsConstants.REQ_PAYLOAD, "ffffffff62a884da31eba2002f8029cd", queryItem);
	        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportsAPIConstants.REPORT_BFF, headers, payload, ReportsAPIConstants.GRAPHQL_ENDPOINT );
	        String errors = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
	        String extensions = SMUtils.getKeyValueFromResponseWithArray( errors, "path" );

	        Log.message( response.getBody().asString() );
	        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
	                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
	    }
	        
	    
	    @DataProvider
	    public Object[][] getDataForPostivieScenarios() {
	        Object[][] data = {{"TC:01", "200", "Verify the GraphQL is obtainng predictable result when all query field sets are given for a teacher", "ALL_QUERY_ITEMS"},
	        		{"TC:02", "200", "Verify the GraphQL is obtainng predictable result when single query set filed are given for a teacher", "SINGLE_QUERY_SET"},
	        		{"TC:03", "200", "Verify the GraphQL is obtainng predictable result when multiple query field sets are given for a teacher", "MULTIPLE_QUERY_SET"}
	        };
	        return data;
	    }
	    
	    @DataProvider
	    public Object[][] getDataForNegativeScenarios() {
	        Object[][] data = {{"TC:04", "200", "Verify Invalid Auth message in the response body when invalid Bearer token is provided", "INVALID_AUTH"},
	        		{"TC:05", "200", "Verify Access Denied Message when CA userId is provided", "CA_USER"},
	        		{"TC:06", "200", "Verify Access Denied Message when Student UserId is provided", "STUDENT_USER"},
	        		{"TC:07", "200", "Verify Bad Request Message when invaid Query is provided", "INVALID_QUERY"},
	        		};
	        return data;
	    }
	    
	        //This method is for constructing the query Items for payload
	        public String constructQueryItems( List<String> queryItems ) {
	            String frameQuery = "{";
	            for ( String item : queryItems ) {
	                if ( frameQuery.endsWith( "{" ) )
	                    frameQuery = frameQuery + item;
	                else
	                    frameQuery = frameQuery + "," + item;
	            }
	            frameQuery = frameQuery + "}";
	            return frameQuery;
	        }     
	        
}
