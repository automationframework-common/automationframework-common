package com.savvas.sm.reports.api.tests;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.JsonUtil;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.ReportConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;

public class GetDemographicListTest extends EnvProperties {

    private Response response;
    private String password;
    String teacherDetails;
    String expectedJson;
    String keyValueFromActualResponse;
    String keyValueFromExpectedJSON;

    @BeforeClass
    public void initTest() throws Exception {
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        String basePath = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator
                + "demographicsListExpectedOutput.json";
        expectedJson = SMUtils.convertFileToString( basePath );
    }

    /**
     * This method is used to test the Get - Demographics List BFF (positive
     * scenarios)
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "getDemographicsListPositiveScenario", groups = { "demographicsListBff", "SMK-51757", "P1", "API","SmokeTest" } )
    public void getDemographicsPositiveScenarios( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( "user-id", adminUserId );
        headers.put( "org-id", adminOrgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );

        switch ( scenario ) {
            case "HAPPY_PATH":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                Log.assertThat( JsonUtil.jsonCompare( response.getBody().asString(), expectedJson ), "Demographics List fetched properly",
                        "Demographics List are not fetched properly! Expected - " + expectedJson + " \nActual -" + response.getBody().asString() );
                break;

            case "TEACHER_CREDENTIAL":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), password ) );
                response = new Reports().getDemographicsList( headers, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ), RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                //data Validation
                Log.assertThat( JsonUtil.jsonCompare( response.getBody().asString(), expectedJson ), "Demographics List fetched properly",
                        "Demographics List are not fetched properly! Expected - " + expectedJson + " \nActual -" + response.getBody().asString() );

                break;

            case "GENDER_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.GENDER );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.GENDER );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "Gender details are fetched properly",
                        "Gender details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "DISABILTY_STATUS_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.DISABILITY_STATUS );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.DISABILITY_STATUS );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "DISABILITY_STATUS details are fetched properly",
                        "DISABILITY_STATUS details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "MIGRANT_STATUS_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.MIGRANT_STATUS );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.MIGRANT_STATUS );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "MIGRANT_STATUS details are fetched properly",
                        "MIGRANT_STATUS details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "SOCIOECONOMIC_STATUS_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.SOCIOECONOMIC_STATUS );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.SOCIOECONOMIC_STATUS );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "SOCIOECONOMIC_STATUS details are fetched properly",
                        "SOCIOECONOMIC_STATUS details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "RACE_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.RACE );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.RACE );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "RACE details are fetched properly",
                        "RACE details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "ETHINICITY_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.ETHNICITY );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.ETHNICITY );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "ETHNICITY details are fetched properly",
                        "ETHNICITY details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "SPECIAL_SERVICES_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.SPECIAL_SERVICES );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.SPECIAL_SERVICES );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "SPECIAL_SERVICES details are fetched properly",
                        "SPECIAL_SERVICES details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;

            case "ENGLISH_LANGUAGE_VALIDATION":
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );

                //data Validation
                keyValueFromActualResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.ENGLISH_LANGUAGE );
                keyValueFromExpectedJSON = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getDemographics" ), ReportsAPIConstants.ENGLISH_LANGUAGE );
                Log.assertThat( JsonUtil.jsonCompare( keyValueFromExpectedJSON, keyValueFromActualResponse ), "SPECIAL_SERVICES details are fetched properly",
                        "SPECIAL_SERVICES details are not fetched properly! Expected - " + keyValueFromExpectedJSON + "/nActual -" + keyValueFromActualResponse );
                break;
            default:
                Log.message( "Not a valid scenario....." );
                break;
        }
        Log.message( response.getBody().asString() );

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + "is not Verified" );

        Log.testCaseResult();

    }

    @DataProvider ( name = "getDemographicsListPositiveScenario" )
    public Object[][] getDemographicsListPositiveScenario() {

        Object[][] inputData = {
                { "tc_demographicsLis001", "getDemographics - Verify the status code 200 and all the demographics with respected values are retrieved for District Admin user", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis002", "getDemographics - Verify the status code 200 and all the demographics with respected values are retrieved for Sub-district Admin user", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.SUBDISTRICTWITHSCHOOL_ADMIN },
                { "tc_demographicsLis003", "getDemographics - Verify the status code 200 and all the demographics with respected values are retrieved for School Admin user", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK, Admins.SCHOOL_ADMIN },
                { "tc_demographicsLis004", "getDemographics - Verify the status code 200 and all the demographics with respected values are retrieved for teacher user", "TEACHER_CREDENTIAL", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis005", "getDemographics - Verify all the GENDER values are displayed in the response for a valid user details", "GENDER_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis006", "getDemographics - Verify all the DISABILTY_STATUS values are displayed in the response for a valid user details", "DISABILTY_STATUS_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis007", "getDemographics - Verify all the MIGRANT_STATUS values are displayed in the response for a valid user details", "MIGRANT_STATUS_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis008", "getDemographics - Verify all the SOCIOECONOMIC_STATUS values are displayed in the response for a valid user details", "SOCIOECONOMIC_STATUS_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis009", "getDemographics - Verify all the RACE values are displayed in the response for a valid user details", "RACE_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis010", "getDemographics - Verify all the ETHINICITY values are displayed in the response for a valid user details", "ETHINICITY_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis011", "getDemographics - Verify all the SPECIAL_SERVICES values are displayed in the response for a valid user details", "SPECIAL_SERVICES_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsLis012", "getDemographics - Verify all the ENGLISH_LANGUAGE values are displayed in the response for a valid user details", "ENGLISH_LANGUAGE_VALIDATION", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN }, };

        return inputData;
    }

    @Test ( priority = 2, dataProvider = "getDemographicsListNegativeScenario", groups = { "demographicsListBff", "SMK-51754", "P3", "API" } )
    public void getDemographicsNegativeScenarios( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + " : " + description );

        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenario ) {
            case "SAVVAS_ADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );
                break;

            case "STUDENT_CREDENTIAL":
                String studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, "userName" ), password ) );
                response = new Reports().getDemographicsList( headers, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                break;

            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token + "invalid" );
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );
                break;

            case "EMPTY_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER );
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                response = new Reports().getDemographicsList( headers, adminUserId + "invalid", adminOrgId );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                response = new Reports().getDemographicsList( headers, adminUserId, adminOrgId + "invalid" );
                break;

            case "EMPTY_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                response = new Reports().getDemographicsList( headers, "", adminOrgId );
                break;

            case "EMPTY_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                response = new Reports().getDemographicsList( headers, adminUserId, "" );
                break;

            case "INVALID_DATA_TYPE":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + token );
                String query = ReportConstants.GET_DEMOGRAHICS_LIST_PAYLOAD;
                query = query.replace( Constants.USER_ID_VALUE, adminUserId );
                query = query.replace( "\\\"" + Constants.ORG_ID + "\\\"", adminOrgId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportConstants.REPORT_BFF, headers, query, ReportConstants.GRAPHQL_ENDPOINT );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        // Verifying Status code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        // Verifying message from response
        if ( scenario.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenario.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( ReportsAPIConstants.NOT_FOUND_404 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenario.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( ReportsAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenario.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( ReportsAPIConstants.INVALID_MESSAGE_FOR_USERID ), "Getting Invalid message for empty userId", "Not getting Invalid message for Invalid userId" );
        } else if ( scenario.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( ReportsAPIConstants.INVALID_MESSAGE_FOR_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        } else if ( scenario.equalsIgnoreCase( "SAVVAS_ADMIN" ) || scenario.equalsIgnoreCase( "STUDENT_CREDENTIAL" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( ReportsAPIConstants.FORBIDDEN_403 ), "Getting forbidden message for " + scenario, "Not getting forbidden message for " + scenario );
        }
    }

    @DataProvider ( name = "getDemographicsListNegativeScenario" )
    public Object[][] getDemographicsListNegativeScenario() {

        Object[][] inputData = {
                //rework is in progress
                //{ "tc_demographicsList013", "getDemographics - Verify the status code 200 and all the demographics with respected values are retrieved for savvas admin user", "SAVVAS_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.SAVVAS_ADMIN },
                { "tc_demographicsList014", "getDemographics - Verify the status code 403 and all the demographics with respected values are retrieved for student user", "STUDENT_CREDENTIAL", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList015", "getDemographics - Verify the status code 401 and UNAUTHORIZED error message when invalid bearer token is passed in header", "INVALID_BEARER_TOKEN", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList016", "getDemographics - Verify the status code 401 and UNAUTHORIZED error message when no bearer token is passed in header", "EMPTY_BEARER_TOKEN", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList017", "getDemographics - Verify the status code 401: Unauthorized and UNAUTHENTICATED error message when invalid userID is passed", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList018", "getDemographics - Verify the status code 400 and Invalid value passed for userId error message when empty userID is passed", "EMPTY_USER_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList019", "getDemographics - Verify the status code 404: Not Found and INTERNAL_SERVER_ERROR error message when invalid orgId is passed", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList020", "getDemographics - Verify the status code 400 and Invalid value passed for organizationId error message when empty orgId is passed", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_demographicsList021", "getDemographics - Verify the status code 400 Bad Request with BAD_USER_INPUT when non-String value is given as an input", "INVALID_DATA_TYPE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST,
                        Admins.DISTRICT_ADMIN }, };
        return inputData;
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }
}
