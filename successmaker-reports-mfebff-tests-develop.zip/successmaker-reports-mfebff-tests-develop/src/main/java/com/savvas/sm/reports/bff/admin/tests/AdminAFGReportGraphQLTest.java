package com.savvas.sm.reports.bff.admin.tests;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.everit.json.schema.ValidationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.reports.reportdatasetup.ReportData;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportAPI;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperReports;

import io.restassured.response.Response;

public class AdminAFGReportGraphQLTest extends EnvProperties {

    public RBSUtils rbsUtils = new RBSUtils();
    public String smUrl;
    public static String districtId;
    public static String orgId;
    private Response response;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String teacherDetails;
    String teacherId;
    String teacherUsername;
    String teacherOrgId;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    RBSUtils rbs = new RBSUtils();

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        teacherUsername = ReportData.teacherDetails.keySet().toArray()[0].toString();
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );
        orgId = ReportData.orgId;

    }

    @Test ( priority = 1, dataProvider = "testPositiveScenario", groups = { "Admin AFG Report Graphql", "SMK-63993", "Area for Growth-BFF", "P1" } )
    public void testAFGRepostAPIPositive( String testcaseId, String description, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseId + ":-" + description );
        Map<String, String> filters = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        String assignmentIds = "";
        String subject = null;
        String assignmentName = null;
        Map<String, List<String>> assignmentUserIdsFromDB;
        Map<String, List<String>> studentsFromResponse;
        Map<String, List<String>> studentsFromDB = new HashMap<>();

        switch ( scenario ) {
            case "DISTRICT_ADMIN":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                assignmentUserIdsFromDB = new SqlHelperReports().getAFGSkillsWithStudentsListFromDB( assignmentIds, subject );
                Log.message( "--" + assignmentUserIdsFromDB.toString() );
                assignmentUserIdsFromDB.entrySet().stream().forEach( entry -> {
                    List<String> studentNames = new ArrayList<>();
                    entry.getValue().stream().forEach( assignmentuserIds -> {
                        String assignmentuserId = assignmentuserIds.split( "," )[0];
                        String assignmentDetail = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter(
                                assignment -> SMUtils.getKeyValueFromResponse( assignment, "studentAssignmentId" ).equals( assignmentuserId ) ).findFirst().orElse( null );
                        if ( Objects.isNull( assignmentDetail ) ) {
                            assignmentDetail = ReportData.defaultMathAssignmentDetails.get( ReportData.teacherDetails.keySet().toArray()[1].toString() ).values().stream().filter(
                                    assignment -> SMUtils.getKeyValueFromResponse( assignment, "studentAssignmentId" ).equals( assignmentuserId ) ).findFirst().orElse( null );

                        }
                        String[] studentName = SMUtils.getKeyValueFromResponse( assignmentDetail, "studentDetail,name" ).split( " " );
                        studentNames.add( studentName[0] + " " + studentName[studentName.length - 1] + "," + assignmentuserIds.split( "," )[1] );
                    } );
                    studentsFromDB.put( entry.getKey(), studentNames );
                } );
                Log.message( "--" + studentsFromDB.toString() );
                studentsFromResponse = getstudentsFromResponse( response.getBody().asString(), assignmentName, subject );
                Log.message( "--" + studentsFromResponse );
                Log.assertThat( studentsFromDB.entrySet().stream().allMatch( entry -> {
                    return studentsFromResponse.get( entry.getKey() ).containsAll( entry.getValue() );
                } ), "All The students are returned properly in the response", "All The students are not fetched properly in the response!!!" );

                break;

            case "SCHOOL_ADMIN":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                assignmentUserIdsFromDB = new SqlHelperReports().getAFGSkillsWithStudentsListFromDB( assignmentIds, subject );
                assignmentUserIdsFromDB.entrySet().stream().forEach( entry -> {
                    List<String> studentNames = new ArrayList<>();
                    entry.getValue().stream().forEach( assignmentuserIds -> {
                        String assignmentuserId = assignmentuserIds.split( "," )[0];
                        String assignmentDetail = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter(
                                assignment -> SMUtils.getKeyValueFromResponse( assignment, "studentAssignmentId" ).equals( assignmentuserId ) ).findFirst().orElse( null );
                        if ( Objects.isNull( assignmentDetail ) ) {
                            assignmentDetail = ReportData.defaultMathAssignmentDetails.get( ReportData.teacherDetails.keySet().toArray()[1].toString() ).values().stream().filter(
                                    assignment -> SMUtils.getKeyValueFromResponse( assignment, "studentAssignmentId" ).equals( assignmentuserId ) ).findFirst().orElse( null );

                        }
                        String[] studentName = SMUtils.getKeyValueFromResponse( assignmentDetail, "studentDetail,name" ).split( " " );
                        studentNames.add( studentName[0] + " " + studentName[studentName.length - 1] + "," + assignmentuserIds.split( "," )[1] );
                    } );
                    studentsFromDB.put( entry.getKey(), studentNames );
                } );
                studentsFromResponse = getstudentsFromResponse( response.getBody().asString(), assignmentName, subject );
                Log.assertThat( studentsFromDB.entrySet().stream().allMatch( entry -> {
                    return studentsFromResponse.get( entry.getKey() ).containsAll( entry.getValue() );
                } ), "All The students are returned properly in the response", "All The students are not fetched properly in the response!!!" );

                break;

            case "SUBDISTRICT_ADMIN":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.subDistrictAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                assignmentUserIdsFromDB = new SqlHelperReports().getAFGSkillsWithStudentsListFromDB( assignmentIds, subject );
                assignmentUserIdsFromDB.entrySet().stream().forEach( entry -> {
                    List<String> studentNames = new ArrayList<>();
                    entry.getValue().stream().forEach( assignmentuserIds -> {
                        String assignmentuserId = assignmentuserIds.split( "," )[0];
                        String assignmentDetail = ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter(
                                assignment -> SMUtils.getKeyValueFromResponse( assignment, "studentAssignmentId" ).equals( assignmentuserId ) ).findFirst().orElse( null );
                        if ( Objects.isNull( assignmentDetail ) ) {
                            assignmentDetail = ReportData.defaultMathAssignmentDetails.get( ReportData.teacherDetails.keySet().toArray()[1].toString() ).values().stream().filter(
                                    assignment -> SMUtils.getKeyValueFromResponse( assignment, "studentAssignmentId" ).equals( assignmentuserId ) ).findFirst().orElse( null );

                        }
                        String[] studentName = SMUtils.getKeyValueFromResponse( assignmentDetail, "studentDetail,name" ).split( " " );
                        studentNames.add( studentName[0] + " " + studentName[studentName.length - 1] + "," + assignmentuserIds.split( "," )[1] );
                    } );
                    studentsFromDB.put( entry.getKey(), studentNames );
                } );
                studentsFromResponse = getstudentsFromResponse( response.getBody().asString(), assignmentName, subject );
                Log.assertThat( studentsFromDB.entrySet().stream().allMatch( entry -> {
                    return studentsFromResponse.get( entry.getKey() ).containsAll( entry.getValue() );
                } ), "All The students are returned properly in the response", "All The students are not fetched properly in the response!!!" );

                break;

            case "MULTI_ADMIN":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "FILTER_BY_ADDITIONALGROUPING_DEFAULTMATH":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "FILTER_BY_READING_SINCE_IP":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( ReportAdminConstants.DATE_AT_RISK, "10400" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "FILTER_BY_READING_24_WEEKS":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( ReportAdminConstants.DATE_AT_RISK, "24" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "DISABILITY_YES":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.DISABILITY_STATUS, "YES" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "DISABILITY_NO_AND_NOT_SPECIFIED":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.DISABILITY_STATUS, "NO\\\",\\\"NOT_SPECIFIED" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "ENGLISH_PROFICIENCY":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.ENGLISH_PROFICIENCY, "ENGLISH" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "ENGLISH_PROFICIENCY_MULTIPLE":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.ENGLISH_PROFICIENCY, "ENGLISH_LANGUAGE_LEARNER\\\",\\\"NOT_SPECIFIED" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "MIGRANT_SINGLE_OPTION":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.MIGRANT_STATUS, "MIGRANT" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "MIGRANT_MULTIPLE_OPTION":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.MIGRANT_STATUS, "NON_MIGRANT\\\",\\\"NOT_SPECIFIED" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "ECONOMIC_STATUS_SINGLE_OPTION":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.SOCIO_STATUS, "ECONOMICALLY_DISADVANTAGED" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "ECONOMIC_STATUS_MULTIPLE_OPTION":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.SOCIO_STATUS, "NOT_ECONOMICALLY_DISADVANTAGED\\\",\\\"NOT_SPECIFIED" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "SPECIAL_SERVICES_SINGLE_OPTION":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.SPECIAL_SERVICES, "PLAN_504" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "SPECIAL_SERVICES_MULTIPLE_OPTION":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );

                assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                filters.put( DemographicFilters.SPECIAL_SERVICES, "GIFTED_TALENTED\\\",\\\"IEP\\\",\\\"OTHER\\\",\\\"NO_SPECIAL_SERVICES" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }

                break;

            case "IPM_ON_MATH":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = SMUtils.getKeyValueFromResponse(
                        ReportData.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                        "assignmentId" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }
                }
                break;

            case "IPM_OFF_MATH":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = SMUtils.getKeyValueFromResponse(
                        ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                        "assignmentId" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "IPM_ON_READING":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = SMUtils.getKeyValueFromResponse(
                        ReportData.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                        "assignmentId" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;

            case "IPM_OFF_READING":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                subject = ReportsUIConstants.READING;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = SMUtils.getKeyValueFromResponse(
                        ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                        "assignmentId" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                        || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                    for ( int i = 0; i < 5; i++ ) {
                        response = new ReportAPI().getAFGAdminReportData( headers, filters );
                        if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                            break;
                        }
                    }

                }
                break;
        }

        // Verifying Status Code
        Log.message( response.getBody().asString() );

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
            //Verifying the data with DB
            Map<String, Map<String, String>> skillsFromResponse = getSkillsFromResponse( response.getBody().asString(), assignmentName, subject );
            Map<String, Map<String, String>> skillsFromDB = new SqlHelperReports().getAFGSkillsFromDB( assignmentIds, subject );
            Log.assertThat( skillsFromDB.entrySet().stream().anyMatch( entry -> {
                return SMUtils.compareTwoHashMap( entry.getValue(), skillsFromResponse.get( entry.getKey() ) );
            } ), "All the skills are returned properly in the response", "All the skills are not fetched properly in the response!!!" );

            // Verifying schema in the Response body
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "testPositiveScenario" )
    public Object[][] testPositiveScenario() {

        Object[][] inputData = { { "tc_AFGBFF001", "Verify the 200 status code and valid reponse for the district admin credential", CommonAPIConstants.STATUS_CODE_OK, "DISTRICT_ADMIN" },
                { "tc_AFGBFF002", "Verify the 200 status code and valid response for the school admin credential", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN" },
                { "tc_AFGBFF003", "Verify the 200 status code and valid response for the sub district admin credential", CommonAPIConstants.STATUS_CODE_OK, "SUBDISTRICT_ADMIN" },
                { "tc_AFGBFF004", "Verify the 200 status code and valid response for the multi admin credential", CommonAPIConstants.STATUS_CODE_OK, "MULTI_ADMIN" },
                { "tc_AFGBFF006", "Verify the 200 Status code and  the output response , while passing any one organization Id with additionalGrouping as None, Math subject and Math assignment id", CommonAPIConstants.STATUS_CODE_OK,
                        "FILTER_BY_ADDITIONALGROUPING_DEFAULTMATH" },
                { "tc_AFGBFF009", "Verify the 200 Status code and  the output response, while passing any one organization Id with additionalGrouping as None, Subject as Reading and courseId as Reading assignment id and date at risk as Since IP.",
                        CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_READING_SINCE_IP" },
                { "tc_AFGBFF010", "Verify the 200 Status code and  the output response, while passing any one organization Id with additionalGrouping as Grade, Subject as Reading and courseId as multiple Reading assignment id adn date at risk as 24 Weeks",
                        CommonAPIConstants.STATUS_CODE_OK, "FILTER_BY_READING_24_WEEKS" },
                { "tc_AFGBFF011", "Verify the 200 Status code and  the output response , while pass the required filters with disability status as 'yes' (single option)", CommonAPIConstants.STATUS_CODE_OK, "DISABILITY_YES" },
                { "tc_AFGBFF012", "Verify the 200 Status code and  the output response , while pass the required filters with disability status as 'No' and  'Not Specified' (multiple options)", CommonAPIConstants.STATUS_CODE_OK,
                        "DISABILITY_NO_AND_NOT_SPECIFIED" },
                { "tc_AFGBFF013", "Verify the 200 Status code and  the output response , while pass the required filters with English language Proficiency as 'English' (single option)", CommonAPIConstants.STATUS_CODE_OK, "ENGLISH_PROFICIENCY" },
                { "tc_AFGBFF014", "Verify the 200 Status code and  the output response , while pass the required filters with english Language Proficiency as 'English language learner' and  'Not specified' (multiple options)",
                        CommonAPIConstants.STATUS_CODE_OK, "ENGLISH_PROFICIENCY_MULTIPLE" },
                { "tc_AFGBFF015", "Verify the 200 Status code and  the output response , while pass the required filters with migrant status  as 'migrant' (single option)", CommonAPIConstants.STATUS_CODE_OK, "MIGRANT_SINGLE_OPTION" },
                { "tc_AFGBFF016", "Verify the 200 Status code and  the output response , while pass the required filters with migrant status  as 'Non Migrant' & not specified (multiple options)", CommonAPIConstants.STATUS_CODE_OK,
                        "MIGRANT_MULTIPLE_OPTION" },
                { "tc_AFGBFF017", "Verify the 200 Status code and  the output response , while pass the required filters with socioeconomic status  as 'Economically Disadvantaged' (single option)", CommonAPIConstants.STATUS_CODE_OK,
                        "ECONOMIC_STATUS_SINGLE_OPTION" },
                { "tc_AFGBFF018", "Verify the 200 Status code and  the output response , while pass the required filters with socioeconomic status  as 'Not Economically Disadvantaged' & Not specified (multiple options)", CommonAPIConstants.STATUS_CODE_OK,
                        "ECONOMIC_STATUS_MULTIPLE_OPTION" },
                { "tc_AFGBFF019", "Verify the 200 Status code and  the output response , while pass the required filters with special services  as ''504 plan\" (single option)", CommonAPIConstants.STATUS_CODE_OK, "SPECIAL_SERVICES_SINGLE_OPTION" },
                { "tc_AFGBFF020", "Verify the 200 Status code and  the output response , while pass the required filters with special services  as 'Gifted/Talented', 'IEP','Other', 'NO_Special_services'  &  'Not_Specified' (multiple options)",
                        CommonAPIConstants.STATUS_CODE_OK, "SPECIAL_SERVICES_MULTIPLE_OPTION" },
                { "tc_AFGBFF021", "Verify the 200 Status code and  the output response , while passing any one organization Id with additionalGrouping as None, Math subject and Math IPM ON assignment ID.", CommonAPIConstants.STATUS_CODE_OK,
                        "IPM_ON_MATH" },

                { "tc_AFGBFF022", "Verify the 200 Status code and  the output response , while passing any one organization Id with additionalGrouping as None, Math subject and Math IPM off assignment ID.", CommonAPIConstants.STATUS_CODE_OK,
                        "IPM_OFF_MATH" },

                { "tc_AFGBFF023", "Verify the 200 Status code and  the output response , while passing any one organization Id with additionalGrouping as None, Reading subject and Reading IPM ON assignment ID.", CommonAPIConstants.STATUS_CODE_OK,
                        "IPM_ON_READING" },
                { "tc_AFGBFF024", "Verify the 200 Status code and  the output response , while passing any one organization Id with additionalGrouping as None, Reading subject and Reading IPM OFF assignment ID.", CommonAPIConstants.STATUS_CODE_OK,
                        "IPM_OFF_READING" }

        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "NegativeScenarios", groups = { "Admin AFG Report Graphql", "SMK-63993", "Area for Growth-BFF", "P2" } )
    public void testAFGRepostAPI( String testcaseId, String description, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseId + ":-" + description );
        Map<String, String> filters = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        String assignmentIds = "";
        String subject = null;
        String assignmentName = null;

        switch ( scenario ) {

            case "INVALID_BEARER":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) + "invalid" );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                break;

            case "INVALID_ORGID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId + "invalid" );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                break;

            case "UNAUTHORIZED_USER":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) + "invalid" );

                filters.put( ReportAdminConstants.SUBJECT, "Math" );
                subject = ReportsUIConstants.MATH;
                assignmentName = SMUtils.getKeyValueFromResponse(
                        ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                        "courseDetail,name" );
                assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                    String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                    return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                filters.put( ReportAdminConstants.COURSES, assignmentIds );
                Log.message( assignmentIds );
                Log.message( ReportData.orgId );
                filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                response = new ReportAPI().getAFGAdminReportData( headers, filters );
                break;

        }
        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );
        Log.message( response.getBody().asString() );
        if ( scenario.equalsIgnoreCase( "INVALID_BEARER" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.UNAUTHORIZED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        } else if ( scenario.equalsIgnoreCase( "INVALID_ORGID" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        } else if ( scenario.equalsIgnoreCase( "UNAUTHORIZED_USER" ) ) {
            Log.assertThat( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ), "Message displayed as expected", "Message not displayed as expected" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "NegativeScenarios" )
    public Object[][] testNegativeScenario() {

        Object[][] inputData = { { "tc_AFGBFF025", "Verify 401: UnAuthorized message in response when invalid Bearer token is given", CommonAPIConstants.STATUS_CODE_OK, "INVALID_BEARER" },
                { "tc_AFGBFF026", "Verify 403: status code and response when invalid organizationId is given in the query", CommonAPIConstants.STATUS_CODE_OK, "INVALID_ORGID" },
                { "tc_AFGBFF027", "Verify 401: UnAuthorized and response when invalid userId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "UNAUTHORIZED_USER" },

        };
        return inputData;
    }

    /**
     * To get the skill details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, Map<String, String>> getSkillsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, Map<String, String>> SkillDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                skillDetails.put( AFGReportConstants.STRAND, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_NAME ) );
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                skillDetails.put( AFGReportConstants.TARGETED_LESSON,
                        SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LESSON_NUMBER ) + ". " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LESSON_TITLE ) );
                if ( skillDetails.get( AFGReportConstants.TARGETED_LESSON ).equals( ". " ) ) {
                    skillDetails.put( AFGReportConstants.TARGETED_LESSON, "" );
                }
                SkillDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), skillDetails );
            } );

        } );
        return SkillDetailFromResponse;
    }

    /**
     * To get the student details from the response
     * 
     * @param response
     * @param assignmentName
     * @return
     */
    public Map<String, List<String>> getstudentsFromResponse( String response, String assignmentName, String subject ) {

        Map<String, List<String>> studentDetailFromResponse = new HashMap<>();
        JSONArray jsonArray = new JSONObject( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, AFGReportConstants.DATA ), AFGReportConstants.GET_AFG_ADMIN_REPORT_DATA ) ).getJSONArray( AFGReportConstants.ORG_ROWS );
        List<String> jsonArrayList = new ArrayList<>();
        IntStream.range( 0, jsonArray.length() ).forEach( itr -> jsonArrayList.add( jsonArray.get( itr ).toString() ) );
        jsonArrayList.stream().filter( responseArray -> SMUtils.getKeyValueFromResponse( responseArray.toString(), AFGReportConstants.ASSIGNMENT_TITLE ).equals( assignmentName ) ).forEach( responseArray -> {
            List<String> skillDetailList = new ArrayList<>();
            JSONArray skillArray = new JSONObject( responseArray.toString() ).getJSONArray( AFGReportConstants.STRAND_SKILL_ROWS );
            IntStream.range( 0, skillArray.length() ).forEach( itr -> skillDetailList.add( skillArray.get( itr ).toString() ) );
            skillDetailList.stream().forEach( skillDetail -> {
                Map<String, String> skillDetails = new HashMap<>();
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.STRAND_LEVEL ) ) );
                }
                skillDetails.put( AFGReportConstants.LEVEL, level );
                if ( subject.equals( ReportsUIConstants.MATH ) ) {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION,
                            SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.CATALOG_NUM ) + " - " + SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );
                } else {
                    skillDetails.put( AFGReportConstants.SKILL_DESCRIPTION, SMUtils.getKeyValueFromResponse( skillDetail.toString(), AFGReportConstants.LO_DESCRIPTION ) );

                }
                List<String> students = new ArrayList<>();
                JSONArray stduentArray = new JSONObject( skillDetail.toString() ).getJSONArray( AFGReportConstants.STUDENT_ROWS );
                List<String> studentDetailList = new ArrayList<>();
                IntStream.range( 0, stduentArray.length() ).forEach( itr -> studentDetailList.add( stduentArray.get( itr ).toString() ) );

                studentDetailList.stream().forEach( student -> {
                    students.add( SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.STUDENT_NAME ) + "," + SMUtils.getKeyValueFromResponse( student.toString(), AFGReportConstants.FAILED_DATE ).substring( 0, 10 ) );
                } );

                studentDetailFromResponse.put( skillDetails.get( AFGReportConstants.LEVEL ) + "-" + skillDetails.get( AFGReportConstants.SKILL_DESCRIPTION ), students );
            } );

        } );
        return studentDetailFromResponse;
    }

    @Test ( priority = 1, dataProvider = "testPositiveScenario", groups = { "Admin AFG Report Graphql", "SMK-63993", "Area for Growth-BFF", "P1", "smoke_test_case" } )
    public void testAFGRepostAPISchema( String testcaseId, String description, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseId + ":-" + description );
        Map<String, String> filters = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        String assignmentIds = "";
        String subject = null;
        String assignmentName = null;
        Map<String, List<String>> assignmentUserIdsFromDB;
        Map<String, List<String>> studentsFromResponse;
        Map<String, List<String>> studentsFromDB = new HashMap<>();

        try {
            switch ( scenario ) {
                case "DISTRICT_ADMIN":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, districtId );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );
                    assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    Log.message( assignmentIds );
                    Log.message( ReportData.orgId );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SCHOOL_ADMIN":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SUBDISTRICT_ADMIN":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.subDistrictAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.subDistrictAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "MULTI_ADMIN":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_ADDITIONALGROUPING_DEFAULTMATH":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultMathAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultMathAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_READING_SINCE_IP":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( ReportAdminConstants.DATE_AT_RISK, "10400" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "FILTER_BY_READING_24_WEEKS":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( ReportAdminConstants.DATE_AT_RISK, "24" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }

                    break;

                case "DISABILITY_YES":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.DISABILITY_STATUS, "YES" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "DISABILITY_NO_AND_NOT_SPECIFIED":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.DISABILITY_STATUS, "NO\\\",\\\"NOT_SPECIFIED" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ENGLISH_PROFICIENCY":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.ENGLISH_PROFICIENCY, "ENGLISH" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ENGLISH_PROFICIENCY_MULTIPLE":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.multiSchoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.multiSchoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.ENGLISH_PROFICIENCY, "ENGLISH_LANGUAGE_LEARNER\\\",\\\"NOT_SPECIFIED" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "MIGRANT_SINGLE_OPTION":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.MIGRANT_STATUS, "MIGRANT" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "MIGRANT_MULTIPLE_OPTION":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.MIGRANT_STATUS, "NON_MIGRANT\\\",\\\"NOT_SPECIFIED" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ECONOMIC_STATUS_SINGLE_OPTION":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.SOCIO_STATUS, "ECONOMICALLY_DISADVANTAGED" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "ECONOMIC_STATUS_MULTIPLE_OPTION":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.SOCIO_STATUS, "NOT_ECONOMICALLY_DISADVANTAGED\\\",\\\"NOT_SPECIFIED" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SPECIAL_SERVICES_SINGLE_OPTION":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.SPECIAL_SERVICES, "PLAN_504" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                        }
                        Thread.sleep( 5000 );
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "SPECIAL_SERVICES_MULTIPLE_OPTION":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.schoolAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "primaryOrgId" ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.schoolAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.defaultReadingAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );

                    assignmentIds = ReportData.defaultReadingAssignmentDetails.values().stream().map( assignmentDetails -> {
                        String assignmentdetail = assignmentDetails.values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null );
                        return SMUtils.getKeyValueFromResponse( assignmentdetail, "assignmentId" );
                    } ).collect( Collectors.toList() ).toString().replace( "[", "" ).replace( "]", "" ).replace( " ", "" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );
                    filters.put( DemographicFilters.SPECIAL_SERVICES, "GIFTED_TALENTED\\\",\\\"IEP\\\",\\\"OTHER\\\",\\\"NO_SPECIAL_SERVICES" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "IPM_ON_MATH":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, districtId );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );
                    assignmentIds = SMUtils.getKeyValueFromResponse(
                            ReportData.mathSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                            "assignmentId" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    Log.message( assignmentIds );
                    Log.message( ReportData.orgId );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "IPM_OFF_MATH":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, districtId );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Math" );
                    subject = ReportsUIConstants.MATH;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );
                    assignmentIds = SMUtils.getKeyValueFromResponse(
                            ReportData.mathSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                            "assignmentId" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    Log.message( assignmentIds );
                    Log.message( ReportData.orgId );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "IPM_ON_READING":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, districtId );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );
                    assignmentIds = SMUtils.getKeyValueFromResponse(
                            ReportData.readingSettingIPMONAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                            "assignmentId" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    Log.message( assignmentIds );
                    Log.message( ReportData.orgId );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;

                case "IPM_OFF_READING":
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( ReportData.districtAdmin, password ) );
                    headers.put( Constants.ORGID_SM_HEADER, districtId );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( ReportData.districtAdminDetails, "userId" ) );

                    filters.put( ReportAdminConstants.SUBJECT, "Reading" );
                    subject = ReportsUIConstants.READING;
                    assignmentName = SMUtils.getKeyValueFromResponse(
                            ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "courseDetail,name" ) ) ).findFirst().orElse( null ),
                            "courseDetail,name" );
                    assignmentIds = SMUtils.getKeyValueFromResponse(
                            ReportData.readingSettingIPMOFFAssignmentDetails.get( teacherUsername ).values().stream().filter( assignment -> Objects.nonNull( SMUtils.getKeyValueFromResponse( assignment, "assignmentId" ) ) ).findFirst().orElse( null ),
                            "assignmentId" );
                    filters.put( ReportAdminConstants.COURSES, assignmentIds );
                    Log.message( assignmentIds );
                    Log.message( ReportData.orgId );
                    filters.put( ReportAdminConstants.ORG_ID, ReportData.orgId );
                    filters.put( ReportAdminConstants.ADDITIONAL_GROUPING, "0" );

                    response = new ReportAPI().getAFGAdminReportData( headers, filters );
                    if ( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                            || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) {
                        for ( int i = 0; i < 5; i++ ) {
                            response = new ReportAPI().getAFGAdminReportData( headers, filters );
                            if ( !( response.getBody().asString().contains( ReportsAPIConstants.NOT_AUTHENTICATED_MESSAGE ) || response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE )
                                    || response.getBody().asString().contains( ReportsAPIConstants.INTERNAL_SERVER_ERROR ) ) ) {
                                break;
                            }
                            Thread.sleep( 5000 );
                        }
                    }
                    Log.message( "Response: " + response.getBody().asString() );
                    // Verifying Status Code
                    Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                            "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

                    if ( !response.getBody().asString().contains( ReportsAPIConstants.ZERO_STATE_MESSAGE ) ) {
                        // Verifying schema in the Response body
                        Log.assertThat( new SchemaValidation().isSchemaValid( "AFG_Admin_Schema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    } else {
                        Log.assertThat( new SchemaValidation().isSchemaValid( "NoDataFound", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                    }
                    break;
            }

        } catch ( ValidationException e ) {
            ReportAPIConstants.keyValidation( response, "AFG" );
        }

        Log.testCaseResult();
    }
}