package com.savvas.sm.reports.ui.pages.teacher;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.utils.SMUtils;

public class PrescriptiveSchedulingPage extends LoadableComponent<PrescriptiveSchedulingPage> {

	private final WebDriver driver;
	boolean isPageLoaded;
	public ReportFilterComponent reportFilterComponent;

	@FindBy(css = "h1.report-heading")
	WebElement pageTitle;

	@FindBy(css = "p.description")
	WebElement description;
	
	@FindBy ( tagName = "cel-date-input" )
	WebElement targetDateRoot;
	
	@FindBy (css = "div.target-level-section label")
	List<WebElement> gradeLabels;
	
    
	/**
	 * 
	 * Constructor class for Login page Here we initializing the driver for page
	 * factory objects.
	 * 
	 * @param driver
	 * @param url
	 */
	public PrescriptiveSchedulingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		reportFilterComponent = new ReportFilterComponent(driver);
	}

	@Override
	protected void load() {
		// TODO Auto-generated method stub
		isPageLoaded = true;
		SMUtils.waitForElement(driver, description);
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		try {
			SMUtils.waitForSpinnertoDisapper(driver, 30);
		} catch (InterruptedException e) {
			Log.message("Issue in Spinner Loading");
		}
		if (SMUtils.waitForElement(driver, description, 30)) {
			Log.message("Area For Growth Page loaded successfully.");
		} else {
			Log.fail("Area For Growth Page not loaded successfully.");
		}
	}
	
	public boolean selectTargetDateAsCurrentDate() {
        boolean flag = false;
        try {
            SMUtils.nap( 10 );
            SMUtils.waitForElement( driver, targetDateRoot );
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, targetDateRoot, "cel-icon-button.calendar-button" ) );
            SMUtils.waitForElement( driver, targetDateRoot );
            WebElement calparent = SMUtils.getWebElement( driver, targetDateRoot, "cel-calendar.cel-calendar-component.hydrated" );
            SMUtils.waitForElement( driver, calparent );
            WebElement currentDate = SMUtils.getWebElement( driver, calparent, "div table tbody tr td.today span" );
            SMUtils.nap( 10 );
            SMUtils.clickJS( driver, currentDate );

            //date.sendKeys( dateStr );
            Log.message( "Date Selected" );
            flag = true;
        } catch ( Exception e ) {
            Log.message( "User is unable to select the current date" );
        }
        return flag;
    }
	
	/**
     * Fill the target levels for grades
     * 
     * @return
     */
    public void fillTargetLevels( String gradeName, String gradeValue ) throws Exception {
        SMUtils.waitForElement( driver, gradeLabels.get(0));
        for (WebElement element : gradeLabels) {
        	if (element.getText().trim().equals(gradeName)) {
        		WebElement ele = element.findElement(By.xpath("./.."));
        		WebElement ele1 = ele.findElement(By.cssSelector("div input"));
        		ele1.sendKeys( Keys.BACK_SPACE );
        		ele1.sendKeys( Keys.BACK_SPACE );
        		ele1.sendKeys( Keys.BACK_SPACE );
        		ele1.sendKeys( Keys.BACK_SPACE );
        		ele1.sendKeys(gradeValue);
        	}
        }
        Log.message( "Target Levels Updated" );
    }
    
       
        
}
