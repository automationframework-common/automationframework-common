package com.savvas.sm.reports.ui.tests.admin.cpar;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformanceAggregatePage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.ReportFilterComponent;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class CumulativePerformanceAggregateRequiredFieldTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    AreaForGrowthPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    CumulativePerformancePage cprPage;
    CumulativePerformanceAggregatePage cpAggregatePage;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify all availble field on CPR and CP aggregate report for Saved report Options", groups = { "Smoke", "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMCPRAggregateReport001:Verify all availble field on CPR and CP aggregate report for Saved report Options<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );
            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Cumulative Performance navigates the user to the Cumulative Performance Report page" );
            SMUtils.logDescriptionTC( "Verify the Cumulative Performance Report label is displayed in Cumulative Performance Page" );
            Log.assertThat( cprPage.getCPRHeading().equalsIgnoreCase( ReportsUIConstants.CPR_HEADER ), "CPR header text is displying", "CPR header text is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the alignment and color code after selection of Cumulative Performance report" );
            Log.assertThat( cprPage.isCPRColorDisplay(), "Cumulative performance report color is displaying", "Cumulative performance report color is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the help icon is displayed in the Cumulative Performance Report Page" );
            Log.assertThat( cprPage.reportFilterComponent.isHelpIconDisplayed(), "Help icon is displying", "Help icon is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the description is displayed in Cumulative Performance Report Page" );
            Log.assertThat( cprPage.reportFilterComponent.getReportDescription().equalsIgnoreCase( ReportsUIConstants.CPR_DESCRIPTION ), "CPR description is displaying", "CPR description is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default selection of toggle is Cumulative Performance page" );
            Log.assertThat( cprPage.isCPRSelected(), "CPR has selected and present", "CPR has not present and not selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the selection of Cumulative Performance Aggregate navigates to Cumulativer Performance Aggregate page" );
            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the color and alignment of the selection when the user selects the Cumulative Performance Aggregate toggle" );
            Log.assertThat( cpAggregatePage.isCPRAggregateColorDisplay(), "Color is displaying for CPR aggregate", "Color is not displaying for CPR aggregate" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Saved Report Option label is displayed in the Cumulative Performance Aggregate Page" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "Saved Report option is displaying", "Saved report option is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Saved Report Option drop down is displayed in the Cumulative Performance Aggregate page" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ), "Saved Report option text is displaying", "Saved Report option text is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verfify the default text in the displayed in the Saved Report Option drop down" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getPlaceHolderFromSingleSelectSaveDropdown().equals( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_WATER_MARK ),
                    "The cumulative Performance Aggregate Save Report Option drop down water mark text is displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_WATER_MARK,
                    "The cumulative Performance Aggregate Save Report Option drop down water mark text is not displayed as " + ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_WATER_MARK );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed in the Saved Report Option drop down" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ), "Arror button is down and display",
                    "Arror button is not down and not display" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Saved Report option drop down is listed with saved report options" );
            cpAggregatePage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).size() > 0, "Values are displyed under save report option",
                    "Values are not displaying under save report option" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed in the Saved Report Option drop down is expanded" );
            cpAggregatePage.reportFilterComponent.expandSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSingleSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).equals( "Down" ), "The arrow is in Downward direction when it is expanded",
                    "The arrow is in Upward direction when it is expanded" );
            Log.testCaseResult();

            /*
             * SMUtils.logDescriptionTC(
             * "Verify the saved report option name is displayed when it is selected"
             * ); String selectingOption =
             * cpAggregatePage.reportFilterComponent.
             * getAvailableOptionsFromSingleSelectDropdown(
             * ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL ).get(
             * 1 ); cpAggregatePage.reportFilterComponent.
             * selectOptionsFromSingleSelectDropdown(
             * ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL,
             * selectingOption ); Log.message( selectingOption ); String
             * savedReportWaterMarkText = cpAggregatePage.reportFilterComponent.
             * getPlaceHolderFromSingleSelectDropdown(
             * ReportsUIConstants.RECENT_SESSION_SAVE_REPORT_OPTION_LABEL );
             * Log.message( savedReportWaterMarkText ); Log.testCaseResult();
             */

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all availble field on CPR aggregate report for organization dropdown.", groups = { "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            Log.testCaseInfo( "tcSMCPRAggregateReport002:Verify all availble field on CPR aggregate report for organization dropdown.<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            SMUtils.logDescriptionTC( "Verify the Organizations label is displayed in the Cumulative Performance Aggregate  page" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization label is displayed", "The Organization label is not displayed" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization label is displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    "The Organization label is not displayed as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Organizations drop down is displayed in the Cumulative Performance Aggregate  page" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isMultiSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The Organization drop down is displayed", "The Organization drop down is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verfify the default text in the displayed in the Organizations drop down" );
            Log.assertThat( dashBoardPage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK ),
                    "The Organization drop down water mark text is not verified as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK,
                    "The Organization drop down water mark text is verified as " + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed when the Organization drop down is collapsed" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isMultiSelectDropDownArrowDisplayed( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ),
                    "The cumulative Performance Aggregate Organizations drop down arrow is displayed and it is verified", "The cumulative Performance Aggregate Organizations drop down arrow is not displayed and it is verified" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getMultiSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Organizations drop down is expandable when it is clicked" );
            cpAggregatePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getMultiSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( "Up" ), "The arrow is in Upward direction when it is Expanded",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Search box is displayed in the Organizations drop down" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isSearchBarDisplay( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The cumulative Performance Aggregate Organizations drop down search box is displayed and it is verified",
                    "The cumulative Performance Aggregate Organizations drop down search box is not displayed and it is verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default text in the search box of Organizations drop down" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getMultiSelectSearchPlaceHolder( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK ),
                    "The water mark of search box is verified as" + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK,
                    "The water mark of search box is not verified as" + ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search icon is displayed in the search box of Organizations drop down" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isSearchIconDisplayedForMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ), "The search icon in the search box is displayed",
                    "The search icon in the search box is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify All option is displayed with check box in the Organizations drop down" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( "ALL" ) );
            List<String> allOptionsFromOrganizationDropdown = cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL );
            allOptionsFromOrganizationDropdown.remove( "ALL" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll( allOptionsFromOrganizationDropdown ), "All options are selected",
                    "All options are not selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify when All is unchecked all the values in the Organizations drop down is selected" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL, Arrays.asList( "ALL" ) );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).isEmpty(), "All options are unselected", "All options are selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify only one Organization is selected the default text displays the organization name in the drop down" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ) ) );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll(
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ) ) ), "All options are selected", "All options are not selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify more than one Organization is selected the default text displays the organization name in the drop down" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 2 ),
                            cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 3 ) ) );
            Log.assertThat(
                    cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).containsAll(
                            Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ),
                                    cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 2 ),
                                    cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 3 ) ) ),
                    "All given options are selected", "All given options are not selected" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Course Selection label is displayed in the Cumulative performance Aggregate page", groups = { "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMCPRAggregateReport003:Verify the Course Selection label is displayed in the Cumulative performance Aggregate page<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            Log.assertThat( cpAggregatePage.reportFilterComponent.getCourseSelectionLabel().equalsIgnoreCase( ReportsUIConstants.RECENT_SESSION_COURSE_SELECTION_LABEL ), "The Course Selection label is verified ",
                    "The Course Selection label is not verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Subject label is displayed in the Cumulative Performance Aggregate report page", groups = { "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            Log.testCaseInfo( "tcSMCPRAggregateReport004: Verify the Subject label is displayed in the Cumulative Performance Aggregate report page<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            SMUtils.logDescriptionTC( "Verify the Subject label is displayed in the Cumulative Performance aggregate page" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ), "The Subject label is displayed", "The Subject label is not displayed" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ), "The Subject label is verified ", "The Subject label is not verified " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Subject drop down is displayed in the Cumulative Performance aggregate Page" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isSingleSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default text is displayed in the subject drop down" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.RECENT_SESSION_SUBJECT_WATERMARK ),
                    "The Subject drop down default text is verified", "The Subject drop down default text is not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the drop down values of the Subject drop down values" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).containsAll( ReportsUIConstants.SUBJECTS ), "The Subject drop down values are verified",
                    "The Subject drop down values are not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Subject drop down is a single select drop down" );
            SMUtils.logDescriptionTC( "Verify the tick symbol is displayed when any of the subject drop down values are selecred" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            cpAggregatePage.reportFilterComponent.collapseSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL );
            Log.message( cpAggregatePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ) );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getPlaceHolderFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL ).equals( ReportsUIConstants.MATH ), "The given value is selected in Subject drop down",
                    "The given value is not selected in Subject drop down" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Courses label and drop down Cumulative Performance Aggregate report page", groups = { "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            Log.testCaseInfo( "tcSMCPRAggregateReport005:Verify the Courses label and drop downCumulative Performance Aggregate report page<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            SMUtils.logDescriptionTC( "Verify the Course(s) label is displayed in the Cumulative performance,  drop down" );
            SMUtils.logDescriptionTC( "Verify the Courses drop down is displayed and disabled by default" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isDropdownLabelDisplayed( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses label is displayed", "The Courses label is not displayed" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses label is verifed and displayed as " + ReportsUIConstants.RECENT_SESSION_COURSES_LABEL,
                    "The Courses label is not verified" );
            Log.testCaseResult();

            Log.assertThat( cpAggregatePage.reportFilterComponent.isMultiSelectDropDownDisplayed( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses drop down is displayed", "The Courses drop down is not displayed" );
            Log.assertThat( !cpAggregatePage.reportFilterComponent.isMultiSelectDropdownEnabled( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The Courses drop down is disabled mode", "The Courses drop down is not disabled mode" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Course drop down default text when no courses are available" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL,
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_ORGANIZATIONS_LABEL ).get( 1 ) ) );

            cpAggregatePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.READING );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).equalsIgnoreCase( ReportsUIConstants.COURSES_ZERO_STATE ), "Zero state is displaying",
                    "Zero state is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the arrow button is displayed when the course drop down is collapsed" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.RECENT_SESSION_SUBJECT_LABEL, ReportsUIConstants.MATH );
            Log.assertThat( cpAggregatePage.reportFilterComponent.isMultiSelectDropDownArrowDisplayed( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ), "The cumulative Performance Aggregate Organizations drop down arrow is displayed and it is verified",
                    "The cumulative Performance Aggregate Organizations drop down arrow is not displayed and it is verified" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getMultiSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).equals( "Down" ), "The arrow is in downward direction when it is collapsed",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the course drop down is expandable when it is clicked" );
            cpAggregatePage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getMultiSelectDropdownArrowDirection( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).equals( "Up" ), "The arrow is in Upward direction when it is Expanded",
                    "The arrow is in Upward direction when it is collapsed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify All option is displayed with check box in the courses drop down" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "ALL" ) );
            List<String> allOptionsFromOrganizationDropdown = cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL );
            allOptionsFromOrganizationDropdown.remove( "ALL" );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).containsAll( allOptionsFromOrganizationDropdown ), "All options are selected",
                    "All options are not selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify when All is unchecked all the values in the courses drop down is selected" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL, Arrays.asList( "ALL" ) );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).isEmpty(), "All options are unselected", "All options are selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify only one Organization is selected the default text displays the courses name in the drop down" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL,
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 1 ) ) );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).containsAll(
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 1 ) ) ), "All options are selected", "All options are not selected" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify more than one Organization is selected the default text displays the courses name in the drop down" );
            cpAggregatePage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL,
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 2 ),
                            cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 3 ) ) );
            Log.assertThat( cpAggregatePage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).containsAll(
                    Arrays.asList( cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 1 ),
                            cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 2 ),
                            cpAggregatePage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RECENT_SESSION_COURSES_LABEL ).get( 3 ) ) ),
                    "All given options are selected", "All given options are not selected" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Cumulative Performance Aggregate page is displayed for District admin", groups = { "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            Log.testCaseInfo( "tcSMCPRAggregateReport006:Verify the Cumulative Performance Aggregate page is displayed for District admin<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            SMUtils.logDescriptionTC( "Verify Cumulative performance Aggregate page is displayed for District admin" );
            Log.assertThat( cpAggregatePage.isCPAggregateSelected(), "Cumulative performance Aggregate page is displaying", "Cumulative performance Aggregate page is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Cumulative Performance Aggregate page is displayed for Sub-district admin", groups = { "Smoke", "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            Log.testCaseInfo( "tcSMCPRAggregateReport007:Verify the Cumulative Performance Aggregate page is displayed for Sub-district admin<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            SMUtils.logDescriptionTC( "Verify the Cumulative Performance Aggregate is displayed for Sub-district admin" );
            Log.assertThat( cpAggregatePage.isCPAggregateSelected(), "Cumulative performance Aggregate page is displaying", "Cumulative performance Aggregate page is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Cumulative Performance Aggregate page is displayed for Sub-district admin", groups = { "Smoke", "SMK-57899", "CumulativePerformanceAggregate", "CumulativePerformanceAggregate" }, priority = 1 )
    public void tcSMCPRAggregateReport008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            Log.testCaseInfo( "tcSMCPRAggregateReport008:Verify the Cumulative Performance Aggregate page is displayed for Sub-district admin<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ), password );

            //Navigating to Cumulative performance report filter page
            cprPage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();

            //Navigating to Cumulative performance Aggregate report filter page
            cpAggregatePage = cprPage.getCPRAggregatePage();

            SMUtils.logDescriptionTC( "Verify the Cumulative Performance aggregate page is displayed for School admin" );
            Log.assertThat( cpAggregatePage.isCPAggregateSelected(), "Cumulative performance Aggregate page is displaying", "Cumulative performance Aggregate page is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
