package com.savvas.sm.reports.exportcsv.admin.tests;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.exportcsv.pages.ExportPopupComponent;
import com.savvas.sm.reports.ui.pages.*;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.IntStream;

public class AdminCPAReportExportCsvTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtAdminUsername;
    private String districtAdminUserId;
    private String districtId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String schoolName;
    private String orgId;
    Map<String, String> headers = new HashMap<>();
    private List<String> teacherUsernames;
    private Map<String, String> teacherUserIds = new HashMap<>();
    List<String> gradeIds = new ArrayList<>();
    private Map<String, String> teacherNames = new HashMap<>();
    Map<String, String> groupDetail = new HashMap<>();
    String[] studentGrades;

    @BeforeClass ( alwaysRun = true )
    public void init() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

       //To fetch the admin details from Report data
       try {
            districtAdminUsername = ReportDataCollection.districtAdmin;
            districtAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
            districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        } catch ( Exception e ) {
            Log.failsoft( "Getting issue while fetch the admin details from Report data" );
        }
        schoolName = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.FLEX_SCHOOL );
        orgId = ReportDataCollection.orgId;

        //To get teacher Details
        teacherUsernames = new ArrayList<>( ReportDataCollection.teacherDetails.keySet() );
        teacherUsernames.stream().forEach( userName -> teacherUserIds.put( userName, SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), Constants.USERID ) ) );
        teacherUsernames.stream().forEach( userName -> teacherNames.put( userName,
                SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), "firstName" ) + " " + SMUtils.getKeyValueFromResponse( ReportDataCollection.teacherDetails.get( userName ), "lastName" ) ) );

        //To get group Detail
        IntStream.range( 0, 2 ).forEach( itr -> groupDetail.put( SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( itr ).toString(), "groupId" ),
                SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( itr ).toString(), "groupName" ) ) );

        //To get gradeIds
        studentGrades = SMUtils.getKeyValueFromResponse( new JSONArray( ReportDataCollection.teacherGroupDetails.get( teacherUsernames.get( 0 ) ) ).get( 0 ).toString(), "studentGradeIds" ).replace( "[", "" ).replace( "]", "" ).split( "," );
        for ( String grade : studentGrades ) {
            if ( grade.length() > 1 ) {
                gradeIds.add( grade );
            } else if ( grade.equals( "k" ) ) {
                gradeIds.add( "KG" );
            } else {
                gradeIds.add( "0" + grade );
            }

        }

    }

    @Test ( enabled = true, groups = { "SMK-72253", "CPAR - Export csv", "smoke_test_case" }, description = "(Admin CPAR)Verify Label and Export Report Export Report CSV link appears on top right corner of the report ouput screen" )
    public void tcAdminCPARExportCsv001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPARExportCsv001 - (Admin CPAR)Verify Label and Export Report Export Report CSV link appears on top right corner of the report ouput screen" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpareportpage = cpreportpage.navigateToCPAReport();

            SMUtils.logDescriptionTC( "tc001 - Verify the user should navigates to Cumulative Performance Aggregate page" );
            Log.assertThat( cpareportpage.isCPAReportSelected(), "The user navigates to Cumulative Performance Aggregate page successfully!", " The user not navigates to Cumulative Performance Aggregate page properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc002 - Verify Student Demographics label is displayed in the Cumulative Performance Aggregate Page" );
            cpareportpage.reportFilterComponent.expandOptionalFilter();
            Log.assertThat( cpareportpage.reportFilterComponent.getStudentDemographicsLabel().equalsIgnoreCase( ReportsUIConstants.STUDENT_DEMOGRAPHICS ), "Student demographics label displayed properly",
                    "Student demographics label not displayed properly. Expected - " );
            Log.testCaseResult();

            //Expand the student demographics
            SMUtils.logDescriptionTC( "tc003 - Verify the Disability Status, Gender, Race, SocioEconomic Status, English Language Proficiency, Migrant Status, Ethnicity, Special seivices option are displayed under the Student demographics field" );
            cpareportpage.reportFilterComponent.expandStudentDemographics();
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.DISABILITY_STATUS ), "Disability status dropdown label is displayed properly", "Issue in display th Disability status dropdown label!" );
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.RACE ), "Race dropdown label is displayed properly", "Issue in display th Race dropdown label!" );
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SOCIOECONOMIC_STATUS ), "SocioEconomic Status dropdown label is displayed properly",
                    "Issue in display the SocioEconomic Status dropdown label!" );
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ), "English Language Proficiency dropdown label is displayed properly",
                    "Issue in display the English Language Proficiency dropdown label!" );
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.MIGRANT_STATUS ), "Migrant Status dropdown label is displayed properly", "Issue in display the Migrant Status dropdown label!" );
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.ETHNICITY ), "Ethnicity dropdown label is displayed properly", "Issue in display the Ethnicity dropdown label!" );
            Log.assertThat( cpareportpage.reportFilterComponent.getDropdownLabels().contains( ReportsUIConstants.SPECIAL_SERVICES ), "Special seivices option dropdown label is displayed properly",
                    "Issue in display the Special seivices option dropdown label!" );
            Log.testCaseResult();

            //Disability status dropdown
            SMUtils.logDescriptionTC( "tc004 - Verify the Disability status dropdown option contains values" );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).containsAll( ReportsUIConstants.DISABILITY_STATUS_OPTIONS ),
                    "ALL options properly in disability status are displayed successfully!", "ALL options properly in disability status are not displayed properly" );
            Log.testCaseResult();
            //Selecting all option in disability status dropdown
            SMUtils.logDescriptionTC( "tc005 - Verify the admin can select all option in Disability status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).containsAll( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();
            //deselect all option in disability status dropdown
            SMUtils.logDescriptionTC( "tc006 - Verify the default text of the Disability status drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in disability status dropdown!", "Issue in deselecting all the option in disability status dropdown!" );
            Log.testCaseResult();

            //Selecting single option in disability status dropdown
            SMUtils.logDescriptionTC( "tc007 - Verify the admin can select single option in Disability status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals( Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in disability status dropdown", "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in disability status dropdown
            SMUtils.logDescriptionTC( "tc008 - Verify the admin can select multiple option in Disability status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS, Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS );
            // Log.message( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).toString() );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.DISABILITY_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.DISABILITY_STATUS_OPTIONS.get( 2 ) ) ), "User able to select the multiple option in disability status dropdown",
                    "Issue in selecting the option in disability status dropdown!" );
            Log.testCaseResult();

            //Race dropdown
            SMUtils.logDescriptionTC( "tc009 - Verify the Race dropdown option contains values" );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).containsAll( ReportsUIConstants.RACE_OPTIONS ), "ALL options properly in race are displayed successfully!",
                    "ALL options properly in race are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in race dropdown
            SMUtils.logDescriptionTC( "tc010 - Verify the admin can select All option in race drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).containsAll( ReportsUIConstants.RACE_OPTIONS.subList( 1, 8 ) ), "User able to select the all option in race dropdown",
                    "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //deselect all option in race dropdown
            SMUtils.logDescriptionTC( "tc011 - Verify the default text of the race drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.RACE ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ), "User able to deselect all the option in race dropdown!",
                    "Issue in deselecting all the option in race dropdown!" );
            Log.testCaseResult();

            //Selecting single option in race dropdown
            SMUtils.logDescriptionTC( "tc012 - Verify the admin can select single option in race drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in race dropdown", "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in race dropdown
            SMUtils.logDescriptionTC( "tc013 - Verify the admin can select multiple option in race drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE, Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.RACE );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.RACE ).equals( Arrays.asList( ReportsUIConstants.RACE_OPTIONS.get( 1 ), ReportsUIConstants.RACE_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in race dropdown", "Issue in selecting the option in race dropdown!" );
            Log.testCaseResult();

            //SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "tc014 - Verify the Socioeconomic Status  dropdown option contains values" );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS ),
                    "ALL options properly in SocioEconomic Status are displayed successfully!", "ALL options properly in SocioEconomic Status are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "tc015 - Verify the admin can select All option in SocioEconomic Status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).containsAll( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //deselect all option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "tc016 - Verify the default text of the SocioEconomic Status drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in SocioEconomic Status dropdown!", "Issue in deselecting all the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //Selecting single option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "tc017 - Verify the admin can select single option in SocioEconomic Status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals( Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in SocioEconomic Status dropdown", "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in SocioEconomic Status dropdown
            SMUtils.logDescriptionTC( "tc018 - Verify the admin can select multiple option in SocioEconomic Status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS,
                    Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SOCIOECONOMIC_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.get( 2 ) ) ), "User able to select the multiple option in SocioEconomic Status dropdown",
                    "Issue in selecting the option in SocioEconomic Status dropdown!" );
            Log.testCaseResult();

            //English language proficiency dropdown
            SMUtils.logDescriptionTC( "tc019 - Verify the English Language Proficiency dropdown option contains values" );
            Log.message( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).toString() );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS ),
                    "ALL options properly in english language proficiency are displayed successfully!", "ALL options properly in english language proficiency are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "tc020 - Verify the admin can select All option in english language proficiency drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.message( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).toString() );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).containsAll( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in english language proficiency dropdown", "Issue in selecting the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //deselect all option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "tc021 - Verify the default text of the english language proficiency drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in english language proficiency dropdown!", "Issue in deselecting all the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //Selecting single option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "tc022 - Verify the admin can select single option in english language proficiency drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals( Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in english language proficiency dropdown", "Issue in selecting the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in english language proficiency dropdown
            SMUtils.logDescriptionTC( "tc023 - Verify the admin can select multiple option in english language proficiency drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY,
                    Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY ).equals(
                            Arrays.asList( ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 1 ), ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.get( 2 ) ) ), "User able to select the multiple option in english language proficiency dropdown",
                    "Issue in selecting the option in english language proficiency dropdown!" );
            Log.testCaseResult();

            //Migrant status dropdown
            SMUtils.logDescriptionTC( "tc024 - Verify the Migrant dropdown option contains values" );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).containsAll( ReportsUIConstants.MIGRANT_STATUS_OPTIONS ),
                    "ALL options properly in migrant status are displayed successfully!", "ALL options properly in migrant status are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in migrant status dropdown
            SMUtils.logDescriptionTC( "tc025 - Verify the admin can select All option in migrant status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).containsAll( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.subList( 1, 4 ) ),
                    "User able to select the all option in migrant status dropdown", "Issue in selecting the option in migrant status dropdown!" );
            Log.testCaseResult();

            //deselect all option in migrant status dropdown
            SMUtils.logDescriptionTC( "tc026 - Verify the default text of the migrant status drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in migrant status dropdown!", "Issue in deselecting all the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Selecting single option in migrant status dropdown
            SMUtils.logDescriptionTC( "tc027 - Verify the admin can select single option in migrant status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals( Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in migrant status dropdown", "Issue in selecting the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in migrant status dropdown
            SMUtils.logDescriptionTC( "tc028 - Verify the admin can select multiple option in migrant status drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS, Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.MIGRANT_STATUS ).equals(
                            Arrays.asList( ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 1 ), ReportsUIConstants.MIGRANT_STATUS_OPTIONS.get( 2 ) ) ), "User able to select the multiple option in migrant status dropdown ",
                    "Issue in selecting the option in migrant status dropdown!" );
            Log.testCaseResult();

            //Ethnicity dropdown
            SMUtils.logDescriptionTC( "tc029 - Verify the Ethnicity dropdown option contains values" );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).containsAll( ReportsUIConstants.ETHNICITY_OPTIONS ), "ALL options properly in ethnicity are displayed successfully!",
                    "ALL options properly in ethnicity are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "tc030 - Verify the admin can select All option in Ethnicity drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).containsAll( ReportsUIConstants.ETHNICITY_OPTIONS.subList( 1, 3 ) ),
                    "User able to select the all option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //deselect all option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "tc031 - Verify the default text of the Ethnicity drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in Ethnicity dropdown!", "Issue in deselecting all the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Selecting single option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "tc032 - Verify the admin can select single option in Ethnicity drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Ethnicity dropdown", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Ethnicity dropdown
            SMUtils.logDescriptionTC( "tc033 - Verify the admin can select multiple option in Ethnicity drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY, Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.ETHNICITY );
            Log.assertThat(
                    cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.ETHNICITY ).equals( Arrays.asList( ReportsUIConstants.ETHNICITY_OPTIONS.get( 1 ), ReportsUIConstants.ETHNICITY_OPTIONS.get( 2 ) ) ),
                    "User able to select the multiple option in Ethnicity dropdown ", "Issue in selecting the option in Ethnicity dropdown!" );
            Log.testCaseResult();

            //Special Services
            SMUtils.logDescriptionTC( "tc034 - Verify the Special Services dropdown option contains values" );
            Log.assertThat( cpareportpage.reportFilterComponent.getAvailableOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS ),
                    "ALL options properly in special services are displayed successfully!", "ALL options properly in special services are not displayed properly" );
            Log.testCaseResult();

            //Selecting all option in Special Services dropdown
            SMUtils.logDescriptionTC( "tc035 - Verify the admin can select All option in Special Services drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).containsAll( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.subList( 1, 7 ) ),
                    "User able to select the all option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

            //deselect all option in Special Services dropdown
            SMUtils.logDescriptionTC( "tc036 - Verify the default text of the Special Services drop down when admin deselect all the option" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            Log.assertThat( cpareportpage.reportFilterComponent.getPlaceHolderFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equalsIgnoreCase( ReportsUIConstants.NONE_OF_THE_OPTIONS_SELECTED ),
                    "User able to deselect all the option in Special Services dropdown!", "Issue in deselecting all the option in Special Services dropdown!" );
            Log.testCaseResult();

            //Selecting single option in Special Services dropdown
            SMUtils.logDescriptionTC( "tc037 - Verify the admin can select single option in Special Services drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equals( Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ) ) ),
                    "User able to select the single option in Special Services dropdown", "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

            //Selecting multiple option in Special Services dropdown
            SMUtils.logDescriptionTC( "tc038 - Verify the admin can select multiple option in Special Services drop down" );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SELECT_ALL ) );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES, Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) );
            cpareportpage.reportFilterComponent.collapseMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES );
            Log.assertThat( cpareportpage.reportFilterComponent.getSelectedOptionsFromMultiSelectDropdown( ReportsUIConstants.SPECIAL_SERVICES ).equals(
                            Arrays.asList( ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 1 ), ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.get( 2 ) ) ), "User able to select the multiple option in Special Services dropdown ",
                    "Issue in selecting the option in Special Services dropdown!" );
            Log.testCaseResult();

            //Expand organization dropdown
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName );

            //Selecting required fields - selecting organization
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( schoolName ) );
            //To select the Subject
            cpareportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.MATH );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //Click Run Report button

            CPAReportViewerPage cpaoutputpage = cpareportpage.clickRunBtn();

            SMUtils.logDescriptionTC( "tc039 - (Admin CPAR)Verify Export Report CSV link appears on top right corner of the report ouput screen" );
            Log.assertThat( cpaoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc040 - Verify the report name is display in the header in CPR aggregate." );
            Log.assertThat( cpaoutputpage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpaoutputpage.reportOutputComponent.clickExportCSVButton();

            SMUtils.logDescriptionTC( "tc041 - (Admin CPAR)Verify Export Report CSV popup appears after user click on Export Report CSV link" );
            //Verifying the Export Report CSV popup header
            Log.assertThat( exportPopup.getExportReportCsvPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORT_DATA_HEADER ), "Export Report CSV popup loaded properly after clicked the ecport CSV button",
                    "Export Report CSV popup not loaded properly after clicked the ecport CSV button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc042 - (Admin CPAR)Verify the fields available in the Export Report CSV popup" );
            Log.assertThat( exportPopup.getExportTypeLabels().containsAll( Arrays.asList( ReportsUIConstants.EXPORT_DEFAULT, ReportsUIConstants.CUSTOMIZE_EXPORT ) ), "Both Default and custom export labels are present in Export Report CSV popup",
                    " Default and custom export labels are not displaying in Export Report CSV popup. Expected - " + Arrays.asList( ReportsUIConstants.EXPORT_DEFAULT, ReportsUIConstants.CUSTOMIZE_EXPORT ) + ". Actual -"
                            + exportPopup.getExportTypeLabels() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc043 - (Admin CPAR)Verify the option selected by default in Export Report CSV popup" );
            Log.assertThat( exportPopup.isDefaultExportRadioButtonSelected(), "Default export radio button is selected by default", "Default export radio button is not selected by default" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc044 - (Admin CPAR)Verify clicking on Cancel button button will close the Export Report CSV popup" );
            exportPopup.clickCancelButtonInExportReportCSVPopup();
            Log.assertThat( !exportPopup.isCloseButtonDisplayedInExportReportCSVPopup(), "The Export Report CSV popup closed after clicked the cancel button", "The Export Report CSV popup not closed after clicked the cancel button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc045 - (Admin-CPAR) Verify CSV gets Download after user completed their column selection and click OK" );
            exportPopup = cpaoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();
            Log.assertThat( ExportCsvUtils.isCsvFileDownloaded( driver ), "CSV file downloaded properly after clicked the ok Button", "CSV file not downloaded properly after clicked the ok Button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc046 - (Admin CPAR)Verify the file name of the downloaded csv for Reading subject" );
            Log.assertThat( ExportCsvUtils.getCsvFileNameFromBS( driver ).contains( "Cumulative Performance Aggregate" ), "The exported csv file has proper file name.", "The exported csv has not contain Cumulative Performance name." );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-72253", "CPAR - Export csv", "smoke_test_case" }, description = "(Admin CPAR)Verify the columns available in exported csv for math assignments" )
    public void tcAdminCPARExportCsv002() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPARExportCsv002 - (Admin CPAR)Verify the columns available in exported csv for math assignments" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpareportpage = cpreportpage.navigateToCPAReport();

            //Expand organization dropdown
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName );

            //Selecting required fields - selecting organization
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( schoolName ) );
            //To select the Subject
            cpareportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.MATH );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpareportpage.clickRunBtn();

            SMUtils.logDescriptionTC( "tc047 - Verify 'the CPR aggregate Report generation with mandatory field'." );
            SMUtils.logDescriptionTC( "Verify the report name is display in the header in CPR aggregate." );
            Log.assertThat( cpoutputpage.getReportPageTitle().equals( ReportsUIConstants.CPRA_HEADER ), "Cumulative Performance Aggregate is displayed in report viewer page header",
                    "Cumulative Performance Aggregate is not displayed in report viewer page header" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc048 - Verify the Course name, Report run, school, teacher, grade and group are present under the header in CPR aggregate." );
            Log.assertThat( cpoutputpage.getSubjectLabel().equals( Constants.MATH ), "Assignment name is present", "Assignment name is not present" );
            Log.assertThat( cpoutputpage.getDateLabel().equals( cpoutputpage.getDateAndTime() ), "Date is present", "Date is not present" );
            Log.assertThat( cpoutputpage.getSelectedOptionLabel().contains( ReportsUIConstants.SELECTED_OPTION_HEADER ), "Selected Options header is present", "Selected Options header is not present" );

            Log.assertThat( cpoutputpage.verifyLegend(), "Legend values are displayed", "Legend values are not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc049 - Verify the available columns in CPR aggregate." );
            Log.assertThat( cpoutputpage.getColumnHeaders().equals( ReportsUIConstants.CPAReport.TABLE_HEADER ), "Table column names are displayed as expected", "Table column names are not displayed as expected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc050 - Verify the page number in CPR aggregate." );
            Log.assertThat( cpoutputpage.verifyPagination(), "Page number is displayed in CPA report viewer page ", "Page number is not displayed in CPA report viewer page " );
            Log.testCaseResult();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );

            SMUtils.logDescriptionTC( "tc051 - (Admin CPAR)Verify the columns available in exported csv for math assignments" );
            Log.assertThat( columnsFromResponse.containsAll( ReportsUIConstants.CPARExportCsv.DEFAULT_HEADERS ), "All colum headers are fetched properly for Math Assignment",
                    "All colum headers are not fetched properly for Math Assignment. Expected -" + ReportsUIConstants.CPARExportCsv.DEFAULT_HEADERS + ".Actual - " + columnsFromResponse );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-72253", "CPAR - Export csv", "smoke_test_case" }, description = "(Admin CPAR)Verify the columns available in exported csv for Reading assignments" )
    public void tcAdminCPARExportCsv003() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPARExportCsv003 - (Admin CPAR)Verify the columns available in exported csv for Reading assignments" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpareportpage = cpreportpage.navigateToCPAReport();

            //Expand organization dropdown
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName );

            //Selecting required fields - selecting organization
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( schoolName ) );
            //To select the Subject
            cpareportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.READING );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpareportpage.clickRunBtn();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );
            List<String> columnsFromResponse = ExportCsvUtils.getCSVHeadersFromResponse( csvDataFromBS );

            SMUtils.logDescriptionTC( "tc052 - (Admin CPAR)Verify the columns available in exported csv for Reading assignments" );
            Log.assertThat( columnsFromResponse.containsAll( ReportsUIConstants.CPARExportCsv.DEFAULT_HEADERS ), "All colum headers are fetched properly for Math Assignment",
                    "All colum headers are not fetched properly for Math Assignment. Expected -" + ReportsUIConstants.CPARExportCsv.DEFAULT_HEADERS + ".Actual - " + columnsFromResponse );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-72253", "CPAR - Export csv", "smoke_test_case" }, description = "(Admin CPAR)Verify the fields available in the available columns custom export" )
    public void tcAdminCPARExportCsv004() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPARExportCsv004 - (Admin CPAR)Verify the fields available in the available columns for - Custom Export" + browser + "]</b></i></small>" );

        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpareportpage = cpreportpage.navigateToCPAReport();

            //Expand organization dropdown
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName );

            //Selecting required fields - selecting organization
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( schoolName ) );
            //To select the Subject
            cpareportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 1 ) );
            //To select the assignment
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.READING );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.READING ) );

            //Click Run Report button
            CPAReportViewerPage cpoutputpage = cpareportpage.clickRunBtn();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickCustomizeExportRadioButton();

            SMUtils.logDescriptionTC( "tc053 -(Admin CPAR)Verify the fields available in the available columns for custom export" );
            List<String> availableColumnsFromUI = exportPopup.getAllAvailableColumns();
            Log.message( availableColumnsFromUI.toString() );
            Log.assertThat( availableColumnsFromUI.containsAll( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS ), "All the custom fields are available for reading",
                    "custom fields are not displaying properly for reading.Expected - " + ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS + ".Actual -" + availableColumnsFromUI );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc054-(Admin-CPAR) Verify Right double arrow (>>)is active (blue color) when user nothing is selected from the available columns" );
            Log.assertThat( exportPopup.isChevronDoubleRightButtonEnabled(), "Chevron double - right arrow is enabled by default", "Chevron double - right arrow is disabled by default" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc055 -(Admin-CPAR) Verfiy the user able to selects Single select and mulit select in the Available columns" );
            exportPopup.selectAvailableColumns( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ), ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            Log.assertThat( exportPopup.getCheckedAvailableColumns().containsAll( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ), ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) ),
                    "User able to select the options in available columns", "Getting issue while select the available columns!!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc056 -(Admin-CPAR) Verify the user can transfer selected single values from available columns to selected columns by clicking the Chevoron-right button" );
            exportPopup.selectAvailableColumns( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ) );
            exportPopup.clickChevronRightButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 0 ).equals( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ), "Selected field is transffered to selected columns from available columns",
                    "Selected fields is not transffered to selected columns from available columns!!!" );
            Log.testCaseResult();

            exportPopup.clickChevronDoubleLeftButton();
            SMUtils.logDescriptionTC( "tc057- (Admin-CPAR) Verify the user can transfer the selected columns values to available columns by clicking the Chevorons-left button" );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.selectSelectedColumns( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ) );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( !exportPopup.getAllSelectedColumns().contains( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ) ), "Single Selected field is transffered to availble columns from selected columns",
                    "Single Selected fields is not transffered to available columns from selected columns!!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc058- (Admin-CPR) Verify the user can transfer selected multiple values from selected columns values to available columns by clicking the Chevoron-left button" );
            exportPopup.selectSelectedColumns( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ), ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( !exportPopup.getAllSelectedColumns().containsAll( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ), ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 2 ) ) ),
                    "Multiple Selected field is transffered to availble columns from selected columns", "Multiple Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc058 -(Admin-CPAR) Verify the user can transfer selected all values from selected columns values to available columns by clicking the Chevoron-left button" );
            exportPopup.clickChevronDoubleRightButton();
            exportPopup.selectSelectedColumns( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS );
            exportPopup.clickChevronLeftButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().isEmpty(), "All Selected field is transffered to available columns from selected columns",
                    "All Selected fields is not transffered to available columns from selected columns!!!.Actual -" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc059 -(Admin CPAR)Verify the user can move the selected values upwords by clicking Cheron-up in Selected columns" );
            exportPopup.selectAvailableColumns( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 0 ), ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronRightButton();
            exportPopup.selectSelectedColumns( Arrays.asList( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ) );
            exportPopup.clickChevronUpButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 0 ).equals( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ), "user able to move the selected fields upwards by clicking chevron up button",
                    "user unable to move the selected fields upwards by clicking chevron up button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc060 -(Admin CPAR)Verify the user can move the selected values downwords by clicking Chevron-down in Selected columns" );
            exportPopup.clickChevronDownButton();
            Log.assertThat( exportPopup.getAllSelectedColumns().get( 1 ).equals( ReportsUIConstants.CPARExportCsv.CUSTOM_AVAILABLE_COLUMNS.get( 1 ) ), "user able to move the selected fields upwards by clicking chevron down button",
                    "user unable to move the selected fields upwards by clicking chevron down button" + exportPopup.getAllSelectedColumns() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-72253", "CPAR - Export csv", "smoke_test_case" }, description = "(Admin CPAR)Verify Export Report Export Report CSV data with UI" )
    public void tcAdminCPARExportCsv005() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminCPRExportCsv005 - (Admin CPAR)Verify Export Report Export Report CSV data with UI - Student" + browser + "]</b></i></small>" );
        try {
            //Launch the url
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();

            //Login as a district admin
            AreaForGrowthPage AFGPage = smLoginPage.loginToSM( districtAdminUsername, password );

            //Navigate to CPR Page
            CumulativePerformancePage cpreportpage = AFGPage.reportFilterComponent.clickOnCumulativePerformancePage();
            CumulativePerformanceAggregatePage cpareportpage = cpreportpage.navigateToCPAReport();

            //Expand organization dropdown
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, schoolName );

            //Selecting required fields - selecting organization
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL, Arrays.asList( schoolName ) );
            //To select the Subject
            cpareportpage.reportFilterComponent.selectOptionsFromSingleSelectDropdown( ReportsUIConstants.CPR_SUBJECT_LABEL, ReportsUIConstants.SUBJECTS.get( 0 ) );
            //To select the assignment
            cpareportpage.reportFilterComponent.expandMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL );
            cpareportpage.reportFilterComponent.enterTextInSearchBar( ReportsUIConstants.CPR_COURSES_LABEL, ReportsUIConstants.MATH );
            cpareportpage.reportFilterComponent.selectOptionsFromMultiSelectDropdown( ReportsUIConstants.CPR_COURSES_LABEL, Arrays.asList( ReportsUIConstants.MATH ) );

            //Click Run Report button

            CPAReportViewerPage cpoutputpage = cpareportpage.clickRunBtn();

            Log.assertThat( cpoutputpage.reportOutputComponent.isExportCSVIconVisible(), "Export csv icon is displaying in last session output page!!!", "Export csv icon is not displaying properly in last session output page!!!" );
            Log.testCaseResult();

            //Click Export CSV Button
            ExportPopupComponent exportPopup = cpoutputpage.reportOutputComponent.clickExportCSVButton();
            exportPopup.clickOkButton();

            //Verifying the delay popup Header
            Log.assertThat( exportPopup.getDownloadingModalPopupHeader().equalsIgnoreCase( ReportsUIConstants.EXPORTING_CSV_FILE ), "Delay message popup loaded properly", "Delay message popup not loaded properly" );

            //to get the downloaded file
            String csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

            SMUtils.logDescriptionTC( "tc061 - (Admin CPAR)Verify Export Report Export Report CSV data with UI" );
            String school = cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SCHOOL );
            List<Map<String, String>> exportedCSVFromUI = ExportCsvUtils.splitCSVData( csvDataFromBS );
            Map<String, String> data = new HashMap<>();
            for ( Map<String, String> dt : exportedCSVFromUI ) {
                if ( dt.get( "\"" + ReportsUIConstants.CPReportConstant.SCHOOL + "\"" ).equals( school ) ) {
                    data = dt;
                    break;
                }
            }
            Log.message( data.toString() );
            Log.assertThat( school.equals( data.get( "\"" + ReportsUIConstants.CPReportConstant.SCHOOL + "\"" ) ), "School Name matched in UI and CSV Data", "School Name not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL ) ),
                    "Current Course Level matched in UI and CSV Data", "Current Course Level not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.IP_LEVEL + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.IP_LEVEL ) ), "IP Level matched in UI and CSV Data",
                    "IP Level not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.GAIN + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.GAIN ) ), "Gain matched in UI and CSV Data",
                    "Gain not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TIME_SPENT + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.TIME_SPENT ) ), "Time Spent matched in UI and CSV Data",
                    "Time Spent not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR ) ),
                    "Total Sessions matched in UI and CSV Data", "Total Sessions not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT ) ),
                    "Exercises Correct matched in UI and CSV Data", "Exercises Correct not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED ) ),
                    "Exercises Attempted matched in UI and CSV Data", "Exercises Attempted not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + "\"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT ) ),
                    "Exercises Percent Correct matched in UI and CSV Data", "Exercises Percent Correct not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + " \"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED ) ), "Skills Assessed matched in UI and CSV Data",
                    "Skills Assessed not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + " \"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_MASTERED ) ), "Skills Mastered matched in UI and CSV Data",
                    "Skills Mastered not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + " \"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED ) ),
                    "Skills Percent Mastered matched in UI and CSV Data", "Skills Percent Mastered not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + " \"" ), cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP ) ),
                    "Percent Student with AP matched in UI and CSV Data", "Percent Student with AP not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.MEAN ) ), "Current Course Level - Mean matched in UI and CSV Data",
                    "Current Course Level - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                    cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.MEAN ) ), "IP Level - Mean matched in UI and CSV Data", "IP Level - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                    cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.MEAN ) ), "Gain - Mean matched in UI and CSV Data", "Gain - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                    cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.MEAN ) ), "Time Spent - Mean matched in UI and CSV Data", "Time Spent - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + ReportsUIConstants.CPReportConstant.MEAN.trim() + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + ReportsUIConstants.CPReportConstant.MEAN ) ), "Total Sessions - Mean matched in UI and CSV Data",
                    "Total Sessions - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.MEAN ) ), "Exercises Correct - Mean matched in UI and CSV Data",
                    "Exercises Correct - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.MEAN ) ), "Exercises Attempted - Mean matched in UI and CSV Data",
                    "Exercises Attempted - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.MEAN + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.MEAN ) ), "Exercises Percent Correct - Mean matched in UI and CSV Data",
                    "Exercises Percent Correct - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.MEAN + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.MEAN ) ), "Skills Assessed - Mean matched in UI and CSV Data",
                    "Skills Assessed - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.MEAN + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.MEAN ) ), "Skills Mastered - Mean matched in UI and CSV Data",
                    "Skills Mastered - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.MEAN + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.MEAN ) ), "Skills Percent Mastered - Mean matched in UI and CSV Data",
                    "Skills Percent Mastered - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + ReportsUIConstants.CPReportConstant.MEAN + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + ReportsUIConstants.CPReportConstant.MEAN ) ), "Percent Student with AP - Mean matched in UI and CSV Data",
                    "Percent Student with AP - Mean not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.CURRENT_COURSE_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Current Course Level - SD matched in UI and CSV Data",
                    "Current Course Level - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                    cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.IP_LEVEL + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "IP Level - SD matched in UI and CSV Data", "IP Level - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                    cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.GAIN + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Gain - SD matched in UI and CSV Data", "Gain - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.TIME_SPENT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Time Spent - SD matched in UI and CSV Data",
                    "Time Spent - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION.trim() + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.TOTAL_SESSIONS_CPAR + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Total Sessions - SD matched in UI and CSV Data",
                    "Total Sessions - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Exercises Correct - SD matched in UI and CSV Data",
                    "Exercises Correct - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_ATTEMPTED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Exercises Attempted - SD matched in UI and CSV Data",
                    "Exercises Attempted - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + "\"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.EXERCISES_PERCENT_CORRECT + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Exercises Percent Correct - SD matched in UI and CSV Data",
                    "Exercises Percent Correct - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_ASSESSED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Skills Assessed - SD matched in UI and CSV Data",
                    "Skills Assessed - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Skills Mastered - SD matched in UI and CSV Data",
                    "Skills Mastered - SD not matched in UI and CSV Data" );

            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.SKILLS_PERCENT_MASTERED + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Skills Percent Mastered - SD matched in UI and CSV Data",
                    "Skills Percent Mastered - SD not matched in UI and CSV Data" );
            Log.assertThat( compareValues( data.get( "\"" + ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION + " \"" ),
                            cpoutputpage.getValueOfColumnCPAR( ReportsUIConstants.CPReportConstant.PERCENT_STUDENT_WITH_AP + ReportsUIConstants.CPReportConstant.STANDARD_DEVIATION ) ), "Percent Student with AP - SD matched in UI and CSV Data",
                    "Percent Student with AP - SD not matched in UI and CSV Data" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    public static boolean compareValues( String csvData, String uiData ) {
        if ( csvData.contains( "NA" ) ) {
            if ( uiData.equalsIgnoreCase( csvData ) ) {
                return true;
            } else {
                Integer uiDataNumeric = Integer.parseInt( uiData.replaceAll( "[^0-9]", "" ) );
                if ( uiDataNumeric == 0 ) {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return csvData.equalsIgnoreCase( uiData );
        }
    }
}
