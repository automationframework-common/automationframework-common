package com.savvas.sm.reports.ui.tests.admin.cpr;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.poi.hpsf.Array;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.reports.constants.ReportsAPIConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.ui.pages.AdminLauncherPage;
import com.savvas.sm.reports.ui.pages.AreaForGrowthPage;
import com.savvas.sm.reports.ui.pages.CumulativePerformancePage;
import com.savvas.sm.reports.ui.pages.LeftNavigationBar;
import com.savvas.sm.reports.ui.pages.RecentSessionsPage;
import com.savvas.sm.reports.ui.pages.StudentPerformancePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.Constants.UserUIConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentDetailsForGivenTeacherConstants;

public class CumulativePerfomanceReportTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    LeftNavigationBar dashBoardPage;
    AdminLauncherPage smLoginPage;

    private HashMap<String, String> organizationDetails = null;
    private HashMap<String, String> allTeacherDetails = null;
    private HashMap<String, String> groupDetails = new HashMap<String, String>();
    private List<String> orgNames = new ArrayList<String>();
    private List<String> expgroupNames = new ArrayList<String>();
    private List<String> expteacherNames = new ArrayList<String>();
    private List<String> teacherIds = new ArrayList<String>();
    private List<String> groupIds = new ArrayList<String>();
    private String subDistrictschoolName;
    private String flexSchoolName;
    private String schoolAdmin;
    private String flexSchoolId;
    private String mathSchool;
    private String mathschoolId;
    private String districtId;
    private String mathFlexAdmin;
    private String flexSchoolAdmin;
    public static String[] schools;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        schools = configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," );

        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        subDistrictschoolName = configProperty.getProperty( "Rumba_subDistrictSchool" );
        schoolAdmin = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );

        // Flex school Admin create
        flexSchoolName = schools[4];
        flexSchoolId = new RBSUtils().getOrganizationIDByName( districtId, flexSchoolName );
        flexSchoolAdmin = "flexschooladmin7686" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) == null ) {
            HashMap<String, String> adminDetails = new HashMap<>();
            adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, flexSchoolName );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, flexSchoolId );
            adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
            adminDetails.put( RBSDataSetupConstants.USERNAME, flexSchoolAdmin );
            boolean createCAUserWithAccess = new RBSUtils().createCAUserWithAccess( adminDetails, true );
        }

        new RBSUtils().resetPassword( flexSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( flexSchoolAdmin ) );

        // Admin create of Math and Reading School
        mathSchool = schools[0];
        mathschoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), mathSchool );

        mathFlexAdmin = "mathFlexadmin1234" + districtId.substring( 25, 31 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

        if ( new RBSUtils().getUserIDByUserName( mathFlexAdmin ) == null ) {
            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, mathFlexAdmin );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, mathschoolId + "\"," + "\"" + flexSchoolId );
            String admin = new RBSUtils().createUser( userDetails );
            new RBSUtils().resetPassword( mathschoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( admin, RBSDataSetupConstants.USERID ) );
        }

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "adminUsernames" )
    public Object[][] positiveData() {
        Object[][] inputData = { { flexSchoolAdmin, flexSchoolName }, { RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), subDistrictschoolName }, { RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), flexSchoolName } };
        return inputData;
    }

    @Test ( enabled = true, description = "Verify each Admin Test", groups = { "Smoke", "SMK-59890", "Cumulative Perfomance Report", "CPR" }, priority = 1, dataProvider = "adminUsernames" )
    public void tcSMCumulativePerfomanceTest001( String adminUsernames, String School ) throws Exception {

        Log.message( "Loggin in with Admin:=> " + adminUsernames );

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( adminUsernames, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            HashMap<String, String> orgDetails = cumulativePerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( orgDetails.keySet() );
            List<String> orgIds = cumulativePerformancePage.getOrganizationIds();

            List<String> schoolIds = new RBSUtils().getAllSchoolIdsForAdmins( adminUsernames );
            List<String> expOrgIds = new RBSUtils().getOrgIdsForReport( schoolIds );

            Collections.sort( expOrgIds );
            Collections.sort( orgIds );

            Log.testCaseInfo( "Verify the organization list" );
            Log.assertThat( SMUtils.compareTwoList( expOrgIds, orgIds ), "The organization list is mathcing", "The organization list is mathcing is not mathcing for \nExpected:" + expOrgIds.toString() + " \nActual:" + orgIds.toString() );
            Log.testCaseResult();

            cumulativePerformancePage.setOrganizationsValue( School );
            cumulativePerformancePage.clickOptionalFilter();

            Log.testCaseInfo( "Verify the Teacher First Name, Last Name for the Teacher is correct" );
            Log.testCaseInfo( "Verify the Teacher Details for single Organization" );

            List<String> actualTeacherNames = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.TEACHERS );
            getTeacherNames( orgDetails.get( School ) );
            Collections.sort( expteacherNames );
            Collections.sort( actualTeacherNames );
            Log.testCaseInfo( "Verify the Teacher Details for all the Techer Details Organization" );
            Log.assertThat( expteacherNames.containsAll( actualTeacherNames ), "All the Teacher is Present", "The teacher is not matched\n Actual" + expteacherNames.toString() + "\nActual :" + actualTeacherNames.toString() );
            Log.testCaseResult();

            Log.testCaseInfo( "Verify if the Group list is showing for the single teacher" );
            if ( !actualTeacherNames.isEmpty() ) {
                cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.TEACHERS, Arrays.asList( actualTeacherNames.get( 0 ) ) );
            }
            List<String> allValuesFromGroupsDropdown = cumulativePerformancePage.getGroupNames();
            expgroupNames = getGroupListNames( cumulativePerformancePage.getGroupIds() );
            Collections.sort( expgroupNames );
            Collections.sort( allValuesFromGroupsDropdown );

            Log.assertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, description = "Valid Multiple Teacher is Selected", groups = { "SMK-59890", "Cumulative Perfomance Report", "CPR" }, priority = 2 )
    public void tcSMCumulativePerfomanceTest002() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( schoolAdmin, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            HashMap<String, String> orgDetails = cumulativePerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( orgDetails.keySet() );

            cumulativePerformancePage.setOrganizationsValue( flexSchoolName );

            cumulativePerformancePage.clickOptionalFilter();

            Log.testCaseInfo( "Verify if the Grde Dropdown is listed all the grade" );
            Log.testCaseInfo( "Verify if the Grde Dropdown is listed Not specified Grade" );
            List<String> allValuesFromGradesDropdown = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.GRADES );
            Log.assertThat( allValuesFromGradesDropdown.containsAll( Constants.Students.ALL_GRADES ), "The Grade Values is matching", "The Grade Values is matching" );
            Log.testCaseResult();

            cumulativePerformancePage.expanDropdown( cumulativePerformancePage.GRADES );
            cumulativePerformancePage.clickSelectAll( cumulativePerformancePage.GRADES );
            Log.testCaseInfo( "Verify if the Grade All is selected when ticked All option" );
            Log.assertThat( cumulativePerformancePage.isSelectAllChecked( cumulativePerformancePage.GRADES ), "The Select All option is Checked", "The Select All option is not Checked" );
            cumulativePerformancePage.clickGradesDropdown();
            Log.testCaseResult();

            Log.testCaseInfo( "Verify the Teacher Details for more thatn one  Teacher is selected" );
            List<String> actualTeacherNames = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.TEACHERS );
            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.TEACHERS, actualTeacherNames.subList( 1, 3 ) );

            List<String> allValuesFromGroupsDropdown = cumulativePerformancePage.getGroupNames();
            expgroupNames = getGroupListNames( cumulativePerformancePage.getGroupIds() );
            Collections.sort( expgroupNames );
            Collections.sort( allValuesFromGroupsDropdown );

            Log.assertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched" + expgroupNames.toString() + "Actual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, description = "When All Teacher is Selected", groups = { "SMK-59890", "Cumulative Perfomance Report", "CPR" }, priority = 3 )
    public void tcSMCumulativePerfomanceTest003() throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( schoolAdmin, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            HashMap<String, String> organizationDetails = cumulativePerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( organizationDetails.keySet() );

            cumulativePerformancePage.setOrganizationsValue( flexSchoolName );
            cumulativePerformancePage.clickOptionalFilter();

            cumulativePerformancePage.clickSelectAll( cumulativePerformancePage.TEACHERS );
            List<String> allValuesFromGroupsDropdown = cumulativePerformancePage.getGroupNames();

            getGroupListNames( cumulativePerformancePage.getGroupIds() );

            Collections.sort( expgroupNames );
            Collections.sort( allValuesFromGroupsDropdown );

            Log.testCaseInfo( "Verify if the Group list is showing for the more than teacher" );
            Log.assertThat( expgroupNames.containsAll( allValuesFromGroupsDropdown ), "All the Groups is Present", "The groups is not matched \nExpected\n" + expgroupNames.toString() + "\nActual :\n" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, priority = 4, description = "Without SuccessMaker Groups ", groups = { "SMK-59890", "Cumulative Perfomance Report", "CPR" } )
    public void tcSMCumulativePerfomanceTest004() throws Exception {
        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( mathFlexAdmin, password );
            Log.message( "Loggin in with Admin: " + mathFlexAdmin );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            HashMap<String, String> organizationDetails = cumulativePerformancePage.getOrganizationDetails();
            orgNames = new ArrayList<String>( organizationDetails.keySet() );

            String orgId1 = mathschoolId;
            String orgId2 = flexSchoolId;

            //teacher create - orgId1 orgId2    
            String teacherUsernameCreate = "teacher16546d9" + districtId.substring( 28, 32 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
            String teacherdetailsCreate = null;
            String teacherIdCreate = null;
            try {
                if ( new RBSUtils().getUserIDByUserName( teacherUsernameCreate ) == null ) {
                    Log.message( "username is not present :" + teacherUsernameCreate );
                    teacherdetailsCreate = new UserAPI().createUserWithCustomization( teacherUsernameCreate, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId1, orgId2 ) );
                }
                teacherIdCreate = new RBSUtils().getUserIDByUserName( teacherUsernameCreate );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }

            // student create   orgId1 orgId2
            String studentUsernameCreate = "student14546d667" + districtId.substring( 28, 32 ) + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
            String studentDetailsCreate = null;
            String studentIdCreate = null;
            try {
                if ( new RBSUtils().getUserIDByUserName( studentUsernameCreate ) == null ) {
                    Log.message( "username is not present :" + studentUsernameCreate );
                    studentDetailsCreate = new UserAPI().createUserWithCustomization( studentUsernameCreate, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId1, orgId2 ) );
                }
                studentIdCreate = new RBSUtils().getUserIDByUserName( studentUsernameCreate );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }

            // resetting password
            new RBSUtils().resetPassword( orgId1, password, teacherIdCreate );

            String className = "Group Without SuccessMaker product" + System.nanoTime();
            String accessToken = new RBSUtils().getAccessToken( teacherUsernameCreate, password );

            String createClassWithoutSMProdcut = new RBSUtils().CreateClassWithoutSMProdcut( className, teacherIdCreate, studentIdCreate, orgId1, accessToken );

            // Group create for org1
            String org1Group = "Group for org " + orgId1.substring( 20 );
            accessToken = new RBSUtils().getAccessToken( teacherUsernameCreate, password );
            new RBSUtils().createClassWithMultipleTeacher( org1Group, new ArrayList<>( Arrays.asList( teacherIdCreate ) ), new ArrayList<>( Arrays.asList( studentIdCreate ) ), orgId1, accessToken );

            // Group create for org2
            String org2Group = "Group for org " + orgId2.substring( 20 );
            accessToken = new RBSUtils().getAccessToken( teacherUsernameCreate, password );

            new RBSUtils().createClassWithMultipleTeacher( org2Group, new ArrayList<>( Arrays.asList( teacherIdCreate ) ), new ArrayList<>( Arrays.asList( studentIdCreate ) ), orgId2, accessToken );

            String teacherDetails = new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( teacherUsernameCreate ) );
            StringBuffer FirstNamesLastNames = new StringBuffer();
            FirstNamesLastNames.append( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.FIRSTNAME ) );
            FirstNamesLastNames.append( " " );
            FirstNamesLastNames.append( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.LASTNAME ) );

            // Reading school 

            // Group Verify for org 2
            cumulativePerformancePage.setOrganizationsValue( flexSchoolName );
            cumulativePerformancePage.clickOptionalFilter();

            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.TEACHERS, Arrays.asList( FirstNamesLastNames.toString() ) );

            // Verifying group for org 2
            List<String> allValuesFromGroupsDropdown = cumulativePerformancePage.getGroupNames();
            Log.assertThat( allValuesFromGroupsDropdown.contains( org2Group ), "The Groups is not Present for without product", "The Groups is not Present for without product\n" + className + "\nActual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

            // Math School
            cumulativePerformancePage.setOrganizationsValue( mathSchool );
            cumulativePerformancePage.setValuesForDropdown( cumulativePerformancePage.TEACHERS, new ArrayList<>( Arrays.asList( FirstNamesLastNames.toString() ) ) );

            // Verifying group without succesmaker product
            allValuesFromGroupsDropdown = cumulativePerformancePage.getGroupNames();
            Collections.sort( allValuesFromGroupsDropdown );

            Log.testCaseInfo( "Verify if the Group list is showing for that has No SM prodcut" );
            Log.assertThat( !allValuesFromGroupsDropdown.contains( className ), "The Groups is not Present for without product as expected!",
                    "The Groups is not Present for without product\n" + className + "\nActual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

            // Verifying group for org 1
            Log.assertThat( allValuesFromGroupsDropdown.contains( org1Group ), "The Groups is present for the org1 Teacher",
                    "The Groups is present for the org1 Teacher\n org 1 Group Expected\n" + org1Group + "\nActual :" + allValuesFromGroupsDropdown.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( enabled = false, priority = 1, description = "Verify all the Student Demographic Values Dropdown Test", groups = { "SMK-59890", "Cumulative Perfomance Report", "CPR" } )
    public void tcSMCumulativePerfomancTest005() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( mathFlexAdmin, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            cumulativePerformancePage.clickOptionalFilter();
            cumulativePerformancePage.clickStudentDemographics();

            // Verifying all the Header is correct

            Log.assertThat( cumulativePerformancePage.verifyStudentDemographicsHeader(), "The Students Demograhics header is matched!", "The Students Demograhics header is not matched!" );
            HashMap<String, List<String>> drodownValues = new HashMap<>();
            drodownValues.put( cumulativePerformancePage.DISABLITY_STATUS, ReportsUIConstants.DISABILITY_STATUS_OPTIONS.subList( 1, ReportsUIConstants.DISABILITY_STATUS_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.ENGLISH_LANGUAGE_PROFICIENCY, ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.subList( 1, ReportsUIConstants.ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.GENDER, ReportsUIConstants.GENDER_OPTIONS.subList( 1, ReportsUIConstants.GENDER_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.MIGRANT_STATUS, ReportsUIConstants.MIGRANT_STATUS_OPTIONS.subList( 1, ReportsUIConstants.MIGRANT_STATUS_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.RACE, ReportsUIConstants.RACE_OPTIONS.subList( 1, ReportsUIConstants.RACE_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.ETHINICIY, ReportsUIConstants.ETHNICITY_OPTIONS.subList( 1, ReportsUIConstants.ETHNICITY_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.SOCIO_ECONOMIC_STATUS, ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.subList( 1, ReportsUIConstants.SOCIOECONOMIC_STATUS_OPTIONS.size() ) );
            drodownValues.put( cumulativePerformancePage.SPECIAL_SERVICES, ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.subList( 1, ReportsUIConstants.SPECIAL_SERVICES_OPTIONS.size() ) );

            // Verification of Student DemoGraphics Filter  dropdown values
            drodownValues.keySet().stream().forEach( dropDown -> {
                cumulativePerformancePage.expanDropdown( dropDown );
                Log.testCaseInfo( "Verifying Select All Options: " + dropDown );
                cumulativePerformancePage.clickSelectAll( dropDown );
                Log.assertThat( cumulativePerformancePage.isSelectAllChecked( dropDown ), "The Dropdown  Selected All is checked", "The Dropdown  Selected All is not checked" );
                Log.testCaseResult();
                cumulativePerformancePage.closeDropdown( dropDown );

                List<String> allValuesFromDropdown = cumulativePerformancePage.getAllValuesFromDropdown( dropDown );
                List<String> expectedValues = drodownValues.get( dropDown );
                Log.message( "Verifying values for the dropdown: " + dropDown );

                Collections.sort( allValuesFromDropdown );
                Collections.sort( expectedValues );

                Log.assertThat( SMUtils.compareTwoList( expectedValues, allValuesFromDropdown ), "All the values in the Dropdown is mathched!",
                        "The dropdown values is not matched! \nExpected " + expectedValues.toString() + "\nActual" + allValuesFromDropdown.toString() );
                Log.testCaseResult();

                Log.testCaseInfo( "Verifying un select All Options: " + dropDown );
                cumulativePerformancePage.unSelectAll( dropDown );
                Log.assertThat( cumulativePerformancePage.getCheckedValuesForDropdown( dropDown ).isEmpty(), "Unselected All options is working as expected!", "Unselected All options is not working as expected! \nExpected" );
                Log.testCaseResult();

                Log.testCaseInfo( "Verifying Selecting single options for the Dropdown: " + dropDown );
                cumulativePerformancePage.unSelectAll( dropDown );
                cumulativePerformancePage.setValuesForDropdown( dropDown, new ArrayList<String>( Arrays.asList( allValuesFromDropdown.get( 0 ) ) ) );
                Log.assertThat( cumulativePerformancePage.getCheckedValuesForDropdown( dropDown ).equals( Arrays.asList( allValuesFromDropdown.get( 0 ) ) ), "Single Selected options is mathced! for Values: " + allValuesFromDropdown.get( 0 ),
                        "Single Selected options is not mathced!: " + allValuesFromDropdown.get( 0 ) );
                Log.testCaseResult();

                Log.testCaseInfo( "Verifying Selecting Multiple options for the Dropdown: " + dropDown );
                Collections.sort( allValuesFromDropdown );
                cumulativePerformancePage.setValuesForDropdown( dropDown, allValuesFromDropdown.subList( 0, 2 ) );
                List<String> checkValues = cumulativePerformancePage.getCheckedValuesForDropdown( dropDown );
                Collections.sort( checkValues );
                Log.assertThat( checkValues.equals( allValuesFromDropdown.subList( 0, 2 ) ), "Multiple selected options is mathced!", "Multiple selected options is not mathced!: " + allValuesFromDropdown.subList( 0, 2 ) );
                Log.testCaseResult();

            } );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = false, priority = 2, description = "Verify all the other Staic Values Test Data", groups = { "SMK-59890", "Cumulative Perfomance Report", "CPR" } )
    public void tcSMCumulativePerfomancTest006() throws Exception {

        //Get driver 
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            AreaForGrowthPage dashBoardPage = smLoginPage.loginToSM( mathFlexAdmin, password );
            CumulativePerformancePage cumulativePerformancePage = dashBoardPage.reportFilterComponent.clickOnCumulativePerformancePage();
            cumulativePerformancePage.waitForSpinnerToLoadAndDisppear();

            cumulativePerformancePage.clickOptionalFilter();

            // Additional Grouping test
            List<String> actValues = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.ADDITIONAL_GROUPING );
            Log.assertThat( SMUtils.compareTwoList( actValues, ReportsUIConstants.ADDITIONAL_GROUPING ), "All the values in Additional grouping is mathched!", "All the values in Additional grouping is not mathched!" + actValues.toString() );
            Log.testCaseResult();

            // Display Dropdown
            actValues = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.DISPLAY );
            Log.assertThat( SMUtils.compareTwoList( actValues, ReportsUIConstants.DISPLAY ), "All the values in Display is mathched!", "All the values in Display is not mathched!" + actValues.toString() );
            Log.testCaseResult();

            // Sort Dropdown
            actValues = cumulativePerformancePage.getAllValuesFromDropdown( cumulativePerformancePage.SORT );
            List<String> expValues = cumulativePerformancePage.SORT_DROPDOWN_VALUES;
            Collections.sort( actValues );
            Collections.sort( expValues );
            Log.assertThat( SMUtils.compareTwoList( actValues, expValues ), "All the values in Sort is mathched!", "All the values in Sort is not mathched!\n Expected: " + expValues.toString() + "\nActual: " + actValues.toString() );
            Log.testCaseResult();

            // mark Student Check box
            cumulativePerformancePage.clickMaskStudentCheckBox();
            Log.assertThat( cumulativePerformancePage.isMaskStudentisChecked(), "The Mark Student Check box is diplayed", "The Mark Student Check box is not diplayed" );

            // Date Range Selected Check
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );

            LocalDate from = LocalDate.now().with( TemporalAdjusters.firstDayOfMonth() );
            LocalDate to = LocalDate.now().with( TemporalAdjusters.lastDayOfMonth() );

            String startDate = dateFormat.format( ( from ) );
            String endDate = dateFormat.format( to );

            String[] fromValues = startDate.split( "/" );
            String[] EndValues = endDate.split( "/" );

            cumulativePerformancePage.clickSelectedDateRangeButton();
            cumulativePerformancePage.clickStartDateCalendar();
            cumulativePerformancePage.clickDayOnStartDateCalendar( "1" );
            cumulativePerformancePage.clickDayOnEndDateCalendar( EndValues[1] );

            List<String> selectedDatesFromCalendar = cumulativePerformancePage.getSelectedDatesFromCalendar();
            Log.assertThat( selectedDatesFromCalendar.get( 0 ).equals( startDate ), "The Date is mathced!", "The Date is not mathced!" );
            Log.assertThat( selectedDatesFromCalendar.get( 1 ).equals( endDate ), "The Date is mathced!", "The Date is not mathced!" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the Teacher Details From the OrgIds
     * 
     * @param orgIds
     * @return
     */

    public void getTeacherNames( String orgId ) {
        expteacherNames.clear();
        Log.message( "Getting teacher Details..." );
        List<String> teacherUsernames = new ArrayList<>();
        JSONArray teacherJsonArray = new RBSUtils().getAllTeachesForOrg( orgId );
        if ( !teacherJsonArray.equals( new JSONArray() ) ) {
            for ( Object user : teacherJsonArray ) {
                JSONObject userJson = new JSONObject( user.toString() );
                HashMap<String, String> otherDetails = new HashMap<String, String>();
                teacherUsernames.add( userJson.get( ReportsAPIConstants.TNS_FIRSTNAME ).toString() + " " + userJson.get( ReportsAPIConstants.TNS_LASTNAME ).toString() );
            }
        }
        expteacherNames.addAll( teacherUsernames );
    }

    /**
     * Get Group List Name for the GroupIds
     * 
     * @param groupIds
     * @return
     */
    public List<String> getGroupListNames( List<String> groupIds ) {
        expgroupNames.clear();
        Log.message( "Getting Groups Details..." );
        groupIds.forEach( groupId -> {
            String classDetails = new RBSUtils().getClass( groupId );
            expgroupNames.add( new SMAPIProcessor().getKeyValues( new JSONObject( classDetails ), ReportsAPIConstants.CLASSNAME ).get( 0 ) );
        } );

        return expgroupNames;
    }
}
