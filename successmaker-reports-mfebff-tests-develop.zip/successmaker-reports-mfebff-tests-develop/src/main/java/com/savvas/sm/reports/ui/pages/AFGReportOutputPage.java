package com.savvas.sm.reports.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.utils.SMUtils;

public class AFGReportOutputPage extends LoadableComponent<AFGReportOutputPage>{
	final WebDriver driver;
    boolean isPageLoaded;
    public ReportOutputComponent reportoutputComponent;
    
    
 // ********* SuccessMaker Launcher/Login Page Elements ***************
    
    /***************** POM for Page **************************/
    
    @FindBy ( css = "report-viewer-header h2" )
    WebElement pageTitle;
    
    @FindBy (css= "p.risk-label.mr-20")
    WebElement totalSkillsAtRisk;
    
    @FindBy (css= "p:nth-child(2)")
    WebElement  totalStudentsAtRisk;
    
    @FindBy ( css = "tr.header > th:nth-child(1)" )
    WebElement strandTitle; 
    
    @FindBy ( css = "tr.header > th:nth-child(2)" )
    WebElement levelTitle; 
    
    @FindBy ( css = "tr.header > th:nth-child(3)" )
    WebElement skillDescriptionTitle; 
    
    @FindBy ( css = "tr.sub-header:nth-child(2)")
    WebElement subHeaders; 
    
    @FindBy (css = "tr.areas-for-growth-row.skills:nth-child(n) > td:nth-child(1)")
    List <WebElement> strandValue;
    
    @FindBy (css = "tr.areas-for-growth-row.skills:nth-child(n) > td.skill-description:nth-child(3)")
    List <WebElement> skillDescriptionValue;
    
    @FindBy (css = "tr.areas-for-growth-row.skills:nth-child(n) > td:nth-child(2)")
    List <WebElement> levelValue;
    
    @FindBy (css = "tr.areas-for-growth-row.students.last-student:nth-child(n)")
    List <WebElement> studentValue;	
    
    @FindBy (css = "tr.areas-for-growth-row.students.last-student:nth-child(n) > td:nth-child(2)")
    List <WebElement> dateAtRisk;
    
    @FindBy (css = "tr.areas-for-growth-row.skills:nth-child(n) > td:nth-child(4)")
    List <WebElement> targetedLessonValue;
    
    @FindBy (css= "div.has-section-risk dl.detail-row.info dd:nth-child(8)")
    WebElement groupLabel;
    
    
    public AFGReportOutputPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportoutputComponent = new ReportOutputComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );
}
    @Override
	protected void isLoaded() throws Error {
		 try {
	            SMUtils.waitForSpinnertoDisapper( driver, 30 );
	        } catch ( InterruptedException e ) {
	            Log.message( "Issue in Spinner Loading" );
	        }
	        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
	            Log.message( "Areas for Growth Report Page loaded successfully." );
	        } else {
	            Log.fail( "Areas for Growth Report Page not loaded successfully." );
	        }

	    }
    /**
	 * Verifing the Areas for Growth Report page
	 */
	public boolean isAreasForGrowthReportPageLoaded() {
		boolean flag = false;
		if(SMUtils.isElementPresent(pageTitle)) {
			flag= true;
			Log.message("Areas For Growth Report OutputPage is loaded Successfully!!");
		}
		return flag;
	}
	
	   public boolean isTotalSkillsAtRisk() {
		   Log.message( "Verifying Total Number of Student At Risk is displayed" );
	        SMUtils.waitForElement( driver, totalSkillsAtRisk );
	        return SMUtils.isElementPresent( totalSkillsAtRisk );
	    }
	   
	   public boolean isTotalStudentsAtRisk(){
		   Log.message( "Verifying Total Number of Student At Risk is displayed" );
	        SMUtils.waitForElement( driver, totalStudentsAtRisk );
	        return SMUtils.isElementPresent( totalStudentsAtRisk );
	   }
	   public List<String> strandColumn() {
	        Log.message( "Getting Strand Column " );
	        SMUtils.waitForElement( driver,strandTitle);
	        return strandValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	    }
	   public List<String> levelColumn() {
	        Log.message( "Getting Level Column " );
	        SMUtils.waitForElement( driver,levelTitle);
	        return levelValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	   	}
	   public List<String> skillDescriptionColumn() {
	        Log.message( "Getting Skill Description Column " );
	        SMUtils.waitForElement( driver,skillDescriptionTitle);
	        return skillDescriptionValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	   	}
	   public List<String> studentColumn() {
	        Log.message( "Getting Student value" );
	        SMUtils.waitForElement( driver,subHeaders);
	        return studentValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	   	}
	   public List<String> dateAtRiskColumn() {
	        Log.message( "Getting At Risk Dates" );
	        SMUtils.waitForElement( driver,subHeaders);
	        return dateAtRisk.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	   	}
	   public List<String> targetedLessonColumn() {
	        Log.message( "Getting Targeted Lessons" );
	        SMUtils.waitForElement( driver,subHeaders);
	        return targetedLessonValue.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	   	}

		public String getGroupLabelValue() {
	        Log.message( "Getting Group Label Value" );
	        SMUtils.waitForElement( driver,subHeaders);
	        return groupLabel.getText();
	   	}
}
