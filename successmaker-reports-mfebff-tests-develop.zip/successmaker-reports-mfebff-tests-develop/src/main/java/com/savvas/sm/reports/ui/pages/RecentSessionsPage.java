package com.savvas.sm.reports.ui.pages;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.learningservices.utils.Log;
import com.savvas.sm.reports.bff.admin.tests.LSRReportAdminGraphQLTest;
import com.savvas.sm.reports.constants.ReportsUIConstants;
import com.savvas.sm.reports.constants.ReportsAPIConstants.adminLSRConstants;
import com.savvas.sm.reports.constants.ReportsUIConstants.AFGReportConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.rbs.RBSUtils;

public class RecentSessionsPage extends LoadableComponent<RecentSessionsPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public ReportFilterComponent reportFilterComponent;
    // ********* SuccessMaker Launcher/Login Page Elements ***************

    @FindBy ( tagName = "h1" )
    WebElement pageTitle;

    @FindBy ( css = "cel-side-navigation[class='side-nav-bar hydrated']" )
    WebElement sideNavigationRoot;

    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportButtonRoot;

    @FindBy ( css = "cumulative-performance > cel-accordion-item" )
    WebElement optionalFilterRoot;

    @FindBy ( css = "last-session > cel-accordion-item" )
    WebElement optionalFilterLSRoot;
    
    @FindBy ( css = "section.additional-filters-section checkbox-item > cel-checkbox-item" )
    WebElement checkBoxParent;
    
    @FindBy ( css = "report-grid td:nth-child(1)")
    public List<WebElement> outputStudentName;

    @FindBy ( css = "report-grid td:nth-child(2)")
    public List<WebElement> outputCurentCourseLevel;

    @FindBy ( css = "report-grid td:nth-child(3)")
    public List<WebElement> outputExercisesCorrect;

    @FindBy ( css = "report-grid td:nth-child(4)")
    public List<WebElement> outputExercisesAttempted;

    @FindBy ( css = "report-grid td:nth-child(6)")
    public List<WebElement> outputHelpUsed;

    @FindBy ( css = "report-grid td:nth-child(7)")
    public List<WebElement> outputTimeSpent;

    @FindBy ( css = "report-grid td:nth-child(8)")
    public List<WebElement> outputTotalSessions;

    @FindBy ( css = "report-grid td:nth-child(9)")
    public List<WebElement> outputSessionDate;
    
    @FindBy ( css = "report-grid td:nth-child(9)")
    public List<WebElement> outputHelpUsedRead;
    
    @FindBy ( css = "report-grid td:nth-child(10)")
    public List<WebElement> outputTimeSpentRead;
    
    @FindBy ( css = "report-grid td:nth-child(11)")
    public List<WebElement> outputTotalSessionsRead;
    
    @FindBy ( css = "report-grid td:nth-child(12)")
    public List<WebElement> outputSessionDateRead;

    @FindBy ( xpath = "//h2[@class='header']")
    WebElement reportHeader;

    @FindBy ( css = "div.table-container")
    WebElement reportTable;
    
    @FindBy ( css = ".info > dd:nth-of-type(3)")
    WebElement zeroState;
    
    @FindBy (css = "h3.assignment-name.ml-3")
    WebElement assignmentOutputName;
    
    @FindBy (css = ".info > dd:nth-of-type(1)")
    WebElement orgNameOutput;

    @FindBy (css = "[alt='Savvas']")
    WebElement footer;
    
    @FindBy (css = "p.header.mt-1")
    WebElement noDataToDisplay;
    
    @FindBy (css = "table#table>thead>tr>th")
    List<WebElement> outputTableHeadersRead;
    
    @FindBy ( css = "div .col-3 .list-head" )
    List<WebElement> headerLegend;
    
    @FindBy ( css = "dl.legends dt" )
    List<WebElement> legendLabels;

    @FindBy ( css = "dl.legends dd" )
    List<WebElement> legendLabelValues;
    
    @FindBy ( css = "[alt='successmaker']")
    WebElement smLogo;
    
    @FindBy ( css = "span.reports.text-lowercase")
    WebElement reportViewer;
    
    @FindBy ( css = "cel-button.pr-2" )
    WebElement runReportRoot;

    @FindBy ( css = "save-report-options cel-modal" )
    WebElement saveReportOption;

    @FindBy ( css = "cel-button.ml-auto" )
    WebElement reSet;
    

    // ****Child Elements****
    private String childSubNavigationMenu = "cel-side-item[data-label='Recent Sessions']";
    private String childSubNavigationButton = "button";
    private String headerCSS = "h2.header";
    private String button = "button";
    public String studentNameCSS = "#table > tbody > tr  > td:nth-child(1) > div";
    private String maskStudentCheckBoxCSS = "label > input[type=checkbox]";
    private String child = "cel-button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public RecentSessionsPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        reportFilterComponent = new ReportFilterComponent( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle, 30 ) ) {
            Log.message( "Recent Sessions Page loaded successfully." );
        } else {
            Log.fail( "Recent Sessions Page not loaded successfully." );
        }

    }

    /**
     * To verify the sub navigation is selected or not
     * 
     * @return
     */
    public boolean isRecentSessionSubNavigationSelected() {
        Log.message( "Verifing Recent Session Sub navigation is selected" );
        WebElement rootElement = SMUtils.getWebElement( driver, sideNavigationRoot, childSubNavigationMenu );
        WebElement recentSessionSubNav = SMUtils.getWebElement( driver, rootElement, childSubNavigationButton );
        return recentSessionSubNav.getAttribute( "class" ).contains( "side-item side-item-active" );
    }

    /**
     * To load Recent Session output MFE page
     * 
     */
    public RecentSessionsOutputPage clickRunBtn() {
        reportFilterComponent.clickRunReportButton();
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 3 ) );
            ArrayList<String> child = new ArrayList<>( driver.getWindowHandles() );
            driver.switchTo().window( child.get( 2 ) );
        } catch ( Exception e ) {
            Log.message( "Getting issue while change the driver to report output page!!!!" );
        }
        return new RecentSessionsOutputPage( driver ).get();
    }

    public boolean checkReportHeaderAfterRun() {
        try {
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( headerCSS ), 10000 );
            SMUtils.waitForElement( driver, driver.findElement( By.cssSelector( headerCSS ) ), 5000 );
            WebElement heading = driver.findElement( By.cssSelector( headerCSS ) );
            return heading.getText().equals( "Last Session" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.message( "Header not found" );
        }
        return false;
    }

    /**
     * Click optional Filter in Report
     */
    public void clickOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }

    /**
     * Click optional Filter in Report
     */
    public void clickLSOptionalFilter() {
        SMUtils.waitForElement( driver, optionalFilterLSRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, optionalFilterLSRoot, "button" );
        SMUtils.scrollDownIntoViewElement( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Optional Filter is clicked" );
    }
    
    /**
     * click checkbox Mask Student CheckBox
     */
    public void clickMaskStudentCheckBox() {
        WebElement element = SMUtils.getWebElementDirect( driver, checkBoxParent, maskStudentCheckBoxCSS );
        SMUtils.scrollIntoView( driver, element );
        SMUtils.click( driver, element );
        Log.message( "Mask Student Checkbox is checked" );
    }
    
    
    public  List<String> getOutputStudentNames(WebDriver driver) throws InterruptedException  {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputStudentName.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public  List<String> getoutputCurentCourseLevel(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputCurentCourseLevel.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputExercisesCorrect(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputExercisesCorrect.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputExercisesAttempted(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputExercisesAttempted.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    public List<String> getoutputHelpUsed(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputHelpUsed.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputTimeSpent(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTimeSpent.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputTotalSessions(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTotalSessions.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputSessionDate(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputSessionDate.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }
    
    
    public List<String> getoutputHelpUsedRead(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputHelpUsedRead.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputTimeSpentRead(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTimeSpentRead.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputTotalSessionsRead(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputTotalSessionsRead.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }


    public List<String> getoutputSessionDateRead(WebDriver driver) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, reportTable, 8 );
        SMUtils.waitForElement( driver, reportHeader );
        return outputSessionDateRead.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }
    
    public boolean verifyZeroState(WebDriver driver) {
        boolean status = false;
        if ( zeroState.getText().equalsIgnoreCase( "NA" ) ) {
            status = true;
        } else {
            status = false;
        }
        return status;
    }
    
    
    /**
     * To get the assignment name from the Report output page
     * 
     * @return assignemntName
     */
    public String getAssignmentNameOutput(WebDriver driver) {
        return assignmentOutputName.getText();
    }
    
    
    /**
     * To get the all the assignments name from the Report output page
     * 
     * @return allAssignmentNames
     */
    public List<String> getAllAssignmentNamesFromOutput(WebDriver driver, int totalPageCount) {
        List<String> allAssignmentNames = new ArrayList<>();
        for ( int  i=0; i<totalPageCount; i++ ) {
            ReportOutputComponent outputPage = new ReportOutputComponent( driver );
            outputPage.clickNextBtn();
            allAssignmentNames.add( getAssignmentNameOutput(driver));
        }
        return allAssignmentNames;
    }
    
    
    /**
     * To get the orgName from the Report output page
     * 
     * @return orgName
     */
    public String getOrgNameOutput(WebDriver driver) {
        return orgNameOutput.getText();
    }
    
    
    /**
     * To Verify the Savvas Footer in Report output page
     * 
     * @return status==true if Savvas Footer is displayed in output page
     */
    public boolean verifyFooterIsDispayed(WebDriver driver) {
        boolean  status = false;
        if ( footer.isDisplayed() ) {
            Log.message( "Footer is displayed!" );
            status = true;
        } else {
            status = false;
        }
        return status;
    }
    
    
    /**
     * To Verify the zero state in Report output page
     * 
     * @return status==true if output page is in zero state
     */
    public boolean VerifyLSZeroState(WebDriver driver) throws InterruptedException {
        boolean status = false;
        if ( noDataToDisplay.getText().equalsIgnoreCase( ReportsUIConstants.NO_DATA_TO_DISPLAY ) ) {
            status = true;
        } else {
            status = false;
        }
        return status;
    }
    
    
    /**
     * To get the Output Table Headers and its field values
     * 
     * @return Output Table Header values
     */

    public  List<String> getOutputTableHeadersRead(WebDriver driver) throws InterruptedException  {
        SMUtils.waitForSpinnertoDisapper( driver );
        List<String> values = outputTableHeadersRead.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
        values.remove( 4 );
        Log.message( "Header values: " + values );
        return values;
    }
    
    /**
     * To verify the Output Table Headers and its field values
     * 
     * @return status
     */
    public  boolean verifyOutputTableHeadersRead(WebDriver driver) throws InterruptedException  {
        boolean status = false;
        SMUtils.waitForSpinnertoDisapper( driver );
        List<String> uiValues = getOutputTableHeadersRead( driver );
        List<String> expectedValues = ReportsUIConstants.OUTPUT_TABLE_HEADERS_READ;
        
        for ( String string : expectedValues ) {
            for ( String actual : uiValues ) {
                string.contains( actual );
                status = true;
            }
            
        }
        return status;
    }
    
    
    /**
     * To verify the SM logo and report Viewer text in output page
     * 
     * @return
     */
    public boolean verifySMLogoandViewer(WebDriver driver) {
        boolean status = false;
        if (  smLogo.isDisplayed() ) {
            reportViewer.getText().equals( ReportsUIConstants.REPORT_VIEWER );
            status = true;
        } else {
            status = false;
        }
       return status;
    }
    
    
    
    /**
     * To verify the legend header and its label values
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabelsForReading() {
        Log.event( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if (SMUtils.getAllTextFromWebElementList( headerLegend ).containsAll( ReportsUIConstants.LS_LEGEND_HEADERS )) {
            IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS.get( itr ) ) );
            IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_VALUES.get( itr ) ) );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }
    
    
    /**
     * To verify the legend header and its label values for Math
     * 
     * @return
     */
    public boolean verifyLegendHeaderAndLabelsForMath() {
        Log.event( "Verifying Legend header and its labels" );
        boolean isLegendLabelDisplayed = false;
        if (SMUtils.getAllTextFromWebElementList( headerLegend ).containsAll( ReportsUIConstants.LS_LEGEND_HEADERS )) {
            IntStream.range( 0, legendLabels.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabels.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS.get( itr ) ) );
            IntStream.range( 0, legendLabelValues.size() ).allMatch( itr -> SMUtils.getTextOfWebElement( legendLabelValues.get( itr ), driver ).equals( ReportsUIConstants.LEGEND_LABELS_VALUES.get( itr ) ) );
            isLegendLabelDisplayed = true;
        }
        return isLegendLabelDisplayed;
    }
    
    
    /**
     * To verify the Output Table Headers and its field values
     * 
     * @return status
     */
    public  boolean verifyOutputTableHeadersMath(WebDriver driver) throws InterruptedException  {
        boolean status = false;
        SMUtils.waitForSpinnertoDisapper( driver );
        List<String> uiValues = getOutputTableHeadersRead( driver );
        List<String> expectedValues = ReportsUIConstants.OUTPUT_TABLE_HEADERS_MATH;
        
        for ( String string : expectedValues ) {
            for ( String actual : uiValues ) {
                string.contains( actual );
                status = true;
            }
            
        }
        return status;
    }
    
    
    /**
     * To validate the runReport button is disabled
     * 
     * @return
     */

    public boolean isRunReportDisabled() {
        boolean flag = true;
        SMUtils.waitForElement( driver, runReportRoot );
        if ( SMUtils.getWebElementDirect( driver, runReportRoot, childSubNavigationButton ).isEnabled() ) {
            flag = false;
        }
        Log.message( "Run Report Button is DisEnabled" );

        return flag;
    }

    public boolean isResetBtnDisabled() {
        boolean flag = true;
        SMUtils.waitForElement( driver, reSet );
        if ( SMUtils.getWebElementDirect( driver, reSet, childSubNavigationButton ).isEnabled() ) {
            flag = false;
        }
        Log.message( "Reset Button is DisEnabled" );

        return flag;
    }

    public boolean isSaveReportOptionDisabled() {
        boolean flag = true;
        SMUtils.waitForElement( driver, saveReportOption );
        if ( SMUtils.getWebElementDirect( driver, saveReportOption, child, childSubNavigationButton ).isEnabled() ) {
            flag = false;
        }
        Log.message( "Save Report Option Button is DisEnabled" );

        return flag;
    }
    
    
    public String getZeroStateFromCoursesDD() {
        JavascriptExecutor jse =(JavascriptExecutor)driver;
        WebElement textBox = (WebElement)jse.executeScript("return document.querySelector('#courses > cel-multi-select').shadowRoot.querySelector('div > div > button')" );
        return textBox.getAttribute( "aria-label" );
    }
}
