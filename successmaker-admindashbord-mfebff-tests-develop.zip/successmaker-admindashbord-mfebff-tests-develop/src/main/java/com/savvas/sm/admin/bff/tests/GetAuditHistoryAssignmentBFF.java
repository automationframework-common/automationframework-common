package com.savvas.sm.admin.bff.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.audithistory.AuditHistroyBFF;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;

public class GetAuditHistoryAssignmentBFF {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String districtAdminDetails;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String districtId;
    public static String teacherId;
    public static String userName;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgList;
    private Response response;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String endPoint;
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String courseId;
    //String studentDetails;
    String studentID;
    String groupId;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String schoolID;

    HashMap<String, String> assignmentDetails;
    HashMap<String, String> groupdetails = new HashMap<>();
    Map<String, Map<String, String>> db = new LinkedHashMap<>();
    SqlHelperAssignment dbhelper = new SqlHelperAssignment();
    AssignmentAPI assign = new AssignmentAPI();

    // Assignment audit query
    List<String> queryAudit = Arrays.asList( AdminAPIConstants.DELETED_BY, AdminAPIConstants.ASSIGNMENT_TITLE, AdminAPIConstants.STUDENT_OR_GROUP_NAME, AdminAPIConstants.RECORD_TYPE, AdminAPIConstants.ASSIGNED_BY, AdminAPIConstants.COURSE_NAME,
            AdminAPIConstants.DELETED_DATE );

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting district admin details from RBS Datasetup
        userName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherStaffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        teacherOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        studentDetailsSchool1 = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername );

        // Getting sub district with school admin details
        String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
        subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );

        // Getting the school under the sub district details
        String schoolUnderSubDistrict = RBSDataSetup.SchoolUnderSubDistrict;
        subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
        Log.message( "District ID of the sub-district school is " + subDistrictwithSchoolId );
        schoolID = rbsUtils.getOrganizationIDByName( subDistrictwithSchoolId, schoolUnderSubDistrict );
        Log.message( "School ID is " + schoolID );

        // Creating custom course
        courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherStaffId, teacherOrgId, DataSetupConstants.SETTINGS, "Custom Course" + System.nanoTime() );
        Log.message( "Custom course created is " + courseId );

    }

    @Test ( priority = 1, dataProvider = "positiveScenarioTestData", groups = { "AuditHistory", "SMK-51740", "P1", "API","smoke_test_case","positive_test_case" } )
    public void getAuditHistoryAssignment_Positive( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcID + " : " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Creating new group
        String groupName = "Group Name" + System.nanoTime();
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        groupdetails.put( GroupConstants.GROUP_NAME, groupName );
        studentID = SMUtils.getKeyValueFromResponse( studentDetailsSchool1, "userId" );
        Log.message( "Student id is " + studentID );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentID ) );
        groupId = SMUtils.getKeyValueFromResponse( createGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );

        switch ( scenario ) {

            case "NO_ASSIGNMENT":

                // GET Audit Histroy
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                Log.message( headers + "" );
                Log.message( teacherOrgId + "" );
                response = getAuditHistoryBFF( headers, RBSDataSetup.subDistrictwithoutSchoolId, userId, districtId, queryAudit );
                Log.message( response.asString() + "" );
                Log.message( response.getBody().asString() + "" );
                // Validating error message
                String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                Log.message( error );
                String message = getErrorMessage( error, "message" );
                Log.message( message );
                Log.assertThat( message.contains( AdminAPIConstants.ZERO_STATE_AUDIT_HISTORY ), "Getting Zero State message if no deleted assignment present", "Not getting Zero State message if no deleted assignment present" );
                break;

            case "VALID":
                // Assigning an assignment
                HashMap<String, String> assignmentDetails = new HashMap<>();
                assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID ), "users" );

                // Deleting an assignment
                assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

                // GET Audit Histroy
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

                // Getting values from DB
                db = dbhelper.getAuditHistoryAssignments( teacherOrgId );
                Log.testCaseResult();
                break;

            case "DELETE_AND_ASSIGN_FOR_TWO_TIMES":
                // Assigning an assignment
                HashMap<String, String> assignmentDetailsTwo = new HashMap<>();
                assignmentDetailsTwo.put( AdminAPIConstants.ORG_ID, teacherOrgId );
                assignmentDetailsTwo.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
                assignmentDetailsTwo.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetailsTwo.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                assign.assignAssignmentToSingleStudent( smUrl, assignmentDetailsTwo, Arrays.asList( studentID ), "users" );

                // Deleting an assignment
                assign.deleteAssignment( smUrl, assignmentDetailsTwo, AssignmentAPIConstants.EXCEPTIONNULL );

                // Assign and Delete for secind time
                assign.assignAssignmentToSingleStudent( smUrl, assignmentDetailsTwo, Arrays.asList( studentID ), "users" );
                assign.deleteAssignment( smUrl, assignmentDetailsTwo, AssignmentAPIConstants.EXCEPTIONNULL );

                // GET Audit Histroy
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

                // Getting values from DB
                db = dbhelper.getAuditHistoryAssignments( teacherOrgId );
                Log.testCaseResult();
                break;

            case "DELETE_GROUP_ASSIGNMENT":

                // Assigning an assignment
                HashMap<String, String> groupAssignmentDetails = new HashMap<>();
                groupAssignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
                groupAssignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
                groupAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                groupAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );

                assign.assignAssignmentToSingleStudent( smUrl, groupAssignmentDetails, Arrays.asList( groupId ), "groups" );
                groupAssignmentDetails.put( AdminAPIConstants.COURSE_ID, courseId );

                // Deleting an assignment
                assign.deleteAssignment( smUrl, groupAssignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

                // GET Audit Histroy
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

                // Getting values from DB
                db = dbhelper.getAuditHistoryAssignments( teacherOrgId );
                Log.testCaseResult();
                break;

            case "VALID_WITH_SUBDISTRICT_ADMIN":

                //Creating teacher and student
                String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
                String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

                //creating student
                String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
                String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                        new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                // Creating course under the teacher
                String courseName = "Custom Course" + System.nanoTime();
                courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, password ), DataSetupConstants.MATH, subdistrictSchoolTeacherID, RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                        DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );

                // Assigning the course to the student
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AdminAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, password ) );
                HashMap<String, String> responseassign = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), Arrays.asList( courseId ) );
                Log.message( responseassign + "" );

                assignmentDetails.put( AdminAPIConstants.COURSE_ID, courseId );
                // Deleting the assignment from the teacher
                assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

                //GET Audit History
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                response = getAuditHistoryBFF( headers, schoolID, subdistrictUserID, subDistrictwithSchoolId, queryAudit );

                // Get values from DB
                db = dbhelper.getAuditHistoryAssignments( schoolID );
                break;

            case "MULTI_SUB_DISTRICT_ADMIN":

                // Adding sub-district org id to admin
                HashMap<String, String> adminDetails = new HashMap<>();
                adminDetails.put( RBSDataSetupConstants.USERNAME, subdistrictUsername );
                adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, RBSDataSetup.subDistrictwithoutSchool );
                adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.subDistrictwithoutSchoolId );
                adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
                new RBSUtils().createCAUserWithAccess( adminDetails, true );

                // GET Audit Histroy
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                response = getAuditHistoryBFF( headers, schoolID, subdistrictUserID, subDistrictwithSchoolId, queryAudit );

                // Get values from DB
                db = dbhelper.getAuditHistoryAssignments( schoolID );
                Log.testCaseResult();
                break;

            case "SAVVAS_ADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.USERID ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" ), queryAudit );

                // Getting values from DB
                db = dbhelper.getAuditHistoryAssignments( teacherOrgId );
                Log.testCaseResult();

            default:
                break;
        }

        if ( !scenario.equals( "zero state" ) ) {

            // Verifying status code
            String statusCode = String.valueOf( response.getStatusCode() );
            Log.assertThat( statusCode.equals( expResCode ), "The Status code is expected " + expResCode + " and actual " + statusCode + " Verified", "The Status code is expected " + expResCode + " and actual " + statusCode + "is not Verified" );

            // Data validation
            Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();

            IntStream.range( 0, SMUtils.getWordCount( response.getBody().asString(), "assignmentTitle" ) ).forEach( iter -> {
                Map<String, String> deletedAssignments = new HashMap<>();
                String rspn = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
                JSONObject jsonObj = new JSONObject( rspn );
                JSONArray ja = jsonObj.getJSONArray( "getAssignmentAudits" );
                JSONObject jObj = ja.getJSONObject( iter );
                deletedAssignments.put( "deletedBy", jObj.get( "deletedBy" ).toString() );
                deletedAssignments.put( "assignmentTitle", jObj.get( "assignmentTitle" ).toString() );
                deletedAssignments.put( "studentOrGroupName", jObj.get( "studentOrGroupName" ).toString() );
                deletedAssignments.put( "recordType", jObj.get( "recordType" ).toString() );
                deletedAssignments.put( "assignedBy", jObj.get( "assignedBy" ).toString() );
                deletedAssignments.put( "courseName", jObj.get( "courseName" ).toString() );
                getAuditHistoryAssignment.put( Integer.toString( iter ), deletedAssignments );
            } );

            Log.assertThat( db.entrySet().stream().allMatch( entry -> getAuditHistoryAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) ), "API fetched all the audit history properly",
                    "API is not fetching all the audit assignment properly" );
        }
    }

    @DataProvider ( name = "positiveScenarioTestData" )
    public Object[][] positiveScenarioTestData() {
        Object[][] data = { { "tcAuditHistoryBFF001", "Verify the zero state response for getAssignmentAudits graphql query if the given organiztion has no delete assignment", "200", "NO_ASSIGNMENT" }, { "tcAuditHistoryBFF002",
                "Verify the getAssignmentAudits graphql query is returned the deleted assignments for the given organization while use a district admin credential & Verify the getAssignmentAudits graphql response, if teacher deleted the student's assignment.",
                "200", "VALID" },
                { "tcAuditHistoryBFF003",
                        "Verify the getAssignmentAudits graphql query is returned the deleted assignments for the given organization while use a subdistrict admin credential & Verify the graphql response is obtaining the predictable result for multiple response query parameters for getAssignmentAudit query",
                        "200", "VALID_WITH_SUBDISTRICT_ADMIN" },
                { "tcAuditHistoryBFF004", "Verify the getAssignmentAudits graphql response, if the teacher deleted the assignment and again the teacher assigned and deleted the same assignment.", "200", "DELETE_AND_ASSIGN_FOR_TWO_TIMES" },
                { "tcAuditHistoryBFF005", "Verify the getAssignmentAudits graphql response, if teacher deleted the group's assignment.", "200", "DELETE_GROUP_ASSIGNMENT" },
                { "tcAuditHistoryBFF006", "Verify the getAssignmentAudits graphql query is returned the deleted assignments for the given organization while use multiple subdistrict admin credential", "200", "MULTI_SUB_DISTRICT_ADMIN" },
                { "tcAuditHistoryBFF014", "Verify the getAssignmentAudits graphql query is returned the deleted assignments for the given organization while use a savvas admin credential", "200", "SAVVAS_ADMIN" } };
        return data;
    }

    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "HolidayScheduler", "SMK-51799", "P2", "API" } )
    public void getAuditHistoryAssignment_Negative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + " : " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenarioType ) {
            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) + "invalid" );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );
                break;

            case "INVALID_QUERY":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, Arrays.asList( AdminAPIConstants.DELETED_BY + "invalid" ) );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId + "Invalid", districtId, queryAudit );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, districtId + "Invalid", queryAudit );
                break;

            case "EMPTY_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, "", districtId, queryAudit );
                break;

            case "EMPTY_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, teacherOrgId, userId, "", queryAudit );
                break;

            case "EMPTY_SELECTED_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = getAuditHistoryBFF( headers, "", userId, districtId, queryAudit );
                break;

            default:
                break;
        }

        // Verifying Status code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        // Verifying message from response
        if ( scenarioType.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_SELECTED_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.INVALID_SELECTED_ORG ), "Getting Invalid message for empty selectedOrgId", "Not getting Invalid message for Invalid selectedOrgId" );
        }
        Log.testCaseResult();
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {

        return new Object[][] { { "tcAuditHistoryBFF007", "Verify '401: UnAuthorized' message in response when invalid Bearer token is given", CommonAPIConstants.STATUS_CODE_OK, "INVALID_BEARER_TOKEN" },
                { "tcAuditHistoryBFF008", "Verify '400: Bad Request' in response when invalid query has been given", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "INVALID_QUERY" },
                { "tcAuditHistoryBFF009", "Verify  '401: UnAuthorized'  and response when invalid userId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_USER_ID" },
                { "tcAuditHistoryBFF010", "Verify 400 status code and response when invalid organizationId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_ORG_ID" },
                { "tcAuditHistoryBFF011", "Verify the message in response when empty userId is given in the query", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_USER_ID" },
                { "tcAuditHistoryBFF012", "Verify the message in response when empty org-id is given in the query", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_ORG_ID" },
                { "tcAuditHistoryBFF013", "Verify the message in response when empty organizationId is given for selectedOrgId in the query", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_SELECTED_ORG_ID" } };
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }
    /**
     * This method is used to GET an Audit History Assignments
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param queryItems
     * @return
     */
    public Response getAuditHistoryBFF( Map<String, String> headers, String selectedOrgId, String userId, String orgId, List<String> queryItems ) {

        String query = AdminConstants.GET_AUDIT_HISTORY_PAYLOAD;
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        StringBuilder frameQuery = new StringBuilder();
        frameQuery.append( "{" );
        queryItems.forEach( querItem -> {
            if ( frameQuery.toString().equals( "{" ) ) {
                frameQuery.append( querItem );
            } else {
                frameQuery.append( "," + querItem );
            }
        } );
        frameQuery.append( "}" );

        query = query.replace( AdminConstants.QUERY_ITEM, frameQuery.toString() );
        return RestAssuredAPIUtil.POSTGraphQl( AuditHistory.AUDIT_HISTORY_BFF_URL, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

}
