package com.savvas.sm.admin.ui.tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

/**
 * This class tests the admin re-direction to CAT/CMS Page
 * 
 * @author madhan.nagarathinam
 *
 */

public class AdminLoginTest extends EnvProperties {
    private String smUrl;
    String districtAdminDetails = null;
    String schoolAdminDetails = null;
    String savvasAdminUserDetails = null;
    String subDistrictAdminDetails = null;
    String districtAdminUserName, schoolAdminUserName, savvasAdminUserName, subDistrictAdminUserName;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String browser;

    @BeforeTest ( alwaysRun = true )
    public void beforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        districtAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userName" );
        schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        schoolAdminUserName = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "userName" );
        savvasAdminUserDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        savvasAdminUserName = SMUtils.getKeyValueFromResponse( savvasAdminUserDetails, "userName" );
        subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subDistrictAdminUserName = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, "userName" );
    }

    @Test ( priority = 1, groups = { "SMK-51121", "mastery_mfe_admin", "P1", "UI" } )
    public void tcMasteryMfeAdminSingle( ITestContext context ) throws Exception {
        // Get driver
        WebDriver driver = WebDriverFactory.get( browser );
        String title;
        Log.testCaseInfo( "Admin Login Test" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            SMUtils.logDescriptionTC( "TC:01 Verify school admin is redirected to CAT CA DashboardPage" );

            LoginWrapper.loginToSuccessMakerAsAdmin( driver, smUrl, schoolAdminUserName, password );
            SMUtils.nap( 3 );
            title = driver.getTitle();
            Log.assertThat( title.contains( "Savvas EasyBridge" ), "School admin is redirected to CAT CA DashboardPage", "School admin is not redirected to CAT CA DashboardPage!" );
            driver.quit();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:02 Verify Distirct admin is redirected to CAT CA DashboardPage" );

            driver = WebDriverFactory.get( browser );
            LoginWrapper.loginToSuccessMakerAsAdmin( driver, smUrl, districtAdminUserName, password );
            SMUtils.nap( 3 );
            title = driver.getTitle();
            Log.assertThat( title.contains( "Savvas EasyBridge" ), "District admin is redirected to CAT CA DashboardPage", "District admin is not redirected to CAT CA DashboardPage!" );
            driver.quit();
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "TC:03 Verify sub-District admin is redirected to CAT CA DashboardPage" );

            driver = WebDriverFactory.get( browser );
            LoginWrapper.loginToSuccessMakerAsAdmin( driver, smUrl, subDistrictAdminUserName, password );
            SMUtils.nap( 3 );
            title = driver.getTitle();
            Log.assertThat( title.contains( "Savvas EasyBridge" ), "Sub-District admin is redirected to CAT CA DashboardPage", "Sub-District admin is not redirected to CAT CA DashboardPage" );
            driver.quit();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:04 Verify Savvas admin is redirected to CAT PA DashboardPage" );

            driver = WebDriverFactory.get( browser );
            LoginWrapper.loginToSuccessMakerAsAdmin( driver, smUrl, savvasAdminUserName, password );
            SMUtils.nap( 3 );
            title = driver.getTitle();
            Log.assertThat( title.contains( "Savvas EasyBridge" ), "Savvas admin is redirected to CAT PA DashboardPage", "Savvas admin is not redirected to CAT PA DashboardPage" );
            driver.quit();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
