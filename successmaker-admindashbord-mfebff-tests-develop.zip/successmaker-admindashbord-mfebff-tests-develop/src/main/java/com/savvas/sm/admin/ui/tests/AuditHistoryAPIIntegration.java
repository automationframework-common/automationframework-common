package com.savvas.sm.admin.ui.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;

public class AuditHistoryAPIIntegration extends EnvProperties {

    private String districtID;
    public RBSUtils rbsUtils = new RBSUtils();
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String userId;
    private String accessToken;
    OrganizationListing orgList = new OrganizationListing();
    Map<String, String> headers = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtID = configProperty.getProperty( "district_ID" );

    }

    @Test ( description = "Verify organizations under the district are displayed in Audit History filter dropdown", groups = { "SMK-51929", "adminDashboard", "AuditHistory", "smoke_test_case" }, priority = 1 )
    public void tcSMAuditHistory001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory001: Verify organizations under the district are displayed in Audit History filter dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.logDescriptionTC( "Verify organizations under the district are displayed in Audit History filter dropdown" );
            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Log.assertThat( allOrganizationsfromdropdown.containsAll( organizationsForAdmin ), "All the sub districts and its child organizations for the district is displayed in the filter drop down",
                    "All the sub districts and its child organizations for the district is not displayed in the filter drop down" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Audit History filter dropdown by logging as district admin whose district has two or more sub-districts with organizations", groups = { "SMK-51929", "adminDashboard", "AuditHistory", "smoke_test_case" }, priority = 1 )
    public void tcSMAuditHistory002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory002: Verify Audit History filter dropdown by logging as district admin whose district has two or more sub-districts with organizations <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.logDescriptionTC( "Verify Audit History filter dropdown by logging as district admin whose district has two or more sub-districts with organizations" );
            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Log.assertThat( allOrganizationsfromdropdown.containsAll( organizationsForAdmin ), "All the child organizations for the district is displayed in the filter drop down", "All the child organizations are not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Audit History filter dropdown by logging as district admin whose district has two or more schools", groups = { "SMK-51929", "adminDashboard", "AuditHistory", "smoke_test_case_1" }, priority = 1 )
    public void tcSMAuditHistory003() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory003: Verify Audit History filter dropdown by logging as district admin whose district has two or more schools <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.logDescriptionTC( "Verify Audit History filter dropdown by logging as district admin whose district has two or more schools" );

            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Collections.sort( allOrganizationsfromdropdown );
            Log.message( allOrganizationsfromdropdown.toString() );
            Log.message( "************" );
            Log.message( "allOrganizationsfromdropdown" + allOrganizationsfromdropdown.size() );

            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.DISTRICT_ADMIN );

            Log.message( "************" );
            Collections.sort( organizationsForAdmin );
            Log.message( organizationsForAdmin.toString() );
            Log.message( "organizationsForAdmin" + organizationsForAdmin.size() );

            Log.softAssertThat( allOrganizationsfromdropdown.size() == organizationsForAdmin.size(), "Organization list size is matching", "Organization list size is not matching" );

            organizationsForAdmin.removeAll( allOrganizationsfromdropdown );

            Log.softAssertThat( Boolean.FALSE.equals( auditHistoryPage.sizeofListElement( organizationsForAdmin ) ), "All the child organizations for the district is displayed in the filter drop down", "All the child organizations are not displayed" );

            Log.testCaseResult();//51

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sub-district name is displayed in Audit History filter dropdown when login as sub-district admin with no school", groups = { "SMK-51929", "adminDashboard", "AuditHistory", "smoke_test_case" }, priority = 1 )
    public void tcSMAuditHistory004() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory004: Verify sub-district name is displayed in Audit History filter dropdown when login as sub-district admin with no school <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.logDescriptionTC( "Verify sub-district name is displayed in Audit History filter dropdown when login as sub-district admin with no school" );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Log.assertThat( allOrganizationsfromdropdown.contains( organizationsForAdmin.get( 0 ) ), "The subdistrict with no child org is displayed in the the organization listing drop down",
                    "The subdistrict with no child org is not displayed in the the organization listing drop down" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Audit History filter dropdown list if an organization is added under sub-distict which has no org before", groups = { "SMK-51929", "adminDashboard", "AuditHistory", "smoke_test_case" }, priority = 1 )
    public void tcSMAuditHistory005() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory005: Verify Audit History filter dropdown list if an organization is added under sub-distict which has no org before <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.logDescriptionTC( "Verify Audit History filter dropdown list if an organization is added under sub-distict which has no org before" );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Log.message( allOrganizationsfromdropdown + "" );
            Log.message( organizationsForAdmin + "" );
            Log.assertThat( allOrganizationsfromdropdown.containsAll( organizationsForAdmin ), "The subdistrict with child org is displayed the child organizations name in the the organization listing drop down",
                    "The subdistrict with no child org is not displayed in the the The subdistrict with child org is not displayed the child organizations name in the the organization listing drop down listing drop down" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Log in as school admin which has one organization and verify the organization is displayed in Audit History filter dropdown", groups = { "SMK-51929", "adminDashboard", "AuditHistory", "smoke_test_case" }, priority = 1 )
    public void tcSMAuditHistory006() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory006: Log in as school admin which has one organization and verify the organization is displayed in Audit History filter dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.SCHOOL_ADMIN );

            String schoolAdminDetails = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
            Log.message( schoolAdminDetails );
            SMUtils.logDescriptionTC( "Log in as school admin which has one organization and verify the organization is displayed in Audit History filter dropdown" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( schoolAdminDetails, password );
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Log.assertThat( SMUtils.compareTwoList( allOrganizationsfromdropdown, organizationsForAdmin ), "The organizations under the School Admin is displayed", "The organizations under the School Admin is not displayed" );
            Log.message( allOrganizationsfromdropdown + "" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Log in as school admin which has two or more organizations and verify the organizations are displayed in Audit History filter dropdown", groups = { "SMK-51929", "adminDashboard", "AuditHistory",
            "smoke_test_case" }, priority = 1 )
    public void tcSMAuditHistory007() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory007: Log in as school admin which has two or more organizations and verify the organizations are displayed in Audit History filter dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            List<String> organizationsForAdmin = getOrganizationsForAdmin( Admins.MULTI_SCHOOL_ADMIN );
            String username = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );

            SMUtils.logDescriptionTC( "Log in as school admin which has two or more organizations and verify the organizations are displayed in Audit History filter dropdown" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            Log.assertThat( SMUtils.compareTwoList( allOrganizationsfromdropdown, organizationsForAdmin ), "The organizations under the School Admin is displayed", "The organizations under the School Admin is not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the organization List for given admin
     * 
     * @param admin
     * @return
     * @throws Exception
     */
    public List<String> getOrganizationsForAdmin( Admins admin ) throws Exception {
        String orgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
            Log.message( orgId );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        }
        Log.message( orgId );
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        Log.message( userId );
        Log.message( "Admin details " + RBSDataSetup.adminDetails.get( admin ).toString() );
        String username = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userName" );
        String user1 = RBSDataSetup.adminUserNames.get( admin );
        Log.message( username );
        Log.message( user1 );
        Log.message( password );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );

        //headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.ORGID, orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers );
        List<String> organizationListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME ) ).forEach(
                iter -> organizationListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME, iter ).toLowerCase() ) );

        return organizationListFromAPI;
    }

}
