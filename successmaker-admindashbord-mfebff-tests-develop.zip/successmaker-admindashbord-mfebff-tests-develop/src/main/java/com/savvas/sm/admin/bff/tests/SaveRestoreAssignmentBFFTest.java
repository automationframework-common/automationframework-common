package com.savvas.sm.admin.bff.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class SaveRestoreAssignmentBFFTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtId;
    private String savvasUserName;
    private String savvasUserId;
    private String savvasAccessToken;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String teacherOrgId;
    private String teacherId;
    private String teacherUsername;
    private String school;
    private String firstStudentUserId;
    private String secondStudentUserId;
    private String courseName;
    private String courseId;
    private String firstAssignmentUserId;
    private String secondAssignmentUserId;
    private String newStudentId;
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    private String restoredAssignmentUserId;
    private String orphanStudentAssignmentUserId;
    HashMap<String, String> newGroupDetails = new HashMap<>();
    private String newGroupId;
    HashMap<String, String> orphanAssignmentDetail = new HashMap<>();

    Response response;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        createData();
    }

    /**
     * This method is used to test the negative scenarios for Save Holiday
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "positiveScenarioTestData", groups = { "SaveRestoreAssignment", "SMK-51776", "P1", "API", "restoreAssignmentSmokeTest" } )
    public void saveRestoreAssignmentPositive( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );
        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAccessToken );

        HashMap<String, String> assignmentDetailMath = new HashMap<>();
        assignmentDetailMath.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        assignmentDetailMath.put( AdminAPIConstants.TEACHER_ID, teacherId );
        assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        assignmentDetailMath.put( AdminAPIConstants.ASSIGNMENT_USER_ID, firstAssignmentUserId );

        switch ( scenarioType ) {
            case "VALID":

                // Deleting an assignment
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );
                // Restoring the deleted assignment
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, districtId, teacherOrgId );
                restoredAssignmentUserId = firstAssignmentUserId;
                break;

            case "RESTORE_ALREADY_RESTORED_ASSIGNMENT":

                // Restoring the deleted assignment
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, districtId, teacherOrgId );

                // Data validation
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "errors,message" ).equals( AdminAPIConstants.BAD_REQUEST_400 ), "Restore Assignment query is not restoring the assingment which is already restored",
                        "Restore Assignment query is failed while restoring the assingment which is already restored" );
                restoredAssignmentUserId = firstAssignmentUserId;
                break;

            case "PASSING_ASSIGNMENTUSERID_AS_ALREADY_RESTORED_ASSIGNMENT":

                // Deleting an assignment
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                HashMap<String, String> asgnmtResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( firstStudentUserId ), Arrays.asList( courseId ) );
                Log.assertThat( asgnmtResponse.get( Constants.STATUS_CODE ).equals( "200" ), "Assignment is assigned to the Student Successfully!!", "Assignment is not assigned to the Student" );
                // Getting assignment id
                JSONObject asgnmtDetailsJson = new JSONObject( asgnmtResponse.get( Constants.REPORT_BODY ) );
                JSONArray asgnmtList = asgnmtDetailsJson.getJSONArray( Constants.DATA );
                JSONObject assignmentInfo = new JSONObject( asgnmtList.get( 0 ).toString() );
                String asgnmtId = assignmentInfo.get( "assignmentId" ).toString();
                String newAssignmentUserId1 = new SqlHelperCourses().getActiveAssignmentUserId( firstStudentUserId, asgnmtId );

                // Remove student from newly added assignment
                HashMap<String, String> newAssignmentDetail = new HashMap<>();
                newAssignmentDetail.put( AdminAPIConstants.ORG_ID, teacherOrgId );
                newAssignmentDetail.put( AdminAPIConstants.TEACHER_ID, teacherId );
                newAssignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                newAssignmentDetail.put( AdminAPIConstants.ASSIGNMENT_USER_ID, newAssignmentUserId1 );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, newAssignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                // Restoring the deleted assignment
                Response restoreAssignmentResponse = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, districtId, teacherOrgId );
                Log.assertThat( restoreAssignmentResponse.getStatusCode() == 200, firstAssignmentUserId + " is restored successfully!!", firstAssignmentUserId + " is not restored" );

                // Restoring the deleted assignment again
                response = new RestoreAssignment().restoreAssignmentBFF( headers, newAssignmentUserId1, savvasUserId, districtId, teacherOrgId );
                Log.message( response.getBody().asString() );
                // Data validation
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "errors,message" ).equals( AdminAPIConstants.CONSTRAINT_VIOLATION ), "Restore Assignment query is not restoring the assingment which is already restored",
                        "Restore Assignment query is failed while restoring the assingment which is already restored" );
                restoredAssignmentUserId = firstAssignmentUserId;
                break;

            case "RESTORE_GROUP_ASSIGNMENT":

                // Creating new group
                newGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                newGroupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
                newGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, teacherOrgId );
                newGroupDetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                HashMap<String, String> createGroupResponse = new GroupAPI().createGroup( smUrl, newGroupDetails, Arrays.asList( firstStudentUserId ) );
                newGroupId = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), "data," + GroupConstants.GROUP_ID );

                // Assigning assignment to group
                Log.assertThat( new AssignmentAPI().assignAssignment( smUrl, mathAssignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment assigned to group successfully",
                        "Assignment is not assigned to group" );

                // Delete group assignment
                mathAssignmentDetails.put( AssignmentAPIConstants.GROUP_ID, newGroupId );
                Log.assertThat( new AssignmentAPI().deleteAssignmentfromGroup( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment is deleted from group", "Assignment is not deleted from group" );

                // Restoring the deleted assignment
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, districtId, teacherOrgId );
                restoredAssignmentUserId = firstAssignmentUserId;
                break;

            case "RESTORE_ORPHAN_STUDENT_ASSIGNMENT":

                String newStudent = "SchStudent" + System.nanoTime();
                String newStudentDetails = new UserAPI().createUserWithCustomization( newStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( school ) ) );
                newStudentId = SMUtils.getKeyValueFromResponse( newStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfos = new HashMap<>();
                studentInfos = generateRequestValues( newStudentDetails, studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.TEACHER_ID, teacherId );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentId );

                // Adding new student to group
                new GroupAPI().addStudentToGroup( smUrl, newGroupDetails, Arrays.asList( newStudentId ), Arrays.asList( newGroupId ) );

                // Assigning assignment to student
                HashMap<String, String> orphanStudentAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( newStudentId ), Arrays.asList( courseId ) );

                // Getting assignment id
                JSONObject orphanAssignmentDetailsJson = new JSONObject( orphanStudentAssignment.get( Constants.REPORT_BODY ) );
                JSONArray orphanAssignmentList = orphanAssignmentDetailsJson.getJSONArray( Constants.DATA );
                JSONObject orphanAssignmentInfo = new JSONObject( orphanAssignmentList.get( 0 ).toString() );
                String orphanStudentAssignmentId = orphanAssignmentInfo.get( "assignmentId" ).toString();
                orphanStudentAssignmentUserId = new SqlHelperCourses().getActiveAssignmentUserId( newStudentId, orphanStudentAssignmentId );
                Log.message( "Orphan student assignment user id " + orphanStudentAssignmentUserId );

                // Deleting an assignment
                orphanAssignmentDetail.put( AdminAPIConstants.ORG_ID, teacherOrgId );
                orphanAssignmentDetail.put( AdminAPIConstants.TEACHER_ID, teacherId );
                orphanAssignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                orphanAssignmentDetail.put( AdminAPIConstants.ASSIGNMENT_USER_ID, orphanStudentAssignmentUserId );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, orphanAssignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Orphan Student assignment removed sucessfully!",
                        "Issue in removing the orphan Student assignment" );

                //Removing new student from group
                HashMap<String, String> removeStudentFromGroup = new GroupAPI().removeStudentFromGroup( smUrl, newStudentId, newGroupId, teacherId, teacherOrgId,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = new RestoreAssignment().restoreAssignmentBFF( headers, orphanStudentAssignmentUserId, savvasUserId, districtId, teacherOrgId );
                restoredAssignmentUserId = orphanStudentAssignmentUserId;
                break;

            case "RESTORE_SUSPENDED_STUDENT_ASSIGNMENT":

                assignmentDetailMath.put( AdminAPIConstants.ASSIGNMENT_USER_ID, secondAssignmentUserId );
                // Deleting an assignment
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                //suspend Student
                Log.assertThat( new RBSUtils().suspendUser( Arrays.asList( secondStudentUserId ) ), "Student is suspended successfully!!", "Student is not suspended" );

                response = new RestoreAssignment().restoreAssignmentBFF( headers, secondAssignmentUserId, savvasUserId, districtId, teacherOrgId );
                restoredAssignmentUserId = secondAssignmentUserId;
                break;

            default:
                break;
        }
        Log.message( response.getBody().asString() );
        // Validating Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + "is not Verified" );

        // Data validation
        Response getRestoreAssignmentResponse = new RestoreAssignment().getRestoreAssignmentBFF( headers, teacherOrgId, savvasUserId, districtId );
        Log.message( getRestoreAssignmentResponse.getBody().asString() + "" );
        try {
            String assignmentResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( getRestoreAssignmentResponse.getBody().asString(), "data" ), "getRestoreAssignments" );
            List<String> assignmentUserIdList = new ArrayList<>();
            JSONArray arr = new JSONArray( assignmentResponse );
            IntStream.range( 0, arr.length() ).forEach( itr -> assignmentUserIdList.add( String.valueOf( arr.getJSONObject( itr ).getInt( "assignmentUserId" ) ) ) );
            Log.message( "Restores assignments id " + assignmentUserIdList );
            Log.assertThat( !assignmentUserIdList.contains( restoredAssignmentUserId ), courseName + " ( " + firstAssignmentUserId + " )" + " assignment is restored successfully!!!",
                    courseName + " ( " + firstAssignmentUserId + " )" + " assignment is not restored" );

        } catch ( NullPointerException e ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getRestoreAssignmentResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.ZERO_STATE_RESTORE_ASSIGNMENT ), courseName + " ( " + firstAssignmentUserId + " )" + " assignment is restored successfully!!!",
                    courseName + " ( " + firstAssignmentUserId + " )" + " assignment is not restored" );
        }

        // Schema validation
        if ( !( scenarioType.equals( "RESTORE_ALREADY_RESTORED_ASSIGNMENT" ) || scenarioType.equals( "PASSING_ASSIGNMENTUSERID_AS_ALREADY_RESTORED_ASSIGNMENT" ) ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "SaveRestoreAssignmentBFF", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }
        Log.testCaseResult();
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarioTestData" )
    public Object[][] positiveScenarioTestData() {

        return new Object[][] { { "tcSaveRestoreAssignment001",
                "Verify the saveRestoreAssignments graphql query is restoring the given assignment when passing savvas admin details. Delete Math/Reading assignment and verify the saveRestoreAssignments graphql query is restoring the given assignment. Delete student assignment and verify the saveRestoreAssignments graphql query is restoring the given assignment",
                CommonAPIConstants.STATUS_CODE_OK, "VALID" },
                { "tcSaveRestoreAssignment002", "Verify the saveRestoreAssignments graphql query should not restore the given assignment which is already restored", CommonAPIConstants.STATUS_CODE_OK, "RESTORE_ALREADY_RESTORED_ASSIGNMENT" },
                { "tcSaveRestoreAssignment003", "Verify the saveRestoreAssignments graphql query when passing already restored assignment", CommonAPIConstants.STATUS_CODE_OK, "PASSING_ASSIGNMENTUSERID_AS_ALREADY_RESTORED_ASSIGNMENT" },
                { "tcSaveRestoreAssignment004",
                        "Delete group assignment and verify the saveRestoreAssignments graphql query is restoring the given assignment. Delete the restored assignment once again and verify the saveRestoreAssignments graphql query is restoring that assignmnet",
                        CommonAPIConstants.STATUS_CODE_OK, "RESTORE_GROUP_ASSIGNMENT" },
                { "tcSaveRestoreAssignment005", "Delete orphan student assignment and verify the saveRestoreAssignments graphql query is restoring the given assignment", CommonAPIConstants.STATUS_CODE_OK, "RESTORE_ORPHAN_STUDENT_ASSIGNMENT" },
                { "tcSaveRestoreAssignment006", "Delete an assignment and suspend the student. Now verify the saveRestoreAssignments graphql query is restoring the given assignment", CommonAPIConstants.STATUS_CODE_OK,
                        "RESTORE_SUSPENDED_STUDENT_ASSIGNMENT" } };
    }

    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "SaveRestoreAssignment", "SMK-51776", "P1", "API" } )
    public void saveRestoreAssignmentNegative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + " : " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String savvasAdminToken = new RBSUtils().getAccessToken( savvasUserName, password );
        switch ( scenarioType ) {

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId + "Invalid", districtId, teacherOrgId );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, districtId + "Invalid", teacherOrgId );
                break;

            case "EMPTY_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, "", districtId, teacherOrgId );
                break;

            case "EMPTY_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, "", teacherOrgId );
                break;

            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken + "Invalid" );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, savvasUserId, districtId, teacherOrgId );
                break;

            case "DISTRICT_ADMIN_CREDENTIALS":
                String districtAdminUserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                String districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                String districtAdminUserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );
                String districtAccessToken = new RBSUtils().getAccessToken( districtAdminUserName, password );
                String districtAdminOrgId = SMUtils.getKeyValueFromResponse( districtAdminDetails, "primaryOrgId" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + districtAccessToken );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, districtAdminUserId, districtAdminOrgId, teacherOrgId );
                break;

            case "SCHOOL_ADMIN_CREDENTIALS":
                String schoolAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolAdminAccessToken = new RBSUtils().getAccessToken( schoolAdminUserName, password );
                String schoolAdminOrgId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + schoolAdminAccessToken );
                response = new RestoreAssignment().restoreAssignmentBFF( headers, firstAssignmentUserId, schoolAdminUserId, schoolAdminOrgId, teacherOrgId );
                break;

            default:
                break;
        }

        Log.message( response.getBody().asString() );
        // Verifying Status code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        // Verifying message from response
        if ( scenarioType.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_USERID ), "Getting Invalid message for empty userId", "Not getting Invalid message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        } else if ( scenarioType.equalsIgnoreCase( "DISTRICT_ADMIN_CREDENTIALS" ) || scenarioType.equalsIgnoreCase( "SUBDISTRICT_ADMIN_CREDENTIALS" ) || scenarioType.equalsIgnoreCase( "SCHOOL_ADMIN_CREDENTIALS" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.ACCESS_DENIED_MESSAGE ), "Getting access denied message for customer admin credentials", "Not getting access denied message for customer admin credentials" );
        }
        Log.testCaseResult();
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {

        return new Object[][] { { "tcSaveRestoreAssignment007", "Verify 401: UnAuthorized and response when invalid userId is given in the query", CommonAPIConstants.STATUS_CODE_OK, "INVALID_USER_ID" },
                { "tcSaveRestoreAssignment008", "Verify 404 status code and response when invalid organizationId is given in the query", CommonAPIConstants.STATUS_CODE_OK, "INVALID_ORG_ID" },
                { "tcSaveRestoreAssignment009", "Verify the saveRestoreAssignments graphql query is returned authentication error when org id is not passed", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_USER_ID" },
                { "tcSaveRestoreAssignment010", "Verify the saveRestoreAssignments graphql query is returned authentication error when user id is not passed", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_ORG_ID" },
                { "tcSaveRestoreAssignment011", "Verify 401: UnAuthorized message in response when invalid Bearer token is given in saveRestoreAssignments graphql query", CommonAPIConstants.STATUS_CODE_OK, "INVALID_BEARER_TOKEN" },
                { "tcSaveRestoreAssignment012", "Save Restore Assignment - Verify the saveRestoreAssignments graphql query should not restore the given assignment when passing district admin details", CommonAPIConstants.STATUS_CODE_OK,
                        "DISTRICT_ADMIN_CREDENTIALS" },
                { "tcSaveRestoreAssignment013", "Save Restore Assignment - Verify the saveRestoreAssignments graphql query should not restore the given assignment when passing sub-district admin details", CommonAPIConstants.STATUS_CODE_OK,
                        "SUBDISTRICT_ADMIN_CREDENTIALS" },
                { "tcSaveRestoreAssignment014", "Save Restore Assignment - Verify the saveRestoreAssignments graphql query should not restore the given assignment when passing school admin details", CommonAPIConstants.STATUS_CODE_OK,
                        "SCHOOL_ADMIN_CREDENTIALS" },

        };
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param messagex
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );
        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    public void createData() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting savvas admin details in RBS Datasetup
        savvasUserName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String savvasAdminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        savvasUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        savvasAccessToken = new RBSUtils().getAccessToken( savvasUserName, password );

        // Getting teacher details
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherOrgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        // Getting student user id
        firstStudentUserId = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), "userId" );
        secondStudentUserId = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), "userId" );

        // Creating custom course
        courseName = "Restore Assignment - " + System.nanoTime();
        courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, teacherOrgId, DataSetupConstants.SETTINGS, courseName );

        // Assigning an assignment
        mathAssignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        mathAssignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherId );
        mathAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        Log.message( "assignment Details: " + mathAssignmentDetails );
        Log.message( "student Id:" + firstStudentUserId + "," + secondStudentUserId );
        Log.message( "course Id :" + courseId );
        HashMap<String, String> assignmentResponse;
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( firstStudentUserId, secondStudentUserId ), Arrays.asList( courseId ) );
        } catch ( Exception e ) {
            Thread.sleep( 10000 );
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( firstStudentUserId, secondStudentUserId ), Arrays.asList( courseId ) );
        }
        Log.message( assignmentResponse.toString() );
        Log.message( savvasAdminDetails );
        // Getting assignment id
        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject assignmentInfo = new JSONObject( assignmentList.get( 0 ).toString() );
        String assignmentId = assignmentInfo.get( "assignmentId" ).toString();
        firstAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( firstStudentUserId, assignmentId );
        secondAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( secondStudentUserId, assignmentId );
    }

}