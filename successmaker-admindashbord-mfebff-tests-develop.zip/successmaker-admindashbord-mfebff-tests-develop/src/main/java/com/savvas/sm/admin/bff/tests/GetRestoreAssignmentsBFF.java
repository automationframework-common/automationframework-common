package com.savvas.sm.admin.bff.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class GetRestoreAssignmentsBFF extends EnvProperties {
    private String smUrl;
    private String districtId;
    private String userName;
    private String userId;
    private String password;
    private String accessToken;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserID;
    private String teacherOrgID;
    private String teacherAccessToken;
    private String studentDetails1;
    private String studentID1;
    private String courseId;
    private String courseName;
    private String assignmentID;
    private String assignmentUserID;
    RestoreAssignment restoreAssignment = new RestoreAssignment();
    Map<String, String> headers = new HashMap<>();
    HashMap<String, String> assignmentDetailMath = new HashMap<>();
    private Response getResponse;
    private Response saveResponse;
    private String school;
    private HashMap<String, String> newGroupDetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    private String newGroupId;
    String newStudentId;
    HashMap<String, String> orphanAssignmentDetail = new HashMap<>();
    String orphanStudentAssignmentUserId;
    Map<String, Map<String, String>> data;
    Map<String, String> assignmentData;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        createData();
    }

    @Test ( dataProvider = "getData_Positive", groups = { "SMK-51776", "Get Restore Assignments", "API", "restoreAssignmentSmokeTest" }, priority = 1 )
    public void getRestoreAssignmentBFF_Positive( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseNumber + ":" + testDescription );
        data = new HashMap<>();
        switch ( scenario ) {
            case "Valid for savvas admin":
                // Removing student's assignment
                assignmentDetailMath.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetailMath.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetailMath.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserID );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                Log.message( studentDetails1 );
                Log.message( teacherDetails );
                assignmentData = new HashMap<>();
                assignmentData.put( "assignmentName", courseName );
                assignmentData.put( "assignmentUserId", assignmentUserID );
                assignmentData.put( "studentFirstName", SMUtils.getKeyValueFromResponse( studentDetails1, "firstName" ) );
                assignmentData.put( "studentLastName", SMUtils.getKeyValueFromResponse( studentDetails1, "lastName" ) );
                assignmentData.put( "teacherFirstName", SMUtils.getKeyValueFromResponse( teacherDetails, "firstName" ) );
                assignmentData.put( "teacherLastName", SMUtils.getKeyValueFromResponse( teacherDetails, "lastName" ) );
                assignmentData.put( "studentUsername", SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ).toLowerCase() );
                data.put( assignmentUserID, assignmentData );
                Log.message( assignmentData.toString() );

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                Log.message( headers.toString() );
                Log.message( teacherOrgID );
                Log.message( userId );
                Log.message( districtId );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                Log.message( getResponse.getBody().asString() );
                Map<String, Map<String, String>> getRestoreAssignments = new HashMap<>();

                IntStream.range( 0, SMUtils.getWordCount( getResponse.getBody().asString(), "assignmentUserId" ) ).forEach( iter -> {
                    Map<String, String> deletedAssignments = new HashMap<>();
                    String rspn = SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "data" );
                    JSONObject jsonObj = new JSONObject( rspn );
                    JSONArray ja = jsonObj.getJSONArray( "getRestoreAssignments" );
                    JSONObject jObj = ja.getJSONObject( iter );
                    deletedAssignments.put( "assignmentName", jObj.get( "assignmentName" ).toString() );
                    deletedAssignments.put( "assignmentUserId", jObj.get( "assignmentUserId" ).toString() );
                    deletedAssignments.put( "studentFirstName", jObj.get( "studentFirstName" ).toString() );
                    deletedAssignments.put( "studentLastName", jObj.get( "studentLastName" ).toString() );
                    deletedAssignments.put( "teacherFirstName", jObj.get( "teacherFirstName" ).toString() );
                    deletedAssignments.put( "teacherLastName", jObj.get( "teacherLastName" ).toString() );
                    deletedAssignments.put( "studentUsername", jObj.get( "studentUsername" ).toString().toLowerCase() );

                    getRestoreAssignments.put( jObj.get( "assignmentUserId" ).toString(), deletedAssignments );
                } );
                Log.message( data.toString() );
                Log.message( getRestoreAssignments.toString() );

                Log.assertThat( data.entrySet().stream().anyMatch( entry -> getRestoreAssignments.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) ), "GraphQL fetched the deleted assignment data",
                        "GraphQL not fetched the deleted assignment data" );

                break;
            case "Valid for restored assignments":
                // Create custom course
                courseName = "Custom Course" + System.nanoTime();
                courseId = new SharedCourses().createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserID, teacherOrgID, DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );

                // Assigning the course to the student
                assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentID1 ), Arrays.asList( courseId ) );
                Log.message( assignmentResponse.toString() );
                // Getting Assignment ID
                JSONObject mathAssignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
                JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
                JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
                assignmentID = mathAssignmentInfo.get( "assignmentId" ).toString();
                Log.message( assignmentID );
                // Getting Assignment User ID
                assignmentUserID = new SqlHelperCourses().getAssignmentUserId( studentID1, assignmentID );
                Log.message( assignmentUserID );
                // Removing student's assignment
                assignmentDetailMath.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetailMath.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetailMath.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserID );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                // Restoring the assignment
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                saveResponse = restoreAssignment.restoreAssignmentBFF( headers, assignmentUserID, userId, districtId, teacherOrgID );
                Log.message( saveResponse.getBody().asString() );
                assignmentData = new HashMap<>();
                assignmentData.put( "assignmentName", courseName );
                assignmentData.put( "assignmentUserId", assignmentUserID );
                assignmentData.put( "studentFirstName", SMUtils.getKeyValueFromResponse( studentDetails1, "firstName" ) );
                assignmentData.put( "studentLastName", SMUtils.getKeyValueFromResponse( studentDetails1, "lastName" ) );
                assignmentData.put( "teacherFirstName", SMUtils.getKeyValueFromResponse( teacherDetails, "firstName" ) );
                assignmentData.put( "teacherLastName", SMUtils.getKeyValueFromResponse( teacherDetails, "lastName" ) );
                assignmentData.put( "studentUsername", SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ).toLowerCase() );
                data.put( assignmentUserID, assignmentData );
                Log.message( assignmentData.toString() );

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                Log.message( getResponse.getBody().asString() );
                getRestoreAssignments = new HashMap<>();

                IntStream.range( 0, SMUtils.getWordCount( getResponse.getBody().asString(), "assignmentUserId" ) ).forEach( iter -> {
                    Map<String, String> deletedAssignments = new HashMap<>();
                    String rspn = SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "data" );
                    JSONObject jsonObj = new JSONObject( rspn );
                    JSONArray ja = jsonObj.getJSONArray( "getRestoreAssignments" );
                    JSONObject jObj = ja.getJSONObject( iter );
                    deletedAssignments.put( "assignmentName", jObj.get( "assignmentName" ).toString() );
                    deletedAssignments.put( "assignmentUserId", jObj.get( "assignmentUserId" ).toString() );
                    deletedAssignments.put( "studentFirstName", jObj.get( "studentFirstName" ).toString() );
                    deletedAssignments.put( "studentLastName", jObj.get( "studentLastName" ).toString() );
                    deletedAssignments.put( "teacherFirstName", jObj.get( "teacherFirstName" ).toString() );
                    deletedAssignments.put( "teacherLastName", jObj.get( "teacherLastName" ).toString() );
                    deletedAssignments.put( "studentUsername", jObj.get( "studentUsername" ).toString().toLowerCase() );

                    getRestoreAssignments.put( jObj.get( "assignmentUserId" ).toString(), deletedAssignments );
                } );
                Log.message( data.toString() );
                Log.message( getRestoreAssignments.toString() );
                Log.assertThat( !data.entrySet().stream().anyMatch( entry -> getRestoreAssignments.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) ),
                        "GraphQL not fetched the restored assignment data", "GraphQL fetched the restored assignment data" );

                break;

            case "RESTORE_GROUP_ASSIGNMENT":

                // Creating new group
                newGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                newGroupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserID );
                newGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, teacherOrgID );
                newGroupDetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                HashMap<String, String> createGroupResponse = new GroupAPI().createGroup( smUrl, newGroupDetails, Arrays.asList( studentID1 ) );
                newGroupId = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), "data," + GroupConstants.GROUP_ID );

                // Create custom course
                courseName = "Custom Course" + System.nanoTime();
                courseId = new SharedCourses().createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserID, teacherOrgID, DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );

                // Assigning the course to the student
                assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                // Assigning assignment to group

                Log.assertThat( new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment assigned to group successfully",
                        "Assignment is not assigned to group" );

                // Delete group assignment
                assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, newGroupId );
                Log.assertThat( new AssignmentAPI().deleteAssignmentfromGroup( smUrl, assignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment is deleted from group", "Assignment is not deleted from group" );

                assignmentData = new HashMap<>();
                assignmentData.put( "assignmentName", courseName );
                assignmentData.put( "studentFirstName", SMUtils.getKeyValueFromResponse( studentDetails1, "firstName" ) );
                assignmentData.put( "studentLastName", SMUtils.getKeyValueFromResponse( studentDetails1, "lastName" ) );
                assignmentData.put( "teacherFirstName", SMUtils.getKeyValueFromResponse( teacherDetails, "firstName" ) );
                assignmentData.put( "teacherLastName", SMUtils.getKeyValueFromResponse( teacherDetails, "lastName" ) );
                assignmentData.put( "studentUsername", SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ).toLowerCase() );
                Log.message( assignmentData.toString() );
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                Log.message( getResponse.getBody().asString() );
                getRestoreAssignments = new HashMap<>();

                IntStream.range( 0, SMUtils.getWordCount( getResponse.getBody().asString(), "assignmentUserId" ) ).forEach( iter -> {
                    Map<String, String> deletedAssignments = new HashMap<>();
                    String rspn = SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "data" );
                    JSONObject jsonObj = new JSONObject( rspn );
                    JSONArray ja = jsonObj.getJSONArray( "getRestoreAssignments" );
                    JSONObject jObj = ja.getJSONObject( iter );
                    deletedAssignments.put( "assignmentName", jObj.get( "assignmentName" ).toString() );
                    deletedAssignments.put( "studentFirstName", jObj.get( "studentFirstName" ).toString() );
                    deletedAssignments.put( "studentLastName", jObj.get( "studentLastName" ).toString() );
                    deletedAssignments.put( "teacherFirstName", jObj.get( "teacherFirstName" ).toString() );
                    deletedAssignments.put( "teacherLastName", jObj.get( "teacherLastName" ).toString() );
                    deletedAssignments.put( "studentUsername", jObj.get( "studentUsername" ).toString().toLowerCase() );

                    getRestoreAssignments.put( jObj.get( "assignmentUserId" ).toString(), deletedAssignments );
                } );
                Log.message( assignmentData.toString() );
                Log.message( getRestoreAssignments.toString() );
                Log.assertThat( getRestoreAssignments.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), assignmentData ) ), "GraphQL fetched the deleted assignment data", "GraphQL fetched the deleted assignment data" );

                break;

            case "Valid for orphan student":
                String newStudent = "SchStudent" + System.nanoTime();
                String newStudentDetails = new UserAPI().createUserWithCustomization( newStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( school ) ) );
                newStudentId = SMUtils.getKeyValueFromResponse( newStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfos = new HashMap<>();
                studentInfos = generateRequestValues( newStudentDetails, studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.TEACHER_ID, teacherUserID );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                Log.message( "Updating grade..." );

                HashMap<String, String> updateStudentProfile2 = new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
                Log.message( updateStudentProfile2.toString() );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentId );

                // Adding new student to group
                HashMap<String, String> addStudentToGroup = new GroupAPI().addStudentToGroup( smUrl, newGroupDetails, Arrays.asList( newStudentId ), Arrays.asList( newGroupId ) );
                Log.message( addStudentToGroup.toString() );
                // Assigning assignment to student
                HashMap<String, String> orphanStudentAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( newStudentId ), Arrays.asList( courseId ) );
                Log.message( orphanStudentAssignment.toString() );

                // Getting assignment id
                JSONObject orphanAssignmentDetailsJson = new JSONObject( orphanStudentAssignment.get( Constants.REPORT_BODY ) );
                JSONArray orphanAssignmentList = orphanAssignmentDetailsJson.getJSONArray( Constants.DATA );
                JSONObject orphanAssignmentInfo = new JSONObject( orphanAssignmentList.get( 0 ).toString() );
                String orphanStudentAssignmentId = orphanAssignmentInfo.get( "assignmentId" ).toString();
                orphanStudentAssignmentUserId = getActiveAssignmentUserId( newStudentId, orphanStudentAssignmentId );
                Log.message( "Orphan student assignment user id " + orphanStudentAssignmentUserId );

                // Deleting an assignment
                orphanAssignmentDetail.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                orphanAssignmentDetail.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                orphanAssignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                orphanAssignmentDetail.put( AdminAPIConstants.ASSIGNMENT_USER_ID, orphanStudentAssignmentUserId );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, orphanAssignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Orphan Student assignment removed sucessfully!",
                        "Issue in removing the orphan Student assignment" );

                //Removing new student from group
                HashMap<String, String> removeStudentFromGroup = new GroupAPI().removeStudentFromGroup( smUrl, newStudentId, newGroupId, teacherUserID, teacherOrgID,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                saveResponse = restoreAssignment.restoreAssignmentBFF( headers, orphanStudentAssignmentUserId, userId, districtId, teacherOrgID );
                Log.message( saveResponse.getBody().asString() );

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                Log.message( getResponse.getBody().asString() );
                break;
            case "RESTORE_SUSPENDED_STUDENT_ASSIGNMENT":

                // Adding new student to group
                new GroupAPI().addStudentToGroup( smUrl, newGroupDetails, Arrays.asList( newStudentId ), Arrays.asList( newGroupId ) );

                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, orphanAssignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Orphan Student assignment removed sucessfully!",
                        "Issue in removing the orphan Student assignment" );

                //suspend Student
                Log.assertThat( new RBSUtils().suspendUser( Arrays.asList( newStudentId ) ), "Student is suspended successfully!!", "Student is not suspended" );

                saveResponse = restoreAssignment.restoreAssignmentBFF( headers, orphanStudentAssignmentUserId, userId, districtId, teacherOrgID );
                Log.message( saveResponse.getBody().asString() );

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                Log.message( getResponse.getBody().asString() );
                break;

            case "Valid for updated student name":
                // Create custom course
                courseName = "Custom Course" + System.nanoTime();
                courseId = new SharedCourses().createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserID, teacherOrgID, DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );

                // Assigning the course to the student
                assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentID1 ), Arrays.asList( courseId ) );
                Log.message( assignmentResponse.toString() );
                // Getting Assignment ID
                mathAssignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
                mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
                mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
                assignmentID = mathAssignmentInfo.get( "assignmentId" ).toString();
                Log.message( assignmentID );
                // Getting Assignment User ID
                assignmentUserID = new SqlHelperCourses().getAssignmentUserId( studentID1, assignmentID );
                Log.message( assignmentUserID );
                // Removing student's assignment
                assignmentDetailMath.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetailMath.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetailMath.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserID );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                // Restoring the assignment
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                assignmentData = new HashMap<>();
                assignmentData.put( "assignmentName", courseName );
                assignmentData.put( "assignmentUserId", assignmentUserID );
                assignmentData.put( "studentFirstName", "Updated_stu_fn" );
                assignmentData.put( "studentLastName", "Updated_stu_ln" );
                assignmentData.put( "teacherFirstName", SMUtils.getKeyValueFromResponse( teacherDetails, "firstName" ) );
                assignmentData.put( "teacherLastName", SMUtils.getKeyValueFromResponse( teacherDetails, "lastName" ) );
                assignmentData.put( "studentUsername", SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ).toLowerCase() );
                data.put( assignmentUserID, assignmentData );
                Log.message( assignmentData.toString() );

                // update student info

                studentInfos = new HashMap<>();
                studentInfos = generateRequestValues( studentDetails1, studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.FIRSTNAME, "Updated_stu_fn" );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.LASTNAME, "Updated_stu_ln" );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.TEACHER_ID, teacherUserID );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                Log.message( "Updating grade..." );

                HashMap<String, String> updateStudentProfile = new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
                Log.message( updateStudentProfile.toString() );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentId );

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

                boolean isstudentUpdated;
                int itr = 0;
                do {

                    Thread.sleep( 30000 );
                    getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                    Log.message( getResponse.getBody().asString() );
                    Map<String, Map<String, String>> getRestoreAssignment = new HashMap<>();
                    IntStream.range( 0, SMUtils.getWordCount( getResponse.getBody().asString(), "assignmentUserId" ) ).forEach( iter -> {
                        Map<String, String> deletedAssignments = new HashMap<>();
                        String rspn = SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "data" );
                        JSONObject jsonObj = new JSONObject( rspn );
                        JSONArray ja = jsonObj.getJSONArray( "getRestoreAssignments" );
                        JSONObject jObj = ja.getJSONObject( iter );
                        deletedAssignments.put( "assignmentName", jObj.get( "assignmentName" ).toString() );
                        deletedAssignments.put( "assignmentUserId", jObj.get( "assignmentUserId" ).toString() );
                        deletedAssignments.put( "studentFirstName", jObj.get( "studentFirstName" ).toString() );
                        deletedAssignments.put( "studentLastName", jObj.get( "studentLastName" ).toString() );
                        deletedAssignments.put( "teacherFirstName", jObj.get( "teacherFirstName" ).toString() );
                        deletedAssignments.put( "teacherLastName", jObj.get( "teacherLastName" ).toString() );
                        deletedAssignments.put( "studentUsername", jObj.get( "studentUsername" ).toString().toLowerCase() );

                        getRestoreAssignment.put( jObj.get( "assignmentUserId" ).toString(), deletedAssignments );

                    } );
                    isstudentUpdated = data.entrySet().stream().allMatch( entry -> getRestoreAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );

                    itr++;
                } while ( !isstudentUpdated && itr < 4 );

                Log.assertThat( isstudentUpdated, "GraphQL fetched the user's updated firstname data before the updation", "GraphQL not fetched the updated firstname for student" );

                break;

            case "Valid for updated teacher name":
                // Create custom course
                courseName = "Custom Course" + System.nanoTime();
                courseId = new SharedCourses().createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserID, teacherOrgID, DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );

                // Assigning the course to the student
                assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentID1 ), Arrays.asList( courseId ) );
                Log.message( assignmentResponse.toString() );
                // Getting Assignment ID
                mathAssignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
                mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
                mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
                assignmentID = mathAssignmentInfo.get( "assignmentId" ).toString();
                Log.message( assignmentID );
                // Getting Assignment User ID
                assignmentUserID = new SqlHelperCourses().getAssignmentUserId( studentID1, assignmentID );
                Log.message( assignmentUserID );
                // Removing student's assignment
                assignmentDetailMath.put( AdminAPIConstants.ORG_ID, teacherOrgID );
                assignmentDetailMath.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
                assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetailMath.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserID );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                // Restoring the assignment
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                assignmentData = new HashMap<>();
                assignmentData.put( "assignmentName", courseName );
                assignmentData.put( "assignmentUserId", assignmentUserID );
                assignmentData.put( "studentFirstName", "Updated_stu_fn" );
                assignmentData.put( "studentLastName", "Updated_stu_ln" );
                assignmentData.put( "teacherFirstName", "Updated_teach_fn" );
                assignmentData.put( "teacherLastName", "Updated_teach_ln" );
                assignmentData.put( "studentUsername", SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ).toLowerCase() );
                data.put( assignmentUserID, assignmentData );
                Log.message( assignmentData.toString() );

                // update teacher info
                HashMap<String, String> staffDetails = new HashMap<>();
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserConstants.USERID, teacherUserID );
                staffDetails.put( UserConstants.ORGID, teacherOrgID );
                staffDetails.put( UserConstants.STAFFID, teacherUserID );
                staffDetails.put( UserConstants.PERSONID, teacherUserID );
                staffDetails.put( RBSDataSetupConstants.FIRSTNAME, "Updated_teach_fn" );
                staffDetails.put( RBSDataSetupConstants.LASTNAME, "Updated_teach_ln" );
                staffDetails.put( RBSDataSetupConstants.MIDDLENAME, "" );
                staffDetails.put( "email", "test@demo.com" );
                staffDetails.put( RBSDataSetupConstants.USERNAME, teacherUsername );
                staffDetails.put( "title", "MR" );
                staffDetails.put( UserConstants.USER_PASSWORD, password );
                staffDetails.put( "changePassword", "true" );

                HashMap<String, String> updateStaffProfile = new UserAPI().updateStaffProfile( smUrl, staffDetails );
                Log.message( updateStaffProfile.toString() );

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                boolean isTeacherUpdated;
                int iter = 0;
                do {

                    Thread.sleep( 30000 );
                    getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );
                    Log.message( getResponse.getBody().asString() );
                    Map<String, Map<String, String>> dataFromResponse = new HashMap<>();

                    IntStream.range( 0, SMUtils.getWordCount( getResponse.getBody().asString(), "assignmentUserId" ) ).forEach( iteration -> {
                        Map<String, String> deletedAssignments = new HashMap<>();
                        String rspn = SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "data" );
                        JSONObject jsonObj = new JSONObject( rspn );
                        JSONArray ja = jsonObj.getJSONArray( "getRestoreAssignments" );
                        JSONObject jObj = ja.getJSONObject( iteration );
                        deletedAssignments.put( "assignmentName", jObj.get( "assignmentName" ).toString() );
                        deletedAssignments.put( "assignmentUserId", jObj.get( "assignmentUserId" ).toString() );
                        deletedAssignments.put( "studentFirstName", jObj.get( "studentFirstName" ).toString() );
                        deletedAssignments.put( "studentLastName", jObj.get( "studentLastName" ).toString() );
                        deletedAssignments.put( "teacherFirstName", jObj.get( "teacherFirstName" ).toString() );
                        deletedAssignments.put( "teacherLastName", jObj.get( "teacherLastName" ).toString() );
                        deletedAssignments.put( "studentUsername", jObj.get( "studentUsername" ).toString().toLowerCase() );

                        dataFromResponse.put( jObj.get( "assignmentUserId" ).toString(), deletedAssignments );
                    } );
                    isTeacherUpdated = data.entrySet().stream().allMatch( entry -> dataFromResponse.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );

                    iter++;
                } while ( !isTeacherUpdated && iter < 4 );

                Log.assertThat( isTeacherUpdated, "GraphQL fetched the user's updated firstname successfully", "GraphQL not fetched the updated firstname for teacher" );

                break;

            //case "Valid for Auto selected orgId":

            //String AutoOrgId = "8a7200f77de565ac017e2485321a067c";
            // Get Restore assignments
            //headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            //headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            // Log.message( headers.toString() );
            // Log.message( AutoOrgId );
            // Log.message( userId );
            // Log.message( districtId );
            //getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, AutoOrgId, userId, districtId );
            //Log.message( getResponse.getBody().asString() );
            //Log.assertThat( getResponse.getBody().asString().contains( "assignmentName" ), "Auto selected orgId is present", "Auto selected orgId is not present" );

            default:
                break;
        }

        Log.message( getResponse.getBody().asString() );

        Log.assertThat( getResponse.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + getResponse.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + getResponse.getStatusCode() + "is not Verified" );

        //   Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Positive() {
        Object[][] data = { { "tcgetRestoreAssignmentBFF01", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should return deleted assignments under a specific organizations for as a savvas admin", "200", "Valid for savvas admin" },
                { "tcgetRestoreAssignmentBFF02", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments which are already restored under a specific organizations for as a savvas admin", "200",
                        "Valid for restored assignments" },
                { "tcgetRestoreAssignmentBFF03", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should return deleted assignments under a specific organizations for as a savvas admin after changing the student's name", "200",
                        "RESTORE_GROUP_ASSIGNMENT" },
                { "tcgetRestoreAssignmentBFF04",
                        "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments which are already restored for an orphan student under a specific organizations for as a savvas admin", "200",
                        "Valid for orphan student" },
                { "tcgetRestoreAssignmentBFF05",
                        "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments which are already restored for a suspended student under a specific organizations for as a savvas admin", "200",
                        "RESTORE_SUSPENDED_STUDENT_ASSIGNMENT" },
                { "tcgetRestoreAssignmentBFF06",
                        "Get Restore Assignment - Verify the getRestoreAssignment graphql query should return deleted assignments and updated student name under a specific organizations for as a savvas admin after changing the student's name", "200",
                        "Valid for updated student name" },
                { "tcgetRestoreAssignmentBFF07",
                        "Get Restore Assignment - Verify the getRestoreAssignment graphql query should return deleted assignments and updated teacher name under a specific organizations for as a savvas admin after changing the teacher's name", "200",
                        "Valid for updated teacher name" },
                { "tcgetRestoreAssignmentBFF20", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should return deleted assignments under a specific organizations for as a savvas admin after changing the selected OrgId name", "200",
                        "Valid for Auto selected orgId" }, };
        return data;
    }

    @Test ( dataProvider = "getData_Negative", groups = { "SMK-51776", "Get Restore Assignments", "API" }, priority = 1 )
    public void getRestoreAssignmentBFF_Negative( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseNumber + ":" + testDescription );
        switch ( scenario ) {
            case "Invalid for District Admin":
                districtId = configProperty.getProperty( "district_ID" );
                String districtuserId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                String districtuserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtuserName, password ) );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, districtuserId, districtId );

                break;
            case "Invalid for Sub-district Admin":
                String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                String subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
                String subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, subDistrictwithSchoolId, subdistrictUserID, subDistrictwithSchoolId );

                break;
            case "Invalid for School Admin":
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( schoolAdminUsername, password ) );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" ), schoolAdminUserID, SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" ) );

                break;
            case "Invalid for teacher/student":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, true + "", teacherUserID, teacherOrgID );
                break;

            case "Invalid with invalid query":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                String query = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getRestoreAssignments(\\n userId:\\\"{userID}\\\"\\n organizationId:\\\"{organizationId}\\\"\\n){\\n assignmentName\\n assignmentUserId\\n deletedDate\\n createdDate\\n studentFirstName\\n studentLastName\\n teacherFirstName\\n teacherLastName\\n studentUsername\\n}\\n}\\n\"}";

                query = query.replace( Constants.USER_ID_VALUE, teacherUserID );
                query = query.replace( Constants.ORG_ID, teacherOrgID );
                getResponse = RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );

                break;
            case "Invalid with invalid token":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken + "invalid" );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId );

                break;
            case "Invalid with invalid userId":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId + "invalid", districtId );

                break;
            case "Invalid with invalid orgId":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, districtId + "invalid" );

                break;
            case "Invalid with empty userId":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, "", districtId );
                getResponse.toString();

                break;
            case "Invalid with empty orgID":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID, userId, "" );

                break;
            case "Invalid with invalid selectedOrgId":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, teacherOrgID + "invalid", userId, districtId );

                break;
            case "Invalid with empty selectedOrgId":
                // Get Restore assignments
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                getResponse = restoreAssignment.getRestoreAssignmentBFF( headers, "", userId, districtId );

                break;

        }
        Log.assertThat( getResponse.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + getResponse.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + getResponse.getStatusCode() + "is not Verified" );

        if ( scenario.equalsIgnoreCase( "Invalid with invalid token" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenario.equalsIgnoreCase( "Invalid with invalid orgId" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenario.equalsIgnoreCase( "Invalid with invalid userId" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenario.equalsIgnoreCase( "Invalid with empty userId" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_USERID ), "Getting Invalid message for empty userId", "Not getting Invalid message for Invalid userId" );
        } else if ( scenario.equalsIgnoreCase( "Invalid with empty orgID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        } else if ( ( scenario.equalsIgnoreCase( "Invalid for District Admin" ) ) || ( scenario.equalsIgnoreCase( "Invalid for Sub-district Admin" ) ) || ( scenario.equalsIgnoreCase( "Invalid for School Admin" ) )
                || ( scenario.equalsIgnoreCase( "Invalid for teacher/student" ) ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( "Access denied! You don't have permission for this action!" ), "Getting message for teacher/other customer", "Getting Invalid message for teacher/other customer" );
        } else if ( scenario.equalsIgnoreCase( "Invalid with empty selectedOrgId" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( getResponse.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.INVALID_SELECTED_ORG ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        }

        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Negative() {
        Object[][] data = {
                { "tcgetRestoreAssignmentBFF08", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments under a specific organizations for as a District Admin", "200", "Invalid for District Admin" },
                { "tcgetRestoreAssignmentBFF09", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments under a specific organizations for as a sub-district admin", "200",
                        "Invalid for Sub-district Admin" },
                { "tcgetRestoreAssignmentBFF010", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments under a specific organizations for as a school admin", "200", "Invalid for School Admin" },
                { "tcgetRestoreAssignmentBFF011", "Get Restore Assignment - Verify the getRestoreAssignment graphql query should not return deleted assignments under a specific organizations for as a teacher/student", "200",
                        "Invalid for teacher/student" },
                { "tcgetRestoreAssignmentBFF012", "Get Restore Assignment - Verify 401: UnAuthorized message in response when invalid Bearer token is given ", "200", "Invalid with invalid token" },
                { "tcgetRestoreAssignmentBFF013", "Get Restore Assignment - Verify 400: Bad Request in response when invalid query has been given", "400", "Invalid with invalid query" },
                { "tcgetRestoreAssignmentBFF014", "Get Restore Assignment - Verify  401: UnAuthorized and response when invalid userId is given in the query", "200", "Invalid with invalid userId" },
                { "tcgetRestoreAssignmentBFF015", "Get Restore Assignment - Verify 403 status code and response when invalid organizationId is given in the query", "200", "Invalid with invalid orgId" },
                { "tcgetRestoreAssignmentBFF016", "Get Restore Assignment - Verify  the message in response when empty userId is given in the query", "200", "Invalid with empty userId" },
                { "tcgetRestoreAssignmentBFF017", "Get Restore Assignment - Verify the message in response when empty org-id is given in the query", "200", "Invalid with empty orgID" },
                { "tcgetRestoreAssignmentBFF018", "Get Restore Assignment - Verify the message and response when invalid selectedOrganizationID is given in the query", "200", "Invalid with invalid selectedOrgId" },
                { "tcgetRestoreAssignmentBFF019", "Get Restore Assignment - Verify the message and response when empty selectedOrganizationID is given in the query ", "200", "Invalid with empty selectedOrgId" } };
        return data;
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    public String getActiveAssignmentUserId( String studentPersonId, String assignmentID ) {
        String assignmentUserID = null;
        String queryString = "select assignment_user_id from school.assignment_user where assignment_id=%s and person_id='%s' and isdeleted='0'";
        queryString = String.format( queryString, assignmentID, studentPersonId );
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        return assignmentUserID = arrList.get( 0 );
    }

    public void createData() throws Exception {
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );
        // Getting savvas admin details in RBS Datasetup
        userName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        accessToken = new RBSUtils().getAccessToken( userName, password );
        // Getting teacher details from RBS datasetup
        teacherDetails = RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Teacher1" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherOrgID = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherAccessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        // Getting Student details from RBS datasetup
        studentDetails1 = RBSDataSetup.getMyStudent( school, teacherUsername );
        //  orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );
        studentID1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userId" );
        // Create custom course
        courseName = "Custom Course" + System.nanoTime();
        courseId = new SharedCourses().createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserID, teacherOrgID, DataSetupConstants.SETTINGS, courseName );
        Log.message( courseId );

        // Assigning the course to the student
        assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgID );
        assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherUserID );
        assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        Log.message( "assignment Details: " + assignmentDetails );
        Log.message( "student Id:" + studentID1 );
        Log.message( "course Id :" + courseId );
        HashMap<String, String> assignmentResponse;
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentID1 ), Arrays.asList( courseId ) );
            if ( assignmentResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( "200" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Thread.sleep( 10000 );
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentID1 ), Arrays.asList( courseId ) );
        }
        Log.message( assignmentResponse.toString() );
        // Getting Assignment ID
        JSONObject mathAssignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
        assignmentID = mathAssignmentInfo.get( "assignmentId" ).toString();
        Log.message( assignmentID );
        // Getting Assignment User ID
        assignmentUserID = new SqlHelperCourses().getAssignmentUserId( studentID1, assignmentID );
        Log.message( assignmentUserID );

    }

}
