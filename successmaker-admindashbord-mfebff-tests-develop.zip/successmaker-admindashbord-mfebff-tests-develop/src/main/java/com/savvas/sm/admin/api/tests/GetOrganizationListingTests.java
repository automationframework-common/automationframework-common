package com.savvas.sm.admin.api.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;

public class GetOrganizationListingTests {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String subDistrictId;
    public static String schoolId;
    public static String districtId;
    public static String teacherId;
    public static String username;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgList;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String endPoint;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        endPoint = AdminAPIConstants.GET_CHILD_ORGANIZATIONS;
        districtId = configProperty.getProperty( "district_ID" );
    }

    /**
     * This method is used to test the Organization list.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "validStatusCodeTestData", groups = { "smoke_test_case", "Organization", "SMK-50229", "P1", "API" } )
    public void getOrganizationListingValidTest( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {

        boolean invalidScenario = false;
        Map<String, String> responseFromAPI = null;

        Log.testCaseInfo( tcID + ": " + tcDescription );

        Map<String, String> headers = new HashMap<>();

        if ( tcID.equals( "tcOrgListing002" ) ) {
            // tcOrgListing002 - to get sub-district under District
            orgId = RBSDataSetup.subDistrictwithSchoolId;
            orgList = RBSDataSetup.schoolUnderSubDistrict_SchoolId;
            userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), "userId" );
            accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );
        } else if ( tcID.equals( "tcOrgListing003" ) ) {
            // tcOrgListing003 - Creating School under District
            orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            orgList = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN ), "userId" );
            accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );
        } else {
            orgId = districtId;
            orgList = districtId;
            userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userId" );
            accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );
        }

        switch ( scenario ) {
            case "valid_scenario":
                // headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.ORGID, orgId );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                String responseBody = responseFromAPI.get( Constants.REPORT_BODY );
                Log.message( responseBody );
                break;

            case "Savvas_Admin_with_District_Id":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );
                accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminConstants.SELECTED_ORGANIZATION_ID, districtId );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                Log.message( responseFromAPI.toString() );
                break;

            case "Savvas_Admin_with_School_Id":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );
                accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminConstants.SELECTED_ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                Log.message( responseFromAPI.toString() );
                break;

            case "Savvas_Admin_with_SubDistrict_Id":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );
                accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminConstants.SELECTED_ORGANIZATION_ID, RBSDataSetup.subDistrictwithSchoolId );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                Log.message( responseFromAPI.toString() );
                break;

            default:
                break;
        }

        // Status code Validations
        Log.assertThat( responseFromAPI.get( Constants.REPORT_STATUS_CODE ).equals( expResCode ), "Response status code is as expected." + expResCode,
                "Response status code is not as expected. Actual - " + responseFromAPI.get( Constants.REPORT_STATUS_CODE ) + ".Expected:" + expResCode );

        if ( !invalidScenario && !tcID.equals( "tcOrgListing009" ) ) {
            // schema validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetOrganizationListingSMK-50229_Schema", expResCode, responseFromAPI.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        } else if ( !tcID.equals( "tcOrgListing009" ) ) {
            // schema validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetOrganizationListingSMK-50229_Schema", expResCode, responseFromAPI.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        }

    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "validStatusCodeTestData" )
    public Object[][] validStatusCodeTestData() {
        Object[][] testData = { { "tcOrgListing001", "Verify all the organizations (schools under the district) are returned in response with 200 response code for given customer admin.", "200", "valid_scenario" },
                { "tcOrgListing002", "Verify all the organizations (subdistrict) is returned in response with 200 response code for given customer admin.", "200", "valid_scenario" },
                { "tcOrgListing003", "Verify all the organizations (subdistrict, schools, child schools) is returned in response with 200 response code for given customer admin.", "200", "valid_scenario" },
                { "tcOrgListing004", "Verify status code 200 when given Org ID  is not having product subscription", "200", "valid_scenario" }, { "tcOrgListing005", "Verify status code 200 when orgid is given as school id ", "200", "valid_scenario" },
                { "tcOrgListing006", "Verify the status code and response , if pass the savvas admin credentials and selected orgId as district id.", "200", "Savvas_Admin_with_District_Id" },
                { "tcOrgListing007", "Verify the status code and response , if pass the savvas admin credentials and selected orgId as school id.", "200", "Savvas_Admin_with_School_Id" },
                { "tcOrgListing008", "Verify the status code and response , if pass the savvas admin credentials and selected orgId as subdistrict Id.", "200", "Savvas_Admin_with_SubDistrict_Id" } };
        return testData;
    }

    /**
     * This method is used to test the Organization list.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "NegativeScenariosTestData", groups = { "Organization", "SMK-50229", "P1", "API" } )
    public void getOrganizationListingNegativeTest( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {

        boolean invalidScenario = false;
        Map<String, String> responseFromAPI = null;

        Log.testCaseInfo( tcID + ": " + tcDescription );

        Map<String, String> headers = new HashMap<>();

        orgId = districtId;
        orgList = districtId;
        userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userId" );
        accessToken = rbsUtils.getAccessToken( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

        switch ( scenario ) {

            case "without_userID":
                // headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.ORGID, orgId );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                invalidScenario = true;
                break;

            case "without_SSOToken":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.ORGID, orgId );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                invalidScenario = true;
                break;

            case "without_OrgId":
                // headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.USERID, userId );

                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                invalidScenario = true;
                break;
                
            case "teacher_id":

                String teacherDetails = RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Teacher1" );
                Log.message( teacherDetails );
                Log.message( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                // headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                invalidScenario = true;
                break;

            case "student_id":
                String studentDetails = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );
                Log.message( studentDetails );
                Log.message( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                accessToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                // headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                Log.message( "Making GET Call for organization List - " + smUrl + endPoint );
                responseFromAPI = orgListing.getOrganizationList( smUrl, headers );
                invalidScenario = true;
                break;

            default:
                break;
        }

        // Status code Validations
        Log.assertThat( responseFromAPI.get( Constants.REPORT_STATUS_CODE ).equals( expResCode ), "Response status code is as expected." + expResCode,
                "Response status code is not as expected. Actual - " + responseFromAPI.get( Constants.REPORT_STATUS_CODE ) + ".Expected:" + expResCode );

        if ( !invalidScenario ) {
            // schema validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetOrganizationListingSMK-50229_Schema", expResCode, responseFromAPI.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        } else {
            // schema validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetOrganizationListingSMK-50229_Schema", expResCode, responseFromAPI.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        }

    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "NegativeScenariosTestData" )
    public Object[][] NegativeScenariosTestData() {
        Object[][] testData = { { "tcOrgListing009", "Verify status code 401 when user id is not passed in header parameter", "401", "without_userID" },
                { "tcOrgListing010", "Verify status code 401 when SSO token  is not passed in header parameter", "401", "without_SSOToken" },
                { "tcOrgListing011", "Verify status code 400 when Org ID  is not passed in query parameter", "400", "without_OrgId" }, { "tcOrgListing012", "Verify status code 403 when User ID  is teacher rumba id in headers", "403", "teacher_id" },
                { "tcOrgListing013", "Verify status code 403 when User ID  is student rumba id in headers", "403", "student_id" }, };
        return testData;
    }

    /**
     * To Convert JSON response into API
     * 
     * @return
     */
    public Map<String, Map<String, String>> convertOrgListingJsonFromRBStoHashMap( String responseFromRBS, String parentOrgId ) {

        List<String> orgIds = Arrays.asList( SMUtils.getKeyValueFromResponse( responseFromRBS, "subOrganizationIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" ).split( "," ) );

        Map<String, Map<String, String>> childOrgs = new HashMap<>();
        Map<String, Map<String, String>> parentOrgs = new HashMap<>();
        orgIds.stream().forEach( orgId -> {
            String orgResponse = SMUtils.getKeyValueFromResponse( responseFromRBS, "subOrgTree," + orgId );
            Map<String, String> orgResponses = new HashMap<>();
            orgResponses.put( "Response", orgResponse );
            orgResponses.put( "ParentOrg", parentOrgId );
            parentOrgs.put( orgId, orgResponses );
        } );

        childOrgs = parentOrgs;
        HashMap<String, Map<String, String>> orgDetailsFromRBS = new HashMap<>();
        while ( !childOrgs.isEmpty() ) {

            Map<String, Map<String, String>> grandChilds = new HashMap<>();

            childOrgs.entrySet().forEach( entryset -> {
                Map<String, String> orgDetails = new HashMap<>();
                orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, SMUtils.getKeyValueFromResponse( entryset.getValue().get( "Response" ), "organization,displayName" ) );
                orgDetails.put( "ParentOrg", entryset.getValue().get( "ParentOrg" ) );
                orgDetailsFromRBS.put( entryset.getKey(), orgDetails );
                String childorgs = SMUtils.getKeyValueFromResponse( entryset.getValue().get( "Response" ), "subOrganizationIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );

                List<String> childorgIds = new ArrayList<>();
                if ( !childorgs.equals( "" ) ) {
                    childorgIds = Arrays.asList( childorgs.split( "," ) );
                }

                childorgIds.stream().forEach( orgId -> {
                    String orgResponse = SMUtils.getKeyValueFromResponse( entryset.getValue().get( "Response" ), "subOrgTree," + orgId );
                    Map<String, String> orgResponses = new HashMap<>();
                    orgResponses.put( "Response", orgResponse );
                    orgResponses.put( "ParentOrg", entryset.getKey() );
                    grandChilds.put( orgId, orgResponses );
                } );

            } );
            childOrgs = grandChilds;
        }

        return orgDetailsFromRBS;
    }

}
