package com.savvas.sm.admin.apiIntegration.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;

public class OrganizationDropdownSelectionTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String password;
    Map<String, String> headers = new HashMap<>();

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = " Verify the Organization drop down for district admin", groups = { "SMK-51725", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdownSelection001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdownSelection001: Verify the Organisation drop down fro district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify organizations under the district are displayed in organization dropdown" );
            SMUtils.logDescriptionTC( "Log in as district admin whose district has two or more sub-districts with organizations" );
            SMUtils.logDescriptionTC( "Log in as district admin whose district has two or more schools" );
            // expand organization dropdown
            dashBoardPage.expandOrganizationDropdown();
            List<String> organizationListFromAPI = getOrganizationsForAdmin( Admins.DISTRICT_ADMIN );
            // get organization from organizations dropdown
            List<String> organizationsFromUI = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            Log.assertThat( SMUtils.compareTwoList( organizationListFromAPI, organizationsFromUI ), "All organizations are displayed for district admin properly!", "All organizations are displayed for district admin properly!" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Organization dropdown for subdistrict admin", groups = { "SMK-51725", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdownSelection002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdownSelection002: Verify organization dropdown list if an organization is added under sub-distict which has no org before. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify sub-district name is displayed in organization dropdown when login as sub-district admin with no school" );
            SMUtils.logDescriptionTC( "Verify organization dropdown list if an organization is added under sub-distict which has no org before" );
            List<String> organizationListFromAPI = getOrganizationsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );

            if ( organizationListFromAPI.size() == 1 ) {
                Log.assertThat( !dashBoardPage.isOrganizationDropdownDisplayed(), "if Admin has only one organization, Organization dropodown is not displayed as expected ", "if Admin has only one organization, Organization dropodown is displayed" );
                Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equalsIgnoreCase( organizationListFromAPI.get( 0 ) ), "organization is selected  by default", "The single organization is not selected  by default" );
            } else {
                // expand organization dropdown
                dashBoardPage.expandOrganizationDropdown();

                // get organization from organizations dropdown
                List<String> organizationsFromUI = dashBoardPage.getAllOrganizationsFromOrgDropdown();
                Log.assertThat( SMUtils.compareTwoList( organizationListFromAPI, organizationsFromUI ), "All organizations are displayed for district admin properly!", "All organizations are displayed for district admin properly!" );
            }

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify the organization dropdown for multiple school admin", groups = { "SMK-51725", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdownSelection003() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdownSelection003: Verify organization dropdown list if an organization is added under sub-distict which has no org before. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "Log in as school admin which has two or more organizations and verify the organizations are displayed in organization dropdown" );
            SMUtils.logDescriptionTC( "Add an organization to school admin and verify that organization is displayed in organization dropdown" );

            List<String> organizationListFromAPI = getOrganizationsForAdmin( Admins.MULTI_SCHOOL_ADMIN );

            if ( organizationListFromAPI.size() == 1 ) {
                Log.assertThat( !dashBoardPage.isOrganizationDropdownDisplayed(), "if Admin has only one organization, Organization dropodown is not displayed as expected ", "if Admin has only one organization, Organization dropodown is displayed" );
                Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equalsIgnoreCase( organizationListFromAPI.get( 0 ) ), "organization is selected  by default", "The single organization is not selected  by default" );
            } else {
                // expand organization dropdown
                dashBoardPage.expandOrganizationDropdown();

                // get organization from organizations dropdown
                List<String> organizationsFromUI = dashBoardPage.getAllOrganizationsFromOrgDropdown();
                Log.assertThat( SMUtils.compareTwoList( organizationListFromAPI, organizationsFromUI ), "All organizations are displayed for district admin properly!", "All organizations are displayed for district admin properly!" );
            }

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Log in as school admin which has one organization and verify the organization is displayed in organization dropdown ", groups = { "SMK-51725", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdownSelection004() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdownSelection004: Log in as school admin which has one organization and verify the organization is displayed in organization dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            List<String> organizationListFromAPI = getOrganizationsForAdmin( Admins.SCHOOL_ADMIN );
            SMUtils.logDescriptionTC( "Log in as school admin which has one organization and verify the organization is displayed in organization dropdown" );
            Log.assertThat( !dashBoardPage.isOrganizationDropdownDisplayed(), "if Admin has only one organization, Organization dropodown is not displayed as expected ", "if Admin has only one organization, Organization dropodown is displayed" );
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equalsIgnoreCase( organizationListFromAPI.get( 0 ) ), "organization is selected  by default", "The single organization is not selected  by default" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the organization List for given admin
     * 
     * @param admin
     * @return
     * @throws Exception
     */
    public List<String> getOrganizationsForAdmin( Admins admin ) throws Exception {
        String orgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
            Log.message( orgId );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );

        // headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.ORGID, orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers );
        List<String> organizationListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME ) ).forEach(
                iter -> organizationListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME, iter ) ) );

        return organizationListFromAPI;
    }

}
