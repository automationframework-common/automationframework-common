package com.savvas.sm.admin.bff.tests;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.settings.HolidaySchedulerBFF;

import io.restassured.response.Response;

public class GetSubroleTypeBFFTest extends EnvProperties {
    Response response;
    HolidaySchedulerBFF holidayScheduler = new HolidaySchedulerBFF();

    @Test ( dataProvider = "getData_Positive", groups = { "SMK-51774", "Get Subrole Type", "Holiday Scheduler", "API", "P1" }, priority = 1 )
    public void getSubRoleType_Positive( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseNumber + ": " + testDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenario ) {
            case "Valid with district admin details":
                String orgId = configProperty.getProperty( "district_ID" );
                String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                String username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId, headers, AdminAPIConstants.CA_ROLE, orgId );
                Log.message( response.getBody().asString() );
                String subRoleType = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,getSubOrgRoleType" ), "subRoleType" );
                // Data Validation
                Log.assertThat( subRoleType.equals( AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN ), "The subroletype for district admin is verified", "The subroletype for district admin is not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getSubRoleTypeBFFschema", statusCode, response.getBody().asString() ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;
            case "Valid with sub-district admin details":
                String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                String subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
                String subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( subdistrictUserID, subDistrictwithSchoolId, headers, AdminAPIConstants.CA_ROLE, subDistrictwithSchoolId );
                Log.message( response.getBody().asString() );
                subRoleType = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,getSubOrgRoleType" ), "subRoleType" );
                // Data Validation
                Log.assertThat( subRoleType.equals( AdminAPIConstants.SUBROLETYPE_SUBDISTRICT_ADMIN ), "The subroletype for sub-district admin is verified", "The subroletype for sub-district admin is not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getSubRoleTypeBFFschema", statusCode, response.getBody().asString() ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;
            case "Valid with school admin details":
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
                String schoolAdminOrgId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUsername, password ) );
                response = holidayScheduler.getSubRoleTypeBFF( schoolAdminUserID, schoolAdminOrgId, headers, AdminAPIConstants.CA_ROLE, schoolAdminOrgId );
                Log.message( response.getBody().asString() );
                subRoleType = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,getSubOrgRoleType" ), "subRoleType" );
                // Data Validation
                Log.assertThat( subRoleType.equals( AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN ), "The subroletype for school admin is verified", "The subroletype for school admin is not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getSubRoleTypeBFFschema", statusCode, response.getBody().asString() ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;
            case "Invalid with invalid access token":
                orgId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) + "Invalid" );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId, headers, AdminAPIConstants.CA_ROLE, orgId );
                Log.message( response.getBody().asString() );

                String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                String message = getErrorMessage( error, "message" );
                Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for " + scenario, "The Unauthorized message is not getting displayed for " + scenario );

                break;
            case "Invalid with no role is passed":
                orgId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId, headers, "", orgId );
                Log.message( response.getBody().asString() );

                error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                message = getErrorMessage( error, "message" );
                Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_ROLE ), "Getting error message for empty role", "Not getting proper error message for empty role" );

                break;
            case "Invalid with invalid org id":
                orgId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId + "invalid", headers, AdminAPIConstants.CA_ROLE, orgId );
                Log.message( response.getBody().asString() );

                error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                message = getErrorMessage( error, "message" );
                Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_WRONG_ORGID ), "Getting error message for invalid orgId", "Not getting proper error message for invalid orgId" );

                break;
            case "Invalid with invalid user id":
                orgId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( "", orgId, headers, AdminAPIConstants.CA_ROLE, orgId );
                Log.message( response.getBody().asString() );

                error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                message = getErrorMessage( error, "message" );
                Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_USERID ), "Getting error message for empty userId", "Not getting proper error message for empty userId" );

                break;
            case "Invalid with no org id":
                orgId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, "", headers, AdminAPIConstants.CA_ROLE, "" );
                Log.message( response.getBody().asString() );

                error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                message = getErrorMessage( error, "message" );
                Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_ORGID ), "Getting error message for empty orgId", "Not getting proper error message for empty orgId" );

                break;
            case "Invalid with no user id":
                orgId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( "", orgId, headers, AdminAPIConstants.CA_ROLE, orgId );
                Log.message( response.getBody().asString() );

                error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
                message = getErrorMessage( error, "message" );
                Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_USERID ), "Getting error message for empty userId", "Not getting proper error message for empty userId" );

                break;

            case "valid with savvas admin details(district id)":
                String districtId = configProperty.getProperty( "district_ID" );
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId, headers, AdminAPIConstants.SA_ROLE, districtId );
                Log.message( response.getBody().asString() );
                subRoleType = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,getSubOrgRoleType" ), "subRoleType" );
                // Data Validation
                Log.assertThat( subRoleType.equals( AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN ), "The subroletype for savvas admin (district id) is verified", "The subroletype for  savvas admin (district id) is not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getSubRoleTypeBFFschema", statusCode, response.getBody().asString() ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;

            case "valid with savvas admin details(subdistrict id)":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId, headers, AdminAPIConstants.SA_ROLE, RBSDataSetup.subDistrictwithSchoolId );
                Log.message( response.getBody().asString() );
                subRoleType = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,getSubOrgRoleType" ), "subRoleType" );
                // Data Validation
                Log.assertThat( subRoleType.equals( AdminAPIConstants.SUBROLETYPE_SUBDISTRICT_ADMIN ), "The subroletype for savvas admin (district id) is verified", "The subroletype for  savvas admin (district id) is not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getSubRoleTypeBFFschema", statusCode, response.getBody().asString() ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;

            case "valid with savvas admin details(school id)":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.USERID );
                username = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );
                password = RBSDataSetupConstants.DEFAULT_PASSWORD;

                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = holidayScheduler.getSubRoleTypeBFF( userId, orgId, headers, AdminAPIConstants.SA_ROLE, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                Log.message( response.getBody().asString() );
                subRoleType = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,getSubOrgRoleType" ), "subRoleType" );
                // Data Validation
                Log.assertThat( subRoleType.equals( AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN ), "The subroletype for savvas admin (district id) is verified", "The subroletype for  savvas admin (district id) is not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getSubRoleTypeBFFschema", statusCode, response.getBody().asString() ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;

            default:
                break;
        }
        Log.message( response.toString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.getStatusCode() + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Positive() {
        Object[][] data = { { "TCGetSubRoleType001", "Verify the getSubOrgRoleType graphql query is returned the correct role type when district admin details are passed", "200", "Valid with district admin details" },
                { "TCGetSubRoleType002", "Verify the getSubOrgRoleType graphql query is returned the correct role type when subdistrict admin details are passed", "200", "Valid with sub-district admin details" },
                { "TCGetSubRoleType003", "Verify the getSubOrgRoleType graphql query is returned the correct role type when school admin details are passed", "200", "Valid with school admin details" },
                { "TCGetSubRoleType004", "Verify the getSubOrgRoleType graphql query is returned authentication error when invalid access token is passed", "200", "Invalid with invalid access token" },
                { "TCGetSubRoleType005", "Verify the getSubOrgRoleType graphql query is returned 400 bad request when role is not passed in the query", "200", "Invalid with no role is passed" },
                { "TCGetSubRoleType006", "Verify the getSubOrgRoleType graphql query is returned authentication error when invalid org id is passed", "200", "Invalid with invalid org id" },
                { "TCGetSubRoleType007", "Verify the getSubOrgRoleType graphql query is returned authentication error when invalid user id is passed", "200", "Invalid with invalid user id" },
                { "TCGetSubRoleType008", "Verify the getSubOrgRoleType graphql query is returned authentication error when org id is not passed", "200", "Invalid with no org id" },
                { "TCGetSubRoleType009", "Verify the getSubOrgRoleType graphql query is returned authentication error when user id is not passed", "200", "Invalid with no user id" },
                { "TCGetSubRoleType010", "Verify the getSubOrgRoleType graphql query is returned the correct role type when hit the BFF using savvas admin credential and district Id is passed as  selected orgId .", "200",
                        "valid with savvas admin details(district id)" },
                { "TCGetSubRoleType011", "Verify the getSubOrgRoleType graphql query is returned the correct role type when hit the BFF using savvas admin credential and subdistrict Id is passed as  selected orgId .", "200",
                        "valid with savvas admin details(subdistrict id)" },
                { "TCGetSubRoleType012", "Verify the getSubOrgRoleType graphql query is returned the correct role type when hit the BFF using savvas admin credential and school Id is passed as  selected orgId .", "200",
                        "valid with savvas admin details(school id)" }, };
        return data;
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

}
