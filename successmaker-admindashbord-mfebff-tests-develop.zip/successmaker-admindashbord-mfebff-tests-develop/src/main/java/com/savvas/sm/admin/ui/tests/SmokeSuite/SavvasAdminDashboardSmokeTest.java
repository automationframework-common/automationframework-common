package com.savvas.sm.admin.ui.tests.SmokeSuite;

import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory.AUDIT_HISTORY_TABLE_HEADER;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

public class SavvasAdminDashboardSmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtId;
    private String userName;
    private String teacherDetails;
    private String teacherId;
    private String teacherUsername;
    private String teacherOrgId;
    private String studentDetails;
    private String schoolName;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String sharedCourseName;
    private String deletedCourseName;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting district admin details from RBS Datasetup
        userName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );

        // Getting teacher details
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( schoolName );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = RBSDataSetup.organizationIDs.get( schoolName );
        studentDetails = RBSDataSetup.getMyStudent( schoolName, teacherUsername );

        //Creating Shared Course
        sharedCourseName = "Math Custom by Setting_" + System.nanoTime();
        new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, teacherOrgId, DataSetupConstants.SETTINGS, sharedCourseName );
        Log.message( "Shared course is created successfully!!!" );

        // Creating custom course
        deletedCourseName = "Custom Course" + System.nanoTime();
        String courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, teacherOrgId, DataSetupConstants.SETTINGS, deletedCourseName );
        Log.message( "Custom course is created successfully!!!" );

        // Assigning an assignment
        HashMap<String, String> assignmentDetails = new HashMap<String, String>();
        assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        new AssignmentAPI().assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) ), "users" );
        Log.message( "Assigned an assignment to the Student" );

        // Deleting an assignment
        new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        Log.message( "Assignment is deleted successfully!!!" );

    }

    @Test ( description = "Verify the user able to access the successmaker admin page ", groups = { "smoke_test_case", "Savvas Admin - Dashboard", "Admin_TC34", "P1" }, priority = 1 )
    public void tcSMSavvasAdminDashboardSmokeTest001() throws Exception {

        //Creating shared course
        WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMSavvasAdminDashboardSmokeTest001: Verify the user able to access the successmaker admin page  <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursesPage = smLoginPage.loginToSM( userName, password, districtId );

            // Navigating to shared course Page
            Log.assertThat( sharedCoursesPage.isLeftNavSelected( SubNavigations.SHARED_COURSES ), "Shared Course option is displaying for savvas admin", "Shared Course option is not displaying for savvas admin" );

            //Verify the created Shared Courses
            sharedCoursesPage.enterValueInSearchBox( sharedCourseName );
            Log.assertThat( sharedCoursesPage.getAllSharedCourses().contains( sharedCourseName ), "Created Shared Course is displaying for savvas admin", "Created Shared Course is not displaying for savvas admin" );

            //Navigate to audit history page
            AuditHistoryPage auditHistoryPage = sharedCoursesPage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.isLeftNavSelected( SubNavigations.AUDIT_HISTORY ), "Audit history option is displaying for savvas admin", "Audit history option is not displaying for savvas admin" );

            auditHistoryPage.selectOrganization( schoolName );

            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME ).contains( deletedCourseName ), "Deleted Assignments are not displaying properly for savvas admin",
                    "Deleted Assignments are displaying properly for savvas admin" );

            SettingsListPage settingpage = sharedCoursesPage.navigateToSettingListPage();
            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
