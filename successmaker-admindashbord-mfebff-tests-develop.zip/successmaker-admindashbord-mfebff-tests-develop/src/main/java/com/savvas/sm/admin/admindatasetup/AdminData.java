package com.savvas.sm.admin.admindatasetup;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

public class AdminData extends EnvProperties {

    public static String orgId;
    public static Map<String, String> teacherDetails = new HashMap<>();
    public static Map<String, String> teacherGroupDetails = new HashMap<>();

    public static String districtAdmin;
    public static String schoolAdmin;
    public static String multiSchoolAdmin;
    public static String subDistrictAdmin;

    public static String districtAdminDetails;
    public static String schoolAdminDetails;
    public static String multiSchoolAdminDetails;
    public static String subDistrictAdminDetails;

    public static Map<String, Map<String, String>> defaultMathAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> mathStandardAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> mathSkillAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> mathSettingIPMOFFAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> mathSettingIPMONAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> mathFocusAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> defaultReadingAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> readingStandardAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> readingSkillAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> readingSettingIPMOFFAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> readingSettingIPMONAssignmentDetails = new HashMap<>();
    public static Map<String, Map<String, String>> readingFocusAssignmentDetails = new HashMap<>();

    private static String smUrl;
    RBSUtils rbsUtils;
    private static String usernameSuffixTest;
    private String studentAssignmentResponse;

    /**
     * This constructor loads the necessary details when it is invoked.
     */
    public AdminData() {}

    /**
     * starting test data setup
     *
     * @throws Exception
     */
    @BeforeClass ( alwaysRun = true )
    private void loadAssignmentDetails() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        rbsUtils = new RBSUtils();
        orgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        districtAdmin = String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest );
        schoolAdmin = String.format( RBSDataSetupConstants.SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
        multiSchoolAdmin = String.format( RBSDataSetupConstants.MULTI_SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
        subDistrictAdmin = String.format( RBSDataSetupConstants.SUBDISTRICT_ADMIN_USERNAME, usernameSuffixTest );

        districtAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( districtAdmin ) );
        schoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( schoolAdmin ) );
        multiSchoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( multiSchoolAdmin ) );
        subDistrictAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( subDistrictAdmin ) );
    }

    @Test
    public void loadData() {

        IntStream.rangeClosed( 1, 2 ).forEach( iteration -> {

            HashMap<String, String> assignmentDetails = new HashMap<>();
            String userName = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, iteration, usernameSuffixTest );
            String userId = rbsUtils.getUserIDByUserName( userName );

            teacherDetails.put( userName, rbsUtils.getUser( userId ) );
            try {
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        rbsUtils.getAccessToken( String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, iteration, usernameSuffixTest ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                // Get Teacher's assignment details
                HashMap<String, String> assignmentLists = new AssignmentAPI().getAssignmentLists( smUrl, assignmentDetails );

                // Get Teacher's group details
                assignmentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                assignmentDetails.put( GroupConstants.STAFF_ID, userId );
                teacherGroupDetails.put( userName, SMUtils.getKeyValueFromResponseWithArray( new GroupAPI().getGroupListingForTeacherID( smUrl, assignmentDetails ).get( Constants.REPORT_BODY ), "data" ) );

                String assignments = assignmentLists.get( Constants.REPORT_BODY );
                Log.message( assignments );
                IntStream.rangeClosed( 1, new JSONObject( assignments ).getJSONArray( "data" ).length() ).forEach( itr -> {
                    assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, SMUtils.getKeyValueFromJsonArray( assignments, "id", itr ) );
                    try {
                        studentAssignmentResponse = new AssignmentAPI().getViewAssignment( smUrl, assignmentDetails ).get( Constants.REPORT_BODY );
                    } catch ( Exception e ) {
                        Log.message( "Issue in getting assignment student details!!!" );
                    }
                    Map<String, String> studentAssignmentDetails = new HashMap<>();
                    IntStream.rangeClosed( 1, new JSONObject( studentAssignmentResponse ).getJSONArray( "data" ).length() ).forEach( student -> {
                        studentAssignmentDetails.put( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromJsonArray( studentAssignmentResponse, "studentDetail", student ), "studentId" ),
                                new JSONObject( studentAssignmentResponse ).getJSONArray( "data" ).get( student - 1 ).toString() );
                    } );

                    if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "default.math" ) ) {
                        defaultMathAssignmentDetails.put( userName, studentAssignmentDetails );
                    } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "default.reading" ) ) {
                        defaultReadingAssignmentDetails.put( userName, studentAssignmentDetails );
                    } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "focus.math" ) ) {
                        mathFocusAssignmentDetails.put( userName, studentAssignmentDetails );
                    } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "focus.reading" ) ) {
                        readingFocusAssignmentDetails.put( userName, studentAssignmentDetails );
                    } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "productKey", itr ).equals( "custom" ) ) {
                        if ( SMUtils.getKeyValueFromJsonArray( assignments, "subject", itr ).equals( "MATH" ) ) {
                            if ( SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SETTINGS" ) ) {
                                if ( SMUtils.getKeyValueFromResponse( new JSONObject( studentAssignmentResponse ).getJSONArray( "data" ).get( 0 ).toString(), "ipStatus" ).equals( "INACTIVE" ) ) {
                                    mathSettingIPMOFFAssignmentDetails.put( userName, studentAssignmentDetails );
                                } else {
                                    mathSettingIPMONAssignmentDetails.put( userName, studentAssignmentDetails );
                                }
                            } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_STANDARDS" ) ) {
                                mathStandardAssignmentDetails.put( userName, studentAssignmentDetails );
                            } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SKILLS" ) ) {
                                mathSkillAssignmentDetails.put( userName, studentAssignmentDetails );
                            }
                        } else {
                            if ( SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SETTINGS" ) ) {
                                if ( SMUtils.getKeyValueFromResponse( new JSONObject( studentAssignmentResponse ).getJSONArray( "data" ).get( 0 ).toString(), "ipStatus" ).equals( "INACTIVE" ) ) {
                                    readingSettingIPMOFFAssignmentDetails.put( userName, studentAssignmentDetails );
                                } else {
                                    readingSettingIPMONAssignmentDetails.put( userName, studentAssignmentDetails );
                                }
                            } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_STANDARDS" ) ) {
                                readingStandardAssignmentDetails.put( userName, studentAssignmentDetails );
                            } else if ( SMUtils.getKeyValueFromJsonArray( assignments, "courseType", itr ).equals( "CUSTOM_BY_SKILLS" ) ) {
                                readingSkillAssignmentDetails.put( userName, studentAssignmentDetails );
                            }
                        }
                    }
                } );

            } catch ( Exception e ) {
                Log.message( "Unable to get the assignment list for the teacher!!! " + e );
            }
        } );

        Log.message( teacherGroupDetails.toString() );
        Log.message( teacherDetails.toString() );
        Log.message( districtAdminDetails );
        Log.message( subDistrictAdminDetails );
        Log.message( schoolAdminDetails );

        Log.message( defaultMathAssignmentDetails.toString() );
        Log.message( mathSettingIPMOFFAssignmentDetails.toString() );
        Log.message( mathSettingIPMONAssignmentDetails.toString() );
        Log.message( mathSkillAssignmentDetails.toString() );
        Log.message( mathStandardAssignmentDetails.toString() );
        Log.message( mathFocusAssignmentDetails.toString() );
        Log.message( defaultReadingAssignmentDetails.toString() );
        Log.message( readingSettingIPMOFFAssignmentDetails.toString() );
        Log.message( readingSettingIPMONAssignmentDetails.toString() );
        Log.message( readingStandardAssignmentDetails.toString() );
        Log.message( readingFocusAssignmentDetails.toString() );
    }

}