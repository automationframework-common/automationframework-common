package com.savvas.sm.admin.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory.AUDIT_HISTORY_NAVIGATION_BUTTONS;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory.AUDIT_HISTORY_TABLE_HEADER;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.utils.SMUtils;

import io.restassured.response.Response;

public class AuditHistoryPage extends LoadableComponent<AuditHistoryPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    // *******************Success Maker Setting List page*******************//

    @FindBy ( className = "logo-image" )
    WebElement smLogo;

    @FindBy ( css = "ul.side-nav" )
    WebElement sideNav;

    @FindBy ( css = "ul.side-nav li span.side-nav-item" )
    List<WebElement> sideNavigationList;

    @FindBy ( css = "audit-history h1.header" )
    WebElement headerLabel;

    @FindBy ( css = "cel-icon[class='contextual-help-icon hydrated']" )
    WebElement headerHelpIconRoot;

    @FindBy ( css = "audit-history-filter label.text-label" )
    WebElement organizationLabel;

    @FindBy ( css = "cel-dropdown-select button" )
    WebElement organizationDropdown;

    @FindBy ( css = "div.not-found p.not-found-results" )
    WebElement noResultDisplayedText;

    @FindBy ( css = "div.not-found p.not-found-description" )
    WebElement noResultDisplayedDescriptionText;

    @FindBy ( css = "span#dropdown-value" )
    WebElement placeHolderDropdownText;

    @FindBy ( css = "cel-dropdown-select li a span" )
    List<WebElement> organizationsList;

    @FindBy ( css = "table-head" )
    List<WebElement> columnHeaderList;

    @FindBy ( css = ".table-head tr th span span" )
    List<WebElement> columnHeaderList1;

    @FindBy ( css = "table-container" )
    WebElement tableContainer;

    @FindBy ( css = "cel-paginator[class='pagination hydrated']" )
    WebElement pageCountRoot;

    @FindBy ( css = "audit-history-list tbody tr.table-row" )
    List<WebElement> rowValues;

    @FindBy ( css = "dropdown-option sc-cel-dropdown-select" )
    WebElement organizationList;

    @FindBy ( css = "table-row highlight-on-hover" )
    WebElement assignmentList;

    @FindBy ( css = "audit-history h1.header" )
    List<WebElement> header;

    @FindBy ( css = "dropdown-option-label sc-cel-dropdown-select" )
    WebElement selectOrg;

    @FindBy ( css = "li.side-nav-wrapper-active" )
    WebElement selectedSideNavBar;

    @FindBy ( css = "cel-dropdown-select .dropdown-select-options-wrapper ul>li a>span" )
    List<WebElement> dropdownSelectorForOrgNew;

    // *********************Child elements****************************//
    public static String helpIconChild = "img.icon-inner";
    public static String pageCountChild = "span.page-items";
    public static String nextButtonChild = "button[class='pagination-button next']";
    public static String firstButtonChild = "button[class='pagination-button first']";
    public static String pagesFormat = "div.page-navigation span";
    public static String navigationButtonsChild = "div.page-navigation button";
    public static String columnvalues = "td:nth-child(%s) span";

    // ***************************All Common
    // methods*******************************//

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public AuditHistoryPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, headerLabel );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, headerLabel, 10 ) ) {
            Log.message( "SM Audit History Page loaded successfully." );
        } else {
            Log.fail( "SM Audit History Page did not load." );
        }

    }

    /***
     * This method used to verify the audit history in Sub navigation menu is
     * displayed
     * 
     * @return boolean
     * @author balaji.chandra
     */

    public boolean verifyAuditHistoryinSubNavigation() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
        wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        Log.message( "Verifying Audit History page is available in Sub Navigation" );
        return SMUtils.getAllTextFromWebElementList( sideNavigationList ).contains( AuditHistory.HEADER );
    }

    /***
     * This method help the user to rertrieve the url of the page
     * 
     * @author balaji.chandra
     * @return String
     */

    public String getAuditHistoryURL() {
        Log.message( "Retrieving the URL of the page: " + driver.getCurrentUrl() );
        return driver.getCurrentUrl();
    }

    /***
     * This method retrieves the Page Header of audit history
     * 
     * @author balaji.chandra
     * @return String
     */
    public String getAuditHistoryPageTitle() {
        SMUtils.waitForElement( driver, headerLabel );
        Log.message( "Retrieved the title of the Audit History Page as: " + SMUtils.getTextOfWebElement( headerLabel, driver ) );
        return SMUtils.getTextOfWebElement( headerLabel, driver );
    }

    /***
     * This method helps the user to retrieve the Help Icon in Audit History
     * Page
     * 
     * @author balaji.chandra
     * @return boolean
     */
    public boolean verifyHelpIconAuditHistoryPageDisplayed() {
        SMUtils.waitForElement( driver, headerHelpIconRoot );
        Log.message( "Verifying the Help icon in Audit History page" );
        return SMUtils.getWebElement( driver, headerHelpIconRoot, helpIconChild ).isDisplayed();
    }

    /***
     * This method verifies the organization drop down is present in the audit
     * history page
     * 
     * @author balaji.chandra
     * @return boolean
     */
    public boolean verifyOrganizationDropdownDisplayed() {
        SMUtils.waitForElement( driver, organizationDropdown );
        Log.message( "Verifying the Organizations drop down is displayed in the Audit History Page" );
        return organizationDropdown.isDisplayed();
    }

    /***
     * This method retrieves the Zero State Header message
     * 
     * @author balaji.chandra
     * @return String
     */
    public String getZeroStateHeader() {
        SMUtils.waitForElement( driver, noResultDisplayedText );
        Log.message( "Retrieving the Zero State message Header" );
        return SMUtils.getTextOfWebElement( noResultDisplayedText, driver );
    }

    /***
     * This method retrieves the Zero State message
     * 
     * @author balaji.chandra
     * @return String
     */
    public String getZeroStateMessage() {
        SMUtils.waitForElement( driver, noResultDisplayedDescriptionText );
        Log.message( "Retrieving the Zero state message" );
        return SMUtils.getTextOfWebElement( noResultDisplayedDescriptionText, driver );
    }

    /***
     * This method retrieves all the organizations from the organization drop
     * down
     * 
     * @author balaji.chandra
     * @return List<String>
     */
    public List<String> getAllOrganizationsfromdropdown() {
        SMUtils.waitForElement( driver, organizationDropdown );
        SMUtils.clickJS( driver, organizationDropdown );
        return convertToLowerCase( SMUtils.getAllTextFromWebElementList( organizationsList ) );
    }

    /***
     * This method select the given organization name
     * 
     * @author balaji.chandra
     * @param organization
     * @return
     */
    public boolean selectOrganization( String organization ) {
        SMUtils.waitForElement( driver, organizationDropdown );
        String expanded_Status = SMUtils.getAttributeOfWebElement( organizationDropdown, driver, "aria-expanded" );
        if ( expanded_Status.equals( "false" ) ) {
            SMUtils.clickJS( driver, organizationDropdown );
            Log.message( "The Organization drop down is expanded" );
        } else {
            Log.message( "The Organization drop down is already expanded" );
        }
        organizationsList.stream().filter( eachElement -> eachElement.getText().trim().equals( organization ) ).findFirst().ifPresent( eachElement -> {
            SMUtils.clickJS( driver, eachElement );
            Log.message( "The Organization " + organization + " is selected" );
        } );
        return isPageLoaded;
    }

    public void selectOrganizationByName( String organization ) {
        SMUtils.waitForElement( driver, organizationDropdown );
        String expanded_Status = SMUtils.getAttributeOfWebElement( organizationDropdown, driver, "aria-expanded" );
        if ( expanded_Status.equals( "false" ) ) {
            SMUtils.clickJS( driver, organizationDropdown );
            Log.message( "The Organization drop down is expanded" );
        } else {
            Log.message( "The Organization drop down is already expanded" );
        }
        SMUtils.nap( 30 );

        Log.message( SMUtils.getAllTextFromWebElementList( dropdownSelectorForOrgNew ).toString() );
        dropdownSelectorForOrgNew.stream().filter( eachElement -> eachElement.getText().trim().equalsIgnoreCase( organization ) ).findFirst().ifPresent( eachElement -> {
            SMUtils.clickJS( driver, eachElement );
            Log.message( "The Organization " + organization + " is selected" );
        } );
    }

    /***
     * This method verified the column header is displayed
     * 
     * @author balaji.chandra
     * @return boolean
     */
    public boolean verifyColumnHeadersdisplayed() {
        SMUtils.fluentWaitForElement( driver, tableContainer );
        return columnHeaderList.stream().allMatch( eachElement -> {
            if ( eachElement.isDisplayed() ) {
                Log.message( "The Column Header " + eachElement.getText() + " is displayed" );
                return true;
            } else {
                return false;
            }
        } );
    }

    /***
     * This method verified the header is displayed
     * 
     * @author pooja.perumal
     * @return boolean
     */
    public boolean verifyHeaderisdisplayed() {
        SMUtils.waitForElement( driver, headerLabel );
        return ( header ).stream().allMatch( eachElement -> {
            if ( eachElement.isDisplayed() ) {
                Log.message( "The Column Header " + eachElement.getText() + " is displayed" );
                return true;
            } else {
                return false;
            }
        } );
    }

    /***
     * This method retrieves retrieves the total count of Deleted courses as
     * Webelement
     * 
     * @author balaji.chandra
     * @return String
     */
    public String getTotalCountInPagination() {
        SMUtils.waitForElement( driver, pageCountRoot );
        Log.message( "Retrieving the Total Page count from the Audit history page" );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElement( driver, pageCountRoot, pageCountChild ), driver );
    }

    /***
     * This method retrieves the total count in pagination
     * 
     * @author balaji.chandra
     * @return int
     */
    public int getTotalCountInPaginationNumber() {
        Log.message( "Total Count of assignments " + Integer.parseInt( getTotalCountInPagination().split( "of" )[1].trim() ) );
        Log.message( "Retrieving the Page Count in Pagination" );
        return Integer.parseInt( getTotalCountInPagination().split( "of" )[1].trim() );
    }

    /***
     * This method verifies the page format is displayed as expected
     * 
     * @author balaji.chandra
     * @return boolean
     */
    public boolean verifyNumberOfPagesFormat() {
        int count = Integer.parseInt( getTotalCountInPagination().split( "of" )[1].trim() );
        String pageFormat;
        if ( count > 100 ) {
            if ( count % 100 == 0 ) {
                count /= 100;
                pageFormat = "Page 1 of " + count;
            } else {
                count /= 100;
                pageFormat = "Page 1 of " + ( count + 1 );
            }

        } else {
            pageFormat = "Page 1 of 1";
        }
        Log.message( "Verifing the total number of pages in audit history page" );
        return pageFormat.equals( SMUtils.getWebElement( driver, pageCountRoot, pagesFormat ).getText().trim() );
    }

    /***
     * This method verifies the page count is displayed
     * 
     * @author balaji.chandra
     * @return boolean
     */
    public boolean verifypageCountisDisplayed() {
        SMUtils.waitForElement( driver, pageCountRoot );
        Log.message( "Verifying the Page count is displayed" );
        return SMUtils.getWebElement( driver, pageCountRoot, pageCountChild ).isDisplayed();
    }

    /***
     * This method verifies the page count format is displayed as expected
     * 
     * @author balaji.chandra
     * @return boolean
     */
    public boolean verifyPageCountFormat() {
        int count = getTotalCountInPaginationNumber();
        Log.message( "Verifying the page count format in audit history page" );
        if ( count > 100 ) {
            return getTotalCountInPagination().trim().equals( "1-100 of " + count );
        } else {
            return getTotalCountInPagination().trim().equals( "1-" + count + " of " + count );
        }
    }

    /***
     * This method retrieves a particular columns value
     * 
     * @param header -> Column name {@link AUDIT_HISTORY_TABLE_HEADER}
     * @return List<String>
     */
    public List<String> getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER header ) {
        List<String> allValues = new ArrayList<>();

        BooleanSupplier isNextPagePresent = () -> {
            if ( verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "false" ) ) {
                clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT );
                return true;
            }
            return false;
        };

        Log.message( "Getting all the Audit History Logs" );
        do {
            SMUtils.waitForElement( driver, pageCountRoot );
            allValues.addAll( SMUtils.getAllTextFromWebElementList( driver.findElements( By.xpath( "//table/tbody/tr/td[" + ( header.ordinal() + 1 ) + "]" ) ) ) );
        } while ( isNextPagePresent.getAsBoolean() );

        if ( SMUtils.getAttributeOfWebElement( SMUtils.getWebElement( driver, pageCountRoot, firstButtonChild ), driver, "aria-disabled" ).equals( "false" ) )
            clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST );
        Log.message( "Navigated to firstPage" );
        return allValues;
    }

    /***
     * This method retrieves the disabled status of Navigation in pagination as
     * true or false
     * 
     * @param buttons -> {@link AUDIT_HISTORY_NAVIGATION_BUTTONS}
     * @return String -> "true", "false"
     */
    public String verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS buttons ) {
        SMUtils.waitForElement( driver, pageCountRoot );
        Log.message( "Verifying the Navigation button is disabled or not" );
        List<WebElement> allButtons = SMUtils.getAllWebElements( driver, pageCountRoot, navigationButtonsChild );
        return SMUtils.getAttributeOfWebElement( allButtons.get( buttons.ordinal() ), driver, "aria-disabled" );
    }

    /***
     * This method clicks Navigation in pagination as true or false
     * 
     * @param buttons -> {@link AUDIT_HISTORY_NAVIGATION_BUTTONS}
     */
    public void clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS buttons ) {
        SMUtils.waitForElement( driver, pageCountRoot );
        Log.message( "Click on the Navigation Button" + buttons );
        List<WebElement> allButtons = SMUtils.getAllWebElements( driver, pageCountRoot, navigationButtonsChild );
        SMUtils.clickJS( driver, allButtons.get( buttons.ordinal() ) );
    }

    /***
     * This method clicks table header for sorting
     * 
     * @param header -> {@link AUDIT_HISTORY_TABLE_HEADER}
     * @throws InterruptedException
     */
    public void clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER header ) throws InterruptedException {
        Thread.sleep( 2000 );
        SMUtils.waitForElement( driver, columnHeaderList.get( header.ordinal() ) );
        SMUtils.click( driver, columnHeaderList.get( header.ordinal() ) );
        Log.message( "The header " + columnHeaderList.get( header.ordinal() ).getText() + " is clicked" );
    }

    /***
     * This method clicks Audit Histroy table header for sorting
     * 
     * @author Satheesh.kumar
     * @param header -> Column Header
     * @throws InterruptedException
     */
    public void clickAuditHistoryColumnHeader( String header ) throws InterruptedException {
        SMUtils.fluentWaitForElement( driver, tableContainer );
        for ( WebElement headerElement : columnHeaderList1 ) {
            String textOfHeaderElement = headerElement.getText().trim();
            Log.message( "Text of header : " + textOfHeaderElement );
            if ( textOfHeaderElement.equals( header ) ) {
                SMUtils.click( driver, headerElement );
                Log.message( "Clicked on column header : " + header );
            }
        }

    }

    /***
     * This method retrieves the current page number in the Audit history page
     * 
     * @author balaji.chandra
     * @return int
     */
    public int getCurrentPageNumber() {
        String pages = SMUtils.getWebElement( driver, pageCountRoot, pagesFormat ).getText().trim();
        String currentPageCount = pages.split( "of" )[0].trim().replaceAll( "[a-zA-Z]", "" );
        Log.message( "Retrieving the Current Page Number" );
        return Integer.parseInt( currentPageCount.trim() );
    }

    /***
     * This method retrieves the total number of pages displayed in the Audit
     * history page
     * 
     * @author balaji.chandra
     * @return int
     */
    public int getAllPageNumber() {
        String pages = SMUtils.getWebElement( driver, pageCountRoot, pagesFormat ).getText().trim();
        String allPageCount = pages.split( "of" )[1].trim().replaceAll( "[a-zA-Z]", "" );
        Log.message( "Retrieving the total number of Pages available" );
        return Integer.parseInt( allPageCount.trim() );
    }

    public Map<String, Map<String, String>> getRowValues() {

        Map<String, Map<String, String>> rv = new HashMap<>();
        SMUtils.nap( 10 ); // wait is required for data to be loaded
        Log.message( rowValues + "" );
        rowValues.stream().forEach( parentElement -> {
            Map<String, String> row = new HashMap<>();
            row.put( "deletedBy", parentElement.findElement( By.cssSelector( String.format( columnvalues, 1 ) ) ).getText().trim() );
            row.put( "assignmentTitle", parentElement.findElement( By.cssSelector( String.format( columnvalues, 2 ) ) ).getText().trim() );
            row.put( "studentOrGroupName", parentElement.findElement( By.cssSelector( String.format( columnvalues, 3 ) ) ).getText().trim() );
            row.put( "recordType", parentElement.findElement( By.cssSelector( String.format( columnvalues, 4 ) ) ).getText().trim().toUpperCase() );
            row.put( "assignedBy", parentElement.findElement( By.cssSelector( String.format( columnvalues, 5 ) ) ).getText().trim() );
            row.put( "courseName", parentElement.findElement( By.cssSelector( String.format( columnvalues, 6 ) ) ).getText().trim() );
            rv.put( parentElement.findElement( By.cssSelector( String.format( columnvalues, 2 ) ) ).getText().trim(), row );

        } );
        return rv;

    }

    /***
     * This method verifies the organization list is present in the audit
     * history page
     * 
     * @author pooja.perumal
     * @return boolean
     */
    public boolean verifyOrganizationListDisplayed() {
        SMUtils.waitForElement( driver, organizationList );
        Log.message( "Verifying the Organizations list is displayed in the Audit History Page" );
        return organizationList.isDisplayed();

    }

    public List<String> convertToLowerCase( List<String> listToBeConvertedToLowerCase ) {
        List<String> finalList = new ArrayList<>();
        listToBeConvertedToLowerCase.forEach( element -> finalList.add( element.toLowerCase() ) );
        return finalList;
    }

    public boolean sizeofListElement( List<String> orgNames ) {
        boolean status = false;
        Set<Boolean> statusList = new HashSet<>();
        orgNames.forEach( element -> {
            if ( element.length() > 50 ) {
                statusList.add( true );
            } else {
                statusList.add( false );
            }
        } );

        List<Boolean> list = new ArrayList<>( statusList );
        if ( list.size() == 1 && Boolean.FALSE.equals( list.get( 0 ) ) ) {
            status = false;
        }
        return status;
    }

    /***
     * This method verifies the deleted assignment list is present in the audit
     * history page
     * 
     * @author pooja.perumal
     * @return boolean
     */
    public boolean verifyDeletedAssignmentListDisplayed() {
        SMUtils.waitForElement( driver, assignmentList );
        Log.message( "Verifying the deleted assignments list is displayed in the Audit History Page" );
        return assignmentList.isDisplayed();

    }

    /**
     * verify deleted assignment
     * 
     * @param valuesFromUI
     * @param response
     * @return
     */
    public boolean verifyDeletedAssignmentsAreDisplayed( Map<String, Map<String, String>> valuesFromUI, Response response ) {
        Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();
        IntStream.range( 0, SMUtils.getWordCount( response.getBody().asString(), "assignmentTitle" ) ).forEach( iter -> {
            Map<String, String> deletedAssignments = new HashMap<>();
            String rspn = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
            JSONObject jsonObj = new JSONObject( rspn );
            JSONArray ja = jsonObj.getJSONArray( "getAssignmentAudits" );
            JSONObject jObj = ja.getJSONObject( iter );
            deletedAssignments.put( "deletedBy", jObj.get( "deletedBy" ).toString() );
            deletedAssignments.put( "assignmentTitle", jObj.get( "assignmentTitle" ).toString() );
            deletedAssignments.put( "studentOrGroupName", jObj.get( "studentOrGroupName" ).toString() );
            deletedAssignments.put( "recordType", jObj.get( "recordType" ).toString().toUpperCase() );
            deletedAssignments.put( "assignedBy", jObj.get( "assignedBy" ).toString() );
            deletedAssignments.put( "courseName", jObj.get( "courseName" ).toString() );
            getAuditHistoryAssignment.put( Integer.toString( iter ), deletedAssignments );
        } );
        return valuesFromUI.entrySet().stream().allMatch( entry -> getAuditHistoryAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );
    }

    /**
     * organization drop down
     * 
     * @param organizationName
     * @return
     */
    public boolean clickOrganizationDropdownUsingCount( String organizationName ) {
        SMUtils.waitForElement( driver, organizationDropdown );
        String expanded_Status = SMUtils.getAttributeOfWebElement( organizationDropdown, driver, "aria-expanded" );
        if ( expanded_Status.equals( "false" ) ) {
            SMUtils.clickJS( driver, organizationDropdown );
            Log.message( "The Organization drop down is expanded" );
        } else {
            Log.message( "The Organization drop down is already expanded" );
        }
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 30 ) );
        wait.until( ExpectedConditions.presenceOfElementLocated( By.cssSelector( "ul[class='dropdown-select-options sc-cel-dropdown-select'] li" ) ) );
        WebElement targetvalue = driver.findElement( By.xpath( "//span[contains(text(),'" + organizationName + "')] " ) );
        targetvalue.click();
        return true;
    }

    /**
     * To verify whether left navigation bar is selected or not
     * 
     * @param leftNavName
     * @return
     */
    public boolean isLeftNavSelected( SubNavigations leftNavName ) {
        try {
            SMUtils.waitForElement( driver, selectedSideNavBar );
            selectedSideNavBar.getText().trim().equals( leftNavName );
            Log.message( leftNavName + " is selected in left navigation" );
            return true;

        } catch ( Exception e ) {
            Log.message( "The Sub Navigation is not clicked" );
            return false;
        }
    }
}
