package com.savvas.sm.admin.ui.tests;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.MSDASettingsPopupPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SettingPage;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class MSDASettingsPopupAPI_Integration_Test extends EnvProperties {

    private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String districtAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String savvasAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;
    private String districtId = null;
    public static String subDistrictwithSchool_name = null;
    public static String subDistrictOrgId_with_school = null;

    private String userName;
    public static String userId;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String subdistrictWithoutOrgUserID;
    String subdistrictWithoutOrgUsername;
    String subDistrictwithoutOrgId;
    String schoolID;
    String singleSchoolAdminUserID;
    String singleSchoolAdminUsername;
    String singleSchoolAdminOrgId;
    String multiSchoolAdminUserID;
    String multiSchoolAdminUsername;
    String multiSchoolAdminOrgId;
    String savvasAdminUserID;
    String savvasAdminUsername;
    String savvasAdminOrgId;
    public RBSUtils rbsUtils = new RBSUtils();
    
    private String savvasAdminToken = null;
    private String subdistrictWithoutOrgAdminToken = null;
    private String subdistrictWithoutOrgAdminDetails = null;

    public String subDistrictwithoutSchool_name = null;
    public String subDistrictOrgId_without_school = null;
    public String school_under_subDistrictwithSchool_name = null;
    
    @BeforeClass(alwaysRun=true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );

        
      //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "00101" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        userName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        //Sub-District Admin
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "0081" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        subdistrictUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        subdistrictUserID = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
        subDistrictwithSchoolId = subDistrictOrgId_with_school;
        schoolID = rbsUtils.getOrganizationIDByName( subDistrictwithSchoolId, school_under_subDistrictwithSchool_name );

        // Getting sub district without school admin details
        subdistrictWithoutOrgAdminDetails = createAdminsClass.createSubDistrictAdminWithoutSchool( smUrl, subDistrictOrgId_without_school, "0081" );
        subdistrictWithoutOrgUserID = SMUtils.getKeyValueFromResponse( subdistrictWithoutOrgAdminDetails, RBSDataSetupConstants.USERID );
        subdistrictWithoutOrgUsername = SMUtils.getKeyValueFromResponse( subdistrictWithoutOrgAdminDetails, RBSDataSetupConstants.USERNAME );
        subDistrictwithoutOrgId = RBSDataSetup.subDistrictwithoutSchoolId;

        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "0081" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        singleSchoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
        singleSchoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
        singleSchoolAdminOrgId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" );

        //Multi-School Admin
        multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "0096" );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        multiSchoolAdminUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
        multiSchoolAdminUserID = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERID );
        multiSchoolAdminOrgId = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, "primaryOrgId" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );

        //Savvas Admin
        savvasAdminDetails = createAdminsClass.createSavvasAdmin( smUrl, districtId, "0081" );
        Log.message( "********" );
        Log.message( "savvasAdminDetails from Create Admins are " + savvasAdminDetails );
        Log.message( "********" );
        savvasAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        savvasAdminUsername = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        savvasAdminUserID = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        savvasAdminOrgId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );

    }

    @Test ( description = "Verify MSDA Setting Edit Popup Page for district admins", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup001: Verify MSDA Setting Edit Popup Page for district admins <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME);

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-26089: Verify district admin can navigate to Math Screener & Diagnostic Assessments popup from Settings" );
            Log.assertThat( popupPage.isMSDAEditPopupDisplayed(), "District customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings",
                    "District customer admin cannot navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.testCaseResult();


            SMUtils.logDescriptionTC( "SMK-26090: Verify district admin can do setting ON or OFF for MSDA and save the record" );
            popupPage.clickTurnAllOn();
            popupPage.clickTurnAllOFF();
            
            // Selecting value to turn on MSDA setting and saving
            popupPage.turnOnMSDAForGivenOrganziation( flexSchool );
            popupPage.clickSaveButton();

            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( flexSchool ), "The selection remains the same after saving the MSDA setting", "The selection is not remaining the same after saving the MSDA setting" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-26091: Verify sub district admin can see the MSDA settings set by district admin ", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup002: Verify sub district admin can see the MSDA settings set by district admin  <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-26091: Verify sub district admin can see the MSDA settings set by district admin " );

            // Getting list of organizations
            String schoolToBeselected = RBSDataSetup.SchoolUnderSubDistrict;
            
            // Selecting value to turn on MSDA setting and saving
            popupPage.turnOnMSDAForGivenOrganziation( schoolToBeselected );
            popupPage.clickSaveButton();
            
            driver.quit();
            
            // Login as sub district admin
            final WebDriver driver1 = WebDriverFactory.get( browser );
            username = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
            
            smLoginPage = new AdminLauncherPage( driver1, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            popupPage = new MSDASettingsPopupPage( driver1 );
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( schoolToBeselected ), "The organization is already selected by district admin is visible to sub district admin", "The organization is already selected by district admin is not visible to sub district admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "SMK-26092: Verify School admin can see the MSDA settings set by district admin ", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup003: Verify School admin can see the MSDA settings set by district admin  <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-26092:Verify School admin can see the MSDA settings set by district admin  " );

            // Getting list of organizations
            String schoolToBeselected = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

            // Selecting value to turn on MSDA setting and saving
            popupPage.turnOnMSDAForGivenOrganziation( schoolToBeselected );
            popupPage.clickSaveButton();
            
            driver.quit();
            
            // Login as sub district admin
            final WebDriver driver1 = WebDriverFactory.get( browser );
            username = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
            
            smLoginPage = new AdminLauncherPage( driver1, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            popupPage = new MSDASettingsPopupPage( driver1 );
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( schoolToBeselected ), "The organization is already selected by district admin is visible to sub district admin", "The organization is already selected by district admin is not visible to sub district admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify district admin can set ON/OFF for all schools by clicking Turn All On/Turn All OFF and save the record.", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup004: Verify district admin can set ON/OFF for all schools by clicking Turn All On/Turn All OFF and save the record. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );
            popupPage.enterValuesInSearchBar( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26093: Verify district admin can set ON for all schools by clicking Turn All On and save the record." );

            // Selecting value to turn on MSDA setting and saving
            popupPage.clickTurnAllOFF();
            popupPage.clickTurnAllOn();
            popupPage.clickSaveButton();
            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.isTurnAllOnOffBtnPresent(), "Turn All off button is displayed after Turn All on Button", "Turn All off button is not displayed after Turn All on Button" );
            Log.assertThat( popupPage.getTurnAllToggleTxt().equals( "Turn All On" ), "Turn All Off Button is displayed", "Turn All Off Button is not displayed" );
            orgList.forEach( eachOrg -> {
                Log.assertThat( !popupPage.verifyMSDASettingForGivenOrganization( eachOrg ), "The Org "+eachOrg+" is selected after selecting Turn All Off", "The selection is not remaining the same after saving the MSDA setting" );
            });
            
            popupPage.clickCancelBtn();

            Log.testCaseResult();
            
            
            SMUtils.logDescriptionTC( "SMK-26094: Verify district admin can set OFF for all schools by clicking Turn All Off and save the record." );
            settingpage.clickEditButtn( SettingPage.MSDA );
         // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage1 = new MSDASettingsPopupPage( driver );

            popupPage.enterValuesInSearchBar( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            // Getting list of organizations
            List<String> orgList1 = popupPage1.getOrganizationNameList();


            // Selecting value to turn on MSDA setting and saving
            popupPage.clickTurnAllOFF();
            popupPage.clickSaveButton();
            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.getTurnAllToggleTxt().equals( "Turn All On" ), "Turn All On Button is displayed", "Turn All On Button is not displayed" );

            Log.assertThat( popupPage.isTurnAllOnOffBtnPresent(), "Turn All On button is displayed after Turn All ON Button", "Turn All On button is not displayed after Turn All On Button" );
           
            orgList1.forEach( eachOrg -> {
                Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( eachOrg ), "The Org "+eachOrg+" is selected after selecting Turn All On", "The selection is not remaining the same after saving the MSDA setting" );
            });
            
            popupPage.clickCancelBtn();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify sub district admin can set ON for all schools by clicking Turn All On and save the record.", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup005: Verify sub district admin can set ON for all schools by clicking Turn All On and save the record. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26095: Verify sub district admin can set ON for all schools by clicking Turn All On and save the record." );

            // Selecting value to turn on MSDA setting and saving
            popupPage.clickTurnAllOn();
            popupPage.clickSaveButton();
            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.isTurnAllOnOffBtnPresent(), "Turn All off button is displayed after Turn All on Button", "Turn All off button is not displayed after Turn All on Button" );
            
            orgList.forEach( eachOrg -> {
                Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( eachOrg ), "The Org "+eachOrg+" is selected after selecting Turn All On", "The selection is not remaining the same after saving the MSDA setting" );
            });
            
            popupPage.clickCancelBtn();

            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify school admin can set ON for all schools by clicking Turn All On and save the record.", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup006: Verify school admin can set ON for all schools by clicking Turn All On and save the record. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26096: Verify school admin can set ON for all schools by clicking Turn All On and save the record." );


            // Selecting value to turn on MSDA setting and saving
            popupPage.clickTurnAllOn();
            popupPage.clickTurnAllOFF();
            popupPage.clickSaveButton();
            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.isTurnAllOnOffBtnPresent(), "Turn All off button is displayed after Turn All on Button", "Turn All off button is not displayed after Turn All on Button" );
            orgList.forEach( eachOrg -> {
                Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( eachOrg ), "The Org "+eachOrg+" is selected after selecting Turn All On", "The selection is not remaining the same after saving the MSDA setting" );
            });
            
            popupPage.clickCancelBtn();

            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify multiple school admin can set ON for all schools by clicking Turn All On and save the record.", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup006: Verify multiple school admin can set ON for all schools by clicking Turn All On and save the record. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "Verify multiple school admin can set ON for all schools by clicking Turn All On and save the record." );


            // Selecting value to turn on MSDA setting and saving
            popupPage.clickTurnAllOn();
            popupPage.clickSaveButton();
            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.isTurnAllOnOffBtnPresent(), "Turn All off button is displayed after Turn All on Button", "Turn All off button is not displayed after Turn All on Button" );
            orgList.forEach( eachOrg -> {
                Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( eachOrg ), "The Org "+eachOrg+" is selected after selecting Turn All On", "The selection is not remaining the same after saving the MSDA setting" );
            });
            
            popupPage.clickCancelBtn();

            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify district admin can set MSDA ON/OFF for one or more school", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup008: Verify district admin can set MSDA ON/OFF for one or more school <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26098: Verify district admin can set MSDA ON/OFF for one or more school" );
            popupPage.turnOffMSDAForAllOrganization();
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 0 ) );
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 1 ) );
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );
            
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( orgList.get( 0 ) )&& popupPage.verifyMSDASettingForGivenOrganization( orgList.get( 1 ) ), "One or more schools are selected", "The organization is already selected by district admin is not visible to sub district admin" );
            
            
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify sub district admin can set MSDA ON/OFF for one or more school ", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup009: Verify sub district admin can set MSDA ON/OFF for one or more school  <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26099: Verify sub district admin can set MSDA ON/OFF for one or more school " );
            popupPage.turnOffMSDAForAllOrganization();
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 0 ) );
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 1 ) );
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );
            
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( orgList.get( 0 ) )&& popupPage.verifyMSDASettingForGivenOrganization( orgList.get( 1 ) ), "One or more schools are selected", "The organization is already selected by district admin is not visible to sub district admin" );
            
            
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify school admin can set MSDA ON/OFF for one or more school  ", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup0010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup0010: Verify school admin can set MSDA ON/OFF for one or more school  <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26100: Verify school admin can set MSDA ON/OFF for one or more school" );
            popupPage.turnOffMSDAForAllOrganization();
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 0 ) );
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );
            
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( orgList.get( 0 ) ), "One or more schools are selected", "The organization is already selected by district admin is not visible to sub district admin" );
            
            
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify multiple school admin can set MSDA ON/OFF for one or more school", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup0011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup0011: Verify multiple school admin can set MSDA ON/OFF for one or more school <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );


            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26101: Verify multiple school admin can set MSDA ON/OFF for one or more school" );
            popupPage.turnOffMSDAForAllOrganization();
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 0 ) );
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );
            
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( orgList.get( 0 ) ), "One or more schools are selected", "The organization is already selected by district admin is not visible to Multiple School Admin" );
            
            
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( enabled = false, description = "Verify 'Turn All On' should display in disable mode when org search returns empty records", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup0012() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup0012: Verify 'Turn All On' should display in disable mode when org search returns empty records <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-26102: Verify 'Turn All On' should display in disable mode when org search returns empty records" );
            popupPage.turnOnMSDAForAllOrganization();
            popupPage.enterValuesInSearchBar( "Invalid Search Organisation" );
            Log.assertThat( !popupPage.isTurnAllOnOffButtonEnabled(), "Turn All On Button is disabled", "Turn All On Button is enabled" );
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Turn All Off' button should display to respective school search in search bar, when admin search any school and click 'Turn All On' button and save.", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup0013() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup0013: Verify 'Turn All Off' button should display to respective school search in search bar, when admin search any school and click 'Turn All On' button and save. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );
            
            popupPage.clickTurnAllOFF();
            popupPage.clickTurnAllOn();

            SMUtils.logDescriptionTC( "SMK-26103: Verify 'Turn All Off' button should display to respective school search in search bar, when admin search any school and click 'Turn All On' button and save." );
            popupPage.enterValuesInSearchBar( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            popupPage.clickTurnAllOFF();
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage1 = new MSDASettingsPopupPage( driver );
            popupPage1.enterValuesInSearchBar( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            Log.assertThat( popupPage1.getTurnAllToggleTxt().equals( "Turn All Off" ), "Turn All Off is displayed when the org is already turned on", "Turn All Off is not displayed when the org is already turned on" );
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Turn All On' button should display ,when admin search any school and click 'Turn All On' button and save.", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup0014() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup0014: Verify 'Turn All On' button should display ,when admin search any school and click 'Turn All On' button and save. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );
            
         // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-26104: Verify 'Turn All On' button should display ,when admin search any school and click 'Turn All On' button and save." );
            popupPage.enterValuesInSearchBar( orgList.get( orgList.size()-2 ) );
            popupPage.clickTurnAllOn();
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage1 = new MSDASettingsPopupPage( driver );
            Log.assertThat( popupPage1.getTurnAllToggleTxt().equals( "Turn All On" ), "Turn All On is displayed when no org is searched", "Turn All On is not displayed when no search is done" );
            Log.testCaseResult();
            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Turn All On/Off' button make changes for filtered organizations", groups = { "SMK-51926", "AdminDashboard", "MSDASettingEditPopup","smoke_test_case" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup0015() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMMSDAEditPopup0015: Verify 'Turn All On/Off' button make changes for filtered organizations <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );
            
         

            SMUtils.logDescriptionTC( "SMK-26105: Verify filtered organizations alone set as MSDA ON when admin search few orgs and click on Turn All On button" );
            popupPage.clickTurnAllOFF();
            popupPage.clickTurnAllOn();
            
            popupPage.enterValuesInSearchBar( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            popupPage.clickTurnAllOFF();
            popupPage.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );

            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage1 = new MSDASettingsPopupPage( driver );
            Log.assertThat( popupPage1.verifyMSDASettingForGivenOrganization( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL )), "The searched and selected org is turned on", "The searched and selected org is turned off" );
            Log.assertThat( popupPage1.getTurnAllToggleTxt().equals( "Turn All On" ), "Turn All On is displayed when no org is searched", "Turn All On is not displayed when no search is done" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "SMK-26106: Verify filtered organizations alone set as MSDA OFF when admin search few orgs and click on Turn All Off button" );
            popupPage1.enterValuesInSearchBar( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            popupPage1.clickTurnAllOn();
            popupPage1.clickSaveButton();
            
            settingpage.clickEditButtn( SettingPage.MSDA );
         // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage2 = new MSDASettingsPopupPage( driver );
            Log.assertThat( !popupPage2.verifyMSDASettingForGivenOrganization( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL )), "The searched and selected org is turned off", "The searched and selected org is turned on" );
            Log.assertThat( popupPage2.getTurnAllToggleTxt().equals( "Turn All On" ), "Turn All On is displayed when no org is searched", "Turn All On is not displayed when no search is done" );
            Log.testCaseResult();
            
            Log.testCaseResult();

            
           

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    
    
    
}