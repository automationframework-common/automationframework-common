package com.savvas.sm.admin.bff.tests;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;

import io.restassured.response.Response;

public class OrganizationPerformanceThisWeekBFFTest extends EnvProperties {

    private String smUrl;
    private String orgId;
    private String flexSchool;
    private String mathSchool;
    
    private Response OrgPerformanceThisWeekReportBFFResponse;    

    String mathSchoolTeacherDetails = null;
    private String districtAdminUsername;
    private String distAdminuserId;
    private String schoolAdminUsername;
    private String schoolAdminuserId;
    private String subDistrictAdminUsername;
    private String subDistrictAdminuserId;

    //Admin creation    
    private String districtAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String schoolAdminDetails = null;

    //===Details
    public String subDistrictwithoutSchool_name = null;
    public String subDistrictwithSchool_name = null;
    public String subDistrictOrgId_with_school = null;
    public String subDistrictOrgId_without_school = null;
    public String school_under_subDistrictwithSchool_name = null;

    private String districtId = null;
    public String url = null;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        url = configProperty.getProperty( "AdminDashboardBFF" )+"/graphql";

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );

        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
        school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );

        CreateAdmins createAdminsClass = new CreateAdmins();
        
        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "00104" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminUsername = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        distAdminuserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );
        
        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "0006" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
        schoolAdminuserId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
        
        //Sub-District Admin
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "0057" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subDistrictAdminUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        subDistrictAdminuserId = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
        
//        selectedSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
    }

    /**
     * This method is used to test the Performance report API.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "performanceReportBFFpositiveScenario", groups = { "OrganizationPerformanceThisWeekReport", "SMK-69943", "P1", "API" }, alwaysRun = true )
    public void performanceReportBFFPositiveTest( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );
        
        Dashboard dashboard = new Dashboard();

        Map<String, String> headers = new HashMap<>();
        String organizationIds = RBSDataSetup.organizationIDs.get( flexSchool )+","+RBSDataSetup.organizationIDs.get( mathSchool );
        Map<String, Object> payload = dashboard.getJsonMapFromFile( "getOPTWReportGraphQL.json" );
        HashMap<String, String> weekTracker = getWeekTrackerDays();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        
        switch ( scenario ) {
            case "DISTRICT_ADMIN":
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( districtAdminUsername, password ) );
            	headers.put( Constants.ORGID_SM_HEADER, districtId );
            	headers.put( Constants.USERID_SM_HEADER, distAdminuserId );
            	payload = dashboard.replaceValue( payload,"variables.userId", distAdminuserId );
                payload = dashboard.replaceValue( payload,"variables.organizationId", districtId );
                payload = dashboard.replaceValue( payload,"variables.selectedOrg", RBSDataSetup.organizationIDs.get( flexSchool ) );
                payload = dashboard.replaceValue( payload,"variables.lastWeekEndDate", weekTracker.get("fourteenDays") );
                payload = dashboard.replaceValue( payload,"variables.lastWeekStartDate", weekTracker.get("lastWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekEndDate", weekTracker.get("currentWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekStartDate", weekTracker.get("lastWeek") );
                Log.message( "Payload: " + payload );
                OrgPerformanceThisWeekReportBFFResponse = RestAssuredAPIUtil.POST( url, headers, dashboard.convertMapToJson( payload ) );
                Log.message( OrgPerformanceThisWeekReportBFFResponse.getBody().asString() );
                break;
            case "ZERO_STATE":
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( districtAdminUsername, password ) );
            	headers.put( Constants.ORGID_SM_HEADER, districtId );
            	headers.put( Constants.USERID_SM_HEADER, distAdminuserId );
                payload = dashboard.replaceValue( payload,"variables.userId", distAdminuserId );
                payload = dashboard.replaceValue( payload,"variables.organizationId", districtId );
                payload = dashboard.replaceValue( payload,"variables.selectedOrg", "8a7205488260d4d8018262e1ac7a0012" );
                payload = dashboard.replaceValue( payload,"variables.lastWeekEndDate", weekTracker.get("fourteenDays") );
                payload = dashboard.replaceValue( payload,"variables.lastWeekStartDate", weekTracker.get("lastWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekEndDate", weekTracker.get("currentWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekStartDate", weekTracker.get("lastWeek") );
                Log.message( "Payload: " + payload );
                OrgPerformanceThisWeekReportBFFResponse = RestAssuredAPIUtil.POST( url, headers, dashboard.convertMapToJson( payload ) );
                Log.message( OrgPerformanceThisWeekReportBFFResponse.getBody().asString() );
                break;
            case "MULTI_ORG":
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( districtAdminUsername, password ) );
            	headers.put( Constants.ORGID_SM_HEADER, districtId );
            	headers.put( Constants.USERID_SM_HEADER, distAdminuserId );
            	payload = dashboard.replaceValue( payload,"variables.userId", distAdminuserId );
                payload = dashboard.replaceValue( payload,"variables.organizationId", districtId );
                payload = dashboard.replaceValue( payload,"variables.selectedOrg", organizationIds );
                payload = dashboard.replaceValue( payload,"variables.lastWeekEndDate", weekTracker.get("fourteenDays") );
                payload = dashboard.replaceValue( payload,"variables.lastWeekStartDate", weekTracker.get("lastWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekEndDate", weekTracker.get("currentWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekStartDate", weekTracker.get("lastWeek") );
                Log.message( "Payload: " + payload );
                OrgPerformanceThisWeekReportBFFResponse = RestAssuredAPIUtil.POST( url, headers, dashboard.convertMapToJson( payload ) );
                Log.message( OrgPerformanceThisWeekReportBFFResponse.getBody().asString() );
                break;
            case "SCHOOL_ADMIN":
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( schoolAdminUsername, password ) );
            	headers.put( Constants.ORGID_SM_HEADER, orgId );
            	headers.put( Constants.USERID_SM_HEADER, schoolAdminuserId );
            	payload = dashboard.replaceValue( payload,"variables.userId", schoolAdminuserId );
                payload = dashboard.replaceValue( payload,"variables.organizationId", orgId );
                payload = dashboard.replaceValue( payload,"variables.selectedOrg", RBSDataSetup.organizationIDs.get( flexSchool ) );
                payload = dashboard.replaceValue( payload,"variables.lastWeekEndDate", weekTracker.get("fourteenDays") );
                payload = dashboard.replaceValue( payload,"variables.lastWeekStartDate", weekTracker.get("lastWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekEndDate", weekTracker.get("currentWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekStartDate", weekTracker.get("lastWeek") );
                Log.message( "Payload: " + payload );
                OrgPerformanceThisWeekReportBFFResponse = RestAssuredAPIUtil.POST( url, headers, dashboard.convertMapToJson( payload ) );
                Log.message( OrgPerformanceThisWeekReportBFFResponse.getBody().asString() );
                break;
            case "SUBDISTRICT_ADMIN":
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subDistrictAdminUsername, password ) );
            	headers.put( Constants.ORGID_SM_HEADER, subDistrictOrgId_with_school );
            	headers.put( Constants.USERID_SM_HEADER, subDistrictAdminuserId );
            	payload = dashboard.replaceValue( payload,"variables.userId", subDistrictAdminuserId );
                payload = dashboard.replaceValue( payload,"variables.organizationId", subDistrictOrgId_with_school );
                payload = dashboard.replaceValue( payload,"variables.selectedOrg", organizationIds );
                payload = dashboard.replaceValue( payload,"variables.lastWeekEndDate", weekTracker.get("fourteenDays") );
                payload = dashboard.replaceValue( payload,"variables.lastWeekStartDate", weekTracker.get("lastWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekEndDate", weekTracker.get("currentWeek") );
                payload = dashboard.replaceValue( payload,"variables.thisWeekStartDate", weekTracker.get("lastWeek") );
                Log.message( "Payload: " + payload );
                OrgPerformanceThisWeekReportBFFResponse = RestAssuredAPIUtil.POST( url, headers, dashboard.convertMapToJson( payload ) );
                Log.message( OrgPerformanceThisWeekReportBFFResponse.getBody().asString() );
                break;
        }
            
        Log.message( OrgPerformanceThisWeekReportBFFResponse.getBody().asString() );

        // Verifying Status code
        Log.assertThat( OrgPerformanceThisWeekReportBFFResponse.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + OrgPerformanceThisWeekReportBFFResponse.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + OrgPerformanceThisWeekReportBFFResponse.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenario.contains( "ZERO_STATE" ) ) {
        	//Schema Validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getZeroDataOPTWReportResponseSchema", statusCode, OrgPerformanceThisWeekReportBFFResponse.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
            Log.assertThat(OrgPerformanceThisWeekReportBFFResponse.getBody().asString().contains("Data not found"), "Zero State message dispalyed as expected", "Zero State message is not dispalyed" );
            
        } else {
        	//Schema Validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getOPTWReportResponseSchema", statusCode, OrgPerformanceThisWeekReportBFFResponse.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
            }
    }

    @DataProvider ( name = "performanceReportBFFpositiveScenario" )
    public Object[][] performanceReportBFFpositiveScenario() {

        Object[][] inputData = {
                { "tc_OrgPerformanceThisWeekReportBFF001", "Verify the organization performance this week widget header", "DISTRICT_ADMIN",
                        CommonAPIConstants.STATUS_CODE_OK },
                { "tc_OrgPerformanceThisWeekReportBFF002", "Verify Organizations listed in organization performance this week if user selected single organization in organization dropdown", "MULTI_ORG",
                            CommonAPIConstants.STATUS_CODE_OK },
                { "tc_OrgPerformanceThisWeekReportBFF003", "Verify Organization performance for this week will be accessible for school admin", "SCHOOL_ADMIN",
                                CommonAPIConstants.STATUS_CODE_OK },
                { "tc_OrgPerformanceThisWeekReportBFF004", "Verify the zero state for organization performance this week.", "ZERO_STATE",
                            CommonAPIConstants.STATUS_CODE_OK },
                { "tc_OrgPerformanceThisWeekReportBFF005", "Verify Organization performance for this week will be accessible for subdistrict admin", "SUBDISTRICT_ADMIN",
                                CommonAPIConstants.STATUS_CODE_OK }
                };
        return inputData;
    }
	
	 public HashMap<String, String> getWeekTrackerDays(){
	    	HashMap<String, String> weekTracker = new HashMap<String, String>();
	    	// Get calendar set to current date and time
	        Calendar c = GregorianCalendar.getInstance();
	        DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

	        String currentWeek = df.format(c.getTime());
	        Log.message("cw: "+ currentWeek);
	        weekTracker.put("currentWeek", currentWeek);

	        c.add(Calendar.DATE, -7);        
	        String thisWeekEndDate = df.format(c.getTime());        
	        weekTracker.put("lastWeek", thisWeekEndDate);        

	        c.add(Calendar.DATE, -7);
	        String lastWeekEndDate = df.format(c.getTime());
	        weekTracker.put("fourteenDays", lastWeekEndDate);

	        return weekTracker;
	    }

}
