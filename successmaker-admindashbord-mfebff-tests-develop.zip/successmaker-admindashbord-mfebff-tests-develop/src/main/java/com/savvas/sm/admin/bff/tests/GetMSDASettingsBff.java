package com.savvas.sm.admin.bff.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.settings.MSDASettingsBFF;
import com.savvas.sm.data.CreateAdmins;

import io.restassured.response.Response;

public class GetMSDASettingsBff {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String districtId;
    public static String teacherId;
    public static String userName;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public static String userId;
    public static String accessToken;
    //public static String orgId;
    public static String orgList;
    private Response response;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String studentDetails;
    String studentUsername;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String subdistrictWithoutOrgUserID;
    String subdistrictWithoutOrgUsername;
    String subDistrictwithoutOrgId;
    String schoolID;
    String singleSchoolAdminUserID;
    String singleSchoolAdminUsername;
    String singleSchoolAdminOrgId;
    String multiSchoolAdminUserID;
    String multiSchoolAdminUsername;
    String multiSchoolAdminOrgId;
    String savvasAdminUserID;
    String savvasAdminUsername;
    String savvasAdminOrgId;
    private String flexSchool;
    private String orgId;

    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String savvasAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;
    private String subdistrictWithoutOrgAdminDetails = null;

    //Tokens
    private String savvasAdminToken = null;
    private String districtAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;
    private String subdistrictWithoutOrgAdminToken = null;
    
    //===Details
    public String subDistrictwithoutSchool_name = null;
    public String subDistrictwithSchool_name = null;
    public String subDistrictOrgId_with_school = null;
    public String subDistrictOrgId_without_school = null;
    public String school_under_subDistrictwithSchool_name = null;

    MSDASettingsBFF msdaBff = new MSDASettingsBFF();

    // Org list query
    List<String> queryItems = Arrays.asList( AdminAPIConstants.ORGANIZATION_ID, AdminAPIConstants.ORGANIZATION_NAME );

    @BeforeClass ( alwaysRun = true )
    public void beforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        
        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
        school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );


        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "00101" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        userName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        //Sub-District Admin
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "0081" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        subdistrictUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        subdistrictUserID = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
        subDistrictwithSchoolId = subDistrictOrgId_with_school;
        schoolID = rbsUtils.getOrganizationIDByName( subDistrictwithSchoolId, school_under_subDistrictwithSchool_name );

        // Getting sub district without school admin details
        subdistrictWithoutOrgAdminDetails = createAdminsClass.createSubDistrictAdminWithoutSchool( smUrl, subDistrictOrgId_without_school, "0081" );
        subdistrictWithoutOrgUserID = SMUtils.getKeyValueFromResponse( subdistrictWithoutOrgAdminDetails, RBSDataSetupConstants.USERID );
        subdistrictWithoutOrgUsername = SMUtils.getKeyValueFromResponse( subdistrictWithoutOrgAdminDetails, RBSDataSetupConstants.USERNAME );
        subDistrictwithoutOrgId = RBSDataSetup.subDistrictwithoutSchoolId;

        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "0081" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        singleSchoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
        singleSchoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
        singleSchoolAdminOrgId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" );

        //Multi-School Admin
        multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "0096" );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        multiSchoolAdminUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
        multiSchoolAdminUserID = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERID );
        multiSchoolAdminOrgId = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, "primaryOrgId" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );

        //Savvas Admin
        savvasAdminDetails = createAdminsClass.createSavvasAdmin( smUrl, districtId, "0081" );
        Log.message( "********" );
        Log.message( "savvasAdminDetails from Create Admins are " + savvasAdminDetails );
        Log.message( "********" );
        savvasAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        savvasAdminUsername = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        savvasAdminUserID = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        savvasAdminOrgId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );

    }

    @Test ( priority = 1, dataProvider = "positiveScenarioTestData", groups = { "MSDASettingsBFF", "SMK-51839", "P1", "API","smoke_test_case","positive_test_case" } )
    public void getMSDASettingsBFF_Positive( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcID + " : " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        HashMap<String, Map<String, String>> responseFromOrgService = new HashMap<>();

        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + districtAdminToken );
                response = msdaBff.getMSDASettingsBFF( headers, userId, districtId, "" );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN, districtAdminDetails );
                break;

            case "SINGLE_SCHOOL_ADMIN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + schoolAdminToken );
                response = msdaBff.getMSDASettingsBFF( headers, singleSchoolAdminUserID, singleSchoolAdminOrgId, "" );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.SCHOOL_ADMIN, schoolAdminDetails );
                break;

            case "MULTI_SCHOOL_ADMIN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + multiSchoolAdminToken );
                response = msdaBff.getMSDASettingsBFF( headers, multiSchoolAdminUserID, multiSchoolAdminOrgId, "" );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.MULTI_SCHOOL_ADMIN, multiSchoolAdminDetails );
                break;

            case "SUBDISTRICT_ADMIN":  	
                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + subDistrictAdminToken );
                response = msdaBff.getMSDASettingsBFF( headers, subdistrictUserID, subDistrictwithSchoolId, "" );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, subDistrictAdminDetails );
                break;

            case "MULTI_SUBDISTRICT_ADMIN":
                //Creating multiple subdistrict admin
                String mutipleSubDistrictAdmin = "mutipleSubDistrictAdmin" + System.nanoTime();
                HashMap<String, String> adminDetails = new HashMap<>();
                adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                adminDetails.put( RBSDataSetupConstants.USERNAME, mutipleSubDistrictAdmin );
                adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, RBSDataSetup.subDistrictwithoutSchool );
                adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.subDistrictwithoutSchoolId );
                adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );

                String subdistrictAdminId = "";
                try {
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    new RBSUtils().resetPassword( RBSDataSetup.subDistrictwithoutSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( mutipleSubDistrictAdmin ) );
                    subdistrictAdminId = new RBSUtils().getUserIDByUserName( mutipleSubDistrictAdmin );

                    List<String> orgIds = Arrays.asList( RBSDataSetup.subDistrictwithoutSchoolId, RBSDataSetup.subDistrictwithSchoolId );
                    new RBSUtils().updateUserOrgId( new RBSUtils().getUser( subdistrictAdminId ), RBSDataSetupConstants.ADMIN_ROLE, orgIds );
                    new RBSUtils().resetPassword( RBSDataSetup.subDistrictwithoutSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( mutipleSubDistrictAdmin ) );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( mutipleSubDistrictAdmin, password ) );
                response = msdaBff.getMSDASettingsBFF( headers, subdistrictAdminId, subDistrictwithSchoolId + "," + subDistrictwithoutOrgId, "" );
                break;

            case "isDiagnosticEnabled_TRUE_isAutoAssignEnabled_FALSE":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + schoolAdminToken );
                new RBSUtils().createOrgSettings( singleSchoolAdminOrgId, "true", "false" );
                response = msdaBff.getMSDASettingsBFF( headers, singleSchoolAdminUserID, singleSchoolAdminOrgId, "" );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.SCHOOL_ADMIN, schoolAdminDetails );
                break;

            case "isDiagnosticEnabled_FALSE_isAutoAssignEnabled_TRUE":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + schoolAdminToken );
                new RBSUtils().createOrgSettings( singleSchoolAdminOrgId, "false", "true" );
                response = msdaBff.getMSDASettingsBFF( headers, singleSchoolAdminUserID, singleSchoolAdminOrgId, "" );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.SCHOOL_ADMIN, schoolAdminDetails );
                break;

            case "Savvas_Admin":
                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                response = msdaBff.getMSDASettingsBFF( headers, savvasAdminUserID, savvasAdminOrgId, districtId );
                responseFromOrgService = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN, districtAdminDetails );
                break;

            default:
                break;
        }

        Log.message( scenario + " :- " + response.getBody().asString() );

        // Verifying status code
        String statusCode = String.valueOf( response.getStatusCode() );
        Log.assertThat( statusCode.equals( expResCode ), "The Status code is expected " + expResCode + " and actual " + statusCode + " Verified", "The Status code is expected " + expResCode + " and actual " + statusCode + "is not Verified" );

        // Data validation
        if ( !scenario.equals( "MULTI_SUBDISTRICT_ADMIN" ) ) {
            HashMap<String, Map<String, String>> orgDetailsFromBFF = getOrgSettingsFromResponse( response.getBody().asString() );
            Log.assertThat( responseFromOrgService.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), orgDetailsFromBFF.get( entry.getKey() ) ) ), "All the organization settings are fetched properly",
                    "All the organization settings are not fetched properly" );
            // Schema validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "MSDASettings", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

        }

        Log.testCaseResult();
    }

    @DataProvider ( name = "positiveScenarioTestData" )
    public Object[][] positiveScenarioTestData() {
        Object[][] data = { { "tcMSDASettingsBFF001", "Verify the getMSDAOrgList graphql query is returning all the organization details with orgSetting when district admin details are passed", "200", "DISTRICT_ADMIN" },
                { "tcMSDASettingsBFF002", "Verify the getMSDAOrgList graphql query is returning the organization details with orgSetting when single school admin details are passed", "200", "SINGLE_SCHOOL_ADMIN" },
                { "tcMSDASettingsBFF003", "Verify the getMSDAOrgList graphql query is returning the organization details with orgSetting when multi-school admin details are passed", "200", "MULTI_SCHOOL_ADMIN" },
                { "tcMSDASettingsBFF004", "Verify the getMSDAOrgList graphql query is returning the organization details with orgSetting when sub-district admin details are passed", "200", "SUBDISTRICT_ADMIN" },
                { "tcMSDASettingsBFF005", "Verify the getMSDAOrgList graphql query is returning the organization details with orgSetting when multiple sub-district admin details are passed", "200", "MULTI_SUBDISTRICT_ADMIN" },
                { "tcMSDASettingsBFF006", "Verify the getMSDAOrgList graphql query is returning the updated settings, If update the isDiagnosticEnabled as true and isAutoAssignEnabled as false for any one organization", "200",
                        "isDiagnosticEnabled_TRUE_isAutoAssignEnabled_FALSE" },
                { "tcMSDASettingsBFF007", "Verify the getMSDAOrgList graphql query is returning the organization details with orgSetting when multiple sub-district admin details are passed", "200", "isDiagnosticEnabled_FALSE_isAutoAssignEnabled_TRUE" },
                { "tcMSDASettingsBFF013", "Verify the getMSDAOrgList graphql query is returning all the organization details with orgSetting when savvas admin details are passed ", "200", "Savvas_Admin" } };
        return data;
    }

    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "MSDASettingsBFF", "SMK-51839", "P2", "API" } )
    public void getMSDASettingsBFF_Negative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + " : " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenarioType ) {
            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) + "invalid" );
                response = msdaBff.getMSDASettingsBFF( headers, userId, districtId, "" );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = msdaBff.getMSDASettingsBFF( headers, userId + "Invalid", districtId, "" );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = msdaBff.getMSDASettingsBFF( headers, userId, districtId + "Invalid", "" );
                break;

            case "EMPTY_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = msdaBff.getMSDASettingsBFF( headers, "", districtId, "" );
                break;

            case "EMPTY_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = msdaBff.getMSDASettingsBFF( headers, userId, "", "" );
                break;

            default:
                break;
        }

        // Verifying Status code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        // Verifying message from response
        if ( scenarioType.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.NOT_FOUND_404 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_USERID ), "Getting Invalid message for empty userId", "Not getting Invalid message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        }
        Log.testCaseResult();
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {

        return new Object[][] { { "tcMSDASettingsBFF008", "Verify '401: UnAuthorized' message in response when invalid Bearer token is given", CommonAPIConstants.STATUS_CODE_OK, "INVALID_BEARER_TOKEN" },
                { "tcMSDASettingsBFF009", "Verify '401: UnAuthorized'  and response when invalid userId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_USER_ID" },
                { "tcMSDASettingsBFF010", "Verify 400 status code and response when invalid organizationId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_ORG_ID" },
                { "tcMSDASettingsBFF011", "Verify the message in response when empty userId is given in the query", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_USER_ID" },
                { "tcMSDASettingsBFF012", "Verify the message in response when empty org-id is given in the query", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_ORG_ID" } };
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    public HashMap<String, Map<String, String>> getOrganizationIdsForAdmin( Admins admin, String adminDetails ) throws Exception {

        String orgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgId" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );
        Map<String, String> headers = new HashMap<>();
        //headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.ORGID, orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers );

        HashMap<String, Map<String, String>> organizationListFromAPI = new HashMap<>();

        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME ) ).forEach( iter -> {
            HashMap<String, String> organizationNameListFromAPI = new HashMap<>();
            organizationNameListFromAPI.put( AdminAPIConstants.ORGANIZATION_NAME, SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME, iter ) );
            organizationNameListFromAPI.put( AdminConstants.IS_DIAGNOSTIC_ENABLED, "false" );
            organizationNameListFromAPI.put( AdminConstants.IS_AUTO_ASSIGN_ENABLED, "false" );
            organizationListFromAPI.put( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_ID, iter ), organizationNameListFromAPI );
        } );
        HashMap<String, String> orgSettingResponse = new RBSUtils().getOrgSettings( new ArrayList<>( organizationListFromAPI.keySet() ) );

        if ( !orgSettingResponse.get( Constants.STATUS_CODE ).equals( "404" ) ) {
            JSONArray responseArray = new JSONArray( orgSettingResponse.get( Constants.REPORT_BODY ) );
            IntStream.range( 0, responseArray.length() ).forEach( itr -> {
                HashMap<String, String> orgSettings = new HashMap<>();
                if ( responseArray.get( itr ).toString().contains( AdminConstants.IS_DIAGNOSTIC_ENABLED ) ) {
                    orgSettings.put( AdminConstants.IS_DIAGNOSTIC_ENABLED, SMUtils.getKeyValueFromResponse( responseArray.get( itr ).toString(), "orgSettings," + AdminConstants.IS_DIAGNOSTIC_ENABLED ) );
                } else {
                    orgSettings.put( AdminConstants.IS_DIAGNOSTIC_ENABLED,
                            organizationListFromAPI.get( SMUtils.getKeyValueFromResponse( responseArray.get( itr ).toString(), AdminAPIConstants.ORGANIZATION_ID ) ).get( AdminConstants.IS_DIAGNOSTIC_ENABLED ) );
                }
                if ( responseArray.get( itr ).toString().contains( AdminConstants.IS_AUTO_ASSIGN_ENABLED ) ) {
                    orgSettings.put( AdminConstants.IS_AUTO_ASSIGN_ENABLED, SMUtils.getKeyValueFromResponse( responseArray.get( itr ).toString(), "orgSettings," + AdminConstants.IS_AUTO_ASSIGN_ENABLED ) );
                } else {
                    orgSettings.put( AdminConstants.IS_AUTO_ASSIGN_ENABLED,
                            organizationListFromAPI.get( SMUtils.getKeyValueFromResponse( responseArray.get( itr ).toString(), AdminAPIConstants.ORGANIZATION_ID ) ).get( AdminConstants.IS_AUTO_ASSIGN_ENABLED ) );
                }
                if ( orgSettings.get( AdminConstants.IS_DIAGNOSTIC_ENABLED ).trim().equals( "" ) ) {
                    orgSettings.put( AdminConstants.IS_DIAGNOSTIC_ENABLED, "false" );
                }
                if ( orgSettings.get( AdminConstants.IS_AUTO_ASSIGN_ENABLED ).trim().equals( "" ) ) {
                    orgSettings.put( AdminConstants.IS_AUTO_ASSIGN_ENABLED, "false" );
                }
                orgSettings.put( AdminAPIConstants.ORGANIZATION_NAME, organizationListFromAPI.get( SMUtils.getKeyValueFromResponse( responseArray.get( itr ).toString(), AdminAPIConstants.ORGANIZATION_ID ) ).get( AdminAPIConstants.ORGANIZATION_NAME ) );
                organizationListFromAPI.put( SMUtils.getKeyValueFromResponse( responseArray.get( itr ).toString(), AdminAPIConstants.ORGANIZATION_ID ), orgSettings );
            } );
        }
        return organizationListFromAPI;
    }

    public HashMap<String, Map<String, String>> getOrgSettingsFromResponse( String response ) {
        HashMap<String, Map<String, String>> orgSettingDetailsFromResponse = new HashMap<>();
        String reponseData = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, "data" ), "getMSDAOrgList" );
        IntStream.range( 0, SMUtils.getWordCount( reponseData, AdminAPIConstants.ORGANIZATION_ID ) ).forEach( iter -> {
            Map<String, String> orgSettingDetails = new HashMap<>();
            JSONArray ja = new JSONArray( reponseData );
            JSONObject jObj = ja.getJSONObject( iter );
            orgSettingDetails.put( AdminAPIConstants.ORGANIZATION_NAME, jObj.get( AdminAPIConstants.ORGANIZATION_NAME ).toString() );
            if ( jObj.toString().contains( AdminConstants.IS_DIAGNOSTIC_ENABLED ) ) {
                orgSettingDetails.put( AdminConstants.IS_DIAGNOSTIC_ENABLED, SMUtils.getKeyValueFromResponse( jObj.get( "orgSettings" ).toString(), AdminConstants.IS_DIAGNOSTIC_ENABLED ) );
            } else {
                orgSettingDetails.put( AdminConstants.IS_DIAGNOSTIC_ENABLED, "false" );
            }
            if ( jObj.toString().contains( AdminConstants.IS_AUTO_ASSIGN_ENABLED ) ) {
                orgSettingDetails.put( AdminConstants.IS_AUTO_ASSIGN_ENABLED, SMUtils.getKeyValueFromResponse( jObj.get( "orgSettings" ).toString(), AdminConstants.IS_AUTO_ASSIGN_ENABLED ) );
            } else {
                orgSettingDetails.put( AdminConstants.IS_AUTO_ASSIGN_ENABLED, "false" );
            }
            orgSettingDetailsFromResponse.put( jObj.get( AdminAPIConstants.ORGANIZATION_ID ).toString(), orgSettingDetails );
        } );
        return orgSettingDetailsFromResponse;
    }
}
