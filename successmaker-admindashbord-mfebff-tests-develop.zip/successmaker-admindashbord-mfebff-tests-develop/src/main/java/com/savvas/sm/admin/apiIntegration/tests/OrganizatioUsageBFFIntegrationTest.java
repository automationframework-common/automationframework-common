package com.savvas.sm.admin.apiIntegration.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class OrganizatioUsageBFFIntegrationTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String password;
    Map<String, String> headers = new HashMap<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private List<String> courseIDs = new ArrayList<>();
    private String mathTeacherDetails;
    private String mathOrgId;
    private String mathSchool;
    private String mathTeacherId;
    private String readingTeacherDetails;
    private String readingOrgId;
    private String readingSchool;
    private String readingTeacherId;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        mathSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );

        mathTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        mathOrgId = RBSDataSetup.organizationIDs.get( mathSchool );
        mathTeacherId = SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student2" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userId" ) );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, mathTeacherId, mathOrgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, mathTeacherId, mathOrgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, mathTeacherId, mathOrgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        Log.message( "Assignment IDs - " + assignmentIds );

        //Creating data for Reading School
        readingTeacherDetails = RBSDataSetup.orgTeacherDetails.get( readingSchool ).get( "Teacher1" );
        readingOrgId = RBSDataSetup.organizationIDs.get( readingSchool );
        readingTeacherId = SMUtils.getKeyValueFromResponse( readingTeacherDetails, "userId" );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, readingTeacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( readingSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( readingSchool ).get( "Student1" ), "userId" ) ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( readingSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, readingTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( readingSchool ).get( "Student1" ), "userId" ) ), AssignmentAPIConstants.USERS_TYPE );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student2" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student2" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( readingSchool ).get( "Student1" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
        FixupFunction.executeFixupFunctions( mathOrgId );
        FixupFunction.executeFixupFunctions( readingOrgId );

    }

    @Test ( description = "Verify the student usage chart, if login using district admin credentials", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration", "smoke_test_case_1" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest001: Verify the student usage chart, if login using district admin credentials <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );
            ArrayList<String> organizationList = new ArrayList<>();

            SMUtils.logDescriptionTC( "Verify the student usage chart, if login using district admin credentials" );

            // Selecting single organization and Math subject
            dashBoardPage.clickOrganizationNameFromDropdownOnAdminDashboard( mathSchool );

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            organizationList.add( mathOrgId );

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, organizationList );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'THIS WEEK' data show in student usage chart." );
            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'LAST WEEK' data show in student usage chart." );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'LAST WEEK' data show in student usage chart." );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Y axis in the if the organization has more than one hour for any one week" );
            Log.assertThat( dashBoardPage.getStudentUsageYAxisIntervals().size() - 1 == 5, "Y axis displayed properly!", "Y axis not displayed properly! Expected count- 5. Actual count -" + dashBoardPage.getStudentUsageYAxisIntervals().size() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Zero state message for Organization usage if the selected organization has no usage", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest002: Verify the Zero state message for Organization usage if the selected organization has no usage. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify the Zero state message for Organization usage if the selected organization has no usage" );
            //verifying Zero State Message
            Log.assertThat( dashBoardPage.getStudentUsageZeroStateMessage().equalsIgnoreCase( AdminUIConstants.Dashboard.STUDENT_USAGE_ZERO_STATE ), "Zero State message displayed Properly in Organization usage - Student usage",
                    "Zero State message not displayed Properly in Organization usage - Student usage. Expected - " + AdminUIConstants.Dashboard.STUDENT_USAGE_ZERO_STATE + " Actual - " + dashBoardPage.getStudentUsageZeroStateMessage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify student usage chart if admin selected single organization in org dropdown.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration", "smoke_test_case" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest003() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest003: Verify student usage chart if admin selected single organization in org dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify student usage chart if admin selected single organization in org dropdown." );
            SMUtils.logDescriptionTC( "Verify student usage chart if selected organization has only Math usage." );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify \"THIS WEEK', \"LAST WEEK\" and \"'SCHOOL YEAR \" if the organization has usage less than hour" );
            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Y axis in the if the organization has less than one hour for all week." );
            Log.assertThat( dashBoardPage.getStudentUsageYAxisIntervals().size() == 5, "Y axis displayed properly!", "Y axis not displayed properly! Expected count- 5. Actual count -" + dashBoardPage.getStudentUsageYAxisIntervals().size() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify student usage chart if admin selected multiple organization in org dropdown", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest004() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest004: Verify student usage chart if admin selected multiple organization in org dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify student usage chart if admin selected multiple organization in org dropdown" );

            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ), RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN,
                    Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );

            //Verify the Selected organization count
            Log.assertThat(
                    dashBoardPage.getNoOfOrganizationSelectedText().equals( String.format( AdminUIConstants.Dashboard.ALL_SELECTED_ORGANIATION_COUNT, 2 ) )
                            || dashBoardPage.getNoOfOrganizationSelectedText().equals( String.format( AdminUIConstants.Dashboard.SELECTED_ORGANIZATIONS_COUNT, 2 ) ),
                    "Organization name is displayed when admin select multiple org", "Organization name is not displayed when admin select multiple org" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify student usage chart if selected organization has only Reading usage.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration", "smoke_test_case" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest005() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest005: Verify student usage chart if selected organization has only Reading usage. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify student usage chart if selected organization has only Reading usage." );

            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if teacher deleted any assignments.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration", "smoke_test_case" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest006() throws Exception {
        //delete assignment
        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetail.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        Log.assertThat( new AssignmentAPI().deleteAssignment( smUrl, assignmentDetail, AssignmentAPIConstants.EXCEPTIONNULL ).get( Constants.STATUS_CODE ).equals( "200" ), "assignment deleted sucessfully!", "Issue in deleting the assignment" );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest006:Verify Student usage chart if teacher deleted any assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify student usage chart if selected organization has only Reading usage." );

            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if teacher deleted the assignment for particular student.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest007() throws Exception {

        //remove assignment for student
        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID,
                new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student2" ), "userId" ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ) );
        Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest007:Verify Student usage chart if teacher deleted the assignment for particular student. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if teacher deleted the assignment for particular student." );

            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.MULTI_SCHOOL_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if school admin associated with one school.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest008() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest008: Verify Student usage chart if school admin associated with one school. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if school admin associated with one school." );

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.SCHOOL_ADMIN, new ArrayList<>() );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );

            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );

            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if school admin associated with multiple school.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest009() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest009: Verify Student usage chart if school admin associated with multiple school. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if school admin associated with multiple school." );

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, new ArrayList<>() );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );

            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );

            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if sub-district admin associated with single subdistrict.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest010() throws Exception {

        //Creating teacher and student for subdistrict school
        String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
        String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

        //creating student
        String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
        String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( assignAssignment.toString() );
        executeCourse( subdistrictSchoolStudent, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest010: Verify Student usage chart if sub-district admin associated with single subdistrict. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if sub-district admin associated with single subdistrict." );

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, new ArrayList<>() );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );

            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );

            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if sub-district admin associated with multiple subdistrict.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest011() throws Exception {

        //Creating multiple subdistrict admin
        String mutipleSubDistrictAdmin = "mutipleSubDistrictAdmin" + System.nanoTime();
        HashMap<String, String> adminDetails = new HashMap<>();
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.USERNAME, mutipleSubDistrictAdmin );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, RBSDataSetup.subDistrictwithoutSchool );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.subDistrictwithoutSchoolId );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );

        String subdistrictAdminId = "";
        try {
            new RBSUtils().createCAUserWithAccess( adminDetails, true );
            new RBSUtils().resetPassword( RBSDataSetup.subDistrictwithoutSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( mutipleSubDistrictAdmin ) );
            subdistrictAdminId = new RBSUtils().getUserIDByUserName( mutipleSubDistrictAdmin );

            List<String> orgIds = Arrays.asList( RBSDataSetup.subDistrictwithoutSchoolId, RBSDataSetup.subDistrictwithSchoolId );
            new RBSUtils().updateUserOrgId( new RBSUtils().getUser( subdistrictAdminId ), RBSDataSetupConstants.ADMIN_ROLE, orgIds );
            new RBSUtils().resetPassword( RBSDataSetup.subDistrictwithoutSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( mutipleSubDistrictAdmin ) );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest011: Verify Student usage chart if sub-district admin associated with multiple subdistrict. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( mutipleSubDistrictAdmin, password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if sub-district admin associated with multiple subdistrict." );

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, new ArrayList<>() );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );

            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );

            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if teacher created any new student in organization.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest012() throws Exception {

        //creating student
        String mathSchoolNewStudent = "SchStudent" + System.nanoTime();
        String mathSchoolNewStudentDetails = new UserAPI().createUserWithCustomization( mathSchoolNewStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( mathOrgId ) );
        String newStudentId = SMUtils.getKeyValueFromResponse( mathSchoolNewStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( mathSchoolNewStudentDetails, studentInfo, UserConstants.SCHOOLID, mathOrgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, mathOrgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, mathTeacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( mathOrgId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentId );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), mathTeacherId, Arrays.asList( newStudentId ), mathOrgId,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, mathOrgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newStudentId ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( assignAssignment.toString() );
        executeCourse( mathSchoolNewStudent, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest012: Verify Student usage chart if teacher created any new student in organization. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if teacher created any new student in organization." );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if organization contains orphan students without assignments", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest013() throws Exception {

        //creating student
        String orphanStudent = "SchStudent" + System.nanoTime();
        String orphanStudentDetails = new UserAPI().createUserWithCustomization( orphanStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( mathOrgId ) );
        String orphanStudentId = SMUtils.getKeyValueFromResponse( orphanStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( orphanStudentDetails, studentInfo, UserConstants.SCHOOLID, mathOrgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, mathOrgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, mathTeacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( mathOrgId, RBSDataSetupConstants.DEFAULT_PASSWORD, orphanStudentId );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest013:Verify Student usage chart if organization contains orphan students without assignments <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if organization contains orphan students without assignments" );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if organization contains orphan students with assignments", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest014() throws Exception {

        //creating student
        String orphanStudent = "SchStudent" + System.nanoTime();
        String orphanStudentDetails = new UserAPI().createUserWithCustomization( orphanStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( mathOrgId ) );
        String orphanStudentId = SMUtils.getKeyValueFromResponse( orphanStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( orphanStudentDetails, studentInfo, UserConstants.SCHOOLID, mathOrgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, mathOrgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, mathTeacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( mathOrgId, RBSDataSetupConstants.DEFAULT_PASSWORD, orphanStudentId );

        //Creating group  for above created teacher & student
        String groupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), mathTeacherId, Arrays.asList( orphanStudentId ), mathOrgId,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, mathOrgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( orphanStudentId ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( assignAssignment.toString() );
        executeCourse( orphanStudent, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );

        //Removing student from the group
        new GroupAPI().removeStudentFromGroup( smUrl, orphanStudentId, groupId, mathTeacherId, mathOrgId,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest014: Verify Student usage chart if organization contains orphan students with assignments <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if organization contains orphan students with assignments" );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student usage chart, if deleted and restored the assignments.", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest015() throws Exception {

        //remove assignment for student
        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        String assignmentUserId = new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userId" ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) );
        assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );

        Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

        HashMap<String, String> userDetail = new HashMap<>();
        userDetail.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
        userDetail.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
        userDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        userDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );

        Log.assertThat( new RestoreAssignment().restoreDeletedAssignment( smUrl, userDetail, CourseAPIConstants.NULL ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment restored sucessfully!", "Issue in restoring the assignment!" );
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest015:Verify the student usage chart, if deleted and restored the assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify the student usage chart, if deleted and restored the assignments." );

            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student usage Chart, after delete the assignment for group", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest016() throws Exception {
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        //adding the student to the  group for the  tacher
        String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), mathTeacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userId" ) ),
                mathOrgId, token );

        //Assigning the assignment
        String courseName = "MATH Custom Settings" + System.nanoTime();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, mathTeacherId, mathOrgId, DataSetupConstants.SETTINGS, courseName ) );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

        //execute course through student dashboard
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userName" ), courseName, true );

        //delete group Assignment
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, newGroupId );
        new AssignmentAPI().deleteAssignmentfromGroup( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest016: Verify the student usage Chart, after delete the assignment for group <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify the student usage Chart, after delete the assignment for group" );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student usage chart, if remove the product association for group", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest017() throws Exception {
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        //adding the student to the  group for the  tacher
        String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), mathTeacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userId" ) ),
                mathOrgId, token );

        //Assigning the assignment
        String courseName = "MATH Custom Settings" + System.nanoTime();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, mathTeacherId, mathOrgId, DataSetupConstants.SETTINGS, courseName ) );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

        //execute course through student dashboard
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student3" ), "userName" ), courseName, true );

        //delete group Assignment
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, newGroupId );
        new AssignmentAPI().deleteAssignmentfromGroup( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );

        //Removing Product from group
        new RBSUtils().addProductToClassGraphQL( mathOrgId, newGroupId, "", token, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID ) );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest017: Verify the student usage chart, if remove the product association for group <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify the student usage chart, if remove the product association for group" );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student usage chart, if deleted the students with assignments", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration", "smoke_test_case" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest018() throws Exception {

        String newStudent = "SchStudent" + System.nanoTime();
        String newStudentDetails = new UserAPI().createUserWithCustomization( newStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( mathSchool ) ) );
        String newStudentId = SMUtils.getKeyValueFromResponse( newStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfos = new HashMap<>();
        studentInfos = new RBSDataSetup().generateRequestValues( newStudentDetails, studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.TEACHER_ID, mathTeacherId );
        studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );

        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
        new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentId );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), mathTeacherId, Arrays.asList( newStudentId ), RBSDataSetup.organizationIDs.get( mathSchool ),
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newStudentId ), AssignmentAPIConstants.USERS_TYPE );

        executeCourse( newStudent, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );

        //delete Student
        new RBSUtils().deleteUser( Arrays.asList( newStudentId ) );
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest018:Verify the Student usage chart, if deleted the students with assignments <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify the Student usage chart, if deleted the students with assignments" );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student usage chart, if suspended the students with assignments", groups = { "SMK-51731", "organizationUsage", "organizationUsageBFFIntegration" }, priority = 1 )
    public void tcSMOrganizationUsageIntegrationTest019() throws Exception {

        String newStudentForSuspend = "SchStudent" + System.nanoTime();
        String newStudentForSuspendDetails = new UserAPI().createUserWithCustomization( newStudentForSuspend, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( mathSchool ) ) );
        String newStudentIdForSuspend = SMUtils.getKeyValueFromResponse( newStudentForSuspendDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInformation = new HashMap<>();
        studentInformation = new RBSDataSetup().generateRequestValues( newStudentForSuspendDetails, studentInformation, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        studentInformation = SMUtils.updateRequestBodyValues( studentInformation, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        studentInformation = SMUtils.updateRequestBodyValues( studentInformation, UserConstants.TEACHER_ID, mathTeacherId );
        studentInformation = SMUtils.updateRequestBodyValues( studentInformation, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );

        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInformation );
        new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentIdForSuspend );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), mathTeacherId, Arrays.asList( newStudentIdForSuspend ), RBSDataSetup.organizationIDs.get( mathSchool ),
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newStudentIdForSuspend ), AssignmentAPIConstants.USERS_TYPE );

        executeCourse( newStudentForSuspend, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );

        //suspend Student
        new RBSUtils().suspendUser( Arrays.asList( newStudentIdForSuspend ) );
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationUsageIntegrationTest019: Verify the Student usage chart, if suspended the students with assignments <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify the Student usage chart, if suspended the students with assignments" );
            //To select the single organization in org dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();

            //To get the student usage data from UI
            Map<String, Map<String, String>> eightWeeksStudentUsageFromUI = dashBoardPage.getEightWeeksStudentUsage();

            //To get the student usage data from API
            Map<String, Map<String, String>> studentUsageDataFromAPI = getStudentUsageDataFromAPI( Admins.DISTRICT_ADMIN, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) );

            //To Verify all week usage
            Log.assertThat( eightWeeksStudentUsageFromUI.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( studentUsageDataFromAPI.get( entry.getKey() ), entry.getValue() ) ), "All weeks student usage details are displayed properly",
                    "All weeks student usage details are not displayed properly. Expected - " + studentUsageDataFromAPI + " Actual - " + eightWeeksStudentUsageFromUI );

            //Verify the Selected organization name
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), "Organization name is displayed when admin select single org",
                    "Organization name is not displayed when admin select single org" );

            // To Verify the weekly usage and School-year usage
            Log.assertThat( dashBoardPage.getThisWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) ), "This week usage hours displayed properly!",
                    "This week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.THIS_WEEK_MINS ) + " Actual - " + dashBoardPage.getThisWeekUsage() );
            Log.assertThat( dashBoardPage.getLastWeekUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) ), "Last week usage hours displayed properly!",
                    "Last week usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.LAST_WEEK_MINS ) + " Actual - " + dashBoardPage.getLastWeekUsage() );
            Log.assertThat( dashBoardPage.getSchoolYearUsage().equalsIgnoreCase( studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) ), "School year usage hours displayed properly!",
                    "School Year usage hours not displayed properly . Expected - " + studentUsageDataFromAPI.get( "individualFields" ).get( StudentUsage.TOTAL_MINTUES ) + " Actual - " + dashBoardPage.getSchoolYearUsage() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To get the student usage data from API
     * 
     * @throws Exception
     */
    public Map<String, Map<String, String>> getStudentUsageDataFromAPI( Admins admin, List<String> selectedOrgIds ) throws Exception {
        if ( selectedOrgIds.isEmpty() ) {
            selectedOrgIds = getOrganizationIdsForAdmin( admin );
        }
        String orgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
            Log.message( "*********************************" );
            Log.message( "Org id of the multi-school-admin is " + orgId );
            Log.message( "*********************************" );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
            Log.message( "*********************************" );
            Log.message( "Org id of the admin is " + orgId );
            Log.message( "*********************************" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        Response postOrganizationUsageBFF = new Dashboard().postOrganizationUsageBFF( headers, selectedOrgIds, userId, orgId, false );
        Log.message( postOrganizationUsageBFF.getBody().asString() );
        Map<String, Map<String, String>> usageDetailsFromResponse = new HashMap<>();
        String reponse = SMUtils.getKeyValueFromResponse( postOrganizationUsageBFF.getBody().asString(), "data" );
        String reponseData = SMUtils.getKeyValueFromResponse( reponse, "getOrganizationUsage" );
        IntStream.rangeClosed( 0, 7 ).forEach( iter -> {
            Map<String, String> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( iter );
            subjectUsage.put( StudentUsage.MATH_MINS, "Math : " + SMDashBoardPage.convertMinutesIntoHours( Integer.parseInt( jObj.get( StudentUsage.MATH_MINS ).toString() ) ).trim() );
            subjectUsage.put( StudentUsage.READING_MINS, "Reading : " + SMDashBoardPage.convertMinutesIntoHours( Integer.parseInt( jObj.get( StudentUsage.READING_MINS ).toString() ) ).trim() );
            usageDetailsFromResponse.put( jObj.get( StudentUsage.WEEK ).toString(), subjectUsage );
        } );
        Map<String, String> individualFields = new HashMap<>();

        individualFields.put( StudentUsage.THIS_WEEK_MINS, SMDashBoardPage.convertMinutesIntoHoursWithTenthDecimal( Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.THIS_WEEK_MINS ) ) ) );
        individualFields.put( StudentUsage.LAST_WEEK_MINS, SMDashBoardPage.convertMinutesIntoHoursWithTenthDecimal( Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.LAST_WEEK_MINS ) ) ) );
        individualFields.put( StudentUsage.TOTAL_MINTUES, SMDashBoardPage.convertMinutesIntoHoursWithRounding( Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.TOTAL_MINTUES ) ) ) );
        usageDetailsFromResponse.put( "individualFields", individualFields );

        return usageDetailsFromResponse;
    }

    /**
     * To get the organization List for given admin
     * 
     * @param admin
     * @return
     * @throws Exception
     */
    public List<String> getOrganizationIdsForAdmin( Admins admin ) throws Exception {

        String orgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );
        Map<String, String> headers = new HashMap<>();
        //headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.ORGID, orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers );
        List<String> organizationListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME ) ).forEach(
                iter -> organizationListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_ID, iter ) ) );

        return organizationListFromAPI;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "2", "20" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "5" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }
}
