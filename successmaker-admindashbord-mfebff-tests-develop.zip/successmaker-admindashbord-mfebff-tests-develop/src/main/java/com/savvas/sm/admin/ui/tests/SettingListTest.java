package com.savvas.sm.admin.ui.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SettingListTest extends EnvProperties {

    private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify Setting list Page with all field", groups = { "SMK-51096", "AdminDashboard", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdmin_SettingList001: Verify Setting list Page with all field <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify school admin can view Settings left nav bar in successmaker." );
            settingpage = dashBoardPage.navigateToSettingListPage();
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify page should be navigated to Settings page when admin click on Setting sub Nav Bar." );
            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify list of all fields on Settings Page." );
            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify  edit button available Holiday Scheduler." );
            Log.assertThat( settingpage.getEditButtn( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ).equals( AdminUIConstants.SettingPage.EDIT_BUTTON ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( " Verify edit button available for Math Screener & Diagnostic Assessments(MSDA)." );
            Log.assertThat( settingpage.getEditButtn( AdminUIConstants.SettingPage.MSDA ).equals( AdminUIConstants.SettingPage.EDIT_BUTTON ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Setting list Page for school admin", groups = { "SMK-51096", "AdminDashboard", "SettingList" }, priority = 2 )
    public void tcSMAdmin_SettingList002() throws Exception {

        username = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {

            Log.testCaseInfo( "tcSMAdmin_SettingList002: Verify Setting list Page for school admin<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify school admin can view Settings left nav bar in successmaker." );
            settingpage = dashBoardPage.navigateToSettingListPage();
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
