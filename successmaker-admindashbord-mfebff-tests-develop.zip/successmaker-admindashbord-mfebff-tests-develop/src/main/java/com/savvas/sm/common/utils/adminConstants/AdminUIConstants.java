package com.savvas.sm.common.utils.adminConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.learningservices.utils.EnvironmentPropertiesReader;

public interface AdminUIConstants {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public String MFEURL = configProperty.getProperty( "AdminDashboardMFE" );
    public String RESTORE_ASSIGNMENT_MFEURL = configProperty.getProperty( "RestoreAssignmentMFE" );

    public String SELECTED_SIDE_NAV_BAR_COLOR = "#2150a3";
    public Object HEADER = "Audit History: Assignments";
    List<String> REPORT_EXECUTION_PERCENTAGE = Arrays.asList( "100", "50", "10", "0" );

    public enum SubNavigations {
        DASHBOARD,
        MASTERY,
        SHARED_COURSES,
        AUDIT_HISTORY,
        SETTINGS
    }

    public interface SettingPage {

        public String HEADER = "Settings";
        public String HOLIDAY_SCHEDULER = "Holiday Scheduler";
        public String MSDA = "Math Screener & Diagnostic Assessments";
        public String EDIT_BUTTON = "Edit";

        // MSDA Edit Popup
        public String MSDA_POPUP_HEADER = "Math Screener & Diagnostic Assessments";
        public String MSDA_POPUP_DESCRIPTION = "This setting allows you to turn MSDA on or off for your school(s).";
        public String MSDA_POPUP_LIST_HEADER = "Organizations:";
        public String SEARCH_BAR_PLACEHOLDER = "Search Organizations";
        public String TURN_ALL_ON = "Turn All On";
        public String TURN_ALL_OFF = "Turn All Off";
        public String TOGGLE_ON_COLOR = "#006be0";
        public String TOGGLE_OFF_COLOR = "#767676";
        public String INVLAID_SEARCH_RESULT = "No search results found.";

    }

    /**
     * Constants related to Dashboard page
     *
     */
    public interface Dashboard {
        public String ARIA_PRESSED = "aria-pressed";
        public String ARIA_EXPANDED = "aria-expanded";
        public String SELECTED_ORGANIZATIONS_COUNT = "%s Organizations Selected";
        public String ALL_SELECTED_ORGANIATION_COUNT = "All %s Organizations Selected";
        public String ALL_ORGANIZATIONS_SELECTED = "All Organizations (%s)";
        public String ALL_ORGANIZATION = "ALL (%s)";
        public String SEARCH_ORGANIZATIONS = "Search Organizations";
        public String SEARCH = "Search";
        public String NO_ORGANIZATION_FOUND = "No organization(s) found...";
        public String NO_DATA_FOUND = "No data found...";
        public String ORG_NAME_SPECIALCHARACTER = "@#  12Aa";
        public String INVALID_ORGNAME = "invalidOrgName";
        public String DASHBOARD = "Dashboard";

        // Performance report widget
        public String PERFORMANCE_REPORT = "Performance Report";
        public String CURRENT_LEVEL_AND_GAIN = "Current Level and Gain";
        public List<String> GAIN_HEADERS = Arrays.asList( "LARGEST GAIN", "SMALLEST GAIN" );
        public List<String> Y_AXIS_INTERVALS = Arrays.asList( "K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" );
        public List<String> X_AXIS_INTERVALS = Arrays.asList( "0", "0.5", "1", "1.5", "2", "2.5", "3", "3.5", "4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.5", "8.95" );
        public String X_AXIS_LABEL = "Course Level";
        public String Y_AXIS_LABEL = "Grade";
        public List<String> SUBJECTS = Arrays.asList( "Math", "Reading" );
        public List<String> HEXA_COLORS_FOR_GRADES = Arrays.asList( "#7356B6", "#9251AC", "#AE5775", "#C85D42", "#C23D4B", "#CE7C3A", "#6F8956", "#169570", "#217AB7", "#3D69BC", "#5458A7", "#52607F", "#3D4262" );

        public String GRADE = "Grade";
        public String INITIAL_PLACEMENT = "Initial Placement (IP)";
        public String CURRENT_LEVEL = "Current Level";
        public String TOTAL_GAIN = "Total Gain";
        List<String> PERFORMANCE_REPORT_ZERO_STATE_MESSAGE = Arrays.asList( "No math performance data to display.", "Once data is captured, you will see it here." );
        List<String> PERFORMANCE_REPORT_ZERO_STATE_READING_MESSAGE = Arrays.asList( "No reading performance data to display.", "Once data is captured, you will see it here." );
        public String NO_PERFORMANCE_MESSAGE = "No performance data to display.";

        // Student Usage
        public String ORGANIZATION_USAGE = "Organization Usage";
        public String STUDENT_USAGE = "Student Usage";
        public String STUDENT_AVERAGES = "Student Averages";
        List<String> STUDENT_AVERAGE_WEEK_HEADERS = new ArrayList<>( Arrays.asList( "THIS WEEK", "LAST WEEK", "SCHOOL YEAR" ) );
        List<String> X_AND_Y_AXIS_HEADERS = new ArrayList<>( Arrays.asList( "Weeks", "Hours" ) );
        public List<String> HEXA_COLORS_FOR_SUBJECTS = Arrays.asList( "#9ECA47", "#32325D" );
        public String STUDENT_USAGE_ZERO_STATE = "No Usage Data to display. Once data is captured, you will see it here";

        //Organization Usage goal
        public String MATH_USAGE_GOAL = "Math Usage Goals";
        public String READING_USAGE_GOAL = "Reading Usage Goals";
        public String USAGE_GOAL_DESC = "Usage goals apply only to the default courses Math and Reading.";
        public String ON_TRACK = "On Track";
        public String WATCH_CLOSELY = "Watch Closely";
        public String FALLING_BEHIND = "Falling Behind";
        public String MATH = "Math";
        public String READING = "READING";
        public String SCHOOL = "school3_RVC";
        public String ON_TRACK_COLOR_CODE = "rgb(158, 202, 71)";
        public String WATCH_CLOSELY_COLOR_CODE = "rgb(249, 168, 70)";
        public String FALLING_BEHIND_COLOR_CODE = "rgb(215, 58, 89)";
        public String ORGANIZATION_USAGE_GOAL_ZERO_STATE_HEADER = "No Usage Data to display.";
        public String ZERO_STATE_DESCRIPTION = "Once data is captured, you will see it here.";

        public String ORGANIZATION_PERFORMANCE_THIS_WEEK = "Organization Performance This Week";
        public List<String> ORGANIZATION_PERFORMANCE_THIS_WEEK_HEADERS = Arrays.asList( "Organization", "Usage", "Skills Assessed", "Skills Mastered", "" );

    }

    /**
     * Constants related to Shared Courses page
     *
     */
    public interface SharedCourses {
        public String HEADER = "Shared Courses";
        public String INVALID_SEARCH_RESULT = "No search results found";
        List<String> SHARED_COURSE_TABLE_HEADER = new ArrayList<>( Arrays.asList( "Course Name", "Course Owner", "Organizations Shared With" ) );

        public enum SHARED_COURSE_TABLE_HEADER {
            COURSE_NAME,
            COURSE_OWNER,
            ORGANIZATIONS_SHARED_WITH
        }

        public String ALPHA_NUMERIC_SPECIAL_CHAR = "Abc123!@#$   ";
        public String SEARCH_COURSE_NAME = "Search Course Name";
        public String COUNT_OF_COURSES = "%s-%s of %s";
        public String PAGE_COUNT = "Page %s of %s";
        public String ARIA_DISABLED = "aria-disabled";
        public String ORG_LIST_POPUP_HEADER = "Edit Share List";
        public String ORGANIZATIONS = "Organizations:";
        public String SHOW_SHARED_ONLY = "Show shared only";
        public String SHARE_ALL = "Share All";
        public String UNSAHERE_ALL = "Unshare All";
        public String CANCEL = "Cancel";
        public String SAVE = "Save";
        public String ORG = "org";
        public String NO_SHARED_ORGANIZATIONS = "No shared organizations.";

    }

    public interface AuditHistory {

        public String HEADER = "Audit History";
        public String URL = "https://ebsm-admin-dashboard-webapp-dev.smdemo.info/audit-history";
        public String AUDIT_HISTORY_URL = "https://successmaker-admin-dashboard-webapp-dev.smdemo.info/audit-history";
        public String EB_AUDIT_HISTORY_URL = "https://nightly-cat.easybridge.pk12ls.com/ca/successmaker.htm";
        public String AUDIT_HISTORY_BFF_URL = "https://sm-admin-dashboard-bff-srv-stack-stage.smdemo.info/graphql";
        public String TITLE = "Audit History: Assignments";
        public String ZERO_STATE_HEADER = "No results displayed";
        public String AUDIT_HISTORY_ZERO_STATE = "No Audit History";
        public String ZERO_STATE_MESSAGE = "Select from the organization list above to generate an audit history list for assignments.";
        public String AUDIT_HISTORY_ZERO_STATE_MESSAGE = "Once there is audit history for the selected organization,it will be listed here.";
        public String ASSIGNMEN_NAME = "Assignment Name";
        public String GROUP_STUDENT= "Group / Student";
        public String TYPE = "Type";
        public String ASSIGNED_BY = "Assigned By";
        public String COURSE = "Course";
        public String DATE_DELETED = "Date Deleted";
        

        public enum AUDIT_HISTORY_TABLE_HEADER {
            DELETED_BY,
            ASSIGNMENT_NAME,
            GROUP_STUDENT,
            TYPE,
            ASSIGNED_BY,
            COURSE,
            DATE_DELETED
        }

        public enum AUDIT_HISTORY_NAVIGATION_BUTTONS {
            FIRST,
            PREVIOUS,
            NEXT,
            LAST
        }

        public enum BUTTON_STATUS {
            ENABLED,
            DISABLED
        }
    }

    /**
     * Constant related to edit holiday scheduler
     * 
     * @author vikas.pandey
     *
     */
    public interface EditHolidayScheduler {

        public String HEADER_TEXT = "Edit Holiday Scheduler";
        public String EDIT_HOLIDAY_SCHEDULER_DESC = "Add and remove holidays for all of the schools in your district.";
        public String EXCLUDES_WEEKENDS = "* Excludes Weekends";
        public String ZERO_STATE_HEADER = "No scheduled holidays";
        public String ZERO_STATE_DESCRIPTION = "Add a single day or date span using the calendar fields.";
        public String START_DATE = "Start Date";
        public String END_DATE = "End Date";
        public String HOLIDAY_NAME = "Holiday Name";
        public String SCHEDULED_HOLIDAY_COL = "Scheduled Holiday*";
        public String REMOVE = "Remove";
        public String START_DATE_ENTER = "03/01/22";
        public String START_DATE_FEB = "02/23/22";
        public String END_DATE_APR = "04/12/22";
        public String END_DATE_ENTER = "03/10/22";
        public String END_DATE_ENTER2 = "03/01/22";
        public String START_DATE_ENTER2 = "03/02/22";
        public String HOLIDAY_NAME_DESC = "Holiday";
        public String HOLIDAY_NAME_LOWERCASE = "holiday";
        public String CANCEL_BTN = "Cancel";
        public String REMOVE_BTN = "Remove";
        public String START_DATE_NEXT = "03/02/22";
        public String START_DATE_NEXT2 = "04/04/22";
        public String END_DATE_NEXT = "03/02/22";
        public String END_DATE_NEXT2 = "04/05/22";
        public String START_DATE_RANGE_FIRST = "03/03/23";
        public String END_DATE_INCLUDE_WEEKEND = "03/16/23";
        public String DATE_RANGE_Text = "03/01/22 - 03/02/22";
        public String DATE_RANGE_Text2 = "03/01/22 - 03/02/22";
        public String DATE_RANGE_Text3 = "04/04/22 - 04/05/22";
        public String startCalendar_Date = "8";
        public String endCalendar_Date = "14";
        public String DATE_RANGE = "03/03/23 - 03/16/23";
        public String EXIST_DATE_ERROR_MESSAGE = "This date is already scheduled.";
        public String ACADEMIC_YEAR_ERROR = "Selected date must be within a year from the current date.";
        public String WRONG_DATE_FORMAT_ERROR = "Must be a valid date";
        public String ERROR_MESSAGE_WITH_EXIST_DATE_RANGE = "One or more days within this date-range have already been scheduled";
        public String DATE_MORE_THAN_YEAR = "03/04/27";
        public String WEEKEND_DATE = "03/05/22";
        public String ERROR_MESSAGE_WEEKENDS = "Selected date must be a weekday";
        public String LESS_THAN_START_DATE_ERROR_MSG = "Start date must be before the end date.";
        public String WRONG_DATE_FORMAT = "22/22/222";
        public String LENGTHY_HOLIDAY_DESCRIPTION = "Description contain 50 words for Holiday Scheduler";
        public String LENGTHY_HOLIDAY_DESCRIPTION_NEW = "Holiday scheduler for lengthy description Holiday scheduler for length description";
        public String HOLIDAY_NEW_DATE = "10/25/22 - 10/27/22";
        public String HOLIDAY_NEW_NAME = "New Holiday";
    }

    /**
     * 
     * Usage Goal - HomePage
     * 
     * @author bharathi.murugan
     *
     */
    public interface UsageGoal {
        public static List<String> USAG_EGOAL_COLUMNS_HEADER = new ArrayList<>( Arrays.asList( "Student", "Usage Goal Status", "Total Time", "Avg Time / Wk", "Target Hours", "Goal End Date" ) );
        public static String USAGE_GOAL_MATH_HEADER = "Math Usage Goals";
        public static String USAGE_GOAL_READING_HEADER = "Reading Usage Goals";
        public static String STUDENT_DETAIL = "studentDetail";
        public static String STUDENT = "student";
        public static String GOAL_BUCKET = "goalBucket";
        public static String ACTUAL_MINUTES = "actualMinutesInCourse";
        public static String AVERAGE_MINUTE_PER_WEEK = "averageMinutesPerWeek";
        public static String ADDITIONAL_MINUTE_PER_WEEK = "additionalMinutesPerWeek";
        public static String GOAL_MINUTES = "goalMinutesInCourse";
        public static String GOAL_END_DATE = "goalEndDate";
        public static String STUDENT_COUNT = "Student%s";
        public static String WATCH_CLOSELY = "Watch Closely";
        public static String FALLING_BEHIND = "Falling Behind";
        public static String ONTRACK = "On Track";
        //****************/*******************/
        public static String HINT_MESSAGE = "Usage goals apply only to the default courses Math and Reading.";
        public static String ORGANIZATION_SELECTED_TEXT = "Organizations Selected";
        public static String PERCENTAGE_TEXT_LEGENDS = "% of Students";
        public static String NO_DATA_DISPLAYED = "No Usage data to display";
        public static String NO_RESULT_DISPLAYED = "NO RESULTS DISPLAYED";
        public static int NO_OF_ORG_TEXT_SIZE = 22;
        public static String HEX_VALUE_BLACK_COlOUR = "#000000";
        public static String HEX_VALUE_ONTRACK = "#9eca47";
        public static String HEX_VALUE_WATCHCLOSELY = "#f9a846";
        public static String HEX_VALUE_FALLINGBEHIND = "#d73a59";
        public static String READING = "Reading";
        public static String MATH = "Math";
    }

    /**
     * Constants related to Restore Assignment List page
     *
     */
    public interface RestoreAssignmentList {

        public String HEADER = "Restore Assignments";
        public List<String> TABLE_TITTLE = Arrays.asList( "Assignment Name", "Teacher Name", "Student Name", "Student Username", "Deleted On" );
        public String DELETED_ON = "Deleted On";
        public String CREATED_ON = "Created On";
        public String RESTORE = "Restore";
        public String ERROR_MESSAGE = "Restoration of assignment failed.\nAnother assignment for this student already exits. Please delete the other assignment first.";

    }

    public enum CREATED_DELETED_DATE {
        DATE_CREATED,
        DATE_UPDATED
    }

    public List<String> SUBNAVIGATION = Arrays.asList( "Dashboard", "Mastery" );

}
