package com.savvas.sm.admin.api.tests;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.settings.HolidayScheduler;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;

public class GetHolidaySchedulerTest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String username;
    private String password;
    private String orgId;
    private String userId;
    private Map<String, String> response;
    HolidayScheduler holidayScheduler = new HolidayScheduler();
    String endPoint;
   
    

    @BeforeTest(alwaysRun = true)
    public void BeforeTest() throws Exception {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = configProperty.getProperty( "district_ID" );
        

        // Creating Admin user data to login
        // Retrieving username and resetting password from the response
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        // End point for API
        endPoint = AdminAPIConstants.GET_HOLIDAY_SCHEDULER;
    }

    @Test ( dataProvider = "getData_Positive", groups = { "smoke_test_case","Happy_Path_Get_Holiday_Scheduler_001", "SMK-49934", "Get Holiday Scheduler", "API" }, priority = 1 )
    public void getHolidayScheduler_Positive( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
  
        switch ( scenario ) {
            case "Valid for district":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                // Getting date for creating holiday
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern( "yyyy-MM-dd" );
                LocalDateTime now = LocalDateTime.now();
                String currentDate = dtf.format( now );

                // Creating sample holiday
                Map<String, String> putHolidayScheduler = holidayScheduler.putHolidayScheduler( smUrl, headers, currentDate, currentDate, "Local Holiday", orgId );

                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                String keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                HashMap<String, String> keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString(), jObj.get( "description" ).toString() );
                } );
                HashMap<String, String> dbValues = getDBValues();
                Log.message( keyValue + "" );
                Log.message( dbValues + "" );
                Log.assertThat( SMUtils.compareTwoHashMap( keyValue, dbValues ), "The dates and description values are verified", "The dates and description are not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getHolidayScheduler", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Valid for district single holiday":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );

                deleteAllHolidays( response );

                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );

                dtf = DateTimeFormatter.ofPattern( "yyyy-MM-dd" );
                now = LocalDateTime.now();
                currentDate = dtf.format( now );

                putHolidayScheduler = new HolidayScheduler().putHolidayScheduler( smUrl, headers, currentDate, currentDate, "Local Holiday", orgId );
                Log.message( putHolidayScheduler.toString() );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();

                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "date" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString(), jObj.get( "description" ).toString() );
                } );
                dbValues = getDBValues();
                Log.assertThat( SMUtils.getWordCount( keyValueFromResponse, "description" ) == 1, "Verified single response is retrieved.",
                        "Verified single response is not retrieved. Actual Count - " + SMUtils.getWordCount( keyValueFromResponse, "description" ) );
                Log.message( keyValue + "" );
                Log.message( dbValues + "" );
                Log.assertThat( SMUtils.compareTwoHashMap( keyValue, dbValues ), "The dates and description values are verified", "The dates and description are not verified" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getHolidayScheduler", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;
            case "Valid for empty response":
                dtf = DateTimeFormatter.ofPattern( "yyyy-MM-dd" );
                now = LocalDateTime.now();
                currentDate = dtf.format( now );

                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                putHolidayScheduler = new HolidayScheduler().putHolidayScheduler( smUrl, headers, currentDate, currentDate, "Local Holiday", orgId );
                Log.message( putHolidayScheduler.toString() );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );

                deleteAllHolidays( response );

                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                String message = SMUtils.getKeyValueFromResponse( response.get( Constants.RESPONSE_BODY ), "messages,message" );
                Log.assertThat( message.equals( AdminAPIConstants.NO_HOLIDAY_MESSAGE ), "No Holiday message verified", "No Holiday message is not verified" );
                break;
            default:
                break;
        }
        Log.message( response.toString() );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Positive() {
        Object[][] data = { { "tcGetHoliday001", "Verify all the holidays are returned in response with 200 response code for given district", "200", "Valid for district" },
                { "tcGetHoliday002", "Verify one holiday details are returned in response with 200 response code for given district", "200", "Valid for district single holiday" },
                { "tcGetHoliday003", "Verify empty response with 200 response code for given district when district is not having any holiday.", "200", "Valid for empty response" } };
        return data;
    }

    @Test ( dataProvider = "getData_Negative", groups = { "SMK-49934", "Get Holiday Scheduler", "API" }, priority = 1 )
    public void getHolidayScheduler_Negative( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseNumber + ": " + testDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        switch ( scenario ) {
            case "Invalid with no SSO token":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                break;
            case "Invalid with invalid SSO token":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) + "Invalid" );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                break;
            case "Invalid for subdistrict admin":
                // Getting Subdistrict admin details
                String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                String subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
                String subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
                // Setting Headers
                headers.put( AdminAPIConstants.ORGID, subDistrictwithSchoolId );
                headers.put( AdminAPIConstants.USERID, subdistrictUserID );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SUBDISTRICT_ADMIN );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                break;
            case "Invalid for school admin":
                // Getting School admin details
            	String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
                // Setting Headers
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                headers.put( AdminAPIConstants.USERID, schoolAdminUserID );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUsername, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                break;
            case "Invalid for teacher":
                // Getting Teacher Details
                String teacherDetails = RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ).get( "Teacher1" );
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN );

                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );

                break;
            case "Invalid for student":
                String studentDetails = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ).get( "Student1" );
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN );

                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );

                break;
            default:
                break;
        }
        Log.message( response.toString() );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Negative() {
        Object[][] data = { { "tcGetHoliday004", "Verify status code 401 when SSO token  is not passed in header parameter", "401", "Invalid with no SSO token" },
                { "tcGetHoliday005", "Verify status code 401 when invalid SSO token  is passed in header parameter", "401", "Invalid with invalid SSO token" },
                { "tcGetHoliday006", "Verify status code is 403 when subdistrict admin details are passed in header parameter", "403", "Invalid for subdistrict admin" },
                { "tcGetHoliday007", "Verify status code is 403 when school admin details are passed in header parameter", "403", "Invalid for school admin" },
                { "tcGetHoliday008", "Verify status code is 403 when school teacher details are passed in header parameter", "403", "Invalid for teacher" },
                { "tcGetHoliday009", "Verify status code is 403 when school student details are passed in header parameter", "403", "Invalid for student" } };
        return data;
    }

    public HashMap<String, String> getDBValues() {
        return new SqlHelperOrganization().getHolidayList();
    }

    public void deleteAllHolidays( Map<String, String> response ) throws Exception {
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.RESPONSE_BODY ), "data" );
        List<String> dateFromResponse = new ArrayList<String>();
        IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
            JSONArray ja = new JSONArray( keyValueFromResponse );
            JSONObject jObj = ja.getJSONObject( itr );
            dateFromResponse.add( jObj.get( "date" ).toString() );
        } );
        Collections.sort( dateFromResponse );
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( AdminAPIConstants.ORGID, orgId );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
        if ( dateFromResponse.size() != 0 ) {
            holidayScheduler.deleteHolidayScheduler( smUrl, headers, dateFromResponse.get( 0 ), dateFromResponse.get( dateFromResponse.size() - 1 ), "", orgId );
        }
    }

}
