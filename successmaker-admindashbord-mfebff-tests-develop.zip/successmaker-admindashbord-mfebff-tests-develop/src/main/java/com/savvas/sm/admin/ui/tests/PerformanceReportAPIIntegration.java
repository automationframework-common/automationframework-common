package com.savvas.sm.admin.ui.tests;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.savvas.sm.admin.util.DevToolsUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.FixupFunction;

import net.lightbody.bmp.proxy.jetty.util.Password;

public class PerformanceReportAPIIntegration extends EnvProperties {

    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgTwoName;
    private String orgTwoId;
    private String teacherId;
    private String teacherUsername;
    private String flexSchool;
    private String flexSchoolId;
    private String student1Details;
    private String student2Details;
    private String student3Details;
    private static HashMap<String, String> staffDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    private List<String> courseIDs = new ArrayList<>();
    private String customMathCourse;
    private String customReadingCourse;
    
  //Tokens
    private String savvasAdminToken = null;
    private String districtAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;

    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String savvasAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String subDistrictAdminWithSchoolDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;

    //===Details
    public static String subDistrictwithoutSchool_name = null;
    public static String subDistrictwithSchool_name = null;
    public static String subDistrictOrgId_with_school = null;
    public static String subDistrictOrgId_without_school = null;
    public static String school_under_subDistrictwithSchool_name = null;

    Dashboard dasboard = new Dashboard();

    private String districtId = null;
    private String configGraphQL;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass( ITestContext context) throws Exception {
    	districtId = configProperty.getProperty( "district_ID" );
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        if ( DevToolsUtils.isMock( context ) ) {
            configGraphQL = "https://sm-admin-dashboard-bff-srv-stack-dev.smdemo.info/graphql";
        }else {

            flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
            flexSchoolId = RBSDataSetup.organizationIDs.get( flexSchool );
            subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
            subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
            subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
            subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
            school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );

            orgTwoName = RBSDataSetup.SchoolUnderSubDistrict;
            orgTwoId = RBSDataSetup.schoolUnderSubDistrict_SchoolId;
            Log.message( flexSchool + "/" + flexSchoolId + "/" + orgTwoName + "/" + orgTwoId );

            teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
            teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
            teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

            student1Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
            student2Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
            student3Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) );
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) );
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) );

            String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

            staffDetails.put( AssignmentAPIConstants.ORG_ID, flexSchoolId );
            staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
            staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

            contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
            contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

            contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
            contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

            Log.message( "contentbasename" + contentBaseName );
            contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
            contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, flexSchoolId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

            customMathCourse = "Custom Math Course" + System.nanoTime();
            contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, flexSchoolId, DataSetupConstants.STANDARD, customMathCourse ) );

            contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
            contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, flexSchoolId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

            customReadingCourse = "Custom Reading Course" + System.nanoTime();
            contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, flexSchoolId, DataSetupConstants.STANDARD, customReadingCourse ) );

            courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
            courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
            courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );

            courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
            courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
            courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );

            Log.message( "Assigning assignment..." );
            Log.message( staffDetails.toString() );
            Log.message( studentRumbaIds.toString() );
            Log.message( courseIDs.toString() );
            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, courseIDs );
            Log.message( "Assignment Details" + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }

            Log.message( "Assignment IDs - " + assignmentIds );

            //District Admin
            districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "081" );
            Log.message( "********" );
            Log.message( "District admin details from Create Admins are " + districtAdminDetails );
            Log.message( "********" );
            districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            //Sub-District Admin
            subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_without_school, "085" );
            Log.message( "********" );
            Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
            Log.message( "********" );
            subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            //Sub-District Admin
            subDistrictAdminWithSchoolDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "086" );
            Log.message( "********" );
            Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
            Log.message( "********" );
            subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            //Multi-School Admin
            multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "0087" );
            Log.message( "********" );
            Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
            Log.message( "********" );
            multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            //School Admin
            schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, flexSchoolId, "088" );
            Log.message( "********" );
            Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
            Log.message( "********" );
            schoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );
            executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );
            FixupFunction.executeFixupFunctions( flexSchoolId );
        }
        
    }

    @Test ( description = "Verify the Performance Report widget data for default couse", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget", "smoke_test_case","mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration001(ITestContext context) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration001: Verify the Performance Report widget data for default couse. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            if (DevToolsUtils.isMock( context ) ) {
                AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("districtadmin_rvc", "password1");
                String json = DevToolsUtils.readJsonResponse("mathPerformance.json");
                Log.message(json);
                DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetPerformanceReport", "post", json);
                tools.createSessionIfThereIsNotOne();
                Log.message(tools.getCdpSession().toString());

                dashBoardPage.expandSubjectDropdown();
                dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );

                Log.assertThat( verifyAverageValue( json,dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Reading assignments data as expected for All organization",
                        "Performance Report widget shows wrong Reading assignments data for All organization" );

                RequestMockUtils.closeMock(tools);
            } else {
                // Login into SM using admin credential
                AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );

                // Selecting single organization and Math subject
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                dashBoardPage.enterTextInSearchTextBox( flexSchool );
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool ) );
                dashBoardPage.clickApplySelectionButton();
                SMUtils.logDescriptionTC( "Verify performance report widget shows the Math assignments data correctly when single org is selected and Math subject is selected" );
                SMUtils.logDescriptionTC( "Verify performance report widget should show proper performance data when students are completed IPM in the selected school and IP level and current course level is same" );
                Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "1" ), "Performance Report widget shows the Math assignments data as expected for single organization",
                        "Performance Report widget shows wrong Math assignments data for single organization" );

                //            Selecting multi organization and Math subject
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                //            dashBoardPage.enterTextInSearchTextBox( flexSchool );
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool, orgTwoName ) );
                dashBoardPage.clickApplySelectionButton();
                SMUtils.logDescriptionTC( "Verify performance report widget shows the Math assignments data correctly when multiple orgs are selected and Math subject is selected" );
                Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId, orgTwoId ), "1" ), "Performance Report widget shows the Math assignments data as expected for multiple organizations",
                        "Performance Report widget shows wrong Math assignments data for multiple organizations" );

                // Selecting multi organization and Reading subject
                dashBoardPage.expandSubjectDropdown();
                dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
                SMUtils.logDescriptionTC( "Verify performance report widget shows the Reading assignments data correctly when multiple orgs are selected and Reading subject is selected" );
                Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId, orgTwoId ), "2" ), "Performance Report widget shows the Reading assignments data as expected for multiple organizations",
                        "Performance Report widget shows wrong Reading assignments data for multiple organizations" );

                // Selecting single organization and Reading subject
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                dashBoardPage.enterTextInSearchTextBox( flexSchool );
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool ) );
                dashBoardPage.clickApplySelectionButton();
                dashBoardPage.expandSubjectDropdown();
                dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
                SMUtils.logDescriptionTC( "Verify performance report widget shows the Reading assignments data correctly when single org is selected and Reading subject is selected" );
                Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "2" ), "Performance Report widget shows the Reading assignments data as expected for single organization",
                        "Performance Report widget shows wrong Reading assignments data for single organization" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for custom by setting IPM ON couses", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget", "smoke_test_case" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration002() throws Exception {

        // Executing Math custom by setting IPM ON course
        executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true, true );

        // Executing Reading custom by setting IPM ON course
        executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false, true );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration002: Verify the Performance Report widget data for custom by setting IPM ON couses. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            // Selecting single organization and Math subject
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( flexSchool );
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            dashBoardPage.clickApplySelectionButton();
            SMUtils.logDescriptionTC( "Verify performance report widget shows the Math custom by settings -IP ON assignments data correctly when single org is selected and Math subject is selected" );
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "1" ), "Performance Report widget shows IP ON assignments data as expected for single organization",
                    "Performance Report widget shows wrong IP ON assignments data for single organization" );

            // Selecting multi organization and Math subject
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool, orgTwoName ) );
            dashBoardPage.clickApplySelectionButton();            
            SMUtils.logDescriptionTC( "Verify performance report widget shows the Math custom by settings -IP ON assignments data correctly when multiple orgs are selected and Math subject is selected" );
                        Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId, orgTwoId ), "1" ), "Performance Report widget shows IP ON assignments data as expected for multiple organizations",
                                "Performance Report widget shows wrong IP ON assignments data for multiple organizations" );

                        // Selecting multi organization and Reading subject
                        dashBoardPage.expandSubjectDropdown();
                        dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
                        SMUtils.logDescriptionTC( "Verify performance report widget shows the Reading custom by settings - IP On assignments data correctly when multiple orgs are selected and Reading subject is selected" );
                        Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId, orgTwoId ), "2" ), "Performance Report widget shows IP ON assignments data as expected for multiple organizations",
                                "Performance Report widget shows wrong IP ON assignments data for multiple organizations" );

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
            SMUtils.logDescriptionTC( "Verify performance report widget shows the Reading custom by setting (IP ON) assignments data correctly when single org is selected and Reading subject is selected" );
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "2" ), "Performance Report widget shows IP ON assignments data as expected for single organization",
                    "Performance Report widget shows wrong IP ON assignments data for single organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for custom by setting IPM OFF couses", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration003() throws Exception {

        // Executing Math custom by setting IPM ON course
        executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), customMathCourse, true, true );

        // Executing Reading custom by setting IPM ON course
        executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), customReadingCourse, false, true );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration003: Verify the Performance Report widget data for custom by setting IPM OFF couses. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "Verify performance report widget shows the Math assignments performance data correctly for school admin" );
            SMUtils.logDescriptionTC( "Verify performance report widget should not shows the Math custom by settings -IP OFF assignments data when single org is selected and Math subject is selected" );
            // Selecting single organization and Math subject
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "1" ), "Performance Report widget is not showing IP OFF assignments data as expected for school admin",
                    "Not As Expected: Performance Report widget shows IP OFF Math assignments data for school admin" );

            SMUtils.logDescriptionTC( "Verify performance report widget should not shows the Reading custom by settings -IP OFF assignments data when single org is selected and Reading subject is selected" );
            // Selecting Reading subject
            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
            SMUtils.logDescriptionTC( "Verify performance report widget is not showing IP OFF assignments data when multiple orgs are selected and Reading subject is selected" );
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "2" ), "Performance Report widget shows the Reading assignments data as expected for single organization",
                    "Not As Expected: Performance Report widget shows IP OFF Reading assignments data for single organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget", "smoke_test_case" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration004() throws Exception {

        // update student grade
        HashMap<String, String> studentInfos = new HashMap<>();
        studentInfos = generateRequestValues( student1Details );
        studentInfos.put( UserConstants.TEACHER_ID, teacherId );
        studentInfos.put( UserConstants.SCHOOLID, flexSchoolId );
        studentInfos.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> updateStudentProfile = new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
        Log.message( "Grade Updated " + updateStudentProfile );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration004: Verify the Performance Report widget data. <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "Verify performance report widget shows the Math assignments performance data correctly for multiple school admin" );
            SMUtils.logDescriptionTC( "Verify performance report widget shows the Math/Reading assignments data correctly after changing student grade" );
            // Selecting single organization and Math subject
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "1" ), "Performance Report widget displayed assignments data after grade change as expected for multiple school admin",
                    "Performance Report widget shows wrong Math assignments data after grade change  for multiple school admin" );

            // Selecting Reading subject
            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "2" ), "Performance Report widget shows the Reading assignments data as expected for single organization",
                    "Performance Report widget shows wrong Reading assignments data for single organization" );

            SMUtils.logDescriptionTC( "Verify performance report widget shows the Math assignments data correctly for the orphan student" );
            //delete Student from all groups
            HashMap<String, String> studentDetails = new HashMap<>();
            studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
            studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, flexSchoolId );
            studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            studentDetails.put( GroupConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( student3Details, "userId" ) );
            HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
            List<String> groupIds = new ArrayList<>();
            IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach(
                    iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

            groupIds.stream().forEach( groupId -> {
                try {
                    new GroupAPI().removeStudentFromGroup( smUrl, SMUtils.getKeyValueFromResponse( student3Details, "userId" ), groupId, teacherId, flexSchoolId,
                            new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                } catch ( Exception e ) {
                    e.printStackTrace();
                }
            } );

            // Selecting single organization and Math subject
            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );

            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "1" ), "Performance Report widget shows the Math assignments data as expected for an organization which has orphan student",
                    "Performance Report widget shows wrong Math assignments data for an organization which has orphan student" );

            SMUtils.logDescriptionTC( "Change MCL for custom by setting IPM ON Math/Reading course and Verify performance report widget shows the assignments performance data correctly" );
            // Manually Setting Course Level
            HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
            assignmentSettings.put( "MANUALLY_SET_COURSE_LEVEL", "TRUE" );
            assignmentSettings.put( "MANUALLY_SET_COURSE_LEVEL_SLIDER", "3.5" );

            staffDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) );

            HashMap<String, String> updateAssignmentUserSettingsResponse = new AssignmentAPI().updateAssignmentUserSettings( smUrl, staffDetails, assignmentSettings, Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ),
                    AssignmentAPIConstants.MATH_COURSE );
            Log.message( "MCL updated: " + updateAssignmentUserSettingsResponse.get( Constants.REPORT_BODY ) );

            // Selecting single organization and Math subject
            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );
            Log.assertThat( verifyAverageValue( dashBoardPage.getCurrentCourseAvrgValue(), Arrays.asList( flexSchoolId ), "1" ),
                    "Performance Report widget shows the assignments data as expected after changing MCL for custom by setting IPM ON Math/Reading course",
                    "Performance Report widget shows wrong assignments data after changing MCL for custom by setting IPM ON Math/Reading course" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for Sub District with school admin", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget", "smoke_test_case" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration005() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration005: Verify the Performance Report widget data for Sub District with school admin. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( subDistrictAdminWithSchoolDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message for sub district admin without school" );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( "Performance Report" ), "Performance Report is displayed for sub district admin", "Performance Report is not displayed for sub district admin" );

            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message when none of the students are not completed IPM in Math custom by settings -IP ON course for the selected school" );
            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message when none of the students are not completed IPM in Math course for the selected school" );
            Log.assertThat( dashBoardPage.getPerformanceReportZeroStateMessage().equals( AdminUIConstants.Dashboard.PERFORMANCE_REPORT_ZERO_STATE_MESSAGE ), "Zero state message is displayed when none of the students are not completed the Math assignment",
                    "Zero state message is not displayed when none of the students are not completed the Math assignment" );

            dashBoardPage.clickOrganizationNameFromDropdownOnAdminDashboard( subDistrictwithSchool_name );
            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message when none of the students are not completed IPM in Reading custom by settings -IP ON course for the selected school" );
            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message when none of the students are not completed IPM in Reading course for the selected school" );
            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
            Log.assertThat( dashBoardPage.getPerformanceReportZeroStateMessage().equals( AdminUIConstants.Dashboard.PERFORMANCE_REPORT_ZERO_STATE_READING_MESSAGE ), "Zero state message is displayed when none of the students are not completed the Reading assignment",
                    "Zero state message is not displayed when none of the students are not completed the Reading assignment" );

            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for Sub District without school admin", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration006() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration006: Verify the Performance Report widget data for Sub District without school admin. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message for sub district admin without school" );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( "Performance Report" ), "Performance Report is displayed for sub district admin", "Performance Report is not displayed for sub district admin" );

            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message when none of the students got assignment in the selected school" );
            Log.assertThat( dashBoardPage.getPerformanceReportZeroStateMessage().equals( AdminUIConstants.Dashboard.PERFORMANCE_REPORT_ZERO_STATE_MESSAGE ), "Zero state message is displayed when none of the students are not completed the assignment",
                    "Zero state message is not displayed when none of the students are not completed the assignment" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify performance report widget should show zero state message in Math course for the selected school", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration007() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration007: Verify performance report widget should show zero state message for Grade K in the chart when Grade K students are not completed IPM in Math course for the selected school <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message for Grade K in the chart when Grade K students are not completed IPM in Math course for the selected school" );
            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message for Grade K in the chart when Grade K students are not completed IPM in Math custom by settings -IP ON course for the selected school" );
            // Selecting single organization and Math subject
            List<String> mathPerformanceReportData = dashBoardPage.getNoDataToDisplayText();
            Log.assertThat( mathPerformanceReportData.contains(AdminUIConstants.Dashboard.NO_PERFORMANCE_MESSAGE), "Zero state message for Grades that are not completed Math IPM are displayed",
                    "Not As Expected: All students have Math data for Performace report" );

            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message for Grade K in the chart when Grade K students are not completed IPM in Reading course for the selected school" );
            SMUtils.logDescriptionTC( "Verify performance report widget should show zero state message for Grade K in the chart when Grade K students are not completed IPM in Reading custom by settings -IP ON course for the selected school" );
            // Selecting Reading subject
            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );
            List<String> readingPerformanceReportData = dashBoardPage.getNoDataToDisplayText();
            Log.assertThat( readingPerformanceReportData.contains(AdminUIConstants.Dashboard.NO_PERFORMANCE_MESSAGE), "Zero state message for Grades that are not completed Reading IPM are displayed",
                    "Not As Expected: All students have Reading data for Performace report" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To verify the average value of current course level
     * 
     * @param averageValueFromUI
     * @param selectedOrgIds
     * @param subjectTypeId
     * @return
     * @throws Exception
     */
    public boolean verifyAverageValue( List<String> averageValueFromUI, List<String> selectedOrgIds, String subjectTypeId ) throws Exception {

        // Getting Performance Report from BFF
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String authToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Auth token is " + authToken );
        headers.put( Constants.AUTHORIZATION, "Bearer " + authToken );
        Response performanceReportBFFResponse = new Dashboard().postPerformanceReportBFF( headers, selectedOrgIds, SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID ),
                SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "primaryOrgId" ), subjectTypeId );
        Log.message( performanceReportBFFResponse.getBody().asString() );

        DecimalFormat df = new DecimalFormat( "0.00" );
        String performanceValue = SMUtils.getKeyValueFromResponse( performanceReportBFFResponse.getBody().asString(), "data,getPerformanceReport" );
        List<String> averageValues = new ArrayList<>();
        IntStream.range( 0, SMUtils.getWordCount( performanceValue, "currentLevel" ) ).forEach( iter -> {
            if ( iter == 0 ) {
                averageValues.add( SMUtils.getKeyValueFromResponse( performanceValue, "grade_k,currentLevel" ) );
            } else {
                averageValues.add( SMUtils.getKeyValueFromResponse( performanceValue, "grade_" + iter + ",currentLevel" ) );
            }
        } );
        averageValues.removeIf( value -> value.equals( "null" ) );

        List<String> averageDecimalValues = new ArrayList<>();
        IntStream.range( 0, averageValues.size() ).forEach( itr -> {
            String value = df.format( Double.parseDouble( averageValues.get( itr ) ) );
            averageDecimalValues.add( value );
        } );
        Log.message( "Average value from API: " + averageDecimalValues );
        Log.message( "Average value from UI: " + averageValueFromUI );
        return SMUtils.compareTwoList( averageValueFromUI, averageDecimalValues );
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "100", "4", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "5" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Reading Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "100", "4", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "5" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData ) {

        HashMap<String, String> generatedStudentDetails = new HashMap<>();
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    @Test ( description = "Verify the Performance Report widget data for Single Oraganization and Math Subject.", groups = { "SMK-66819", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration016() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration002:  <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );

            //selecting single organization
            dashBoardPage.expandOrganizationDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( "#School Number 1" );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( "#School Number 1" ) );
            dashBoardPage.clickApplySelectionButton();

            String json = DevToolsUtils.readJsonResponse( "mathPerformance.json" );
            Log.message( json );
            DevTools tools = RequestMockUtils.setResponse( driver, configGraphQL, "getPerformanceReport", "post", json );
            tools.createSessionIfThereIsNotOne();
            Log.message( tools.getCdpSession().toString() );

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );

            Log.assertThat( verifyAverageValue( json, dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Math assignments data as expected for single organization",
                    "Performance Report widget shows wrong Math assignments data for single organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for Multi Oraganization and Math Subject.", groups = { "SMK-66819", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration003: Verify the Performance Report widget data for Multi Oraganization and Math Subject. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );

            //selecting single organization
            dashBoardPage.expandOrganizationDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( "SM Auto School SME187 - Math-19" );
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( "SM Auto School SME187 - Math-19" ) );
            dashBoardPage.clickApplySelectionButton();

            String json = DevToolsUtils.readJsonResponse( "mathPerformance.json" );
            Log.message( json );
            DevTools tools = RequestMockUtils.setResponse( driver, configGraphQL, "getPerformanceReport", "post", json );
            tools.createSessionIfThereIsNotOne();
            Log.message( tools.getCdpSession().toString() );

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );

            Log.assertThat( verifyAverageValue( json, dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Math assignments data as expected for Multi organization",
                    "Performance Report widget shows wrong Math assignments data for Multi organization" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for SubDistrict Admin - Math", groups = { "SMK-66819", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration004: Verify the Performance Report widget data for SubDistrict Admin. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );

            String json = DevToolsUtils.readJsonResponse( "mathPerformance.json" );
            Log.message( json );
            DevTools tools = RequestMockUtils.setResponse( driver, configGraphQL, "getPerformanceReport", "post", json );
            tools.createSessionIfThereIsNotOne();
            Log.message( tools.getCdpSession().toString() );

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );

            Log.assertThat( verifyAverageValue( json, dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Math assignments data as expected for Sub District Admin",
                    "Performance Report widget shows wrong Math assignments data for Sub District Admin" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for School  Admin - Math", groups = { "SMK-66819", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration005: Verify the Performance Report widget data for School  Admin. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( "districtadmin_rvc", "password1" );

            String json = DevToolsUtils.readJsonResponse( "mathPerformance.json" );
            Log.message( json );
            DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "getPerformanceReport", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message( tools.getCdpSession().toString() );

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.MATH );

            Log.assertThat( verifyAverageValue( json, dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Math assignments data as expected for School Admin",
                    "Performance Report widget shows wrong Math assignments data for School Admin" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To verify the average value of current course level
     *
     * @param averageValueFromUI
     * @param jsonfile
     * @return
     * @throws Exception
     */
    public boolean verifyAverageValue( String jsonfile, List<String> averageValueFromUI ) throws Exception {

        DecimalFormat df = new DecimalFormat( "0.00" );
        String performanceValue = SMUtils.getKeyValueFromResponse( jsonfile, "data,getPerformanceReport" );
        List<String> averageValues = new ArrayList<>();
        IntStream.range( 0, SMUtils.getWordCount( performanceValue, "currentLevel" ) ).forEach( iter -> {
            if ( iter == 0 ) {
                averageValues.add( SMUtils.getKeyValueFromResponse( performanceValue, "grade_k,currentLevel" ) );
            } else {
                averageValues.add( SMUtils.getKeyValueFromResponse( performanceValue, "grade_" + iter + ",currentLevel" ) );
            }
        } );
        averageValues.removeIf( value -> value.equals( "null" ) );

        List<String> averageDecimalValues = new ArrayList<>();
        IntStream.range( 0, averageValues.size() ).forEach( itr -> {
            String value = df.format( Double.parseDouble( averageValues.get( itr ) ) );
            averageDecimalValues.add( value );
        } );
        Log.message( "Average value from Mock request: " + averageDecimalValues );
        Log.message( "Average value from UI: " + averageValueFromUI );
        return SMUtils.compareTwoList( averageValueFromUI, averageDecimalValues );
    }

    @Test ( description = "Verify the Performance Report widget data for default course - Reading", groups = { "SMK-66805", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration001: Verify the Performance Report widget data for All Organization and Reading Subject. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("districtadmin_rvc", "password1");
            String json = DevToolsUtils.readJsonResponse("readingPerformance.json");
            Log.message(json);
            DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetPerformanceReport", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );

            Log.assertThat( verifyAverageValue( json,dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Reading assignments data as expected for All organization",
                    "Performance Report widget shows wrong Reading assignments data for All organization" );

            RequestMockUtils.closeMock(tools);

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Performance Report widget data for default course - Reading", groups = { "SMK-66805", "adminDashboard", "performanceReportWidget", "mock"}, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration012() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration002: Verify the Performance Report widget data for Single Oraganization and Reading Subject. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("districtadmin_rvc", "password1");
            //selecting single organization
            dashBoardPage.expandOrganizationDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox("RVC Auto Regression School - READING");
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList("RVC Auto Regression School - READING"));
            dashBoardPage.clickApplySelectionButton();

            String json = DevToolsUtils.readJsonResponse("readingPerformance.json");
            Log.message(json);
            DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "getPerformanceReport", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );

            Log.assertThat( verifyAverageValue( json,dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Reading assignments data as expected for single organization",
                    "Performance Report widget shows wrong Reading assignments data for single organization" );

            RequestMockUtils.closeMock(tools);
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( description = "Verify the Performance Report widget data for default course - Reading", groups = { "SMK-66805", "adminDashboard", "performanceReportWidget","mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration013() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration003: Verify the Performance Report widget data for Multi Oraganization and Reading Subject. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("districtadmin_rvc", "password1");
            //selecting single organization
            dashBoardPage.expandOrganizationDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox("SM Auto School SME187 - Reading-19");
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList("SM Auto School SME187 - Reading-19"));
            dashBoardPage.clickApplySelectionButton();

            String json = DevToolsUtils.readJsonResponse("readingPerformance.json");
            Log.message(json);
            DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "getPerformanceReport", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );

            Log.assertThat( verifyAverageValue( json,dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Reading assignments data as expected for Multi organization",
                    "Performance Report widget shows wrong Reading assignments data for Multi organization" );

            RequestMockUtils.closeMock(tools);
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( description = "Verify the Performance Report widget data for default course - Reading", groups = { "SMK-51729", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration014() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration004: Verify the Performance Report widget data for SubDistrict Admin. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecsubdistrictadmin99@nightlynextbasic", "testing123$");
            String json = DevToolsUtils.readJsonResponse("readingPerformance.json");
            Log.message(json);
            DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "getPerformanceReport", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );

            Log.assertThat( verifyAverageValue( json,dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Reading assignments data as expected for Sub District Admin",
                    "Performance Report widget shows wrong Reading assignments data for Sub District Admin" );

            RequestMockUtils.closeMock(tools);

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( description = "Verify the Performance Report widget data for default course - Reading", groups = { "SMK-66805", "adminDashboard", "performanceReportWidget", "mock" }, priority = 1 )
    public void tcSMPerformanceReportAPIIntegration015() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReportAPIIntegration005: Verify the Performance Report widget data for School  Admin. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecschooladmincustom051@nightlynextbasic", "testing123$");
            String json = DevToolsUtils.readJsonResponse("readingPerformance.json");
            Log.message(json);
            DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "getPerformanceReport", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());

            dashBoardPage.expandSubjectDropdown();
            dashBoardPage.selectOptionInSubjectDropdown( Constants.READING );

            Log.assertThat( verifyAverageValue( json,dashBoardPage.getCurrentCourseAvrgValue() ), "Performance Report widget shows the Reading assignments data as expected for School Admin",
                    "Performance Report widget shows wrong Reading assignments data for School Admin" );

            RequestMockUtils.closeMock(tools);

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
