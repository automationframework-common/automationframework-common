package com.savvas.sm.admin.api.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

public class PostOrganizationUsageTest extends EnvProperties {

    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String flexSchool;
    private String mathSchool;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();

    private List<String> courseIDs = new ArrayList<>();
    private Map<String, String> response = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String exception = null;
    private String message = null;

    @BeforeClass(alwaysRun = true)
    public void beforeClass() throws Exception {
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        Log.message( "Assignment IDs - " + assignmentIds );

        //Creating data for math School
        String mathSchoolTeacherDetails = RBSDataSetup.orgTeacherDetails.get( mathSchool ).get( "Teacher1" );
        String mathSchoolTeacherId = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, "userId" );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, mathSchoolTeacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathSchoolTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) ), AssignmentAPIConstants.USERS_TYPE );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );

        executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        
        FixupFunction.executeFixupFunctions( orgId );


    }

    /**
     * This method is used to test the Organization Usage API.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "organizationUsagepositiveScenario", groups = { "smoke_test_case", "OrganizationUsage", "SMK-51757", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgId" );
        } else {
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }

        List<String> studentIds;

        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        switch ( scenario ) {
            case "FOR_SINGLE_STUDENT":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "FOR_MULTIPLE_STUDENTS":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "ZERO_STATE":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "AFTER_DELETE_THE_STUDENT'S_ASSIGNMENT":

                //delete assignment
                HashMap<String, String> assignmentDetail = new HashMap<>();
                assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID,
                        new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), assignmentIds.get(contentBaseName.get(  AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE  )) ) );
                new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "AFTER_DELETE_THE_GROUP'S_ASSIGNMENT":

                //adding the student to the  group for the  teacher
                String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userId" ) ),
                        RBSDataSetup.organizationIDs.get( flexSchool ), new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                //Assigning the assignment
                String courseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID,
                        new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId,
                                orgId, DataSetupConstants.SETTINGS, courseName ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //execute course through student dashboard
                executeCourse( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userName" ), courseName, true );
                assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, newGroupId );

                //delete assignment from group
                new AssignmentAPI().deleteAssignmentfromGroup( smUrl, assignmentDetails, "" );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student4" ), "userId" ) );

                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "ORPHAN_STUDENT":

                //delete Student from all groups
                HashMap<String, String> studentDetails = new HashMap<String, String>();
                studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
                studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( GroupConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
                List<String> groupIds = new ArrayList<>();
                IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach(
                        iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

                groupIds.stream().forEach( groupId -> {
                    try {
                        new GroupAPI().removeStudentFromGroup( smUrl, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ), groupId, teacherId, orgId,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    } catch ( Exception e ) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                } );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "SCHOOL_ADMIN":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "MULTIPLE_SCHOOL_ADMIN":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
                break;

            case "SUBDISTRICT_ADMIN":

                //Creating teacher and student
                String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
                String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

                //creating student
                String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
                String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

                //Creating group  for above created teacher & student
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                        new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
                HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( assignAssignment.toString() );

                executeCourse( subdistrictSchoolStudent, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, RBSDataSetup.subDistrictwithSchoolId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( subdistrictSchoolStudentId );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>(), studentIds );
            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        //Schema validation
        if ( !scenario.equalsIgnoreCase( "ZERO_STATE" ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "PostOrganizationUsageSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        } else {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

            //Exception validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION ), "Exception Verified successfully!",
                    "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

            //Message Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( "Student usage not found" ), "Message Verified successfully!",
                    "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );
        }
    }

    @DataProvider ( name = "organizationUsagepositiveScenario" )
    public Object[][] organizationUsagepositiveScenario() {

        Object[][] inputData = { { "tc_OrganizationUsage001", "Verify the status code and response, if pass the single student in the request body.", "FOR_SINGLE_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage002", "Verify the status code and response, if pass the multiple students in the request body.", "FOR_MULTIPLE_STUDENTS", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage003", "Verify the status code and response, if pass the organizations which is not having usage data", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage004", "Verify the response, after delete the assignment for some students", "AFTER_DELETE_THE_STUDENT'S_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage005", "Verify the response, after delete the assignment for group", "AFTER_DELETE_THE_GROUP'S_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage006", "Verify the response, if the give the orphan student id", "ORPHAN_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage007", "Verify the 200 status code and response, if pass the school admin credential.", "SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.SCHOOL_ADMIN },
                { "tc_OrganizationUsage008", "Verify the 200 status code and response, if pass the multiple school admin credential.", "MULTIPLE_SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.MULTI_SCHOOL_ADMIN },
                { "tc_OrganizationUsage009", "Verify the 200 status code and response, if pass the subdistrict admin credential.", "SUBDISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.SUBDISTRICTWITHSCHOOL_ADMIN } };
        return inputData;
    }

    /**
     * This method is used to test the Organization Usage API.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "organizationNegativeScenario", groups = { "OrganizationUsage", "SMK-51757", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        List<String> studentIds;

        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        switch ( scenario ) {

            case "INVALID_USERID":

                headers.put( UserConstants.USERID, "" );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "EMPTY_ORGID":
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, "" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_ACCESS_TOKEN":
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token + "invalid" );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );

                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "WITH_STUDENT_CREDENTIAL":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_TEACHER_CREDENTIAL":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userId" ),
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ), SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student3" ), "userId" ) );
                response = new Dashboard().postOrganizationUsage( smUrl, headers, studentIds );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;
            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        //Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        //Schema Validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getStudentUsageSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        //Exception validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( exception ), "Exception Verified successfully!",
                "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

        //Status Validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,status" ).equalsIgnoreCase( "failure" ), "Status Verified successfully!", "Issue in displaying Status!" );

        //message Validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( message ), "Message Verified successfully!",
                "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );

    }

    @DataProvider ( name = "organizationNegativeScenario" )
    public Object[][] organizationNegativeScenario() {

        Object[][] inputData = { { "tc_OrganizationUsage010", "Verify status code 401 when   user id is not passed in header parameter", "INVALID_USERID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage011", "Verify status code 401 when SSO token is not passed in header parameter", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage012", "Verify status code 400 when Org ID is not passed in query parameter", "EMPTY_ORGID", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage013", "Verify status code 403 when User ID is student rumba id in headers", "WITH_STUDENT_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsage014", "Verify status code 403 when User ID is teacher rumba id in headers", "WITH_TEACHER_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN } };
        return inputData;
    }

    /**
     * To verify the response with DB
     * 
     */
    private void verifyResponseWithDB( String response, List<String> assignmentIds, List<String> studentIds ) {
        Map<String, Map<String, String>> usageDetailsFromResponse = new HashMap<>();
        String reponseData = SMUtils.getKeyValueFromResponse( response, "data" );
        IntStream.rangeClosed( 0, 7 ).forEach( iter -> {
            Map<String, String> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( iter );
            subjectUsage.put( StudentUsage.MATH_MINS, jObj.get( StudentUsage.MATH_MINS ).toString() );
            subjectUsage.put( StudentUsage.READING_MINS, jObj.get( StudentUsage.READING_MINS ).toString() );
            usageDetailsFromResponse.put( jObj.get( StudentUsage.WEEK ).toString(), subjectUsage );
        } );
        Map<String, String> individualFields = new HashMap<>();

        individualFields.put( StudentUsage.THIS_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.THIS_WEEK_MINS ) );
        individualFields.put( StudentUsage.LAST_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.LAST_WEEK_MINS ) );
        individualFields.put( StudentUsage.TOTAL_MINTUES, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.TOTAL_MINTUES ) );
        usageDetailsFromResponse.put( "individualFields", individualFields );

        Map<String, Map<String, String>> usageDetailsFromDB = new SqlHelperUsage().getStudentUsage( assignmentIds, studentIds );

        Log.message( "usage Data from Db - " + usageDetailsFromDB );

        Log.assertThat( usageDetailsFromDB.entrySet().stream().allMatch( entry -> {
            if ( entry.getValue().containsKey( StudentUsage.MATH_MINS ) ) {
                int mathDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.MATH_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.MATH_MINS ) );
                int readDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.READING_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.READING_MINS ) );
                return ( mathDeviation >= -1 && mathDeviation <= 1 ) && ( readDeviation >= -1 && readDeviation <= 1 );
            } else if ( entry.getValue().containsKey( StudentUsage.THIS_WEEK_MINS ) ) {
                int thisWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.THIS_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.THIS_WEEK_MINS ) );
                int lastWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.LAST_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.LAST_WEEK_MINS ) );
                int toatalMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.TOTAL_MINTUES ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.TOTAL_MINTUES ) );
                return ( thisWeekMinsDeviation >= -2 && thisWeekMinsDeviation <= 2 ) && ( lastWeekMinsDeviation >= -2 && lastWeekMinsDeviation <= 2 ) && ( toatalMinsDeviation >= -2 && toatalMinsDeviation <= 2 );
            } else {
                return false;
            }
        } ), "Usage data are fetched properly", "Usage data are not fetched properly. Expected -" + usageDetailsFromDB.toString() + ": Actual -" + usageDetailsFromResponse.toString() );
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "5" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "5" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

}
