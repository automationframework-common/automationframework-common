package com.savvas.sm.admin.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SharedCourses;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SharedCourses.SHARED_COURSE_TABLE_HEADER;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.utils.SMUtils;

public class SharedCoursesListViewPage extends LoadableComponent<SharedCoursesListViewPage> {

    boolean isPageLoaded;
    private final WebDriver driver;

    // ********* SuccessMaker Shared Courses Page Elements ***************

    @FindBy ( css = "h1.header" )
    WebElement sharedCoursesHeader;

    @FindBy ( css = "form.searchBar__form input" )
    WebElement searchBox;

    @FindBy ( css = ".th-action-button cel-button" )
    WebElement btnEditRoot;

    @FindBy ( css = "thead .table-row .d-flex" )
    List<WebElement> sharedCoursesTableHeader;

    @FindBy ( css = "div.not-found" )
    WebElement notFoundText;

    @FindBy ( css = "input[placeholder]" )
    WebElement searchBarPlaceHolder;

    @FindBy ( css = "cel-icon.arrow-up" )
    WebElement upArrow;

    @FindBy ( css = "cel-icon.arrow-down" )
    WebElement downArrow;

    @FindBy ( css = "shared-courses-list cel-paginator.pagination" )
    WebElement paginationRoot;

    @FindBy ( css = "ul.side-nav" )
    WebElement sideNav;

    @FindBy ( css = "ul.side-nav li span" )
    List<WebElement> subNavList;

    @FindBy ( css = "li.side-nav-wrapper-active" )
    WebElement selectedSideNavBar;

    @FindBy ( css = "side-nav-wrapper-inactive" )
    List<WebElement> subNavbar;

    // ********* Child elements for shadow root *********

    String secondaryButton = "button.secondary_button";
    String tableList = "tbody tr td:nth-of-type(%s) span";
    String countOfSharedCourses = "span.page-items";
    String conutOfPages = "div.page-navigation span";
    String preBackwardButton = "button.first";
    String backButton = "button.previous";
    String nextButton = "button.next";
    String fastForwardButton = "button.last";
    String childBtnEdit = ".th-action-button cel-button";

    /**
     * Constructor to load driver and components
     * 
     * @param driver
     */
    public SharedCoursesListViewPage( WebDriver driver ) {
        this.driver = driver;
        // To init elements
        PageFactory.initElements( driver, this );
    }

    /**
     * Verify the page load
     */
    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, sharedCoursesHeader, 30 );
    }

    /**
     * Verifying the page is loaded.
     */
    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();

        }

        if ( SMUtils.waitForElement( driver, sharedCoursesHeader, 30 ) ) {
            Log.message( "Shared Courses list view page loaded successfully." );
        } else {
            Log.fail( "Shared Courses list view page did not load." );
        }

    }

    /**
     * To verify whether search box is present or not
     * 
     * @return
     */
    public boolean isSearchBoxDisplayed() {
        SMUtils.waitForElement( driver, searchBox );
        Log.message( "Verifying whether search box is displayed or not" );
        return searchBox.isDisplayed();
    }

    /**
     * To enter a course name in search box
     * 
     * @param sharedCourseName
     */
    public void enterValueInSearchBox( String sharedCourseName ) {
        SMUtils.waitForElement( driver, searchBox );
        searchBox.clear();
        searchBox.sendKeys( sharedCourseName );
        Log.message( sharedCourseName + " is entered in search box" );
    }

    /**
     * To get the value entered in the search box
     * 
     * @return
     */
    public String getValueEnteredInSearchBox() {
        SMUtils.waitForElement( driver, searchBox );
        String valueEntered = searchBox.getAttribute( "value" );
        Log.message( valueEntered + " is entered in search box" );
        return valueEntered;
    }

    /**
     * To get shared course list view table header
     * 
     * @return
     */
    public List<String> getSharedCoursesTableHeader() {
        SMUtils.waitForElement( driver, btnEditRoot );
        return sharedCoursesTableHeader.stream().map( header -> header.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get not found message when invalid shared course name entered
     * 
     * @return
     */
    public String getInvalidSearchMsgTxt() {
        SMUtils.waitForElement( driver, notFoundText );
        Log.message( "Getting invalid search message text" );
        return notFoundText.getText().trim();
    }

    /**
     * To get place holder text in search bar
     * 
     * @return
     */
    public String getSearchBarPlaceHolderTxt() {
        SMUtils.waitForElement( driver, searchBarPlaceHolder, 10 );
        Log.message( "Getting default text from search bar" );
        return searchBarPlaceHolder.getAttribute( "placeholder" );
    }

    /**
     * To verify whether edit button is present in shared courses list view
     * table
     * 
     * @return
     */
    public boolean isEditBtnDisplayed() {
        SMUtils.waitForElement( driver, btnEditRoot );
        Log.message( "Verifying the presence of Edit button in shared courses list view table" );
        return SMUtils.getWebElementDirect( driver, btnEditRoot, secondaryButton ).isDisplayed();
    }

    /**
     * To sort the column in Shared Courses table
     * 
     * @param columnName
     */
    public void sortTableColumn( SharedCourses.SHARED_COURSE_TABLE_HEADER columnName ) {
        SMUtils.waitForElement( driver, btnEditRoot );
        SMUtils.click( driver, sharedCoursesTableHeader.get( columnName.ordinal() ) );
        Log.message( columnName + " column is clicked in Shared Course list table" );
    }

    /**
     * To verify the column is in ascending order
     * 
     * @return
     */
    public boolean isColumnInAscendingOrder() {
        SMUtils.waitForElement( driver, upArrow );
        Log.message( "Verifying the column is arranged in ascending order" );
        return SMUtils.isElementPresent( upArrow );
    }

    /**
     * To verify the column is in descending order
     * 
     * @return
     */
    public boolean isColumnInDescendingOrder() {
        SMUtils.waitForElement( driver, downArrow );
        Log.message( "Verifying the column is arranged in descending order" );
        return SMUtils.isElementPresent( downArrow );
    }

    /**
     * To get the list of values form Shared Courses table
     * 
     * @param headerName
     * @return
     */
    public List<String> getListFromTable( SharedCourses.SHARED_COURSE_TABLE_HEADER headerName ) {
        SMUtils.waitForElement( driver, btnEditRoot );
        List<WebElement> elements = driver.findElements( By.cssSelector( String.format( tableList, headerName.ordinal() + 1 ) ) );
        return SMUtils.getAllTextFromWebElementList( elements );
    }

    /**
     * To Verify the Pre-backward button is Enabled
     *
     * @return
     */
    public boolean isPreBackwardButtonEnabled() {
        SMUtils.waitForElement( driver, paginationRoot );
        Log.message( "Verifying the pre-backward button!" );
        return !Boolean.valueOf( SMUtils.getAttributeOfWebElement( SMUtils.getWebElementDirect( driver, paginationRoot, preBackwardButton ), driver, SharedCourses.ARIA_DISABLED ) );
    }

    /**
     * To click the Pre-backward button
     */
    public void clickPreBackwardButton() {
        SMUtils.waitForElement( driver, paginationRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, paginationRoot, preBackwardButton ) );
        Log.message( "Clicked pre-backward button!" );
    }

    /**
     * To Verify the backward button is Enabled
     *
     * @return
     */
    public boolean isBackwardButtonEnabled() {
        SMUtils.waitForElement( driver, paginationRoot );
        Log.message( "Verifying the backward button!" );
        return !Boolean.valueOf( SMUtils.getAttributeOfWebElement( SMUtils.getWebElementDirect( driver, paginationRoot, backButton ), driver, SharedCourses.ARIA_DISABLED ) );
    }

    /**
     * To click the backward button
     */
    public void clickBackwardButton() {
        SMUtils.waitForElement( driver, paginationRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, paginationRoot, backButton ) );
        Log.message( "Clicked backward button!" );
    }

    /**
     * To Verify the forward button is Enabled
     *
     * @return
     */
    public boolean isForwardButtonEnabled() {
        SMUtils.waitForElement( driver, paginationRoot );
        Log.message( "Verifying the forward button!" );
        return !Boolean.valueOf( SMUtils.getAttributeOfWebElement( SMUtils.getWebElementDirect( driver, paginationRoot, nextButton ), driver, SharedCourses.ARIA_DISABLED ) );
    }

    /**
     * To click the forward button
     */
    public void clickForwardButton() {
        SMUtils.waitForElement( driver, paginationRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, paginationRoot, nextButton ) );
        Log.message( "Clicked forward button!" );
    }

    /**
     * To Verify the fast forward button is Enabled
     * 
     * @return
     */
    public boolean isFastForwardButtonEnabled() {
        SMUtils.waitForElement( driver, paginationRoot );
        Log.message( "Verifying the fast forward button!" );
        return !Boolean.valueOf( SMUtils.getAttributeOfWebElement( SMUtils.getWebElementDirect( driver, paginationRoot, fastForwardButton ), driver, SharedCourses.ARIA_DISABLED ) );
    }

    /**
     * To click the fast forward button
     */
    public void clickFastForwardButton() {
        SMUtils.waitForElement( driver, paginationRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, paginationRoot, fastForwardButton ) );
        Log.message( "Clicked fast forward button!" );
    }

    /**
     * To get the count of shared Courses
     * 
     * @return
     */
    public String getCountOfSharedCourses() {
        SMUtils.waitForElement( driver, paginationRoot );
        Log.message( "Getting the count of Shared courses!" );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, paginationRoot, countOfSharedCourses ), driver );
    }

    /**
     * To get the count of shared Course pages
     * 
     * @return
     */
    public String getCountOfSharedCoursePages() {
        SMUtils.waitForElement( driver, paginationRoot );
        Log.message( "Getting the count of Shared courses pages!" );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, paginationRoot, conutOfPages ), driver );
    }

    /**
     * To get all the shared courses names
     * 
     * @param headerName
     * @return
     */
    public List<String> getAllSharedCourses() {
        List<String> allSharedCourses = new ArrayList<>();
        BooleanSupplier isNextPagePresent = () -> {
            if ( isForwardButtonEnabled() ) {
                clickForwardButton();
                return true;
            }
            return false;
        };

        Log.message( "Getting all the shared courses!" );
        do {
            SMUtils.waitForElement( driver, btnEditRoot );
            allSharedCourses.addAll( SMUtils.getAllTextFromWebElementList( driver.findElements( By.cssSelector( String.format( tableList, SHARED_COURSE_TABLE_HEADER.COURSE_NAME.ordinal() + 1 ) ) ) ) );
        } while ( isNextPagePresent.getAsBoolean() );

        if ( isPreBackwardButtonEnabled() ) {
            clickPreBackwardButton();
            Log.message( "Navigated to first page!" );
        }

        return allSharedCourses;
    }

    /**
     * To click the edit button for given corse name
     * 
     * @param courseName
     * @return
     */
    public SharedCourseOrganizationPopupPage clickEditButton( String courseName ) {
        SMUtils.waitForElement( driver, btnEditRoot );
        driver.findElements( By.cssSelector( String.format( tableList, SHARED_COURSE_TABLE_HEADER.COURSE_NAME.ordinal() + 1 ) ) ).stream().filter(
                element -> SMUtils.getTextOfWebElement( element, driver ).equalsIgnoreCase( courseName ) ).findFirst().ifPresent( element -> {
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, element.findElement( By.xpath( "./../.." ) ).findElement( By.cssSelector( childBtnEdit ) ), secondaryButton ) );
                    Log.message( "Clicked Edit Button -" + courseName );
                } );

        return new SharedCourseOrganizationPopupPage( driver ).get();
    }

    public SettingsListPage navigateToSettingListPage() {
        SMUtils.nap( 3 );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
        wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        subNavList.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( AdminUIConstants.SettingPage.HEADER ) ) {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
                Log.message( "Setting page is Clicked successfull" );
            }

        } );
        return new SettingsListPage( driver ).get();
    }

    /**
     * To verify whether left navigation bar is selected or not
     * 
     * @param leftNavName
     * @return
     */
    public boolean isLeftNavSelected( SubNavigations leftNavName ) {
        try {
            SMUtils.waitForElement( driver, selectedSideNavBar );
            selectedSideNavBar.getText().trim().equals( leftNavName );
            Log.message( leftNavName + " is selected in left navigation" );
            return true;

        } catch ( Exception e ) {
            Log.message( "The Sub Navigation is not clicked" );
            return false;
        }
    }

    /**
     * Navigate to Restore List Page ( to Load the MFE)
     * 
     * @return
     */
    public RestoreAssignmentsListPage navigateToRestoreAssignmentsListPage( String orgId ) {
        try {
            driver.get( String.format( AdminUIConstants.RESTORE_ASSIGNMENT_MFEURL, orgId ) );
            Log.message( "MFE Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE url not loaded" );
        }
        return new RestoreAssignmentsListPage( driver ).get();
    }

    /**
     * Navigate to Setting List Page
     * 
     * @return
     */
    public AuditHistoryPage navigateToAuditHistoryPage() {
        SMUtils.nap( 1 ); // For loading in MAC ENV
        //WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
        //wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        subNavList.forEach( element -> {

            if ( element.getText().trim().equalsIgnoreCase( AdminUIConstants.AuditHistory.HEADER ) ) {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
                Log.message( "Audit History page is Clicked successfull" );
            }

        } );
        return new AuditHistoryPage( driver ).get();
    }

    public Boolean isdashboardPagedisplay() {
        try {
            SMUtils.waitForElement( driver, sideNav );
            SMUtils.scrollToBottomOfPage( driver );
            List<String> dashboard = SMUtils.getAllTextFromWebElementList( subNavbar );
            return dashboard.contains( AdminUIConstants.SUBNAVIGATION.get( 0 ) );

        } catch ( Exception e ) {
            Log.message( "Dashboard subnavigation should not display" );
            return false;
        }

    }

    public Boolean ismasteryPagedisplay() {
        try {
            SMUtils.waitForElement( driver, sideNav );
            SMUtils.scrollToBottomOfPage( driver );
            List<String> mastery = SMUtils.getAllTextFromWebElementList( subNavbar );
            return mastery.contains( AdminUIConstants.SUBNAVIGATION.get( 1 ) );

        } catch ( Exception e ) {
            Log.message( "Dashboard subnavigation should not display" );
            return false;

        }

    }
}
