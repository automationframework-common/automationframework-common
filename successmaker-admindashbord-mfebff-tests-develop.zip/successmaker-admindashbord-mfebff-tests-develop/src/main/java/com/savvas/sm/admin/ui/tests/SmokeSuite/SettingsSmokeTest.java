package com.savvas.sm.admin.ui.tests.SmokeSuite;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.HolidaySchedulerEditPopupPage;
import com.savvas.sm.admin.ui.pages.MSDASettingsPopupPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SettingPage;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SettingsSmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    HolidaySchedulerEditPopupPage editHolidayScheduler;

    private String districtAdminUserName;
    private String subDistrictAdminUserName;
    private String schoolAdminUserName;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtAdminUserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        subDistrictAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        schoolAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
    }

    @Test ( description = "Verify Holiday Scheduler should not display to school admin", groups = { "smoke_test_case", "Admin_TC14", "Settings", "Holiday Scheduler" }, priority = 1 )
    public void tcSMAdminSettingsSmoke001() throws Throwable {

        username = schoolAdminUserName;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdminSettingsSmoke001 : Verify Holiday Scheduler should not display to school admin<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();
            SMUtils.logDescriptionTC( "Verify Edit holiday scheduler window pop should be open when admin click Edit button for Holiday Scheduler" );
            editHolidayScheduler = new HolidaySchedulerEditPopupPage( driver );
            Log.assertThat( Boolean.FALSE.equals( editHolidayScheduler.checkVisibilityOfHolidayScheduler() ), "Edit Holiday scheduler header is not displayed to school admin", "Edit Holiday scheduler header is displayed to school admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Holiday Scheduler should not display to sub-district admin", groups = { "Admin_TC15", "smoke_test_case", "Settings", "Holiday Scheduler" }, priority = 1 )
    public void tcSMAdminSettingsSmoke002() throws Throwable {

        username = subDistrictAdminUserName;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdminSettingsSmoke002 : Verify Holiday Scheduler should not display to school admin<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();
            SMUtils.logDescriptionTC( "Verify Edit holiday scheduler window pop should be open when admin click Edit button for Holiday Scheduler" );
            editHolidayScheduler = new HolidaySchedulerEditPopupPage( driver );
            Log.assertThat( Boolean.FALSE.equals( editHolidayScheduler.checkVisibilityOfHolidayScheduler() ), "Edit Holiday scheduler header is not displayed to sub-district admin", "Edit Holiday scheduler header is displayed to sub-district admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the settings available in Settings tab for district admin.", groups = { "smoke_test_case", "Settings", "Holiday Scheduler", "Admin_TC13", "Admin_TC16", "Admin_TC17", "Admin_TC18", "Admin_TC19",
            "Admin_TC20" }, priority = 1 )
    public void tcSMAdminSettingsSmoke003() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdminSettingsSmoke003 : Verify the settings available in Settings tab for district admin.<small><b><i>[" + browser + "]</b></i></small>" );

            username = districtAdminUserName;
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the settings available in Settings tab for district admin." );
            settingpage = dashBoardPage.navigateToSettingListPage();
            SMUtils.logDescriptionTC( "Verify Edit holiday scheduler window pop should be open when admin click Edit button for Holiday Scheduler" );
            editHolidayScheduler = settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( editHolidayScheduler.getHeaderText().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday scheduler header is displaying", "Edit Holiday scheduler is not displaying" );
            Log.testCaseResult();
            editHolidayScheduler.clickRemovebutton();
            SMUtils.logDescriptionTC( "Verify Holiday should be save and display in holiday list when admin save record" );
            SMUtils.logDescriptionTC( "Verify holiday should be save and display in holiday list when admin save record for single day" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickSaveButton();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER ), "Start date is available in holiday list", "Start date is not available in holiday list" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Holiday should not be save and should not display in holiday list if admin click cancel button" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.WEEKEND_DATE );
            SMUtils.logDescriptionTC( "Verify error message should display when admin trying to add holiday for weekend dates." );
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.ERROR_MESSAGE_WEEKENDS ), "Error message for weekend date is coming as expected",
                    "Error message for weekend date is not coming as expected" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clikCancelButton();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( !( editHolidayScheduler.getholidaylist() ).contains( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT ), "Unsaved holiday is not available in holiday list", "Unsaved holiday is available in holiday list" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Holiday should not save when admin add holiday and click close cross icon" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickCloseDialogeHeader();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( !editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT ), "Unsaved holiday is not available in holiday list when admin click on cross icon",
                    "Unsaved holiday is available in holiday list" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Zero state message when no holiday scheduled." );
            editHolidayScheduler.clickRemovebutton();
            Log.assertThat( editHolidayScheduler.getZeroStateMessage(), "Zero state message is displayng", "Zero state message is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify holiday should be save when admin give lengthy description while adding holiday " );
            SMUtils.logDescriptionTC( "Verify holiday should be save and display in holiday list when admin save record for date range . " );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.LENGTHY_HOLIDAY_DESCRIPTION );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickSaveButton();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            SMUtils.logDescriptionTC( "Verify list of all holiday list should display to  district admin on Holiday Scheduler popup" );
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER ), "Start date is available in holiday list for lengthy description",
                    "Start date is not available in holiday list" );
            Log.testCaseResult();

            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickSaveButton();

            SMUtils.logDescriptionTC( "Verify holiday should not displayed in holiday list when admin remove holiday and save record." );
            editHolidayScheduler.removePerticularHoliday( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            Log.assertThat( !editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT ), "Removed holiday not available in holiday list", "Removed holiday is available" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify MSDA Settings for Sub-Distict Admin", groups = { "smoke_test_case", "Settings", "MSDA Settings", "Admin_TC21", "Admin_TC22"}, priority = 1 )
    public void tcSMAdminSettingsSmoke004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdminSettingsSmoke004: Verify MSDA Settings for Sub-Distict Admin for an organization <small><b><i>[" + browser + "]</b></i></small>" );
            username = subDistrictAdminUserName;
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();
            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.assertThat( settingpage.getSettingListOptionNew().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.assertThat( settingpage.getEditButtn( AdminUIConstants.SettingPage.MSDA ).equals( AdminUIConstants.SettingPage.EDIT_BUTTON ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );

            SMUtils.logDescriptionTC( "Verify the MSDA is turning on for a new organization" );

            // Initializing MSDA Setting Popup Page Elements
            settingpage.clickEditButtn( SettingPage.MSDA );
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );
            Log.assertThat( popupPage.clickTurnAllOn(), "Admin able to click Turn All ON button", "Admin unable to click Turn All ON button" );
            Log.assertThat( popupPage.clickTurnAllOFF(), "Admin able to click Turn All OFF button", "Admin unable to click Turn All OFF button" );
            // Selecting value to turn on MSDA setting and saving
            popupPage.turnOnMSDAForGivenOrganziation( RBSDataSetup.SchoolUnderSubDistrict );
            popupPage.clickSaveButton();

            SMUtils.logDescriptionTC( "Verify the MSDA is turning off for an organization which is already turned on" );

            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( popupPage.verifyMSDASettingForGivenOrganization( RBSDataSetup.SchoolUnderSubDistrict ), "The selection remains the same after saving the MSDA setting", "The selection is not remaining the same after saving the MSDA setting" );
            // Selecting value to turn on MSDA setting and saving
            popupPage.turnOffMSDAForGivenOrganziation( RBSDataSetup.SchoolUnderSubDistrict );
            popupPage.clickSaveButton();

            // Again opening the MSDA setting pop up
            settingpage.clickEditButtn( SettingPage.MSDA );
            Log.assertThat( Boolean.FALSE.equals( popupPage.verifyMSDASettingForGivenOrganization( RBSDataSetup.SchoolUnderSubDistrict ) ), "The selection remains the same after saving the MSDA setting",
                    "The selection is not remaining the same after saving the MSDA setting" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
