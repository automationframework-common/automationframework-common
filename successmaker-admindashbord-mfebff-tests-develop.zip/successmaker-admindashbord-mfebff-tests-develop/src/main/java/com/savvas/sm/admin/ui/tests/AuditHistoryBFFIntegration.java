package com.savvas.sm.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.util.DevToolsUtils;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.audithistory.AuditHistroyBFF;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.restassured.response.Response;

public class AuditHistoryBFFIntegration {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String districtId;
    public static String teacherId;
    //public static String userName;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    //public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgList;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String endPoint;
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String courseId;
    List<String> studentDetails = new ArrayList<String>();
    List<String> studentID = new ArrayList<String>();
    String singleStudentGroupId;
    String multiStudentGroupId;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String schoolID;
    String schoolName;
    String schoolUnderSubDistrict;
    String singleSchoolUsername;
    String multiSchoolUsername;
    Response response1;
    Response response2;
    Map<String, Map<String, String>> valuesUI = new HashMap<>();
    Map<String, Map<String, String>> valuesFromUI = new HashMap<>();
    Map<String, String> headers = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    AuditHistroyBFF history = new AuditHistroyBFF();
    HashMap<String, String> groupdetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    private String configGraphQL;

    //===Details
    public String subDistrictwithoutSchool_name = null;
    public String subDistrictwithSchool_name = null;
    public String subDistrictOrgId_with_school = null;
    public String subDistrictOrgId_without_school = null;
    public String school_under_subDistrictwithSchool_name = null;

    CreateAdmins createAdminsClass = new CreateAdmins();
    //Admin Details
    private String districtAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String schoolAdminDetails = null;
    private String savvasAdminDetails = null;
    private String multiSchoolAdminDetails = null;

    //Admin UserId
    private String districtAdminUserId = null;
    private String subDistrictAdminUserId = null;
    private String schoolAdminUserId = null;
    private String multiSchoolAdminUserId = null;

    //Admin Tokens
    private String districtAdminToken = null;
    private String schoolAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;

    //Admin UserNames
    private String districtAdminUserName = null;
    private String schoolAdminUserName = null;
    private String subDistrictAdminUserName = null;
    private String multiSchoolAdminUserName = null;

    // Assignment audit query
    List<String> queryAudit = Arrays.asList( AdminAPIConstants.DELETED_BY, AdminAPIConstants.ASSIGNMENT_TITLE, AdminAPIConstants.STUDENT_OR_GROUP_NAME, AdminAPIConstants.RECORD_TYPE, AdminAPIConstants.ASSIGNED_BY, AdminAPIConstants.COURSE_NAME );

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );
        configGraphQL = "https://sm-admin-dashboard-bff-srv-stack-dev.smdemo.info/graphql";

        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
        school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );

        //District Admin
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminUserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );
        districtAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        districtAdminToken = new RBSUtils().getAccessToken( districtAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Sub-District Admin 
        subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subDistrictAdminUserName = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        subDistrictAdminToken = new RBSUtils().getAccessToken( subDistrictAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );

        //School Admin
        schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminUserName = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
        schoolAdminToken = new RBSUtils().getAccessToken( schoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Multi-School Admin
        multiSchoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminUserName = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( multiSchoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        if ( !DevToolsUtils.isMock( context ) ) {
            // Getting teacher details
            teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            teacherStaffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
            teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
            teacherOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
            studentDetailsSchool1 = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );

            // Getting sub district with school admin details
            String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
            subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );

            // Getting the school under the sub district details
            schoolUnderSubDistrict = RBSDataSetup.SchoolUnderSubDistrict;
            subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
            schoolID = rbsUtils.getOrganizationIDByName( subDistrictwithSchoolId, schoolUnderSubDistrict );

            // Getting school Admin details
            String singleSchoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
            singleSchoolUsername = SMUtils.getKeyValueFromResponse( singleSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
            String multiSchoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
            multiSchoolUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );

            // Creating new group
            groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherStaffId );
            groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
            groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
            studentDetails.add( RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" ) );
            studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), "userId" ) );
            studentDetails.add( RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student2" ) );
            studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 1 ), "userId" ) );
            HashMap<String, String> createSingleStudentGroup = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentID.get( 0 ) ) );
            singleStudentGroupId = SMUtils.getKeyValueFromResponse( createSingleStudentGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );
            HashMap<String, String> createMultiStudentGroup = new GroupAPI().createGroup( smUrl, groupdetails, studentID );
            multiStudentGroupId = SMUtils.getKeyValueFromResponse( createMultiStudentGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );
            Log.message( "Group is created successfully!!!" );

            // Creating custom course
            courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherStaffId, teacherOrgId, DataSetupConstants.SETTINGS, "Custom Course" + System.nanoTime() );
            Log.message( "Custom course is created successfully!!!" );

            // Assigning an assignment
            assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
            assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
            assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
            assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 0 ) ), "users" );
            Log.message( "Assigned an assignment to the Student" );

            // Deleting an assignment
            assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
            Log.message( "Assignment is deleted successfully!!!" );
        }

    }

    @Test ( description = "Verify deleted assignments are displayed in Audit History page when deleting student assignment", groups = { "SMK-51740", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistoryBFF001( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver( driver );
        String json = null;
        DevTools tools = null;

        Log.testCaseInfo( "tcSMAuditHistoryBFF001: Verify deleted assignments are displayed in Audit History page when deleting student assignment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( districtAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.nap( 30 );

            SMUtils.logDescriptionTC( "Verify Audit History menu exists in district admin page" );
            SMUtils.logDescriptionTC( "Verify Audit Assignment History table when single student is removed from an assignment" );

            if ( DevToolsUtils.isMock( context ) ) {
                json = DevToolsUtils.readJsonResponse( "AuditHistoryMock1.json" );
                Log.message( json );
                Log.message( "configGraphQL " + configGraphQL );
                tools = RequestMockUtils.setResponse( driver, configGraphQL, "GetAuditHistoryList", "post", json );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            // Getting deleted assignments from UI
            auditHistoryPage.selectOrganizationByName( schoolName );

            valuesUI = auditHistoryPage.getRowValues();

            if ( !DevToolsUtils.isMock( context ) ) {
                // Getting deleted assignment details from BFF
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, districtAdminUserId );
                response1 = history.getAuditHistoryBFF( headers, teacherOrgId, districtAdminUserId, districtId, queryAudit );
                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesUI, response1 ), "Deleted assignments are displayed when single student is removed from an assignmnet",
                        "Deleted assignments are not displayed when single student is removed from an assignmnet" );
                Log.testCaseResult();
            } else {
                RequestMockUtils.closeMock( tools );
                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesUI, json ), "Deleted assignments are displayed when single student is removed from an assignmnet",
                        "Deleted assignments are not displayed when single student is removed from an assignmnet" );
                Log.testCaseResult();
            }

            SMUtils.logDescriptionTC( "Verify Audit Assignment History table when multiple students are removed from an assignment" );
            SMUtils.logDescriptionTC( "Verify Audit Assignment History table when assignment is deleted" );

            if ( !DevToolsUtils.isMock( context ) ) {
                // Assigning and deleting an assignment for another student
                assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
                assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
            } else {
                json = DevToolsUtils.readJsonResponse( "AuditHistoryMock2.json" );
                Log.message( json );
                tools = RequestMockUtils.setResponse( driver, configGraphQL, "GetAuditHistoryList", "post", json );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            // Getting deleted assignments from UI
            auditHistoryPage.selectOrganizationByName( schoolName );

            valuesFromUI = auditHistoryPage.getRowValues();

            if ( !DevToolsUtils.isMock( context ) ) {
                // Getting deleted assignment details from BFF
                response2 = history.getAuditHistoryBFF( headers, teacherOrgId, districtAdminUserId, districtId, queryAudit );
                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response2 ), "Deleted assignments are displayed when multiple students are removed from an assignmnet",
                        "Deleted assignments are not displayed when multiple students are removed from an assignmnet" );
                Log.testCaseResult();
            } else {
                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, json ), "Deleted assignments are displayed when multiple students are removed from an assignmnet",
                        "Deleted assignments are not displayed when multiple students are removed from an assignmnet" );
                Log.testCaseResult();
                RequestMockUtils.closeMock( tools );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify deleted assignments are displayed in Audit History page when deleting group assignment", groups = { "SMK-51740", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistoryBFF002( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver( driver );
        String json = null;
        DevTools tools = null;

        Log.testCaseInfo( "tcSMAuditHistoryBFF002: Verify deleted assignments are displayed in Audit History page when deleting group assignment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            if ( !DevToolsUtils.isMock( context ) ) {
                // Assigning assignment to group
                assign.assignAssignment( smUrl, assignmentDetails, Arrays.asList( singleStudentGroupId ), "groups" );

                // Deleting an assignment
                assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
            }

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( districtAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.nap( 30 );

            SMUtils.logDescriptionTC( "Verify Audit Assignment History table when single student is removed from group assignment" );

            if ( DevToolsUtils.isMock( context ) ) {
                json = DevToolsUtils.readJsonResponse( "AuditHistoryMock1.json" );
                Log.message( json );
                Log.message( "configGraphQL " + configGraphQL );
                tools = RequestMockUtils.setResponse( driver, configGraphQL, "GetAuditHistoryList", "post", json );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            auditHistoryPage.selectOrganizationByName( schoolName );
            valuesUI = auditHistoryPage.getRowValues();

            if ( !DevToolsUtils.isMock( context ) ) {
                // Getting deleted assignment details from BFF
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                headers.put( Constants.USERID_SM_HEADER, districtAdminUserId );
                response1 = history.getAuditHistoryBFF( headers, teacherOrgId, districtAdminUserId, districtId, queryAudit );

                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesUI, response1 ), "Deleted assignments are displayed when single student is removed from an group assignmnet",
                        "Deleted assignments are not displayed when single student is removed from an group assignmnet" );
                Log.testCaseResult();
            } else {
                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesUI, json ), "Deleted assignments are displayed when single student is removed from an assignmnet",
                        "Deleted assignments are not displayed when single student is removed from an assignmnet" );
                Log.testCaseResult();
                RequestMockUtils.closeMock( tools );
            }

            SMUtils.logDescriptionTC( "Verify Audit Assignment History table when multiple students are removed from group assignment" );
            SMUtils.logDescriptionTC( "Verify Audit Assignment History table when teacher create new assignment second time and delete it again" );

            if ( !DevToolsUtils.isMock( context ) ) {
                // Removing multiple students from group
                assign.assignAssignment( smUrl, assignmentDetails, Arrays.asList( multiStudentGroupId ), "groups" );
                assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
            } else {
                json = DevToolsUtils.readJsonResponse( "AuditHistoryMock2.json" );
                Log.message( json );
                tools = RequestMockUtils.setResponse( driver, configGraphQL, "GetAuditHistoryList", "post", json );
                tools.createSessionIfThereIsNotOne();
                Log.message( tools.getCdpSession().toString() );
            }

            // Getting deleted assignments from UI
            auditHistoryPage.selectOrganizationByName( schoolName );

            valuesFromUI = auditHistoryPage.getRowValues();

            if ( !DevToolsUtils.isMock( context ) ) {
                // Getting deleted assignment details from BFF
                response2 = history.getAuditHistoryBFF( headers, teacherOrgId, districtAdminUserId, districtId, queryAudit );

                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response2 ), "Deleted assignments are displayed when multiple students are removed from an group assignmnet",
                        "Deleted assignments are not displayed when multiple students are removed from an group assignmnet" );
                Log.testCaseResult();
            } else {
                Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, json ), "Deleted assignments are displayed when multiple students are removed from an group assignmnet",
                        "Deleted assignments are not displayed when multiple students are removed from an group assignmnet" );
                Log.testCaseResult();
                RequestMockUtils.closeMock( tools );
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Audit History page is displayed for sub district admin", groups = { "SMK-51740", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistoryBFF003( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver( driver );

        Log.testCaseInfo( "tcSMAuditHistoryBFF003: Verify Audit History page is displayed for sub district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( subDistrictAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.nap( 30 );
            SMUtils.nap( 30 );

            SMUtils.logDescriptionTC( "Verify Audit History menu exists in sub-district admin page" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "Audit History page is displayed for sub district admin", "Audit History page is not displayed for sub district admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Audit History page is displayed for single school admin", groups = { "SMK-51740", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistoryBFF004( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver( driver );

        Log.testCaseInfo( "tcSMAuditHistoryBFF004: Verify Audit History page is displayed for single school admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( schoolAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.nap( 30 );

            SMUtils.logDescriptionTC( "Verify Audit History menu exists for school admin associated with single organizations" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "Audit History page is displayed for single school admin", "Audit History page is not displayed for single school admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Audit History page is displayed for multi school admin", groups = { "SMK-51740", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistoryBFF005( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver( driver );

        Log.testCaseInfo( "tcSMAuditHistoryBFF005: Verify Audit History page is displayed for single school admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( multiSchoolAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            SMUtils.nap( 30 );

            SMUtils.logDescriptionTC( "Verify Audit History menu exists for school admin associated with multiple organizations" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "Audit History page is displayed for multi school admin", "Audit History page is not displayed for multi school admin" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * Verifying deleted assignments are displaying in Audit History page
     * 
     * @param valuesFromUI
     * @param response
     * @return
     */
    public boolean verifyDeletedAssignmentsAreDisplayed( Map<String, Map<String, String>> valuesFromUI, Response response ) {
        Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();
        IntStream.range( 0, SMUtils.getWordCount( response.getBody().asString(), "assignmentTitle" ) ).forEach( iter -> {
            Map<String, String> deletedAssignments = new HashMap<>();
            String rspn = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
            JSONObject jsonObj = new JSONObject( rspn );
            JSONArray ja = jsonObj.getJSONArray( "getAssignmentAudits" );
            JSONObject jObj = ja.getJSONObject( iter );
            deletedAssignments.put( "deletedBy", jObj.get( "deletedBy" ).toString() );
            deletedAssignments.put( "assignmentTitle", jObj.get( "assignmentTitle" ).toString() );
            deletedAssignments.put( "studentOrGroupName", jObj.get( "studentOrGroupName" ).toString() );
            deletedAssignments.put( "recordType", jObj.get( "recordType" ).toString().toUpperCase() );
            deletedAssignments.put( "assignedBy", jObj.get( "assignedBy" ).toString() );
            deletedAssignments.put( "courseName", jObj.get( "courseName" ).toString() );
            getAuditHistoryAssignment.put( Integer.toString( iter ), deletedAssignments );
        } );
        return valuesFromUI.entrySet().stream().allMatch( entry -> getAuditHistoryAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );
    }

    /**
     * Verifying deleted assignments are displaying in Audit History page
     * 
     * @param valuesFromUI
     * @param mockResponse
     * @return
     */
    public boolean verifyDeletedAssignmentsAreDisplayed( Map<String, Map<String, String>> valuesFromUI, String response ) {
        Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();
        IntStream.range( 0, SMUtils.getWordCount( response, "assignmentTitle" ) ).forEach( iter -> {
            Map<String, String> deletedAssignments = new HashMap<>();
            String rspn = SMUtils.getKeyValueFromResponse( response, "data" );
            JSONObject jsonObj = new JSONObject( rspn );
            JSONArray ja = jsonObj.getJSONArray( "getAssignmentAudits" );
            JSONObject jObj = ja.getJSONObject( iter );
            deletedAssignments.put( "deletedBy", jObj.get( "deletedBy" ).toString() );
            deletedAssignments.put( "assignmentTitle", jObj.get( "assignmentTitle" ).toString() );
            deletedAssignments.put( "studentOrGroupName", jObj.get( "studentOrGroupName" ).toString() );
            deletedAssignments.put( "recordType", jObj.get( "recordType" ).toString().toUpperCase() );
            deletedAssignments.put( "assignedBy", jObj.get( "assignedBy" ).toString() );
            deletedAssignments.put( "courseName", jObj.get( "courseName" ).toString() );
            getAuditHistoryAssignment.put( Integer.toString( iter ), deletedAssignments );
        } );
        return valuesFromUI.entrySet().stream().allMatch( entry -> getAuditHistoryAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );
    }

}
