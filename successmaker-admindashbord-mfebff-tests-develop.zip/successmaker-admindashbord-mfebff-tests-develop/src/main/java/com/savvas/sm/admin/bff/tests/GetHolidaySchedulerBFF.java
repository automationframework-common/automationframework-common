package com.savvas.sm.admin.bff.tests;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;

import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.settings.HolidaySchedulerBFF;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.CreateAdmins;

import io.restassured.response.Response;

public class GetHolidaySchedulerBFF extends EnvProperties {

    private String districtId;
    private String userName;
    private String password;
    private String userId;
    private String orgId;
    private String flexSchool;
    private String schoolAdminuserName;
    private String schoolAdminuserId;
    private String savvasUserName;
    private String savvasUserId;
    Response response;
    String startDate;
    String endDate;
    String description;
    String holidayDetails;
    List<LocalDate> dates;
    private String smUrl;

    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String schoolAdminDetails = null;
    private String savvasAdminDetails = null;
    private String multiSchoolAdminDetails = null;

    //Tokens
    private String districtAdminToken = null;
    private String schoolAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String savvasAdminToken = null;

    public static String subDistrictwithSchool_name = null;
    public static String subDistrictOrgId_with_school = null;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        districtId = configProperty.getProperty( "district_ID" );
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );

        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );

        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "0061" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "052" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Sub-District Admin Creation
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "97" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Multi-School Admin
        multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "98" );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Savvas Admin
        savvasAdminDetails = createAdminsClass.createSavvasAdmin( smUrl, districtId, "045" );
        Log.message( "********" );
        Log.message( "savvasAdminDetails from Create Admins are " + savvasAdminDetails );
        Log.message( "********" );
        savvasAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        // Getting savvas admin details
        savvasUserName = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        savvasUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        // Getting admin details
        userName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( priority = 1, dataProvider = "getTestData", groups = { "HolidayScheduler", "SMK-51799", "P2", "API", "smoke_test_case", "positive_test_case" } )
    public void getHolidayPositiveAndNegative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        // Getting dates of current week
        LocalDate listDays = LocalDate.now();
        dates = Arrays.asList( DayOfWeek.values() ).stream().map( listDays::with ).collect( Collectors.toList() );
        startDate = dates.get( 0 ).toString();
        endDate = dates.get( 4 ).toString();
        description = "SM Holiday";
        String keyValueFromResponse;
        HashMap<String, String> keyValue = new HashMap<>();

        switch ( scenarioType ) {
            case "VALID":
                // Creating holidays
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + districtAdminToken );
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\", description: \\\"" + description + "\\\" }";
                new HolidaySchedulerBFF().saveHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );

                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                Log.message( response.getBody().toString() + "" );

                // Verifying the response with DB values
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONObject jsonObj = new JSONObject( keyValueFromResponse );
                    JSONArray ja = jsonObj.getJSONArray( "getHolidayScheduler" );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString(), jObj.get( "description" ).toString() );
                } );
                HashMap<String, String> holidayListFromDB = new SqlHelperOrganization().getHolidayList();
                Log.assertThat( SMUtils.compareTwoHashMap( keyValue, holidayListFromDB ), "The dates and description values are verified", "The dates and description are not verified" );
                break;

            case "SAVVAS ADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\" }";
                new HolidaySchedulerBFF().saveHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, savvasUserId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, savvasUserId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                Log.message( response.getBody().toString() + "" );
                // Verifying the response with DB values
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONObject jsonObj = new JSONObject( keyValueFromResponse );
                    JSONArray ja = jsonObj.getJSONArray( "getHolidayScheduler" );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString(), jObj.get( "description" ).toString() );
                } );
                HashMap<String, String> holidayListFromDB2 = new SqlHelperOrganization().getHolidayList();
                Log.assertThat( SMUtils.compareTwoHashMap( keyValue, holidayListFromDB2 ), "The dates and description values are verified", "The dates and description are not verified" );
                break;

            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) + "invalid" );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                break;

            case "INVALID_QUERY":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE + "Invalid", AdminAPIConstants.DESCRIPTION ), districtId );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId + "Invalid", districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId + "Invalid", Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                break;

            case "EMPTY_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, "", districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                break;

            case "EMPTY_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, "", Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                break;
            case "SCHOOL ADMIN":
                schoolAdminuserName = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
                schoolAdminuserId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( schoolAdminuserName, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.SCHOOL_ADMIN, schoolAdminuserId, schoolOrgId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), schoolOrgId );
                break;
            case "SUB_DISTRICT ADMIN":
                String subdistrictUserID = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
                String subdistrictUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.SUB_DISTRICT_ADMIN, subdistrictUserID, subDistrictwithSchoolId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ),
                        subDistrictwithSchoolId );
                break;
            case "MULTI SCHOOL ADMIN":
                String multiSchoolUserID = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERID );
                String multiSchoolUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
                String multiSchoolOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( multiSchoolUsername, password ) );
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.SUB_DISTRICT_ADMIN, multiSchoolUserID, multiSchoolOrgId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), multiSchoolOrgId );
                break;

            default:
                break;

        }

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenarioType.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_USERID ), "Getting Invalid message for empty userId", "Not getting Invalid message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        } else if ( scenarioType.equalsIgnoreCase( "SCHOOL ADMIN" ) || ( scenarioType.equalsIgnoreCase( "SUB_DISTRICT ADMIN" ) ) || ( scenarioType.equalsIgnoreCase( "MULTI SCHOOL ADMIN" ) ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );

        }
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getTestData" )
    public Object[][] getTestData() {

        return new Object[][] { { "SMK-19666", "Verify the getHolidayScheduler graphql query is returned all saved holiday list while use a district admin credential", CommonAPIConstants.STATUS_CODE_OK, "VALID" },
                { "SMK-19670", "Verify the getHolidayScheduler graphql query is returned all saved holiday list while use a savvas admin credential", CommonAPIConstants.STATUS_CODE_OK, "SAVVAS ADMIN" },
                { "SMK-19671", "Verify '401: UnAuthorized' message in response when invalid Bearer token is given", CommonAPIConstants.STATUS_CODE_OK, "INVALID_BEARER_TOKEN" },
                { "SMK-19672", "Verify '400: Bad Request' in response when invalid query has been given", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "INVALID_QUERY" },
                { "SMK-19673", "Verify  '401: UnAuthorized'  and response when invalid userId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_USER_ID" },
                { "SMK-19674", "Verify 400 status code and response when invalid organizationId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_ORG_ID" },
                { "SMK-19676", "Verify 200: Verify  the message in response when empty userId is given in the query  ", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_USER_ID" },
                { "SMK-19677 ", "Verify 200: Verify the message in response when empty org-id is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_ORG_ID" },
                { "SMK-19669", "Verify 200: Verify the getHolidayScheduler graphql query should not return saved holiday list while use a subdistrict admin credential", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT ADMIN" },
                { "SMK-19668", "Verify 200: Verify the getHolidayScheduler graphql query should not return saved holiday list while use a multiple school admin credential", CommonAPIConstants.STATUS_CODE_OK, "MULTI SCHOOL ADMIN" },
                { "SMK-19667", "Verify 200: Verify the getHolidayScheduler graphql query should not return saved holiday list while use a school admin credential", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL ADMIN" } };

    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

}
