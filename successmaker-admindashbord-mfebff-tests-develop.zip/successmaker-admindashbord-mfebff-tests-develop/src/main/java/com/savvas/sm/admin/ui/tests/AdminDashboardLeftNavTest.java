package com.savvas.sm.admin.ui.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;

public class AdminDashboardLeftNavTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify left navigation bar functionality in admin dashboard", groups = { "SMK-51098", "AdminDashboard", "LeftNavigation" }, priority = 1 )
    public void tcSMLeftNav001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMLeftNav001: Verify left navigation bar functionality in admin dashboard. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify admin can view left navigation bar in successmaker" );
            Log.assertThat( dashBoardPage.isSideNavBarDisplayed(), "Side navigation bar is displayed successfully!!!", "Side navigation bar is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify admin can select Mastery in left nav bar" );
            dashBoardPage.navigateTo( SubNavigations.MASTERY );
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.MASTERY ), SubNavigations.MASTERY + " is selected in left navigation as expected", SubNavigations.MASTERY + " is not selected in left navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify admin can navigate from one left nav bar to another" );
            SMUtils.logDescriptionTC( "Verify admin can select Shared Courses in left nav bar" );
            dashBoardPage.navigateTo( SubNavigations.SHARED_COURSES );
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.SHARED_COURSES ), SubNavigations.SHARED_COURSES + " is selected in left navigation as expected", SubNavigations.SHARED_COURSES + " is not selected in left navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify admin can select Audit History in left nav bar" );
            dashBoardPage.navigateTo( SubNavigations.AUDIT_HISTORY );
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.AUDIT_HISTORY ), SubNavigations.AUDIT_HISTORY + " is selected in left navigation as expected", SubNavigations.AUDIT_HISTORY + " is not selected in left navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify admin can select Settings in left nav bar" );
            dashBoardPage.navigateTo( SubNavigations.SETTINGS );
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify admin can select Settings in left nav bar" );
            dashBoardPage.navigateTo( SubNavigations.DASHBOARD );
            Log.assertThat( dashBoardPage.isLeftNavSelected( SubNavigations.DASHBOARD ), SubNavigations.DASHBOARD + " is selected in left navigation as expected", SubNavigations.DASHBOARD + " is not selected in left navigation" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the selected left nav bar should be blue in color" );
            dashBoardPage.navigateTo( SubNavigations.SETTINGS );
            Log.assertThat( dashBoardPage.verifySelectedSideNavBarColor( AdminUIConstants.SELECTED_SIDE_NAV_BAR_COLOR ), "Selected side nav bar color is same as excepted", "Selected side nav bar color is not same as excepted" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
