package com.savvas.sm.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.data.RBSDataSetup;

import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.audithistory.AuditHistroyBFF;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.response.Response;

public class SavvasAdminSMDashboard {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String districtAdminDetails;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String districtId;
    public static String teacherId;
    public static String userName;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgName;
    public static String orgList;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String endPoint;
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String courseId;
    List<String> studentDetails = new ArrayList<String>();
    List<String> studentID = new ArrayList<String>();
    String singleStudentGroupId;
    String multiStudentGroupId;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String schoolID;
    String schoolName;
    String schoolUnderSubDistrict;
    String singleSchoolUsername;
    String multiSchoolUsername;
    Response response1;
    Response response2;
    Map<String, Map<String, String>> valuesUI = new HashMap<>();
    Map<String, Map<String, String>> valuesFromUI = new HashMap<>();
    Map<String, String> headers = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    AuditHistroyBFF history = new AuditHistroyBFF();
    HashMap<String, String> groupdetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();

    // Assignment audit query
    List<String> queryAudit = Arrays.asList( AdminAPIConstants.DELETED_BY, AdminAPIConstants.ASSIGNMENT_TITLE, AdminAPIConstants.STUDENT_OR_GROUP_NAME, AdminAPIConstants.RECORD_TYPE, AdminAPIConstants.ASSIGNED_BY, AdminAPIConstants.COURSE_NAME );

    @BeforeClass
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );
        orgId=RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgName=RBSDataSetup.getSchools( Schools.FLEX_SCHOOL);
        Log.message( orgName );

        // Getting district admin details from RBS Datasetup
        userName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String savvasadmindetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( savvasadmindetails, RBSDataSetupConstants.USERID );

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools(  Schools.FLEX_SCHOOL ) );
        teacherStaffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = orgId;
        studentDetailsSchool1 = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        // Getting sub district with school admin details
        String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );

        // Getting the school under the sub district details
        schoolUnderSubDistrict = RBSDataSetup.SchoolUnderSubDistrict;
        subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
        schoolID = rbsUtils.getOrganizationIDByName( subDistrictwithSchoolId, schoolUnderSubDistrict );

        // Gettinig school admin details
        String singleSchoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        singleSchoolUsername = SMUtils.getKeyValueFromResponse( singleSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
        String multiSchoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
        multiSchoolUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );

        // Creating new group
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherStaffId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        studentDetails.add( RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" ) );
        studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), "userId" ) );
        studentDetails.add( RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student2" ) );
        studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 1 ), "userId" ) );
        HashMap<String, String> createSingleStudentGroup = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentID.get( 0 ) ) );
        singleStudentGroupId = SMUtils.getKeyValueFromResponse( createSingleStudentGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );
        HashMap<String, String> createMultiStudentGroup = new GroupAPI().createGroup( smUrl, groupdetails, studentID );
        multiStudentGroupId = SMUtils.getKeyValueFromResponse( createMultiStudentGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );
        Log.message( "Group is created successfully!!!" );

        // Creating custom course
        courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherStaffId, teacherOrgId, DataSetupConstants.SETTINGS, "Custom Course" + System.nanoTime() );
        Log.message( "Custom course is created successfully!!!" );

        // Assigning an assignment
        assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 0 ) ), "users" );
        Log.message( "Assigned an assignment to the Student" );

        // Deleting an assignment
        assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        Log.message( "Assignment is deleted successfully!!!" );

    }
    
    @Test ( description = "Verify the dashboard subnav page should not be loaded,When district name is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Dashboard" }, priority = 1 )
    public void tcSavvasAdminSMDashboard001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        
        Log.testCaseInfo( "Verify the dashboard subnav page should not be loaded,When district name is searched in organization search field.... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            //Verify Dashborad page  
            Log.assertThat( !sharedCoursePage.isdashboardPagedisplay(), "Dashboard subnav page should not show..!!!", "Dashboard subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the dashboard subnav page should not be loaded,When districtID is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Dashboard" }, priority = 1 )
    public void tcSavvasAdminSMDashboard002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        
        Log.testCaseInfo( "Verify the dashboard subnav page should not be loaded,When districtID is searched in organization search field.... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            //Verify Dashborad page  
            Log.assertThat( !sharedCoursePage.isdashboardPagedisplay(), "Dashboard subnav page should not show..!!!", "Dashboard subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the dashboard subnav page should not be loaded,When schoolID is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Dashboard" }, priority = 1 )
    public void tcSavvasAdminSMDashboard003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the dasboard subnav page should not be loaded,When schoolID is searched in organization search field.... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            //Verify Dashborad page  
            Log.assertThat( !sharedCoursePage.isdashboardPagedisplay(), "Dashboard subnav page should not show..!!!", "Dashboard subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the dashboard subnav page should not be loaded,When subdistrictID is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Dashboard" }, priority = 1 )
    public void tcSavvasAdminSMDashboard004() throws Exception {
        // Get driver
         final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the dashboard subnav page should not be loaded,When subdistrictID is searched in organization search field.... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM(userName, password,orgId );

            //Verify Dashborad page  
            Log.assertThat( !sharedCoursePage.isdashboardPagedisplay(), "Dashboard subnav page should not show..!!!", "Dashboard subnav page should shown" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the mastery subnav page should not be loaded,When districtID  is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Mastery" }, priority = 1 )
    public void tcSavvasAdminSMMastery005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the mastery subnav page should not be loaded,When districtID  is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId);

            //Verify Mastery page  
            Log.assertThat( !sharedCoursePage.ismasteryPagedisplay(), "Mastery subnav page should not show..!!!", "Mastery subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the mastery subnav page should not be loaded,When schoolID is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Mastery" }, priority = 1 )
    public void tcSavvasAdminSMMastery006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Verify the mastery subnav page should not be loaded,When schoolID is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId);

            //Verify Mastery page  
            Log.assertThat( !sharedCoursePage.ismasteryPagedisplay(), "Mastery subnav page should not show..!!!", "Mastery subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the mastery subnav page should not be loaded,When subdistrictID is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Mastery" }, priority = 1 )
    public void tcSavvasAdminSMMastery007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the mastery subnav page should not be loaded,When subdistrictID is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            //Verify Mastery page  
            Log.assertThat( !sharedCoursePage.ismasteryPagedisplay(), "Mastery subnav page should not show..!!!", "Mastery subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the mastery subnav page should not be loaded,When district name is searched in organization search field..", groups = { "SMK-65224", "SavvasAdminSMDashboard", "Mastery" }, priority = 1 )
    public void tcSavvasAdminSMMastery008() throws Exception {
        // Get driver
         final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the mastery subnav page should not be loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            //Verify Mastery page  
            Log.assertThat( !sharedCoursePage.ismasteryPagedisplay(), "Mastery subnav page should not show..!!!", "Mastery subnav page should shown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Audit history page is loaded,When district name is searched in organization search field..", groups = { "SMK-65224", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSavvasAdminAuditHistoryPage001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the Audit history page is loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
        HashMap<String,String> deleteAssignment = assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
       Log.message( deleteAssignment.toString());
        try {
            smUrl = configProperty.getProperty( "SMAppUrl" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = sharedCoursePage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.verifyHeaderisdisplayed(), "Audit history page title should be displayed.!!!", "Audit history page title should not be displayed" );
            //Verify organization dropdown
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "organization dropdown should be displayed...!!!", "organization dropdown should not be displayed.." );
            //Select the organization 
            Log.assertThat( auditHistoryPage.clickOrganizationDropdownUsingCount( orgName ), "Organization name should be selected...!!!", "Organization name should not be selected.." );

            //Verify Audit history table
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "Selected organization deleted assignments should be displayed...!!!", "Selected organization deleted assignments should not be displayed.." );
            //Verify Audit history assignments
           
            
            valuesFromUI = auditHistoryPage.getRowValues();

            // Getting deleted assignment details from BFF
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
            response1 = history.getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

            Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response1 ), "Deleted assignments are displayed when sinlge student are removed from an assignmnet",
                    "Deleted assignments are not displayed when single students are removed from an assignmnet" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            //driver.quit();
        }
    }

    public boolean verifyDeletedAssignmentsAreDisplayed( Map<String, Map<String, String>> valuesFromUI, Response response ) {
        Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();
        IntStream.range( 0, SMUtils.getWordCount( response.getBody().asString(), "assignmentTitle" ) ).forEach( iter -> {
            Map<String, String> deletedAssignments = new HashMap<>();
            String rspn = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
            JSONObject jsonObj = new JSONObject( rspn );
            JSONArray ja = jsonObj.getJSONArray( "getAssignmentAudits" );
            JSONObject jObj = ja.getJSONObject( iter );
            deletedAssignments.put( "deletedBy", jObj.get( "deletedBy" ).toString() );
            deletedAssignments.put( "assignmentTitle", jObj.get( "assignmentTitle" ).toString() );
            deletedAssignments.put( "studentOrGroupName", jObj.get( "studentOrGroupName" ).toString() );
            deletedAssignments.put( "recordType", jObj.get( "recordType" ).toString().toUpperCase() );
            deletedAssignments.put( "assignedBy", jObj.get( "assignedBy" ).toString() );
            deletedAssignments.put( "courseName", jObj.get( "courseName" ).toString() );
            getAuditHistoryAssignment.put( Integer.toString( iter ), deletedAssignments );
        } );
        return valuesFromUI.entrySet().stream().allMatch( entry -> getAuditHistoryAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );
    }

    @Test ( description = "Verify the Audit history page is loaded,When school name is searched in organization search field...", groups = { "SMK-65224", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSavvasAdminAuditHistoryPage002() throws Exception {
     // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        
        Log.testCaseInfo( "Verify the Audit history page is loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
        HashMap<String,String> deleteAssignment = assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
       Log.message( deleteAssignment.toString());
        try {
            smUrl = configProperty.getProperty( "SMAppUrl" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = sharedCoursePage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.verifyHeaderisdisplayed(), "Audit history page title should be displayed.!!!", "Audit history page title should not be displayed" );
            //Verify organization dropdown
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "organization dropdown should be displayed...!!!", "organization dropdown should not be displayed.." );
            //Select the organization 
            Log.assertThat( auditHistoryPage.clickOrganizationDropdownUsingCount( orgName ), "Organization name should be selected...!!!", "Organization name should not be selected.." );

            //Verify Audit history table
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "Selected organization deleted assignments should be displayed...!!!", "Selected organization deleted assignments should not be displayed.." );
            //Verify Audit history assignments
           
            
            valuesFromUI = auditHistoryPage.getRowValues();

            // Getting deleted assignment details from BFF
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
            response1 = history.getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

            Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response1 ), "Deleted assignments are displayed when sinlge student are removed from an assignmnet",
                    "Deleted assignments are not displayed when single students are removed from an assignmnet" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            //driver.quit();
        }
    }

    @Test ( description = "Verify the Audit history page is loaded,When subdistrict name  is searched in organization search filed....", groups = { "SMK-65224", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSavvasAdminAuditHistoryPage003() throws Exception {
     // Get driver
    	 final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the Audit history page is loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
        HashMap<String,String> deleteAssignment = assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
       Log.message( deleteAssignment.toString());
        try {
            smUrl = configProperty.getProperty( "SMAppUrl" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = sharedCoursePage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.verifyHeaderisdisplayed(), "Audit history page title should be displayed.!!!", "Audit history page title should not be displayed" );
            //Verify organization dropdown
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "organization dropdown should be displayed...!!!", "organization dropdown should not be displayed.." );
            //Select the organization 
            Log.assertThat( auditHistoryPage.clickOrganizationDropdownUsingCount( orgName ), "Organization name should be selected...!!!", "Organization name should not be selected.." );

            //Verify Audit history table
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "Selected organization deleted assignments should be displayed...!!!", "Selected organization deleted assignments should not be displayed.." );
            //Verify Audit history assignments
           
            
            valuesFromUI = auditHistoryPage.getRowValues();

            // Getting deleted assignment details from BFF
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
            response1 = history.getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

            Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response1 ), "Deleted assignments are displayed when sinlge student are removed from an assignmnet",
                    "Deleted assignments are not displayed when single students are removed from an assignmnet" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            //driver.quit();
        }
    }

    @Test ( description = "Verify the Audit history page is loaded,When district ID is searched in organization search field....", groups = { "SMK-65224", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSavvasAdminAuditHistoryPage004() throws Exception {
     // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the Audit history page is loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
        HashMap<String,String> deleteAssignment = assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
       Log.message( deleteAssignment.toString());
        try {
            smUrl = configProperty.getProperty( "SMAppUrl" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = sharedCoursePage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.verifyHeaderisdisplayed(), "Audit history page title should be displayed.!!!", "Audit history page title should not be displayed" );
            //Verify organization dropdown
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "organization dropdown should be displayed...!!!", "organization dropdown should not be displayed.." );
            //Select the organization 
            Log.assertThat( auditHistoryPage.clickOrganizationDropdownUsingCount( orgName ), "Organization name should be selected...!!!", "Organization name should not be selected.." );

            //Verify Audit history table
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "Selected organization deleted assignments should be displayed...!!!", "Selected organization deleted assignments should not be displayed.." );
            //Verify Audit history assignments
           
            
            valuesFromUI = auditHistoryPage.getRowValues();

            // Getting deleted assignment details from BFF
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
            response1 = history.getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

            Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response1 ), "Deleted assignments are displayed when sinlge student are removed from an assignmnet",
                    "Deleted assignments are not displayed when single students are removed from an assignmnet" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            //driver.quit();
        }
    }

    @Test ( description = "Verify the Audit history page is loaded,When school ID is searched in organization search field..", groups = { "SMK-65224", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSavvasAdminAuditHistoryPage005() throws Exception {
     // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the Audit history page is loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
        HashMap<String,String> deleteAssignment = assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
       Log.message( deleteAssignment.toString());
        try {
            smUrl = configProperty.getProperty( "SMAppUrl" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = sharedCoursePage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.verifyHeaderisdisplayed(), "Audit history page title should be displayed.!!!", "Audit history page title should not be displayed" );
            //Verify organization dropdown
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "organization dropdown should be displayed...!!!", "organization dropdown should not be displayed.." );
            //Select the organization 
            Log.assertThat( auditHistoryPage.clickOrganizationDropdownUsingCount( orgName ), "Organization name should be selected...!!!", "Organization name should not be selected.." );

            //Verify Audit history table
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "Selected organization deleted assignments should be displayed...!!!", "Selected organization deleted assignments should not be displayed.." );
            //Verify Audit history assignments
           
            
            valuesFromUI = auditHistoryPage.getRowValues();

            // Getting deleted assignment details from BFF
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
            response1 = history.getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

            Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response1 ), "Deleted assignments are displayed when sinlge student are removed from an assignmnet",
                    "Deleted assignments are not displayed when single students are removed from an assignmnet" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            //driver.quit();
        }
    }

    @Test ( description = "Verify the Audit history page is loaded.When subdistrict ID is searched in organization search field...", groups = { "SMK-65224", "adminDashboard", "Dashboard" }, priority = 1 )
    public void tcSavvasAdminAuditHistoryPage006() throws Exception {
     // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        Log.testCaseInfo( "Verify the Audit history page is loaded,When district name is searched in organization search field... <small><b><i>[" + browser + "]</b></i></small>" );
        assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
        HashMap<String,String> deleteAssignment = assign.deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
       Log.message( deleteAssignment.toString());
        try {
            smUrl = configProperty.getProperty( "SMAppUrl" );
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( userName, password,orgId );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = sharedCoursePage.navigateToAuditHistoryPage();
            Log.assertThat( auditHistoryPage.verifyHeaderisdisplayed(), "Audit history page title should be displayed.!!!", "Audit history page title should not be displayed" );
            //Verify organization dropdown
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "organization dropdown should be displayed...!!!", "organization dropdown should not be displayed.." );
            //Select the organization 
            Log.assertThat( auditHistoryPage.clickOrganizationDropdownUsingCount( orgName ), "Organization name should be selected...!!!", "Organization name should not be selected.." );

            //Verify Audit history table
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "Selected organization deleted assignments should be displayed...!!!", "Selected organization deleted assignments should not be displayed.." );
            //Verify Audit history assignments
           
            
            valuesFromUI = auditHistoryPage.getRowValues();

            // Getting deleted assignment details from BFF
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
            response1 = history.getAuditHistoryBFF( headers, teacherOrgId, userId, districtId, queryAudit );

            Log.assertThat( verifyDeletedAssignmentsAreDisplayed( valuesFromUI, response1 ), "Deleted assignments are displayed when sinlge student are removed from an assignmnet",
                    "Deleted assignments are not displayed when single students are removed from an assignmnet" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            //driver.quit();
        }
    }
}
