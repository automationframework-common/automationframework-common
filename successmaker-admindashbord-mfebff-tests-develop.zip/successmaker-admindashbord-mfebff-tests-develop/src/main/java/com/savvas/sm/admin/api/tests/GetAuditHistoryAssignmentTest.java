package com.savvas.sm.admin.api.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.audithistory.AuditHistory;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class GetAuditHistoryAssignmentTest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String districtAdminDetails;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String subDistrictId;
    public static String schoolId;
    public static String districtId;
    public static String teacherId;
    public static String username;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgList;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    Map<String, String> response = new HashMap<>();
    String endPoint;
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String courseId;
    HashMap<String, String> assignmentDetails;
    AuditHistory history = new AuditHistory();

    HashMap<String, String> groupdetails = new HashMap<>();
    Map<String, Map<String, String>> db = new LinkedHashMap<>();
    SqlHelperAssignment dbhelper = new SqlHelperAssignment();

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        Log.message( districtAdminDetails );
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        Log.message( teacherDetails );
        teacherStaffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        studentDetailsSchool1 = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );
    }

    @Test ( priority = 1, dataProvider = "testdata_Positive", groups = { "smoke_test_case", "Organization", "SMK-50229", "P1", "API" } )
    public void getAuditHistoryAssignment_Positive( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        String studentDetails = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );
        String studentID = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );
        //        new RBSUtils().updateUserOrgId( studentDetails, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( teacherOrgId ) );

        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentID ) );
        Log.testCaseInfo( tcDescription );
        switch ( scenario ) {
            case "valid":
                Log.message( teacherUsername );
                courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherStaffId, teacherOrgId, DataSetupConstants.SETTINGS, "Custom Course" + System.nanoTime() );
                Log.message( courseId );
                HashMap<String, String> assignmentDetails = new HashMap<>();
                assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
                Log.message( studentID );
                HashMap<String, String> assignMultipleAssignments = assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentID ), Arrays.asList( courseId ) );
                Log.message( assignMultipleAssignments + "" );
                assignmentDetails.put( AdminAPIConstants.COURSE_ID, courseId );
                //HashMap<String, String> assignment = assignAssignment( smUrl, assignmentDetails,Arrays.asList( studentID ) , AdminAPIConstants.USERS_TYPE );
                HashMap<String, String> deleteAssignment = deleteAssignment( smUrl, assignmentDetails );
                Log.message( deleteAssignment + "" );
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password ), teacherOrgId,
                        SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" ), districtId );
                db = dbhelper.getAuditHistoryAssignments( teacherOrgId );
                break;
            case "valid with sub-district admin":
                //Creating teacher and student
                String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
                String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

                //creating student
                String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
                String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

                groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupdetails.put( GroupConstants.GROUP_OWNER_ID, subdistrictSchoolTeacherID );
                groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( subdistrictSchoolStudentId ) );

                // Creating course under the teacher
                String courseName = "Custom Course" + System.nanoTime();
                courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, password ), DataSetupConstants.MATH, subdistrictSchoolTeacherID, RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                        DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );

                // Assigning the course to the student
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AdminAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                assignmentDetails.put( AdminAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, password ) );
                HashMap<String, String> responseassign = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), Arrays.asList( courseId ) );
                Log.message( responseassign + "" );

                assignmentDetails.put( AdminAPIConstants.COURSE_ID, courseId );
                // Deleting the assignment from the teacher
                HashMap<String, String> deleteAssignment1 = deleteAssignment( smUrl, assignmentDetails );
                Log.message( deleteAssignment1 + "" );
                // Getting Audit history for the subdistrict admin
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                        SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), RBSDataSetupConstants.USERID ), RBSDataSetup.subDistrictwithSchoolId );
                db = dbhelper.getAuditHistoryAssignments( RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                break;
            case "valid with school admin":
                String schoolAdmindetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdmindetails, RBSDataSetupConstants.USERID );
                String schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdmindetails, RBSDataSetupConstants.USERNAME );
                Log.message( schoolAdmindetails );
                String primarySchoolID = SMUtils.getKeyValueFromResponse( schoolAdmindetails, "primaryOrgId" );

                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( schoolAdminUsername, password ), primarySchoolID, schoolAdminUserID, primarySchoolID );
                db = dbhelper.getAuditHistoryAssignments( primarySchoolID );
                break;
            case "valid with savvas admin":
                String savvasAdmindetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
                String savvasAdminUserID = SMUtils.getKeyValueFromResponse( savvasAdmindetails, RBSDataSetupConstants.USERID );
                String savvasAdminUsername = SMUtils.getKeyValueFromResponse( savvasAdmindetails, RBSDataSetupConstants.USERNAME );
                String savvasAdminOrgId = SMUtils.getKeyValueFromResponse( savvasAdmindetails, "primaryOrgId" );

                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( savvasAdminUsername, password ), RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ), savvasAdminUserID,
                        savvasAdminOrgId );
                db = dbhelper.getAuditHistoryAssignments( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                break;
            default:
                break;
        }
        Log.message( response + "" );
        String statusCode = response.get( Constants.STATUS_CODE );
        Log.assertThat( statusCode.equals( expResCode ), "The Status code is expected " + expResCode + " and actual " + statusCode + " Verified", "The Status code is expected " + expResCode + " and actual " + statusCode + "is not Verified" );
        Log.message( db + "" );

        //data validation
        Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), "assignmentTitle" ) ).forEach( iter -> {
            Map<String, String> deletedAssignments = new HashMap<String, String>();
            deletedAssignments.put( "deletedBy", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "deletedBy", iter ) );
            deletedAssignments.put( "assignmentTitle", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "assignmentTitle", iter ) );
            deletedAssignments.put( "studentOrGroupName", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "studentOrGroupName", iter ) );
            deletedAssignments.put( "recordType", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "recordType", iter ) );
            deletedAssignments.put( "assignedBy", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "assignedBy", iter ) );
            deletedAssignments.put( "courseName", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "courseName", iter ) );
            getAuditHistoryAssignment.put( deletedAssignments.get( "assignmentTitle" ) + " , " + deletedAssignments.get( "studentOrGroupName" ), deletedAssignments );
        } );
        Log.assertThat( db.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), getAuditHistoryAssignment.get( entry.getKey() ) ) ), "API fetched all the audit history properly",
                "API is not fetching all the audit assignment properly" );

        //        Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetAuditHistory", statusCode, response.get( "body" )) , "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "testdata_Negative", groups = { "Organization", "SMK-50229", "P1", "API" } )
    public void getAuditHistoryAssignment_Negative( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {
        HashMap<String, String> groupdetails = new HashMap<>();
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        String studentDetails = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ).get( "Student1" );
        String studentID = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );

        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentID ) );
        Log.testCaseInfo( tcDescription );
        switch ( scenario ) {
            case "invalid with wrong authorization":
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password ) + "invalid", teacherOrgId,
                        SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" ), districtId );
                break;
            case "invalid with wrong userid":
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password ), teacherOrgId,
                        SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" ) + "invalid", districtId );
                break;
            case "invalid with empty userid":
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password ), teacherOrgId, "", districtId );
                break;
            case "invalid with empty orgid":
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password ), teacherOrgId,
                        SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" ), "" );
                break;
            case "invalid with wrong orgid":
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password ), teacherOrgId + "invalid",
                        SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" ), districtId + "Invalid" );
                break;
            case "invalid with student details":
                String studentIDs = SMUtils.getKeyValueFromResponse( studentDetailsSchool1, RBSDataSetupConstants.USERID );
                String studentUsername = SMUtils.getKeyValueFromResponse( studentDetailsSchool1, RBSDataSetupConstants.USERNAME );
                String studentOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( studentUsername, password ), studentOrgId, studentIDs, studentOrgId );
                break;
            case "invalid with teacher details":
                response = history.getAuditHistoryAssignmentList( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), teacherOrgId, teacherStaffId, teacherOrgId );
                break;
            default:
                break;
        }
        Log.message( response + "" );
        String statusCode = response.get( Constants.STATUS_CODE );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expResCode ), "The Status code is expected " + expResCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + expResCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetAuditHistory", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

        Log.testCaseResult();
    }

    @DataProvider ( name = "testdata_Positive" )
    public Object[][] validStatusCodeTestData1() {
        Object[][] data = { { "tcAuditHistoryAssignment002", "Verify staus code 200 when user pass correct header and endpoint", "200", "valid" },
                { "tcAuditHistoryAssignment0010", "Verify response when sub district admin details passed in header", "200", "valid with sub-district admin" },
                { "tcAuditHistoryAssignment0011", "Verify response when school admin details passed in header", "200", "valid with school admin" },
                { "tcAuditHistoryAssignment0012", "Verify response when savvas admin details passed in header", "200", "valid with savvas admin" } };
        return data;
    }

    @DataProvider ( name = "testdata_Negative" )
    public Object[][] validStatusCodeTestData() {
        Object[][] data = { { "tcAuditHistoryAssignment003", "Verify status code 401, when user pass wrong authorization passed in header.", "401", "invalid with wrong authorization" },
                { "tcAuditHistoryAssignment004", "Verify status code 401, when user pass valid authorization and invalid user-id.", "401", "invalid with wrong userid" },
                { "tcAuditHistoryAssignment005", "Verify status code 401, when user pass valid authorization and empty user-id.", "401", "invalid with empty userid" },
                { "tcAuditHistoryAssignment006", "Verify status code 403, when empty org-id passed in headers with valid authorization  and valid user-id", "403", "invalid with empty orgid" },
                { "tcAuditHistoryAssignment007", "Verify status code 403, when invalid org-id passed in headers with valid authorization  and valid user-id", "403", "invalid with wrong orgid" },
                { "tcAuditHistoryAssignment008", "Verify status code 403, when student authorization passed in header", "403", "invalid with student details" },
                { "tcAuditHistoryAssignment009", "Verify status code 403, when teacher authorization passed in header", "403", "invalid with teacher details" }, };
        return data;
    }

    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AdminAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AdminAPIConstants.ORG_ID ) );
        return headers;
    }

    public HashMap<String, String> deleteAssignment( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AdminAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AdminAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AdminAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endpoint = AdminAPIConstants.DELETE_ASSIGNMENT_API;
        endpoint = endpoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{contentbaseId}", courseID );

        return RestHttpClientUtil.DELETE( envUrl, endpoint, headers, params );
    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     *
     * @param envUrl
     * @param assignmentDetails
     * @param studentRumbaIds
     * @param type
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignMultipleAssignments( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, List<String> courseIDs ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AdminAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AdminAPIConstants.TEACHER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AdminAPIConstants.ASSIGN_MULTIPLE_ASSIGNMENTS_API;

        String payload = "{\n\"ids\": [\"{studentRumbaIds}\"],\n\"contentBaseIds\":[\"{courseIds}\"],\n\"type\":\"users\"\n}";
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( payload );

        if ( !studentRumbaIds.isEmpty() && !courseIDs.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AdminAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            listString = "";
            for ( String courseID : courseIDs ) {

                listString += courseID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AdminAPIConstants.COURSE_IDS ), listString ) );
        } else {
            Log.fail( "Student / Course ID missing" );
        }

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );
        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );

    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

}
