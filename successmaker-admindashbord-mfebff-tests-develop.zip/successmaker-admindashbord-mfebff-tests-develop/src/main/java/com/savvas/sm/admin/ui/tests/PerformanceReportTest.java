package com.savvas.sm.admin.ui.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.admindatasetup.AdminData;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.Dashboard;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.FixupFunction;

import io.restassured.response.Response;

public class PerformanceReportTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String multiSchoolusername;
    private String singleSchoolusername;
    private String password;
    private String flexSchool;
    private String orgId;
    private String teacherDetails;
    private String teacherId;
    private String teacherUsername;
    private String student1Details;
    private String student2Details;
    private String student3Details;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    
    private List<String> courseIDs = new ArrayList<>();
    private String courseId;
    
    //Tokens
    private String districtAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;
    
    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;
    private String districtId = null;
    

    @BeforeClass(alwaysRun=true)
    public void initTest() throws Exception {
    	districtId = configProperty.getProperty( "district_ID" );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        Log.message( RBSDataSetup.teacherStudentRelation.toString() );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        
        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        student1Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student2Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student3Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) );
        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        Log.message( "Assignment IDs - " + assignmentIds );
        
        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "021" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Multi-School Admin
        multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "0027" );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "028" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        multiSchoolusername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
        singleSchoolusername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        
        executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );

        executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );
        
        FixupFunction.executeFixupFunctions( orgId );
    }

    @Test ( description = "Verify the Performance Report", groups = { "SMK-51098", "adminDashboard", "organizationDropdown", "smoke_test_case", "Sanity Test" }, priority = 1 )
    public void tcSMPerformanceReport001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMPerformanceReport001: Verify the Performance Report. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify Performance Report widget is present in admin dashboard" );
            SMUtils.logDescriptionTC( "Verify the heading present in Performance Report widget" );
            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.PERFORMANCE_REPORT ), "Performance report header is present in the admin dashboard page", "Performance report header is not present in the admin dashboard page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Subject dropdown is present in Performance Report" );
            SMUtils.logDescriptionTC( "Verify Subject dropdown should have Math and Reading values to select in Performance Report" );
            dashBoardPage.expandSubjectDropdown();
            Log.assertThat( dashBoardPage.getOptionsInSubjectDropdown().equals( Dashboard.SUBJECTS ), "Math and Reading are present in the subject dropdown", "Math and Reading are not present in the subject dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Subject dropdown is a single select dropdown in Performance Report" );
            dashBoardPage.selectOptionInSubjectDropdown( Dashboard.SUBJECTS.get( 1 ) );
            Log.assertThat( dashBoardPage.getSelectedSubjectInPerformanceReport().equalsIgnoreCase( Dashboard.SUBJECTS.get( 1 ) ), " Subject dropdown is a single select dropdown in Performance Report",
                    " Subject dropdown is not a single select dropdown in Performance Report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify LARGEST GAIN is present in Performance Report" );
            SMUtils.logDescriptionTC( "Verify SMALLEST GAIN is present in Performance Report" );
            Log.assertThat( dashBoardPage.getGainHeaders().equals( Dashboard.GAIN_HEADERS ), "LARGEST GAIN and SMALLEST GAIN are displayed properly in performance report widget",
                    "LARGEST GAIN and SMALLEST GAIN are not displayed properly in performance report widget" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Course Level heading is displayed in x-axis of the graph in Performance Report" );
            Log.assertThat( dashBoardPage.getXAxisLabel().equalsIgnoreCase( Dashboard.X_AXIS_LABEL ), "Course Level heading is displayed in x-axis of the graph in Performance Report",
                    "Course Level heading is not displayed in x-axis of the graph in Performance Report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify x-axis in the graph displays Course Level values in Performance Report" );
            Log.assertThat( dashBoardPage.getXAxisIntervals().equals( Dashboard.X_AXIS_INTERVALS ), "x axis intervals are displayed properly in Performance report", "x axis intervals are not displayed properly in Performance report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Grade heading is displayed in y-axis of the graph in Performance Report" );
            Log.assertThat( dashBoardPage.getYAxisLabel().equalsIgnoreCase( Dashboard.Y_AXIS_LABEL ), "Grade heading is displayed in x-axis of the graph in Performance Report",
                    "Grade heading is not displayed in x-axis of the graph in Performance Report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify y-axis in the graph displays Grade values in Performance Report" );
            Log.assertThat( dashBoardPage.getYAxisIntervals().equals( Dashboard.Y_AXIS_INTERVALS ), "y axis intervals are displayed properly in Performance report", "y axis intervals are not displayed properly in Performance report" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify course level value is displayed with the coloured horizontal bars in the graph in Performance Report" );
            SMUtils.logDescriptionTC( "Verify each grade's gain bar is represented with a unique color in the graph in Performance Report" );
            Log.assertThat( Dashboard.HEXA_COLORS_FOR_GRADES.containsAll( dashBoardPage.getColorsForPerformanceChartBars() ), "All grade's gains are represented in unique color", "All grade's gains are not represented in unique color" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify tooltip is appeared when mouse hovers on gain bar" );
            Log.assertThat( dashBoardPage.verifyTooltipContentForDisplayedBars(), "Tooltip is appeared with valid data when mouse hovers on gain bar", "Tooltip is not appeared with valid data when mouse hovers on gain bar" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify the data displayed based on the organization selected in organization selected in Organization dropdown" );
            SMUtils.logDescriptionTC( "Verify selected organization count is displayed in Performance Report" );

            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool, RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            dashBoardPage.clickApplySelectionButton();
            Log.assertThat( dashBoardPage.getSelectedOrganizationCountInPerformanceWidget().equalsIgnoreCase( String.format( Dashboard.SELECTED_ORGANIZATIONS_COUNT, 2 ) ),
                    "The Performance report data displayed based on the organization selected in organization selected in Organization dropdown",
                    "The Performance report data is not displayed based on the organization selected in organization selected in Organization dropdown" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify selected organization name is displayed in Performance Report" );
            // Uncheck all the organizations
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool ) );
            dashBoardPage.clickApplySelectionButton();
            //Collapase org dropdown
            dashBoardPage.collapseOrganizationDropdown();
            Log.assertThat( dashBoardPage.getSelectedOrganizationCountInPerformanceWidget().equalsIgnoreCase( flexSchool ), "Organization name is displayed in Performance Report if user selected single organization",
                    "Organization name is not displayed in Performance Report if user selected single organization" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Performance Report for school admin associated with two or more organization", groups = { "SMK-50724", "adminDashboard", "Performance Report Widget", "smoke_test_case", "Sanity Test" }, priority = 1 )
    public void tcSMPerformanceReport002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMperformanceReport002: Verify Performance Report for school admin associated with two or more organization. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( multiSchoolusername, password );
            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.PERFORMANCE_REPORT ), "The Performance Report Header is displayed", "The Performance Report Header is not displayed" );
            Log.assertThat( dashBoardPage.isSubjectDropdownPresent(), "The Subject drop down is displayed in the Performance Report widget", "The Subject drop down is not displayed in the Performance Report widget" );
            Log.assertThat( dashBoardPage.getGainHeaders().equals( AdminUIConstants.Dashboard.GAIN_HEADERS ), "The Gains are displayed", "The Gains are not displayed" );
            Log.assertThat( !dashBoardPage.getSelectedOrganizationCountInPerformanceWidget().isEmpty(), "The Organizations Count is displayed and verified in the performance report widget",
                    "The Organizations Count is not displayed and verified in the performance report widget" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Performance Report for school admin associated with single school", groups = { "SMK-50724", "adminDashboard", "Performance Report Widget", "smoke_test_case", "Sanity Test" }, priority = 1 )
    public void tcSMPerformanceReport003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMperformanceReport003: Verify Performance Report for school admin associated with single school. <small><b><i>[" + browser + "]</b></i></small>" );


        try {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( singleSchoolusername, password );
            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.PERFORMANCE_REPORT ), "The Performance Report Header is displayed", "The Performance Report Header is not displayed" );
            Log.assertThat( dashBoardPage.isSubjectDropdownPresent(), "The Subject drop down is displayed in the Performance Report widget", "The Subject drop down is not displayed in the Performance Report widget" );
            Log.assertThat( dashBoardPage.getGainHeaders().equals( AdminUIConstants.Dashboard.GAIN_HEADERS ), "The Gains are displayed", "The Gains are not displayed" );
            Log.assertThat( !dashBoardPage.getSelectedOrganizationCountInPerformanceWidget().isEmpty(), "The Organizations Count is displayed and verified in the performance report widget",
                    "The Organizations Count is not displayed and verified in the performance report widget" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 5 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "100", "3", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "31" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Reading Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "31" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

}
