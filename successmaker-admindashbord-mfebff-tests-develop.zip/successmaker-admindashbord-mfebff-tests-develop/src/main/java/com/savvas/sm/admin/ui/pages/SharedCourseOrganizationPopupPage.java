package com.savvas.sm.admin.ui.pages;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SharedCourses;
import com.savvas.sm.utils.SMUtils;

public class SharedCourseOrganizationPopupPage extends LoadableComponent<SharedCourseOrganizationPopupPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    // *******************Shared course-organization list
    // popup*******************

    @FindBy ( css = "cel-dialog-header div.dialog-header h1" )
    WebElement popupHeader;

    @FindBy ( css = "span.selected-course-name" )
    WebElement courseName;

    @FindBy ( css = "edit-shared-courses-list form.searchBar__form input" )
    WebElement searchBox;

    @FindBy ( css = "cel-button.share-all" )
    WebElement btnShareAll;

    @FindBy ( css = "cel-button.unshare-all" )
    WebElement btnUnShareAll;

    @FindBy ( css = "div.organizations-name" )
    WebElement lblOrganizations;

    @FindBy ( css = "div.organizations-shared-only span" )
    WebElement lblShowSharedOnly;

    @FindBy ( css = "label.text-label" )
    WebElement lblSelectedCourse;

    @FindBy ( css = "cel-checkbox.shared-checkbox" )
    WebElement chbxShowSharedCourseOnly;

    @FindBy ( css = "button.info-button" )
    WebElement helpIcon;

    @FindBy ( css = "button#closeBtn" )
    WebElement closeIcon;

    @FindBy ( css = "edit-shared-courses-list cel-button.cancel-btn-wrapper" )
    WebElement btnCancel;

    @FindBy ( css = "edit-shared-courses-list cel-button.action-btn-wrapper" )
    WebElement btnSave;

    @FindBy ( css = "div.organizations-info" )
    List<WebElement> organizations;

    @FindBy ( css = "div.not-found" )
    WebElement lblNoResultFound;

    // *********************Child elements****************************//

    private static String childSecondaryButton = ".secondary_button";
    private static String childPrimaryButton = ".primary_button";
    private static String checkBox = "div.checkbox-container input";
    private static String lblOrganizationName = "div[title]";
    private static String btnshare = "cel-button.share-button";
    private static String btnUnshare = "cel-button.unshare-button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public SharedCourseOrganizationPopupPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, popupHeader );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, popupHeader, 10 ) ) {
            Log.message( "Shared course-organization list popup loaded successfully." );
        } else {
            Log.fail( "Shared course-organization list popup did not load." );
        }
    }

    /**
     * To get the popup header
     * 
     * @return
     */
    public String getPopupHeaderText() {
        SMUtils.waitForElement( driver, popupHeader );
        Log.message( "Gettinng popup header!" );
        return SMUtils.getTextOfWebElement( popupHeader, driver );
    }

    /**
     * To get the selected course name
     * 
     * @return
     */
    public String getSelectedCourseName() {
        SMUtils.waitForElement( driver, courseName );
        Log.message( "Gettinng selected course name!" );
        return SMUtils.getTextOfWebElement( courseName, driver );
    }

    /**
     * To get the selected course label
     * 
     * @return
     */
    public String getSelectedCourseLabel() {
        SMUtils.waitForElement( driver, lblSelectedCourse );
        Log.message( "Gettinng selected course label!" );
        return SMUtils.getTextOfWebElement( lblSelectedCourse, driver );
    }

    /**
     * To get the organzations label
     * 
     * @return
     */
    public String getOrganizationLabel() {
        SMUtils.waitForElement( driver, lblOrganizations );
        Log.message( "Gettinng selected course label!" );
        return SMUtils.getTextOfWebElement( lblOrganizations, driver );
    }

    /**
     * To get the 'show shared only' label
     * 
     * @return
     */
    public String getShowSharedCourseLabel() {
        SMUtils.waitForElement( driver, lblShowSharedOnly );
        Log.message( "Gettinng 'show shared only' label!" );
        return SMUtils.getTextOfWebElement( lblShowSharedOnly, driver );
    }

    /**
     * To enter text in the search box
     * 
     */
    public void enterTextInSearchBox( String searchText ) {
        SMUtils.waitForElement( driver, searchBox );
        SMUtils.enterValue( searchBox, searchText );
    }

    /**
     * To get the Entered value in the search box
     * 
     * @return
     */
    public String getEneteredValueInSearchBox() {
        SMUtils.waitForElement( driver, searchBox );
        return SMUtils.getAttributeOfWebElement( searchBox, driver, "value" );
    }

    /**
     * To get 'No results found' message
     */
    public String getNoResultFoundErrorMessage() {
        SMUtils.waitForElement( driver, lblNoResultFound );
        return SMUtils.getTextOfWebElement( lblNoResultFound, driver );
    }

    /**
     * To Verify the availability of the 'share all' button
     * 
     * @return
     */
    public boolean isShareAllButtonPresent() {
        SMUtils.waitForElement( driver, btnShareAll );
        return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, btnShareAll, childSecondaryButton ) ) && SMUtils.getTextOfWebElement( btnShareAll, driver ).equalsIgnoreCase( SharedCourses.SHARE_ALL );
    }

    /**
     * To click Share All button
     */
    public void clickShareAll() {
        SMUtils.waitForElement( driver, btnShareAll );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnShareAll, childSecondaryButton ) );
        Log.message( "Clicked share all button!" );
    }

    /**
     * To Verify the availability of the 'share all' button
     * 
     * @return
     */
    public boolean isUnshareAllButtonPresent() {
        SMUtils.waitForElement( driver, btnUnShareAll );
        return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, btnUnShareAll, childSecondaryButton ) ) && SMUtils.getTextOfWebElement( btnUnShareAll, driver ).equalsIgnoreCase( SharedCourses.UNSAHERE_ALL );
    }

    /**
     * To click Unshare All button
     */
    public void clickUnShareAll() {
        SMUtils.waitForElement( driver, btnUnShareAll );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnUnShareAll, childSecondaryButton ) );
        Log.message( "Clicked unshare all  button!" );
    }

    /**
     * To verify the availability of the 'show shared only' checkbox
     * 
     * @return
     */
    public boolean isShowSharedOnlyCheckboxPresent() {
        SMUtils.waitForElement( driver, chbxShowSharedCourseOnly );
        return SMUtils.isElementPresent( chbxShowSharedCourseOnly );
    }

    /**
     * To select/unselect the 'show shared only' checkbox
     */
    public void clickShowSharedOnlyCheckbox() {
        SMUtils.waitForElement( driver, chbxShowSharedCourseOnly );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chbxShowSharedCourseOnly, checkBox ) );
        if ( SMUtils.getWebElementDirect( driver, chbxShowSharedCourseOnly, checkBox ).isSelected() ) {
            Log.message( "Checked - show shared only checkbox!" );
        } else {
            Log.message( "Unchecked - show shared only checkbox!" );
        }
    }

    /**
     * To get all the listed organizations
     */
    public List<String> getAllListedOrganization() {
        SMUtils.waitForElement( driver, popupHeader );
        Log.message( "Getting all the listed organizations!" );
        return SMUtils.getAllTextFromWebElementList( organizations.stream().map( element -> SMUtils.getChildWebElementFromParent( element, lblOrganizationName ) ).collect( Collectors.toList() ) );
    }

    /**
     * To get course shared organizations
     */
    public List<String> getCourseSharedOrganizations() {
        SMUtils.waitForElement( driver, popupHeader );
        Log.message( "Getting course shared organizations!" );
        return SMUtils.getAllTextFromWebElementList( organizations.stream().filter( element -> {
            try {
                return Objects.nonNull( SMUtils.getChildWebElementFromParent( element, btnUnshare ) );
            } catch ( Exception e ) {
                return false;
            }
        } ).map( element -> SMUtils.getChildWebElementFromParent( element, lblOrganizationName ) ).collect( Collectors.toList() ) );
    }

    /**
     * To get course unshared organizations
     */
    public List<String> getCourseUnsharedOrganizations() {
        SMUtils.waitForElement( driver, popupHeader );
        Log.message( "Getting course unshared organizations!" );
        return SMUtils.getAllTextFromWebElementList( organizations.stream().filter( element -> {
            try {
                return Objects.nonNull( SMUtils.getChildWebElementFromParent( element, btnshare ) );
            } catch ( Exception e ) {
                return false;
            }
        } ).map( element -> SMUtils.getChildWebElementFromParent( element, lblOrganizationName ) ).collect( Collectors.toList() ) );
    }

    /**
     * To click share button for given organizations
     * 
     * @Param organizationNames
     */
    public void clickShareButtonForGivenOrganizations( List<String> organizationNames ) {
        SMUtils.waitForElement( driver, popupHeader );
        organizations.stream().filter( element -> {
            try {
                return Objects.nonNull( SMUtils.getChildWebElementFromParent( element, btnshare ) ) && organizationNames.contains( SMUtils.getTextOfWebElement( SMUtils.getChildWebElementFromParent( element, lblOrganizationName ), driver ) );
            } catch ( Exception e ) {
                return false;
            }
        } ).forEach( element -> {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, SMUtils.getChildWebElementFromParent( element, btnshare ), childSecondaryButton ) );
            Log.message( "Clicked share button for organization - " + SMUtils.getTextOfWebElement( SMUtils.getChildWebElementFromParent( element, lblOrganizationName ), driver ) );
        } );
    }

    /**
     * To click unshare button for given organizations
     * 
     * @Param organizationNames
     */
    public void clickUnShareButtonForGivenOrganizations( List<String> organizationNames ) {
        SMUtils.waitForElement( driver, popupHeader );
        organizations.stream().filter( element -> {
            try {
                return Objects.nonNull( SMUtils.getChildWebElementFromParent( element, btnUnshare ) ) && organizationNames.contains( SMUtils.getTextOfWebElement( SMUtils.getChildWebElementFromParent( element, lblOrganizationName ), driver ) );
            } catch ( Exception e ) {
                return false;
            }
        } ).forEach( element -> {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, SMUtils.getChildWebElementFromParent( element, btnUnshare ), childSecondaryButton ) );
            Log.message( "Clicked unshare button for organization - " + SMUtils.getTextOfWebElement( SMUtils.getChildWebElementFromParent( element, lblOrganizationName ), driver ) );
        } );
    }

    /**
     * To verify the share/unshare button for all organizations
     *
     * @return
     */
    public boolean isShareOrUnshareButtonDisplayedForAllOrganizations() {
        SMUtils.waitForElement( driver, popupHeader, 8 );
        return organizations.stream().allMatch( element -> {
            try {
                if ( Objects.nonNull( element.findElement( By.cssSelector( btnshare ) ) ) ) {
                    return true;
                }
            } catch ( Exception e ) {
                if ( Objects.nonNull( element.findElement( By.cssSelector( btnUnshare ) ) ) ) {
                    return true;
                }
            }
            return false;
        } );
    }

    /**
     * To verify the availability of the help icon
     */
    public boolean isHelpIconPresent() {
        SMUtils.waitForElement( driver, helpIcon );
        return SMUtils.isElementPresent( helpIcon );
    }

    /**
     * To click help Icon
     */
    public void clickHelpIcon() {
        SMUtils.waitForElement( driver, helpIcon );
        SMUtils.clickJS( driver, helpIcon );
        Log.message( "Clicked help icon!" );
    }

    /**
     * To verify the availability of the close icon
     */
    public boolean isCloseIconPresent() {
        SMUtils.waitForElement( driver, closeIcon );
        return SMUtils.isElementPresent( closeIcon );
    }

    /**
     * To click close Icon
     */
    public SharedCoursesListViewPage clickCloseIcon() {
        SMUtils.waitForElement( driver, closeIcon );
        SMUtils.clickJS( driver, closeIcon );
        Log.message( "Clicked close icon!" );
        return new SharedCoursesListViewPage( driver ).get();
    }

    /**
     * To get the text of close button
     */
    public String getCancelButtonText() {
        SMUtils.waitForElement( driver, btnCancel );
        return SMUtils.getTextOfWebElement( btnCancel, driver );
    }

    /**
     * To verify the close button is enabled or not
     * 
     * @return
     */
    public boolean isCancelButtonEnabled() {
        SMUtils.waitForElement( driver, btnCancel );
        return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, btnCancel, childSecondaryButton ) );
    }

    /**
     * To click close button
     * 
     * @return
     */
    public SharedCoursesListViewPage clickCancelButton() {
        SMUtils.waitForElement( driver, btnCancel );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnCancel, childSecondaryButton ) );
        Log.message( "Clicked close button!" );
        return new SharedCoursesListViewPage( driver ).get();
    }

    /**
     * To get the text of Save button
     */
    public String getSaveButtonText() {
        SMUtils.waitForElement( driver, btnSave );
        return SMUtils.getTextOfWebElement( btnSave, driver );
    }

    /**
     * To verify the save button is enabled or not
     * 
     * @return
     */
    public boolean isSaveButtonEnabled() {
        SMUtils.waitForElement( driver, btnSave );
        return SMUtils.isElementEnabled( SMUtils.getWebElementDirect( driver, btnSave, childPrimaryButton ) );
    }

    /**
     * To click Save button
     * 
     * @return
     */
    public SharedCoursesListViewPage clickSaveButton() {
        SMUtils.waitForElement( driver, btnSave );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSave, childPrimaryButton ) );
        Log.message( "Clicked save button!" );
        return new SharedCoursesListViewPage( driver ).get();
    }

}
