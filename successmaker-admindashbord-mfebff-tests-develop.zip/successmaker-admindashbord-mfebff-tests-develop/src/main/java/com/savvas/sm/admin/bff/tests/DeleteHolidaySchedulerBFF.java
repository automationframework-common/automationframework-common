package com.savvas.sm.admin.bff.tests;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.settings.HolidaySchedulerBFF;

import io.restassured.response.Response;
import com.savvas.sm.data.CreateAdmins;

public class DeleteHolidaySchedulerBFF extends EnvProperties {

    private String districtId;
    private String userName;
    private String savvasUserName;
    private String savvasUserId;
    private String password;
    private String userId;
    private String orgId;
    private String flexSchool;
    Response response;
    String startDate;
    String endDate;
    String description;
    String holidayDetails;
    List<LocalDate> dates;
    private String smUrl;

    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String schoolAdminDetails = null;
    private String savvasAdminDetails = null;
    private String multiSchoolAdminDetails = null;

    //Tokens
    private String savvasAdminToken = null;
    private String districtAdminToken = null;
    private String schoolAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    
    public static String subDistrictwithSchool_name = null;
    public static String subDistrictOrgId_with_school = null;
    
    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        districtId = configProperty.getProperty( "district_ID" );
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );


        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "047" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        
        // Getting district admin details
        userName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );
        
      //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "047" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminToken=new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        
        //Sub-District Admin Creation
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "047" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        
      //Multi-School Admin
        multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "95" );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        
        //Savvas Admin
        savvasAdminDetails = createAdminsClass.createSavvasAdmin( smUrl, districtId, "047" );
        Log.message( "********" );
        Log.message( "savvasAdminDetails from Create Admins are " + savvasAdminDetails );
        Log.message( "********" );
        savvasAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

       

        // Getting savvas admin details
        savvasUserName = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        savvasUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    /**
     * This method is used to test the negative scenarios for Save Holiday
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "positiveScenarioTestData", groups = { "HolidayScheduler", "SMK-51799", "P2", "API","smoke_test_case","positive_test_case" } )
    public void deleteHolidayPositive( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );
        // headers

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        // Getting dates of current week
        LocalDate listDays = LocalDate.now();
        dates = Arrays.asList( DayOfWeek.values() ).stream().map( listDays::with ).collect( Collectors.toList() );
        startDate = dates.get( 0 ).toString();
        endDate = dates.get( 4 ).toString();
        description = "SM Holidays";
        List<String> savedDates = new ArrayList<>();
        IntStream.rangeClosed( 0, 4 ).forEach( itr -> {
            savedDates.add( dates.get( itr ).toString() );
        } );
        switch ( scenarioType ) {
            case "VALID":
                // Creating holidays
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + districtAdminToken );
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\", description: \\\"" + description + "\\\" }";
                new HolidaySchedulerBFF().saveHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );

                // Verify holiday is added
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                verifySavedHolidays( response, savedDates, description );

                // Deleting holidays
                endDate = dates.get( 0 ).toString();
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\" }";
                new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );

                // Validation
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                verifyDeletedHolidays( response, Arrays.asList( startDate ) );
                break;

            case "MULTIPLE_HOLIDAYS":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + districtAdminToken );
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\" }, { startDate: \\\"" + startDate + "\\\", endDate: \\\"" + dates.get( 1 ).toString() + "\\\" }";
                new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );

                // Validation
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                verifyDeletedHolidays( response, Arrays.asList( startDate, dates.get( 1 ).toString() ) );
                break;

            case "DATE_RANGE_HOLIDAYS":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + districtAdminToken );
                endDate = dates.get( 2 ).toString();
                description = "Long Leave";
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\" }";
                new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );

                // Validation
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                verifyDeletedHolidays( response, Arrays.asList( startDate, dates.get( 1 ).toString(), dates.get( 2 ).toString() ) );
                break;

            case "SAVVAS_ADMIN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAdminToken );
                startDate = dates.get( 3 ).toString();
                endDate = dates.get( 3 ).toString();
                holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\" }";
                new HolidaySchedulerBFF().deleteHoliday_BFF( headers, "Savvas Admin", userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );

                // Validation
                response = new HolidaySchedulerBFF().getHoliday_BFF( headers, "Savvas Admin", savvasUserId, districtId, Arrays.asList( AdminAPIConstants.DATE, AdminAPIConstants.DESCRIPTION ), districtId );
                verifyDeletedHolidays( response, Arrays.asList( startDate ) );
                break;

            default:
                break;

        }
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarioTestData" )
    public Object[][] positiveScenarioTestData() {

        return new Object[][] { { "SMK-19678", "Verify the deleteHolidayScheduler graphql query is removing holiday from list when district admin removes the holiday from holiday list", CommonAPIConstants.STATUS_CODE_OK, "VALID" },
                { "SMK-19683", "Verify the deleteHolidayScheduler graphql query is deleting holiday listwhen admin try to delete the multiple holiday records at once.", CommonAPIConstants.STATUS_CODE_OK, "MULTIPLE_HOLIDAYS" },
                { "SMK-19684", " Verify the deleteHolidayScheduler graphql is deleting the holiday for a date range when admin try to delete it.", CommonAPIConstants.STATUS_CODE_OK, "DATE_RANGE_HOLIDAYS" },
                { "SMK-19682", "Verify the deleteHolidayScheduler graphql query is removing holiday from list when Savvas admin remove the holiday from holiday list.", CommonAPIConstants.STATUS_CODE_OK, "SAVVAS_ADMIN" } };
    }

    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "HolidayScheduler", "SMK-51799", "P2", "API" } )
    public void deleteHolidayNegative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        startDate = dates.get( 4 ).toString();
        endDate = dates.get( 4 ).toString();
        holidayDetails = "{ startDate: \\\"" + startDate + "\\\", endDate: \\\"" + endDate + "\\\" }";

        switch ( scenarioType ) {
            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) + "invalid" );
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );
                break;

            case "INVALID_QUERY":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId, holidayDetails, AdminAPIConstants.STATUS + "invalid", districtId );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId + "Invalid", districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, districtId + "Invalid", holidayDetails, AdminAPIConstants.STATUS, districtId );
                break;

            case "EMPTY_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, "", districtId, holidayDetails, AdminAPIConstants.STATUS, districtId );
                break;

            case "EMPTY_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.DISTRICT_ADMIN, userId, "", holidayDetails, AdminAPIConstants.STATUS, districtId );
                break;
                
            case "SUB_DISTRICT ADMIN":
            	String subdistrictUserID = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
            	String subdistrictUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
            	 response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.SUB_DISTRICT_ADMIN, subdistrictUserID, subDistrictwithSchoolId , holidayDetails, AdminAPIConstants.STATUS, subDistrictwithSchoolId );
            	break;
            	
            case "SCHOOL ADMIN":
            	String schoolAdminuserName = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
            	String schoolAdminuserId=SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
            	String schoolOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ));
            	headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( schoolAdminuserName, password ) );
            	 response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.SCHOOL_ADMIN, schoolAdminuserId, schoolOrgId , holidayDetails, AdminAPIConstants.STATUS, schoolOrgId );
            	break;
            	
            case "MULTI SCHOOL ADMIN":
            	String multiSchoolUserID = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERID );
                String multiSchoolUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
                String multiSchoolOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( multiSchoolUsername, password ) ); 	
                response = new HolidaySchedulerBFF().deleteHoliday_BFF( headers, AdminAPIConstants.SCHOOL_ADMIN, multiSchoolUserID, multiSchoolOrgId , holidayDetails, AdminAPIConstants.STATUS, multiSchoolOrgId );
            default:
                break;

        }

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        if ( scenarioType.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for Invalid Irrespective org's", "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for Invalid userId", "Not getting Unauthorized message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_USERID ), "Getting Invalid message for empty userId", "Not getting Invalid message for Invalid userId" );
        } else if ( scenarioType.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.EMPTY_ORGID ), "Getting Invalid message for empty orgId", "Not getting Invalid message for Invalid orgId" );
        }else if ( scenarioType.equalsIgnoreCase( "SUB_DISTRICT ADMIN" )||scenarioType.equalsIgnoreCase( "SCHOOL ADMIN" )||scenarioType.equalsIgnoreCase( "MULTI SCHOOL ADMIN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.FORBIDDEN_403 ), "Getting Access Denied message for School Admin/Sub District Admin", "The Access Denied message is not getting displayed for School Admin/Sub District Admin" );
    }
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {

        return new Object[][] { { "SMK-19685", "Verify '401: UnAuthorized' message in response when invalid Bearer token is given", CommonAPIConstants.STATUS_CODE_OK, "INVALID_BEARER_TOKEN" },
                { "SMK-19686", "Verify '400: Bad Request' in response when invalid query has been given", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "INVALID_QUERY" },
                { "SMK-19687", "Verify  '401: UnAuthorized'  and response when invalid userId is given in the query ", CommonAPIConstants.STATUS_CODE_OK, "INVALID_USER_ID" },
                { "SMK-19679", "Verify the deleteHolidayScheduler graphql query should not remove the holiday from list when sub-district admin removes the holiday from holiday list", CommonAPIConstants.STATUS_CODE_OK, "SUB_DISTRICT ADMIN" },
                { "SMK-19681", "Verify the deleteHolidayScheduler graphql query should not remove the holiday from list when school admin who belongs to single schools remove the holiday from holiday list ", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL ADMIN" },
                { "SMK-19680", "Verify the deleteHolidayScheduler graphql query should not remove the holiday from list when school admin who belongs to multiple schools remove the holiday from holiday list", CommonAPIConstants.STATUS_CODE_OK, "MULTI SCHOOL ADMIN" },
                { "SMK-19688", "Verify 403 status code and response when invalid organizationId is given in the query", CommonAPIConstants.STATUS_CODE_OK, "INVALID_ORG_ID" },
                { "SMK-19690", "Verify the message in response when empty userId is given in the query  ", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_USER_ID" },
                { "SMK-19691", " Verify the message in response when empty org-id is given in the query", CommonAPIConstants.STATUS_CODE_OK, "EMPTY_ORG_ID" } };
    }

    /**
     * To verify the saved holiday list
     * 
     * @param response
     * @param dateList
     * @param description
     */
    public void verifySavedHolidays( Response response, List<String> dateList, String description ) {
        Log.message( response.getBody().toString() + "" );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
        HashMap<String, String> keyValue = new HashMap<>();
        IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
            JSONObject jsonObj = new JSONObject( keyValueFromResponse );
            JSONArray ja = jsonObj.getJSONArray( "getHolidayScheduler" );
            JSONObject jObj = ja.getJSONObject( itr );
            keyValue.put( jObj.get( "date" ).toString(), jObj.get( "description" ).toString() );
        } );
        Log.message( "Date size: " + dateList.size() );
        IntStream.range( 0, dateList.size() ).forEach( date -> {
            Log.assertThat( keyValue.get( dateList.get( date ) ).equals( description ), "Holiday is added for the date: " + dateList.get( date ) + " with given description: " + description, "Holiday date or description is not same as given" );
        } );
    }

    /**
     * To verify the Deleted holiday list
     * 
     * @param response
     * @param dateList
     * @param description
     */
    public void verifyDeletedHolidays( Response response, List<String> dateList ) {
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
        HashMap<String, String> keyValue = new HashMap<>();
        Log.message( response.getBody().asString() );
        IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
            JSONObject jsonObj = new JSONObject( keyValueFromResponse );
            JSONArray ja = jsonObj.getJSONArray( "getHolidayScheduler" );
            JSONObject jObj = ja.getJSONObject( itr );
            keyValue.put( jObj.get( "date" ).toString(), jObj.get( "description" ).toString() );
        } );
        IntStream.range( 0, dateList.size() ).forEach( date -> {
            Log.assertThat( !keyValue.containsKey( dateList.get( date ) ), "Holiday( " + dateList.get( date ) + " ) is deleted successfully!!!", "Holiday( " + dateList.get( date ) + " ) is not deleted" );
        } );
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

}