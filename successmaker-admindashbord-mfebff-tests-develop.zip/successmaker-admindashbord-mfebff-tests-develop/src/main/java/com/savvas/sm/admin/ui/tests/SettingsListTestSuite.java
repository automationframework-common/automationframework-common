package com.savvas.sm.admin.ui.tests;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.HolidaySchedulerEditPopupPage;
import com.savvas.sm.admin.ui.pages.MSDASettingsPopupPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SettingsListTestSuite extends EnvProperties {

    private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password;
    private String orgId;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    List<LocalDate> dates;
    String startDate;
    String endDate;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        username = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify the Settings page is loaded,When district name is searched in organization search field", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList001: Verify the Settings page is loaded,When district name is searched in organization search field <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7200f77de565ac017e248148670654" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify the settings page is loaded,When school name is searched in organization search field.", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList002: Verify the settings page is loaded,When school name is searched in organization search field. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7209887f513da0017f53a5e46d026c" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify the Settings page is loaded,When subdistrict name is searched in organization search filed.", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        
        try {
            Log.testCaseInfo( "tcSettingList003: Verify the Settings page is loaded,When subdistrict name is searched in organization search filed. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a72019a7f90ca06017f962de1830086" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Settings page is loaded,When district ID is searched in organization search field.", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList004: Verify the Settings page is loaded,When district ID is searched in organization search field. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7200f77de565ac017e248148670654" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();
            
            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify the Settings page is loaded,When school ID is searched in organization search field.", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList005: Verify the Settings page is loaded,When school ID is searched in organization search field. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7209887f513da0017f53a5e46d026c" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();
            
            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Settings page is loaded.When subdistrict ID is searched in organization search field.", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList006: Verify the Settings page is loaded.When subdistrict ID is searched in organization search field. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a72019a7f90ca06017f962de1830086" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();
            
            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify user able to edit settings after clicked successmaker admin links for district admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList007: Verify user able to edit settings after clicked successmaker admin links for district admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7200f77de565ac017e248148670654" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            HolidaySchedulerEditPopupPage naviagteToEditHolidaySchedulerPage = settingpage.naviagteToEditHolidaySchedulerPage("Holiday Scheduler");
            Log.assertThat(naviagteToEditHolidaySchedulerPage.getHeaderText().contains(AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday Scheduler text is displaying", "Edit Holiday Scheduler text is displaying");
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify user able to edit settings after clicked successmaker admin links for school admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList008: Verify user able to edit settings after clicked successmaker admin links for school admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7209887f513da0017f53a5e46d026c" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            HolidaySchedulerEditPopupPage naviagteToEditHolidaySchedulerPage = settingpage.naviagteToEditHolidaySchedulerPage("Holiday Scheduler");
            Log.assertThat(naviagteToEditHolidaySchedulerPage.getHeaderText().contains(AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday Scheduler text is displaying", "Edit Holiday Scheduler text is displaying");
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify user able to edit settings after clicked successmaker admin links for sub-district admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList009() throws Exception {
        // Get driver
         final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList009: Verify user able to edit settings after clicked successmaker admin links for sub-district admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a72019a7f90ca06017f962de1830086" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            HolidaySchedulerEditPopupPage naviagteToEditHolidaySchedulerPage = settingpage.naviagteToEditHolidaySchedulerPage("Holiday Scheduler");
            Log.assertThat(naviagteToEditHolidaySchedulerPage.getHeaderText().contains(AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday Scheduler text is displaying", "Edit Holiday Scheduler text is displaying");
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user able to add holiday scheduler in settings after clicked successmaker admin links for district admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
       
        try {
            Log.testCaseInfo( "tcSettingList010: Verify user able to add holiday scheduler in settings after clicked successmaker admin links for district admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7200f77de565ac017e248148670654" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            HolidaySchedulerEditPopupPage naviagteToEditHolidaySchedulerPage = settingpage.naviagteToEditHolidaySchedulerPage("Holiday Scheduler");
            Log.assertThat(naviagteToEditHolidaySchedulerPage.getHeaderText().contains(AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday Scheduler text is displaying", "Edit Holiday Scheduler text is displaying");
         
            Date date = new Date();  
   		    Calendar c = Calendar.getInstance(); 
   		    c.setTime(date);
   		    Date startDate;
   		    startDate = c.getTime();
   		    c.add(Calendar.DATE, 3);
   		    Date endDate = c.getTime();
   		 
   		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");  
   		    String strDate= formatter.format(startDate); 
   		    String eDate= formatter.format(endDate); 
   		    Log.message(strDate);
   		    Log.message(eDate);
            naviagteToEditHolidaySchedulerPage.clickStartCalendarIcon();
            naviagteToEditHolidaySchedulerPage.clickStartDateFromCalender(strDate.toString());
            naviagteToEditHolidaySchedulerPage.clickEndCaledarIcon();
            naviagteToEditHolidaySchedulerPage.clickEndDateFromCalender(eDate.toString());
            naviagteToEditHolidaySchedulerPage.typeHolidayDescription("New holiday");
            naviagteToEditHolidaySchedulerPage.clickAddDates();
            naviagteToEditHolidaySchedulerPage.clickSaveButton();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify user able to edit MSDA  in settings after clicked successmaker admin links for district admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList011: Verify user able to edit MSDA  in settings after clicked successmaker admin links for district admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7200f77de565ac017e248148670654" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            
            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            MSDASettingsPopupPage MSDAPage = settingpage.clickEditButtn("Math Screener & Diagnostic Assessments (MSDA)");
            MSDAPage.verifyMSDAPopupHeaderAndDescription();
            Log.testCaseResult();
                   
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify user able to edit MSDA  in settings after clicked successmaker admin links for school admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList012() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList012: Verify user able to edit MSDA  in settings after clicked successmaker admin links for school admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7209887f513da0017f53a5e46d026c" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            MSDASettingsPopupPage MSDAPage = settingpage.clickEditButtn("Math Screener & Diagnostic Assessments (MSDA)");
            MSDAPage.verifyMSDAPopupHeaderAndDescription();
            Log.testCaseResult();
                   
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user able to edit MSDA  in settings after clicked successmaker admin links for subdistrict admin", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList013() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList013: Verify user able to edit MSDA  in settings after clicked successmaker admin links for subdistrict admin <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a72019a7f90ca06017f962de1830086" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            MSDASettingsPopupPage MSDAPage = settingpage.clickEditButtn("Math Screener & Diagnostic Assessments (MSDA)");
            MSDAPage.verifyMSDAPopupHeaderAndDescription();
            Log.testCaseResult();
                   
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify district admin can see the holidays which is added by savvas admin.", groups = { "SMK-65224", "Settings Tab", "SettingList" }, priority = 1 )
    public void tcSMAdmin_SettingList014() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSettingList014: Verify district admin can see the holidays which is added by savvas admin. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage sharedCoursePage = smLoginPage.loginToSM( "absavvasadmin", "password1","8a7200f77de565ac017e248148670654" );

            SettingsListPage settingpage = sharedCoursePage.navigateToSettingListPage();
            Log.assertThat( sharedCoursePage.isLeftNavSelected( SubNavigations.SETTINGS ), SubNavigations.SETTINGS + " is selected in left navigation as expected", SubNavigations.SETTINGS + " is not selected in left navigation" );
            Log.testCaseResult();
            

            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.MSDA ), "Math Screener & Diagnostic Assessments (MSDA) is displaying", "Math Screener & Diagnostic Assessments (MSDA) is not displaying" );
            Log.assertThat( settingpage.isQuestionIconDisplayed(), "Question icon is displaying on Setting list page", "Question icon is not displaying on Setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getSettingListOption().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday scheduler is displaying setting list page", "Holiday scheduler is not displaying setting list page" );
            Log.testCaseResult();

            Log.assertThat( settingpage.getEditButtn("Holiday Scheduler").equals( "Edit" ), "Edit Button is displaying for Holiday schedular",
                    "Edit Button is not displaying for Holiday schedular" );
            Log.testCaseResult();
            Log.assertThat( settingpage.getEditButtn( "Math Screener & Diagnostic Assessments (MSDA)" ).equals( "Edit" ), "Edit button is displaying for Math Screener & Diagnostic Assessments (MSDA)",
                    "Edit button is not displaying for Math Screener & Diagnostic Assessments (MSDA)" );
            Log.testCaseResult();
            
            HolidaySchedulerEditPopupPage naviagteToEditHolidaySchedulerPage = settingpage.naviagteToEditHolidaySchedulerPage("Holiday Scheduler");
            Log.assertThat(naviagteToEditHolidaySchedulerPage.getHeaderText().contains(AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday Scheduler text is displaying", "Edit Holiday Scheduler text is displaying");
            
            SMUtils.logDescriptionTC( "Verify district admin can see the holidays which is added by savvas admin." );
             Log.message(naviagteToEditHolidaySchedulerPage.getholidayDates().toString());
             Log.assertThat(naviagteToEditHolidaySchedulerPage.getholidayDates().contains( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NEW_DATE ), "Date is displaying", "Date is not displaying" );
             Log.message(naviagteToEditHolidaySchedulerPage.getHolidayNames().toString());
             Log.assertThat(naviagteToEditHolidaySchedulerPage.getHolidayNames().contains( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NEW_NAME ), "Name is displaying", "Name is not displaying" );
             Log.testCaseResult();
                           
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}