package com.savvas.sm.admin.ui.pages;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.CREATED_DELETED_DATE;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;

public class RestoreAssignmentsListPage extends LoadableComponent<RestoreAssignmentsListPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    @FindBy ( css = "h1.header" )
    WebElement headerLabel;

    @FindBy ( css = "span.d-inline-flex" )
    List<WebElement> restoreTableTittle;

    @FindBy ( css = "cel-icon.arrow-down " )
    WebElement defaultDescendingSorting;

    @FindBy ( css = "cel-icon.hydrated" )
    WebElement sorting;

    @FindBy ( css = "cel-icon.arrow-up" )
    WebElement ascendingSorting;

    @FindBy ( css = "cel-button.hydrated" )
    WebElement restoreButton;

    @FindBy ( css = "cel-paginator.pagination" )
    WebElement noOfDeletedAssignmentPage;

    @FindBy ( css = "cel-dropdown-menu-box.hydrated" )
    WebElement toggleButton;

    @FindBy ( css = "span.sc-cel-toast" )
    WebElement assignmentRestored;

    @FindBy ( css = "button.dialog-btn-close" )
    WebElement errorMessage;

    @FindBy ( css = "div.error-content span" )
    WebElement errorContent;

    // *********************Child elements****************************//
    public static String noOfDeletedSssignmentChild = "div span.page-items";
    public static String noOfDeletedAssignmentPageChild = "div span";
    public static String createdOnChild = "li[aria-label='Created On Date']";
    public static String deletedOnChild = "li[aria-label='Deleted On Date']";
    public static String deletedList = "//span[contains(text(),'%s')]/ancestor::td/preceding-sibling::td/child::span[contains(text(),'%s')]/ancestor::tr";
    public static String clickRestore = "//span[contains(text(),'%s')]/ancestor::td/preceding-sibling::td/child::span[contains(text(),'%s')]/ancestor::td/following-sibling::td/cel-button ";
    public static String secondaryButton = "button.secondary_button";

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public RestoreAssignmentsListPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, headerLabel );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, headerLabel, 10 ) ) {
            Log.message( "Restore Assignment List page loaded successfully." );
        } else {
            Log.fail( "Restore Assignment List page did not load." );
        }

    }

    /**
     * To get Restore assignment Table page header
     * 
     * @return
     */
    public String getRestoreAssignmentHeader() {
        Log.message( "Getting Recent Session Report Table Title" );
        SMUtils.waitForElement( driver, restoreButton );
        return headerLabel.getText().trim();
    }

    /**
     * To get restore assignment Table title
     * 
     * @return
     */
    public List<String> getRestoreAssignmentTableTitle() {
        Log.message( "Getting Recent Session Report Table Title" );
        SMUtils.waitForElement( driver, restoreButton );
        return restoreTableTittle.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
    }

    /***
     * This method helps the user to verify the restore assignment count in
     * Restore Assignment list Page
     * 
     * @return boolean
     */
    public boolean deletedCountDisplayed() {
        SMUtils.waitForElement( driver, noOfDeletedAssignmentPage );
        Log.message( "Verifying the deleted assignment count in Restore Assignment page" );
        return SMUtils.isElementPresent( SMUtils.getWebElement( driver, noOfDeletedAssignmentPage, noOfDeletedSssignmentChild ) );

    }

    /***
     * This method helps the user to verify the pagination in Restore Assignment
     * list Page
     * 
     * @return boolean
     */
    public boolean paginationDisplayed() {
        SMUtils.waitForElement( driver, noOfDeletedAssignmentPage );
        Log.message( "Verifying the pagenation in Restore Assignment page" );
        return SMUtils.getWebElement( driver, noOfDeletedAssignmentPage, noOfDeletedAssignmentPageChild ).isDisplayed();
    }

    /***
     * This method helps the user to verify the restore button in restore
     * assignment page
     * 
     * @return boolean
     */
    public boolean restoreButton() {
        SMUtils.waitForElement( driver, noOfDeletedAssignmentPage );
        Log.message( "Verifying the restore button in Restore Assignment page" );
        return restoreButton.isDisplayed();
    }

    /***
     * This method helps the user to verify the default sorting in restore
     * assignment page
     * 
     * @return boolean
     */
    public boolean defaultDeteletedOnColumnSorting() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the decending sorting!!" );
        return defaultDescendingSorting.isDisplayed();
    }

    /***
     * This method helps the user to verify the assignment column is sorting or
     * not in restore assignment page
     * 
     * @return boolean
     */

    public boolean sortingTheAssignmentColumn() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the ascending sorting!!" );
        SMUtils.clickJS( driver, restoreTableTittle.get( 0 ) );
        return ascendingSorting.isDisplayed();
    }

    /***
     * This method helps the user to verify the Deleted On column is sorting or
     * not in restore assignment page
     * 
     * @return boolean
     */

    public boolean sortingTheDeletedOnColumn() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the Organizations drop down is displayed in the Audit History Page" );
        SMUtils.clickJS( driver, restoreTableTittle.get( 4 ) );
        return ascendingSorting.isDisplayed();
    }

    /***
     * This method helps the user to verify the Teachername column is sorting or
     * not in restore assignment page
     * 
     * @return boolean
     */

    public boolean sortingTheTeacherNameColumn() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the Organizations drop down is displayed in the Audit History Page" );
        SMUtils.clickJS( driver, restoreTableTittle.get( 1 ) );
        return ascendingSorting.isDisplayed();
    }

    /***
     * This method helps the user to verify the Student Name column is sorting
     * or not in restore assignment page
     * 
     * @return boolean
     */

    public boolean sortingTheStudentNameColumn() {
        SMUtils.waitForElement( driver, restoreButton );
        SMUtils.clickJS( driver, restoreTableTittle.get( 2 ) );
        return ascendingSorting.isDisplayed();
    }

    /***
     * This method helps the user to verify the Student Username column is
     * sorting or not in restore assignment page
     * 
     * @return boolean
     */

    public boolean sortingTheStudentUsernameColumn() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the Organizations drop down is displayed in the Audit History Page" );
        SMUtils.clickJS( driver, restoreTableTittle.get( 3 ) );
        return ascendingSorting.isDisplayed();
    }

    /***
     * This method helps the user to verify the change the deleted on option in
     * restore assignment page
     * 
     * @return String
     */

    public String toggleToCreatedOnCloumn() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the Organizations drop down is displayed in the Audit History Page" );
        SMUtils.moveToElementSelenium( driver, toggleButton );
        WebElement allButtons = SMUtils.getWebElement( driver, toggleButton, createdOnChild );
        SMUtils.clickJS( driver, allButtons );
        SMUtils.moveToElementSelenium( driver, restoreButton );
        Log.message( restoreTableTittle.get( 4 ).getText().trim() );
        return restoreTableTittle.get( 4 ).getText().trim();
    }

    /***
     * This method helps the user to verify the restore the assignment in
     * restore assignment page
     */
    public void clickTheRestoreButton( String date, String studentUsername ) {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the assignment is restoring to teacher" );
        WebElement restoreElement = driver.findElement( By.xpath( String.format( clickRestore, date.toUpperCase(), studentUsername.toLowerCase() ) ) );
        SMUtils.waitForElement( driver, restoreElement );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, restoreElement, secondaryButton ) );
        Log.message( "Restore button is clicked" );

    }

    /***
     * This method helps the user to verify the change the created on option in
     * restore assignment page
     * 
     * @return String
     */

    public String toggleToDeletedOnCloumn() {
        SMUtils.waitForElement( driver, restoreButton );
        Log.message( "Verifying the Organizations drop down is displayed in the Audit History Page" );
        SMUtils.moveToElementSelenium( driver, toggleButton );
        WebElement allButtons = SMUtils.getWebElement( driver, toggleButton, deletedOnChild );
        SMUtils.clickJS( driver, allButtons );
        return restoreTableTittle.get( 4 ).getText().trim();
    }

    /***
     * This method helps to get the created date/deleted date for deleted
     * assignment
     * 
     * @return String
     */
    public String getCreatedAndDeletedDate( CREATED_DELETED_DATE createdOrDeletedDate, String assignmentUserId ) throws ParseException {
        List<Object[]> query = SQLUtil.executeQuery( "select " + createdOrDeletedDate + " from assignment_user where assignment_user_id = " + assignmentUserId );
        String dateFromDB = null;
        for ( Object[] list : query ) {
            dateFromDB = list[0].toString();
        }
        TimeZone timeZonePST = TimeZone.getTimeZone( "PST" );
        DateFormat df = new SimpleDateFormat( "yyyy-MM-dd HH:mm" );
        DateFormat outputformat = new SimpleDateFormat( "MM/dd/yyyy hh:mm aa " );
        outputformat.setTimeZone( timeZonePST );
        Date date = df.parse( dateFromDB.substring( 0, 16 ) );
        String formatDate = outputformat.format( date );
        return formatDate + timeZonePST.getID().trim();
    }

    public List<String> getDeletedDataList( String time, String studentUsername ) {
        SMUtils.waitForElement( driver, restoreButton );
        List<String> deletedAssignmentList = new ArrayList<>();
        try {
            List<WebElement> elements = driver.findElements( By.xpath( String.format( deletedList, time.toUpperCase(), studentUsername.toLowerCase() ) ) );
            deletedAssignmentList = elements.stream().map( element -> element.getText().trim().replace( "\n", " " ) ).collect( Collectors.toList() );

        } catch ( Exception e ) {
            Log.message( "The given assignment details are not displaying in restore assignment listing page." );
        }
        return deletedAssignmentList;
    }

    /***
     * This method helps the user to verify the error message popup in restore
     * assignment page
     * 
     * @return boolean
     */

    public void closeErrorMessagePopup() {
        SMUtils.waitForElement( driver, errorMessage );
        Log.message( "Error message popup box is displaying successfully" );
        SMUtils.click( driver, errorMessage );
        Log.message( "Error message popup is closed" );

    }

    /**
     * To get the restore assignment error Message
     */

    public String getErrorMessage() {
        SMUtils.waitForElement( driver, errorMessage );
        return errorContent.getText().trim();
    }

}
