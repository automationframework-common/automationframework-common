package com.savvas.sm.admin.apiIntegration.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.FixupFunction;

public class UsageGoalAdminDashBoardUIValidations extends EnvProperties {

    private String smUrl;
    private String browser;
    private static String sessionCookie;
    private String username;
    private String password;
    private HashMap<String, String> userDetails = new HashMap<String, String>();
    private String orgId;
    private String student1Details;
    private String student2Details;
    private String student3Details;

    Map<String, String> headers = new HashMap<>();
    private String teacherDetails;
    private String teacherId;
    private String readingSchool;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private List<String> courseIDs = new ArrayList<>();
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    String teacherAccessToken;
    String teacherUsername;
    String mathAssignmentId;
    String readingAssignmentId;
    private String flexSchool;
    private String mathSchool;
    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtId = null;
    private String districtAdminDetails = null;
    private String districtAdminToken = null;

    @BeforeClass ( alwaysRun = true )
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        
        districtId = configProperty.getProperty( "district_ID" );
        
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        //Creating Admin user data to login
        
        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        student1Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student2Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student3Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) );

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupNameRVC" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );

        Log.message( "Assigning assignment..." );

        HashMap<String, String> assignmentResponseMath = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );

        JSONObject mathAssignmentDetailsJson = new JSONObject( assignmentResponseMath.get( Constants.REPORT_BODY ) );

        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );

        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );

        mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();

        Log.message( "Assignment Details" + assignmentResponseMath );

        HashMap<String, String> assignmentResponseReading = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, Arrays.asList( "2" ) );

        Log.message( "Assignment Details" + assignmentResponseReading );

        JSONObject readAssignmentDetailsJson = new JSONObject( assignmentResponseReading.get( Constants.REPORT_BODY ) );

        JSONArray readAssignmentList = readAssignmentDetailsJson.getJSONArray( Constants.DATA );

        JSONObject readAssignmentInfo = new JSONObject( readAssignmentList.get( 0 ).toString() );

        readingAssignmentId = readAssignmentInfo.get( "assignmentId" ).toString();
        
        Log.message( "Assignment IDs - " + assignmentIds );

        executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );
        executeCourse( SMUtils.getKeyValueFromResponse( student2Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );

        FixupFunction.executeFixupFunctions( RBSDataSetup.organizationIDs.get( flexSchool ) );
        

        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "51" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
     
    }

    @Test ( description = "Verify Math Usage Goal", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal01( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );
         
            dashBoardPage.clickAllOptionsInOrganizationDropdown();

            //Select Mulit organization in organization dropdown     
            dashBoardPage.enterTextInSearchTextBox( flexSchool );
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            dashBoardPage.clickApplySelectionButton();

            Log.assertThat( dashBoardPage.toggleToUsageGoalsnew(), "Successfully Toggled to usage button", "Issue in toggle to usage button" );

            // Validate the Hint Message on the top right corner of the Organization usage section
            Log.assertThat( dashBoardPage.validateNoteText( AdminUIConstants.UsageGoal.HINT_MESSAGE ), "Hint Message is shown Successfully", "Correct Message Not Thrown" );

            // Validate % of students text for math usage goal
            Log.assertThat( dashBoardPage.validatePercentageTextForAllLegends( AdminUIConstants.UsageGoal.MATH ), "% of students text displayed below of all legends ", "Error in Text" );

            // Validate the Header Text of Progress Bar
            Log.assertThat( dashBoardPage.validateHeaderTextOfProgressBar( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.USAGE_GOAL_MATH_HEADER ), "Header Text For Math Progress Bar is Shown as expected", "Header Text is  not shown properly" );

            // Validate Organization Selected Text Bottom of the Page
            String noOfOrganizationSelectedText = dashBoardPage.getNoOfOrganizationSelectedText();
            Log.assertThat( noOfOrganizationSelectedText.contains( AdminUIConstants.UsageGoal.ORGANIZATION_SELECTED_TEXT ), "Organization Selected text is shown Successfully", "Correct Message Not Thrown" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK ), "OnTrack Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.WATCH_CLOSELY ), "Watch Closely Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.FALLING_BEHIND ), "Falling Behind Text Legend Validated Successfully", "Error in Text" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Reading Usage Goal", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal02( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );
            
            dashBoardPage.clickAllOptionsInOrganizationDropdown();

            //Select Mulit organization in organization dropdown     
            dashBoardPage.enterTextInSearchTextBox( flexSchool );
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            dashBoardPage.clickApplySelectionButton();

            dashBoardPage.toggleToUsageGoalsnew();

            // Validate the Header Text of Progress Bar
            Log.assertThat( dashBoardPage.validateHeaderTextOfProgressBar( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.USAGE_GOAL_MATH_HEADER ), "Header Text For Math Progress Bar is Shown as expected",
                    "Header Text is  not shown properly" );
            
            Log.assertThat( dashBoardPage.validateHeaderTextOfProgressBar( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.USAGE_GOAL_READING_HEADER ), "Header Text For Reading Progress Bar is Shown as expected",
                    "Header Text is  not shown properly" );

            // Validate % of students text for Reading usage goal
            Log.assertThat( dashBoardPage.validatePercentageTextForAllLegends( AdminUIConstants.UsageGoal.READING ), "% of students text displayed below of all legends ", "Error in Text" );

            // Validate Organization Selected Text Bottom of the Page
            String noOfOrganizationSelectedText = dashBoardPage.getNoOfOrganizationSelectedText();
            Log.assertThat( noOfOrganizationSelectedText.contains( AdminUIConstants.UsageGoal.ORGANIZATION_SELECTED_TEXT ), "Organization Selected text is shown Successfully", "Correct Message Not Thrown" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.ONTRACK ), "OnTrack Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.WATCH_CLOSELY ), "Watch Closely Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.FALLING_BEHIND ), "Falling Behind Text Legend Validated Successfully", "Error in Text" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Percentage of Progress Bar", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal03( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password);
            dashBoardPage.clickAllOptionsInOrganizationDropdown();

            //Select Mulit organization in organization dropdown     
            dashBoardPage.enterTextInSearchTextBox( flexSchool );
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            dashBoardPage.clickApplySelectionButton();


            dashBoardPage.toggleToUsageGoalsnew();

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.WATCH_CLOSELY ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.FALLING_BEHIND ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.ONTRACK ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.WATCH_CLOSELY ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.FALLING_BEHIND ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK, AdminUIConstants.UsageGoal.HEX_VALUE_ONTRACK ), "Colour is validated for given Legend",
                    "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.WATCH_CLOSELY, AdminUIConstants.UsageGoal.HEX_VALUE_WATCHCLOSELY ), "Colour is validated for given Legend",
                    "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.FALLING_BEHIND, AdminUIConstants.UsageGoal.HEX_VALUE_FALLINGBEHIND ), "Colour is validated for given Legend",
                    "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.ONTRACK, AdminUIConstants.UsageGoal.HEX_VALUE_ONTRACK ), "Colour is validated for given Legend",
                    "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.WATCH_CLOSELY, AdminUIConstants.UsageGoal.HEX_VALUE_WATCHCLOSELY ), "Colour is validated for given Legend",
                    "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.UsageGoal.READING, AdminUIConstants.UsageGoal.FALLING_BEHIND, AdminUIConstants.UsageGoal.HEX_VALUE_FALLINGBEHIND ), "Colour is validated for given Legend",
                    "Issue in colour of given legend" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

 // Running Fine Static Data Since Data Scattering Option not available Commenting this Test case
    @Test ( description = "Verify sum of all percentage is 100", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" }, enabled = false )
    public void tcUsageGoal04( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );
            
            dashBoardPage.clickAllOptionsInOrganizationDropdown();

            //Select Mulit organization in organization dropdown     
            dashBoardPage.enterTextInSearchTextBox( flexSchool);
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            dashBoardPage.clickApplySelectionButton();

            dashBoardPage.toggleToUsageGoalsnew();

            // Verify the total of % of student is equal to 100 for the Reading Usage Goals
            Log.assertThat( dashBoardPage.verifySumOfAllPercentageIsHundred( AdminUIConstants.UsageGoal.READING ), "SUM of all legend percentage for Reading sub is 100", "Issue in total sum in percentage" );

            // Verify the total of % of student is equal to 100 for the Math Usage Goals
            Log.assertThat( dashBoardPage.verifySumOfAllPercentageIsHundred( AdminUIConstants.UsageGoal.MATH ), "SUM of all legend percentage for Math sub is 100", "Issue in total sum in percentage" );

            // Verify the text colour of Usage Goals
            Log.assertThat( dashBoardPage.validateUsageGoalTextColour(), "Text Colour of usage goal is validated and shown as expected", "Colour not matched" );

            // Verify all the organization is selected matches with text
            Log.assertThat( dashBoardPage.VerifyAllOrganizationSelectedMatchWithText(), "Matched with the No of Organization selected", "Not matched" );

            // scroll to top of the page
            dashBoardPage.scrollIntoTopOfPage();

            // Verify the if no Organization is selected
            Log.assertThat( dashBoardPage.verifyNoOrganizationSelectedOnTheDropDown(), "No of Org selected shows as Zero when no org is selected", "Not shown as expected" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    // Running Fine Static Data Since Data Scattering Option not available Commenting this Testa case
    @Test ( description = "Verify data changed based on Organization selected", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" }, enabled = false )
    public void tcUsageGoal05( ITestContext context ) throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SMDashBoardPage usagePage = new SMDashBoardPage( driver );
            
            usagePage.clickAllOptionsInOrganizationDropdown();

            //Select Mulit organization in organization dropdown     
            usagePage.enterTextInSearchTextBox( flexSchool );
            usagePage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            usagePage.clickApplySelectionButton();
            
            // Toggle Usage goal
            usagePage.toggleToUsageGoalsnew();

            // Percentage Details Before changing changes in Oraganization selected
            int percentageDetails = usagePage.getPercentageDetails( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK );

            //Select single organization in organization dropdown     
            dashBoardPage.selectGivenOrgFromDropDown( Arrays.asList( flexSchool ) );
            dashBoardPage.clickApplySelectionButton();

            // Percentage Details After changing changes in Oraganization selected
            int percentageDetails2 = usagePage.getPercentageDetails( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK );

            // Verify the total of % of student is equal to 100 for the Reading Usage Goals
            Log.assertThat( percentageDetails != percentageDetails2, "Changes in data according to the organization selected", "Data not updated after changing organization selected" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "95", "2", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "5" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Reading Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "95", "1", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "5" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

}
