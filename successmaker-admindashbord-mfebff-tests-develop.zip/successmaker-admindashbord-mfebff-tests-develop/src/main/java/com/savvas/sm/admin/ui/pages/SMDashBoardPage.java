package com.savvas.sm.admin.ui.pages;

import java.text.DecimalFormat;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.Dashboard;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SubNavigations;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;

import io.restassured.response.Response;

public class SMDashBoardPage extends LoadableComponent<SMDashBoardPage> {

    private final WebDriver driver;
    boolean isPageLoaded;
    public int percentage;
    public boolean status = false;
    public int totalValue = 0;

    // ********* SuccessMaker Launcher/Login Page Elements ***************
    @FindBy ( className = "logo-image" )
    WebElement smLogo;

    @FindBy ( css = "ul.side-nav span.side-nav-item" )
    List<WebElement> subNavigations;

    @FindBy ( css = "div.spinner-container" )
    WebElement dashBoardSpinner;

    @FindBy ( css = "ng-cel-select.org-single-select" )
    WebElement orgListingDropDown;

    @FindBy ( css = "li.side-nav-wrapper-active" )
    WebElement selectedSideNavBar;

    @FindBy ( css = "ul.side-nav" )
    WebElement sideNav;

    @FindBy ( css = "span.side-nav-item" )
    List<WebElement> settingSubNav;

    @FindBy ( css = "ul.side-nav li span" )
    List<WebElement> subNavList;

    @FindBy ( css = "cel-button.apply-btn" )
    WebElement btnApplySelectionRoot;

    @FindBy ( css = "div.card-header" )
    List<WebElement> dashboardCardHeaders;

    @FindBy ( css = "side-nav-wrapper-inactive" )
    List<WebElement> subNavbar;

    // ******** Performance Report ********

    @FindBy ( css = "div h3.header" )
    WebElement zeroStateMessageHeader;

    @FindBy ( css = "div span.message" )
    WebElement zeroStateMessageDescription;

    @FindBy ( css = "div.card-header" )
    List<WebElement> lblWidgetHeader;

    @FindBy ( css = "performance-report div.font-weight-bold" )
    WebElement lblCurrentlevelAndGain;

    @FindBy ( css = "performance-report div.title" )
    List<WebElement> lblTitle;

    @FindBy ( css = "performance-report button.dropdown-select-trigger" )
    WebElement subjectDropdown;

    @FindBy ( css = "performance-report div.dropdown-select-options-wrapper ul li a" )
    List<WebElement> subjectDropdownOptions;

    @FindBy ( css = "performance-report highcharts-chart g.highcharts-xaxis-labels text" )
    List<WebElement> xAxisIntervals;

    @FindBy ( css = "performance-report highcharts-chart g.highcharts-yaxis-labels text" )
    List<WebElement> yAxisIntervals;

    @FindBy ( css = "performance-report highcharts-chart g.highcharts-xaxis text" )
    WebElement xAxisLabel;

    @FindBy ( css = "performance-report highcharts-chart g.highcharts-yaxis text" )
    WebElement yAxisLabel;

    @FindBy ( css = "performance-report .selected-count" )
    WebElement organzationSelectedCountInPerformanceWidget;

    // for color verification
    @FindBy ( css = "performance-report g.highcharts-series g rect" )
    List<WebElement> performanceChartBarsForColor;

    @FindBy ( css = "performance-report g.highcharts-series g" )
    List<WebElement> performanceChartBars;

    @FindBy ( css = "div.highcharts-tooltip-container table tbody tr" )
    List<WebElement> noDataToDisplay;
    
    @FindBy ( css = "text.highcharts-plot-band-label" )
    List<WebElement> PerformanceChartTooltip;

    // Student usage and usage goals Toggle Button Root Element
    @FindBy ( css = "div cel-toggle-button" )
    WebElement toggleBtnRoot;

    @FindBy ( css = "div.selected-count" )
    WebElement buttonwait;

    // Header Text "Math Usage Goal"
    @FindBy ( css = "div.sub-section:first-child div.usage-title" )
    WebElement mathUsageHeaderText;
    
    //Header Text
    @FindBy (css = "div:nth-of-type(n) > .usage-title")
    WebElement usageHeaderText;
    
    // Header Text "Reading Usage Goal"
    @FindBy ( css = "div.sub-section:last-child div.usage-title" )
    WebElement readingUsageHeaderText;

    // Math MultiProgressBar Root
    @FindBy ( css = "div.sub-section:first-child cel-multi-part-progress-bar.hydrated" )
    WebElement mathMultiProgressBarRoot;

    // Reading MultiProgressBar Root
    @FindBy ( css = "div.sub-section:last-child cel-multi-part-progress-bar.hydrated" )
    WebElement readingMultiProgressBarRoot;

    // Math Bar all Legends text
    @FindBy ( css = "div.sub-section:first-child div.legend-container div.legend div.legend-text" )
    List<WebElement> mathBarAllLegendsText;

    // Reading Bar all Legends text
    @FindBy ( css = "div.sub-section:first-child div.legend-container div.legend div.legend-text" )
    List<WebElement> readingBarAllLegendsText;
    
    //all Legends Text
    @FindBy (css = "div:nth-of-type(n) > .legend-text")
    List<WebElement> allLegendsText;

    // Math Bar all Legends percentage
    @FindBy ( css = "div.sub-section:first-child div.legend-container div.legend div.legend-value" )
    List<WebElement> mathBarAllLegendsPercentage;
    
    //all Legends percentage
    @FindBy (css = "div.legend-value")
    List<WebElement> allLegendsPercentage;

    // Reading Bar all Legends percentage
    @FindBy ( css = "div.sub-section:last-child div.legend-container div.legend div.legend-value" )
    List<WebElement> readingBarAllLegendsPercentage;

    // Math Bar all Legends colours
    @FindBy ( css = "div.sub-section:first-child div.legend-container div.legend div.legend-block" )
    List<WebElement> mathBarAllLegendsColours;

    // Reading Bar all Legends colours
    @FindBy ( css = "div.sub-section:last-child div.legend-container div.legend div.legend-block" )
    List<WebElement> readingBarAllLegendsColours;

    // No of Organization selected Element
    @FindBy ( css = "div.organizations-selected" )
    WebElement noOfOrganizationSelected;

    // note on the side of the page
    @FindBy ( css = "div.usage-goals-note" )
    WebElement noteTextOnOrgUsage;

    // select Orginization dropdown options CheckBox root
    @FindBy ( css = "cel-multi-check-dropdown.org-multi-select" )
    WebElement orginizationSelectDropDownRoot;

    // ******** Student Usage ********

    @FindBy ( css = "cel-toggle-button.toggle-button" )
    WebElement studentUsageBtnRoot;

    @FindBy ( css = "div.student-averages-title" )
    WebElement studentUsageHeader;

    @FindBy ( css = "g.highcharts-legend-item" )
    List<WebElement> studentUsageLegends;

    @FindBy ( css = "g.highcharts-legend-item rect" )
    List<WebElement> studentUsageLegendColors;

    @FindBy ( css = "span.week" )
    List<WebElement> weekHeaders;

    @FindBy ( css = ".student-usage highcharts-chart.highcharts" )
    WebElement studentUsageChart;

    @FindBy ( css = ".student-usage g.highcharts-axis .highcharts-axis-title" )
    List<WebElement> xAndYAxisTitle;

    @FindBy ( css = ".student-usage .highcharts-axis-labels" )
    List<WebElement> weeksAndHoursLbl;

    @FindBy ( css = ".student-usage .highcharts-xaxis-labels text" )
    List<WebElement> weeks;

    @FindBy ( css = ".student-usage rect.highcharts-color-0" )
    List<WebElement> mathHours;

    @FindBy ( css = ".student-usage rect.highcharts-color-1" )
    List<WebElement> readingHours;

    @FindBy ( css = ".student-usage div.highcharts-tooltip" )
    WebElement studentUsageTooltip;

    @FindBy ( css = "div.current-week span.hours" )
    WebElement currentWeekUsage;

    @FindBy ( css = "div.last-week span.hours" )
    WebElement lastWeekUsage;

    @FindBy ( css = "div.school-year span.hours" )
    WebElement schoolYearUsage;

    @FindBy ( css = "div.student-usage div" )
    WebElement studentUsageZeroStateMessage;

    @FindBy ( css = "div.error-message-1" )
    WebElement zeroStateHeader;

    @FindBy ( css = "div.error-message-2" )
    WebElement zeroStateDesc;

    @FindBy ( css = "div.student-usage g.highcharts-yaxis-labels text" )
    List<WebElement> studentUsageYAxisIntervals;

    //**Organization performance this week header****
    @FindBy ( css = "organization-mastery table th  span.d-inline-flex span:nth-child(1)" )
    List<WebElement> organizationPerformanceThisWeekHeaders;

    @FindBy ( css = "organizations-selection button.dropdown-select-trigger" )
    WebElement organizationDropdown;

    @FindBy ( css = "organizations-selection div.dropdown-select-options-wrapper ul>li>a .dropdown-option-label" )
    List<WebElement> organizationDropdownValues;
    
    @FindBy ( css = "ng-cel-select.org-single-select span span" )
    WebElement orgNameInDropDownTextBox;
    
    @FindBy (css = "cel-button.selection-btn")
    WebElement btnApplySelectionRootNew;

    // ****Child Elements****
    private String txtBoxOrganizationSearch = "input.dropdown-search";
    private String selectAllRoot = "div.dropdown-all-select cel-checkbox";
    private String orgListRoot = "div ul.dropdown-select-options li span";
    private String lblorgName = "div.checkbox";
    private String allOrgRoot = "label.checkbox-label";
    private String checkBox = "input[type='checkbox']";
    private String expandCollapseOrganizationDropdown = "cel-icon.toggle-icon";
    private String selectedOrganizationCount = "span.head-label";
    private String cancelIconForSearchOrganizations = "cel-icon.search-close-icon";
    private String lblNoOrganizationFound = "div.dropdown-scroll li.dropdown-item";
    private String btnPrimary = "button.primary_button";
    private static String usageGoalChildElement = "div.toggle-button button+button";
    private static String studentUsageChildElement = "div.toggle-button button";
    private static String organizationDropDownChild = "div.multi-check-dropdown-container button";
    private static String applyButtonChild = "button.primary_button";
    private static String selectedToggleBtn = "button[aria-pressed=true]";
    private static String currentCourseAvrgValue = "g.highcharts-data-label-color-%s tspan.highcharts-text-outline";
    private static String button = "button";
    private static String selectlistorg = "cel-checkbox";
    private static String orgElement = "button.dropdown-head";
    private static String selectlistorgnew = "div.dropdown-scroll ul.dropdown-list-items cel-checkbox";
    

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public SMDashBoardPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, sideNav, 15 );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 40 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }

        if ( SMUtils.waitForElement( driver, buttonwait, 30 ) || ( SMUtils.waitForElement( driver, zeroStateMessageHeader, 30 ) ) ) {
            Log.message( "SM Admin dashboard Page loaded successfully." );
        } else {
            Log.fail( "SM Admin dashboard Page did not load." );
        }

    }

    /**
     * To verify the organization dropdown is displayed or not
     */
    public boolean isOrganizationDropdownDisplayed() {
        try {
            SMUtils.waitForElement( driver, sideNav );
            return SMUtils.isElementPresent( orginizationSelectDropDownRoot );
        } catch ( NoSuchElementException e ) {
            return false;
        }
    }

    /**
     * To expand organization dropdown
     */
    public void expandOrganizationDropdown() {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot, 20 );
        WebElement expandIcon = SMUtils.getWebElement( driver, orginizationSelectDropDownRoot, orgElement );
        if ( !Boolean.parseBoolean( expandIcon.getAttribute( Dashboard.ARIA_EXPANDED ) ) ) {
            SMUtils.click( driver, expandIcon );
            if ( Boolean.parseBoolean( expandIcon.getAttribute( Dashboard.ARIA_EXPANDED ) ) ) {
                Log.message( "Expanded - organization dropdown!" );
            } else {
                Log.message( "Some issue occured while expanding the organization dropdown!" );
            }

        }
    }
    
    public boolean isOrgDrodownExpanded() {
        return Boolean.parseBoolean( SMUtils.getWebElement( driver, orginizationSelectDropDownRoot, orgElement ).getAttribute( Dashboard.ARIA_EXPANDED ) );
    }

    /**
     * To collapse organization dropdown
     */
    public void collapseOrganizationDropdown() {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        WebElement collapseIcon = SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, orgElement );
        if ( Boolean.parseBoolean( collapseIcon.getAttribute( Dashboard.ARIA_EXPANDED ) ) ) {
            SMUtils.clickJS( driver, collapseIcon );
            Log.message( "collapsed - organization dropdown!" );
        }
    }

    /**
     * To click all options in organization dropdown
     */
    public void clickAllOptionsInOrganizationDropdown() {
        expandOrganizationDropdown();
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, selectAllRoot, checkBox ) );
        Log.message( "Clicked - All options in organization dropdown" );
    }

    /**
     * To get Select All label
     * 
     * @return
     */
    public String getSelectAllLabel() {
        expandOrganizationDropdown();
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, selectAllRoot, lblorgName ), driver );
    }

    /**
     * To get all organizations name from dropdown
     * 
     * @return
     */
    public List<String> getAllOrganizationsFromOrgDropdown() {
        expandOrganizationDropdown();
        SMUtils.waitForElement( driver, orgListingDropDown );
        return SMUtils.getAllTextFromWebElementList( SMUtils.getWebElementsDirect( driver, orgListingDropDown, orgListRoot ).stream().map( element -> SMUtils.getWebElement( driver, element, lblorgName ) ).collect( Collectors.toList() ) );
    }
    /**
     * To get all organizations name from Multi-org dropdown
     * 
     * @return
     */
    public List<String> getAllOrgFromDropdown(){
    	SMUtils.waitForElement(driver, orginizationSelectDropDownRoot);
    	Log.message( "Getting organization name list from org dropdown" );
    	 return SMUtils.getAllTextFromWebElementList( SMUtils.getWebElementsDirect( driver, orginizationSelectDropDownRoot, selectlistorgnew ).stream().map( element -> SMUtils.getWebElement( driver, element, allOrgRoot ) ).collect( Collectors.toList() ) );
    }
    
    /**
     * To select organizations in organization dropdown
     * 
     */
    public void selectOrganizationsFromOrgDropdown( List<String> organizations ) {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        SMUtils.getAllWebElements( driver, orginizationSelectDropDownRoot, selectlistorgnew ).stream().map( element -> SMUtils.getWebElement( driver, element, lblorgName ) ).forEach( element -> {
            if ( organizations.contains( element.getText().trim() ) ) {
                SMUtils.clickJS( driver, element.findElement( By.cssSelector( checkBox ) ) );
            }
        } );
        Log.message( "Selected given organizations!" );
    }

    /**
     * To select organization from single select organization dropdown
     * 
     */
    public void selectOrganizationsFromSingleSelectOrgDropdown( String organization ) {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        SMUtils.getChildWebElementsFromParent( orginizationSelectDropDownRoot, selectlistorgnew ).stream().filter( element -> element.getText().trim().equals( organization ) ).findFirst().ifPresent( element -> {
            Log.message( "entered..." );
            SMUtils.clickJS( driver, element );
        } );
        Log.message( "Selected given organization! - " + organization );
    }
    /**
     * To get selected organizations from organization dropdown
     * 
     * @return
     */
    public List<String> getselectedOrganizationsFromOrgDropdown() {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        return SMUtils.getAllTextFromWebElementList( SMUtils.getWebElementsDirect( driver, orginizationSelectDropDownRoot, selectlistorgnew ).stream().filter( element -> SMUtils.getWebElementDirect( driver, element, checkBox ).isSelected() ).map(
                element -> SMUtils.getWebElement( driver, element, lblorgName ) ).collect( Collectors.toList() ) );
    }

    /**
     * To get selected count of organizations or selected organization name(if
     * one organization is selected)
     * 
     * @return
     */
    public String getSelectedOrganizationCount() {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, selectedOrganizationCount ), driver );
    }

    /**
     * To get place holder for search organization text box
     * 
     * @return
     */
    public String getPlaceHolderForSearchTextBox() {
        return SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, txtBoxOrganizationSearch ).getAttribute( "placeholder" );
    }

    /**
     * To enter text in search organization text box.
     * 
     */
    public void enterTextInSearchTextBox( String searchText ) {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        SMUtils.enterValue( SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, txtBoxOrganizationSearch ), searchText );
    }

    /**
     * To get entered text in search organization text box.
     * 
     * @return
     */
    public String getEnteredTextInSearchTextBox() {
        expandOrganizationDropdown();
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        return SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, txtBoxOrganizationSearch ).getAttribute( "value" );
    }

    /**
     * To click cancel icon in Search text box
     */
    public void clickCancelIconInSearchTextBox() {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, cancelIconForSearchOrganizations ) );
        Log.message( "Clicked cancel icon in organization search text box." );
    }

    /**
     * To get no organization found error message.
     * 
     * @return
     */
    public String getNoOrganizationFoundMessage() {
        SMUtils.waitForElement( driver, orginizationSelectDropDownRoot );
        return SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, orginizationSelectDropDownRoot, lblNoOrganizationFound ), driver );
    }

    /**
     * To check the Apply selection(s) button is enabled or not
     * 
     * @return
     */
    public boolean isApplySelectionButtonEnabled() {
        SMUtils.waitForElement( driver, btnApplySelectionRootNew );
        return btnApplySelectionRootNew.isEnabled();
    }

    /**
     * To click the Apply selection(s) button
     */
    public void clickApplySelectionButton() {
        SMUtils.waitForElement( driver, btnApplySelectionRootNew );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnApplySelectionRootNew, btnPrimary ) );
        Log.message( "Clicked - Apply selection(s) button!" );

    }

    /**
     * To verify side navigation bar is displayed or not
     * 
     * @return
     */
    public boolean isSideNavBarDisplayed() {
        SMUtils.waitForElement( driver, sideNav );
        Log.message( "Verifying side navigation bar is displaying or not" );
        return SMUtils.isElementPresent( sideNav );
    }

    /**
     * To select left navigation
     * 
     * @param navigation
     */
    public void navigateTo( AdminUIConstants.SubNavigations navigation ) {
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
            wait.until( ExpectedConditions.visibilityOf( sideNav ) );
            SMUtils.waitForElement( driver, subNavigations.get( navigation.ordinal() ) );
            SMUtils.click( driver, subNavigations.get( navigation.ordinal() ) );
            Log.message( "The Sub Navigation " + subNavigations.get( navigation.ordinal() ).getText() + " is clicked" );

        } catch ( Exception e ) {
            Log.message( "The Sub Navigation is not clicked" );
        }
    }

    /**
     * To verify whether left navigation bar is selected or not
     * 
     * @param leftNavName
     * @return
     */
    public boolean isLeftNavSelected( SubNavigations leftNavName ) {
        try {
            SMUtils.waitForElement( driver, selectedSideNavBar );
            selectedSideNavBar.getText().trim().equals( leftNavName );
            Log.message( leftNavName + " is selected in left navigation" );
            return true;

        } catch ( Exception e ) {
            Log.message( "The Sub Navigation is not clicked" );
            return false;
        }
    }

    /**
     * To verify the color of selected side navigation bar
     * 
     * @param desiredColor
     * @return
     * @throws Exception
     */
    public boolean verifySelectedSideNavBarColor( String desiredColor ) throws Exception {
        SMUtils.waitForElement( driver, selectedSideNavBar );
        return SMUtils.checkBackgroundColor( selectedSideNavBar, desiredColor );
    }

    /**
     * Navigate to Shared Courses List Page
     * 
     * @return
     */
    public SharedCoursesListViewPage navigateToSharedCoursesListPage() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
        wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        subNavList.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( AdminUIConstants.SharedCourses.HEADER ) ) {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
                Log.message( "Shared Course is Clicked successfull" );
            }

        } );
        return new SharedCoursesListViewPage( driver ).get();

    }

    /**
     * To Click Student Usage Toggle Button
     * 
     * @return
     * 
     */
    public boolean toggleToStudentUsage() {
        try {
            WebElement usageGoals = SMUtils.getWebElement( driver, toggleBtnRoot, studentUsageChildElement );
            SMUtils.scrollWebElementToView( driver, usageGoals );
            SMUtils.clickJS( driver, usageGoals );
            SMUtils.waitForElement( driver, mathUsageHeaderText );
            Log.message( "Toggled usage goals." );
            return mathUsageHeaderText.isDisplayed();
        } catch ( NoSuchElementException e ) {
            return false;
        }
    }

    /**
     * To Click Usage goal Toggle Button
     * 
     * @throws InterruptedException
     * 
     */
    public boolean toggleToUsageGoals() throws InterruptedException {
        try {
            WebElement usageGoals = SMUtils.getWebElement( driver, toggleBtnRoot, usageGoalChildElement );
            SMUtils.scrollWebElementToView( driver, usageGoals );
            SMUtils.clickJS( driver, usageGoals );
            SMUtils.waitForElement( driver, mathUsageHeaderText );
            Log.message( "Toggled usage goals." );
            SMUtils.waitForSpinnertoDisapper( driver );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 60 ) );
            wait.until( ExpectedConditions.visibilityOf( mathUsageHeaderText ) );
            return mathUsageHeaderText.isDisplayed();
        } catch ( NoSuchElementException e ) {
            return false;
        }
    }
    
    public boolean toggleToUsageGoalsnew() throws InterruptedException {
            WebElement usageGoals = SMUtils.getWebElement( driver, toggleBtnRoot, usageGoalChildElement );
            SMUtils.scrollWebElementToView( driver, usageGoals );
            if ( !Boolean.parseBoolean( usageGoals.getAttribute( Dashboard.ARIA_PRESSED ) ) ) {
                SMUtils.click( driver, usageGoals );
                if ( Boolean.parseBoolean( usageGoals.getAttribute( Dashboard.ARIA_PRESSED ) ) ) {
                    Log.message( "Toggled usage goals" );
                    SMUtils.waitForSpinnertoDisapper( driver );
                } else {
                    Log.message( "Some issue in toggling usage goals!" );
                }
            }
			return usageGoals.isEnabled();
    }

    /**
     * To Validate % of Students text below all legends
     * 
     * @param To Pass Math or Reading as Sub
     * @return
     */

    public boolean validatePercentageTextForAllLegends( String subject ) {
        if ( subject.equals( Constants.MATH ) ) {
        	mathBarAllLegendsPercentage.stream().forEach( eachtext -> {
                if ( eachtext.getText().trim().contains( Constants.UsageGoal.PERCENTAGE_TEXT_LEGENDS ) ) {
                    status = true;
                }
            } );
            Log.message( "Percentage Text for all legends validated successfully" );
        } else {
        	readingBarAllLegendsPercentage.stream().forEach( eachtext -> {
                if ( eachtext.getText().trim().contains( Constants.UsageGoal.PERCENTAGE_TEXT_LEGENDS ) ) {
                    status = true;
                }
            } );
            Log.message( "Percentage Text for all legends validated successfully" );
        }
        return status;
    }

    /**
     * To Scroll to top page from bottom
     * 
     */
    public void scrollIntoTopOfPage() {
        SMUtils.scrollWebElementToView( driver, orgListingDropDown );
    }

    /**
     * Navigate to Setting List Page
     * 
     * @return
     */
    public SettingsListPage navigateToSettingListPage() {
        SMUtils.nap( 3 );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
        wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        subNavList.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( AdminUIConstants.SettingPage.HEADER ) ) {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
                Log.message( "Setting page is Clicked successfull" );
            }

        } );
        return new SettingsListPage( driver ).get();
    }

    /**
     * Navigate to Setting List Page
     * 
     * @return
     */
    public RestoreAssignmentsListPage navigateToRestoreAssignmentsListPage( String orgId ) {
        try {
            driver.get( String.format( AdminUIConstants.RESTORE_ASSIGNMENT_MFEURL, orgId ) );
            Log.message( "MFE Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE url not loaded" );
        }
        return new RestoreAssignmentsListPage( driver ).get();
    }

    /**
     * To get the widget headers
     * 
     * @return
     */
    public List<String> getWidgetHeaders() {
        SMUtils.waitForElement( driver, lblCurrentlevelAndGain );
        Log.message( "Getting all the widget Headers in Admin dashboard page!" );
        return SMUtils.getAllTextFromWebElementList( lblWidgetHeader );
    }

    /**
     * To get the Current level and Gain Header
     * 
     * @return
     */
    public String getCurrentLevelAndGainHeader() {
        SMUtils.waitForElement( driver, lblCurrentlevelAndGain );
        Log.message( "Getting header in performance widget!" );
        return SMUtils.getTextOfWebElement( lblCurrentlevelAndGain, driver );
    }

    /**
     * To get the Gain Headers(Smallest and Largest Gain)
     * 
     * @return
     */
    public List<String> getGainHeaders() {
        SMUtils.waitForElement( driver, lblCurrentlevelAndGain );
        Log.message( "Getting gain lables in performance widget!" );
        return SMUtils.getAllTextFromWebElementList( lblTitle );
    }

    /**
     * To expand subject dropdown in Performance report widget
     * 
     */
    public void expandSubjectDropdown() {
        SMUtils.waitForElement( driver, subjectDropdown );
        SMUtils.clickJS( driver, subjectDropdown );
        Log.message( "Expanded - subject dropdown in performance widget" );
    }

    /**
     * To get the options presents in subject dropdown
     * 
     * @return
     */
    public List<String> getOptionsInSubjectDropdown() {
        SMUtils.waitForElement( driver, subjectDropdown );
        Log.message( "Getting Subjects presented in Subject dopdown!" );
        return SMUtils.getAllTextFromWebElementList( subjectDropdownOptions );
    }

    /**
     * To Select the option in subject dropdown
     * 
     */
    public void selectOptionInSubjectDropdown( String option ) {
        SMUtils.waitForElement( driver, subjectDropdown );
        subjectDropdownOptions.stream().filter( element -> SMUtils.getTextOfWebElement( element, driver ).equalsIgnoreCase( option ) ).findFirst().ifPresent( element -> {
            SMUtils.clickJS( driver, element );
            Log.message( "Selected the subject - " + option );
        } );
    }

    /**
     * To get selected subject in Performance report
     */
    public String getSelectedSubjectInPerformanceReport() {
        SMUtils.waitForElement( driver, subjectDropdown );
        Log.message( "Getting selected subject in Performance report!" );
        return SMUtils.getTextOfWebElement( subjectDropdown, driver );
    }

    /**
     * To get the x axis label in Performance report widget
     * 
     * @return
     */
    public String getXAxisLabel() {
        SMUtils.waitForElement( driver, xAxisLabel );
        Log.message( "Getting X-axis label in Performance Report widget!" );
        return SMUtils.getTextOfWebElement( xAxisLabel, driver );
    }

    /**
     * To get the y axis label in Performance report widget
     * 
     * @return
     */
    public String getYAxisLabel() {
        SMUtils.waitForElement( driver, yAxisLabel );
        Log.message( "Getting Y-axis label in Performance Report widget!" );
        return SMUtils.getTextOfWebElement( yAxisLabel, driver );
    }

    /**
     * To get the X axis intervals in Performance report widget
     * 
     * @return
     */
    public List<String> getXAxisIntervals() {
        SMUtils.waitForElement( driver, xAxisLabel );
        Log.message( "Getting Y-axis intervals in Performance Report widget!" );
        return SMUtils.getAllTextFromWebElementList( xAxisIntervals );
    }

    /**
     * To get the Y axis intervals in Performance report widget
     * 
     * @return
     */
    public List<String> getYAxisIntervals() {
        SMUtils.waitForElement( driver, yAxisLabel );
        Log.message( "Getting Y-axis intervals in Performance Report widget!" );
        return SMUtils.getAllTextFromWebElementList( yAxisIntervals );
    }

    /**
     * To get the selected organization count in performance widget
     * 
     * @return
     */
    public String getSelectedOrganizationCountInPerformanceWidget() {
        SMUtils.waitForElement( driver, organzationSelectedCountInPerformanceWidget );
        Log.message( "Getting selected organization count in Performance Report widget!" );
        return SMUtils.getTextOfWebElement( organzationSelectedCountInPerformanceWidget, driver );
    }

    /**
     * To verify the subject dropdown in Performance report widget is displayed
     *
     */
    public boolean isSubjectDropdownPresent() {
        SMUtils.waitForElement( driver, subjectDropdown );
        Log.message( "Verifying the Subject dropdown!" );
        return subjectDropdown.isDisplayed();
    }

    /**
     * To get colors for all grade bars
     * 
     * @return
     */
    public List<String> getColorsForPerformanceChartBars() throws Exception {
        SMUtils.waitForElement( driver, xAxisLabel );
        Log.message( "Getting the colors od Bar chart!" );
        return performanceChartBarsForColor.stream().map( element -> SMUtils.getAttributeOfWebElement( element, driver, "fill" ) ).collect( Collectors.toList() );
    }

    /**
     * To verify tooltip content for all grade bars
     * 
     * @return
     */
    public boolean verifyTooltipContentForDisplayedBars() {
        SMUtils.waitForElement( driver, xAxisLabel );
        return performanceChartBars.stream().filter( SMUtils::isElementPresent ).map( element -> {
            SMUtils.click( driver, element );
            return SMUtils.getAllTextFromWebElementList( PerformanceChartTooltip );
        } ).allMatch( toolTipContents -> toolTipContents.get( 0 ).contains( Dashboard.GRADE ) && toolTipContents.get( 1 ).contains( Dashboard.INITIAL_PLACEMENT ) && toolTipContents.get( 2 ).contains( Dashboard.CURRENT_LEVEL )
                && toolTipContents.get( 3 ).contains( Dashboard.TOTAL_GAIN ) );
    }

    /**
     * To verify card header is present in admin dashboard
     * 
     * @param cardHeaderName
     * @return
     */
    public boolean verifyCardHeaderIsPresent( String cardHeaderName ) {
        SMUtils.waitForElement( driver, studentUsageBtnRoot );
        Log.message( "Verifying card header is present in dashboard page" );
        return dashboardCardHeaders.stream().map( header -> header.getText().trim() ).collect( Collectors.toList() ).contains( cardHeaderName );
    }

    /**
     * To verify Student Usage button is seected or not
     * 
     * @return
     */
    public boolean verifyStudentUsageBtnIsSelected() {
        SMUtils.waitForElement( driver, studentUsageBtnRoot );
        Log.message( "Verifying Student Usage button is selected or not" );
        return SMUtils.getWebElementDirect( driver, studentUsageBtnRoot, selectedToggleBtn ).getText().trim().equals( Dashboard.STUDENT_USAGE );
    }

    /**
     * To get student usage header
     * 
     * @return
     */
    public String getStudentUsageHeader() {
        SMUtils.waitForElement( driver, studentUsageHeader );
        Log.message( "Getting Student Usage header" );
        return studentUsageHeader.getText().trim();
    }

    /**
     * To get student usage legends
     * 
     * @return
     */
    public List<String> getStudentUsageLegends() {
        SMUtils.waitForElement( driver, studentUsageHeader );
        Log.message( "Getting Student Usage legends" );
        return studentUsageLegends.stream().map( legend -> legend.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To get student usage average weeks
     * 
     * @return
     */
    public List<String> getStudentAverageWeeks() {
        SMUtils.waitForElement( driver, studentUsageHeader );
        Log.message( "Getting week headers" );
        return weekHeaders.stream().map( legend -> legend.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify student usage chart is present or not
     * 
     * @return
     */
    public boolean isStudentChartPresent() {
        SMUtils.waitForElement( driver, studentUsageChart );
        Log.message( "Verifying Student Chart is displaying or not" );
        return studentUsageChart.isDisplayed();
    }

    /**
     * To get weeks and hours from student usage chart
     * 
     * @return
     */
    public List<String> getWeeksAndHoursHeader() {
        SMUtils.waitForElement( driver, studentUsageChart );
        Log.message( "Getting week and hours headers" );
        return xAndYAxisTitle.stream().map( header -> header.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify weeks and hours are present in student usage chart
     * 
     * @return
     */
    public boolean isWeeksAndHoursLblPresent() {
        SMUtils.waitForElement( driver, studentUsageChart );
        Log.message( "Verifying week and hour labels are displaying or not" );
        return weeksAndHoursLbl.stream().allMatch( WebElement::isDisplayed );
    }

    /**
     * To verify tooltip is present in student usage chart
     * 
     * @return
     */
    public boolean isStudentUsageTooltipDiaplayed() {
        SMUtils.waitForElement( driver, studentUsageChart );
        Log.message( "Verifying student usage tooltip is displaying or not" );
        IntStream.rangeClosed( 0, weeks.size() - 1 ).forEach( element -> {
            if ( SMUtils.isElementPresent( mathHours.get( element ) ) ) {
                SMUtils.click( driver, mathHours.get( element ) );
                SMUtils.waitForElement( driver, mathHours.get( element ) );
                studentUsageTooltip.isDisplayed();
            } else if ( SMUtils.isElementPresent( readingHours.get( element ) ) ) {
                SMUtils.click( driver, readingHours.get( element ) );
                SMUtils.waitForElement( driver, readingHours.get( element ) );
                studentUsageTooltip.isDisplayed();
            } else {
                Log.message( "No Student Usage data present for the week: " + element );
            }
        } );
        Log.message( "Tooltip is displayed for each week in Student Usage chart" );
        return true;
    }

    /**
     * To verify color code for Math and Reading in Student Usage chart
     */
    public boolean verifyMathAndReadingColor() {
        SMUtils.waitForElement( driver, studentUsageChart );
        Log.message( "Verifying color code for Math and Reading in Student Usage chart" );
        return studentUsageLegendColors.stream().map( element -> SMUtils.getAttributeOfWebElement( element, driver, "fill" ) ).collect( Collectors.toList() ).equals( Dashboard.HEXA_COLORS_FOR_SUBJECTS );
    }

    /**
     * To get the Eight week student usage
     */
    public Map<String, Map<String, String>> getEightWeeksStudentUsage() {
        SMUtils.scrollDownPage( driver );
        // WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        new WebDriverWait( driver, Duration.ofSeconds( 90 ) ).until( ExpectedConditions.visibilityOfAllElements( weeks ) );
        List<String> dates = getEightWeeksMonday();
        Map<String, Map<String, String>> studentUsageForEightWeeks = new HashMap<>();
        Collections.reverse( dates );
        Iterator<String> weeksList = dates.iterator();

        IntStream.rangeClosed( 0, weeks.size() - 1 ).forEach( element -> {
            String week = weeksList.next();
            Map<String, String> studentUsageForWeek = new HashMap<>();
            if ( SMUtils.isElementPresent( mathHours.get( element ) ) ) {
                SMUtils.click( driver, mathHours.get( element ) );
                studentUsageForWeek.put( StudentUsage.MATH_MINS, studentUsageTooltip.getText().split( "\n" )[0] );
            } else {
                studentUsageForWeek.put( StudentUsage.MATH_MINS, "Math : 0 minutes" );
            }
            if ( SMUtils.isElementPresent( readingHours.get( element ) ) ) {
                SMUtils.click( driver, readingHours.get( element ) );
                studentUsageForWeek.put( StudentUsage.READING_MINS, studentUsageTooltip.getText().split( "\n" )[0] );
            } else {
                studentUsageForWeek.put( StudentUsage.READING_MINS, "Reading : 0 minutes" );
            }
            studentUsageForEightWeeks.put( week, studentUsageForWeek );
        } );
        return studentUsageForEightWeeks;
    }

    /**
     * To convert minutes into hours and minutes
     *
     * @return
     */
    public static String convertMinutesIntoHours( int minutes ) {
        String result = "";
        if ( minutes == 60 || minutes / 60 == 1 ) {
            result = result + Constants.UsageChart.ONE_HOUR + " ";
        } else if ( minutes > 60 ) {
            result = result + String.valueOf( minutes / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase() + " ";
        }
        if ( minutes % 60 != 0 ) {
            if ( minutes % 60 == 1 ) {
                result = result + "1 minute";
            } else {
                result = result + minutes % 60 + " " + Constants.UsageChart.MINUTES.toLowerCase();
            }

        }
        if ( result.equals( "" ) ) {
            result = "0 minutes";
        }
        return result.trim();
    }

    /**
     * To get This Week usage
     * 
     * @return
     */
    public String getThisWeekUsage() {

        new WebDriverWait( driver, Duration.ofSeconds( 30 ) ).until( ExpectedConditions.visibilityOfAllElements( weeks ) );
        return SMUtils.getTextOfWebElement( currentWeekUsage, driver );
    }

    /**
     * To get Last Week usage
     * 
     * @return
     */
    public String getLastWeekUsage() {
        new WebDriverWait( driver, Duration.ofSeconds( 30 ) ).until( ExpectedConditions.visibilityOfAllElements( weeks ) );
        return SMUtils.getTextOfWebElement( lastWeekUsage, driver );
    }

    /**
     * To get School year usage
     * 
     * @return
     */
    public String getSchoolYearUsage() {
        new WebDriverWait( driver, Duration.ofSeconds( 30 ) ).until( ExpectedConditions.visibilityOfAllElements( weeks ) );
        return SMUtils.getTextOfWebElement( schoolYearUsage, driver );
    }

    /**
     * To get zero state message for student usage
     * 
     * @return
     */
    public String getStudentUsageZeroStateMessage() {
        SMUtils.waitForElement( driver, zeroStateHeader, 20 );
        SMUtils.scrollToBottomOfPage( driver );
        return SMUtils.getTextOfWebElement( zeroStateHeader, driver );
    }

    /**
     * To get student usage y axis intervals
     * 
     * @return
     */
    public List<String> getStudentUsageYAxisIntervals() {
        SMUtils.scrollToBottomOfPage( driver );
        return SMUtils.getAllTextFromWebElementList( studentUsageYAxisIntervals );
    }

    /**
     * To convert minutes into hours and minutes
     *
     * @return
     */
    public static String convertMinutesIntoHoursWithRounding( int minutes ) {
        String result;
        if ( minutes == 0 ) {
            result = Constants.UsageChart.ZERO_HOURS;
        } else if ( minutes < 60 ) {
            result = Constants.UsageChart.LESS_THAN_ONE_HOUR;
        } else if ( minutes / 60 == 1 && minutes % 60 < 30 ) {
            result = Constants.UsageChart.ONE_HOUR;
        } else {
            if ( minutes % 60 < 30 ) {
                result = String.valueOf( minutes / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
            } else {
                result = String.valueOf( ( minutes / 60 ) + 1 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
            }
        }
        return result;
    }

    /**
     * To convert minutes into hours and minutes
     *
     * @return
     */
    public static String convertMinutesIntoHoursWithTenthDecimal( int minutes ) {
        String result;
        if ( minutes == 0 ) {
            result = Constants.UsageChart.ZERO_HOURS;
        } else if ( minutes < 60 ) {
            result = Constants.UsageChart.LESS_THAN_ONE_HOUR;
        } else if ( minutes / 60 == 1 && minutes % 60 == 30 ) {
            result = Constants.UsageChart.ONE_HOUR;
        } else {
            DecimalFormat decimalFormat = new DecimalFormat( "#.#" );
            result = decimalFormat.format( (double) minutes / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
        }
        return result;
    }

    /**
     * To get past four weeks Monday
     * 
     * @return
     */
    public static List<String> getEightWeeksMonday() {
        List<String> eightWeeksMonday = new ArrayList<String>();
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
        ZonedDateTime weekStartDate = ZonedDateTime.now( ZoneId.of( "America/Phoenix" ) );

        if ( weekStartDate.getDayOfWeek().toString().equals( "SUNDAY" ) ) {
            weekStartDate = weekStartDate.minusDays( 1 );
        }
        while ( !weekStartDate.getDayOfWeek().toString().equals( "MONDAY" ) ) {
            weekStartDate = weekStartDate.minusDays( 1 );
        }
        int iter = 0;
        while ( iter < 8 ) {
            eightWeeksMonday.add( weekStartDate.format( dateFormat ) );
            weekStartDate = weekStartDate.minusDays( 7 );
            iter++;
        }
        return eightWeeksMonday;
    }

    /**
     * Navigate to Setting List Page
     * 
     * @return
     */
    public AuditHistoryPage navigateToAuditHistoryPage() {
        SMUtils.nap( 1 ); // For loading in MAC ENV
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
        wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        subNavList.forEach( element -> {

            if ( element.getText().trim().equalsIgnoreCase( AdminUIConstants.AuditHistory.HEADER ) ) {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
                Log.message( "Audit History page is Clicked successfull" );
            }

        } );
        return new AuditHistoryPage( driver ).get();
    }
    /**
     * Navigate to Setting List Page
     * 
     * @return
     */
    public void navigateToDashboardPage() {
        SMUtils.nap( 1 ); // For loading in MAC ENV
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 15 ) );
        wait.until( ExpectedConditions.visibilityOf( sideNav ) );
        subNavList.forEach( element -> {

            if ( element.getText().trim().equalsIgnoreCase( AdminUIConstants.Dashboard.DASHBOARD ) ) {
                SMUtils.click( driver, element );
                SMUtils.click( driver, element );
                Log.message( "Dashboard page is Clicked successfull" );
            }

        } );
    }

    /**
     * Verify Usage goal is display
     * 
     * @return
     */
    public Boolean isUsageGoalDisplaying() {
        SMUtils.waitForElement( driver, toggleBtnRoot );
        SMUtils.scrollToBottomOfPage( driver );
        WebElement usageGoals = SMUtils.getWebElement( driver, toggleBtnRoot, usageGoalChildElement );
        Log.message( "Verifying usage goal is dislaying" );
        return usageGoals.isDisplayed();
    }

    /**
     * To validate the Header Text of Progress Bar
     * 
     * @param To Pass Math or Reading as Sub and Header Text to validate
     * @return
     * 
     */
    public boolean validateHeaderTextOfProgressBar( String subject, String header ) {
        if ( subject.equalsIgnoreCase( "MATH" ) ) {
            if ( mathUsageHeaderText.getText().trim().equals( header ) ) {
                status = true;
                Log.message( "Header Text is Validated for math" );
            }
        } else {
            if ( readingUsageHeaderText.getText().trim().equals( header ) ) {
                status = true;
                Log.message( "Header Text is Validated for Reading" );
            }
        }
        return status;
    }

    /**
     * To Validate all Legends Text for Both Math and Reading
     * 
     * @param To Pass Math or Reading as Sub
     * @return
     * 
     * @return
     */
    public boolean validateLegendText( String subject, String textToValidate ) {
        if ( subject.equals( Constants.MATH ) ) {
        	 allLegendsText.stream().forEach( eachtext -> {
                if ( eachtext.getText().trim().equalsIgnoreCase( textToValidate ) ) {
                    status = true;
                    Log.message( "Given text Validated" );
                }
            } );
        } else {
        	 allLegendsText.stream().forEach( eachtext -> {
                if ( eachtext.getText().trim().equalsIgnoreCase( textToValidate ) ) {
                    status = true;
                    Log.message( "Given text Validated" );
                }
            } );
        }
        return status;
    }

    /**
     * To validate the note text on the side of the page
     * 
     * @param To pass text to validate
     * @return
     */
    public boolean validateNoteText( String noteText ) {
        SMUtils.waitForElement( driver, noteTextOnOrgUsage );
        if ( SMUtils.getTextOfWebElement( noteTextOnOrgUsage, driver ).equals( noteText ) ) {
            status = true;
            Log.message( "Given Text Validated" );
        }
        return status;
    }

    /**
     * To Verify the Colour of the Usage Goal
     * 
     * @return
     */
    public boolean validateUsageGoalTextColour() {
        WebElement usageGoals = SMUtils.getWebElement( driver, toggleBtnRoot, usageGoalChildElement );
        SMUtils.scrollWebElementToView( driver, usageGoals );
        String colorRgb = usageGoals.getCssValue( Constants.Students.BACKGROUND_COLOR ).trim();
        String hexColor = Color.fromString( colorRgb ).asHex();
        if ( hexColor.equals( Constants.UsageGoal.HEX_VALUE_BLACK_COlOUR ) ) {
            status = true;
            Log.message( "Usage Goal Text Colour Validated" );
        }
        return status;
    }

    /**
     * To validate colour of the given Legend
     * 
     * @return
     */
    public boolean validateColourForAllLegends( String subject, String LegendName, String defaultColor ) {
        if ( subject.equals( Constants.MATH ) ) {
            IntStream.range( 0, mathBarAllLegendsText.size() ).forEach( eachText -> {
                if ( mathBarAllLegendsText.get( eachText ).getText().equals( LegendName ) ) {
                    String colourOfBlock = mathBarAllLegendsColours.get( eachText ).getAttribute( "style" ).substring( 18 ).trim().replace( ";", "" );
                    String hexColor = Color.fromString( colourOfBlock ).asHex();
                    if ( hexColor.equals( defaultColor ) ) {
                        status = true;
                        Log.message( "Colour Validated for given legend" );
                    }
                }
            } );
        } else {
            IntStream.range( 0, readingBarAllLegendsText.size() ).forEach( eachText -> {
                if ( readingBarAllLegendsText.get( eachText ).getText().equals( LegendName ) ) {
                    String colourOfBlock = readingBarAllLegendsColours.get( eachText ).getAttribute( "style" ).substring( 18 ).trim().replace( ";", "" );
                    String hexColor = Color.fromString( colourOfBlock ).asHex();
                    if ( hexColor.equals( defaultColor ) ) {
                        status = true;
                        Log.message( "Colour Validated for given legend" );
                    }
                }
            } );
        }
        return status;
    }

    /**
     * To get percentage details for each legend
     * 
     * @param To Pass Math or Reading as Subject
     * 
     * @return
     */
    public int getPercentageDetails( String subject, String legendName ) {
        if ( subject.equals( Constants.MATH ) ) {
            IntStream.range( 0, mathBarAllLegendsPercentage.size() ).forEach( eachText -> {
                if ( mathBarAllLegendsText.get( eachText ).getText().equals( legendName ) ) {
                    String percentageText = mathBarAllLegendsPercentage.get( eachText ).getText().trim();
                    if ( Character.toString( percentageText.charAt( 2 ) ).equals( "%" ) ) {
                        percentage = Integer.parseInt( percentageText.substring( 0, 2 ) );

                    } else {
                        percentage = Integer.parseInt( percentageText.substring( 0, 1 ) );
                    }
                }
            } );
        } else {
            if ( subject.equals( Constants.READING ) ) {
                IntStream.range( 0, readingBarAllLegendsPercentage.size() ).forEach( eachText -> {
                    if ( readingBarAllLegendsText.get( eachText ).getText().equals( legendName ) ) {
                        String percentageText = readingBarAllLegendsPercentage.get( eachText ).getText().trim();
                        if ( Character.toString( percentageText.charAt( 2 ) ).equals( "%" ) ) {
                            percentage = Integer.parseInt( percentageText.substring( 0, 2 ) );

                        } else {
                            percentage = Integer.parseInt( percentageText.substring( 0, 1 ) );
                        }
                    }
                } );
            }
        }
        return percentage;
    }

    /**
     * To validate whether the percentage is between 0 to 100 value
     * 
     * @return
     */
    public boolean verifyPercentageIsBetween0To100( String subject, String LegendName ) {
        boolean status = false;
        int percentageDetails = getPercentageDetails( subject, LegendName );
        if ( percentageDetails >= 0 && percentageDetails <= 100 ) {
            status = true;
            Log.message( "Percentage is between 0 to 100" );
        }
        return status;
    }

    /**
     * To validate whether the sum of all percentage is 100 for Math Progress or
     * Reading Progress
     * 
     * @return
     * 
     * @return
     */
    public boolean verifySumOfAllPercentageIsHundred( String subject ) {
        List<Integer> allValues = new ArrayList<Integer>();
        if ( subject.equals( Constants.MATH ) ) {
            mathBarAllLegendsPercentage.stream().forEach( eachtext -> {
                String percentageText = eachtext.getText().trim();
                if ( Character.toString( percentageText.charAt( 2 ) ).equals( "%" ) ) {
                    allValues.add( percentage = Integer.parseInt( percentageText.substring( 0, 2 ) ) );
                } else {
                    allValues.add( percentage = Integer.parseInt( percentageText.substring( 0, 1 ) ) );
                }
            } );
        } else {
            if ( subject.equals( Constants.READING ) ) {
                readingBarAllLegendsPercentage.stream().forEach( eachtext -> {
                    String percentageText = eachtext.getText().trim();
                    if ( Character.toString( percentageText.charAt( 2 ) ).equals( "%" ) ) {
                        allValues.add( percentage = Integer.parseInt( percentageText.substring( 0, 2 ) ) );
                    } else {
                        allValues.add( percentage = Integer.parseInt( percentageText.substring( 0, 1 ) ) );
                    }
                } );
            }
        }
        allValues.stream().forEach( eachValue -> {
            totalValue = totalValue + eachValue;
        } );
        if ( totalValue == 100 ) {
            status = true;
        }
        return status;
    }

    /**
     * To get No Of Organization Selected from the text at the bottom of the
     * page
     * 
     * @return
     */

    public int getNofOrganizationSelected() {
        int noOfOrgSelected = 0;
        SMUtils.waitForElement( driver, noOfOrganizationSelected );
        String text = noOfOrganizationSelected.getText().trim();
        if ( text.length() == Constants.UsageGoal.NO_OF_ORG_TEXT_SIZE ) {
            noOfOrgSelected = Integer.parseInt( String.valueOf( text.charAt( 0 ) ) );
        } else {
            String noOfOrg = text.substring( 0, 2 );
            noOfOrgSelected = Integer.parseInt( noOfOrg );
            String.valueOf( noOfOrgSelected );
        }
        return noOfOrgSelected;
    }

    /**
     * To get No Of Organization Selected from the text at the bottom of the
     * page
     * 
     * @return
     */

    public String getNofOrganizationSelectedDetails() {
        int noOfOrgSelected = 0;
        String noOfOrg = null;
        SMUtils.waitForElement( driver, noOfOrganizationSelected );
        String text = noOfOrganizationSelected.getText().trim();
        if ( text.length() == Constants.UsageGoal.NO_OF_ORG_TEXT_SIZE ) {
            noOfOrgSelected = Integer.parseInt( String.valueOf( text.charAt( 0 ) ) );
        } else {
            noOfOrg = text.substring( 0, 2 );
            noOfOrgSelected = Integer.parseInt( noOfOrg );

        }
        return noOfOrg;
    }

    /**
     * To get No Of Organization Selected full text
     * 
     * @return
     */
    public String getNoOfOrganizationSelectedText() {
        SMUtils.waitForElement( driver, noOfOrganizationSelected );
        return noOfOrganizationSelected.getText().trim();
    }

    /**
     * To verify if no organization is selected
     */
    public boolean verifyNoOrganizationSelectedOnTheDropDown() {
        clickAllOptionsInOrganizationDropdown();
        clickApplySelectionButton();
        int nofOrganizationSelected = getNofOrganizationSelected();
        if ( nofOrganizationSelected == 0 ) {
            status = true;
        }
        return status;
    }

    /**
     * To verify if all organization is selected matches with text
     */
    public boolean VerifyAllOrganizationSelectedMatchWithText() {
        String selectedOrganizationCount = getSelectedOrganizationCount();
        int nofOrganizationSelectedShownInText = getNofOrganizationSelected();
        if ( selectedOrganizationCount.length() == 21 ) {
            String count = Character.toString( selectedOrganizationCount.charAt( 19 ) );
            int numOforgSelected = Integer.parseInt( count );
            if ( numOforgSelected == nofOrganizationSelectedShownInText ) {
                status = true;
            }
        } else {
            String noOfOrg = selectedOrganizationCount.substring( 19, 21 );
            int numOforgSelected = Integer.parseInt( noOfOrg );
            if ( numOforgSelected == nofOrganizationSelectedShownInText ) {
                status = true;
            }
        }
        Log.message( "Verify all selected organization showing below on usage goal page" );
        return status;
    }

    /**
     * Get zero state
     * 
     * @return
     */
    public String getZeroStateHeader() {
        SMUtils.waitForElement( driver, zeroStateHeader );
        Log.message( "Get zero state header text" );
        return zeroStateHeader.getText().trim();
    }

    /**
     * Get zero state
     * 
     * @return
     */
    public String getZeroStateDescription() {
        SMUtils.waitForElement( driver, zeroStateDesc );
        Log.message( "Get zero state description text" );
        return zeroStateDesc.getText().trim();
    }

    /**
     * Get ZeroStateMessage
     * 
     * @return
     */
    public List<String> getPerformanceReportZeroStateMessage() {
        SMUtils.waitForElement( driver, zeroStateMessageHeader );
        List<String> zeroStateMessage = new ArrayList<>();
        zeroStateMessage.add( SMUtils.getTextOfWebElement( zeroStateMessageHeader, driver ) );
        zeroStateMessage.add( SMUtils.getTextOfWebElement( zeroStateMessageDescription, driver ) );
        return zeroStateMessage;
    }

    /**
     * This method will select given organization and click Apply Selection
     * button to load the data
     * 
     * @param orgNames
     */
    public void loadDataForGivenOrganizations( List<String> orgNames ) {
        clickAllOptionsInOrganizationDropdown();
        orgNames.stream().forEach( org -> {
            enterTextInSearchTextBox( org );
            selectOrganizationsFromOrgDropdown( Arrays.asList( org ) );
        } );
        clickApplySelectionButton();
        Log.message( "Given organizations are selected: " + orgNames );
    }

    /**
     * To get current course level average value
     * 
     * @return
     */
    public List<String> getCurrentCourseAvrgValue() {
        SMUtils.waitForElement( driver, xAxisLabel );
        List<String> averageValues = new ArrayList<>();
        IntStream.rangeClosed( 0, 12 ).forEach( itr -> {
            try {
                String value = driver.findElement( By.cssSelector( String.format( currentCourseAvrgValue, itr ) ) ).getText().trim();
                Log.message( "Grade-" + itr + " " + value );
                averageValues.add( value );
            } catch ( Exception e ) {
                Log.message( "No performance data for grade-" + itr );
            }
        } );
        Log.message( "Average Values: " + averageValues );
        return averageValues;
    }

    /**
     * This Method Will Select all the Organization given inside
     * 
     * @param List of Organization
     * @return
     */
    public Boolean selectGivenOrgFromDropDown( List<String> orgName ) throws InterruptedException {
        Boolean status = false;
        WebElement expandIcon = SMUtils.getWebElementDirect( driver, orgListingDropDown, expandCollapseOrganizationDropdown );
        SMUtils.clickJS( driver, expandIcon );
        // Showing Null Property if we use Dynamic wait
        Thread.sleep( 5000 );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, orgListingDropDown, selectAllRoot, checkBox ) );
        List<WebElement> webElementsDirect = SMUtils.getWebElementsDirect( driver, orgListingDropDown, orgListRoot );
        for ( int eachOrg = 0; eachOrg < webElementsDirect.size(); eachOrg++ ) {
            WebElement webElement = SMUtils.getWebElement( driver, webElementsDirect.get( eachOrg ), allOrgRoot );
            if ( orgName.contains( webElement.getText() ) ) {
                status = true;
                SMUtils.clickJS( driver, webElement );
            }
        }
        return status;
    }

    /**
     * To get the column headers in Organization performance this week
     * 
     * @return
     */
    public List<String> getPerformanceThisWeekHeader() {
        SMUtils.waitForElement( driver, studentUsageChart );
        return SMUtils.getAllTextFromWebElementList( organizationPerformanceThisWeekHeaders );

    }

    /**
     * dashboard page display
     * 
     * @return
     */
    public Boolean isdashboardPagedisplay() {
        try {
            SMUtils.waitForElement( driver, sideNav );
            SMUtils.scrollToBottomOfPage( driver );
            List<String> dashboard = SMUtils.getAllTextFromWebElementList( subNavbar );
            return dashboard.contains( AdminUIConstants.SUBNAVIGATION.get( 0 ) );

        } catch ( Exception e ) {
            Log.message( "Dashboard subnavigation should not display" );
            return false;
        }

    }

    /**
     * mastery page display
     * 
     * @return
     */
    public Boolean ismasteryPagedisplay() {
        try {
            SMUtils.waitForElement( driver, sideNav );
            SMUtils.scrollToBottomOfPage( driver );
            List<String> mastery = SMUtils.getAllTextFromWebElementList( subNavbar );
            return mastery.contains( AdminUIConstants.SUBNAVIGATION.get( 1 ) );

        } catch ( Exception e ) {
            Log.message( "Dashboard subnavigation should not display" );
            return false;
        }
    }

    /**
     * To click on the organization dropdown on the admin dashboard screen
     * 
     */
    public void clickOrganizationDropdownOnAdminDashboard() {
        SMUtils.waitForElement( driver, organizationDropdown );
        SMUtils.click( driver, organizationDropdown );
    }    
    /**
     * To select organization from the dropdown
     * 
     * @param organizationName
     * 
     */
    public void clickOrgnizationFromTheDropdown( String organizationName ) {

        organizationDropdownValues.stream().filter( elementOfDropDown -> SMUtils.getTextOfWebElement( elementOfDropDown, driver ).equalsIgnoreCase( organizationName ) ).findFirst().ifPresent( element -> {
            if ( SMUtils.getTextOfWebElement( element, driver ).equalsIgnoreCase( organizationName ) ) {
                SMUtils.click( driver, element );
                Log.message( "Organization clicked from the dropdown is " + organizationName );
            } else {
                Log.message( "There was no orgnaztion called " + organizationName + "to be clicked" );
            }
        } );
    }

    /**
     * To click on the organization from the dropdown for the Performance report
     * 
     * @param organizationName
     * 
     */
    public void clickOrganizationNameFromDropdownOnAdminDashboard( String organizationName ) {
        clickOrganizationDropdownOnAdminDashboard();
        clickOrgnizationFromTheDropdown( organizationName );
    }

    /**
     * @param valuesFromUI
     * @param response
     * @return
     */
    public boolean verifyDeletedAssignmentsAreDisplayed( Map<String, Map<String, String>> valuesFromUI, Response response ) {
        Map<String, Map<String, String>> getAuditHistoryAssignment = new HashMap<>();
        IntStream.range( 0, SMUtils.getWordCount( response.getBody().asString(), "assignmentTitle" ) ).forEach( iter -> {
            Map<String, String> deletedAssignments = new HashMap<>();
            String rspn = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
            JSONObject jsonObj = new JSONObject( rspn );
            JSONArray ja = jsonObj.getJSONArray( "getAssignmentAudits" );
            JSONObject jObj = ja.getJSONObject( iter );
            deletedAssignments.put( "deletedBy", jObj.get( "deletedBy" ).toString() );
            deletedAssignments.put( "assignmentTitle", jObj.get( "assignmentTitle" ).toString() );
            deletedAssignments.put( "studentOrGroupName", jObj.get( "studentOrGroupName" ).toString() );
            deletedAssignments.put( "recordType", jObj.get( "recordType" ).toString().toUpperCase() );
            deletedAssignments.put( "assignedBy", jObj.get( "assignedBy" ).toString() );
            deletedAssignments.put( "courseName", jObj.get( "courseName" ).toString() );
            getAuditHistoryAssignment.put( Integer.toString( iter ), deletedAssignments );
        } );
        return valuesFromUI.entrySet().stream().allMatch( entry -> getAuditHistoryAssignment.entrySet().stream().anyMatch( value -> SMUtils.compareTwoHashMap( value.getValue(), entry.getValue() ) ) );
    }
    
    /**
     * To get Selected Org in organization dropdown text box
     * 
     * @return
     */
    public String getOrgNameFromOrgTextBox() {
        return SMUtils.getTextOfWebElement(orgNameInDropDownTextBox, driver );
    }
    
    /**
     * To get No Data to display text from Performance graph
     * 
     * @return
     */
    public List<String> getNoDataToDisplayText() {
        return SMUtils.getAllTextFromWebElementList( noDataToDisplay );
    }

}
