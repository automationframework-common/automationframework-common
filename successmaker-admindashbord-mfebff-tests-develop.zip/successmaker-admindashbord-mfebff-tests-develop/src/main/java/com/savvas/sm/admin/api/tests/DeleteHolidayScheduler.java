package com.savvas.sm.admin.api.tests;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.settings.HolidayScheduler;

public class DeleteHolidayScheduler {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    public RBSUtils rbsUtils = new RBSUtils();
    private String username;
    private String password;
    private String orgId;
    private String userId;
    private String flexSchool;
    private String mathSchool;
    private String accessToken;
    private Map<String, String> response;
    HashMap<String, String> params = new HashMap<String, String>();
    HolidayScheduler holidayScheduler = new HolidayScheduler();
    String endPoint = AdminConstants.DELETE_HOLIDAY_SCHEDULER;

    @BeforeClass(alwaysRun = true)
    public void BeforeClass() throws Exception {

        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = configProperty.getProperty( "district_ID" );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        // Creating Admin user data to login
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        accessToken = rbsUtils.getAccessToken( username, password );
    }

    /**
     * To Verify valid scenarios for Delete Holiday
     * 
     * @param testcaseName
     * @param statusCode
     * @param testcaseDescription
     * @param scenarioType
     * @throws Exception
     */
    @Test ( dataProvider = "DeleteHolidaysPositiveScenariosData", groups = { "smoke_test_case", "SMK-50435", "Delete Holiday Scheduler", "API" }, priority = 1 )
    public void deleteHolidayScheduler001( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        String startDate;
        String endDate;
        Map<String, String> deleteResponse = new HashMap<String, String>();
        List<String> dateFromGetCall;
        String selectedOrganizationId = "";
        Log.testCaseInfo( testcaseName + ":" + testcaseDescription );

        // Headers
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( AdminAPIConstants.ORGID, orgId );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
        SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy-MM-dd" );
        Calendar calendar = Calendar.getInstance();
        calendar.setTime( new Date() );

        switch ( scenarioType ) {
            case "DELETE ALL HOLIDAYS":

                //Getting first monday to add the holidays
                LocalDate now = LocalDate.now();
                LocalDate firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                LocalDate firstFriday = firstMonday.plusDays( 5 );
                endDate = firstFriday.toString();

                holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, AdminAPIConstants.HOLIDAY + "" + System.nanoTime(), orgId );

                // To get data
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                dateFromGetCall = getDatesFromResponse( response.get( Constants.REPORT_BODY ) );
                Collections.sort( dateFromGetCall );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, dateFromGetCall.get( 0 ), dateFromGetCall.get( dateFromGetCall.size() - 1 ), "", orgId );
                Log.message( deleteResponse.toString() );
                // data Validation
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                dateFromGetCall = getDatesFromResponse( response.get( Constants.REPORT_BODY ) );
                Log.assertThat( dateFromGetCall.isEmpty(), "All holidays date are deleted as expected", "All holidays are not deleted" );
                break;

            case "DELETE SINGLE HOLIDAY":
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();

                holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, AdminAPIConstants.HOLIDAY + "" + System.nanoTime(), orgId );

                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, startDate, "", selectedOrganizationId );
                Log.message( deleteResponse.toString() );

                // data Validation
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                dateFromGetCall = getDatesFromResponse( response.get( Constants.REPORT_BODY ) );
                Log.assertThat( !dateFromGetCall.contains( startDate ), "Single holidays date is deleted as expected", "Single holidays date is  not deleted in holiday scheduler" );
                break;

            case "DELETE MULTIPLE HOLIDAY":
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();

                List<String> deletedDates = new ArrayList<String>();

                IntStream.range( 0, 3 ).forEach( itr -> {
                    deletedDates.add( firstMonday.plusDays( itr ).toString() );
                } );
                holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, deletedDates.get( deletedDates.size() - 1 ), AdminAPIConstants.HOLIDAY + "" + System.nanoTime(), orgId );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, deletedDates.get( deletedDates.size() - 1 ), "", orgId );
                Log.message( deleteResponse.toString() );

                // data Validation

                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                List<String> datesFromGetCall = getDatesFromResponse( response.get( Constants.REPORT_BODY ) );
                Log.assertThat( deletedDates.stream().allMatch( date -> !datesFromGetCall.contains( date ) ), "Multiple holidays date is deleted as expected", "Multiple holidays date is  not deleted in holiday scheduler" );
                break;

            case "DELETE INCORRECT HOLIDAY":
                calendar.add( Calendar.DATE, -20 );
                startDate = dateFormat.format( calendar.getTime() );

                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, startDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "DELETE SOME CORRECT HOLIDAY AND SOME INCORRECT HOLIDAY":
                // To create data
                startDate = dateFormat.format( calendar.getTime() );
                calendar.add( Calendar.DATE, 7 );
                endDate = dateFormat.format( calendar.getTime() );

                holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, AdminAPIConstants.HOLIDAY + "" + System.nanoTime(), orgId );

                calendar.add( Calendar.DATE, 10 );
                endDate = dateFormat.format( calendar.getTime() );

                deletedDates = new ArrayList<String>();
                calendar.setTime( new Date() );
                calendar.add( Calendar.DATE, 6 );
                IntStream.range( 0, 10 ).forEach( itr -> {
                    deletedDates.add( dateFormat.format( calendar.getTime() ) );
                    calendar.add( Calendar.DATE, 1 );
                } );

                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", selectedOrganizationId );
                Log.message( deleteResponse.toString() );

                // data Validation
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                List<String> datesFromGetResponse = getDatesFromResponse( response.get( Constants.REPORT_BODY ) );
                Log.assertThat( deletedDates.stream().allMatch( date -> !datesFromGetResponse.contains( date ) ), "Multiple holidays date are deleted which are present in DB", "All holidays date are not deleted in holiday scheduler" );
                break;

            case "DELETE SOME RANGE OF HOLIDAYS":
                // To create data
                startDate = dateFormat.format( calendar.getTime() );
                calendar.add( Calendar.DATE, 7 );
                endDate = dateFormat.format( calendar.getTime() );

                holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, AdminAPIConstants.HOLIDAY + "" + System.nanoTime(), orgId );

                deletedDates = new ArrayList<String>();
                calendar.setTime( new Date() );
                IntStream.range( 0, 7 ).forEach( itr -> {
                    deletedDates.add( dateFormat.format( calendar.getTime() ) );
                    calendar.add( Calendar.DATE, 1 );
                } );

                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", selectedOrganizationId );
                Log.message( deleteResponse.toString() );

                // data Validation
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                List<String> datesFromGet = getDatesFromResponse( response.get( Constants.REPORT_BODY ) );
                Log.assertThat( deletedDates.stream().allMatch( date -> !datesFromGet.contains( date ) ), "Multiple holidays date are deleted which are present in DB", "All holidays date are not deleted in holiday scheduler" );
                break;
            default:
                Log.message( "Invalid Scenario type: " + scenarioType );
                break;
        }

        // status code Validation
        Log.assertThat( deleteResponse.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + deleteResponse.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + deleteResponse.get( Constants.STATUS_CODE ) + "is not Verified" );

        // schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "deleteHolidaySchedulerSchema", statusCode, deleteResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] DeleteHolidaysPositiveScenariosData() {
        Object[][] data = { { "tcdeleteHolidayScheduler001: ", "200", "Verify response with 200 response code when all holiday has been deleted", "DELETE ALL HOLIDAYS" },
                { "tcdeleteHolidayScheduler002: ", "200", "Verify response with 200 response code when single holiday has been deleted", "DELETE SINGLE HOLIDAY" },
                { "tcdeleteHolidayScheduler003: ", "200", "Verify response with 200 response code when multiple holidays has been deleted", "DELETE MULTIPLE HOLIDAY" },
                { "tcdeleteHolidayScheduler004: ", "200", "Verify the response when the requested date is not in the holiday list", "DELETE INCORRECT HOLIDAY" },
                { "tcdeleteHolidayScheduler005: ", "200", "Verify the response when the requested date is not in the holiday list", "DELETE SOME CORRECT HOLIDAY AND SOME INCORRECT HOLIDAY" },
                { "tcdeleteHolidayScheduler006: ", "200", "Verify if deleted data is from a range, the range is split appropriately.", "DELETE SOME RANGE OF HOLIDAYS" }, };
        return data;
    }

    /**
     * To Verify negative scenarios for Delete Holiday
     * 
     * @param testcaseName
     * @param statusCode
     * @param testcaseDescription
     * @param scenarioType
     * @throws Exception
     */
    @Test ( dataProvider = "DeleteHolidaysNegativeScenariosData", groups = { "SMK-50435", "Delete Holiday Scheduler", "API" }, priority = 1 )
    public void deleteHolidayScheduler002( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        String startDate;
        String endDate;
        Map<String, String> deleteResponse = new HashMap<String, String>();

        Log.testCaseInfo( testcaseName + ":" + testcaseDescription );

        SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy-MM-dd" );
        Calendar calendar = Calendar.getInstance();
        calendar.setTime( new Date() );
        startDate = dateFormat.format( calendar.getTime() );
        calendar.add( Calendar.DATE, 3 );
        endDate = dateFormat.format( calendar.getTime() );
        List<String> selectedOrganizationId = new ArrayList<>();
        // Headers
        Map<String, String> headers = new HashMap<>();

        switch ( scenarioType ) {
            case "WRONG ACCESS TOKEN":
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken + "incorrect" );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "WITHOUT ACCESS TOKEN":
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "WITHOUT REQUEST BODY":
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken + "incorrect" );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );

                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, "", "", "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "WITH TEACHER CREDENTIAL":
                String teacherDetails = RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ).get( "Teacher1" );
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( "School1" ) );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "WITHOUT ORGID":
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "WITHOUT USERID":
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "INVALID WITH SUB DISTRICT ADMIN":
                // Getting Subdistrict admin details
                String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                String subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
                String subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
                // Setting Headers
                headers.put( AdminAPIConstants.ORGID, subDistrictwithSchoolId );
                headers.put( AdminAPIConstants.USERID, subdistrictUserID );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SUBDISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            case "INVALID WITH SCHOOL ADMIN":

                // Getting School admin details
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
                // Setting Headers
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                headers.put( AdminAPIConstants.USERID, schoolAdminUserID );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUsername, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                Log.message( "Making Delete Call for Holiday scheduler - " + smUrl + endPoint );
                deleteResponse = holidayScheduler.deleteHolidayScheduler( smUrl, headers, startDate, endDate, "", orgId );
                Log.message( deleteResponse.toString() );

                break;

            default:
                Log.message( "Invalid Scenario type: " + scenarioType );
                break;
        }

        // status code Validation
        Log.assertThat( deleteResponse.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + deleteResponse.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + deleteResponse.get( Constants.STATUS_CODE ) + "is not Verified" );
        // schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "deleteHolidaySchedulerSchema", statusCode, deleteResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] DeleteHolidaysNegativeScenariosData() {
        Object[][] data = { { "tcdeleteHolidayScheduler007: ", "401", "Verify response with 401 response code when wrong access_token given", "WRONG ACCESS TOKEN" },
                { "tcdeleteHolidayScheduler008: ", "401", "Verify response with 401 response code when without access_token given", "WITHOUT ACCESS TOKEN" },
                { "tcdeleteHolidayScheduler009: ", "401", "Verify response with 401Bad request when no request body is passing in request", "WITHOUT REQUEST BODY" },
                { "tcdeleteHolidayScheduler010: ", "403", "Verify Student/Teacher should not able to delete any holidaay", "WITH TEACHER CREDENTIAL" },
                { "tcdeleteHolidayScheduler011: ", "403", "Verify response with 403 response code while hit the API without orgId.", "WITHOUT ORGID" },
                { "tcdeleteHolidayScheduler012: ", "401", "Verify response with 401 response code while hit the API without userId.", "WITHOUT USERID" },
                { "tcdeleteHolidayScheduler013: ", "403", "Verify subdistrict admin should not able to delete any holidaay", "INVALID WITH SUB DISTRICT ADMIN" },
                { "tcdeleteHolidayScheduler014: ", "403", "Verify school admin should not able to delete any holidaay", "INVALID WITH SCHOOL ADMIN" } };
        return data;
    }

    /**
     * to get holiday dates from response
     * 
     * @param response
     * @return
     */
    public List<String> getDatesFromResponse( String response ) {
        String keyValueFromResponse = SMUtils.getKeyValueFromResponseWithArray( response, "data" );
        List<String> dateFromResponse = new ArrayList<String>();
        IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
            JSONArray ja = new JSONArray( keyValueFromResponse );
            JSONObject jObj = ja.getJSONObject( itr );
            dateFromResponse.add( jObj.get( "date" ).toString() );
        } );
        return dateFromResponse;
    }

}
