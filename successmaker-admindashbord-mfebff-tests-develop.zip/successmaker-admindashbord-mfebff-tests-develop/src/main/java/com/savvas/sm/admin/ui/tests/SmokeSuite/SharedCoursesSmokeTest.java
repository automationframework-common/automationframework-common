package com.savvas.sm.admin.ui.tests.SmokeSuite;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SharedCourseOrganizationPopupPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;

public class SharedCoursesSmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtAdminDetails;
    private String districtId;
    private String schoolName;
    private String teacherDetails;
    private String districtAdminUserName;
    private String districtAdminUserId;
    private String teacherId;
    private String teacherUsername;
    private String teacherOrgId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting district admin details from RBS Datasetup
        districtAdminUserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        districtAdminUserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        // Getting teacher details
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( schoolName );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = RBSDataSetup.organizationIDs.get( schoolName );
    }

    @Test ( description = "Verify the shared Course list for school admin", priority = 1 )
    public void tcSMSharedCourse001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMSharedCourse001: Verify the shared Course list view page for district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Creating share course
            String courseNameSettings = "Reading Custom by Setting_" + System.nanoTime();
            String courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( schoolName ), DataSetupConstants.SETTINGS,
                    courseNameSettings );
            Log.message( "Shared course is created successfully!!!" );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( districtAdminUserName, password );

            SharedCoursesListViewPage sharedCoursesPage = dashBoardPage.navigateToSharedCoursesListPage();

            sharedCoursesPage.enterValueInSearchBox( courseNameSettings );
            Log.assertThat( sharedCoursesPage.getAllSharedCourses().contains( courseNameSettings ), "Shared Setting course - Reading is displayed", "Shared Setting course - Reading is not displayed" );

            //Click edit button for the created course
            SharedCourseOrganizationPopupPage editPopup = sharedCoursesPage.clickEditButton( courseNameSettings );

            Log.assertThat( editPopup.isShareAllButtonPresent(), "Share All button is displayed in the Edit share list pop up", "Share All button is not displayed in the Edit share list pop up" );

            editPopup.clickShareAll();
            sharedCoursesPage = editPopup.clickSaveButton();
            editPopup = sharedCoursesPage.clickEditButton( courseNameSettings );
            Log.assertThat( editPopup.isUnshareAllButtonPresent(), "User able to share the course to other organization", "User unable to share the course to other organization" );

            editPopup.clickUnShareAll();
            sharedCoursesPage = editPopup.clickSaveButton();
            editPopup = sharedCoursesPage.clickEditButton( courseNameSettings );
            Log.assertThat( editPopup.getCourseSharedOrganizations().containsAll( Arrays.asList( schoolName ) ), "User able to share the course to other organization", "User unable to share the course to other organization" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Shared course for school admin", priority = 1 )
    public void tcSMSharedCourse002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMSharedCourse002: Verify the shared Course list view page for school admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Creating share course
            String courseNameSettings = "Reading Custom by Setting_" + System.nanoTime();
            String courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( schoolName ), DataSetupConstants.SETTINGS,
                    courseNameSettings );
            Log.message( "Shared course is created successfully!!!" );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            SharedCoursesListViewPage sharedCoursesPage = dashBoardPage.navigateToSharedCoursesListPage();

            sharedCoursesPage.enterValueInSearchBox( courseNameSettings );
            Log.assertThat( sharedCoursesPage.getAllSharedCourses().contains( courseNameSettings ), "Shared Setting course - Reading is displayed", "Shared Setting course - Reading is not displayed" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
