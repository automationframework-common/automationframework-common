package com.savvas.sm.admin.ui.tests.SmokeSuite;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.RestoreAssignmentsListPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.CREATED_DELETED_DATE;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.RestoreAssignmentList;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class RestoreAssignmentSmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String savvasAdminUserName;
    private String savvasAccessToken;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String teacherOrgId;
    private String teacherId;
    private String teacherUsername;
    private String school;
    private String studentDetails;
    private String studentUserId;
    private String courseName;
    private String courseId;
    private String savvasAdminUserId;
    private String studentUserName;
    private String teacherName;
    private String studentName;
    private String assignmentUserId;
    private Map<String, String> headers = new HashMap<>();
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        // Getting savvas admin details in RBS Datasetup
        savvasAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String savvasAdminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        savvasAdminUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        savvasAdminUserName = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        savvasAccessToken = new RBSUtils().getAccessToken( savvasAdminUserName, password );

        // Getting teacher details
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherOrgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.LASTNAME ) + ", " + SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.FIRSTNAME );

        // Getting student details
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) + ", " + SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME );

        // Creating custom course
        courseName = "Restore Assignment - " + System.nanoTime();
        courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, teacherOrgId, DataSetupConstants.SETTINGS, courseName );
        Log.event( "Deleted Assignment Name - " + courseName );

        // Assigning an assignment
        mathAssignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        mathAssignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherId );
        mathAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
        Log.event( "Assignment Response - " + assignmentResponse.toString() );

        // Getting assignment id
        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject assignmentInfo = new JSONObject( assignmentList.get( 0 ).toString() );
        String assignmentId = assignmentInfo.get( "assignmentId" ).toString();
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserId, assignmentId );
        Log.event( "Assignment User id - " + assignmentUserId );

        // Remove student assignemnt 
        mathAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

        // Headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAccessToken );
    }

    @Test ( description = "Verify Restore Assignment page should be accessible only for savvas Admin and not for Customer Admin", groups = { "smoke_test_case", "Audit History", "admin_TC23", "P1" }, priority = 1 )
    public void tcSMAdminRestoreAssignmentSmoke001() throws Exception {

        Log.testCaseInfo( "tcSMAdminRestoreAssignmentSmoke001: Verify Restore Assignment page should be accessible only for savvas Admin and not for Customer Admin <small><b><i>[" + browser + "]</b></i></small>" );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {

            //Launching the login page
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( savvasAdminUserName, password, teacherOrgId );

            RestoreAssignmentsListPage restoreAssignmentPage = dashBoardPage.navigateToRestoreAssignmentsListPage( teacherOrgId );

            //Verifying the Page Header
            Log.assertThat( restoreAssignmentPage.getRestoreAssignmentHeader().equals( AdminUIConstants.RestoreAssignmentList.HEADER ), "Restore assignment page header is displayed successfully!!!",
                    "Restore assignment page header is not displayed properly. Expected - " + AdminUIConstants.RestoreAssignmentList.HEADER + ".Actual - " + restoreAssignmentPage.getRestoreAssignmentHeader() );

            //Verifying the Column Headers
            Log.assertThat( restoreAssignmentPage.getRestoreAssignmentTableTitle().equals( AdminUIConstants.RestoreAssignmentList.TABLE_TITTLE ), "Restore assignment table columns are displayed properly!!!",
                    "Restore assignment table column Headers are not displaying properly. Expected - " + AdminUIConstants.RestoreAssignmentList.TABLE_TITTLE + ". Actual - " + restoreAssignmentPage.getRestoreAssignmentTableTitle() );

            //To get the Assignment created date and deleted date from database
            String deletedDateTime = restoreAssignmentPage.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId );
            String createdDateTime = restoreAssignmentPage.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_CREATED, assignmentUserId );

            //To get the deleted assignment from UI
            List<String> deletedDataList = restoreAssignmentPage.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            List<String> expectedList = Arrays.asList( courseName, teacherName, studentName, studentUserName.toLowerCase(), deletedDateTime, RestoreAssignmentList.RESTORE );
            String expectedAssignment = "";
            for ( String value : expectedList ) {
                expectedAssignment = expectedAssignment + value + " ";
            }
            //Verifying the deleted assignment details with deleted date
            Log.assertThat( deletedDataList.contains( expectedAssignment.toString().replace( " pm ", " PM " ).replace( " am ", " AM " ).trim() ), "Deleted assignment details are displaying properly in restore assignment listing page",
                    "Deleted assignment details are not displaying properly in restore assignment listing page. Expected - " + expectedAssignment.toString() + ".Actual - " + deletedDataList.toString() );

            restoreAssignmentPage.toggleToCreatedOnCloumn();
            List<String> createdDataList = restoreAssignmentPage.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            expectedList = Arrays.asList( courseName, teacherName, studentName, studentUserName.toLowerCase(), createdDateTime, RestoreAssignmentList.RESTORE );
            expectedAssignment = "";
            for ( String value : expectedList ) {
                expectedAssignment = expectedAssignment + value + " ";
            }

            //Verifying the deleted assignment details with deleted date
            Log.assertThat( createdDataList.contains( expectedAssignment.toString().replace( " pm ", " PM " ).replace( " am ", " AM " ).trim() ), "Deleted assignment details are displaying properly in restore assignment listing page",
                    "Deleted assignment details are not displaying properly in restore assignment listing page. Expected - " + expectedAssignment.toString() + ".Actual - " + createdDataList.toString() );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify savvas admin able to restore the deleted assignment", groups = { "smoke_test_case", "Audit History", "admin_TC24", "P1" }, priority = 1 )
    public void tcSMAdminRestoreAssignmentSmoke002() throws Exception {

        Log.testCaseInfo( "tcSMAdminRestoreAssignmentSmoke002: Verify savvas admin able to restore the deleted assignment <small><b><i>[" + browser + "]</b></i></small>" );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            //Launching the login page
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( savvasAdminUserName, password, teacherOrgId );

            RestoreAssignmentsListPage restoreAssignmentPage = dashBoardPage.navigateToRestoreAssignmentsListPage( teacherOrgId );

            // To date the deleted date for the assignment
            String deletedDateTime = restoreAssignmentPage.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId );
            restoreAssignmentPage.clickTheRestoreButton( deletedDateTime.substring( 11, 23 ), studentUserName );

            // To get the displaying assignment detail from restore listing page
            List<String> deletedDataList = restoreAssignmentPage.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            Log.assertThat( deletedDataList.isEmpty() || !deletedDataList.contains( courseName ), "The deleted assignments is restored properly ", "The deleted assignment is not restored properly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the error message is displayed when restoring the same assignment", groups = { "smoke_test_case", "Audit History", "admin_TC25", "P1" }, priority = 1 )
    public void tcSMAdminRestoreAssignmentSmoke003() throws Exception {

        Log.testCaseInfo( "tcSMAdminRestoreAssignmentSmoke003: Verify the error message is displayed when restoring the same assignment <small><b><i>[" + browser + "]</b></i></small>" );

        //assigning assignment
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) + ", " + SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
        Log.event( "assignment reponse -" + assignmentResponse.toString() );

        // Getting assignment id
        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject assignmentInfo = new JSONObject( assignmentList.get( 0 ).toString() );
        String assignmentId = assignmentInfo.get( "assignmentId" ).toString();
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserId, assignmentId );
        Log.event( "Assignment User id - " + assignmentUserId );

        // Remove student assignemnt 
        mathAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

        // Again assigning the same assignment
        assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
        Log.event( "assignment reponse -" + assignmentResponse.toString() );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            //Launching the login page
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( savvasAdminUserName, password, teacherOrgId );

            RestoreAssignmentsListPage restoreAssignmentPage = dashBoardPage.navigateToRestoreAssignmentsListPage( teacherOrgId );

            // To date the deleted date for the assignment
            String deletedDateTime = restoreAssignmentPage.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId );
            restoreAssignmentPage.clickTheRestoreButton( deletedDateTime.substring( 11, 23 ), studentUserName );

            // To get the displaying assignment detail from restore listing page
            Log.message( restoreAssignmentPage.getErrorMessage() );
            Log.assertThat( restoreAssignmentPage.getErrorMessage().equalsIgnoreCase( RestoreAssignmentList.ERROR_MESSAGE ), "Error Message is displaying properly", "Error Message is not displaying properly" );
            restoreAssignmentPage.closeErrorMessagePopup();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
