package com.savvas.sm.admin.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;

import io.restassured.response.Response;

public class ExportUtils extends EnvProperties {

    /**
     * To Split and Store the response csv data
     * 
     * @return
     * 
     * @throws IOException
     * 
     */
    public static List<Map<String, String>> splitCSVDataFromResponse( String response ) {
        List<Map<String, String>> keysAndValueList = new ArrayList<>();

        List<String> valueList = new ArrayList<>( Arrays.asList( response.split( "\n" ) ) );
        List<String> keys = Arrays.asList( valueList.get( 0 ).split( "," ) );

        valueList.remove( 0 );

        valueList.forEach( row -> {
            List<String> rowValues = Arrays.asList( row.split( "," ) );
            Map<String, String> keysAndValue = new HashMap<>();
            IntStream.range( 0, rowValues.size() ).forEach( itr -> {
                keysAndValue.put( keys.get( itr ), rowValues.get( itr ) );
            } );
            keysAndValueList.add( keysAndValue );
        } );

        return keysAndValueList;

    }

    /**
     * To hit the export csv API for Teacher - student Performance Report
     * 
     * @param headers
     * @param isGroupSelected
     * @param studentOrGroupIds
     * @param subject
     * @param Weeks
     * @param isCustomExport
     * @param selectedFields
     * 
     * @return
     */
    public static Response postTeacherStudentPerformanceReportCSV( Map<String, String> headers, boolean isGroupSelected, List<String> studentOrGroupIds, boolean isMath, List<String> assignmentIds, int weeks, boolean isCustomExport,
            List<String> selectedFields ) {
        Response response = null;
        try {
            String teacherId = headers.get( Constants.USERID_SM_HEADER );
            String orgId = headers.get( Constants.ORGID_SM_HEADER );
            headers.put( "Content-Type", "application/json" );
            headers.put( "Accept", "text/csv" );

            List<String> defaultSelectedFields = Arrays.asList( "fullName", "userName", "assignmentTitle", "organizationName", "teacherFirstName", "teacherLastName", "grade", "groupName", "ipmLevel", "ipmAttempts", "ipmCorrect", "ipmMin", "ipmPlaced",
                    "gain", "currentCourseLevel", "exercisesAttempts", "exercisesCorrect", "totalAudioRepeatsUsed", "totalGlossary", "totalHelp", "totalReportCardViews", "totalSkillsMastered", "totalSkillsAssessed", "totalTimeSpent", "totalSessions",
                    "criAttempts", "criCorrects" );

            String ReportGraphql = configProperty.getProperty( "AdminReportBFF" );
            AtomicReference<String> requestBody = new AtomicReference<>();

            String basePath = ( new File( "." ) ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "schemaJson" + File.separator + "report"
                    + File.separator;

            requestBody.set( SMUtils.convertFileToString( basePath + "postTeacherStudentPerformanceReportExportCSVRequestPayload.json" ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", orgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.teacherId", teacherId ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.isGroupSelected", isGroupSelected ) );
            if ( isGroupSelected ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.groupIds", studentOrGroupIds ) );
            } else {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.studentIds", studentOrGroupIds ) );
            }

            if ( isMath ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.subject", 1 ) );
                if ( !isCustomExport ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", defaultSelectedFields ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFields ) );
                }
            } else {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "subject", 2 ) );
                if ( !isCustomExport ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", defaultSelectedFields ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFields ) );
                }
            }
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.weeks", weeks ) );
            if ( !assignmentIds.isEmpty() ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.assignmentIds", assignmentIds ) );
            }

            String endPoint = "/export-csv";
            response = RestAssuredAPIUtil.POST( ReportGraphql + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    /**
     * To hit teacher-Student Performance Report BFF
     * 
     * @param header
     * @param isGroupSelected
     * @param studentOrGroupIds
     * @param isMath
     * @param assignmentIds
     * @param weeks
     * @param isIncludeAOD
     * @param isIncludePBS
     * @param isIncludePS
     */
    public void getSPRTeacherReportBFF( Map<String, String> headers, boolean isGroupSelected, List<String> studentOrGroupIds, int subjectId, List<String> assignmentIds, String language, int weeks, boolean isIncludeAOD, boolean isIncludePBS,
            boolean isIncludePS ) {

        String teacherId = headers.get( Constants.USERID_SM_HEADER );
        String orgId = headers.get( Constants.ORGID_SM_HEADER );
        headers.put( "Content-Type", "application/json" );
        String query = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getISPReportData(\\n    teacherId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n  isGroupSelected: %s\\n subject: %s\\n lang: \\\"%s\\\"\\n aod: %s\\n  pbs: %s\\n  ps: %s\\n  weeks: %s\\n studentIds: [{studentId}]\\n  groupIds: [{groupId}]\\n assignmentIds: [{assignmentId}]\\n ) {\\n    ispReportResponse {\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      totalNoOfAodRows\\n      totalNoOfPsRows\\n      totalNoOfStrandRows\\n      aodRows {\\n        firstName\\n        lastName\\n        fullName\\n        userName\\n        grade\\n        groupName\\n        personId\\n        assignmentUserId\\n        assignmentTitle\\n        cttypeName\\n        strandLevel\\n        skillObjectives\\n        skillMastery\\n        masteryStatusDate\\n        pearsonSkillObjectiveId\\n        formattedStrandLevel\\n        lo_REVIEW_TYPE_NAME\\n        catalogNum\\n      }\\n      psRows {\\n        firstName\\n        lastName\\n        fullName\\n        userName\\n        grade\\n        groupName\\n        personId\\n        assignmentUserId\\n        assignmentTitle\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipmStatusId\\n        ipmLevel\\n        proficiencyStatus\\n        ipmAttempts\\n        ipmCorrect\\n        k2ipmTotalAttempts\\n        k2ipmTotalCorrect\\n        ipmPlaced\\n        gain\\n        exercisesAttempts\\n        exercisesCorrect\\n        criAttempts\\n        criCorrects\\n        totalSkillsMastered\\n        totalSkillsAssessed\\n        totalHelp\\n        totalAudioRepeatsUsed\\n        totalReportCardViews\\n        totalGlossary\\n        totalTimeSpent\\n        ipmMin\\n        totalSessions\\n        totalIpCorrect\\n        totalIpAttempts\\n        totalPrerequisiteAttempts\\n        totalPrerequisiteCorrect\\n        aodskillCount\\n        asmtAssignerId\\n        formattedAssignedCourseLevel\\n        formattedCurrentCourseLevel\\n        formattedIpmLevel\\n        formattedGain\\n        formattedExercisesCorrect\\n        formattedExercisesAttempts\\n        exercisesPercentCorrect\\n        retentionIndex\\n        formattedSkillsMastered\\n        formattedSkillsAssessed\\n        skillsPercentCorrect\\n        formattedTotalTimeSpent\\n      }\\n      strandRows {\\n        firstName\\n        lastName\\n        fullName\\n        userName\\n        grade\\n        groupName\\n        personId\\n        assignmentUserId\\n        assignmentTitle\\n        cttypeId\\n        cttypeName\\n        strandLevel\\n        strandCorrect\\n        strandAttempts\\n        strandToppedOut\\n        fluencyStatus\\n        grammarStatus\\n        formattedStrandLevel\\n        formattedStrandCorrect\\n        formattedStrandAttempts\\n        percentSkillsMastered\\n        strandDescription\\n        loMasteredCount\\n        loNotMasteredCount\\n        strandOn\\n        strandStatus\\n        strandType\\n      }\\n    }\\n  }\\n}\\n\"}";

        query = String.format( query, teacherId, orgId, isGroupSelected, subjectId, language, isIncludeAOD, isIncludePBS, isIncludePS, weeks );

        if ( isGroupSelected ) {
            query = query.replace( "{groupId}", studentOrGroupIds.toString().replace( "[", "" ).replace( "]", "" ) );
            query = query.replace( "{studentId}", "" );
        } else {
            query = query.replace( "{studentId}", studentOrGroupIds.toString().replace( "[", "" ).replace( "]", "" ) );
            query = query.replace( "{groupId}", "" );
        }
    }

}
