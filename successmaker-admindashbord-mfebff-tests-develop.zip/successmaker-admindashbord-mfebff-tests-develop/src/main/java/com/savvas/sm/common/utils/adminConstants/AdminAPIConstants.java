package com.savvas.sm.common.utils.adminConstants;

import java.util.Arrays;
import java.util.List;

public interface AdminAPIConstants {
    // Constants - API
    public static String ORGID = "org-id";
    public static String USERID = "user-id";
    public static String AUTHORISATION = "Authorization";
    public static String BEARER = "Bearer ";

    // HolidayScheduler
    public static String START_DATE = "startDate";
    public static String END_DATE = "endDate";
    public static String DESCRIPTION = "description";
    public static String HOLIDAY = "holiday";
    String EMPTY_USERID = "Invalid value passed for userId";
    String EMPTY_ORGID = "Invalid value passed for organizationId";
    String DATE = "date";
    String DISTRICT_ADMIN = "District Admin";
    String SCHOOL_ADMIN = "School Admin";
    String SUB_DISTRICT_ADMIN = "Subdistrict Admin";
    String SAVVAS_ADMIN = "Savvas Admin";
    
    String SUBROLETYPE = "subRoletype";
    String SUBROLETYPE_DISTRICT_ADMIN = "District Admin";
    String SUBROLETYPE_SUBDISTRICT_ADMIN = "Subdistrict Admin";
    String SUBROLETYPE_SCHOOL_ADMIN = "School Admin";
    String NO_HOLIDAY_MESSAGE = "Holiday Data Not Found";
    String CA_ROLE = "Customer Admin";
    String SA_ROLE = "Savvas Admin";
    String INVALID_MESSAGE_FOR_ROLE = "Invalid value passed for role";
    String INVALID_MESSAGE_FOR_WRONG_ORGID = "\"Organization not found in Solar Search\"";
    String ZERO_STATE_RESTORE_ASSIGNMENT = "No Assignments found to restore";
    String ACCESS_DENIED_MESSAGE = "Access denied! You don't have permission for this action!";

    // ShareCourse
    public static String ORGANIZATION_ID = "organizationId";
    public static String COURSE_ID = "courseId";
    String ORGANIZATION_NAME = "organizationName";
    String PARENT_ORGANIZATION_ID = "parentOrganizationId";

    // Constants - Endpoints
    public static String GET_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/getHolidays";
    public static String PUT_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/addHolidays";
    public static String DELETE_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/deleteHolidays";
    public static String GET_CHILD_ORGANIZATIONS = "/lms/web/api/v1/organizations/getChildren";
    public static String CHILD_ORGANIZATION_FROM_ORGSERVICE = "/org-service/v1/organizations/{organizationId}/childtree";
    public static String GET_SHARE_COURSE = "/lms/web/api/v1/sharedCourse";
    public static String GET_SHARED_COURSE = "/lms/web/api/v1/sharedCourse";

    String GET_ORGANIZATION_FLAGS = "/lms/web/api/v1/organizations/getOrganizationFlags";
    String POST_ORGANIZATION_FLAGS = "/lms/web/api/v1/organizations/setOrganizationFlags";

    String GET_SUCCESS_MSG = "Operation succeeded!";
    String AUTHENTICATION_FAILED = "Authentication Failed";
    String PARAMETER_MISSING = "Required String[] parameter 'flags' is not present";
    String ORG_ID_MISSING = "Missing request header 'org-id' for method parameter of type String";
    String ACCESS_DENIED = "Access is denied";
    String FLAGS_CREATED = "Flags created successfully";
    String MISSING_BODY = "Required request body is missing: public com.savvas.core.rest.RestResponse com.savvas.organization.web.OrganizationController.setOrganizationFlags(java.lang.String,com.pst.lms.dto.OrgSettings) throws java.lang.Exception";
    String INVALID_BODY_VALUE = "Values for Organization Settings are invalid";
    String VALID_RESPONSE_MSG = "Message response is correct and valid";
    String INVALID_RESPONSE_MSG = "Message is not expected value and invalid";

    String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
    String UNAUTHORIZED_401 = "401: Unauthorized";
    String FORBIDDEN_403 = "403: Forbidden";
    String NOT_FOUND_404 = "404: Not Found";
    String BAD_REQUEST_400 = "400: Bad Request";
    String INTERNAL_SERVERZ_ERROR_500 = "500: Internal Server Error";
    String CONSTRAINT_VIOLATION = "CONSTRAINT VIOLATION - DUPLICATE RECORDS";
    String FAILED = "failed";
    String INVALID_MESSAGE_FOR_USERID = "Invalid value passed for userId";
    String INVALID_MESSAGE_FOR_ORGID = "Invalid value passed for organizationId";

    // AssignmentAPI
    public static String TEACHER_ID = "teacherID";
    public static String ORG_ID = "orgID";
    public static String STUDENT_RUMBA_IDS = "studentRumbaIds";
    public static String STUDENT_RUMBA_GRADE_IDS = "studentRumbaIds_Grades";
    public static String STATUS = "status";

    //Attributes
    public static String USERS_TYPE = "users";
    public static String GROUPS_TYPE = "groups";
    public static String ASSIGNMENT_COURSE_ID = "courseID";
    public static String ASSIGNMENT_USER_ID = "assignmentUserID";

    public static String CREATE_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/{courseID}/assign";
    public static String DELETE_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courseassignments/{contentbaseId}";
    public static String ASSIGN_MULTIPLE_ASSIGNMENTS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/assign";
    public static String COURSE_IDS = "courseIds";

    public static String GRADE = "grade";
    public static String BIRTHDAY = "birthday";
    public static String STUDENT_IDENTIFICATION_NUMBER = "studentIdentificationNumber";
    public static String USER_PASSWORD = "userPassword";
    public static String CONFIRM_PASSWORD = "confirmPassword";
    public static String ETHINICITY = "ethnicity";
    public static String SPECIAL_SERVICES = "specialServices";
    public static String HAS_DISABILITY = "hasDisability";
    public static String HAS_ECONOMIC_DISADVANTAGE = "hasEconomicDisadvantage";
    public static String HAS_ENGLISH_PROFICIENCY = "hasEnglishProficiency";
    public static String ISMIGRANT = "isMigrant";
    public static String SCHOOLID = "schoolId";
    public static String PERSONID = "personId";
    public static String GENDER_FIELD = "gender";

    // Audit Histroy
    String DELETED_BY = "deletedBy";
    String ASSIGNMENT_TITLE = "assignmentTitle";
    String STUDENT_OR_GROUP_NAME = "studentOrGroupName";
    String RECORD_TYPE = "recordType";
    String ASSIGNED_BY = "assignedBy";
    String COURSE_NAME = "courseName";
    String DELETED_DATE = "deletedDate";
    String ZERO_STATE_AUDIT_HISTORY = "No assignment audit history found";
    String INVALID_SELECTED_ORG = "Invalid value passed for selectedOrgId";

    List<String> GRADES = Arrays.asList( "grade_k", "grade_1", "grade_1", "grade_2", "grade_3", "grade_4", "grade_4", "grade_5", "grade_6", "grade_7", "grade_8", "grade_9", "grade_10", "grade_11", "grade_12" );

    //Admin's Organization Performance
    String ORG_STUDENTS_MAP = "orgStudentsMap";
    String LAST_WEEK_START_DATE = "lastWeekStartDate";
    String LAST_WEEK_END_DATE = "lastWeekEndDate";
    String THIS_WEEK_START_DATE = "thisWeekStartDate";
    String THIS_WEEK_END_DATE = "thisWeekEndDate";

}
