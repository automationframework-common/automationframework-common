package com.savvas.sm.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.util.DevToolsUtils;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.Dashboard;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;

import LSTFAI.customfactories.EventFiringWebDriver;

public class OrganizationDropdownTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String flexSchool;
    private String mathSchool;
    private String orgId;
    private String configGraphQL;
    
    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String schoolAdminDetails = null;
    private String districtId = null;
    private String subDistrictAdminDetails = null;
    public static String subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
    public static String subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );

    
    @BeforeClass(alwaysRun=true)
    public void initTest() throws Exception {
    	districtId = configProperty.getProperty( "district_ID" );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        configGraphQL = "https://sm-admin-dashboard-bff-srv-stack-dev.smdemo.info/graphql";
        
        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "0077" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        
         //Sub-District Admin Creation
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "98" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        
        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "100" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        
        
    }

    //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the Organisation drop down", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","smoke_test_case","mock" }, priority = 1 )
    public void tcSMOrganizationDropdown001(ITestContext context) throws Exception {
        // Get driver
    	
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
		
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tc001: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecdistrictadmin99@nightlynextbasic",
    					"testing123$");

    			AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgList2.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			dashBoardPage.navigateToDashboardPage();
    			
    			dashBoardPage.expandOrganizationDropdown();
                Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expandable", "Organization dropdown is not expandable" );
                Log.testCaseResult();
                
                //Get the org list
                List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
                
                int organizationDropdownListCountDashBoardUI = organizations.size();
                
                Log.assertThat(organizationDropdownListCountDashBoardUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
                
              //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.ALL_ORGANIZATIONS_SELECTED, organizations.size() ) ), "All organizations are selcted as default",
                        "All organizations are not selcted as default" );
                Log.testCaseResult();
                
              //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
                SMUtils.logDescriptionTC( "SMK-15683 :Verify the ALL option is present in the Organisation drop down in the dashboard page" );
                
                //Collapase dropdown
                dashBoardPage.collapseOrganizationDropdown();
                // verifying the Select All label
                Log.assertThat( dashBoardPage.getSelectAllLabel().equalsIgnoreCase( String.format( Dashboard.ALL_ORGANIZATION, organizations.size() ) ), "ALL (" + organizations.size() + ") is displayed properly under the organization dropdown",
                        "ALL (" + organizations.size() + ") is not diplayed properly under the organization dropdown" );
                Log.testCaseResult();
                
                SMUtils.logDescriptionTC( "SMK-15680: Verify the Organisation drop down is a multiselect drop down in the dashboard page" );
                SMUtils.logDescriptionTC( "SMK-15685 :Verify the user is able to select one or more organisations from the Organisation drop down in the dashboard page." );
                //Collapase dropdown
                dashBoardPage.collapseOrganizationDropdown();
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                dashBoardPage.enterTextInSearchTextBox(organizations.get(1));
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList(organizations.get(1) ));
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( organizations.get(1) ), "User can able to select single organizations.", "User cannot able to select single organizations." );
                Log.testCaseResult();

    			RequestMockUtils.closeMock(tools);

        	} else {
        		Log.testCaseInfo( "tcSMOrganizationDropdown001: Verify the Organisation drop down. <small><b><i>[" + browser + "]</b></i></small>" );
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "SMK-15679 : Verify the Organisation drop down is present in the dashboard page" );
            SMUtils.logDescriptionTC( "SMK-15681 :Verify the Organisation drop down is expandable in the dashboard page" );
            // expand organization dropdown
            dashBoardPage.expandOrganizationDropdown();
            Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expanded", "Organization dropdown is not expanded" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15682 :Verify the default selection in the Organisation drop down in the dashboard page" );
            SMUtils.logDescriptionTC( "SMK-15686 :Verify the organisations listed in the Organisation drop down in the dashboard page" );
            // get organization from organizations dropdown
            List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
            
            //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
            Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.ALL_ORGANIZATIONS_SELECTED, organizations.size() ) ), "All organizations are selcted as default",
                    "All organizations are not selcted as default" );
            Log.testCaseResult();

            //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
            SMUtils.logDescriptionTC( "SMK-15683 :Verify the ALL option is present in the Organisation drop down in the dashboard page" );
            
            //Collapase dropdown
            dashBoardPage.collapseOrganizationDropdown();
            // verifying the Select All label
            Log.assertThat( dashBoardPage.getSelectAllLabel().equalsIgnoreCase( String.format( Dashboard.ALL_ORGANIZATION, organizations.size() ) ), "ALL (" + organizations.size() + ") is displayed properly under the organization dropdown",
                    "ALL (" + organizations.size() + ") is not diplayed properly under the organization dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15680: Verify the Organisation drop down is a multiselect drop down in the dashboard page" );
            SMUtils.logDescriptionTC( "SMK-15685 :Verify the user is able to select one or more organisations from the Organisation drop down in the dashboard page." );
            //Collapase dropdown
            dashBoardPage.collapseOrganizationDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox(organizations.get(1));
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList(organizations.get(1) ));
            Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( organizations.get(1) ), "User can able to select single organizations.", "User cannot able to select single organizations." );

            // trying to select multi organizations
            if ( organizations.size() > 1 ) {
            	dashBoardPage.collapseOrganizationDropdown();
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                dashBoardPage.enterTextInSearchTextBox(flexSchool);
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool));
                Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().size() >= 2, "User can able to select multiple organizations.", "User cannot able to select multiple organizations." );
            } else {
                Log.message( "This admin having less than one organization" );
            }
            Log.testCaseResult();
        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
  //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the functionality of ALL option present in the Organisation drop down in the dashboard page", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","smoke_test_case","mock"  }, priority = 2 )
    public void tcSMOrganizationDropdown002(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tc002: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecdistrictadmin99@nightlynextbasic",
    					"testing123$");

    			AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgList2.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			dashBoardPage.navigateToDashboardPage();
    			
    			dashBoardPage.expandOrganizationDropdown();
                Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expandable", "Organization dropdown is not expandable" );
                Log.testCaseResult();
                
                //Get the org list
                List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
                
                int organizationDropdownListCountDashBoardUI = organizations.size();
                
                Log.assertThat(organizationDropdownListCountDashBoardUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
                
                dashBoardPage.collapseOrganizationDropdown();
                
             // Uncheck the All organization checkbox
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().isEmpty(), "User can able to Deselect all the organization using All option checkbox.", "User cannot able to Deselect all the organization using All option checkbox." );
                
                //Collapase org dropdown
                dashBoardPage.collapseOrganizationDropdown();
                // check the All organization checkbox
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().size() == organizations.size(), "User can able to Select all the organization using All option checkbox.",
                        "User cannot able to select all the organization using All option checkbox." );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "SMK-15687: Verify the Search Bar is present in the Organisation drop down in the dashboard page" );
                SMUtils.logDescriptionTC( "SMK-15688 :Verify the default text in the Search Bar in the Organisation drop down in the dashboard page" );
                Log.assertThat( dashBoardPage.getPlaceHolderForSearchTextBox().equalsIgnoreCase( Dashboard.SEARCH ), Dashboard.SEARCH + "is displayed properly in the search text box",
                        Dashboard.SEARCH_ORGANIZATIONS + "is not displayed properly in the search text box" );
                Log.testCaseResult();
                
              	RequestMockUtils.closeMock(tools);

        	} else {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "SMK-15684 : Verify the functionality of ALL option present in the Organisation drop down in the dashboard page" );
            // Uncheck the All organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().isEmpty(), "User can able to Deselect all the organization using All option checkbox.", "User cannot able to Deselect all the organization using All option checkbox." );
            List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
            
            //Collapase org dropdown
            dashBoardPage.collapseOrganizationDropdown();
            // check the All organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().size() == organizations.size(), "User can able to Select all the organization using All option checkbox.",
                    "User cannot able to select all the organization using All option checkbox." );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "SMK-15687: Verify the Search Bar is present in the Organisation drop down in the dashboard page" );
            SMUtils.logDescriptionTC( "SMK-15688 :Verify the default text in the Search Bar in the Organisation drop down in the dashboard page" );
            Log.assertThat( dashBoardPage.getPlaceHolderForSearchTextBox().equalsIgnoreCase( Dashboard.SEARCH ), Dashboard.SEARCH + "is displayed properly in the search text box",
                    Dashboard.SEARCH_ORGANIZATIONS + "is not displayed properly in the search text box" );
            Log.testCaseResult();

        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    //Multi Select Org Option which is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the functionality of ALL option present in the Organisation drop down in the dashboard page", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","smoke_test_case","mock"  }, priority = 3 )
    public void tcSMOrganizationDropdown003(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tc003: Verify the organization list count matches with the mocked organiczation list count when we use single organization and login as district admin <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecdistrictadmin99@nightlynextbasic",
    					"testing123$");
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgList.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			 AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
     			
     			List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();

     			int organizationDropdownListCountUI = allOrganizationsfromdropdown.size();

     			Log.assertThat(organizationDropdownListCountUI == mockDataOrganizationCount,
     					"OrganizationDropdownList count matched with UI after mocking the data",
     					"Org count didn't matched");
     			
     			dashBoardPage.navigateToDashboardPage();
                 
                 SMUtils.logDescriptionTC( "Verify the Organisation drop down is not present in the dashboard page" );
                 
                 Log.assertThat(dashBoardPage.isOrganizationDropdownDisplayed(), " Organisation drop down is present ", "Organisation drop down is not present");  
        
                 Log.testCaseResult();
           
                
              	RequestMockUtils.closeMock(tools);

        	} else {
                // Login into SM using admin credential
                AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
                SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );

                SMUtils.logDescriptionTC( "SMK-15684 : Verify the functionality of ALL option present in the Organisation drop down in the dashboard page" );
                // Uncheck the All organization checkbox
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().isEmpty(), "User can able to Deselect all the organization using All option checkbox.", "User cannot able to Deselect all the organization using All option checkbox." );
                List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
                
                //Collapase org dropdown
                dashBoardPage.collapseOrganizationDropdown();
                // check the All organization checkbox
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().size() == organizations.size(), "User can able to Select all the organization using All option checkbox.",
                        "User cannot able to select all the organization using All option checkbox." );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "SMK-15687: Verify the Search Bar is present in the Organisation drop down in the dashboard page" );
                SMUtils.logDescriptionTC( "SMK-15688 :Verify the default text in the Search Bar in the Organisation drop down in the dashboard page" );
                Log.assertThat( dashBoardPage.getPlaceHolderForSearchTextBox().equalsIgnoreCase( Dashboard.SEARCH ), Dashboard.SEARCH + "is displayed properly in the search text box",
                        Dashboard.SEARCH_ORGANIZATIONS + "is not displayed properly in the search text box" );
                Log.testCaseResult();
            	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
  //Search Option which is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the functionality of Search Bar", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","mock" }, priority = 4 )
    public void tcSMOrganizationDropdown004(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);

        Log.testCaseInfo( "tcSMOrganizationDropdown004: Verify the functionality of Search Bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tc004: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecdistrictadmin99@nightlynextbasic",
    					"testing123$");

    			AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgList2.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			dashBoardPage.navigateToDashboardPage();
    			
    			dashBoardPage.expandOrganizationDropdown();
                Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expandable", "Organization dropdown is not expandable" );
                Log.testCaseResult();
                
                //Get the org list
                List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
                
                int organizationDropdownListCountDashBoardUI = organizations.size();
                
                Log.assertThat(organizationDropdownListCountDashBoardUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
                Log.testCaseResult();
                
              	RequestMockUtils.closeMock(tools);

        	} else {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );
            dashBoardPage.expandOrganizationDropdown();
            List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
            SMUtils.logDescriptionTC( "SMK-15689 :Verify the functionality of Search Bar with valid organisation name in the checked state in the Organisation drop down in the dashboard page" );
            dashBoardPage.enterTextInSearchTextBox(flexSchool );
            // get the sorted/listed organizations
            List<String> sortedOrganizations = dashBoardPage.getAllOrgFromDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.contains(flexSchool ) ),
                    "User can able to see the relevant results for the Organsiation name(s) searched.", "User cannot able to see the relevant results for the Organsiation name(s) searched." );
            // uncheck all the sorted organizations
            dashBoardPage.selectOrganizationsFromOrgDropdown( sortedOrganizations );
            dashBoardPage.clickCancelIconInSearchTextBox();
            if ( organizations.size() - sortedOrganizations.size() > 1 ) {
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.SELECTED_ORGANIZATIONS_COUNT, organizations.size() - sortedOrganizations.size() ) ),
                        "The drop down header is displayed as (Updated Org Count) Organizations Selected", "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            } else {
                Log.assertThat( !dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase(flexSchool), "The drop down header is displayed as (Updated Org Count) Organizations Selected",
                        "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            }
            Log.testCaseResult();
            //Collapase org dropdown
            dashBoardPage.collapseOrganizationDropdown();
            SMUtils.logDescriptionTC( "SMK-15690 :Verify the functionality of Search Bar with valid organisation name in the unchecked state in the Organisation drop down in the dashboard page" );
            // uncheck the All organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();

            dashBoardPage.enterTextInSearchTextBox(flexSchool );
            // get the sorted/listed organizations
            sortedOrganizations = dashBoardPage.getAllOrgFromDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.contains( flexSchool ) ),
                    "User can able to see the relevant results for the Organsiation name(s) searched.", "User cannot able to see the relevant results for the Organsiation name(s) searched." );

            // uncheck all the sorted organizations
            dashBoardPage.selectOrganizationsFromOrgDropdown( sortedOrganizations );
            dashBoardPage.clickCancelIconInSearchTextBox();
            if ( sortedOrganizations.size() > 1 ) {
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.SELECTED_ORGANIZATIONS_COUNT, sortedOrganizations.size() ) ),
                        "The drop down header is displayed as (Updated Org Count) Organizations Selected", "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            } else {
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( "SM Auto School SME187 - Flex" ), "The drop down header is displayed as (Updated Org Count) Organizations Selected",
                        "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15692 :Verify the functionality of Search Bar with invalid organisation name in the unchecked state in the Organisation drop down in the dashboard page" );
            // uncheck all organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            // check all organizations checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( Dashboard.INVALID_ORGNAME );
            Log.assertThat( dashBoardPage.getNoOrganizationFoundMessage().equalsIgnoreCase( Dashboard.NO_DATA_FOUND ), "User can able to see the error message(" + Dashboard.NO_DATA_FOUND + ")in the organization displaying pane.",
                    "User cannot able to see the error message(" + Dashboard.NO_DATA_FOUND + ")in the organization displaying pane." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15691 :Verify the functionality of Search Bar with invalid organisation name in the checked state in the Organisation drop down in the dashboard page" );
            // uncheck all organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( Dashboard.INVALID_ORGNAME );
            Log.assertThat( dashBoardPage.getNoOrganizationFoundMessage().equalsIgnoreCase( Dashboard.NO_DATA_FOUND ), "User can able to see the error message(" + Dashboard.NO_DATA_FOUND + ")in the organization displaying pane.",
                    "User cannot able to see the error message(" + Dashboard.NO_DATA_FOUND + ")in the organization displaying pane." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();
        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
  //Search Option which is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the functionality of Search Bar", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","smoke_test_case","mock"  }, priority = 5 )
    public void tcSMOrganizationDropdown005(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);
        
        Log.testCaseInfo( "tcSMOrganizationDropdown005: Verify the functionality of Search Bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tcSMOrganizationDropdown005: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecdistrictadmin99@nightlynextbasic",
    					"testing123$");

    			AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgList2.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			dashBoardPage.navigateToDashboardPage();
    			
    			dashBoardPage.expandOrganizationDropdown();
                Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expandable", "Organization dropdown is not expandable" );
                Log.testCaseResult();
                
                //Get the org list
                List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
                
                int organizationDropdownListCountDashBoardUI = organizations.size();
                
                Log.assertThat(organizationDropdownListCountDashBoardUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
                
                SMUtils.logDescriptionTC( "SMK-15693 :Verify searching of organization with minimum characters in the Organization drop down in the dashboard page." );
                String singleCharacter = String.valueOf( organizations.get( organizations.size() - 1 ).charAt( organizations.get( organizations.size() - 1 ).length() - 1 ) );
                dashBoardPage.enterTextInSearchTextBox( singleCharacter );
                // get the sorted/listed organizations
                List<String> sortedOrganizations = dashBoardPage.getAllOrgFromDropdown();
                Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( singleCharacter.toLowerCase() ) ), "User can able to see the relevant search result with minimum of 1 character.",
                        "User cannot able to see the relevant search result with minimum of 1 character." );
                dashBoardPage.clickCancelIconInSearchTextBox();
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "SMK-15695 :Verify the search bar is case sensitive in Organization drop down in dashboard page" );
                dashBoardPage.enterTextInSearchTextBox( singleCharacter.toUpperCase() );
                sortedOrganizations = dashBoardPage.getAllOrgFromDropdown();
                Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( singleCharacter.toLowerCase() ) ),
                        "User can be able to see the organizations listed in the display pane with relevant search result irrespective to case sensitivity.",
                        "User cannot be able to see the organizations listed in the display pane with relevant search result irrespective to case sensitivity." );
                dashBoardPage.clickCancelIconInSearchTextBox();
                Log.testCaseResult();
                
              	RequestMockUtils.closeMock(tools);

        	} else {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );
            dashBoardPage.expandOrganizationDropdown();
            List<String> organizations = dashBoardPage.getAllOrgFromDropdown();

            SMUtils.logDescriptionTC( "SMK-15693 :Verify searching of organization with minimum characters in the Organization drop down in the dashboard page." );
            String singleCharacter = String.valueOf( organizations.get( organizations.size() - 1 ).charAt( organizations.get( organizations.size() - 1 ).length() - 1 ) );
            dashBoardPage.enterTextInSearchTextBox( singleCharacter );
            // get the sorted/listed organizations
            List<String> sortedOrganizations = dashBoardPage.getAllOrgFromDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( singleCharacter.toLowerCase() ) ), "User can able to see the relevant search result with minimum of 1 character.",
                    "User cannot able to see the relevant search result with minimum of 1 character." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15695 :Verify the search bar is case sensitive in Organization drop down in dashboard page" );
            dashBoardPage.enterTextInSearchTextBox( singleCharacter.toUpperCase() );
            sortedOrganizations = dashBoardPage.getAllOrgFromDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( singleCharacter.toLowerCase() ) ),
                    "User can be able to see the organizations listed in the display pane with relevant search result irrespective to case sensitivity.",
                    "User cannot be able to see the organizations listed in the display pane with relevant search result irrespective to case sensitivity." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15696 : Verify the search bar allows to enter alphanumeric characters in the search bar of Organization drop down in the dashboard page." );
            SMUtils.logDescriptionTC( "SMK-15697 :Verify the search bar allows to enter special characters in the search bar of Organization drop down in the dashboard page." );
            SMUtils.logDescriptionTC( "SMK-15694 : Verify the search bar allows the double space as input in the Organization listing drop down in dashboard page" );
            dashBoardPage.enterTextInSearchTextBox( Dashboard.ORG_NAME_SPECIALCHARACTER );
            Log.assertThat( dashBoardPage.getEnteredTextInSearchTextBox().equals( Dashboard.ORG_NAME_SPECIALCHARACTER ), "User can able to enter the special characters in the search bar ",
                    "User cannot able to enter the special characters in the search bar " );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();
        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
  //Apply Selection Option is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the functionality of Apply selection(s) button", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","mock" }, priority = 6 )
    public void tcSMOrganizationDropdown006(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);
       
        Log.testCaseInfo( "tcSMOrganizationDropdown006: Verify the functionality of Apply selection(s) button. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tcSMOrganizationDropdown006: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecdistrictadmin99@nightlynextbasic",
    					"testing123$");

    			AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgList2.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			dashBoardPage.navigateToDashboardPage();
    			
    			dashBoardPage.expandOrganizationDropdown();
                Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expandable", "Organization dropdown is not expandable" );
                Log.testCaseResult();
                
                //Get the org list
                List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
                
                int organizationDropdownListCountDashBoardUI = organizations.size();
                
                Log.assertThat(organizationDropdownListCountDashBoardUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
                SMUtils.logDescriptionTC( "SMK-15699 :Verify the Apply Selection(s) button is disabled by default in the dashboard page." );
                Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is disabled by default.", "Apply Selection(s) button is enabled by default." );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "SMK-15700 : Verify the functionality of Apply Selection(s) button in the dashboard page." );
                dashBoardPage.expandOrganizationDropdown();
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ) ) );
                Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is enabled after selecting the organization", "Apply Selection(s) button is disabled after selecting the organization" );
                Log.testCaseResult();
                
              	RequestMockUtils.closeMock(tools);

        	} else {
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "SMK-15699 :Verify the Apply Selection(s) button is disabled by default in the dashboard page." );
            Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is disabled by default.", "Apply Selection(s) button is enabled by default." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15700 : Verify the functionality of Apply Selection(s) button in the dashboard page." );
            dashBoardPage.expandOrganizationDropdown();
            List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ) ) );
            Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is enabled after selecting the organization", "Apply Selection(s) button is disabled after selecting the organization" );
            Log.testCaseResult();
        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( description = "Verify if no organization dropdown is displaying in the admin dashboard when login as School admin", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","smoke_test_case","mock" }, priority = 7 )
    public void tcSMOrganizationDropdown007(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);

        Log.testCaseInfo( "tcSMOrganizationDropdown007: Verify if no organization dropdown is displaying in the admin dashboard when login as School admin <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tcSMOrganizationDropdown007: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecschooladmincustom051@nightlynextbasic",
    					"testing123$");
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgListSchoolAdmin.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
    			AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();

    			int organizationDropdownListCountUI = allOrganizationsfromdropdown.size();

    			Log.assertThat(organizationDropdownListCountUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
    			
    			dashBoardPage.navigateToDashboardPage();
                
                SMUtils.logDescriptionTC( "Verify the Organisation drop down is not present in the dashboard page" );
                
                Log.assertThat(!dashBoardPage.isOrganizationDropdownDisplayed(), " Organisation drop down is not present ", "Organisation drop down is present");  
       
                Log.testCaseResult();
                
              	RequestMockUtils.closeMock(tools);

        	} else {
        	 username = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
             
            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the Organisation drop down is not present in the dashboard page" );
  
            Log.assertThat(!dashBoardPage.isOrganizationDropdownDisplayed(), " Organisation drop down is not present ", "Organisation drop down is present");  
   
            Log.testCaseResult();
        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
  //Apply Selection Option is expected to be reverted back hence not deleting these codes
    @Test ( description = "Verify the functionality of Apply selection(s) button", groups = { "SMK-51098", "adminDashboard", "organizationDropdown","mock" }, priority = 8 )
    public void tcSMOrganizationDropdown008(ITestContext context) throws Exception {
    	List<String> includedGroups = context.getCurrentXmlTest().getIncludedGroups();
		Log.message(includedGroups.toString());
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        EventFiringWebDriver chromedriver = new EventFiringWebDriver(driver);
       
        try {
        	if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
        		Log.testCaseInfo(
        				"tcSMOrganizationDropdown008: Verify the organization list count matches with the mocked organiczation list count when we login as subdistrict admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
        		Log.testCaseInfo( "tcSMOrganizationDropdown008: Verify the functionality of Apply selection(s) button when we login as subdisctrict admin <small><b><i>[" + browser + "]</b></i></small>" );

        		AdminLauncherPage smLoginPage = new AdminLauncherPage(chromedriver, smUrl).get();
    			SMDashBoardPage dashBoardPage = smLoginPage.loginToSM("smautoexecsubdistrictadmin99@nightlynextbasic",
    					"testing123$");
    			
    			String json = DevToolsUtils.readJsonResponse("MockOrgListSubDistrict.json");
    			Log.message(json);
    			DevTools tools = RequestMockUtils.setResponse(driver, configGraphQL, "OrganizationList", "post",
    					json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());

    			JSONParser parser = new JSONParser();
    			JSONObject jsonObject = (JSONObject) parser.parse(json);
    			JSONObject jsonObjectData = (JSONObject) jsonObject.get("data");
    			JSONArray jsonArrayGetOrganizationList = (JSONArray) jsonObjectData.get("getOrganizationList");
    			int mockDataOrganizationCount = jsonArrayGetOrganizationList.size();
    			
                AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
    			
    			List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();

    			int organizationDropdownListCountUI = allOrganizationsfromdropdown.size();

    			Log.assertThat(organizationDropdownListCountUI == mockDataOrganizationCount,
    					"OrganizationDropdownList count matched with UI after mocking the data",
    					"Org count didn't matched");
    			
    			dashBoardPage.navigateToDashboardPage();
                
                SMUtils.logDescriptionTC( "Verify the Organisation drop down is not present in the dashboard page" );
                
                Log.assertThat(!dashBoardPage.isOrganizationDropdownDisplayed(), " Organisation drop down is not present ", "Organisation drop down is present");  
       
                Log.testCaseResult();
                
              	RequestMockUtils.closeMock(tools);

        	} else {
        		Log.testCaseInfo( "tcSMOrganizationDropdown008: Verify the functionality of Apply selection(s) button. <small><b><i>[" + browser + "]</b></i></small>" );

            // Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME ), password );

            SMUtils.logDescriptionTC( "SMK-15699 :Verify the Apply Selection(s) button is disabled by default in the dashboard page." );
            Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is disabled by default.", "Apply Selection(s) button is enabled by default." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15700 : Verify the functionality of Apply Selection(s) button in the dashboard page." );
            dashBoardPage.expandOrganizationDropdown();
            List<String> organizations = dashBoardPage.getAllOrgFromDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ) ) );
            Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is enabled after selecting the organization", "Apply Selection(s) button is disabled after selecting the organization" );
            Log.testCaseResult();
        	}

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
