package com.savvas.sm.admin.ui.tests.SmokeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.Dashboard;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.FixupFunction;

public class DashboardSmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtAdminDetails;
    private String districtId;
    private String schoolName;
    private String teacherDetails;
    private String districtAdminUserName;
    private String districtAdminUserId;
    private String teacherId;
    private String teacherUsername;
    private String teacherOrgId;
    private String studentDetails;
    private List<String> courseIDs = new ArrayList<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting district admin details from RBS Datasetup
        districtAdminUserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );

        // Getting teacher details
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( schoolName );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = RBSDataSetup.organizationIDs.get( schoolName );
        studentDetails = RBSDataSetup.getMyStudent( schoolName, teacherUsername );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolName ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        // Assigning an assignment
        courseIDs.add( AssignmentAPIConstants.MATH );
        courseIDs.add( AssignmentAPIConstants.READING );

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) ), courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        //Creating teacher and student for subdistrict school
        String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
        String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

        //creating student
        String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
        String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        //Assigning the assignment
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        //assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), courseIDs );
        Log.message( assignAssignment.toString() );

        //course Execution - District Teacher
        executeCourse( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), AssignmentAPIConstants.MATH_COURSE, true );
        executeCourse( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), AssignmentAPIConstants.READING_COURSE, false );

        //course Execution - Sub-District Teacher
        executeCourse( subdistrictSchoolStudent, AssignmentAPIConstants.READING_COURSE, false );
        executeCourse( subdistrictSchoolStudent, AssignmentAPIConstants.MATH_COURSE, true );

        //Running fixup queries
        FixupFunction.executeFixupFunctions( teacherOrgId );
        Log.message( "Sub-district org id if " + RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        FixupFunction.executeFixupFunctions( RBSDataSetup.schoolUnderSubDistrict_SchoolId );

    }

    @Test ( description = "Verify all the widgets in admin dashboard for district admin ", groups = { "smoke_test_case", "Admin_TC01", "Dashboard" }, priority = 1 )
    public void tcSMAdminDashboardSmoke001() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAdminDashboard001: Verify all the widgets in admin dashboard for district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( districtAdminUserName, password );

            //select organization in organization dropdown
            dashBoardPage.selectOrganizationsFromSingleSelectOrgDropdown( schoolName );

            SMUtils.logDescriptionTC( "Verify Performance Report widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.PERFORMANCE_REPORT ), "Performance report header is present in the admin dashboard page", "Performance report header is not present in the admin dashboard page" );

            dashBoardPage.expandSubjectDropdown();
            Log.assertThat( dashBoardPage.getOptionsInSubjectDropdown().equals( Dashboard.SUBJECTS ), "Math and Reading are present in the subject dropdown", "Math and Reading are not present in the subject dropdown" );

            Log.assertThat( dashBoardPage.getXAxisLabel().equalsIgnoreCase( Dashboard.X_AXIS_LABEL ), "Course Level heading is displayed in x-axis of the graph in Performance Report",
                    "Course Level heading is not displayed in x-axis of the graph in Performance Report" );

            Log.assertThat( dashBoardPage.getXAxisIntervals().equals( Dashboard.X_AXIS_INTERVALS ), "x axis intervals are displayed properly in Performance report", "x axis intervals are not displayed properly in Performance report" );

            Log.assertThat( dashBoardPage.getYAxisLabel().equalsIgnoreCase( Dashboard.Y_AXIS_LABEL ), "Grade heading is displayed in x-axis of the graph in Performance Report",
                    "Grade heading is not displayed in x-axis of the graph in Performance Report" );

            Log.assertThat( dashBoardPage.getYAxisIntervals().equals( Dashboard.Y_AXIS_INTERVALS ), "y axis intervals are displayed properly in Performance report", "y axis intervals are not displayed properly in Performance report" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Organization performance this week widget is present in admin dashboard" );

            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.ORGANIZATION_PERFORMANCE_THIS_WEEK ), "orgainzation performance this week is present in the admin dashboard page",
                    "orgainzation performance this week is not present in the admin dashboard page" );

            Log.assertThat( dashBoardPage.getPerformanceThisWeekHeader().containsAll( Dashboard.ORGANIZATION_PERFORMANCE_THIS_WEEK_HEADERS ), "orgainzation performance this week - heaeders is present in the admin dashboard page",
                    "orgainzation performance this week - headers is not present in the admin dashboard page" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify organization - student usage widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ), "Organization Usage header is present in dashboard page", "Organization Usage header is not present in dashboard page" );

            Log.assertThat( dashBoardPage.verifyStudentUsageBtnIsSelected(), "Student Usage button is selected as default", "Student Usage button is not selected as default" );

            Log.assertThat( dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES ), "Student Averages header is present under Student Usage", "Student Averages header is present under Student Usage" );

            Log.assertThat( dashBoardPage.getStudentUsageLegends().containsAll( Constants.Reports.SUBJECTS ), "Legends are present in Student Usage", "Legends are present in Student Usage" );

            Log.assertThat( dashBoardPage.getStudentAverageWeeks().containsAll( Dashboard.STUDENT_AVERAGE_WEEK_HEADERS ), "Week headers are present in Student Average", "Week headers are not present in Student Average" );

            Log.assertThat( dashBoardPage.getWeeksAndHoursHeader().containsAll( Dashboard.X_AND_Y_AXIS_HEADERS ), "X and Y axis headers are displayed in Student Usage chart", "X and Y axis headers are not displayed in Student Usage chart" );

            Log.assertThat( dashBoardPage.isWeeksAndHoursLblPresent(), "X and Y axis values are displayed in Student Usage chart", "X and Y axis values are not displayed in Student Usage chart" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify organization - student usage goal widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.toggleToUsageGoals(), "Successfully Toggled to usage button", "Issue in toggle to usage button" );

            // Validate % of students text for math usage goal
            Log.assertThat( dashBoardPage.validatePercentageTextForAllLegends( AdminUIConstants.UsageGoal.MATH ), "% of students text displayed below of all legends ", "Error in Text" );

            // Validate % of students text for math usage goal
            Log.assertThat( dashBoardPage.validatePercentageTextForAllLegends( AdminUIConstants.UsageGoal.READING ), "% of students text displayed below of all legends ", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK ), "OnTrack Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.WATCH_CLOSELY ), "Watch Closely Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.FALLING_BEHIND ), "Falling Behind Text Legend Validated Successfully", "Error in Text" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all the widgets in admin dashboard for school admin", groups = { "smoke_test_case", "Admin_TC03", "Dashboard" }, priority = 1 )
    public void tcSMAdminDashboardSmoke002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAdminDashboard002: Verify all the widgets in admin dashboard for school admin . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password );

            SMUtils.logDescriptionTC( "Verify Performance Report widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.PERFORMANCE_REPORT ), "Performance report header is present in the admin dashboard page", "Performance report header is not present in the admin dashboard page" );

            dashBoardPage.expandSubjectDropdown();
            Log.assertThat( dashBoardPage.getOptionsInSubjectDropdown().equals( Dashboard.SUBJECTS ), "Math and Reading are present in the subject dropdown", "Math and Reading are not present in the subject dropdown" );

            Log.assertThat( dashBoardPage.getXAxisLabel().equalsIgnoreCase( Dashboard.X_AXIS_LABEL ), "Course Level heading is displayed in x-axis of the graph in Performance Report",
                    "Course Level heading is not displayed in x-axis of the graph in Performance Report" );

            Log.assertThat( dashBoardPage.getXAxisIntervals().equals( Dashboard.X_AXIS_INTERVALS ), "x axis intervals are displayed properly in Performance report", "x axis intervals are not displayed properly in Performance report" );

            Log.assertThat( dashBoardPage.getYAxisLabel().equalsIgnoreCase( Dashboard.Y_AXIS_LABEL ), "Grade heading is displayed in x-axis of the graph in Performance Report",
                    "Grade heading is not displayed in x-axis of the graph in Performance Report" );

            Log.assertThat( dashBoardPage.getYAxisIntervals().equals( Dashboard.Y_AXIS_INTERVALS ), "y axis intervals are displayed properly in Performance report", "y axis intervals are not displayed properly in Performance report" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Organization performance this week widget is present in admin dashboard" );

            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.ORGANIZATION_PERFORMANCE_THIS_WEEK ), "orgainzation performance this week is present in the admin dashboard page",
                    "orgainzation performance this week is not present in the admin dashboard page" );

            Log.assertThat( dashBoardPage.getPerformanceThisWeekHeader().containsAll( Dashboard.ORGANIZATION_PERFORMANCE_THIS_WEEK_HEADERS ), "orgainzation performance this week - heaeders is present in the admin dashboard page",
                    "orgainzation performance this week - headers is not present in the admin dashboard page" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify organization - student usage widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ), "Organization Usage header is present in dashboard page", "Organization Usage header is not present in dashboard page" );

            Log.assertThat( dashBoardPage.verifyStudentUsageBtnIsSelected(), "Student Usage button is selected as default", "Student Usage button is not selected as default" );

            Log.assertThat( dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES ), "Student Averages header is present under Student Usage", "Student Averages header is present under Student Usage" );

            Log.assertThat( dashBoardPage.getStudentUsageLegends().containsAll( Constants.Reports.SUBJECTS ), "Legends are present in Student Usage", "Legends are present in Student Usage" );

            Log.assertThat( dashBoardPage.getStudentAverageWeeks().containsAll( Dashboard.STUDENT_AVERAGE_WEEK_HEADERS ), "Week headers are present in Student Average", "Week headers are not present in Student Average" );

            Log.assertThat( dashBoardPage.getWeeksAndHoursHeader().containsAll( Dashboard.X_AND_Y_AXIS_HEADERS ), "X and Y axis headers are displayed in Student Usage chart", "X and Y axis headers are not displayed in Student Usage chart" );

            Log.assertThat( dashBoardPage.isWeeksAndHoursLblPresent(), "X and Y axis values are displayed in Student Usage chart", "X and Y axis values are not displayed in Student Usage chart" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify organization - student usage goal widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.toggleToUsageGoals(), "Successfully Toggled to usage button", "Issue in toggle to usage button" );

            // Validate % of students text for math usage goal
            Log.assertThat( dashBoardPage.validatePercentageTextForAllLegends( AdminUIConstants.UsageGoal.MATH ), "% of students text displayed below of all legends ", "Error in Text" );

            // Validate % of students text for math usage goal
            Log.assertThat( dashBoardPage.validatePercentageTextForAllLegends( AdminUIConstants.UsageGoal.READING ), "% of students text displayed below of all legends ", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.ONTRACK ), "OnTrack Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.WATCH_CLOSELY ), "Watch Closely Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.UsageGoal.MATH, AdminUIConstants.UsageGoal.FALLING_BEHIND ), "Falling Behind Text Legend Validated Successfully", "Error in Text" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all the widgets in admin dashboard for subdistrict admin ", groups = { "smoke_test_case", "Admin_TC02", "Dashboard" }, priority = 1 )
    public void tcSMAdminDashboardSmoke003() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "SMAdminDashboard003: Verify all the widgets in admin dashboard for subdistrict admin  <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password );

            Log.message( "Sub-district username is " + RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) );

            SMUtils.logDescriptionTC( "Verify Performance Report widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.PERFORMANCE_REPORT ), "Performance report header is present in the admin dashboard page", "Performance report header is not present in the admin dashboard page" );

            dashBoardPage.expandSubjectDropdown();
            Log.assertThat( dashBoardPage.getOptionsInSubjectDropdown().equals( Dashboard.SUBJECTS ), "Math and Reading are present in the subject dropdown", "Math and Reading are not present in the subject dropdown" );

            Log.assertThat( dashBoardPage.getXAxisLabel().equalsIgnoreCase( Dashboard.X_AXIS_LABEL ), "Course Level heading is displayed in x-axis of the graph in Performance Report",
                    "Course Level heading is not displayed in x-axis of the graph in Performance Report" );

            Log.assertThat( dashBoardPage.getXAxisIntervals().equals( Dashboard.X_AXIS_INTERVALS ), "x axis intervals are displayed properly in Performance report", "x axis intervals are not displayed properly in Performance report" );

            Log.assertThat( dashBoardPage.getYAxisLabel().equalsIgnoreCase( Dashboard.Y_AXIS_LABEL ), "Grade heading is displayed in x-axis of the graph in Performance Report",
                    "Grade heading is not displayed in x-axis of the graph in Performance Report" );

            Log.assertThat( dashBoardPage.getYAxisIntervals().equals( Dashboard.Y_AXIS_INTERVALS ), "y axis intervals are displayed properly in Performance report", "y axis intervals are not displayed properly in Performance report" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Organization performance this week widget is present in admin dashboard" );

            Log.assertThat( dashBoardPage.getWidgetHeaders().contains( Dashboard.ORGANIZATION_PERFORMANCE_THIS_WEEK ), "orgainzation performance this week is present in the admin dashboard page",
                    "orgainzation performance this week is not present in the admin dashboard page" );

            Log.assertThat( dashBoardPage.getPerformanceThisWeekHeader().containsAll( Dashboard.ORGANIZATION_PERFORMANCE_THIS_WEEK_HEADERS ), "orgainzation performance this week - heaeders is present in the admin dashboard page",
                    "orgainzation performance this week - headers is not present in the admin dashboard page" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify organization - student usage widget is present in admin dashboard" );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ), "Organization Usage header is present in dashboard page", "Organization Usage header is not present in dashboard page" );

            Log.assertThat( dashBoardPage.verifyStudentUsageBtnIsSelected(), "Student Usage button is selected as default", "Student Usage button is not selected as default" );

            Log.assertThat( dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES ), "Student Averages header is present under Student Usage", "Student Averages header is present under Student Usage" );

            Log.assertThat( dashBoardPage.getStudentUsageLegends().containsAll( Constants.Reports.SUBJECTS ), "Legends are present in Student Usage", "Legends are present in Student Usage" );

            Log.assertThat( dashBoardPage.getStudentAverageWeeks().containsAll( Dashboard.STUDENT_AVERAGE_WEEK_HEADERS ), "Week headers are present in Student Average", "Week headers are not present in Student Average" );

            Log.assertThat( dashBoardPage.getWeeksAndHoursHeader().containsAll( Dashboard.X_AND_Y_AXIS_HEADERS ), "X and Y axis headers are displayed in Student Usage chart", "X and Y axis headers are not displayed in Student Usage chart" );

            Log.assertThat( dashBoardPage.isWeeksAndHoursLblPresent(), "X and Y axis values are displayed in Student Usage chart", "X and Y axis values are not displayed in Student Usage chart" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "5", "31" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "5", "31" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }
}
