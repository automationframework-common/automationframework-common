package com.savvas.sm.admin.bff.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListBFF;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;

import io.restassured.response.Response;

/**
 * @author karthigeyan.bala
 *
 */
/**
 * @author karthigeyan.bala
 *
 */
public class GetOrganizationListBFF {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String districtAdminDetails;
    public RBSUtils rbsUtils = new RBSUtils();
    public static String districtId;
    public static String teacherId;
    public static String userName;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public static String userId;
    public static String accessToken;
    public static String orgId;
    public static String orgList;
    private Response response;
    OrganizationListing orgListing = new OrganizationListing();
    HashMap<String, String> userDetail = new HashMap<>();
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String studentDetailsSchool1;
    String studentDetails;
    String studentUsername;
    String subdistrictUsername;
    String subdistrictUserID;
    String subDistrictwithSchoolId;
    String subdistrictWithoutOrgUserID;
    String subdistrictWithoutOrgUsername;
    String subDistrictwithoutOrgId;
    String schoolID;
    String singleSchoolAdminUserID;
    String singleSchoolAdminUsername;
    String singleSchoolAdminOrgId;
    String multiSchoolAdminUserID;
    String multiSchoolAdminUsername;
    String multiSchoolAdminOrgId;

    OrganizationListBFF orgListBFF = new OrganizationListBFF();

    // Org list query
    List<String> queryItems = Arrays.asList( AdminAPIConstants.ORGANIZATION_ID, AdminAPIConstants.ORGANIZATION_NAME );

    @BeforeClass
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting district admin details from RBS Datasetup
        userName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherStaffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        // Getting student details
        studentDetails = RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );

        // Getting sub district with school admin details
        String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
        subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );

        // Getting the school under the sub district details
        String schoolUnderSubDistrict = RBSDataSetup.SchoolUnderSubDistrict;
        subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
        schoolID = rbsUtils.getOrganizationIDByName( subDistrictwithSchoolId, schoolUnderSubDistrict );

        // Getting sub district without school admin details
        String subdistrictWithoutOrgAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN );
        subdistrictWithoutOrgUserID = SMUtils.getKeyValueFromResponse( subdistrictWithoutOrgAdminDetails, RBSDataSetupConstants.USERID );
        subdistrictWithoutOrgUsername = SMUtils.getKeyValueFromResponse( subdistrictWithoutOrgAdminDetails, RBSDataSetupConstants.USERNAME );
        subDistrictwithoutOrgId = RBSDataSetup.subDistrictwithoutSchoolId;

        // Getting single school admin details
        String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        singleSchoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
        singleSchoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
        singleSchoolAdminOrgId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" );

        // Getting multi school admin details
        String multiSchoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
        multiSchoolAdminUserID = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERID );
        multiSchoolAdminUsername = SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME );
        multiSchoolAdminOrgId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );

    }

    @Test ( priority = 1, dataProvider = "positiveScenarioTestData", groups = { "OrganizationListBFF", "SMK-51770", "P1", "API" } )
    public void getOrganizationListBFF_Positive( String tcID, String tcDescription, String expResCode, String scenario ) throws Exception {

        Log.testCaseInfo( tcID + " : " + tcDescription );
        Map<String, Map<String, String>> orgDetailsFromAPI = new HashMap<>();

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenario ) {

            case "DISTRICT_ADMIN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, districtId, districtId, queryItems );
                break;

            case "SUBDISTRICT_WITH_ORG":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, subdistrictUserID, subDistrictwithSchoolId, subDistrictwithSchoolId, queryItems );
                Log.message( response.getBody().asString() );
                Log.assertThat( getChildOrganizations( response ).containsAll( Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) ), "Getting all organization under sub district", "Not getting all organization under sub district" );
                break;

            case "SUBDISTRICT_WITHOUT_ORG":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( subdistrictWithoutOrgUsername, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, subdistrictWithoutOrgUserID, subDistrictwithoutOrgId, subDistrictwithoutOrgId, queryItems );
                Log.message( response.getBody().asString() );
                Log.assertThat( getChildOrganizations( response ).contains( RBSDataSetup.subDistrictwithoutSchoolId ), "Getting sub district organization details for sub district without organization",
                        "Not getting sub district organization details for sub district without organization" );
                break;

            case "MULTI_SCHOOL_ADMIN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( multiSchoolAdminUsername, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, multiSchoolAdminUserID, multiSchoolAdminOrgId, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ), queryItems );
                Log.message( response.getBody().asString() );
                Log.assertThat( getChildOrganizations( response ).contains( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) ), "Getting all organization for multi school admin",
                        "Not getting all organization for multi school admin" );
                break;

            case "SINGLE_SCHOOL_ADMIN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( singleSchoolAdminUsername, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, singleSchoolAdminUserID, singleSchoolAdminOrgId, singleSchoolAdminOrgId, queryItems );
                Log.message( response.getBody().asString() );
                Log.assertThat( getChildOrganizations( response ).containsAll( Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) ) ), "Getting an excepted organization for single school admin",
                        "Not getting an excepted organization for single school admin" );
                break;

            case "Savvas_Admin_with_District_Id":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, orgId, districtId, queryItems );
                Log.message( response.getBody().asString() );

                break;

            case "Savvas_Admin_with_School_Id":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, orgId, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ), queryItems );
                Log.message( response.getBody().asString() );
                Log.assertThat( getChildOrganizations( response ).containsAll( Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) ) ),
                        "Getting an excepted organization for savvas admin while pass the selected orgIds as school Id", "Not getting an excepted organization forsavvas admin while pass the selected orgIds as school Id" );
                break;

            case "Savvas_Admin_with_SubDistrict_Id":
                userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" );
                orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "primaryOrgId" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, orgId, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ), queryItems );
                Log.message( response.getBody().asString() );
                Log.assertThat( getChildOrganizations( response ).containsAll( Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) ) ),
                        "Getting an excepted organization for savvas admin while pass the selected orgIds as subdistrict Id", "Not getting an excepted organization forsavvas admin while pass the selected orgIds as subdistrict Id" );
                break;

            default:
                break;
        }

        Log.message( scenario + " :- " + response.getBody().asString() );

        // Verifying status code
        String statusCode = String.valueOf( response.getStatusCode() );
        Log.assertThat( statusCode.equals( expResCode ), "The Status code is expected " + expResCode + " and actual " + statusCode + " Verified", "The Status code is expected " + expResCode + " and actual " + statusCode + "is not Verified" );
        Log.testCaseResult();
    }

    @DataProvider ( name = "positiveScenarioTestData" )
    public Object[][] positiveScenarioTestData() {
        Object[][] data = { { "tcOrgListBFF001", "Verify the getOrganizationList graphql query is fetching all the child organizations when district admin fetches org list", "200", "DISTRICT_ADMIN" },
                { "tcOrgListBFF002", "Verify the getOrganizationList graphql query is fetching all the child organizations when subdistrict admin which has child orgs, fetches org list", "200", "SUBDISTRICT_WITH_ORG" },
                { "tcOrgListBFF003", "Verify the getOrganizationList graphql query is fetching all the child organizations when subdistrict admin which doesnt have child orgs, fetches org list", "200", "SUBDISTRICT_WITHOUT_ORG" },
                { "tcOrgListBFF004", "Verify the getOrganizationList graphql query is fetching all the schools associated when school admin which is associated with multiple orgs, fetches org list", "200", "MULTI_SCHOOL_ADMIN" },
                { "tcOrgListBFF005", "Verify the getOrganizationList graphql query is fetching the school associated when school admin which is associated with single org, fetches org list", "200", "SINGLE_SCHOOL_ADMIN" },
                { "tcOrgListBFF006", "Verify the getOrganizationList graphql response , if pass the savvas admin credentials and selected orgId as district id.", "200", "Savvas_Admin_with_District_Id" },
                { "tcOrgListBFF007", "Verify the getOrganizationList graphql response , if pass the savvas admin credentials and selected orgId as school id.", "200", "Savvas_Admin_with_School_Id" },
                { "tcOrgListBFF008", "Verify the getOrganizationList graphql response , if pass the savvas admin credentials and selected orgId as subdistrict id.", "200", "Savvas_Admin_with_SubDistrict_Id" } };

        return data;
    }

    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "OrganizationListBFF", "SMK-51770", "P1", "API" } )
    public void getOrganizationListBFF_Negative( String tcID, String tcDescription, String expResCode, String scenarioType ) throws Exception {

        Log.testCaseInfo( tcID + " : " + tcDescription );

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenarioType ) {

            case "TEACHER_ACCESS_TOKEN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( teacherUsername, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, districtId, districtId, queryItems );
                break;

            case "STUDENT_ACCESS_TOKEN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, districtId, districtId, queryItems );
                break;

            case "INVALID_ACCESS_TOKEN":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) + "Invalid" );
                response = orgListBFF.getOrganizationListBFF( headers, userId, districtId, districtId, queryItems );
                break;

            case "INVALID_ORG_ID":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId, districtId + "Invalid", districtId, queryItems );
                break;

            case "INVALID_USER_ID":

                // GET Organization List
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, password ) );
                response = orgListBFF.getOrganizationListBFF( headers, userId + "Invalid", districtId, districtId, queryItems );
                break;

            default:
                break;
        }

        // Verifying Status code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expResCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + expResCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expResCode );

        // Verifying message from response
        if ( scenarioType.equalsIgnoreCase( "TEACHER_ACCESS_TOKEN" ) || scenarioType.equalsIgnoreCase( "STUDENT_ACCESS_TOKEN" ) || scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Unauthorized message for " + scenarioType, "The Unauthorized message is not getting displayed for " + scenarioType );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_401 ), "Getting Access Denied message for Invalid org id", "The Access Denied message is not getting displayed for Invalid org id!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ACCESS_TOKEN" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {
        Object[][] data = { { "tcOrgListBFF006", "Verify the getOrganizationList graphql query is returning unauthorized error message when teacher access token is passed", "200", "TEACHER_ACCESS_TOKEN" },
                { "tcOrgListBFF007", "Verify the getOrganizationList graphql query is returning unauthorized error message when student access token is passed", "200", "STUDENT_ACCESS_TOKEN" },
                { "tcOrgListBFF008", "Verify the getOrganizationList graphql query is returning unauthorized error message when invalid access token is passed", "200", "INVALID_ACCESS_TOKEN" },
                { "tcOrgListBFF009", "Verify the getOrganizationList graphql query is returning unauthorized error message when invalid org id is passed", "200", "INVALID_ORG_ID" },
                { "tcOrgListBFF010", "Verify the getOrganizationList graphql query is returning unauthorized error message when invalid user id is passed", "200", "INVALID_USER_ID" } };
        return data;
    }

    /**
     * This method is extracting error message from response
     * 
     * @param jsonResponse
     * @param message
     * @return
     */
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    /**
     * To get child organizations
     * 
     * @param response
     * @return
     */
    public List<String> getChildOrganizations( Response response ) {
        List<String> orgKeyValue = new ArrayList<>();
        IntStream.range( 0, SMUtils.getWordCount( response.getBody().asString(), "organizationId" ) ).forEach( iter -> {
            String rspn = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
            JSONObject jsonObj = new JSONObject( rspn );
            JSONArray ja = jsonObj.getJSONArray( "getOrganizationList" );
            JSONObject jObj = ja.getJSONObject( iter );
            orgKeyValue.add( jObj.get( "organizationId" ).toString() );
        } );
        return orgKeyValue;
    }

}
