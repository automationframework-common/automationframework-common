package com.savvas.sm.admin.apiIntegration.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class OrganizationUsageGoalTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String password;
    Map<String, String> headers = new HashMap<>();
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String readingSchool;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private List<String> courseIDs = new ArrayList<>();
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    String teacherAccessToken;
    String teacherUsername;
    String mathAssignmentId;
    String readingAssignmentId;
    private String flexSchool;
    private String mathSchool;
    private String districtId = null;
    private String student1Details;
    private String student2Details;
    private String student3Details;
    private String studentId;
    
  //Tokens
    private String savvasAdminToken = null;
    private String districtAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;

    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String savvasAdminDetails = null;
    private String subDistrictAdminWOSDetails = null;
    private String subDistrictAdminWithSchoolDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;

    //===Details
    public static String subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
    public static String subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
    public static String subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
    public static String subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
    public static String school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
     
        districtId = configProperty.getProperty( "district_ID" );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );

        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        student1Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student2Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student3Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) );
        studentId = SMUtils.getKeyValueFromResponse( student1Details, "userId" );

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupNameRVC" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );

        Log.message( "Assigning assignment..." );

        HashMap<String, String> assignmentResponseMath = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );

        JSONObject mathAssignmentDetailsJson = new JSONObject( assignmentResponseMath.get( Constants.REPORT_BODY ) );

        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );

        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );

        mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();

        Log.message( "Assignment Details" + assignmentResponseMath );

        HashMap<String, String> assignmentResponseReading = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, Arrays.asList( "2" ) );

        Log.message( "Assignment Details" + assignmentResponseReading );

        JSONObject readAssignmentDetailsJson = new JSONObject( assignmentResponseReading.get( Constants.REPORT_BODY ) );

        JSONArray readAssignmentList = readAssignmentDetailsJson.getJSONArray( Constants.DATA );

        JSONObject readAssignmentInfo = new JSONObject( readAssignmentList.get( 0 ).toString() );

        readingAssignmentId = readAssignmentInfo.get( "assignmentId" ).toString();
        
        Log.message( "Assignment IDs - " + assignmentIds );

        executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );
        executeCourse( SMUtils.getKeyValueFromResponse( student2Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );

        FixupFunction.executeFixupFunctions( RBSDataSetup.organizationIDs.get( flexSchool ) );
        

        //District Admin
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "45" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        districtAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Sub-District Admin
        subDistrictAdminWOSDetails = createAdminsClass.createSubDistrictAdminWithoutSchool( smUrl, subDistrictOrgId_without_school, "046" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminWOSDetails );
        Log.message( "********" );
        subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminWOSDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Sub-District Admin
        subDistrictAdminWithSchoolDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "047" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminWithSchoolDetails );
        Log.message( "********" );
        subDistrictAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( subDistrictAdminWithSchoolDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Multi-School Admin
        multiSchoolAdminDetails = createAdminsClass.createMultiSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, districtId, "048" );
        Log.message( "********" );
        Log.message( "multiSchoolAdminDetails from Create Admins are " + multiSchoolAdminDetails );
        Log.message( "********" );
        multiSchoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "049" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        schoolAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

    }

    @Test ( description = "Verify all field available on organization usage goal", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal", "smoke_test_case" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration001() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration001:Verify all field available on organization usage goal<small><b><i>[" + browser + "]</b></i></small>" );

            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password   );
            //Clicking expand dropdown and all options from dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( flexSchool );
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            
            //Apply Selection button
            dashBoardPage.clickApplySelectionButton();

            SMUtils.logDescriptionTC( "Verify user can see Usage goals setting button for orgnization usage on dashboard page." );
            Log.assertThat( dashBoardPage.isUsageGoalDisplaying(), "Usage goal toggle is displaying", "Usage goal toggle is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( " Verify user can see Usage goals bar once he select Usage goals." );
            Log.assertThat( dashBoardPage.toggleToUsageGoalsnew(), "Usage goal page is displaying after selecting  usage goal toggle", "Usage goal page is not displaying after selecting  usage goal toggle" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify text 'Math Usage goals' should display on Usage goals" );
            Log.assertThat( dashBoardPage.validateHeaderTextOfProgressBar( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.MATH_USAGE_GOAL ), "Math usage goal text is displaying", "Math Usage goal Text is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify text 'Reading Usage goals' should display on Usage goals" );
            Log.assertThat( dashBoardPage.validateHeaderTextOfProgressBar( AdminUIConstants.Dashboard.READING, AdminUIConstants.Dashboard.READING_USAGE_GOAL ), "Reading usage goal text is displaying", "Reading usage goal text is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify legends for default math Usage goals" );
            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.ON_TRACK ), "On Track Legend is displaying", "On Track Legend is not displaying" );
            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.WATCH_CLOSELY ), "Watch Closely Legend is displaying", "watch Closely Legend is not displaying" );
            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.FALLING_BEHIND ), "Falling Behind Legend is displaying", "Falling Behind Legend is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all field available on organization usage goal", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal", "smoke_test_case" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration002() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration002:Verify all field available on organization usage goal<small><b><i>[" + browser + "]</b></i></small>" );

            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password );
            
            //Select single organization in organization dropdown
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            
            dashBoardPage.enterTextInSearchTextBox( flexSchool);
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( flexSchool ) );
            dashBoardPage.clickApplySelectionButton();
            dashBoardPage.toggleToUsageGoalsnew();
            SMUtils.logDescriptionTC( "Verify legends for default reading Usage goals" );
            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.Dashboard.READING, AdminUIConstants.Dashboard.ON_TRACK ), "On Track Legend is displaying", "On Track Legend is not displaying" );
            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.Dashboard.READING, AdminUIConstants.Dashboard.WATCH_CLOSELY ), "Watch Closely Legend is displaying", "watch Closely Legend is not displaying" );
            Log.assertThat( dashBoardPage.validateLegendText( AdminUIConstants.Dashboard.READING, AdminUIConstants.Dashboard.FALLING_BEHIND ), "Falling Behind Legend is displaying", "Falling Behind Legend is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify text 'Usage goals apply only to the default courses Math and Reading.' should display top right corner on Usage goals" );
            Log.assertThat( dashBoardPage.validateNoteText( AdminUIConstants.Dashboard.USAGE_GOAL_DESC ), "Usage note is displaying for usage goal", "Usage note is not displaying for usage goal" );
            Log.testCaseResult();
            
            int sizeOfOrg = dashBoardPage.getselectedOrganizationsFromOrgDropdown().size();
            SMUtils.logDescriptionTC( "" );
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( String.format( AdminUIConstants.Dashboard.SELECTED_ORGANIZATIONS_COUNT, sizeOfOrg )), "Single school selction name is displaying on usage goal page",
                    "Single school selction name is not displaying on usage goal page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "" );
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.ON_TRACK, AdminUIConstants.Dashboard.ON_TRACK_COLOR_CODE ), "On track legends colors are displaying",
                    "On Track legends color are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "" );
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.WATCH_CLOSELY, AdminUIConstants.Dashboard.WATCH_CLOSELY_COLOR_CODE ), "Watch closely legends colors are displaying",
                    "Watch closely legends color are not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "" );
            Log.assertThat( dashBoardPage.validateColourForAllLegends( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.FALLING_BEHIND, AdminUIConstants.Dashboard.FALLING_BEHIND_COLOR_CODE ), "Falling Behind legends colors are displaying",
                    "Falling Behind legends color are not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Zero state message for Organization usage if the selected organization has no usage", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration003() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration003:Verify the Zero state message for Organization usage if the selected organization has no usage<small><b><i>[" + browser + "]</b></i></small>" );

            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(SMUtils.getKeyValueFromResponse( subDistrictAdminWOSDetails, RBSDataSetupConstants.USERNAME ), password );
            SMUtils.logDescriptionTC( "Verify the Zero state message for Organization usage if the selected organization has no usage" );
            
            //Toggle usage goals
            dashBoardPage.toggleToUsageGoalsnew();
            //verifying Zero State Message
            Log.assertThat( dashBoardPage.getZeroStateHeader().equalsIgnoreCase( AdminUIConstants.Dashboard.ORGANIZATION_USAGE_GOAL_ZERO_STATE_HEADER ), "Zero State message displayed Properly in Organization usage goal",
                    "Zero State message not displayed Properly in Organization usage goal" );
            Log.assertThat( dashBoardPage.getZeroStateDescription().equalsIgnoreCase( AdminUIConstants.Dashboard.ZERO_STATE_DESCRIPTION ), "Zero State message displayed Properly in Organization usage goal desc",
                    "Zero State message not displayed Properly in Organization usage goal" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify availble field on organization usage goal", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration004() throws Throwable {
    	
        //Creating teacher and student
        String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
        String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

        //creating student
        String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
        String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );

        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( assignAssignment.toString() );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration004:Verify availble field on organization usage goal<small><b><i>[" + browser + "]</b></i></small>" );
            //login as district admin, due to issue in fixup query for Sub district
            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME ), password  );
                        
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            //selecting org from the dropdown
            //List <String> orglist =dashBoardPage.getAllOrgFromDropdown();
            dashBoardPage.enterTextInSearchTextBox( flexSchool );
            dashBoardPage.selectOrganizationsFromOrgDropdown(Arrays.asList(flexSchool));
            dashBoardPage.clickApplySelectionButton();
            SMUtils.logDescriptionTC( " Verify sub district user can see Usage goals bar once he select Usage goals on dash board" );
            Log.assertThat( dashBoardPage.toggleToUsageGoals(), "Usage goal page is displaying after selecting  usage goal toggle", "Usage goal page is not displaying after selecting  usage goal toggle" );
            Log.testCaseResult();

            int sizeOfOrg = dashBoardPage.getselectedOrganizationsFromOrgDropdown().size();

            //Verify the Selected organization count
            Log.assertThat(
                    dashBoardPage.getNoOfOrganizationSelectedText().equals( String.format( AdminUIConstants.Dashboard.ALL_SELECTED_ORGANIATION_COUNT, sizeOfOrg ) )
                            || dashBoardPage.getNoOfOrganizationSelectedText().equals( String.format( AdminUIConstants.Dashboard.SELECTED_ORGANIZATIONS_COUNT, sizeOfOrg ) ),
                    "Organization name is displayed when admin select multiple org", "Organization name is not displayed when admin select multiple org" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify usage bar percenatage should be in round figure(0 to 100)." );
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.ON_TRACK ), "Student percentage is in between 0 to 100 for ON track student ",
                    "Student percentage is not in between 0 to 100 for ON track student" );
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.FALLING_BEHIND ), "Student percentage is in between 0 to 100 for Falling Behind student",
                    "Student percentage is in between 0 to 100 for Falling Behind student" );
            Log.assertThat( dashBoardPage.verifyPercentageIsBetween0To100( AdminUIConstants.Dashboard.MATH, AdminUIConstants.Dashboard.WATCH_CLOSELY ), "Student percentage is in between 0 to 100 for Watch closely student",
                    "Student percentage is in between 0 to 100 for Watch Closely student" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify orphan student (student created in SM side and not added in group) details should also be display in usage goal.", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration005() throws Throwable {

        //creating student
        String orphanStudent = "SchStudent" + System.nanoTime();
        String orphanStudentDetails = new UserAPI().createUserWithCustomization( orphanStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
        String orphanStudentId = SMUtils.getKeyValueFromResponse( orphanStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( orphanStudentDetails, studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, orphanStudentId );

        //Creating group  for above created teacher & student
        String groupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( orphanStudentId ), orgId,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );

        Log.message( "contentbasename" + contentBaseName );
        HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( orphanStudentId ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( assignAssignment.toString() );
        
        //Removing student from the group
        new GroupAPI().removeStudentFromGroup( smUrl, orphanStudentId, groupId, teacherId, orgId, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration005:Verify orphan student (student created in SM side and not added in group) details should also be display in usage goal.<small><b><i>[" + browser + "]</b></i></small>" );
          //login as district admin, due to issue in fixup query for Sub district
            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME  ), password  );
            SMUtils.logDescriptionTC( "Verify orphan student (student created in SM side and not added in group) details should also be display in usage goal." );
            SMUtils.logDescriptionTC( "Verify user can see Usage goals setting button for orgnization usage on dashboard page." );
            Log.assertThat( dashBoardPage.isUsageGoalDisplaying(), "Usage goal toggle is displaying", "Usage goal toggle is not displaying" );
            Log.testCaseResult();

            Log.assertThat( dashBoardPage.toggleToUsageGoalsnew(), "Usage goal page is displaying after selecting  usage goal toggle", "Usage goal page is not displaying after selecting  usage goal toggle" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify school admin with single and multiple institutions can view the usage goal in dashboard page", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration006() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration006:Verify school admin with single and multiple institutions can view the usage goal in dashboard page<small><b><i>[" + browser + "]</b></i></small>" );

            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), password  );
            
            SMUtils.logDescriptionTC( "Verify user can see Usage goals setting button for orgnization usage on dashboard page." );
            Log.assertThat( dashBoardPage.isUsageGoalDisplaying(), "Usage goal toggle is displaying", "Usage goal toggle is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Usage Goal after deleting student assignment", groups = { "SMK-51733", "AdminDashboard", "OrganizationUsagegoal", "smoke_test_case" }, priority = 1 )
    public void SM_OrganizationUsagegoalAPIIntegration007() throws Throwable {
    	
        // delete assignment
        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, studentId );
        new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "SM_OrganizationUsagegoalAPIIntegration007:Verify Usage Goal after deleting student assignment<small><b><i>[" + browser + "]</b></i></small>" );

            // Login into SM using admin credential
            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(SMUtils.getKeyValueFromResponse( multiSchoolAdminDetails, RBSDataSetupConstants.USERNAME ), password  );
            //verifying Zero State Message
            dashBoardPage.toggleToUsageGoalsnew();
            Log.assertThat( dashBoardPage.getZeroStateHeader().equalsIgnoreCase( AdminUIConstants.Dashboard.ORGANIZATION_USAGE_GOAL_ZERO_STATE_HEADER ), "Zero State message displayed Properly in Organization usage goal",
                    "Zero State message not displayed Properly in Organization usage goal" );
            Log.assertThat( dashBoardPage.getZeroStateDescription().equalsIgnoreCase( AdminUIConstants.Dashboard.ZERO_STATE_DESCRIPTION ), "Zero State message displayed Properly in Organization usage goal desc",
                    "Zero State message not displayed Properly in Organization usage goal" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    
    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "95", "2", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "5" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Reading Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "95", "1", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "5" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * To generate request value for student
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }
}
