package com.savvas.sm.admin.ui.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory.AUDIT_HISTORY_NAVIGATION_BUTTONS;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory.AUDIT_HISTORY_TABLE_HEADER;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

public class AuditHistoryUI extends EnvProperties {
    private String smUrl;
    private String browser;
    private String password;
    private String districtAdminDetails;
    private String districtId;

    HashMap<String, String> assignmentDetails = new HashMap<>();
    public static String userName;
    public static String userId;
    String teacherDetails;
    String teacherStaffId;
    String teacherUsername;
    String teacherOrgId;
    String courseId;
    String schoolName;
    HashMap<String, String> groupdetails = new HashMap<>();
    List<String> studentDetails = new ArrayList<String>();
    List<String> studentID = new ArrayList<String>();
    List<String> courseIDS = new ArrayList<String>();
    String singleStudentGroupId;
    String multiStudentGroupId;
    AssignmentAPI assign = new AssignmentAPI();
    private String flexSchool;
    private String schoolAdminDetails = null;
    String singleSchoolAdminUsername;
    private String subDistrictAdminDetails = null;
    String subdistrictUsername;
    public static String subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
    public static String subDistrictOrgId_with_school;

    @BeforeClass ( alwaysRun = true )
    public void initTest() throws Exception {
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtId = configProperty.getProperty( "district_ID" );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );
        String endpoint = "null";

        //Admin Creation for District
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );

        // Getting admin details
        userName = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        userId = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERID );

        //School Admin
        schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        singleSchoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );

        //Sub-District Admin
        subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
        subdistrictUsername = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherStaffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherOrgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        // Creating new group
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherStaffId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        studentDetails.add( RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername ) );
        studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), "userId" ) );
        studentDetails.add( RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername ) );
        studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 1 ), "userId" ) );
        studentDetails.add( RBSDataSetup.getMyStudent( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername ) );
        studentID.add( SMUtils.getKeyValueFromResponse( studentDetails.get( 2 ), "userId" ) );
        HashMap<String, String> createSingleStudentGroup = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentID.get( 0 ) ) );
        singleStudentGroupId = SMUtils.getKeyValueFromResponse( createSingleStudentGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );
        HashMap<String, String> createMultiStudentGroup = new GroupAPI().createGroup( smUrl, groupdetails, studentID );
        multiStudentGroupId = SMUtils.getKeyValueFromResponse( createMultiStudentGroup.get( Constants.REPORT_BODY ), ( "data,groupId" ) );
        Log.message( "Group is created successfully!!!" );

        // Creating custom course
        for ( int a = 0; a < 40; a++ ) {
            courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherStaffId, teacherOrgId, DataSetupConstants.SETTINGS, "Custom Course" + System.nanoTime() );

            courseIDS.add( courseId );
        }
        //To generate Audit History
        for ( int i = 0; i < courseIDS.size(); i++ ) {
            // Assigning an assignment
            assignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
            assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherStaffId );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
            assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseIDS.get( i ) );
            assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 0 ) ), "users" );
            assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 1 ) ), "users" );
            assign.assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( studentID.get( 2 ) ), "users" );
            Log.message( "Assigned an assignment to the Student" );

            // Deleting an assignment
            assign.deleteAssignment( smUrl, assignmentDetails, endpoint );
            Log.message( "Assignment is deleted successfully!!!" );
        }

    }

    @Test ( description = "Verify Audit History should display in left nav bar and other components in the Audit History Page", groups = { "SMK-51928", "SMK-51927", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory001: Verify Audit History  should display in left nav bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify Audit History  should display in left nav bar" );
            Log.assertThat( auditHistoryPage.verifyAuditHistoryinSubNavigation(), "The Audit History Page is displayed in Left navigation bar", "The Audit History Page is not displayed in Left navigation bar" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify page should navigate to Audit History filters - UI ,when admin click on Audit History." );

            if ( configProperty.getProperty( "isExecutionInMFE" ).equalsIgnoreCase( "true" ) ) {
                Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.AUDIT_HISTORY_URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            } else {
                Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.EB_AUDIT_HISTORY_URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            }

            SMUtils.logDescriptionTC( "Verify List of all fields available to 'Audit History Filter- UI." );

            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verfiy the default zero state message in Audit history Page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory002: Verfiy the default zero state message in Audit history Page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verfiy the default zero state message in Audit history Page." );
            Log.assertThat( auditHistoryPage.getZeroStateHeader().equals( AuditHistory.AUDIT_HISTORY_ZERO_STATE ) && auditHistoryPage.getZeroStateMessage().equals( AuditHistory.AUDIT_HISTORY_ZERO_STATE_MESSAGE ),
                    "The Zero State message is displayed and verified", "The Zero state message is not displayed and verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify audit history list columns for audit history.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory003: Verify audit history list columns for audit history. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganizationByName( flexSchool );

            SMUtils.logDescriptionTC( "Verify audit history list columns for audit history." );
            SMUtils.logDescriptionTC( "Verify assignmements list page should display based on organization selection." );
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "The Column Headers are displayed", "The Column Headers are not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the total number of audit history are displayed in the audit history list page and number of pages for more than 100 records.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory004: Verify the total number of audit history are displayed in the audit history list page and number of pages for more than 100 records. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the total number of audit history are displayed in the audit history list page" );
            auditHistoryPage.selectOrganizationByName( flexSchool );
            Log.assertThat( auditHistoryPage.verifypageCountisDisplayed(), "The Page count is displayed", "The Page count is not displayed" );
            Log.assertThat( auditHistoryPage.verifyPageCountFormat(), "The Page format is displayed and verified", "The page format is not verified" );
            Log.assertThat( auditHistoryPage.getTotalCountInPaginationNumber() == auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE ).size(), "Audit History Count and number of records displayed are same and verified",
                    "Audit History Count and number of records displayed are not same and not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the number of pages of audit history displayed for the results more than 100 count in the audit history page." );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST ).equals( "true" ), "The backward button is disabled by default", "The backward button is enabled by default" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "false" ), "The forward button is enabled by default", "The forward button is disabled by default" );
            Log.assertThat( auditHistoryPage.verifyPageCountFormat(), "The Page format is displayed and verified", "The page format is not verified" );
            Log.assertThat( auditHistoryPage.verifyNumberOfPagesFormat(), "The Number of Pages and the page format is verified", "The Number of Pages and the page format is not verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of forward navigation in the page navigation for more than 100 count in the audit history page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory005: Verify the functionality of forward navigation in the page navigation for more than 100 count in the audit history page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of forward navigation in the page navigation for more than 100 count in the audit history page." );
            auditHistoryPage.selectOrganizationByName( flexSchool );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "false" ), "The forward button is enabled by default", "The forward button is disabled by default" );

            for ( int i = 0; auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "false" ); i++ ) {
                auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT );
                Log.message( "Navigated to the Next Page" );
            }
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "true" ), "The Next button is disabled", "The Next button is enabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "true" ), "The Last button is disabled", "The Last button is enabled" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of fast forward navigation in the page navigation for more than 100 count in the audit history page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory006: Verify the functionality of fast forward navigation in the page navigation for more than 100 count in the audit history page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of fast forward navigation in the page navigation for more than 100 count in the audit history page." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganizationByName( flexSchool );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "false" ), "The forward button is enabled by default", "The forward button is disabled by default" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST );
            Log.message( "Navigated to the Last Page" );
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "true" ), "The Next button is disabled", "The Next button is enabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "true" ), "The Last button is disabled", "The Last button is enabled" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page.s", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory007: Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page.s <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page." );
            auditHistoryPage.selectOrganizationByName( flexSchool );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "true" ), "The previous button is disabled by default", "The previuos button is enabled by default" );

            for ( int i = 0; auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "false" ); i++ ) {
                auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT );
                Log.message( "Navigated to the Next Page" );
            }
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "false" ), "The Previous button is enabled", "The Previous button is disabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST ).equals( "false" ), "The First button is enabled", "The First button is disabled" );
            int currentPageNumber = auditHistoryPage.getCurrentPageNumber();
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS );
            int newPageNumber = auditHistoryPage.getCurrentPageNumber();
            Log.assertThat( newPageNumber == currentPageNumber - 1, "The previous navigated to the one page backward and verified", "The previous is not navigated to the one page backward" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of pre backward navigation in the page navigation for more than 100 count in the audit history page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory008: Verify the functionality of pre backward navigation in the page navigation for more than 100 count in the audit history page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page." );
            auditHistoryPage.selectOrganizationByName( flexSchool );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "true" ), "The previous button is disabled by default", "The previuos button is enabled by default" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST );
            Log.message( "Navigated to the Last Page" );
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "false" ), "The Previous button is enabled", "The Previous button is disabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST ).equals( "false" ), "The First button is enabled", "The First button is disabled" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST );
            int newPageNumber = auditHistoryPage.getCurrentPageNumber();
            Log.assertThat( newPageNumber == 1, "The First Button navigated to the one page backward and verified", "The First Button is not navigated to the one page backward" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to sort by ascending/descending all the column.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory009: Verify user can able to sort by ascending/descending all the column. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( userName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify user can able to sort by ascending/descending all the column." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganizationByName( flexSchool );

            Log.message( "Verifying the sort functionality for Assignment Name" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.ASSIGNMEN_NAME );
            List<String> beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.ASSIGNMEN_NAME );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME ).equals( beforeSort ), "After clicking the Assignment Name header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Group/Student" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.GROUP_STUDENT );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.GROUP_STUDENT );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT ).equals( beforeSort ), "After clicking the GROUP/STUDENT header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Type" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.TYPE );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.TYPE );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.TYPE );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.TYPE ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.TYPE ).equals( beforeSort ), "After clicking the TYPE header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Assigned By" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.ASSIGNED_BY );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.ASSIGNED_BY );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY ).equals( beforeSort ), "After clicking the ASSIGNED BY header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Courses" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.COURSE );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.COURSE );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE ).equals( beforeSort ), "After clicking the COURSE header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Dates Deleted" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.DATE_DELETED );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickAuditHistoryColumnHeader( AuditHistory.DATE_DELETED );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED ).equals( beforeSort ), "After clicking the DATE DELETED header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify the audit history listing for school admin", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory010: verify the audit history listing for school admin <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( singleSchoolAdminUsername, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "verify the audit history listing for school admin" );
            if ( configProperty.getProperty( "isExecutionInMFE" ).equalsIgnoreCase( "true" ) ) {
                Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.AUDIT_HISTORY_URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            } else {
                Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.EB_AUDIT_HISTORY_URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            }

            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify the audit history listing for sub-district admin.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory011: verify the audit history listing for sub-district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( subdistrictUsername, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "verify the audit history listing for sub-district admin." );
            if ( configProperty.getProperty( "isExecutionInMFE" ).equalsIgnoreCase( "true" ) ) {
                Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.AUDIT_HISTORY_URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            } else {
                Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.EB_AUDIT_HISTORY_URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            }
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
