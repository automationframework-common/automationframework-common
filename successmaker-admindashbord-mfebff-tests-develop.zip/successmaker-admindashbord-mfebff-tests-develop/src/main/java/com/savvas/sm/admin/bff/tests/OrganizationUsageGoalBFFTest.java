package com.savvas.sm.admin.bff.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.admindatasetup.AdminData;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.data.CreateAdmins;

import io.restassured.response.Response;

public class OrganizationUsageGoalBFFTest extends EnvProperties {

    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String flexSchool;
    private String mathSchool;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    String studentDetails;
    private List<String> courseIDs = new ArrayList<>();
    private Response response;
    private HashMap<String, String> groupDetails = new HashMap<>();
    String studentId;
    HomePage homePage = new HomePage();
    String teacherAccessToken;
    String teacherUsername;
    String mathAssignmentId;
    String readingAssignmentId;

    String flexSchoolStudentOneDeatils = null;
    String flexSchoolStudentTwoDeatils = null;
    String flexSchoolStudentThreeDeatils = null;
    String flexSchoolStudentFourDetails = null;
    String mathSchoolStudentOneDetails = null;
    private String savvasAdminToken = null;
    private String districtAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String savvasAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;
    private String districtId = null;

    //===Details
    public String subDistrictwithoutSchool_name = null;
    public String subDistrictwithSchool_name = null;
    public String subDistrictOrgId_with_school = null;
    public String subDistrictOrgId_without_school = null;
    public String school_under_subDistrictwithSchool_name = null;

    Dashboard dashboard = new Dashboard();

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        teacherUsername = AdminData.teacherDetails.keySet().toArray()[0].toString();
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );
        orgId = AdminData.orgId;

        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
        school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );

        //Savvas Admin
        savvasAdminDetails = createAdminsClass.createSavvasAdmin( smUrl, districtId, "005" );
        Log.message( "********" );
        Log.message( "savvasAdminDetails from Create Admins are " + savvasAdminDetails );
        Log.message( "********" );

        //FixupFunction.executeFixupFunctions( RBSDataSetup.organizationIDs.get( mathSchool ) );

    }

    /**
     * This method is used to test the Organization Usage BFF.
     * 
     * @param tcID
     * @throws Exception
     */
    //TODO - We can improve this once Fixup query is fixed by the developer
    @Test ( priority = 1, dataProvider = "organizationUsageGoalPositiveScenario", groups = { "OrganizationUsageGoalBFF", "SMK-58859", "P1", "API", "smoke_test_case", "positive_test_case" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        String adminUserName = null;
        String adminAccessToken = null;
        String adminDetails = null;
        String adminUserId = null;
        String adminOrgId = null;
        List<String> organizationIds = new ArrayList<>();

        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.multiSchoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.DISTRICT_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.districtAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.districtAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = orgId;
        } else if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.schoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.subDistrictAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "userId" );
            organizationIds = Arrays.asList( SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" ) );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SAVVAS_ADMIN ) ) {
            adminDetails = savvasAdminDetails;
            adminAccessToken = savvasAdminToken;
            adminUserName = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
            adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }

        Log.message( "Admin passed in the test case is " + adminUserName );
        Log.message( "Admin access token is " + adminAccessToken );
        Log.message( "Admin details are " + adminDetails );
        Log.message( "Admin userId is " + adminUserId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        switch ( scenario ) {
            case "FOR_SINGLE_ORG":
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                break;

            case "FOR_MULTIPLE_ORG":
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                break;

            case "ZERO_STATE":
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                break;

            case "SUBDISTRICT_ADMIN":
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, subDistrictOrgId_with_school, false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                break;

            case "SCHOOL_ADMIN":
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                break;

            case "MULTIPLE_SCHOOL_ADMIN":
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                break;

            case "ORGANIZATIN_WITH_ORPHAN_STUDENT":

                //delete Student from all groups
                HashMap<String, String> studentDetails = new HashMap<String, String>();
                studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
                studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( GroupConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( flexSchoolStudentThreeDeatils, "userId" ) );
                HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
                List<String> groupIds = new ArrayList<>();
                IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach(
                        iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

                groupIds.stream().forEach( groupId -> {
                    try {
                        new GroupAPI().removeStudentFromGroup( smUrl, SMUtils.getKeyValueFromResponse( flexSchoolStudentThreeDeatils, "userId" ), groupId, teacherId, orgId,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                } );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                if ( !response.getBody().asString().contains( "com.savvas.core.exceptions.DataNotFoundException" ) ) {
                    Log.assertThat( new SMAPIProcessor().isSchemaValid( "OrganizationUsageGoalBFFSchema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                } else if ( response.getBody().asString().contains( null ) ) {
                    Log.assertThat( response.getBody().asString().contains( "Data not found" ), "Response coming as expected", "Response is not coming as expected" );
                }
                break;

            case "DELETED_ASSIGNMENT":

                //delete assignment
                HashMap<String, String> mathassignmentsDetail = new HashMap<>();
                mathassignmentsDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                mathassignmentsDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                mathassignmentsDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                HashMap<String, String> assignmentResponseMathDefault = new AssignmentAPI().assignMultipleAssignments( smUrl, mathassignmentsDetail, Arrays.asList( ( SMUtils.getKeyValueFromResponse( flexSchoolStudentTwoDeatils, "userId" ) ) ),
                        Arrays.asList( "1" ) );
                JSONObject mathAssignmentDetailsJsonDefault = new JSONObject( assignmentResponseMathDefault.get( Constants.REPORT_BODY ) );

                JSONArray mathAssignmentListDefaul = mathAssignmentDetailsJsonDefault.getJSONArray( Constants.DATA );
                JSONObject mathAssignmentInfodefault = new JSONObject( mathAssignmentListDefaul.get( 0 ).toString() );
                mathAssignmentId = mathAssignmentInfodefault.get( "assignmentId" ).toString();

                mathassignmentsDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( flexSchoolStudentTwoDeatils, "userId" ), mathAssignmentId ) );
                new AssignmentAPI().removeStudentAssignment( smUrl, mathassignmentsDetail, "null" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );

                break;

            case "DELETED_GROUP":
                //adding the student to the  group for the  teacher
                String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( flexSchoolStudentFourDetails, "userId" ) ),
                        RBSDataSetup.organizationIDs.get( flexSchool ), new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                //Assigning the assignment
                String courseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID,
                        new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId,
                                orgId, DataSetupConstants.SETTINGS, courseName ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //delete group with assignment
                new GroupAPI().deleteGroup( newGroupId, teacherId, RBSDataSetup.organizationIDs.get( flexSchool ),
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( "The response under the scenario is " + response.getBody().asString() );
                if ( !response.getBody().asString().contains( "com.savvas.core.exceptions.DataNotFoundException" ) ) {
                    Log.assertThat( new SMAPIProcessor().isSchemaValid( "OrganizationUsageGoalBFFSchema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
                } else if ( response.getBody().asString().contains( null ) ) {
                    Log.assertThat( response.getBody().asString().contains( "Data not found" ), "Response coming as expected", "Response is not coming as expected" );
                }

                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }
        if ( !scenario.equalsIgnoreCase( "ZERO_STATE" ) ) {

            // Verifying status code
            String actualStatus = String.valueOf( response.getStatusCode() );
            Log.assertThat( actualStatus.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + actualStatus + " Verified", "The Status code is expected " + statusCode + " and actual " + actualStatus + "is not Verified" );
            if ( !response.getBody().asString().contains( "com.savvas.core.exceptions.DataNotFoundException" ) ) {
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "OrganizationUsageGoalBFFSchema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
            } else if ( response.getBody().asString().contains( null ) ) {
                Log.assertThat( response.getBody().asString().contains( "Data not found" ), "Response coming as expected", "Response is not coming as expected" );
            }

        }
    }

    @DataProvider ( name = "organizationUsageGoalPositiveScenario" )
    public Object[][] organizationUsageGoalPositiveScenario() {

        Object[][] inputData = {
                { "tc_OrganizationUsageGoalBFF001", "Verify the getUsageGoals graphql query is showing organization usage goal for multiple orgId passed in selectedOrg field.", "FOR_SINGLE_ORG", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF002", "Verify the getUsageGoals graphql query is showing organization usage goal for multiple orgId passed in selectedOrg field.", "FOR_MULTIPLE_ORG", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF003", "Verify the getUsageGoals graphql query is showing empty response for selected organization when selected org doen not have usage data", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF004", "Verify the getUsageGoals graphql query is showing organization usage goal  for subdistrict when selected orgId part of sub district.", "SUBDISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.SCHOOL_ADMIN },
                { "tc_OrganizationUsageGoalBFF005", "Verify the getUsageGoals graphql query is showing organization usage goal for school admin when selected orgId is part of school admin .", "SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.SCHOOL_ADMIN },
                { "tc_OrganizationUsageGoalBFF006", "Verify the getUsageGoals graphql query is showing organization usage goal for multiple school admin when selected orgId is part of school admin .", "MULTIPLE_SCHOOL_ADMIN",
                        CommonAPIConstants.STATUS_CODE_OK, Admins.MULTI_SCHOOL_ADMIN } };
        return inputData;
    }

    /**
     * This method is used to test the Organization Usage BFF.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "organizationUsageGoalNegativeScenario", groups = { "OrganizationUsageBFF", "SMK-58859", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        String adminUserName = null;
        String adminAccessToken = null;
        String adminDetails = null;
        String adminUserId = null;
        String adminOrgId = null;
        List<String> organizationIds = new ArrayList<>();

        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.multiSchoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.DISTRICT_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.districtAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.districtAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = orgId;
        } else if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.schoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.subDistrictAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "userId" );
            organizationIds = Arrays.asList( SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" ) );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SAVVAS_ADMIN ) ) {
            adminDetails = savvasAdminDetails;
            adminAccessToken = savvasAdminToken;
            adminUserName = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
            adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
            Log.message( "Savvas admin details are " + adminDetails );
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }

        Log.message( "Admin passed in the test case is " + adminUserName );
        Log.message( "Admin access token is " + adminAccessToken );
        Log.message( "Admin details are " + adminDetails );
        Log.message( "Admin userId is " + adminUserId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        switch ( scenario ) {
            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, "Bearer invlaid" );
                response = new Dashboard().postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "INVALID_USER_ID":
                response = new Dashboard().postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId + "invalid", configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "INVALID_ORG_ID":
                response = new Dashboard().postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) + "invalid", false );
                Log.message( response.getBody().asString() );
                break;

            case "EMPTY_USER_ID":
                response = new Dashboard().postOrganizationUsageGoalBFF( headers, organizationIds, "", configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "EMPTY_ORG_ID":
                response = new Dashboard().postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, "", false );
                Log.message( response.getBody().asString() );
                break;

            case "WITH_SAVVAS_ADMIN_CREDENTIAL":
                organizationIds = Arrays.asList( orgId );
                response = new Dashboard().postOrganizationUsageGoalBFF( headers, organizationIds, adminUserId, SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgId" ), false );
                Log.message( response.getBody().asString() );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );
        String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );

        if ( scenario.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenario.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_USERID ), "Getting error message for empty userId", "Not getting proper error message for empty userId" );
        } else if ( scenario.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_ORGID ), "Getting error message for empty orgId", "Not getting proper error message for empty orgId" );
        }
    }

    @DataProvider ( name = "organizationUsageGoalNegativeScenario" )
    public Object[][] organizationUsageGoalNegativeScenario() {

        Object[][] inputData = { { "tc_OrganizationUsageGoalBFF011", "Verify \"401: UnAuthorized\" message in response when invalid Bearer token is given", "INVALID_BEARER_TOKEN", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF012", "Verify \"401: UnAuthorized\" and response when invalid userId is given in the query", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF013", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF014", "Verify the message in response when empty userId is given in the query", "EMPTY_USER_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF015", "Verify the message in response when empty org-id is given in the query", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoalBFF016", "Verify the status code and reponse for the savvas admin credential.", "WITH_SAVVAS_ADMIN_CREDENTIAL", CommonAPIConstants.STATUS_CODE_OK, Admins.SAVVAS_ADMIN } };
        return inputData;
    }

    // This method is extracting error message from response
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        Log.message( "Course name is " + courseName );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 2 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "95", "2", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "31" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 2 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "95", "2", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "31" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

}
