package com.savvas.sm.admin.ui.tests.SmokeSuite;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.AuditHistory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

public class AuditHistorySmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String schoolName;
    private String teacherDetails;
    private String districtAdminUserName;
    private String subdDistrictAdminUserName;
    private String schoolAdminUserName;
    private String teacherId;
    private String teacherUsername;
    private String studentDetails;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String courseName;
    public String subDistrictCourseName;
    Map<String, String> headers = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        // Getting district admin details from RBS Datasetup
        districtAdminUserName = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        subdDistrictAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        schoolAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );

        // Getting teacher details
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( schoolName );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentDetails = RBSDataSetup.getMyStudent( schoolName, teacherUsername );

        courseName = "Custom Course_1" + System.nanoTime();
        // Creating custom course
        String courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( schoolName ), DataSetupConstants.SETTINGS,
                courseName );
        Log.message( "Custom course is created successfully!!!" );

        // Assigning an assignment
        assignmentDetails.put( AdminAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolName ) );
        assignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        new AssignmentAPI().assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) ), "users" );
        Log.message( "Assigned an assignment to the Student" );

        // Deleting an assignment
        HashMap<String, String> deleteAssignment = new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        Log.message( "Assignment is deleted successfully!!!" );

        //=========Sub District teachers,students,courses and assignments
        //Creating teacher and student for subdistrict school
        String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
        String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

        //creating student
        String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
        String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
        String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

        //Creating group  for above created teacher & student
        new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        subDistrictCourseName = "Custom Course_2" + System.nanoTime();
        // Creating custom course
        String custoCourseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( schoolName ), DataSetupConstants.SETTINGS,
                subDistrictCourseName );
        Log.message( "Custom course is created successfully!!!" );

        //Assigning the assignment
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, custoCourseId );
        new AssignmentAPI().assignAssignmentToSingleStudent( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), "users" );
        Log.message( "Assigned an assignment to the Student" );

        // Deleting an assignment
        new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        Log.message( "Assignment is deleted successfully!!!" );

    }

    @Test ( description = "Verify the audit history page is displayed for district admins", groups = { "smoke_test_case", "Audit History", "Admin_TC10" }, priority = 1 )
    public void tcSMAdminAuditHistorySmoke001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistorySmoke001: Verify the audit history page is displayed for district admins <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( districtAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            //select organization in organization dropdown
            auditHistoryPage.selectOrganizationByName( schoolName );

            Log.assertThat( auditHistoryPage.verifyAuditHistoryinSubNavigation(), "The Audit History Page is displayed in Left navigation bar", "The Audit History Page is not displayed in Left navigation bar" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "The Column Headers are displayed", "The Column Headers are not displayed" );
            Log.assertThat( auditHistoryPage.getRowValues().get( courseName ).get( "assignmentTitle" ).equals( courseName ), "Deleted assignment is displayed in Audit History page successfully!!!",
                    "Deleted assignment is not displayed in Audit History page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the audit history page is displayed for sub district admins", groups = { "smoke_test_case", "Audit History", "Admin_TC11" }, priority = 1 )
    public void tcSMAdminAuditHistorySmoke002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistorySmoke002: Verify the audit history page is displayed for sub district admins<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( subdDistrictAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            //select organization in organization dropdown
            auditHistoryPage.selectOrganizationByName( RBSDataSetup.SchoolUnderSubDistrict );

            Log.assertThat( auditHistoryPage.verifyAuditHistoryinSubNavigation(), "The Audit History Page is displayed in Left navigation bar", "The Audit History Page is not displayed in Left navigation bar" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "The Column Headers are displayed", "The Column Headers are not displayed" );
            Log.message( "Audit history getRowValues" + auditHistoryPage.getRowValues() );

            Log.assertThat( auditHistoryPage.getRowValues().get( subDistrictCourseName ).get( "assignmentTitle" ).equals( subDistrictCourseName ), "Deleted assignment is displayed in Audit History page successfully!!!",
                    "Deleted assignment is not displayed in Audit History page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the audit history page is displayed for school district admins", groups = { "smoke_test_case", "Audit History", "Admin_TC12" }, priority = 1 )
    public void tcSMAdminAuditHistorySmoke003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistorySmoke003: Verify the audit history page is displayed for school district admins<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( schoolAdminUserName, password );

            // Navigating to Audit History Page
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            //select organization in organization dropdown
            auditHistoryPage.selectOrganizationByName( schoolName );

            Log.assertThat( auditHistoryPage.verifyAuditHistoryinSubNavigation(), "The Audit History Page is displayed in Left navigation bar", "The Audit History Page is not displayed in Left navigation bar" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "The Column Headers are displayed", "The Column Headers are not displayed" );
            Log.assertThat( auditHistoryPage.getRowValues().get( courseName ).get( "assignmentTitle" ).equals( courseName ), "Deleted assignment is displayed in Audit History page successfully!!!",
                    "Deleted assignment is not displayed in Audit History page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
