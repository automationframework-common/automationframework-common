package com.savvas.sm.admin.ui.pages;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SettingPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;

public class MSDASettingsPopupPage extends LoadableComponent<MSDASettingsPopupPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    //*******************Success Maker Setting MSDA Popup page*******************//

    @FindBy ( css = ".msda-modal .dialog-wrapper" )
    WebElement MSDAEditPopup;

    @FindBy ( css = "[title='Math Screener & Diagnostic Assessments']" )
    WebElement popupHeader;

    @FindBy ( css = ".top-section .description" )
    WebElement popupDescription;

    @FindBy ( css = ".top-section .list-header" )
    WebElement popupListHeader;

    @FindBy ( css = "[aria-label='question circle']" )
    WebElement infoIcon;

    @FindBy ( css = ".searchBar__form input" )
    WebElement searchBar;

    @FindBy ( css = "msda-popup div.list" )
    WebElement organizationList;

    @FindBy ( css = "p.organization-name" )
    List<WebElement> organizationNameList;

    @FindBy ( css = ".list-header cel-button" )
    WebElement btnTurnAllOnOff;

    @FindBy ( css = ".msda-toggle button" )
    List<WebElement> organizationToggleBtn;

    @FindBy ( css = "msda-popup .toggle-on" )
    List<WebElement> toggleON;

    @FindBy ( css = "msda-popup .toggle-off" )
    List<WebElement> toggleOFF;

    @FindBy ( css = "msda-popup .cancel-btn" )
    WebElement btnCancel;

    @FindBy ( css = "msda-popup .save-btn" )
    WebElement btnSave;

    @FindBy ( css = "p.no-result" )
    WebElement invalidSearchResult;

    @FindBy ( css = "#dialogHeaderClose" )
    WebElement closeIconRoot;

    @FindBy ( css = "cel-loading-spinner.hydrated" )
    WebElement spinnerIcon;

    @FindBy ( css = "switch-button label" )
    List<WebElement> toggleLabelsForEachSchool;

    //*********************Child elements****************************//

    public static String btnSecondary = ".secondary_button";
    public static String toggleStatus = "label.label";
    public static String toggleButton = "button.switch-button";
    public static String innerIcon = "img.icon-inner";

    //***************************All Common methods*******************************//

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public MSDASettingsPopupPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        new WebDriverWait( driver, Duration.ofSeconds( 20 ) ).until( ExpectedConditions.visibilityOf( popupHeader ) );

    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, popupHeader );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, popupHeader, 10 ) ) {
            Log.message( "MSDA Edit Popup page loaded successfully." );
        } else {
            Log.fail( "MSDA Edit Popup page did not load." );
        }

    }

    /**
     * To verify MSDA edit popup header and description
     * 
     * @return
     */
    public boolean verifyMSDAPopupHeaderAndDescription() {
        SMUtils.waitForElement( driver, popupHeader );
        Log.message( "Verifying MSDA popup header and description are same as excepted" );
        return ( popupHeader.getText().trim().equals( SettingPage.MSDA_POPUP_HEADER ) && popupDescription.getText().trim().equals( SettingPage.MSDA_POPUP_DESCRIPTION ) && popupListHeader.getText().trim().equals( SettingPage.MSDA_POPUP_LIST_HEADER ) );
    }

    /**
     * To verify the presence of Search Box in MSDA edit popup
     * 
     * @return
     */
    public boolean isSearchBarPresent() {
        SMUtils.waitForElement( driver, searchBar );
        Log.message( "Verifying Search Bar and its placeholder are present in MSDA popup" );
        return SMUtils.isElementPresent( searchBar ) && searchBar.getAttribute( SMUtils.PLACEHOLDER ).equals( SettingPage.SEARCH_BAR_PLACEHOLDER );
    }

    /**
     * To verify the presence of Turn All On/Off button
     * 
     * @return
     */
    public boolean isTurnAllOnOffBtnPresent() {
        SMUtils.waitForElement( driver, btnTurnAllOnOff );
        Log.message( "Verifying Turn All button is present or not" );
        return SMUtils.isElementPresent( btnTurnAllOnOff );
    }

    /**
     * To verify the presence of Organization list
     * 
     * @return
     */
    public boolean isOrganizationListPresent() {
        SMUtils.waitForElement( driver, organizationList );
        Log.message( "Verifying Organization List is present in MSDA edit popup" );
        return ( SMUtils.isElementEnabled( organizationList ) );
    }

    /**
     * To verify the presence of toggle button for all organizations
     * 
     * @return
     */
    public boolean verifyPresenceOfToggleBtnForAllOrganizations() {
        SMUtils.waitForElement( driver, organizationList );
        Log.message( "Verifying toggle button is present for all organizations" );
        return organizationToggleBtn.stream().allMatch( element -> SMUtils.isElementPresent( element ) );
    }

    /**
     * To verify the presence of Save and Cancel button
     * 
     * @return
     */
    public boolean isCancelAndSaveBtnPresent() {
        SMUtils.waitForElement( driver, btnCancel );
        Log.message( "Verifying Cancel and Save button is present in MSDA edit popup" );
        return ( SMUtils.isElementEnabled( btnCancel ) && SMUtils.isElementPresent( btnSave ) );
    }

    /**
     * To Turn ON MSDA settig for all organizations
     * 
     * @return
     */
    public boolean clickTurnAllOn() {
        SMUtils.waitForElement( driver, btnTurnAllOnOff );
        if ( btnTurnAllOnOff.getText().trim().equals( SettingPage.TURN_ALL_OFF ) ) {
            SMUtils.click( driver, btnTurnAllOnOff );
            Log.message( "Turn All toggle button is turned ON" );
        } else {
            Log.message( "Turn All toggle button is already turned ON" );
        }
        return SMUtils.verifyWebElementTextEquals( btnTurnAllOnOff, SettingPage.TURN_ALL_ON );
    }

    /**
     * To Turn OFF MSDA settig for all organizations
     * 
     * @return
     */
    public boolean clickTurnAllOFF() {
        SMUtils.waitForElement( driver, btnTurnAllOnOff );
        if ( btnTurnAllOnOff.getText().trim().equals( SettingPage.TURN_ALL_ON ) ) {
            SMUtils.click( driver, btnTurnAllOnOff );
            Log.message( "Turn All toggle button is turned OFF" );
        } else {
            Log.message( "Turn All toggle button is already turned OFF" );
        }
        return SMUtils.verifyWebElementTextEquals( btnTurnAllOnOff, SettingPage.TURN_ALL_OFF );
    }

    /**
     * To Turn ON MSDA settig for all organizations using toggle button
     */
    public void turnOnMSDAForAllOrganization() {
        SMUtils.waitForElement( driver, organizationList );
        try {
            toggleOFF.stream().forEach( element -> SMUtils.click( driver, element ) );
            Log.message( "MSDA is turned ON for all organizations" );

        } catch ( Exception e ) {
            Log.message( "MSDA is already turned ON for all organizations" );
        }
    }

    /**
     * To Turn OFF MSDA settig for all organizations using toggle button
     */
    public void turnOffMSDAForAllOrganization() {
        SMUtils.waitForElement( driver, organizationList );
        try {
            toggleON.stream().forEach( element -> SMUtils.click( driver, element ) );
            Log.message( "MSDA is turned OFF for all organizations" );

        } catch ( Exception e ) {
            Log.message( "MSDA is already turned OFF for all organizations" );
        }
    }

    /**
     * To get Turn All button text
     * 
     * @return
     */
    public String getTurnAllToggleTxt() {
        SMUtils.waitForElement( driver, btnTurnAllOnOff );
        return btnTurnAllOnOff.getText().trim();
    }

    /**
     * To get list of organizations in MSDA edit popup
     * 
     * @return
     */
    public List<String> getOrganizationNameList() {
        SMUtils.waitForElement( driver, organizationList );
        Log.message( "Getting organization name list from MSDA edit popup" );
        return organizationNameList.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To Turn ON MSDA setting for given organization
     * 
     * @param orgName
     */
    public void turnOnMSDAForGivenOrganziation( String orgName ) {
        SMUtils.waitForElement( driver, organizationList );
        organizationNameList.stream().forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( orgName ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                if ( parentElement.findElement( By.cssSelector( toggleStatus ) ).getText().trim().equals( Constants.OFF ) ) {
                    SMUtils.click( driver, parentElement.findElement( By.cssSelector( toggleButton ) ) );
                    Log.message( "MSDA is turned ON for given organization" );
                } else {
                    Log.message( "MSDA is already turned ON for given organization" );
                }
            }
        } );
    }

    /**
     * To Turn OFF MSDA setting for given organization
     * 
     * @param orgName
     */
    public void turnOffMSDAForGivenOrganziation( String orgName ) {
        SMUtils.waitForElement( driver, organizationList );
        organizationNameList.stream().forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( orgName ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                if ( parentElement.findElement( By.cssSelector( toggleStatus ) ).getText().trim().equals( Constants.ON ) ) {
                    SMUtils.click( driver, parentElement.findElement( By.cssSelector( toggleButton ) ) );
                    Log.message( "MSDA is turned OFF for the given organization : " + orgName );
                } else {
                    Log.message( "MSDA is already turned OFF for the given organization : " + orgName );
                }
            }
        } );
    }

    /**
     * To verify toggle ON button color and text
     * 
     * @return
     */
    public boolean verifyToggleONColorAndTxt() {
        SMUtils.waitForElement( driver, organizationList );
        Log.message( "Veifying Color and Text for toggle ON button" );
        return toggleON.stream().allMatch( btnON -> {
            try {
                WebElement parentElement = btnON.findElement( By.xpath( "./.." ) );
                parentElement.findElement( By.cssSelector( toggleStatus ) ).getText().trim().equals( Constants.ON );
                return SMUtils.checkCssValueBackground( btnON, SettingPage.TOGGLE_ON_COLOR );
            } catch ( Exception e ) {
                e.printStackTrace();
            }
            return false;
        } );
    }

    /**
     * To verify toggle OFF button color and text
     * 
     * @return
     */
    public boolean verifyToggleOFFColorAndTxt() {
        SMUtils.waitForElement( driver, organizationList );
        Log.message( "Veifying Color and Text for toggle OFF button" );
        return toggleOFF.stream().allMatch( btnON -> {
            try {
                WebElement parentElement = btnON.findElement( By.xpath( "./.." ) );
                parentElement.findElement( By.cssSelector( toggleStatus ) ).getText().trim().equals( Constants.OFF );
                return SMUtils.checkCssValueBackground( btnON, SettingPage.TOGGLE_OFF_COLOR );
            } catch ( Exception e ) {
                e.printStackTrace();
            }
            return false;
        } );
    }

    /**
     * To enter the value in search box
     * 
     * @param value
     */
    public void enterValuesInSearchBar( String value ) {
        SMUtils.waitForElement( driver, searchBar );
        SMUtils.enterValue( searchBar, value );
        Log.message( value + " is entered in MSDA edit popup search box" );
    }

    /**
     * To get invalid search result message
     * 
     * @return
     */
    public String getInvalidSearchResult() {
        SMUtils.waitForElement( driver, invalidSearchResult );
        Log.message( "Getting invalid search result message" );
        return invalidSearchResult.getText().trim();
    }

    /**
     * To clear the entered value in search box
     */
    public void clearEnteredValue() {
        SMUtils.waitForElement( driver, searchBar );
        searchBar.sendKeys( Keys.CONTROL, "a" );
        searchBar.sendKeys( Keys.DELETE );
        Log.message( "Entered values are cleared in MSDA edit popup search box" );
    }

    /**
     * To click cancel button
     */
    public void clickCancelBtn() {
        SMUtils.waitForElement( driver, btnCancel );
        SMUtils.click( driver, btnCancel );
        Log.message( "Clicked cancel button in MSDA edit popup" );
    }

    /**
     * To verify the presence of MSDA edit popup
     * 
     * @return
     */
    public boolean isMSDAEditPopupDisplayed() {
        SMUtils.waitForElement( driver, infoIcon );
        Log.message( "Verifying MSDA edit popuo is present or not" );
        try {
            SMUtils.nap( 3 ); // Wait is required for MSDA popup to be displayed
            return SMUtils.isElementPresent( MSDAEditPopup );
        } catch ( Exception e ) {
            Log.message( "MSDA edit pop is not present" );
            return false;
        }
    }

    /**
     * To verify all available fields in MSDA edit popup
     * 
     * @return
     */
    public boolean verifyAllAvailableFields() {
        SMUtils.waitForElement( driver, MSDAEditPopup );
        Log.message( "Verifying all avilable fields in MSDA edit popup" );
        verifyMSDAPopupHeaderAndDescription();
        isOrganizationListPresent();
        isTurnAllOnOffBtnPresent();
        verifyPresenceOfToggleBtnForAllOrganizations();
        isCancelAndSaveBtnPresent();
        return true;
    }

    /**
     * To click the close icon in MSDA edit popup
     */
    public void clickCloseIcon() {
        SMUtils.waitForElement( driver, closeIconRoot );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, closeIconRoot, innerIcon ) );
        Log.message( "Clicked close icon in MSDA edit popup" );
    }

    /**
     * To click on the save button
     */
    public void clickSaveButton() {
        Log.message( "Clicking Save button in MSDA Edit pop up" );
        SMUtils.waitForElement( driver, btnSave );
        if ( btnSave.isEnabled() ) {
            SMUtils.click( driver, btnSave );
        } else {
            Log.message( "Save button is disabled" );
        }

    }

    public boolean verifyMSDASettingForGivenOrganization( String orgName ) {
        SMUtils.waitForElement( driver, organizationList );
        SMUtils.nap( 10 );
        AtomicBoolean value = new AtomicBoolean( false );
        organizationNameList.stream().forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( orgName ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                if ( parentElement.findElement( By.cssSelector( toggleStatus ) ).getText().trim().equals( Constants.OFF ) ) {
                    value.set( false );
                } else {
                    value.set( true );
                }
            }
        } );
        return value.get();
    }

    public boolean isTurnAllOnOffButtonEnabled() {
        SMUtils.waitForElement( driver, btnTurnAllOnOff );
        return btnTurnAllOnOff.isEnabled() ? true : false;
    }

    public boolean onOffButtonStatusForEachSchoolAsExpected( String toggleStatusToVerify ) {
        boolean status = false;
        Set<Boolean> flagList = new HashSet<>();
        toggleLabelsForEachSchool.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( toggleStatusToVerify ) ) {
                Log.message( "Toggle status is as expected" );
                flagList.add( true );
            }
        } );
        if ( flagList.size() == 1 ) {
            status = true;
        }
        return status;
    }

}