package com.savvas.sm.admin.admindatasetup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;


public class AdminDataSetupRun extends EnvProperties {

    public String smUrl;
    public String browser;
    public String teacherId;
    public String teacherUsername;
    public String schoolId;

    public static HashMap<String, String> teacherDetails = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> schoolStudentDetails = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> coursesName = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> coursesId = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> assignmentsId = new HashMap<>();

    @Test
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        // Getting school names

        Log.message( "***************** Report data creation started ***************" );

        IntStream.rangeClosed( 1, 2 ).forEach( iteration -> {
            try {
                String school = getSchools( Schools.FLEX_SCHOOL );
                Log.message( "***** Creating data for school: " + school + ": " + " *****" );

                schoolId = RBSDataSetup.organizationIDs.get( school );
                String teacherDetail = RBSDataSetup.orgTeacherDetails.get( school ).get( "Teacher" + iteration );
                teacherDetails.put( school, teacherDetail );
                teacherId = SMUtils.getKeyValueFromResponse( teacherDetail, RBSDataSetupConstants.USERID );
                teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetail, RBSDataSetupConstants.USERNAME );
                Log.message( "Teacher details for " + school + ": " + teacherDetail );

                // Getting Student details
                HashMap<String, String> studentUserNames = new HashMap<>();
                HashMap<String, String> studentRumbaIds = new HashMap<>();
                HashMap<String, String> studentDetails = new HashMap<>();

                if ( Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) >= 5 ) {
                    IntStream.rangeClosed( 1, 5 ).forEach( itr -> {
                        String studentDetail = RBSDataSetup.getMyStudent( school, teacherUsername );
                        studentDetails.put( "Student" + itr, studentDetail );
                        studentUserNames.put( Constants.STUDENT_USERNAME + itr, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );
                        studentRumbaIds.put( Constants.STUDENT_ID + itr, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
                    } );
                } else {
                    Log.fail( "Minimum 5 Students are requires. Give Student count as 5 or more in config.properties!" );
                }
                Log.message( "Student details for " + school + ": " + studentDetails );
                schoolStudentDetails.put( school, studentDetails );

                HashMap<String, String> courseName = new HashMap<>();
                HashMap<String, String> courseIds = new HashMap<>();
                HashMap<String, String> assignmentIds = new HashMap<>();

                if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) || school.equalsIgnoreCase( getSchools( Schools.MATH_SCHOOL ) ) ) {

                    courseName.put( Constants.MATH, AssignmentAPIConstants.MATH_COURSE );
                    courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_MATH, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                    // Creating Math courses
                    Log.message( "***** Creating Math Custom Courses *****" );
                    if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                        courseName.put( Constants.SM_FOCUS_MATH_GRADE1, Constants.SM_FOCUS_MATH_GRADE1 );
                        courseIds.put( Constants.SM_FOCUS_MATH_GRADE1, AssignmentAPIConstants.FOCUS_MATH_1 );
                    }
                    courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
                    courseIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                            DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
                    courseIds.put( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH,
                            teacherId, schoolId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) ) );
                    courseIds.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                            DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
                    courseIds.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId, schoolId,
                            DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );

                    Log.message( "Course details for " + school + ": " + courseIds );

                    Log.message( "**** Assigning Assignments ****" );
                    HashMap<String, String> staffDetails = new HashMap<>();
                    staffDetails.put( AssignmentAPIConstants.ORG_ID, schoolId );
                    staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                    staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, new ArrayList<>( studentRumbaIds.values() ), new ArrayList<>( courseIds.values() ) );

                    JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
                    JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
                    for ( Object assignment : assignmentList ) {
                        JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                        assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
                    }
                    Log.message( "Assignments Id for " + school + ": " + assignmentIds );
                }

                if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) || school.equalsIgnoreCase( getSchools( Schools.READING_SCHOOL ) ) ) {

                    courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
                    courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, String.format( DataSetupConstants.SETTINGS_IPM_ON_COURSE_NAME_READING, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                    courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

                    // Creating Reading courses
                    Log.message( "***** Creating Reading Custom Courses *****" );
                    if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                        courseName.put( Constants.SM_FOCUS_READING_GRADE1, Constants.SM_FOCUS_READING_GRADE1 );
                        courseIds.put( Constants.SM_FOCUS_READING_GRADE1, AssignmentAPIConstants.FOCUS_READING_1 );
                    }
                    courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
                    courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                            DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                    courseIds.put( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE, new CourseAPI().createCustomBySettingIPMOnCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ),
                            DataSetupConstants.READING, teacherId, schoolId, courseName.get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) ) );
                    courseIds.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                            DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                    courseIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.READING, teacherId, schoolId,
                            DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

                    Log.message( "Course details for " + school + ": " + courseIds );

                    Log.message( "**** Assigning Assignments ****" );
                    HashMap<String, String> staffDetails = new HashMap<>();
                    staffDetails.put( AssignmentAPIConstants.ORG_ID, schoolId );
                    staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                    staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                    HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, new ArrayList<>( studentRumbaIds.values() ), new ArrayList<>( courseIds.values() ) );

                    JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
                    JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
                    for ( Object assignment : assignmentList ) {
                        JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                        assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
                    }
                    Log.message( "Assignments Id for " + school + ": " + assignmentIds );
                }

                coursesName.put( school, courseName );
                coursesId.put( school, courseIds );
                assignmentsId.put( school, assignmentIds );

                courseExecutionForFlexSchool();

            } catch ( Exception e ) {
                e.printStackTrace();
            }
        } );

        Log.message( "Teacher Details: " + teacherDetails );
        Log.message( "Student Details: " + schoolStudentDetails );
        Log.message( "Course Name Details: " + coursesName );
        Log.message( "Course Id Details: " + coursesId );
        Log.message( "Assignment Id Details: " + assignmentsId );
        Log.message( "***** Starting the course execution parallelly for all schools *****" );

    }

    public void courseExecutionForFlexSchool() {

        Log.message( "***** Started Math course execution for Flex licensed school *****" );
        // Getting Student Names
        HashMap<String, String> studentMap = schoolStudentDetails.get( getSchools( Schools.FLEX_SCHOOL ) );
        List<String> studentNames = new ArrayList<>();
        studentMap.keySet().stream().forEach( name -> studentNames.add( SMUtils.getKeyValueFromResponse( studentMap.get( name ), Constants.USER_NAME ) ) );
        // Getting Math Course Names
        List<String> mathCourseNameList = new ArrayList<>();
        coursesName.get( getSchools( Schools.FLEX_SCHOOL ) ).values().stream().filter( courseName -> courseName.toLowerCase().contains( Constants.MATH.toLowerCase() ) ).forEach( mathCourseNameList::add );

        IntStream.range( 0, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.size() ).forEach( itr -> {

            IntStream.range( 0, mathCourseNameList.size() ).forEach( iter -> {
                WebDriver driver = WebDriverFactory.get( browser );
                try {
                    LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentNames.get( itr ), RBSDataSetupConstants.DEFAULT_PASSWORD );

                    if ( studentNames.get( itr ).equals( studentNames.get( 0 ) ) || AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "0" ) || AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "10" ) ) {
                        if ( mathCourseNameList.get( iter ).equals( Constants.MATH ) || mathCourseNameList.get( iter ).equals( coursesName.get( getSchools( Schools.FLEX_SCHOOL ) ).get( Constants.CUSTOM_BY_SETTING_IP_ON_MATH_COURSE ) )
                                || mathCourseNameList.get( iter ).equals( coursesName.get( getSchools( Schools.FLEX_SCHOOL ) ).get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) ) {
                            Log.message( studentNames.get( itr ) + " " + mathCourseNameList.get( iter ) );
                            executeCourse( driver, studentNames.get( itr ), mathCourseNameList.get( iter ), true, true, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        } else {
                            Log.message( studentNames.get( itr ) + " " + mathCourseNameList.get( iter ) );

                            executeCourse( driver, studentNames.get( itr ), mathCourseNameList.get( iter ), true, false, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        }
                    } else {
                        Log.message( studentNames.get( itr ) + " " + mathCourseNameList.get( iter ) );

                        executeCourse( driver, studentNames.get( itr ), mathCourseNameList.get( iter ), true, false, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                    }
                } catch ( IOException e ) {
                    e.printStackTrace();
                    driver.close();
                } finally {
                    driver.close();
                }

            } );

        } );
        Log.message( "***** Completed Math course execution for Flex licensed school *****" );

        Log.message( "***** Started Reading course execution for Flex licensed school *****" );
        // Getting Reading Course Names
        List<String> readingCourseNameList = new ArrayList<>();
        coursesName.get( getSchools( Schools.FLEX_SCHOOL ) ).values().stream().filter( courseName -> courseName.toLowerCase().contains( Constants.READING.toLowerCase() ) ).forEach( readingCourseNameList::add );

        IntStream.range( 0, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.size() ).parallel().forEach( itr -> {

            IntStream.range( 0, readingCourseNameList.size() ).forEach( iter -> {
                WebDriver driver = WebDriverFactory.get( browser );
                LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentNames.get( itr ), RBSDataSetupConstants.DEFAULT_PASSWORD );

                try {
                    if ( studentNames.get( itr ).equals( studentNames.get( 0 ) ) || AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "0" ) || AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ).equals( "10" ) ) {
                        if ( readingCourseNameList.get( iter ).equals( Constants.READING ) || readingCourseNameList.get( iter ).equals( coursesName.get( getSchools( Schools.FLEX_SCHOOL ) ).get( Constants.CUSTOM_BY_SETTING_IP_ON_READING_COURSE ) )
                                || readingCourseNameList.get( iter ).equals( coursesName.get( getSchools( Schools.FLEX_SCHOOL ) ).get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) ) {
                            Log.message( studentNames.get( itr ) + " " + readingCourseNameList.get( iter ) );
                            executeCourse( driver, studentNames.get( itr ), readingCourseNameList.get( iter ), false, true, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        } else {
                            Log.message( studentNames.get( itr ) + " " + readingCourseNameList.get( iter ) );
                            executeCourse( driver, studentNames.get( itr ), readingCourseNameList.get( iter ), false, false, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                        }
                    } else {
                        Log.message( studentNames.get( itr ) + " " + readingCourseNameList.get( iter ) );
                        executeCourse( driver, studentNames.get( itr ), readingCourseNameList.get( iter ), false, false, AdminUIConstants.REPORT_EXECUTION_PERCENTAGE.get( itr ) );
                    }
                } catch ( IOException e ) {
                    e.printStackTrace();
                } finally {
                    driver.close();
                }
            } );

        } );
        Log.message( "***** Completed Reading course execution for Flex licensed school *****" );
    }

    /**
     * To execute Math and Reading courses
     * 
     * @param studentUserName
     * @param courseName
     * @param isMath
     * @param isClearIP
     * @param percentage
     * @throws IOException
     */
    public void executeCourse( WebDriver driver, String studentUserName, String courseName, boolean isMath, boolean isClearIP, String percentage ) throws IOException {

        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        try {
                            if ( percentage.equals( "0" ) ) {
                                studentsPage.executeMathCourse( studentUserName, courseName, percentage, "5", "50" );
                            } else {
                                studentsPage.executeMathCourse( studentUserName, courseName, percentage, "5", "35" );
                            }

                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, percentage, "1", "1" );
                }
                studentsPage.logout();
            } catch ( Exception e ) {
                Log.message( "Simulator  error -" + e );
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 2 ).forEach( value -> {
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, percentage, "3", "35" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, percentage, "1", "2" );
                }
                studentsPage.logout();
            } catch ( Exception e ) {
                Log.message( "Simulator  error -" + e );
            }
        }
    }

    /**
     * To get the school Name
     *
     * @param schoolForTest
     * @return
     */
    public static String getSchools( Schools schoolForTest ) {
        try {

            return configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," )[schoolForTest.ordinal()];
        } catch ( Exception e ) {
            Log.message( "Give all the schools required in config.properties! " );
            return null;
        }
    }
}
