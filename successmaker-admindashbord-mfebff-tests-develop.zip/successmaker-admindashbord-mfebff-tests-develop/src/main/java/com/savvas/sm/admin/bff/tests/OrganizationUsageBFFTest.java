package com.savvas.sm.admin.bff.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.admin.admindatasetup.AdminData;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;
import com.savvas.sm.data.CreateAdmins;

import io.restassured.response.Response;

public class OrganizationUsageBFFTest extends EnvProperties {

    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String flexSchool;
    private String mathSchool;
    private String readingSchool;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();

    private List<String> courseIDs = new ArrayList<>();
    private Response response;
    private HashMap<String, String> groupDetails = new HashMap<>();

    private String flexSchoolStudentOneDetails = null;
    private String flexSchoolStudentTwoDetails = null;
    private String flexSchoolStudentThreeDetails = null;
    private String flexSchoolStudentFourDetails = null;
    private String teacherUsername;
    private String mathSchoolTeacherDetails = null;
    private String mathSchoolTeacherOrgId = null;
    private String mathSchoolTeacherId = null;
    private String mathSchoolTeacherUserName = null;
    private String mathSchoolStudentDetails = null;
    private String subdistrictSchoolTeacher;
    private String subdistrictSchoolTeacherID;

    //Tokens
    private String savvasAdminToken = null;
    private String districtAdminToken = null;
    private String subDistrictAdminToken = null;
    private String multiSchoolAdminToken = null;
    private String schoolAdminToken = null;

    //Admin creation
    CreateAdmins createAdminsClass = new CreateAdmins();
    private String districtAdminDetails = null;
    private String savvasAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String multiSchoolAdminDetails = null;
    private String schoolAdminDetails = null;

    //===Details
    public String subDistrictwithoutSchool_name = null;
    public String subDistrictwithSchool_name = null;
    public String subDistrictOrgId_with_school = null;
    public String subDistrictOrgId_without_school = null;
    public String school_under_subDistrictwithSchool_name = null;

    private String districtId = null;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    Dashboard dashboard = new Dashboard();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        RBSUtils rbsUtils = new RBSUtils();

        // Teacher, Student, Assignment and Group details
        teacherUsername = AdminData.teacherDetails.keySet().toArray()[0].toString();
        teacherId = rbsUtils.getUserIDByUserName( teacherUsername );
        orgId = AdminData.orgId;

        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
        school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );

        //Savvas Admin
        savvasAdminDetails = createAdminsClass.createSavvasAdmin( smUrl, districtId, "005" );
        Log.message( "********" );
        Log.message( "savvasAdminDetails from Create Admins are " + savvasAdminDetails );
        Log.message( "********" );
        savvasAdminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
    }

    /**
     * This method is used to test the Organization Usage BFF.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( dependsOnMethods = { "tcorgnizationUsageBFFSmokeTest" }, priority = 1, dataProvider = "organizationUsagePositiveScenario", groups = { "OrganizationUsageBFF", "SMK-51757", "P1", "API" }, alwaysRun = true )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        String adminUserName = null;
        String adminAccessToken = null;
        String adminDetails = null;
        String adminUserId = null;
        String adminOrgId = null;
        List<String> organizationIds = new ArrayList<>();

        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.multiSchoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.DISTRICT_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.districtAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.districtAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = orgId;
        } else if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.schoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.subDistrictAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "userId" );
            organizationIds = Arrays.asList( SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" ) );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SAVVAS_ADMIN ) ) {
            adminDetails = savvasAdminDetails;
            adminAccessToken = savvasAdminToken;
            adminUserName = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
            adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }

        Log.message( "Admin passed in the test case is " + adminUserName );
        Log.message( "Admin access token is " + adminAccessToken );
        Log.message( "Admin details are " + adminDetails );
        Log.message( "Admin userId is " + adminUserId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        switch ( scenario ) {

            case "FOR_MULTIPLE_ORG":
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "SCHOOL_ADMIN":
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "MULTIPLE_SCHOOL_ADMIN":
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "ORGANIZATIN_WITH_ORPHAN_STUDENT":
                //delete Student from all groups
                HashMap<String, String> studentDetails = new HashMap<String, String>();
                studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
                studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( GroupConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( flexSchoolStudentThreeDetails, "userId" ) );
                HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
                List<String> groupIds = new ArrayList<>();
                IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach(
                        iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

                groupIds.stream().forEach( groupId -> {
                    try {
                        new GroupAPI().removeStudentFromGroup( smUrl, SMUtils.getKeyValueFromResponse( flexSchoolStudentThreeDetails, "userId" ), groupId, teacherId, orgId,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                } );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "DELETED_ASSIGNMENT":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                //delete assignment
                HashMap<String, String> assignmentDetail = new HashMap<>();
                assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID,
                        new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( flexSchoolStudentTwoDetails, "userId" ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "PRODUCT_REMOVED_GROUP_ASSIGNMENT":
                String groupName = "Group " + System.nanoTime();
                Log.message( "Group Name -" + groupName );
                //adding the student  to the  group for the  teacher
                String groupId = new GroupAPI().createGroupWithCustomization( groupName, teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( flexSchoolStudentThreeDetails, "userId" ) ), RBSDataSetup.organizationIDs.get( flexSchool ),
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                //Assigning the assignment
                String settingCourseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID,
                        new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId,
                                orgId, DataSetupConstants.SETTINGS, settingCourseName ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //execute course through student dashboard
                executeCourse( SMUtils.getKeyValueFromResponse( flexSchoolStudentThreeDetails, "userName" ), settingCourseName, true, false );

                //Removing Product from group
                new RBSUtils().addProductToClassGraphQL( RBSDataSetup.organizationIDs.get( flexSchool ), groupId, "", adminAccessToken, adminUserId );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "DELETED_GROUP":

                //adding the student to the  group for the  teacher
                String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( flexSchoolStudentFourDetails, "userId" ) ),
                        RBSDataSetup.organizationIDs.get( flexSchool ), new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                //Assigning the assignment
                String courseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID,
                        new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId,
                                orgId, DataSetupConstants.SETTINGS, courseName ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //execute course through student dashboard
                executeCourse( SMUtils.getKeyValueFromResponse( flexSchoolStudentFourDetails, "userName" ), courseName, true, false );

                //delete group with assignment
                new GroupAPI().deleteGroup( newGroupId, teacherId, RBSDataSetup.organizationIDs.get( flexSchool ),
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "DELETED_STUDENT":
                String newStudent = "SchStudent" + System.nanoTime();
                String newStudentDetails = new UserAPI().createUserWithCustomization( newStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) ) );
                String newStudentId = SMUtils.getKeyValueFromResponse( newStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfos = new HashMap<>();
                studentInfos = generateRequestValues( newStudentDetails, studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, UserConstants.TEACHER_ID, teacherId );
                studentInfos = SMUtils.updateRequestBodyValues( studentInfos, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentId );

                //Creating group  for above created teacher & student
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( newStudentId ), RBSDataSetup.organizationIDs.get( flexSchool ),
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newStudentId ), AssignmentAPIConstants.USERS_TYPE );

                executeCourse( newStudent, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, false );

                //delete Student
                new RBSUtils().deleteUser( Arrays.asList( newStudentId ) );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "SUSPENDED_STUDENT":
                String newStudentForSuspend = "SchStudent" + System.nanoTime();
                String newStudentForSuspendDetails = new UserAPI().createUserWithCustomization( newStudentForSuspend, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) ) );
                String newStudentIdForSuspend = SMUtils.getKeyValueFromResponse( newStudentForSuspendDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInformation = new HashMap<>();
                studentInformation = generateRequestValues( newStudentForSuspendDetails, studentInformation, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                studentInformation = SMUtils.updateRequestBodyValues( studentInformation, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                studentInformation = SMUtils.updateRequestBodyValues( studentInformation, UserConstants.TEACHER_ID, teacherId );
                studentInformation = SMUtils.updateRequestBodyValues( studentInformation, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInformation );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentIdForSuspend );

                //Creating group  for above created teacher & student
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( newStudentIdForSuspend ), RBSDataSetup.organizationIDs.get( flexSchool ),
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newStudentIdForSuspend ), AssignmentAPIConstants.USERS_TYPE );

                executeCourse( newStudentForSuspend, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, false );

                //suspend Student
                new RBSUtils().suspendUser( Arrays.asList( newStudentIdForSuspend ) );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + adminAccessToken );
                organizationIds = Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) );
                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        if ( !scenario.equalsIgnoreCase( "ZERO_STATE" ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "OrganizationUsageBFFSchema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }

    }

    @DataProvider ( name = "organizationUsagePositiveScenario" )
    public Object[][] organizationUsagePositiveScenario() {

        Object[][] inputData = {
                { "tc_OrganizationUsageBFF002", "Verify the getOrganizationUsage graphql query is showing student usage for multiple orgId passed in selectedOrg field", "FOR_MULTIPLE_ORG", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF003", "Verify the getOrganizationUsage graphql query is showing empty response for selected organization when selected org doen not have usage data", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF004", "Verify the getOrganizationUsage graphql query is showing student usage for subdistrict when selected orgId part of sub district.", "SUBDISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.SUBDISTRICTWITHSCHOOL_ADMIN },
                { "tc_OrganizationUsageBFF005", "Verify the getOrganizationUsage graphql query is showing student usage for school admin when selected orgId is part of school admin ", "SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.SCHOOL_ADMIN },
                { "tc_OrganizationUsageBFF006", "Verify the getOrganizationUsage graphql query is showing student usage for multiple school admin when selected orgId is part of school admin.", "MULTIPLE_SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.MULTI_SCHOOL_ADMIN } };
        return inputData;
    }

    /**
     * This method is used to test the Organization Usage BFF.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "organizationUsageNegativeScenario", groups = { "OrganizationUsageBFF", "SMK-51757", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        String adminUserName = null;
        String adminAccessToken = null;
        String adminDetails = null;
        String adminUserId = null;
        String adminOrgId = null;
        List<String> organizationIds = new ArrayList<>();

        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.multiSchoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.DISTRICT_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.districtAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.districtAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = orgId;
        } else if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.schoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.subDistrictAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "userId" );
            organizationIds = Arrays.asList( SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" ) );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SAVVAS_ADMIN ) ) {
            adminDetails = savvasAdminDetails;
            adminAccessToken = savvasAdminToken;
            adminUserName = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
            adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
            Log.message( "Savvas admin details are " + adminDetails );
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }

        Log.message( "Admin passed in the test case is " + adminUserName );
        Log.message( "Admin access token is " + adminAccessToken );
        Log.message( "Admin details are " + adminDetails );
        Log.message( "Admin userId is " + adminUserId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        switch ( scenario ) {
            case "INVALID_BEARER_TOKEN":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + "123455" );
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "INVALID_QUERY":
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ), true );
                Log.message( response.getBody().asString() );
                break;

            case "INVALID_USER_ID":
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, adminUserId + "invalid", configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "INVALID_ORG_ID":
                organizationIds = Arrays.asList( "12233455555" );
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, adminUserId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) + "invalid", false );
                Log.message( response.getBody().asString() );
                break;

            case "EMPTY_USER_ID":
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, "", configProperty.getProperty( ConfigConstants.DISTRICT_ID ), false );
                Log.message( response.getBody().asString() );
                break;

            case "EMPTY_ORG_ID":
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, adminUserId, "", false );
                Log.message( response.getBody().asString() );
                break;

            case "WITH_SAVVAS_ADMIN_CREDENTIAL":
                organizationIds = Arrays.asList( orgId );
                response = new Dashboard().postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + " is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );
        String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );

        if ( scenario.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( AdminAPIConstants.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        }
        else if ( scenario.equalsIgnoreCase( "EMPTY_USER_ID" ) ) {
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_USERID ), "Getting error message for empty userId", "Not getting proper error message for empty userId" );
        } else if ( scenario.equalsIgnoreCase( "EMPTY_ORG_ID" ) ) {
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( AdminAPIConstants.INVALID_MESSAGE_FOR_ORGID ), "Getting error message for empty orgId", "Not getting proper error message for empty orgId" );
        } 
    }

    @DataProvider ( name = "organizationUsageNegativeScenario" )
    public Object[][] organizationUsageNegativeScenario() {

        Object[][] inputData = { { "tc_OrganizationUsageBFF013", "Verify \"401: UnAuthorized\" message in response when invalid Bearer token is given", "INVALID_BEARER_TOKEN", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF014", "Verify \"400: Bad Request\" in response when invalid query has been given", "INVALID_QUERY", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF015", "Verify \"401: UnAuthorized\" and response when invalid userId is given in the query", "INVALID_USER_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF016", "Verify 403 status code and response when invalid organizationId is given in the query", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF017", "Verify the message in response when empty userId is given in the query", "EMPTY_USER_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF018", "Verify the message in response when empty org-id is given in the query", "EMPTY_ORG_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF019", "Verify getStudentUsage reponse, if pass the savvas admiin credential.", "WITH_SAVVAS_ADMIN_CREDENTIAL", CommonAPIConstants.STATUS_CODE_OK, Admins.SAVVAS_ADMIN } };
        return inputData;
    }

    /**
     * This method is a smoke test the Organization Usage BFF.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "organizationUsageSmokeScenario", groups = { "OrganizationUsageBFF", "SMK-51757", "P1", "API", "smoke_test_case", "positive_test_case" } )
    public void tcorgnizationUsageBFFSmokeTest( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        String adminUserName = null;
        String adminAccessToken = null;
        String adminDetails = null;
        String adminUserId = null;
        String adminOrgId = null;
        List<String> organizationIds = new ArrayList<>();

        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.multiSchoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.multiSchoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.DISTRICT_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.districtAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.districtAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = orgId;
        } else if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {

            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.schoolAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "userId" );
            organizationIds = Arrays.asList( orgId );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.schoolAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) {
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( AdminData.subDistrictAdmin, password ) );
            adminUserId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "userId" );
            organizationIds = Arrays.asList( SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" ) );
            adminOrgId = SMUtils.getKeyValueFromResponse( AdminData.subDistrictAdminDetails, "primaryOrgId" );
        } else if ( admin.equals( Admins.SAVVAS_ADMIN ) ) {
            adminDetails = savvasAdminDetails;
            adminAccessToken = savvasAdminToken;
            adminUserName = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
            adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }

        Log.message( "Admin userId is " + adminUserId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        switch ( scenario ) {
            case "FOR_SINGLE_ORG":

                /*** Logs starts here ***/
                Log.message( "headers are " + headers.toString() );
                Log.message( "organizationIds are " + organizationIds.toString() );
                Log.message( "adminUserId is " + adminUserId );
                /*** Logs ends here ***/

                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "ZERO_STATE":

                /*** Logs starts here ***/
                Log.message( "headers are " + headers.toString() );
                Log.message( "organizationIds are " + organizationIds.toString() );
                Log.message( "adminUserId is " + adminUserId );
                /*** Logs ends here ***/

                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, adminOrgId, false );
                Log.message( response.getBody().asString() );
                break;

            case "SUBDISTRICT_ADMIN":

                /*** Logs starts here ***/
                Log.message( "headers are " + headers.toString() );
                Log.message( "organizationIds are " + organizationIds.toString() );
                Log.message( "adminUserId is " + adminUserId );
                /*** Logs ends here ***/

                response = dashboard.postOrganizationUsageBFF( headers, organizationIds, adminUserId, subDistrictOrgId_with_school, false );
                Log.message( response.getBody().asString() );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        if ( !scenario.equalsIgnoreCase( "ZERO_STATE" ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "OrganizationUsageBFFSchema", statusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        }

    }

    @DataProvider ( name = "organizationUsageSmokeScenario" )
    public Object[][] organizationUsageSmokeScenario() {

        Object[][] inputData = {
                { "tc_OrganizationUsageBFF001",
                        "Verify the getOrganizationUsage graphql query is showing student usage for selected orgId passed in query & Verify the getOrganizationUsage graphql query should show student usage for custom course(IPM ON/OFF)", "FOR_SINGLE_ORG",
                        CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF003", "Verify the getOrganizationUsage graphql query is showing empty response for selected organization when selected org doen not have usage data", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageBFF004", "Verify the getOrganizationUsage graphql query is showing student usage for subdistrict when selected orgId part of sub district.", "SUBDISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.SUBDISTRICTWITHSCHOOL_ADMIN } };
        return inputData;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "95", "2", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "31" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "95", "2", "31" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "31" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    // This method is extracting error message from response
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    /**
     * To verify the response with DB
     * 
     */
    private void verifyResponseWithDB( String response, List<String> assignmentIds, List<String> studentIds ) {
        Map<String, Map<String, String>> usageDetailsFromResponse = new HashMap<>();
        String reponse = SMUtils.getKeyValueFromResponse( response, "data" );
        String reponseData = SMUtils.getKeyValueFromResponse( reponse, "getOrganizationUsage" );
        IntStream.rangeClosed( 0, 7 ).forEach( iter -> {
            Map<String, String> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( iter );
            subjectUsage.put( StudentUsage.MATH_MINS, jObj.get( StudentUsage.MATH_MINS ).toString() );
            subjectUsage.put( StudentUsage.READING_MINS, jObj.get( StudentUsage.READING_MINS ).toString() );
            usageDetailsFromResponse.put( jObj.get( StudentUsage.WEEK ).toString(), subjectUsage );
        } );
        Map<String, String> individualFields = new HashMap<>();

        individualFields.put( StudentUsage.THIS_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.THIS_WEEK_MINS ) );
        individualFields.put( StudentUsage.LAST_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.LAST_WEEK_MINS ) );
        individualFields.put( StudentUsage.TOTAL_MINTUES, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.TOTAL_MINTUES ) );
        usageDetailsFromResponse.put( "individualFields", individualFields );

        Map<String, Map<String, String>> usageDetailsFromDB = new SqlHelperUsage().getStudentUsage( assignmentIds, studentIds );

        Log.message( "usage Data from Db - " + usageDetailsFromDB );

        Log.assertThat( usageDetailsFromDB.entrySet().stream().allMatch( entry -> {
            if ( entry.getValue().containsKey( StudentUsage.MATH_MINS ) ) {
                int mathDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.MATH_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.MATH_MINS ) );
                int readDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.READING_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.READING_MINS ) );
                return ( mathDeviation >= -1 && mathDeviation <= 1 ) && ( readDeviation >= -1 && readDeviation <= 1 );
            } else if ( entry.getValue().containsKey( StudentUsage.THIS_WEEK_MINS ) ) {
                int thisWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.THIS_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.THIS_WEEK_MINS ) );
                int lastWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.LAST_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.LAST_WEEK_MINS ) );
                int toatalMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.TOTAL_MINTUES ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.TOTAL_MINTUES ) );
                return ( thisWeekMinsDeviation >= -2 && thisWeekMinsDeviation <= 2 ) && ( lastWeekMinsDeviation >= -2 && lastWeekMinsDeviation <= 2 ) && ( toatalMinsDeviation >= -2 && toatalMinsDeviation <= 2 );
            } else {
                return false;
            }
        } ), "Usage data are fetched properly", "Usage data are not fetched properly. Expected -" + usageDetailsFromDB.toString() + ": Actual -" + usageDetailsFromResponse.toString() );
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    /**
     * To get all students from organizations
     * 
     * @param selectedOrganizationIds
     * @param teacherId
     * @param teacherOrgId
     * @param token
     * @return
     * @throws Exception
     */
    public List<String> getAllStudentsFromOrganization( String smUrl, List<String> selectedOrganizationIds, String teacherId, String teacherOrgId, String token ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( UserConstants.USERID, teacherId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.ORGID, teacherOrgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        List<String> studentIds = new ArrayList<>();
        for ( String selectedOrganizationId : selectedOrganizationIds ) {
            String requestBody = String.format( AdminConstants.GET_ALL_STUDENTS_FROM_ORGANIZATION_PAYLOAD, selectedOrganizationId );
            int offsetCount = 0;
            int iter = 0;
            do {
                String body = requestBody.replace( AdminConstants.COUNT, String.valueOf( iter ) );
                HashMap<String, String> post = RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), AdminConstants.GET_STUDENT_END_POINT, body );
                JSONObject jsonObj = new JSONObject( SMUtils.getKeyValueFromResponse( post.get( Constants.REPORT_BODY ), "data" ) );
                if ( iter == 0 ) {
                    Log.message( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ) );
                    offsetCount = Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ) ) / 250;
                    if ( Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ) ) % 250 == 0 ) {
                        offsetCount -= 1;
                    }
                }
                JSONArray ja = jsonObj.getJSONArray( AdminConstants.USER_LIST );
                for ( int arrayCount = 0; arrayCount < ja.length(); arrayCount++ ) {
                    JSONObject jObj = ja.getJSONObject( arrayCount );
                    studentIds.add( jObj.get( Constants.USERID ).toString() );
                }
                iter++;
            } while ( iter <= offsetCount );
        }
        return studentIds;
    }

}