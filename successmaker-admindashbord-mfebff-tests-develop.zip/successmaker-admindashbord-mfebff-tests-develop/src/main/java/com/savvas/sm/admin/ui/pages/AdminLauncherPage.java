package com.savvas.sm.admin.ui.pages;

import static org.testng.AssertJUnit.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;

public class AdminLauncherPage extends LoadableComponent<AdminLauncherPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private final WebDriver driver;
    private String smUrl;
    private String browser;

    // ********* SuccessMaker Launcher/Login Page Elements ***************
    @FindBy ( id = "launchButton" )
    WebElement smLaunchButton;

    @FindBy ( id = "username" )
    WebElement elementUsername;

    @FindBy ( id = "password" )
    WebElement elementPassword;

    @FindBy ( className = "btn-submit" )
    WebElement elementSignInButton;

    @FindBy ( id = "splashImg" )
    WebElement imgSuccessMaker;

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public AdminLauncherPage( WebDriver driver, String url ) {
        this.driver = driver;
        smUrl = url;
        PageFactory.initElements( driver, this );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Override
    protected void isLoaded() {
        assertTrue( "HomePage is not loaded!", driver.getCurrentUrl().contains( smUrl ) );

        if ( browser.toLowerCase().contains( "safari" ) ) { // SMK-44058 -
                                                            // Inconsistent issue on
                                                            // clicking Enter here
                                                            // in Safari browser
            if ( SMUtils.waitForElement( driver, elementSignInButton ) ) { // So
                                                                           // Launching
                                                                           // login
                                                                           // page
                                                                           // directly
                                                                           // only
                                                                           // on
                                                                           // safari
                Log.message( "SM Login page loaded successfully!" );
            } else {
                Log.fail( "SM login page did not load." );
            }
        } else {
            if ( SMUtils.waitForElement( driver, smLaunchButton ) ) {
                Log.message( "SM Pre-Login page loaded successfully!" );
            } else {
                Log.fail( "SM pre-login page did not load." );
            }
        }
    }

    @Override
    protected void load() {
        if ( browser.toLowerCase().contains( "safari" ) ) {
            driver.get( configProperty.getProperty( ConfigConstants.SSO_URL ) + "/sso/login?profile=eb&k12int=true&service=" + smUrl + "/lms/sso.view" ); // SMK-44058
                                                                                                                                                          // -
                                                                                                                                                          // Inconsistent
                                                                                                                                                          // issue
                                                                                                                                                          // on
                                                                                                                                                          // clicking
                                                                                                                                                          // Enter
                                                                                                                                                          // here
                                                                                                                                                          // in
                                                                                                                                                          // Safari
                                                                                                                                                          // browser
        } else { // So Launching login page directly only on safari
            driver.get( smUrl );
        }
        Log.message( "Hit the SM Instance Url - " + smUrl );
    }

    /**
     * To login to SM application
     * 
     * @param username
     * @param password
     * @return
     */
    public SMDashBoardPage loginToSM( String username, String password ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        if ( configProperty.getProperty( "isExecutionInMFE" ).equalsIgnoreCase( "true" ) ) {
            loadMFEPage();
        } else {
            new WebDriverWait( driver, Duration.ofSeconds( 30 ) ).until( ExpectedConditions.frameToBeAvailableAndSwitchToIt( "successmakerIframe" ) );
        }

        return new SMDashBoardPage( driver ).get();
    }

    /**
     * To login to SM application as savvas admin
     * 
     * @param username
     * @param password
     * @return
     */
    public SharedCoursesListViewPage loginToSM( String username, String password, String orgID ) {
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchSM(); // To Navigate from Launcher Page to SSO Login Page.
        }
        enterCredentials( username, password );
        loadMFEPage( orgID );
        return new SharedCoursesListViewPage( driver ).get();
    }

    /**
     * To load MFE page
     * 
     */
    private void loadMFEPage() {
        try {
            driver.get( AdminUIConstants.MFEURL );
            Log.message( "MFE Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE url not loaded" );
        }
    }

    /**
     * To load MFE page
     * 
     */
    private void loadMFEPage( String orgID ) {
        try {
            driver.get( AdminUIConstants.MFEURL + "/shared-courses?selectedOrgId=" + orgID );
            Log.message( "MFE Url loaded" );
        } catch ( Exception e ) {
            Log.message( "MFE url not loaded" );
        }
    }

    /***
     * Click Enter here to launch the SSO Login Page
     * 
     */
    private void launchSM() {
        try {
            SMUtils.waitForElement( driver, smLaunchButton );
            SMUtils.clickJS( driver, smLaunchButton );
            //WebDriverWait wait = new WebDriverWait( driver, 10 );
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
            wait.until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            SMUtils.switchWindow( driver );
            Log.message( "Enter Here in launcher Page is clicked Successfully" );
        } catch ( Exception e ) {
            Log.message( "Unable to click Enter Here button in Launcher Page" );
        }
    }

    /**
     * To enter the credentials in SM application
     * 
     * @param username
     * @param password
     */
    private void enterCredentials( String username, String password ) {
        try {
            WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
            wait.until( ExpectedConditions.visibilityOf( elementUsername ) );
            elementUsername.clear();
            elementUsername.sendKeys( username );
            Log.event( "Entered userName - " + username );

            wait.until( ExpectedConditions.visibilityOf( elementPassword ) );
            elementPassword.clear();
            elementPassword.sendKeys( password );
            Log.event( "Entered Password - " + password );
            WebDriverWait waitdriver = new WebDriverWait( driver, Duration.ofSeconds( 10 ) );
            waitdriver.until( ExpectedConditions.elementToBeClickable( elementSignInButton ) );
            SMUtils.clickJS( driver, elementSignInButton );

            Log.message( "Logged into SM Application" );
        } catch ( Exception e ) {
            Log.message( "Unable to login to the SM Application" );
        }

    }

}