package com.savvas.sm.admin.ui.tests;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.MSDASettingsPopupPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.admin.util.DevToolsUtils;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.Dashboard;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.SettingPage;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import com.savvas.sm.data.CreateAdmins;

public class MSDASettingsPopupTest extends EnvProperties {

    private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    private String districtId;
    private String orgId;
    private String flexSchool;
    private String configGraphQL;
    
    //Admin creation
    
    private String districtAdminDetails = null;
    private String subDistrictAdminDetails = null;
    private String subDistrictAdminDetails2 = null;
    private String schoolAdminDetails = null;

    //===Details
    public static String subDistrictwithoutSchool_name = null;
    public static String subDistrictwithSchool_name = null;
    public static String subDistrictOrgId_with_school = null;
    public static String subDistrictOrgId_without_school = null;
    
    @BeforeClass (alwaysRun=true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( "district_ID" );
        configGraphQL = "https://sm-admin-dashboard-bff-srv-stack-dev.smdemo.info/graphql";
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        
        CreateAdmins createAdminsClass = new CreateAdmins();
       
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        
        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name );
     
      //Admin Creation for District
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "054" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "********" );
        
      //Sub-District Admin Creation
        subDistrictAdminDetails = createAdminsClass.createSubDistrictAdminWithSchool( smUrl, subDistrictOrgId_with_school, "98" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetailsfrom Create Admins are " + subDistrictAdminDetails );
        Log.message( "********" );
     
      //Sub-District Admin without School creation
        subDistrictAdminDetails2 = createAdminsClass.createSubDistrictAdminWithoutSchool( smUrl, subDistrictOrgId_without_school, "99" );
        Log.message( "********" );
        Log.message( "subDistrictAdminDetails without school from Create Admins are " + subDistrictAdminDetails2 );
        Log.message( "********" );
        
        
       //School Admin
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "053" );
        Log.message( "********" );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );
        
        
    }
    
    @Test ( description = "Verify MSDA Setting Edit Popup Page with all fields.", groups = { "SMK-51836", "AdminDashboard", "MSDASettingEditPopup", "mock" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup001(ITestContext context) throws Exception {
        // Get driver
    	final WebDriver driver = WebDriverFactory.get( browser );
    	DevTools tools = null;
        
        Log.testCaseInfo( "tcSMMSDAEditPopup001: Verify MSDA Setting Edit Popup Page with all fields. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
        	smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM(username, password );
            if ( DevToolsUtils.isMock( context ) ) {
        		Log.testCaseInfo(
        				"tc001: Verify the organization list count matches with the mocked organiczation list count when we use more than one organization and login as district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
    			
    			String json = DevToolsUtils.readJsonResponse("MSDAOrgList2.json");
    			Log.message(json);
    			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetMSDAOrgList", "post",json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());
        	} 
            
            // Navigatig to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );
            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-17942: Verify District customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.assertThat( popupPage.isMSDAEditPopupDisplayed(), "District customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings",
                    "District customer admin cannot navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17946: Verify Search field is available for searching organization" );
            Log.assertThat( popupPage.isSearchBarPresent(), "Search bar is present in MSDA popup", "Search bar is present in MSDA popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17945: Verify the fields available in 'Math Screenerr & Diagnostic Assessments' popup" );
            Log.assertThat( popupPage.verifyAllAvailableFields(), "All fields are available in MSDA edit popup", "All fields are not available in MSDA edit popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17952: Verify 'Turn All Off' button should exists when all the organizations are selected already" );
            popupPage.turnOnMSDAForAllOrganization();
            Log.assertThat( popupPage.getTurnAllToggleTxt().equals( SettingPage.TURN_ALL_OFF ), "Turn All Off toggle button is present when all the organizations are already selected",
                    "Turn All Off toggle button is not present when all the organizations are already selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17951: Verify 'Turn All On' button should exists when none of the organizations are selected so far" );
            popupPage.turnOffMSDAForAllOrganization();
            Log.assertThat( popupPage.getTurnAllToggleTxt().equals( SettingPage.TURN_ALL_ON ), "Turn All On toggle button is present when none of the organizations are selected",
                    "Turn All On toggle button is not present when none of the organizations are selected" );
            Log.testCaseResult();

            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();
            
            SMUtils.logDescriptionTC( "SMK-17953: Verify 'Turn All On' button should exists when few of the organizations are selected so far" );
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 0 ) );
            popupPage.turnOnMSDAForGivenOrganziation( orgList.get( 1 ) );
            Log.assertThat( popupPage.getTurnAllToggleTxt().equals( SettingPage.TURN_ALL_ON ), "Turn All On toggle button is present when few organizations are selected", "Turn All On toggle button is not present when few organizations are selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17954: Verify toggle button is displayed in blue color with text 'ON' when organization is selected for MSDA" );
            Log.assertThat( popupPage.verifyToggleONColorAndTxt(), "Color and text are same as excepted for toggle ON button", "Color and text are not same as excepted for toggle ON button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17955: Verify toggle button is displayed in grey color with text 'Off' when organization is deselected for MSDA" );
            Log.assertThat( popupPage.verifyToggleOFFColorAndTxt(), "Color and text are same as excepted for toggle OFF button", "Color and text are not same as excepted for toggle OFF button" );
            Log.testCaseResult();
        	

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if (null != tools) {
                RequestMockUtils.closeMock(tools);
            }
            driver.quit();
        }
    }
    @Test ( description = "Verify Search Bar Functionality in MSDA Setting Edit Popup Page.", groups = { "SMK-51836", "AdminDashboard", "MSDASettingEditPopup", "mock" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup002(ITestContext context) throws Exception {
        // Get driver
    	final WebDriver driver = WebDriverFactory.get( browser );
    	DevTools tools = null;

        Log.testCaseInfo( "tcSMSettingsMSDAEditPopup002: Verify Search Bar Functionality in MSDA Setting Edit Popup Page. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        
        try {
        	//Login to Admin dashboard
        	 smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
             dashBoardPage = smLoginPage.loginToSM(  username, password);
        	
             if ( DevToolsUtils.isMock( context ) ) {
        		Log.testCaseInfo(
        				"tc002: Verify the organization list count matches with the mocked organiczation list count when we login as sub district admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
    			
    			String json = DevToolsUtils.readJsonResponse("MSDAOrgSubDistrtct.txt");
    			Log.message(json);
    			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetMSDAOrgList", "post",json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());
        	}
           
            // Navigatig to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );
            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-17943: Verify Sub District customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.assertThat( popupPage.isMSDAEditPopupDisplayed(), "Sub District customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings",
                    "Sub District customer admin cannot navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.testCaseResult();

            // Getting list of organizations
            List<String> orgList = popupPage.getOrganizationNameList();

            SMUtils.logDescriptionTC( "SMK-17957: Verify matched organization will list when valid single keyword is searched" );
            String singleWord = orgList.get( 0 ).split( " ", 2 )[0];
            List<String> exceptedList = orgList.stream().filter( word -> word.toLowerCase().contains( singleWord.toLowerCase() ) ).collect( Collectors.toList() );
            popupPage.enterValuesInSearchBar( singleWord );
            Log.assertThat( exceptedList.containsAll( popupPage.getOrganizationNameList() ), "Matched organizatios are listing when valid single keyword is searched", "Matched organizatios are not listing when valid single keyword is searched" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17958: Verify matched organization will list when valid keyword which has space is given" );
            SMUtils.logDescriptionTC( "SMK-17959: Verify matched organization will list when valid keyword which has 2 white spaces is given" );
            String doubleWord = orgList.get( 0 ).split( " ", 2 )[0];
            List<String> expList = orgList.stream().filter( word -> word.toLowerCase().contains( doubleWord.toLowerCase() ) ).collect( Collectors.toList() );
            popupPage.enterValuesInSearchBar( doubleWord );
            Log.assertThat( expList.containsAll( popupPage.getOrganizationNameList() ), "Matched organizatios are listing when valid keyword which has space is searched",
                    "Matched organizatios are not listing when valid keyword which has space is searched" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17960: Verify 'No results found' text appears when invalid keyword is given" );
            popupPage.enterValuesInSearchBar( Dashboard.INVALID_ORGNAME );
            Log.assertThat( popupPage.getInvalidSearchResult().equals( SettingPage.INVLAID_SEARCH_RESULT ), "'No results found' text is displayed when invalid keyword is given", "'No results found' text is not displayed when invalid keyword is given" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17961: Verify organization list will reset to all the organization when given search keyword is reset" );
            popupPage.clearEnteredValue();
            Log.assertThat( orgList.equals( popupPage.getOrganizationNameList() ), "All organizations are listed when given keyword is cleared", "All organizations are not listed when given keyword is cleared" );
            Log.testCaseResult();
            
            // Login as sub district admin without school 
            final WebDriver driver1 = WebDriverFactory.get( browser );
            username= SMUtils.getKeyValueFromResponse( subDistrictAdminDetails2, RBSDataSetupConstants.USERNAME );
            smLoginPage = new AdminLauncherPage( driver1, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigate to MSDA Setting Popup Page
            settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );
            // Initialising MSDA Setting Popup Page Elements
            popupPage = new MSDASettingsPopupPage( driver1 );
            SMUtils.logDescriptionTC("SMK-17949:Verify subdistrict alone available in the organization list when sub district customer admin is not having child school and he can access the MSDA Edit popup");
            Log.assertThat( popupPage.isMSDAEditPopupDisplayed(),"Sub District customer admin without school can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings",
                    "Sub District customer admin wihtout school cannot navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.testCaseResult();
        	
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if (null != tools) {
                RequestMockUtils.closeMock(tools);
            }
            driver.quit();
        }
    }
    @Test ( description = "Verify MSDA Setting Edit Popup Functionality.", groups = { "SMK-51836", "AdminDashboard", "MSDASettingEditPopup", "mock" }, priority = 1 )
    public void tcSMSettingsMSDAEditPopup003(ITestContext context) throws Exception {
        // Get driver
    	final WebDriver driver = WebDriverFactory.get( browser );
    	DevTools tools = null;

        Log.testCaseInfo( "tcSMSettingsMSDAEditPopup003: Verify MSDA Setting Edit Popup Functionality. <small><b><i>[" + browser + "]</b></i></small>" );
        username = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );

        try {
        	 smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
             dashBoardPage = smLoginPage.loginToSM(  username, password );
             // Navigatig to MSDA Setting Popup Page
             
             if ( DevToolsUtils.isMock( context ) ) {
        		Log.testCaseInfo(
        				"tc003: Verify the organization list count matches with the mocked organiczation list count when login as school admin. <small><b><i>["
        						+ browser + "]</b></i></small>");
    			
    			String json = DevToolsUtils.readJsonResponse("MSDAOrgSubDistrtct.txt");
    			Log.message(json);
    			tools = RequestMockUtils.setResponse(driver, configGraphQL, "GetMSDAOrgList", "post",json);
    			tools.createSessionIfThereIsNotOne();
    			Log.message(tools.getCdpSession().toString());
        	} 
        	settingpage = dashBoardPage.navigateToSettingListPage();
            settingpage.clickEditButtn( SettingPage.MSDA );
           
            // Initialising MSDA Setting Popup Page Elements
            MSDASettingsPopupPage popupPage = new MSDASettingsPopupPage( driver );

            SMUtils.logDescriptionTC( "SMK-17944: Verify School customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.assertThat( popupPage.isMSDAEditPopupDisplayed(), "School customer admin can navigate to 'Math Screener & Diagnostic Assessments' popup from Settings",
                    "School customer admin cannot navigate to 'Math Screener & Diagnostic Assessments' popup from Settings" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17962: Verify page is redirected to settings page when user clicks on cancel button in the Edit MSDA popup" );
            popupPage.clickCancelBtn();
            Log.assertThat( !popupPage.isMSDAEditPopupDisplayed(), "Page is redirected to settings page when user clicks on cancel button in the Edit MSDA popup",
                    "Page is not redirected to settings page when user clicks on cancel button in the Edit MSDA popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17973: Verify MSDA Edit popup is closed when clicking 'X' icon" );
            settingpage.clickEditButtn( SettingPage.MSDA );
            popupPage.clickCloseIcon();
            Log.assertThat( !popupPage.isMSDAEditPopupDisplayed(), "MSDA Edit popup is closed when clicking close icon", "MSDA Edit popup is not closed when clicking close icon" );
            Log.testCaseResult();
        
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if (null != tools) {
                RequestMockUtils.closeMock(tools);
            }
            driver.quit();
        }
    }

}