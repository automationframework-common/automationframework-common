package com.savvas.sm.admin.ui.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.HolidaySchedulerEditPopupPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.admin.util.DevToolsUtils;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.CreateAdmins;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class EditHolidaySchedulerTest extends EnvProperties {

    private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    private String subdistrictusername;
    private String schooladminusername;
    private String orgId;
    private String flexSchool;
    private String districtId;
    HolidaySchedulerEditPopupPage editHolidayScheduler;
    //Admin creation
    
    private String districtAdminDetails = null;
    private String subdistrictAdminDetails = null;
    private String schoolAdminDetails = null;
    private String configGraphQL;
    

    @BeforeClass (alwaysRun=true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtId = configProperty.getProperty( "district_ID" );
        configGraphQL = "https://sm-admin-dashboard-bff-srv-stack-dev.smdemo.info/graphql";
        
        CreateAdmins createAdminsClass = new CreateAdmins();
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        
        //Admin Creation for District, Sub District, School
        districtAdminDetails = createAdminsClass.createDistrictAdmin( smUrl, districtId, "051" );
        subdistrictAdminDetails= createAdminsClass.createSubDistrictAdminWithSchool(smUrl, districtId, "051");
        schoolAdminDetails = createAdminsClass.createSchoolAdmin( smUrl, Schools.FLEX_SCHOOL, orgId, "051" );
        Log.message( "********" );
        Log.message( "District admin details from Create Admins are " + districtAdminDetails );
        Log.message( "Sub-District admin details from Create Admins are " + subdistrictAdminDetails );
        Log.message( "schoolAdminDetails from Create Admins are " + schoolAdminDetails );
        Log.message( "********" );

        // Getting district admin details
        username = SMUtils.getKeyValueFromResponse( districtAdminDetails, RBSDataSetupConstants.USERNAME );
        subdistrictusername= SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );
        schooladminusername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );

    }

    @Test ( description = "Verify edit holiday scheduler all fields", groups = { "SMK-52186", "AdminDashboard", "EditHolidayScheduler","mock" }, priority = 1 )
    public void tcSMAdmin_EditHolidayScheduler001(ITestContext context) throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        DevTools tools = null;
        try {
            Log.testCaseInfo( "tcSMAdmin_EditHolidayScheduler001: Verify edit holiday scheduler all fields <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
             dashBoardPage = smLoginPage.loginToSM( username, password);
             if ( DevToolsUtils.isMock( context ) ) {
     			
     			String json = DevToolsUtils.readJsonResponse("GetHolidayScheduler.json");
     			Log.message(json);
     			
     			tools = RequestMockUtils.setResponse(driver, configGraphQL, "getHolidayScheduler", "post",json);
     			tools.createSessionIfThereIsNotOne();
     			Log.message(tools.getCdpSession().toString());
             } 

            settingpage = dashBoardPage.navigateToSettingListPage();
            editHolidayScheduler = settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17879: Verify the Header for edit holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getHeaderText().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday scheduler header is displaying", "Edit Holiday scheduler is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17880: Verify the Description text for edit holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getDescriptionText().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.EDIT_HOLIDAY_SCHEDULER_DESC ), "Edit Holiday scheduler description is displaying",
                    "Edit Holiday scheduler description is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17887: Verify the start date text box in Edit Holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getStartDate().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.START_DATE ), "Start Date is displying", "Start date is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17888: Verify the end date text box in Edit Holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getEndDate().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.END_DATE ), "End date is displaying", "End date is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17889: Verify the Description Text box in Edit Holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getHolidayNameText().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME ), "Holiday text box is displaying", "Holiday text box is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17894: Verify user can type and enter the start date in start date text box." );
            SMUtils.logDescriptionTC( "SMK-17896: Verify user can type and enter the end date in end date text box." );
            SMUtils.logDescriptionTC( "SMK-17883: Verify the displayed dates present under the Scheduled Holidays* column." );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER ), "Start date is available in holiday list", "Start date is not available in holiday list" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17881: Verify '*Excludes Weekends' label in edit holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getExcludeWeekensText().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.EXCLUDES_WEEKENDS ), "Exclude weekends text is displaying", "Exclude weekends text is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17882: Verify the column headers in edit holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getScheduledHolidayColumn().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.SCHEDULED_HOLIDAY_COL ), "Scheduled Holiday is displaying in column", "Scheduled Holiday is not displaying in column" );
            Log.assertThat( editHolidayScheduler.getHolidayColumnName().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME ), "Holiday name is displaying in column", "Holiday name is not displaying in column" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17885: Verify the displayed description present under the Description column" );
            Log.assertThat( editHolidayScheduler.getHolidayNameList().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC ), "Correct holiday name is displaying", "Holiday name description is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17892: Verify save button in the Edit Holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.isSaveButtonDisplayed(), "Save Button is displaying", "Save button is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17891: Verify cancel  button in the Edit Holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.getCancelButton().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.CANCEL_BTN ), "Cancel Button is available", "Cancel button is not available" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17886: Verify the remove button for all the Holidays." );
            Log.assertThat( editHolidayScheduler.getRemoveButton().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.REMOVE_BTN ), "Remove button is displaying", "Remove is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17890: Verify close icon(X) in the  Edit Holiday scheduler popup." );
            Log.assertThat( editHolidayScheduler.isCloseDialogeHeaderDisplayed(), " Cross icon is displaying", "Cross icon is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17920: Verify when two consecutive holiday scheduler added with same description" );
            SMUtils.logDescriptionTC( "SMK-17899: Verify user can add holiday by giving Start date , End date and description" );
            SMUtils.logDescriptionTC( "SMK-17884: Verify the displayed dates if more than 1 continues date has same description" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT2);
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT2 );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.DATE_RANGE_Text3 ), "Date range is displaying for two consecutive dates",
                    "Date range is not displaying for two consecutive date" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17893: Verify user can add Start Date by selecting a date in Calendar" );
            SMUtils.logDescriptionTC( "SMK-17895: Verify user can add end Date by selecting a date in Calendar" );
            editHolidayScheduler.clickStartCalendarIcon();
            editHolidayScheduler.clickStartDateFromCalender( AdminUIConstants.EditHolidayScheduler.startCalendar_Date );

            editHolidayScheduler.clickEndCaledarIcon();
            editHolidayScheduler.clickEndDateFromCalender( AdminUIConstants.EditHolidayScheduler.endCalendar_Date );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17904: Verify holiday should not add for weekends , when weekends available in date range " );
            Log.message( "Verify holiday should add for date range." );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_RANGE_FIRST );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_INCLUDE_WEEKEND );
            editHolidayScheduler.clickAddDates();

            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.DATE_RANGE ), "Date range is displaying when leave added for date range",
                    "Date range is not displaying when leave added for date range" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17898: Verify error message when user give  already existing date in start date and end date" );
            SMUtils.logDescriptionTC( "SMK-17908: Verify when user try to add holiday  which is already exists " );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_RANGE_FIRST );
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.EXIST_DATE_ERROR_MESSAGE ), "Date is already exist error message is displaying",
                    "Date is already exist error message is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17912: Verify Holiday scheduler window pop up should be closed, when user click on cancel button" );
            editHolidayScheduler.clikCancelButton();
            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "Header text is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if (null != tools) {
                RequestMockUtils.closeMock(tools);
            }
            driver.quit();
        }
    }

    @Test ( description = "Verify edit holiday scheduler all fields", groups = { "SMK-52186", "AdminDashboard", "EditHolidayScheduler" }, priority = 1 )
    public void tcSMAdmin_EditHolidayScheduler002() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdmin_EditHolidayScheduler002: Verify edit holiday scheduler for edit, add, cancel button <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();
            editHolidayScheduler = settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );

            SMUtils.logDescriptionTC( "SMK-17913: Verify Holiday scheduler window pop up should be closed, when user click on (X) icon" );
            editHolidayScheduler.clickCloseDialogeHeader();
            Log.assertThat( settingpage.getPageHeaderText().equals( AdminUIConstants.SettingPage.HEADER ), "Header Text Is displaying", "Header text is not displaying" );
            Log.testCaseResult();

            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );

            SMUtils.logDescriptionTC( "SMK-17905: Verify user can remove holiday for single day/date range by clicking on remove button" );
            SMUtils.logDescriptionTC( "SMK-17906: Verify user can remove list holiday my clicking on remove button individually" );
            editHolidayScheduler.clickRemovebutton();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17897: Verify error message when user give any date after the current year" );
            SMUtils.logDescriptionTC( "SMK-17902: Verify user can add holiday only for current academic year" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.DATE_MORE_THAN_YEAR );
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.ACADEMIC_YEAR_ERROR ), "Error message is displaying", "Error message is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17903: Verify holiday should not be added for weekends day,when user give only weekends day in calendar" );
            SMUtils.logDescriptionTC( "SMK-17907: Verify when admin give only weekends in start date and end date" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.WEEKEND_DATE );
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.ERROR_MESSAGE_WEEKENDS ), "Error Message is displaying when admin choose weekends", "Error message iss not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17922: Verify Zero state message when no holiday added." );
            Log.assertThat( editHolidayScheduler.getZeroStateMessage(), "Zero state message is displayng", "Zero state message is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify edit holiday scheduler all fields", groups = { "SMK-52186", "AdminDashboard", "EditHolidayScheduler" }, priority = 1 )
    public void tcSMAdmin_EditHolidayScheduler003() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdmin_EditHolidayScheduler003: Verify edit holiday scheduler for edit, add, cancel button <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();
            editHolidayScheduler = settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );

            SMUtils.logDescriptionTC( "SMK-17909: Verify when user added end date as less than the start date." );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER2 );
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.LESS_THAN_START_DATE_ERROR_MSG ), "Error message is displaying when admin give end date less than start date",
                    "Error message is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17910: Verify when user give wrong date format for Start Date and End Date." );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.WRONG_DATE_FORMAT );
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.WRONG_DATE_FORMAT_ERROR ), "Error message is displaying for error date", "Error message is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17914: Verify Add Dates, Save Button in disable mode untill user does not made any changes." );
            Log.assertThat( editHolidayScheduler.isAddDatesBtnDisable(), "Add dates button is disabled", "Add dates button is not disabled" );
            Log.assertThat( editHolidayScheduler.isSaveButtonDisabled(), "Save button is disabled", "Save button is not disabled" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17921: Verify when two consecutive holiday scheduler added with same description but other case" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER2 );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_LOWERCASE );
            editHolidayScheduler.clickAddDates();
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.DATE_RANGE_Text2 ), "Date range is displaying for two consecutive dates",
                    "Date range is not displaying for two consecutive date" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-17919: Verify when admin add holiday date range where few holidays already exists" );
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_FEB );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_APR );
            editHolidayScheduler.clickAddDates();
            Log.assertThat( editHolidayScheduler.getErrorMessage().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.ERROR_MESSAGE_WITH_EXIST_DATE_RANGE ), "Error message is displaying", "Error message is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify edit holiday is not displayed for Sub District admin", groups = { "SMK-52186", "AdminDashboard", "EditHolidayScheduler" }, priority = 1 )
    public void tcSMAdmin_EditHolidayScheduler004() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdmin_EditHolidayScheduler004: Verify edit holiday is not displayed for Sub District admin. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( subdistrictusername, password );
           
            settingpage = dashBoardPage.navigateToSettingListPage();

            SMUtils.logDescriptionTC( "Verify Holiday Scheduler is not displayed for Sub District admin" );
            Log.assertThat( !settingpage.getSettingListOptionNew().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday Scheduler is not displayed for sub district admin as expected",
                    "Not as expectd: Holiday Scheduler is displayed for sub district admin" );
            Log.assertThat( !settingpage.isHolidaySchedulerEditBtnDisplayed(), "Holiday Scheduler Edit button is not displayed for sub district admin as expected", "Not as expectd: Holiday Scheduler Edit button is displayed for sub district admin" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify edit holiday is not displayed for School admin", groups = { "SMK-52186", "AdminDashboard", "EditHolidayScheduler" }, priority = 1 )
    public void tcSMAdmin_EditHolidayScheduler005() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMAdmin_EditHolidayScheduler005: Verify edit holiday is not displayed for School admin. <small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( schooladminusername, password );
            settingpage = dashBoardPage.navigateToSettingListPage();

            SMUtils.logDescriptionTC( "Verify Holiday Scheduler is not displayed for School admin" );
            Log.assertThat( !settingpage.getSettingListOptionNew().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday Scheduler is not displayed for School admin as expected",
                    "Not as expectd: Holiday Scheduler is displayed for School admin" );
            Log.assertThat( !settingpage.isHolidaySchedulerEditBtnDisplayed(), "Holiday Scheduler Edit button is not displayed for School admin as expected", "Not as expectd: Holiday Scheduler Edit button is displayed for School admin" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}