package com.savvas.sm.admin.ui.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.RestoreAssignmentsListPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public class RestoreAssignmentsListTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String orgId;

    @BeforeClass ( )
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        username = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        orgId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

    }

    @Test ( description = "Verify the restore assignment table", groups = { "SMK-51934", "AdminDashboard", "RestoreAssignmentList" }, priority = 1 )
    public void tcSMRestore_Assignment_List001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMRestore_Assignment_List001: Verify Restore Assignment list Page with all field <small><b><i>[" + browser + "]</b></i></small>" );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( username, password, orgId );

            // Navigating to Restore assignment Page
            RestoreAssignmentsListPage restoreAssignment = dashBoardPage.navigateToRestoreAssignmentsListPage( orgId );

            // Verify the header
            SMUtils.logDescriptionTC( "Verify Restore SuccessMaker Assignments header is displayed below the View Org Information" );
            Log.assertThat( restoreAssignment.getRestoreAssignmentHeader().equals( AdminUIConstants.RestoreAssignmentList.HEADER ), "Restore assignment page header is displayed successfully!!!", "Restore assignment page header is not displayed properly" );

            //Verify the table title
            SMUtils.logDescriptionTC( "Verify the columns available in Restore Assignments table" );
            Log.assertThat( restoreAssignment.getRestoreAssignmentTableTitle().equals( AdminUIConstants.RestoreAssignmentList.TABLE_TITTLE ), "Restore assignment table page tittle is displayed successfully!!!",
                    "Restore assignment table page title is not displayed properly" );

            //Verify the page number
            SMUtils.logDescriptionTC( "Verify the page number is displayed in the Restore Assignments " );
            Log.assertThat( restoreAssignment.paginationDisplayed(), "Restore assignment pagenation is displayed successfully", "Restore assignment pagenation is not displayed properly" );

            //Verify the deleted assignment count
            SMUtils.logDescriptionTC( "Verify the number of deleted assignments count is display near to page number in the Restore Assignments " );
            Log.assertThat( restoreAssignment.deletedCountDisplayed(), "Restore assignment pagenation is displayed successfully", "Restore assignment pagenation is not displayed properly" );

            //verify the sorting is  default descending order
            SMUtils.logDescriptionTC( "Verify the list should be sorted in default descending order" );
            Log.assertThat( restoreAssignment.defaultDeteletedOnColumnSorting(), "Restore assignment default descending sorting is displayed successfully", "Restore assignment default descending sorting is not displayed properly" );

            //Verify the assignment name column is sorting
            SMUtils.logDescriptionTC( "Verify user can sort the Assignment Name column in the Restore Assignments list" );
            Log.assertThat( restoreAssignment.sortingTheAssignmentColumn(), "Sorting the assignment column in Restore Assignment is working successfully", "Sorting the assignment column in Restore Assignment is not working properly" );

            //Verify the teacher name column is sorting
            SMUtils.logDescriptionTC( "Verify user can sort the Teacher Name column in the Restore Assignments list" );
            Log.assertThat( restoreAssignment.sortingTheTeacherNameColumn(), "Sorting the teacher name column in Restore Assignment is working successfully", "Sorting the teacher name column in Restore Assignment is not working properly" );

            //Verify the student name column is sorting
            SMUtils.logDescriptionTC( "Verify user can sort the Student Name column in the Restore Assignments list" );
            Log.assertThat( restoreAssignment.sortingTheStudentNameColumn(), "Sorting the student name column in Restore Assignment is working successfully", "Sorting the student name column in Restore Assignment is not working properly" );

            //Verify the student username column is sorting
            SMUtils.logDescriptionTC( "Verify user can sort the Student Username column in the Restore Assignments list" );
            Log.assertThat( restoreAssignment.sortingTheStudentUsernameColumn(), "Sorting the student username column in Restore Assignment is working successfully", "Sorting the student username column in Restore Assignment is not working properly" );

            //Verify the deleted on column is sorting 
            SMUtils.logDescriptionTC( "Verify user can mouse hover the Deleted On Date column and check the Created On Date column is available" );
            SMUtils.logDescriptionTC( "Verify user can sort the Deleted On column in the Restore Assignments list" );
            Log.assertThat( restoreAssignment.sortingTheDeletedOnColumn(), "Sorting the deleted on column in Restore Assignment is working successfully", "Sorting the deleted on column in Restore Assignment is not working properly" );

            //Navigate to created on column
            SMUtils.logDescriptionTC( "Verify user can toggle the Deleted On Date column to become a Created On Date column in Restore Assignments" );
            Log.assertThat( restoreAssignment.toggleToCreatedOnCloumn().equals( AdminUIConstants.RestoreAssignmentList.CREATED_ON ), "Deleted On column toggle to Created On is working successfully ",
                    "Deleted On column toggle to Created On is not working properly " );

            //Verify the restore button
            SMUtils.logDescriptionTC( "Verify the Restore button is available in the Restore  Assignments" );
            Log.assertThat( restoreAssignment.restoreButton(), "Restore button is displayed successfully", "Restore button is not displayed properly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
