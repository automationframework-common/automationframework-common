package com.savvas.sm.admin.apiIntegration.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.HolidaySchedulerEditPopupPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SettingsListPage;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class BFFIntegrationHolidayscheduler extends EnvProperties {
	
	private String smUrl;
    private String browser;
    SettingsListPage settingpage;
    private String username;
    private String password;
    SMDashBoardPage dashBoardPage;
    AdminLauncherPage smLoginPage;
    HolidaySchedulerEditPopupPage editHolidayScheduler;

    @BeforeClass(alwaysRun=true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify edit holiday scheduler all Save edit an ddelete functionality", groups = { "SMK-55066", "AdminDashboard", "EditHolidayScheduler","smoke_test_case" }, priority = 1 )
    public void bffIntegrationEditHolidayScheduler001() throws Throwable {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "bffIntegrationEditHolidayScheduler001:Verify edit holiday scheduler all Save edit and delete functionality<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();
            SMUtils.logDescriptionTC("Verify Edit holiday scheduler window pop should be open when admin click Edit button for Holiday Scheduler");
            editHolidayScheduler = settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( editHolidayScheduler.getHeaderText().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.HEADER_TEXT ), "Edit Holiday scheduler header is displaying", "Edit Holiday scheduler is not displaying" );
            Log.testCaseResult();
            editHolidayScheduler.clickRemovebutton();
            SMUtils.logDescriptionTC("Verify Holiday should be save and display in holiday list when admin save record");
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickSaveButton();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER ), "Start date is available in holiday list", "Start date is not available in holiday list" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("Holiday should not be save and should not display in holiday list if admin click cancel button");
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clikCancelButton();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( !(editHolidayScheduler.getholidaylist()).contains( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT ),"Unsaved holiday is not available in holiday list", "Unsaved holiday is available in holiday list" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("Holiday should not save when admin add holiday and click close cross icon");
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickCloseDialogeHeader();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( !editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT ), "Unsaved holiday is not available in holiday list when admin click on cross icon", "Unsaved holiday is available in holiday list" );
            Log.testCaseResult();
            
            
            SMUtils.logDescriptionTC( "Verify Zero state message when no holiday scheduled." );
            editHolidayScheduler.clickRemovebutton();
            Log.assertThat( editHolidayScheduler.getZeroStateMessage(), "Zero state message is displayng", "Zero state message is not displaying" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("Verify holiday should be save when admin give lengthy description while adding holiday ");
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_ENTER );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.LENGTHY_HOLIDAY_DESCRIPTION );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickSaveButton();
            settingpage.naviagteToEditHolidaySchedulerPage( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER );
            Log.assertThat( editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_ENTER ), "Start date is available in holiday list for lengthy description", "Start date is not available in holiday list" );
            Log.testCaseResult();
            
            editHolidayScheduler.typeStartDate( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT );
            editHolidayScheduler.typeEndDate( AdminUIConstants.EditHolidayScheduler.END_DATE_NEXT );
            editHolidayScheduler.typeHolidayDescription( AdminUIConstants.EditHolidayScheduler.HOLIDAY_NAME_DESC );
            editHolidayScheduler.clickAddDates();
            editHolidayScheduler.clickSaveButton();
            
            
            SMUtils.logDescriptionTC("Verify holiday should not displayed in holiday list when admin remove holiday and save record.");
            editHolidayScheduler.removePerticularHoliday(AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT);
            Log.assertThat( !editHolidayScheduler.getholidaylist().toString().trim().contains( AdminUIConstants.EditHolidayScheduler.START_DATE_NEXT ), "Removed holiday not available in holiday list", "Removed holiday is available" );
            Log.testCaseResult();
            
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
        
    @Test ( description = "Verify subdistrict and School admin cannot see the edit holiday scheduler option in Settings page", groups = { "SMK-55066", "AdminDashboard", "EditHolidayScheduler" }, priority = 1 )
    public void bffIntegrationEditHolidayScheduler002() throws Throwable {

	    username = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "bffIntegrationEditHolidayScheduler002: Verify subdistrict and School admin cannot see the edit holiday scheduler option in Settings page<small><b><i>[" + browser + "]</b></i></small>" );

            smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            dashBoardPage = smLoginPage.loginToSM( username, password );

            settingpage = dashBoardPage.navigateToSettingListPage();

            SMUtils.logDescriptionTC( "Verify Holiday Scheduler is not displayed for Sub District admin" );
            Log.assertThat( !settingpage.getSettingListOptionNew().contains( AdminUIConstants.SettingPage.HOLIDAY_SCHEDULER ), "Holiday Scheduler is not displayed for sub district admin as expected",
                    "Not as expectd: Holiday Scheduler is displayed for sub district admin" );
            Log.assertThat( !settingpage.isHolidaySchedulerEditBtnDisplayed(), "Holiday Scheduler Edit button is not displayed for sub district admin as expected", "Not as expectd: Holiday Scheduler Edit button is displayed for sub district admin" );

            Log.testCaseResult();
    
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    
    }
    
}
