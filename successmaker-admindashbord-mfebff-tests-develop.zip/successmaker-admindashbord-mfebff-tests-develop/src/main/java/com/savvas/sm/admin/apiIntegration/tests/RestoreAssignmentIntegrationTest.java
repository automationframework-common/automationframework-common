package com.savvas.sm.admin.apiIntegration.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.RestoreAssignmentsListPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.common.utils.adminConstants.AdminAPIConstants;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.CREATED_DELETED_DATE;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants.RestoreAssignmentList;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class RestoreAssignmentIntegrationTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String districtId;
    private String savvasUserName;
    private String savvasUserId;
    private String savvasAccessToken;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String teacherOrgId;
    private String teacherId;
    private String teacherUsername;
    private String teacherName;
    private String school;
    private String studentDetails;
    private String studentUserId;
    private String studentUserName;
    private String studentName;
    private String courseName;
    private String courseId;
    private String assignmentUserId1;
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    private String restoredAssignmentUserId;
    private String orphanStudentAssignmentUserId;
    HashMap<String, String> newGroupDetails = new HashMap<>();
    private String newGroupId;
    HashMap<String, String> orphanAssignmentDetail = new HashMap<>();
    Map<String, String> headers = new HashMap<>();

    Response response;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        createData();
    }

    @Test ( description = "Verify the restore assignment table", groups = { "SMK-51934", "AdminDashboard", "RestoreAssignmentList", "restoreAssignmentSmokeTest" }, priority = 1 )
    public void tcSMRestore_Assignment_List001() throws Exception {
        // Remove student assignemnt 
        mathAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId1 );
        Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMRestore_Assignment_List001: Verify Restore Assignment list Page with all field <small><b><i>[" + browser + "]</b></i></small>" );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( savvasUserName, password, teacherOrgId );

            // Navigating to Restore assignment Page
            RestoreAssignmentsListPage restoreAssignment = dashBoardPage.navigateToRestoreAssignmentsListPage( teacherOrgId );
            String deletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId1 );
            String createdDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_CREATED, assignmentUserId1 );
            List<String> deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );

            SMUtils.logDescriptionTC( "Verify the deleted assignments are displayed in the Restore Assignment page for savvas admin " );
            SMUtils.logDescriptionTC( "Verify the deleted date is displayed in the hosted timezone area" );
            Log.assertThat( verifyDataInRestoreList( deletedDataList, studentName, studentUserName, deletedDateTime ), "The deleted assignments are displaying successfully ", "The deleted assignment are not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the created date is displayed in the hosted timezone area" );
            restoreAssignment.toggleToCreatedOnCloumn();
            List<String> createdDateList = restoreAssignment.getDeletedDataList( createdDateTime.substring( 11, 23 ), studentUserName );
            Log.assertThat( verifyDataInRestoreList( createdDateList, studentName, studentUserName, createdDateTime ), "The created dateandtime are displaying successfully", "The created dateandtime are not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the admin is able to restore the student's assignment" );
            SMUtils.logDescriptionTC( "Verify the restored assignment is not listed in the Restore assignment page" );
            deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            restoreAssignment.toggleToDeletedOnCloumn();
            deletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId1 );
            restoreAssignment.clickTheRestoreButton( deletedDateTime.substring( 11, 23 ), studentUserName );
            deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            Log.assertThat( deletedDataList.isEmpty(), "The deleted assignments is restored successfully ", "The deleted assignment is not restored properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the deleted date,if the restored assignment is deleted again" );
            Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );
            driver.navigate().refresh();
            deletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId1 );
            restoreAssignment.clickTheRestoreButton( deletedDateTime.substring( 11, 23 ), studentUserName );
            Log.assertThat( deletedDataList.isEmpty(), "The deleted assignments is displaying successfully ", "The deleted assignment is not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify a 'paused' deleted assignment is displayed in the restore assignment page" );
            HashMap<String, String> assignmentDetails = new HashMap<>();
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, teacherOrgId );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId1 );
            new AssignmentAPI().changeAssignmentStatus( smUrl, assignmentDetails, "200", "null" );
            Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );
            driver.navigate().refresh();
            deletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId1 );
            deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            Log.assertThat( verifyDataInRestoreList( deletedDataList, studentName, studentUserName, deletedDateTime ), "The deleted assignments is displaying successfully ", "The deleted assignment is not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the error message is displayed when restoring the same assignment" );
            new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            driver.navigate().refresh();
            deletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId1 );
            restoreAssignment.clickTheRestoreButton( deletedDateTime.substring( 11, 23 ), studentUserName );
            deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), studentUserName );
            restoreAssignment.closeErrorMessagePopup();
            Log.assertThat( verifyDataInRestoreList( deletedDataList, studentName, studentUserName, deletedDateTime ), "The error message is displaying successfully ", "The error message is not displaying properly" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the restore assignment table", groups = { "SMK-51934", "AdminDashboard", "RestoreAssignmentList", "restoreAssignmentSmokeTest" }, priority = 1 )
    public void tcSMRestore_Assignment_List002() throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
        SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( savvasUserName, password, teacherOrgId );

        String secondStudentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        String secondStudentUserId = SMUtils.getKeyValueFromResponse( secondStudentDetails, RBSDataSetupConstants.USERID );
        String secondStudentUserName = SMUtils.getKeyValueFromResponse( secondStudentDetails, RBSDataSetupConstants.USERNAME );
        String secondStudentName = SMUtils.getKeyValueFromResponse( secondStudentDetails, RBSDataSetupConstants.LASTNAME ) + ", " + SMUtils.getKeyValueFromResponse( secondStudentDetails, RBSDataSetupConstants.FIRSTNAME );

        // Creating new group
        newGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        newGroupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        newGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, teacherOrgId );
        newGroupDetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        HashMap<String, String> createGroupResponse = new GroupAPI().createGroup( smUrl, newGroupDetails, Arrays.asList( secondStudentUserId ) );
        newGroupId = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), "data," + GroupConstants.GROUP_ID );

        HashMap<String, String> response = new AssignmentAPI().assignAssignment( smUrl, mathAssignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );
        String assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
        String assignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( secondStudentUserId, assignmentID );

        // Delete group assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.GROUP_ID, newGroupId );
        Log.assertThat( new AssignmentAPI().deleteAssignmentfromGroup( smUrl, mathAssignmentDetails, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment is deleted from group", "Assignment is not deleted from group" );

        try {
            Log.testCaseInfo( "tcSMRestore_Assignment_List03: Verify Restore Assignment list Page with all field <small><b><i>[" + browser + "]</b></i></small>" );
            // Navigating to Restore assignment Page
            RestoreAssignmentsListPage restoreAssignment = dashBoardPage.navigateToRestoreAssignmentsListPage( teacherOrgId );
            String deletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, assignmentUserId2 );
            List<String> deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), secondStudentUserName );

            SMUtils.logDescriptionTC( "Verify the deleted group assignment is displayed in restore Assignment Page" );
            Log.assertThat( verifyDataInRestoreList( deletedDataList, secondStudentName, secondStudentUserName, deletedDateTime ), "The deleted assignments is displaying successfully ", "The deleted assignment is not displaying properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the admin able to restore the deleted group's assignment" );
            restoreAssignment.clickTheRestoreButton( deletedDateTime.substring( 11, 23 ), secondStudentUserName );
            deletedDataList = restoreAssignment.getDeletedDataList( deletedDateTime.substring( 11, 23 ), secondStudentUserName );
            Log.assertThat( deletedDataList.isEmpty(), "The deleted assignments is restored successfully ", "The deleted assignment is not restored properly" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the restore assignment table", groups = { "SMK-51934", "AdminDashboard", "RestoreAssignmentList" }, priority = 1 )
    public void tcSMRestore_Assignment_List003() throws Exception {

        // Creating custom course
        courseName = "Restore Assignment - " + System.nanoTime();
        courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, teacherOrgId, DataSetupConstants.SETTINGS, courseName );

        // Assigning assignment to student
        HashMap<String, String> orphanStudentAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );

        // Getting assignment id
        JSONObject orphanAssignmentDetailsJson = new JSONObject( orphanStudentAssignment.get( Constants.REPORT_BODY ) );
        JSONArray orphanAssignmentList = orphanAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject orphanAssignmentInfo = new JSONObject( orphanAssignmentList.get( 0 ).toString() );
        String orphanStudentAssignmentId = orphanAssignmentInfo.get( "assignmentId" ).toString();
        orphanStudentAssignmentUserId = new SqlHelperCourses().getActiveAssignmentUserId( studentUserId, orphanStudentAssignmentId );
        Log.message( "Orphan student assignment user id " + orphanStudentAssignmentUserId );

        // Deleting an assignment
        orphanAssignmentDetail.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        orphanAssignmentDetail.put( AdminAPIConstants.TEACHER_ID, teacherId );
        orphanAssignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        orphanAssignmentDetail.put( AdminAPIConstants.ASSIGNMENT_USER_ID, orphanStudentAssignmentUserId );
        Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, orphanAssignmentDetail, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Orphan Student assignment removed sucessfully!",
                "Issue in removing the orphan Student assignment" );

        //delete Student from all groups
        HashMap<String, String> studentDetails = new HashMap<String, String>();
        studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, teacherOrgId );
        studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        studentDetails.put( GroupConstants.STUDENT_ID, studentUserId );
        HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
        List<String> groupIds = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach( iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

        groupIds.stream().forEach( groupId -> {
            try {
                new GroupAPI().removeStudentFromGroup( smUrl, studentUserId, groupId, teacherId, teacherOrgId,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            } catch ( Exception e ) {
                e.printStackTrace();
            }
        } );
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        try {
            Log.testCaseInfo( "tcSMRestore_Assignment_List03: Verify Restore Assignment list Page with all field <small><b><i>[" + browser + "]</b></i></small>" );

            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SharedCoursesListViewPage dashBoardPage = smLoginPage.loginToSM( savvasUserName, password, teacherOrgId );

            // Navigating to Restore assignment Page
            RestoreAssignmentsListPage restoreAssignment = dashBoardPage.navigateToRestoreAssignmentsListPage( teacherOrgId );
            String orphanDeletedDateTime = restoreAssignment.getCreatedAndDeletedDate( CREATED_DELETED_DATE.DATE_UPDATED, orphanStudentAssignmentUserId );
            SMUtils.nap( 10 );
            driver.navigate().refresh();
            List<String> deletedDataList = restoreAssignment.getDeletedDataList( orphanDeletedDateTime.substring( 11, 23 ), studentUserName );

            SMUtils.logDescriptionTC( "Verify the deleted assignment is displayed in restore assignment for an orphan student" );
            Log.assertThat( verifyDataInRestoreList( deletedDataList, studentName, studentUserName, orphanDeletedDateTime ), "The deleted assignments is displaying successfully ", "The deleted assignment is not displaying properly" );

            SMUtils.logDescriptionTC( "Verify the admin is able to restore the assignment for a orphan student" );
            restoreAssignment.clickTheRestoreButton( orphanDeletedDateTime.substring( 11, 23 ), studentUserName );
            deletedDataList = restoreAssignment.getDeletedDataList( orphanDeletedDateTime.substring( 11, 23 ), studentUserName );
            Log.assertThat( deletedDataList.isEmpty(), "The deleted assignments is restored successfully ", "The deleted assignment is not restored properly" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public boolean verifyDataInRestoreList( List<String> actualList, String studentName, String studentUserName, String dateTime ) {

        List<String> list = Arrays.asList( courseName, teacherName, studentName, studentUserName.toLowerCase(), dateTime, RestoreAssignmentList.RESTORE );
        String expValue = "";
        for ( String value : list ) {
            expValue = expValue + value + " ";
        }
        Log.message( "Actual: " + actualList );
        Log.message( "Expected: " + expValue.replace( "pm", "PM" ).replace( "am", "AM" ) );
        return actualList.contains( expValue.replace( "pm", "PM" ).replace( "am", "AM" ).trim() );

    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    public void createData() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        districtId = configProperty.getProperty( "district_ID" );

        // Getting savvas admin details in RBS Datasetup
        savvasUserName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String savvasAdminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        savvasUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        savvasUserName = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERNAME );
        savvasAccessToken = new RBSUtils().getAccessToken( savvasUserName, password );

        // Getting teacher details
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherOrgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.LASTNAME ) + ", " + SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.FIRSTNAME );

        // Getting student details
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) + ", " + SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME );

        // Creating custom course
        courseName = "Restore Assignment - " + System.nanoTime();
        courseId = new SharedCourses().createCustomCourse( smUrl, new RBSUtils().getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherId, teacherOrgId, DataSetupConstants.SETTINGS, courseName );

        // Assigning an assignment
        mathAssignmentDetails.put( AdminAPIConstants.ORG_ID, teacherOrgId );
        mathAssignmentDetails.put( AdminAPIConstants.TEACHER_ID, teacherId );
        mathAssignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
        Log.message( assignmentResponse.toString() );

        // Getting assignment id
        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject assignmentInfo = new JSONObject( assignmentList.get( 0 ).toString() );
        String assignmentId = assignmentInfo.get( "assignmentId" ).toString();
        assignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentUserId, assignmentId );

        // Headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + savvasAccessToken );
    }

}