package com.savvas.sm.admin.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.adminConstants.AdminUIConstants;
import com.savvas.sm.utils.SMUtils;

public class HolidaySchedulerEditPopupPage extends LoadableComponent<HolidaySchedulerEditPopupPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    // *******************Success Maker Setting List page*******************//

    @FindBy ( css = "h1.dialog-header__message" )
    WebElement headerlbl;

    @FindBy ( css = "div.description-content p.description" )
    WebElement descriptionContent;

    @FindBy ( css = "p.excludes-weekends" )
    WebElement excludeWeekends;

    @FindBy ( css = "div.start-date-area label" )
    WebElement startDateText;

    @FindBy ( css = "div.end-date-area label" )
    WebElement endDateText;

    @FindBy ( css = "div.description-area label" )
    WebElement holidayNameText;

    @FindBy ( css = "div.hoilday-list-header div.holiday-info" )
    WebElement scheduleHolidayInfo;

    @FindBy ( css = "div.hoilday-list-header div.holiday-name" )
    WebElement holidayNameColumnText;

    @FindBy ( css = "cel-button.add-dates-btn" )
    WebElement addDatesButtonRoot;

    @FindBy ( css = "cel-button.save-btn" )
    WebElement saveButtonRoot;

    @FindBy ( css = "cel-button.cancel-btn" )
    WebElement canselButtonRoot;

    @FindBy ( css = "#startDate" )
    WebElement startDate;

    @FindBy ( css = "#endDate" )
    WebElement endDate;

    @FindBy ( css = "div.description-area #description" )
    WebElement holidayNameTextBox;

    @FindBy ( css = "div.holiday-remove a" )
    List<WebElement> removeButton;

    @FindBy ( css = "button.info-button cel-icon" )
    WebElement questionIcon;

    @FindBy ( css = "div.holiday-body div div span" )
    List<WebElement> holidayList;

    @FindBy ( css = "div.holiday-name p" )
    List<WebElement> holidayNameList;

    @FindBy ( css = "#dialogHeaderClose" )
    WebElement crossIcon;

    @FindBy ( css = "span.error-message span" )
    WebElement existDateErrorMessage;

    @FindBy ( css = "div.not-found div" )
    WebElement zeroStateHeaderError;

    @FindBy ( css = "div.no-results-description" )
    WebElement zeroStateDescription;

    @FindBy ( css = "cel-button.dialog-button" )
    WebElement holidaySchdulerErrorCloseRoot;

    @FindBy ( css = "div.holidays-list" )
    WebElement holidays;

    @FindBy ( css = "settings .main-container-heading-text" )
    WebElement settingsHeading;

    @FindBy ( css = "table>tbody>tr>td:nth-of-type(1)" )
    List<WebElement> numberOfrows;

    // ********************************Child
    // Elements**********************************//

    public static String childButton = ".primary_button";
    public static String childCancelButton = ".secondary_button";
    public static String GrandChildcalendaricon = ".calendar-icon";
    public static String childCalendarIcon = ".icon-inner";
    private static String datePickerParent = "div div cel-date-picker-popup";
    private static String datePickerTable = "div > div.date-picker-modal-dates";
    private static String datePicketrInput = "input.date-picker-input";
    private static String removeSpecificDate = "div.holiday-remove a";
    // These index related POM used in methods to get dynamic data. And these
    // locators are child elements
    private static String datePickerChild = "div div.date-picker-modal-dates button:nth-child(%s)";
    private static String holidaySchdulerErrorClosechild = "button";

    // ***************************All Common
    // methods*******************************//

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public HolidaySchedulerEditPopupPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, headerlbl );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, headerlbl, 10 ) ) {
            Log.message( "SM Setting list page loaded successfully." );
        } else {
            Log.fail( "SM Setting list page did not load." );
        }

    }

    public void holidaySchdulerErrorCloseButton() {
        WebElement closeElement = SMUtils.getWebElement( driver, holidaySchdulerErrorCloseRoot, holidaySchdulerErrorClosechild );
        SMUtils.clickJS( driver, closeElement );
        Log.message( "holiday Schduler Error button is closed" );
    }

    /**
     * Get Edit holiday scheduler text
     * 
     * @return
     */
    public String getHeaderText() {
        SMUtils.waitForElement( driver, headerlbl );
        Log.message( "Get Edit Holiday Scheduler text" );
        return headerlbl.getText().trim();
    }

    /**
     * Get excludes weekends text
     * 
     * @return
     */
    public String getExcludeWeekensText() {
        SMUtils.waitForElement( driver, excludeWeekends );
        Log.message( "Get the Exclude Weekends Text" );
        return excludeWeekends.getText().trim();
    }

    /**
     * Get Edit Holiday Scheduler Text
     * 
     * @return
     */
    public String getDescriptionText() {
        SMUtils.waitForElement( driver, descriptionContent );
        Log.message( "Get Edit Holiday scheduler description text" );
        return descriptionContent.getText().trim();
    }

    /**
     * Get Add Dates Button
     * 
     * @return
     */
    public String getAddDates() {
        SMUtils.waitForElement( driver, addDatesButtonRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, addDatesButtonRoot, childButton );
        Log.message( "Verify Add Dates button text" );
        return actualElement.getText().trim();

    }

    /**
     * Verify save button is displaying
     * 
     * @return
     */
    public Boolean isSaveButtonDisplayed() {
        SMUtils.waitForElement( driver, saveButtonRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, saveButtonRoot, childButton );
        Log.message( "Verify Save button is  displaying" );
        return actualElement.isDisplayed();
    }

    /**
     * Verify cancel button
     * 
     * @return
     */
    public String getCancelButton() {
        SMUtils.waitForElement( driver, canselButtonRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, canselButtonRoot, childCancelButton );
        Log.message( "Verify Cancel Button" );
        return actualElement.getText().trim();
    }

    /**
     * Clicking the date from calendar for the same month for start date
     * 
     * @param date
     */
    public void clickStartDateFromCalender( String date ) {
        try {
            WebElement calenderIconRoot = SMUtils.getWebElement( driver, startDate, datePickerParent );
            WebElement dateTable = SMUtils.getWebElement( driver, calenderIconRoot, datePickerTable );
            String dateCount = dateTable.getAttribute( "childElementCount" );
            WebElement dateButton = null;
            int dates = 1;
            do {
                dateButton = SMUtils.getWebElement( driver, calenderIconRoot, String.format( datePickerChild, dates ) );
                String dateText = dateButton.getText();
                if ( date.equals( dateText ) ) {
                    SMUtils.clickJS( driver, dateButton );
                    break;
                }
                dates++;
            } while ( dates <= Integer.parseInt( dateCount ) );
            SMUtils.clickJS( driver, dateButton );
            Log.message( "Date Selected - " + date );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Clicking the date from calendar for the same month for start date
     * 
     * @param date
     */
    public void clickEndDateFromCalender( String date ) {
        try {
            WebElement calenderIconRoot = SMUtils.getWebElement( driver, endDate, datePickerParent );
            WebElement dateTable = SMUtils.getWebElement( driver, calenderIconRoot, datePickerTable );
            String dateCount = dateTable.getAttribute( "childElementCount" );
            WebElement dateButton = null;
            int dates = 1;
            do {
                dateButton = SMUtils.getWebElement( driver, calenderIconRoot, String.format( datePickerChild, dates ) );
                String dateText = dateButton.getText();
                if ( date.equals( dateText ) ) {
                    SMUtils.clickJS( driver, dateButton );
                    break;
                }
                dates++;
            } while ( dates <= Integer.parseInt( dateCount ) );
            SMUtils.clickJS( driver, dateButton );
            Log.message( "Date Selected - " + date );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verify is save button disabled
     * 
     * @return
     */
    public Boolean isSaveButtonDisabled() {
        SMUtils.waitForElement( driver, saveButtonRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, saveButtonRoot, childButton );
        Log.message( "Verify save button is disabled" );
        return !actualElement.isEnabled();
    }

    /**
     * Verify add dates button enabled or disable
     * 
     * @return
     */
    public Boolean isAddDatesBtnDisable() {
        SMUtils.waitForElement( driver, addDatesButtonRoot );
        WebElement atualElement = SMUtils.getWebElement( driver, addDatesButtonRoot, childButton );
        Log.message( "Add dates button is disabled" );
        return !atualElement.isEnabled();
    }

    /**
     * 
     * @param remove
     */
    public void clickRemovebutton() {
        int size = removeButton.size();
        IntStream.range( 0, size ).forEach( element -> {

            SMUtils.clickJS( driver, removeButton.get( 0 ) );
        } );

        Log.message( "Clicked on Remove link" );
    }

    /**
     * Verify question circle
     * 
     * @return
     */
    public Boolean isHelpIconDisplayed() {
        SMUtils.waitForElement( driver, questionIcon );
        Log.message( "Question circle is diplaying" );
        return questionIcon.isDisplayed();
    }

    /**
     * Get Scheduled Holiday Text
     * 
     * @return
     */
    public String getScheduledHolidayColumn() {
        SMUtils.waitForElement( driver, scheduleHolidayInfo );
        Log.message( "Verify Scheduled holiday is displaying in column" );
        return scheduleHolidayInfo.getText().trim();
    }

    /**
     * Get HolidayName text in column
     * 
     * @return
     */
    public String getHolidayColumnName() {
        SMUtils.waitForElement( driver, holidayNameColumnText );
        Log.message( "Verify Holiday name is displaying in column" );
        return holidayNameColumnText.getText().trim();
    }

    /**
     * Get Start date
     * 
     * @return
     */
    public String getStartDate() {
        SMUtils.waitForElement( driver, startDateText );
        Log.message( "Verify Start date text box" );
        return startDateText.getText().trim();
    }

    /**
     * Get End date
     * 
     * @return
     */
    public String getEndDate() {
        SMUtils.waitForElement( driver, endDateText );
        Log.message( "Verify End date text box" );
        return endDateText.getText().trim();
    }

    /**
     * Get Holiday name text
     * 
     * @return
     */
    public String getHolidayNameText() {
        SMUtils.waitForElement( driver, holidayNameText );
        Log.message( "Get Holiday name text box" );
        return holidayNameText.getText().trim();
    }

    /**
     * Enter start date
     * 
     * @param date
     */
    public void typeStartDate( String date ) {

        SMUtils.waitForElement( driver, startDate );
        WebElement atualElement = SMUtils.getWebElement( driver, startDate, datePicketrInput );
        atualElement.clear();
        atualElement.sendKeys( date + Keys.ENTER );
        Log.message( "Enter Start date" );
    }

    /**
     * Enter end date
     * 
     * @param date
     */
    public void typeEndDate( String date ) {
        SMUtils.waitForElement( driver, endDate );
        WebElement atualElement = SMUtils.getWebElement( driver, endDate, datePicketrInput );
        SMUtils.clickJS( driver, atualElement );
        atualElement.clear();
        atualElement.sendKeys( date + Keys.ENTER );
        Log.message( "Enter End date" );
    }

    /**
     * Click Add Dates button
     */
    public void clickAddDates() {
        SMUtils.waitForElement( driver, addDatesButtonRoot );
        WebElement atualElement = SMUtils.getWebElement( driver, addDatesButtonRoot, childButton );
        SMUtils.clickJS( driver, atualElement );
        Log.message( "Clicked Add dates button" );
    }

    /**
     * Enter holiday description
     * 
     * @param description
     */
    public void typeHolidayDescription( String description ) {
        SMUtils.waitForElement( driver, holidayNameTextBox );
        holidayNameTextBox.clear();
        holidayNameTextBox.sendKeys( description + Keys.ENTER );
        Log.message( "Enter holiday description " + description );
    }

    /**
     * Get all added holiday list
     * 
     * @return
     */
    public List<String> getholidaylist() {
        Log.message( "Get all added holiday list" );
        return SMUtils.getAllTextFromWebElementList( holidayList );

    }

    /**
     * Get all added holiday list
     * 
     * @return allValues
     */
    public List<String> getholidayDates() {
        List<String> allValues = new ArrayList<>();
        new WebDriverWait( driver, Duration.ofSeconds( 3 ) ).until( ExpectedConditions.visibilityOfAllElements( holidayList ) );
        holidayList.forEach( element -> {
            allValues.add( element.getText().trim() );
        } );
        Log.message( "Getting all holiday date options" );
        return allValues;
    }

    /**
     * Get all holiday name list
     * 
     * @return
     */
    public List<String> getHolidayNameList() {
        Log.message( "Get All added description list" );
        return SMUtils.getAllTextFromWebElementList( holidayNameList );
    }

    /**
     * Get all holiday names list
     * 
     * @return
     */
    public List<String> getHolidayNames() {
        List<String> allValues = new ArrayList<>();
        holidayNameList.forEach( element -> {
            allValues.add( element.getText().trim() );
        } );
        Log.message( "Getting all holiday date options" );
        return allValues;
    }

    /**
     * Get all remove button
     * 
     * @return
     */
    public List<String> getRemoveButton() {
        Log.message( "Get all remove button" );
        return SMUtils.getAllTextFromWebElementList( removeButton );
    }

    /**
     * Cross icon
     * 
     * @return
     */
    public Boolean isCloseDialogeHeaderDisplayed() {
        Log.message( "Verify Close dialoge header is displaying" );
        return crossIcon.isDisplayed();
    }

    /**
     * Clicked start date icon
     */
    public void clickStartCalendarIcon() {
        SMUtils.waitForElement( driver, startDate );
        WebElement element = SMUtils.getWebElement( driver, startDate, GrandChildcalendaricon );
        WebElement actualElement = SMUtils.getWebElement( driver, element, childCalendarIcon );
        SMUtils.clickJS( driver, actualElement );
        Log.message( "Clicked start date calendar icon" );
    }

    /**
     * Clicked end date icon
     */
    public void clickEndCaledarIcon() {
        SMUtils.waitForElement( driver, endDate );
        WebElement element = SMUtils.getWebElement( driver, endDate, GrandChildcalendaricon );
        WebElement actualElement = SMUtils.getWebElement( driver, element, childCalendarIcon );
        SMUtils.clickJS( driver, actualElement );
        Log.message( "Clicked end date calendar icon" );
    }

    /**
     * Get Error message
     * 
     * @return
     */
    public String getErrorMessage() {
        SMUtils.waitForElement( driver, existDateErrorMessage );
        Log.message( "Capture error message for dates" );
        return existDateErrorMessage.getText().trim();
    }

    /**
     * click cancel button
     * 
     * @return
     */
    public void clikCancelButton() {
        SMUtils.waitForElement( driver, canselButtonRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, canselButtonRoot, childCancelButton );
        Log.message( "Clicked Cancel Button" );
        SMUtils.clickJS( driver, actualElement );
    }

    /**
     * Click Cross icon
     * 
     * @return
     */
    public void clickCloseDialogeHeader() {
        SMUtils.waitForElement( driver, crossIcon );
        WebElement actualElement = SMUtils.getWebElement( driver, crossIcon, childCalendarIcon );
        SMUtils.clickJS( driver, actualElement );
        Log.message( "Clicked cross icon on window popup" );
    }

    /**
     * Get zero state message
     * 
     * @return
     */
    public Boolean getZeroStateMessage() {
        SMUtils.waitForElement( driver, zeroStateHeaderError );
        Log.message( "Get zero state message with header and description." );
        return zeroStateHeaderError.getText().trim().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.ZERO_STATE_HEADER ) && zeroStateDescription.getText().trim().equalsIgnoreCase( AdminUIConstants.EditHolidayScheduler.ZERO_STATE_DESCRIPTION );
    }

    /**
     * Click Save button
     */
    public void clickSaveButton() {
        SMUtils.waitForElement( driver, saveButtonRoot );
        WebElement actualElement = SMUtils.getWebElement( driver, saveButtonRoot, childButton );
        SMUtils.clickJS( driver, actualElement );
        Log.message( "Clicked Save buttton" );
    }

    /**
     * Click Remove button for specific date
     * 
     * @param date
     */
    public void removePerticularHoliday( String date ) {
        holidayList.forEach( element -> {
            if ( element.getText().trim().equals( date ) ) {
                WebElement pElement = element.findElement( By.xpath( "./.." ) );
                SMUtils.clickJS( driver, pElement.findElement( By.cssSelector( removeSpecificDate ) ) );
            }
        } );
        Log.message( "Selected holiday removed" );
    }

    /**
     * To get the settings heading
     * 
     * @return String
     * 
     */
    public String settingsHeading() {
        SMUtils.waitForElement( driver, settingsHeading );
        return SMUtils.getTextOfWebElement( settingsHeading, driver );
    }

    /**
     * To check whether the Edit Holiday Scheduler is visible or not
     * 
     * @return Boolean
     * 
     */
    public Boolean checkVisibilityOfHolidayScheduler() {
        List<String> rowList = SMUtils.getAllTextFromWebElementList( numberOfrows );
        Boolean status = true;
        if ( rowList.size() <= 1 && Boolean.FALSE.equals( rowList.get( 0 ).equalsIgnoreCase( "Holiday Scehduler" ) ) ) {
            status = false;
        }

        return status;

    }
}
