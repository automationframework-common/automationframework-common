# successmaker_test_automation
SuccessMaker Admin and Teacher UI and API Automation Repository. (Epic: SME-7)

**API Automation Guidelines**

https://docs.google.com/document/d/1VIz_SvL0i53ZNDK_L7ECuO3aiAkZPIlz3Q2ldpVdanY/edit
