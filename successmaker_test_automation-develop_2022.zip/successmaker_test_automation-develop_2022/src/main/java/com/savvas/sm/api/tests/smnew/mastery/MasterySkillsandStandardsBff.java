package com.savvas.sm.api.tests.smnew.mastery;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.pojo.mastery.GetStandardsMastery;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

/**
 * Method for testing the standards in the GraphQL call
 * 
 * @author madhan.nagarathinam
 */

public class MasterySkillsandStandardsBff extends BaseAPITest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    String teacherDetails;
    String studentDetails;
    String orgId;
    String teacherId;
    String studentId;
    String MATH_SUBJECT_ID = "1";
    String READING_SUBJECT_ID = "2";
    String INVALID_SUBJECT_ID = "3";
    String subject_Id;

    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() {
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ) );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        orgId = configProperty.getProperty( "district_ID" );
        studentId = SMUtils.getKeyValueFromResponse( teacherDetails, "studentDetails" );
    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51598", "(Graphql) BFF skills/standards data integration - real", "GraphQL", "BFF" }, priority = 1 )
    public void getSkillsStandardsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        String organizationId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + RBSDataSetup.organizationIDs.get( school ) + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
        String UserId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + teacherId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;

        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "ALL_QUERYITEMS":
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_ID );
                queryItem = constructQueryItems( queryItems );
                break;

            case "SINGLE_QUERY_ITEM":
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItem = constructQueryItems( queryItems );
                break;

            case "MATH":
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_ID );
                queryItem = constructQueryItems( queryItems );
                break;

            case "READING":
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + READING_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_ID );
                queryItem = constructQueryItems( queryItems );
                break;
        }
        String payload = String.format( MasteryConstants.Graphql.skillsandStandards.REQ_PAYLOAD, organizationId, UserId, subject_Id, queryItem );
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        Log.message( response.getBody().asString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getStandardsDataBFFResponseSchema", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

        // DB validation for Standards Data with respect to the GraphQL Response
        if ( scenarioType.equalsIgnoreCase( "MATH" ) || scenarioType.equalsIgnoreCase( "READING" ) ) {
            // deserialize the response
            final ObjectMapper objectMapper = new ObjectMapper();
	            // convert JSON array to List of objects
            String skillsStandard = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ).toString();
            List<GetStandardsMastery> listStandardVersionResponse = Arrays.asList( objectMapper.readValue( getJsonArrayFromResponse( skillsStandard, "skillsAndStandards" ).toString(), GetStandardsMastery[].class ) );
            // get values from Database
            List<StandardVersionMastery> listStandardVersionDB = SqlHelperMastery.getStandards( scenarioType );
            // compare
            Log.assertThat( compareStandardsFromApiResponseAndDB( listStandardVersionResponse, listStandardVersionDB ), "DB records and Api response both are same for subject- " + scenarioType,
                    "DB records and Api response both are different for subject- " + scenarioType );
        }

    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51598", "(Graphql) BFF skills/standards data integration - real", "GraphQL", "BFF" }, priority = 2 )
    public void getSkillsStandardsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        String organizationId = null;
        String userId = null;

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "INVALID_AUTH":
                headers.put( Constants.AUTHORIZATION, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                organizationId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + RBSDataSetup.organizationIDs.get( school ) + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                userId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + teacherId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_PAYLOAD":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                organizationId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + RBSDataSetup.organizationIDs.get( school ) + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                userId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + teacherId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( "122" );
                queryItem = constructQueryItems( queryItems );
                break;

            case "STUDENT":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                organizationId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + RBSDataSetup.organizationIDs.get( school ) + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                userId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + studentId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItem = constructQueryItems( queryItems );
                break;

            case "IRRESPECTIVE_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                organizationId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + orgId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                userId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + teacherId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + MATH_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_SUBJECT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                organizationId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + RBSDataSetup.organizationIDs.get( school ) + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                userId = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + teacherId + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                subject_Id = LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION + INVALID_SUBJECT_ID + LoginConstants.ADMIN_USER.BACKWARD_SLASH + LoginConstants.ADMIN_USER.DOUBLE_QUOTATION;
                queryItems.add( MasteryConstants.Graphql.skillsandStandards.STANDARDS_NAME );
                queryItem = constructQueryItems( queryItems );
                break;
        }
        String payload = String.format( MasteryConstants.Graphql.skillsandStandards.REQ_PAYLOAD, organizationId, userId, subject_Id, queryItem );
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        Log.message( response.getBody().asString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        if ( scenarioType.equalsIgnoreCase( "INVALID_AUTH" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.UNAUTHORIZED_MESSAGE ), "Getting Unauthorized message for Invalid authorization",
                    "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "STUDENT" ) || scenarioType.equalsIgnoreCase( "IRRESPECTIVE_ORG_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.ACCESS_DENIED ), "Getting Access Denied message for Invalid users / Irrespective org's",
                    "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_PAYLOAD" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( MasteryConstants.Graphql.skillsandStandards.SYNTAX_ERROR ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( MasteryConstants.Graphql.skillsandStandards.INVALID_SUBJECT_ID_ERROR ), "Getting Invalid value passed for subjectId error message for invalid subject Id",
                    "Not getting Invalid value passed for subjectId error message for invalid subject Id!" );
        }
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:01 ", "200", "Verify that valid response is fetching when all the schemas are given in query paramaters", "ALL_QUERYITEMS" },
                { "TC:02 ", "200", "Verify 200 status code and valid response when a single set query is given ", "SINGLE_QUERY_ITEM" },
                { "TC:03 ", "200", "Verify the graphql response is obtaining all the standard details in the database for all set of Fields for Skills/standards query when Math subject Id is given", "MATH" },
                { "TC:04 ", "200", "Verify the graphql response is obtaining all the standard details in the database for all set of Fields for Skills/standards query when Reading subject Id is given", "READING" },

        };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:05 ", "200", "Verify '401: UnAuthorized' message in response when invalid Bearer token is given ", "INVALID_AUTH" },
                { "TC:06 ", "400", "Verify '400: Bad Request' in response when invalid query has been given", "INVALID_PAYLOAD" },
                { "TC:07 ", "200", "Verify the invalid athorization message on the response when invalid user id with valid authorization and valid org-id is given", "STUDENT" },
                { "TC:08 ", "200", "Verify the user is not authorized message on the response when irrespective org is given the query", "IRRESPECTIVE_ORG_ID" },
                { "TC:09 ", "200", "Verify 400 status code and response when invalid subject id is given in the query ", "INVALID_SUBJECT_ID" }

        };
        return data;
    }

    //This method is for constructing the query Items for payload
    public String constructQueryItems( List<String> queryItems ) {
        String frameQuery = "{";
        for ( String item : queryItems ) {
            if ( frameQuery.endsWith( "{" ) )
                frameQuery = frameQuery + item;
            else
                frameQuery = frameQuery + "," + item;
        }
        frameQuery = frameQuery + "}";
        return frameQuery;
    }

    //This method is extracting error message from response

    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

    /**
     * This method is used to compare the standards list from API response and
     * DB-Table entries
     * 
     * @param listStandardVersionResponse
     * @param listStandardVersionDB
     * @return
     */
    private boolean compareStandardsFromApiResponseAndDB( List<GetStandardsMastery> listStandardVersionResponse, List<StandardVersionMastery> listStandardVersionDB ) {
        boolean returnParam = false;
        // sort the values by ascending order pointing - StandardsID
        listStandardVersionDB.sort( Comparator.comparing( StandardVersionMastery::getStandardsId ) );
        listStandardVersionResponse.sort( Comparator.comparing( GetStandardsMastery::getStandardsId ) );

        // add to common list for comparison.
        // Since, comparing two list of different object is not possible
        List<String> commonListDB = new ArrayList<String>();
        List<String> commonListResponse = new ArrayList<String>();

        listStandardVersionResponse.stream().forEachOrdered( c -> {
            commonListResponse.add( c.getStandardsId() );
            commonListResponse.add( c.getStandardsName() );
        } );

        listStandardVersionDB.stream().forEachOrdered( c -> {
            commonListDB.add( c.getStandardsId() );
            commonListDB.add( c.getStandardsName() );
        } );

        // compare
        returnParam = commonListDB.equals( commonListResponse );

        return returnParam;
    }
}
