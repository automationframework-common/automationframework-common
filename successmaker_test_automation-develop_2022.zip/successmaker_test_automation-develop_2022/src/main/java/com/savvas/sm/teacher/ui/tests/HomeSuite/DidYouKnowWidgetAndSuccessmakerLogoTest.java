package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class DidYouKnowWidgetAndSuccessmakerLogoTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    // For Simulator Execution
    private String chromePlatform = "Windows_10_Chrome_latest";

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
    }

    @Test ( description = "Verify the Did you know widget and header present in Home Page for teacher user", groups = { "SMK-38835", "HomePage", "Did you know widget" }, priority = 1 )
    public void tcSMDidYouKnow01() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMDidYouKnow01: Verify the Did you know widget and header present in Home Page for teacher user. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            //TopNavBar topNavBar = tHomePage.topNavBar;
            // Validate Did you know widget visible in home page
            Log.assertThat( tHomePage.isDidYouKnowWidgetDisplayed(), "Did You Know widget is displayed in HomePage", "Did You Know widget is not displayed in HomePage" );
            // Validate Did you know widget title 
            Log.assertThat( tHomePage.getDidYouKnowTitle().getText().trim().equals( Constants.HomePageWidgetConstants.DIDYOUKNOWHEADER ), "Did You Know widget title is: " + tHomePage.getDidYouKnowTitle().getText().trim(),
                    "Did You Know widget title is not displayed in HomePage" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the tip contents will display inside the Did you know? widget.", groups = { "SMK-38835", "HomePage", "Did you know widget" }, priority = 1 )
    public void tcSMDidYouKnow02() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMDidYouKnow02: Verify the tip contents will display inside the Did you know? widget. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            //TopNavBar topNavBar = tHomePage.topNavBar;
            // Validate Did you know widget content is visible in home page
            Log.assertThat( tHomePage.isDidYouKnowTextContentDisplayed(), "Did You Know widget content is displayed in HomePage", "Did You Know widget is not displayed in HomePage" );
            // Validate visibility of Did you know widget link 
            Log.assertThat( tHomePage.isDidYouKnowContentLinkDisplayed(), "Did You Know widget content link is displayed", "Did You Know widget title is not displayed in HomePage" );
            Log.assertThat( tHomePage.getDidYouKnowContentLink().getText().trim().contains( Constants.HomePageWidgetConstants.DIDYOUKNOWCONTENTLINKS ), "Did you know content link is :" + tHomePage.getDidYouKnowContentLink().getText().trim(),
                    "Did you know content link is not displayed" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify  link will be clickable in Did you know widget and it will be open in new window", groups = { "SMK-38835", "HomePage", "Did you know widget" }, priority = 1 )
    public void tcSMDidYouKnow03() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
 
		Log.testCaseInfo( "tcSMDidYouKnow03: Verify  link will be clickable in Did you know widget and it will be open in new window. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Click "my Savvas Training" link in Did you know widget
            tHomePage.clickDidYouKnowContentLink();
            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();
            // Validate visibility of My Savvas Training page loaded 
            Log.assertThat( tHomePage.isMySavvasTrainingPageGetDisplayed(), "My Savvas Training site is displayed", "My Savvas Training site is not displayed" );
            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );

                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
                Log.testCaseResult();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
 
    //UI automation supports only Flex licensed org. Hence making this case as skip
    @Test ( enabled = false, description = "Verify teacher can see successmaker logo in top nav bar when teacher org has focus license only", dataProvider = "getTeacherUsernameWithFocus", groups = { "SMK-49963", "logo", "topNavBar" }, priority = 2 )
    public void tcSMLogoTest001( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMLogoTest001: Verify teacher can see successmaker logo in top nav bar when teacher org has focus license only <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // login into SM
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "Verify teacher can see successmaker logo in top nav bar when teacher org has focus license only" );
            // Verifying Successmaker logo
            Log.assertThat( teacherHomePage.topNavBar.isNewSuccessmakerLogoDisplayed(), "Successmaker logo displayed for teacher having focus license alone", "Successmaker logo is not displayed for teacher having focus license alone" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //UI automation supports only Flex licensed org. Hence making this case as skip
    @Test ( enabled = false, description = "Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker math and focus license", dataProvider = "getTeacherUsernameWithMathAndFocus", groups = { "SMK-49963", "logo", "topNavBar" }, priority = 2 )
    public void tcSMLogoTest002( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD002: Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker math and focus license <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // login into SM
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker math and focus license" );
            // Verifying Successmaker logo
            Log.assertThat( teacherHomePage.topNavBar.isNewSuccessmakerLogoDisplayed(), "Successmaker logo displayed for teacher having Math and focus license alone", "Successmaker logo is not displayed for teacher having math and focus license alone" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //UI automation supports only Flex licensed org. Hence making this case as skip
    @Test (enabled = false, description = "Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker reading and focus license", dataProvider = "getTeacherUsernameWithReadingAndFocus", groups = { "SMK-49963", "logo",
            "topNavBar" }, priority = 3 )
    public void tcSMLogoTest003( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD003: Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker reading and focus license <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // login into SM
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker reading and focus license" );
            // Verifying Successmaker logo
            Log.assertThat( teacherHomePage.topNavBar.isNewSuccessmakerLogoDisplayed(), "Successmaker logo displayed for teacher having reading and focus license alone",
                    "Successmaker logo is not displayed for teacher having reading and focus license alone" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //UI automation supports only Flex licensed org. Hence making this case as skip
    @Test ( enabled = false,  description = "Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker Math and Reading licenses", groups = { "SMK-49963", "logo", "topNavBar" }, priority = 3 )
    public void tcSMLogoTest004() throws Exception {
        ExecuteCourse();
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD004: Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker Math and Reading licenses <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // login into SM
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "Verify teacher can see successmaker logo in top nav bar when teacher org has successmaker Math and Reading licenses" );
            // Verifying Successmaker logo
            Log.assertThat( teacherHomePage.topNavBar.isNewSuccessmakerLogoDisplayed(), "Successmaker logo displayed for teacher having Default license", "Successmaker logo is not displayed for teacher having Default license" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify teacher can see successmaker logo in print preview of progress monitoring when teacher org has successmaker Math and Reading licenses" );
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            String studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student1" );

            //Click on to expand the skill details
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "data,firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "data,middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetails, "data,lastName" ) );

            assignmentDetailsPage.clickPrintBtn();
            if ( browser.contains( "Safari" ) ) {
                Actions action = new Actions( driver );
                action.sendKeys( Keys.ESCAPE ).perform();
            } else {
                new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
                String currentWindow = driver.getWindowHandle();
                Set<String> windowHandles = driver.getWindowHandles();
                List<String> windowList = new ArrayList<>( windowHandles );
                driver.switchTo().window( windowList.get( 1 ) );
                //Now work with the dialog as with an ordinary page:  
                assignmentDetailsPage.clickClosePrintPopup();
                driver.switchTo().window( currentWindow );
            }

            Log.assertThat( assignmentDetailsPage.isNewSuccessmakerLogoDisplayed(), "Successmaker logo is displayed in Progress montoring print popup", "Successmaker logo is not displayed in Progress montoring print popup" );
            Log.testCaseResult();
            assignmentDetailsPage.clickZoomInCloseButton();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            BaseAPITest apiTest = new BaseAPITest();
            apiTest.invalidateSession( smUrl, apiTest.getJessionCookie( smUrl, username, password ) );
            Log.endTestCase();
            driver.quit();
        }
    }


    public void ExecuteCourse() throws Exception {
        BaseAPITest baseApiObject = new BaseAPITest();
        String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );
        String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" );
        String studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student1" );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, DataSetup.organizationId.toString(), teacherId, "1", Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetails, "data,personId" ) ) );
	    // Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

        // Executing math assignments in student dashboard
        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );
        LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.MATH, "95", "5", "30" );
        studentDashboardPage.logout();
        chromeDriver.quit();
    }
}
