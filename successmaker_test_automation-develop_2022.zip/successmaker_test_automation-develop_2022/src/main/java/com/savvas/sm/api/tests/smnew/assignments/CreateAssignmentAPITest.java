package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

/**
 * To test the create group API
 * 
 * @author manikanda.nagendran
 *
 */
public class CreateAssignmentAPITest extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    public String isItMt = null;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
        isItMt = configProperty.getProperty( "isMTExecution" );

    }

    /**
     * Tests the positive scenarios of create group.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "createAssignmentPositiveScenariosData", groups = { "SMK-51905", "smoke_test_case", "Assignments", "Create Assignments", "P1", "API" } )
    public void tcassignAssignment001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();

        List<String> requestIds = new ArrayList<>();
        List<String> mathCourseIds = new ArrayList<String>();
        List<String> readingCourseIds = new ArrayList<String>();

        HashMap<String, String> userDetails = new HashMap<>();
        List<String> schools = new ArrayList<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        String organizationId = RBSDataSetup.organizationIDs.get( school );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        readingCourseIds.add( "2" );
        readingCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) ) );
        readingCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) ) );
        readingCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) ) );

        mathCourseIds.add( "1" );
        mathCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
        mathCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
        mathCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );
        try {
            switch ( scenario ) {

                case "ASSIGN TO SINGLE STUDENT MATH":

                    mathCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                        requestIds.add( studentRumbaIds.get( 0 ) );
                        try {
                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.USERS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Math assignment to single student failed: " + e );
                        }

                    } );

                    break;

                case "ASSIGN TO SINGLE STUDENT READING":
                    readingCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                        requestIds.add( studentRumbaIds.get( 0 ) );
                        try {
                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.USERS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to single student failed: " + e );
                        }
                    } );
                    break;

                case "ASSIGN TO MULTIPLE STUDENTS MATH":
                    mathCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                        requestIds.add( studentRumbaIds.get( 0 ) );
                        requestIds.add( studentRumbaIds.get( 1 ) );
                        try {
                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.USERS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple students failed: " + e );
                        }

                    } );

                    break;

                case "ASSIGN TO MULTIPLE STUDENTS READING":

                    readingCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                        requestIds.add( studentRumbaIds.get( 0 ) );
                        requestIds.add( studentRumbaIds.get( 1 ) );
                        try {
                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.USERS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple students failed: " + e );
                        }

                    } );

                    break;
                case "ASSIGN TO SINGLE GROUP MATH":

                    mathCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                        try {
                            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                            requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );

                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.GROUPS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple students failed: " + e );
                        }

                    } );

                    break;

                case "ASSIGN TO SINGLE GROUP READING":

                    readingCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                        try {
                            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                            requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );

                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.GROUPS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple students failed: " + e );
                        }

                    } );

                    break;

                case "ASSIGN TO MULTIPLE GROUPS MATH":
                    mathCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );

                        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                        try {
                            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                            requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );

                            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                            requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );

                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.GROUPS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple groups failed: " + e );
                        }

                    } );

                    break;
                case "ASSIGN TO MULTIPLE GROUPS READING":
                    readingCourseIds.forEach( courseID -> {
                        HashMap<String, String> response = new HashMap<>();
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );

                        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                        try {
                            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                            requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );

                            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                            requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );

                            response = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.GROUPS_TYPE );
                            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                            verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple groups failed: " + e );
                        }

                    } );

                    break;
                default:
                    Log.fail( "Invalid case " + scenario );

            }
        } catch ( Exception e ) {
            Log.fail( "Exception : " + e );
        }

        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "createAssignmentPositiveScenariosData" )
    public Object[][] createAssignementData() {

        Object[][] inputData = {
                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create 1 group and 1 content base id", "ASSIGN TO SINGLE GROUP MATH", "200" },
                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create 1 student and 1 content base id", "ASSIGN TO SINGLE STUDENT MATH", "200" },
                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create multiple groups and 1 content base id", "ASSIGN TO MULTIPLE GROUPS MATH", "200" },
                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create multiple students and 1 content base id", "ASSIGN TO MULTIPLE STUDENTS MATH",
                        "200" },
                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create 1 student and 2 content base id", "ASSIGN TO SINGLE STUDENT READING", "200" },

                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create multiple students and 2 content base id", "ASSIGN TO MULTIPLE STUDENTS READING",
                        "200" },
                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create 1 group and 2 content base id", "ASSIGN TO SINGLE GROUP READING", "200" },

                { "Verify that the status code is 200 and response is as expected while passing valid input for user type to add a student to single course POST API Create multiple groups and 2 content base id", "ASSIGN TO MULTIPLE GROUPS READING",
                        "200" },

        };
        return inputData;
    }

    @Test ( dataProvider = "createAssignmentNegativeScenariosData", groups = { "SMK-50200", "Group", "Create Group", "P1", "API" } )
    public void tcassignAssignment002( String description, String courseID, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        Map<String, String> headers = new HashMap<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> response = new HashMap<>();
        //Parameters
        HashMap<String, String> params = new HashMap<>();

        List<String> requestIds = new ArrayList<>();

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

        String userType = null;
        String orgID = null;

        String teacherID = null;

        switch ( scenario ) {
            case "INVALID STUDENT ID":

                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = RBSDataSetup.organizationIDs.get( school );

                userType = AssignmentAPIConstants.USERS_TYPE;
                requestIds.add( studentRumbaIds.get( 0 ) );
                requestIds.add( "ffffffffff" );

                break;
            case "INVALID GROUP ID":

                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = RBSDataSetup.organizationIDs.get( school );

                userType = AssignmentAPIConstants.GROUPS_TYPE;
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                studentRumbaIds.add( studentRumbaIds.get( 0 ) );
                studentRumbaIds.add( studentRumbaIds.get( 1 ) );
                response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

                requestIds.add( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,groupId" ) );
                requestIds.add( "fff" );

                break;

            case "INVALID ORG ID":

                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = "jhgdfhg558875";

                userType = AssignmentAPIConstants.USERS_TYPE;
                requestIds.add( studentRumbaIds.get( 0 ) );

                break;

            case "INVALID COURSE ID":

                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = RBSDataSetup.organizationIDs.get( school );

                userType = AssignmentAPIConstants.USERS_TYPE;

                requestIds.add( studentRumbaIds.get( 0 ) );

                break;

            case "INVALID TEACHER ID":

                orgID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                teacherID = "54334";

                userType = AssignmentAPIConstants.GROUPS_TYPE;

                requestIds.add( studentRumbaIds.get( 0 ) );

                break;

            case "EMPTY ORG ID":

                orgID = " ";
                teacherID = RBSDataSetup.organizationIDs.get( school );

                userType = AssignmentAPIConstants.GROUPS_TYPE;

                Log.message( "Details: " + RBSDataSetup.orgStudentDetails.get( school ) );
                requestIds.add( studentRumbaIds.get( 0 ) );

                break;

            case "EMPTY COURSE ID":
                orgID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                teacherID = RBSDataSetup.organizationIDs.get( school );

                userType = AssignmentAPIConstants.GROUPS_TYPE;

                requestIds.add( studentRumbaIds.get( 0 ) );

                break;

            case "UNMAPPED STUDENT ID":
                orgID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                teacherID = RBSDataSetup.organizationIDs.get( school );

                userType = AssignmentAPIConstants.USERS_TYPE;

                requestIds.add( studentRumbaIds.get( 1 ) );

                break;

            default:
                Log.fail( "Invalid case " + scenario );
        }

        String endPoint = AssignmentAPIConstants.CREATE_ASSIGNMENT_API;
        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );

        if ( endPoint.contains( "//" ) ) {
            endPoint = endPoint.replace( "/ /", "//" );
        }

        response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, generateRequestBody( requestIds, userType ) );

        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        //        verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );

        Log.testCaseResult();
    }

    public String generateRequestBody( List<String> studentRumbaIds, String type ) throws IOException {
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createAssignmentAPIPayload" ) ) );

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            //Temp fix for grade
            listString = "";
            int temp = 0;
            for ( String studentID : studentRumbaIds ) {

                if ( temp > 0 ) {
                    listString += ",\"" + studentID + "\"" + ": 2";
                } else {
                    listString += studentID.concat( "\": 2," );
                }
                temp += 1;

            }

            if ( temp <= 1 ) {

                listString = listString.substring( 0, listString.length() - 1 );
            }

            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_GRADE_IDS ), listString ).replace( ",,", "," ) );
        } else {
            Log.fail( "Student / Group ID missing" );
        }

        if ( type.equalsIgnoreCase( AssignmentAPIConstants.USERS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );
        } else if ( type.equalsIgnoreCase( AssignmentAPIConstants.GROUPS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.GROUPS_TYPE ) );
        } else {
            Log.fail( "Invalid Type: " + type );
        }

        return requestBody.get();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "createAssignmentNegativeScenariosData" )
    public Object[][] createAssignementDataInavalid() {

        Object[][] inputData = { { "Verify that the status code is 400 and response is as expected while passing invalid organizationId to add students/groups to single course POST API", "z", "INVALID COURSE ID", "400" },
                { "Verify that the status code is 500 without passing staffId to add students to single course POST API\r\n" + " 1 Student and 1 content base id", "", "EMPTY COURSE ID", "500" },
                { "Verify that the status code is 400 and response is as expected while passing combination of valid and invalid ids to add students to single course POST API\r\n" + " Create 2 students for 1 teacher and 1 content base id", "1",
                        "INVALID STUDENT ID", "400" },
                { "Verify that the status code is 400 and response is as expected while passing combination of valid and invalid ids to add groups to single course POST API\r\n" + " Create 2 groups and 1 content base id", "1", "INVALID GROUP ID", "400" },
                { "Verify that the status code is 400 and response is as expected while passing invalid organizationId to add students/groups to single course POST API", "1", "INVALID ORG ID", "400" },

                { "Verify that the status code is 400 and response is as expected while passing invalid staffId to add students/groups to single course POST API", "1", "INVALID TEACHER ID", "400" },
                { "Verify that the status code is 500 without passing staffId to add students to single course POST API\r\n" + " 1 Student and 1 content base id", "1", "UNMAPPED STUDENT ID", "400" }

        };

        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     * @throws IOException
     */
    public boolean verifyResponse( String actualResponse, String statusCode ) throws IOException {
        boolean isVerified = false;

        Log.assertThat( smAPIprocessor.isSchemaValid( "createAssignmentSchema", statusCode, actualResponse ), "Schema is returned as expected.", "Schema is not as expected." );
        try {

            if ( statusCode.startsWith( "2" ) ) {
                String assignmentId = SMUtils.getKeyValueFromResponse( actualResponse, "data,assignmentId" );

                List<String> assignDetails = SqlHelperAssignment.getAssignmentDetails( assignmentId );
                Log.assertThat( !assignDetails.isEmpty(), "Assignment Details Present in DB", "Assignment Details not Present in DB" );
            }

        } catch ( Exception e ) {
            Log.fail( "Issue in validating the response" );
        }

        return isVerified;
    }

}