package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class GroupsAssignmentListTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String groupDetails;
    private String groupName;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String student1;
    private String student2;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        student2 = RBSDataSetup.getMyStudent( school, username );
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.USERID ) );
        HashMap<String, String> groupDetailsMap = new HashMap<>();

        groupName = "SM Regression Group" + System.nanoTime();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails = createGroup.get( Constants.BODY );
        Log.message( groupDetails );
    }

    @Test ( description = "SMK-8703 Verify Teacher is able to navigate in between tabs", priority = 1 )
    public void tcSMK8703( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK8703: Verify Teacher is able to navigate in between tabs <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            //Verify Assignments Tab
            groupsTab.clickAssignmentSideSubNav();
            groupsTab.clickGroupsSubNav( Constants.ASSIGNMENTS );
            SMUtils.waitForElement( driver, groupsTab.assignmentsHeader );
            Log.assertThat( groupsTab.assignmentsHeader.getText().equals( Constants.ASSIGNMENTS ), "The 'Assignments' tab is loaded successfully", "The 'Assignments' tab is not loaded successfully" );

            //Verify Mastery Tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            //Verify Settings Tab
            groupsTab.clickGroupsSubNav( Constants.SETTINGS );
            SMUtils.waitForElement( driver, groupsTab.settingsHeader );
            Log.assertThat( groupsTab.settingsHeader.getText().equals( Constants.SETTINGS ), "The 'Settings' tab is loaded successfully", "The 'Settings' tab is not loaded successfully" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8705 & SMK-8707 By login as teacher, Create a group with students and do not add Assignments, verify Zero state message is displaying under Assignments sub tab", priority = 2 )
    public void tcSMK8705( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK8705: By login as teacher, Create a group with students and do not add Assignments, verify Zero state message is displaying under Assignments sub tab <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.clickGroupsSubNav( Constants.ASSIGNMENTS );
            SMUtils.waitForElement( driver, groupsTab.assignmentHeaderNOData );
            Log.assertThat( groupsTab.assignmentHeaderNOData.getText().equals( Constants.GroupUIConstants.ZEROSTATE_HEADER ), "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is displayed correctly",
                    "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is not displayed correctly" );
            Log.assertThat( groupsTab.assignmentNoMsg.getText().equals( Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG ), "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is displayed correctly",
                    "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is not displayed correctly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            driver.quit();
        }
    }

    @Test ( description = "SMK-8704,SMK-8706,SMK-8714 Verify by clicking on Assignments tab, list of all assignments for that particular Group is displaying", priority = 3 )
    public void tcSMK8704( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String assignmentName = Constants.GroupsAssignments.MATH;
    	Date date = new Date();
        TimeZone zone = TimeZone.getTimeZone( "US/Arizona" );
        DateFormat formatter = new SimpleDateFormat( "MM/dd/yyyy" );
        formatter.setTimeZone( zone );
        String dateToday = formatter.format( date ).toString();
        Log.testCaseInfo( "SMK-8704,SMK-8706,SMK-8714: Verify by clicking on Assignments tab, list of all assignments for that particular Group is displaying <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();

            // Adding Custom courses to Groups
            coursePage.addCourseToGroups();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.clickGroupsSubNav( Constants.ASSIGNMENTS );
            HashMap<String, HashMap<String, String>> assignmentDetails = groupsTab.getAssignmentDetailsBasedOnGroupSubNav();
            Log.assertThat( assignmentDetails.get( "Assignment1" ).get( "Assignment Title" ).equals( assignmentName ), "The assignmentName " + assignmentName + " is displayed correctly",
                    "The assignmentName " + assignmentName + " is not displayed correctly" );
            Log.assertThat( assignmentDetails.get( "Assignment1" ).get( "Date Assigned" ).equals( dateToday ), "The DateAssigned date is displayed correctly", "The DateAssigned Date is not displayed correctly:Expected Date " + dateToday );
            GroupPage groupPage = new GroupPage( driver );
            Log.assertThat( groupPage.viewAssignmentBtnStatic.isDisplayed(), "The 'View Assignment' button is displayed", "The 'View Assignment' button is not displayed" );
            //Verify View Assignment Button
            groupsTab.clickViewAssignmentButtonBasedOnCourse( assignmentName );
            driver.navigate().back();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8713 and SMK-8720 Delete all the assignments from the group, verify Zero state message is displaying under Assignments sub tab", priority = 1 )
    public void tcSMK8713( ITestContext context ) throws Exception {
        String assignmentName = Constants.GroupsAssignments.MATH;
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        Log.testCaseInfo( "SMK8713 and tcSMK8720: Delete all the assignments from the group, verify Zero state message is displaying under Assignments sub tab <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();

            // Adding Custom courses to Groups
            coursePage.addCourseToGroups();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.clickGroupsSubNav( Constants.ASSIGNMENTS );
            groupsTab.deleteAllAssignmentsInGroupsSideNav();
            SMUtils.waitForElement( driver, groupsTab.assignmentHeaderNOData );
            Log.assertThat( groupsTab.assignmentHeaderNOData.getText().equals( Constants.GroupUIConstants.ZEROSTATE_HEADER ), "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is displayed correctly",
                    "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is not displayed correctly" );
            Log.assertThat( groupsTab.assignmentNoMsg.getText().equals( Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG ), "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is displayed correctly",
                    "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is not displayed correctly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher is able to see a drop down of actions when clicking the ellipses for each assignment", priority = 5 )
    public void tcSMK8715( ITestContext context ) throws Exception {
        String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
        String assignmentName = Constants.GroupsAssignments.MATH;
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        Log.testCaseInfo( "SMK8715: Verify the teacher is able to see a drop down of actions when clicking the ellipses for each assignment <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();

            // Adding Custom courses to Groups
            coursePage.addCourseToGroups();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.clickGroupsSubNav( Constants.ASSIGNMENTS );
            groupsTab.pauseAllAssignmentsInGroupsSideNav();
            groupsTab.deleteAllAssignmentsInGroupsSideNav();
            SMUtils.waitForElement( driver, groupsTab.assignmentHeaderNOData );
            Log.assertThat( groupsTab.assignmentHeaderNOData.getText().equals( Constants.GroupUIConstants.ZEROSTATE_HEADER ), "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is displayed correctly",
                    "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is not displayed correctly" );
            Log.assertThat( groupsTab.assignmentNoMsg.getText().equals( Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG ), "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is displayed correctly",
                    "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is not displayed correctly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for each Paused assignment, the teacher is able to see 'Paused' message.", priority = 6 )
    public void tcSMK8722( ITestContext context ) throws Exception {
        String assignmentName = Constants.GroupsAssignments.MATH;
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        Log.testCaseInfo( "SMK8722: Verify for each Paused assignment, the teacher is able to see 'Paused' message. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();

            // Adding Custom courses to Groups
            coursePage.addCourseToGroups();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.clickAssignmentSideSubNav();
            groupsTab.pauseAllAssignmentsInGroupsSideNav();
            boolean pausedStatus = groupsTab.verifyAssignmentIsPaused( assignmentName );
            Log.assertThat( pausedStatus, "The 'Paused' Badge is displayed for paused assignments", "The 'Paused' Badge is not displayed for paused assignments" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }
}
