package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class MasterySmokeTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher7" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Mastery Report Page", priority = 1 )
    public void tcSMBVT030() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT030: Verify Mastery Report Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastry Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();

            // Verifying the headers and titles
            Log.assertThat( masteryPage.getMasteryHeading().equals( "Mastery" ), "Header title displayed properly!", "Header title not displayed properly" );
            Log.assertThat( masteryPage.getMasteryStep1Heading().equals( "STEP 1: Select Groups or Students" ), "Students and group title displayed properly!", "Students and group title not displayed properly" );
            Log.assertThat( masteryPage.getMasteryStep2Heading().equals( "STEP 2: Refine Search" ), "Refine search title displayed properly!", "Refine search title not displayed properly" );

            // Initiating the mastry filter components
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();

            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            masteryFiltersComponent.setDropDownMS( "Groups" );
            List<String> groupsFromUI = masteryFiltersComponent.getValuesFromDropDownMS();
            Log.assertThat( groupsList.equals( groupsFromUI ), "Groups displayed successfully!", "Groups not displayed properly", driver );

            // getting the student names from data setup
            List<String> studentList = new ArrayList<>();
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            for ( int studentCount = 1; studentCount <= DataSetup.teacherStudentMap.get( username ).size(); studentCount++ ) {
                studentList.add( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add( SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,firstName" ) + ", " + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,lastName" ) );
            }

            // Get students from UI
            masteryFiltersComponent.setDropDownMS( "Students" );
            List<String> studentsFromUI = masteryFiltersComponent.getValuesFromDropDownMS();

            // Student verifications
            Log.assertThat( SMUtils.sortList( studentFirstNameAndLastNameList ).equals( SMUtils.sortList( studentsFromUI ) ), "Students displayed properly", "Students are not displayed properly" );

            // Getting assignments from UI
            masteryFiltersComponent.selectSubject( "Math" );
            masteryFiltersComponent.setDropDownMS( "Assignments" );
            List<String> mathAssignmentsFromUI = masteryFiltersComponent.getValuesFromDropDownMS();
            masteryFiltersComponent.selectSubject( "Reading" );
            masteryFiltersComponent.setDropDownMS( "Assignments" );
            List<String> readingAssignmentsFromUI = masteryFiltersComponent.getValuesFromDropDownMS();
            List<String> assignmentListUI = SMUtils.mergeList( mathAssignmentsFromUI, readingAssignmentsFromUI );

            // Getting assignment from data setup
            List<String> assignmentList = new ArrayList<>();
            String assignments = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentCount = 1; assignmentCount <= SMUtils.getWordCount( assignments, "name" ); assignmentCount++ ) {
                assignmentList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", assignmentCount ) );
            }

            // Validations for assignments
            Log.assertThat( SMUtils.sortList( assignmentList ).equals( SMUtils.sortList( assignmentListUI ) ), "Assignments are displayed properly!", "Assignments are not displayed properly!" );

            // Getting standards
            List<String> readingStandardsFromUI = masteryFiltersComponent.getAllSkillStandardsDropDownValues();
            masteryFiltersComponent.selectSubject( "Math" );
            List<String> mathStandardsFromUI = masteryFiltersComponent.getAllSkillStandardsDropDownValues();

            // Getting standards from data

            List<String> readingStandardsListFromData = Constants.READING_SUCCESSMAKER_STANDARDS;
            List<String> mathStandardsListFromData = Constants.MATH_SUCCESSMAKER_STANDARDS;

            // Validations for standards
            Log.assertThat( readingStandardsFromUI.equals( readingStandardsListFromData ), "Reading Standards are displayed properly!", "Reading Standards are not displayed properly!" );
            Log.assertThat( mathStandardsFromUI.equals( mathStandardsListFromData ), "Math Standards are displayed properly!", "Math Standards are not displayed properly!" );
            // Verify apply filter
            masteryFiltersComponent.applyFilter();
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }
}
