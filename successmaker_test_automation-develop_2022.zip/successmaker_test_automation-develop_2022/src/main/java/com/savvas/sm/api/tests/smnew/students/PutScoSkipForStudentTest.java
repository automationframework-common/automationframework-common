package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class PutScoSkipForStudentTest extends EnvProperties {
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public String endPoint = "lms/web/assignments/scoskip/{auId}";

    //private String userId ;
    private String sessionId;
    private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    private String browser;
    String assignmentUserId;

    public static String groupName = Constants.GROUP_NAME;

    public HashMap<String, String> GroupDetails = new HashMap<>();
    public HashMap<String, String> AssignmentDetails = new HashMap<>();
    public List<String> courseIdsForAssign = new ArrayList<>();

    String teacherBearertoken = null;

    private String currentPhase = "CustomCourse";

    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Reading Course Names
        courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.SM_FOCUS_READING_GRADE1, Constants.SM_FOCUS_READING_GRADE1 );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
            courseIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

            courseIds.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        } catch ( Exception e ) {
            Log.message( "Issue in Math Custom course creation!! - " + e.getMessage() );
        }

        //Reading course Ids
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        courseIds.put( Constants.SM_FOCUS_READING_GRADE1, AssignmentAPIConstants.FOCUS_READING );

        Log.message( "Course Ids for " + school + ": " + courseIds );

        // Assigning the courses to the students
        AssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        AssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        AssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, AssignmentDetails, studentRumbaIds, new ArrayList( courseIds.values() ) );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        Log.message( "Assignment JSON= " + assignmentDetailsJson );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );

            Log.message( "Assignment IDs - " + assignmentIds );
        }

    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "smoke_test_case", "SMK-66841", "[Automation] API to Set Sco Skipped: PUT /lms/web/assignments/scoskip/", "API", "P1" }, priority = 1 )
    public void putUpdateStudentScoSkip001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Response response = null;

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        //Pathparams
        Map<String, String> pathParams = new HashMap<String, String>();

        //Queryparams
        Map<String, Object> queryParams = new HashMap<String, Object>();

        String assignmentUserId;
        String scoHistory;
        String scoId;

        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUsername, "testing123$" ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
        headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, studentUserId );

        switch ( scenarioType ) {
            case "DEFAULT_READING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );

                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                Log.message( headers + "" );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                queryParams.put( StudentsAPIConstants.SCO_ID, scoId );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase );
                Log.message( pathParams + "" );
                break;

            case "VALID__SETTING_READING":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                Log.message( headers + "" );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                queryParams.put( StudentsAPIConstants.SCO_ID, scoId );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase );
                Log.message( pathParams + "" );
                break;

            case "VALID__SKILL_READING":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                Log.message( headers + "" );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                queryParams.put( StudentsAPIConstants.SCO_ID, scoId );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase );
                break;

            case "VALID__STANDARDS_READING":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                Log.message( headers + "" );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                queryParams.put( StudentsAPIConstants.SCO_ID, scoId );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase );
                break;

            case "VALID__READING_FOCUS":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.SM_FOCUS_READING_GRADE1 ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                Log.message( headers + "" );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                queryParams.put( StudentsAPIConstants.SCO_ID, scoId );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase );
        }
        response = PUTWITHPATHPARAMS( smUrl, headers, pathParams, queryParams, endPoint );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC01: ", "200", "Verify the status code is 200 when valid data is given for assignment which has been created from Deafult Reading for PUT Method.", "DEFAULT_READING" },
                { "TC02: ", "200", "Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by setting) for PUT Method.", "VALID__SETTING_READING" },
                { "TC03: ", "200", "Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by skills) for PUT Method.", "VALID__SKILL_READING" },
                { "TC04: ", "200", "Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by standard) for PUT Method.", "VALID__STANDARDS_READING" },
                { "TC05: ", "200", "Verify the status code is 200 when valid data is given for assignment which has been created from Focus Reading for PUT Method.", "VALID__READING_FOCUS" } };

        return data;
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-66841", "[Automation] API to Set Sco Skipped: PUT /lms/web/assignments/scoskip/", "API" }, priority = 1 )
    public void putUpdateStudentScoSkip002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        //Pathparams
        Map<String, String> pathParams = new HashMap<String, String>();

        //Queryparams
        Map<String, Object> queryParams = new HashMap<String, Object>();

        String assignmentUserId;
        String sessionId;
        String scoHistory;
        String scoId;

        switch ( scenarioType ) {
            case "INVALIDAUTH_REQUEST":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                headers.put( Constants.AUTHORIZATION, new RBSUtils().getAccessToken( studentUsername, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, studentUserId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                break;

            case "TEACHER_ID_IN_HEADER":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                headers.put( Constants.AUTHORIZATION, new RBSUtils().getAccessToken( studentUsername, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, teacherUserId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                break;

            case "INVALID_ASSIGNMENTUSER_ID":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId + 123 );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUsername, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, studentUserId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                break;
            case "INVALID_CURRENT_PHASE_VALUE":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUsername, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, studentUserId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );

                queryParams.put( StudentsAPIConstants.SCO_ID, scoId );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase + 123 );
                break;
            case "INVALID_SCO_ID":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                scoHistory = getScoHistory();
                scoId = getScoId( scoHistory );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUsername, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, studentUserId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
                queryParams.put( StudentsAPIConstants.SCO_ID, scoId + 123 );
                queryParams.put( StudentsAPIConstants.SESSIONID, 0 );
                queryParams.put( StudentsAPIConstants.CURRENT_PHASE, currentPhase );
                break;

        }
        Response response = PUTWITHPATHPARAMS( smUrl, headers, pathParams, queryParams, endPoint );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC02: ", "401", "Verify the status code is 401 when Invalid/expired Autorization given.", "INVALIDAUTH_REQUEST" },
                { "TC03: ", "401", "Verify the status code is 401 when Teacher ID is given in header insted of student ID.", "TEACHER_ID_IN_HEADER" },
                { "TC04: ", "400", "Verify the status code is 400 when Invalid/corrupt Assignment User ID(-1) is given.", "INVALID_ASSIGNMENTUSER_ID" },
                { "TC05: ", "500", "Verify the status code is 500 when we use incorrect currentPhaseis in enpoint.", "INVALID_CURRENT_PHASE_VALUE" },
                { "TC06: ", "500", "Verify the response code is 500 for the String type assignment user id", "INVALID_SCO_ID" } };
        return data;

    }

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }

    // method for put with input parameter
    public static Response PUTWITHPATHPARAMS( String baseURL, Map<String, String> headers, Map<String, String> inputData, Map<String, Object> queryParams, String url ) {
        setBaseURL( baseURL );
        Response resp = RestAssured.given().headers( headers ).pathParams( inputData ).queryParams( queryParams ).put( url ).andReturn();
        Log.message( "running PUT command" );
        Log.message( "URL \n" + baseURL );
        Log.message( "Header \n" + resp.getHeaders().toString() );
        Log.event( "Response body \n" + resp.asString() );
        Log.message( "Time taken to get response is \n" + resp.getTime() + " milli second" );
        return resp;

    }

    // method for setting of base url
    public static void setBaseURL( String baseURL ) {
        try {
            if ( !baseURL.isEmpty() || !baseURL.contains( null ) ) {
                RestAssured.baseURI = baseURL;
            }
        } catch ( NullPointerException e ) {
            System.out.println( "Base URL is set as null" );
        }
    }

    public String getuserAssignmentId( String studentRumbaId ) {
        List<Object[]> userAssignmentId = SQLUtil.executeQuery( "select assignment_user_id from assignment_user where person_id ='" + studentRumbaId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : userAssignmentId ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String userAssID = arrList.get( 0 );
        return userAssID;
    }

    public String getScoHistory() {
        List<Object[]> Sco_History = SQLUtil.executeQuery( "select exercise_set_sco_id from school.read_assignment_sco_history order by random() limit 1" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_History ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String ssID = arrList.get( 0 );
        return ssID;
    }

    public String getScoId( String scoHis ) {
        List<Object[]> Sco_Id = SQLUtil.executeQuery( "select exercise_set_sco_name from successmaker.exerset_sco where exercise_set_sco_id='" + scoHis + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_Id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String ssID = arrList.get( 0 );
        return ssID;

    }

}
