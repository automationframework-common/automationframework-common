package com.savvas.sm.api.tests.smnew.organization;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.OrganizationAPIConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class GetOrganizationFlagsTest extends UserAPI {

    private String smUrl;
    private String username;
    private String password;
    private String orgId;
    private String userId;
    private Map<String, String> response;

    @BeforeClass(alwaysRun = true)
    public void beforeTest() throws Exception {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( Constants.APP_URL_FROM_CONFIG );
        orgId = configProperty.getProperty( Constants.ORG_ID_FROM_CONFIG );

        HashMap<String, String> userDetails = new HashMap<>();

        // Creating Admin user data to login
        String districtAdmin = "District_Admin" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_FROM_CONFIG ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, districtAdmin );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
        // Creating District Admin
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        String adminDetails = new RBSUtils().createUser( userDetails );
        // Retrieving username and resetting password from the response
        username = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID ) );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( dataProvider = "getData", groups = { "smoke_test_case","Smoke getOrganizationFlags001","get organization flags","P1","SMK-52630", "Get Organizations Flags", "API" }, priority = 1 )
    public void getOrganizationFlags001( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();
        String responseMessage;

        // End point for API
        String endPoint = OrganizationAPIConstants.GET_ORGANIZATION_FLAGS;

        Log.testCaseInfo( testcaseName + testcaseDescription );

        switch ( scenarioType ) {
            case "VALID":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getOrganizationFlags_SMK-52630", statusCode, response.get( Constants.BODY ) ), "Schema Validated for status code " + statusCode,
                        "Schema Validation failed for status code " + statusCode );
                Log.assertThat( responseMessage.equals( OrganizationAPIConstants.GET_SUCCESS_MSG ), OrganizationAPIConstants.VALID_RESPONSE_MSG, OrganizationAPIConstants.INVALID_RESPONSE_MSG );
                break;
            case "SSO TOKEN NOT GIVEN":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "INVALID SSO TOKEN GIVEN":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) + Constants.INVALID );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT PARAMETER":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT ORG_ID":
                headers.put( OrganizationAPIConstants.USERID, userId );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT USER_ID":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT ORG_ID AND USER_ID":
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "INVALID USER_ID":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId + Constants.INVALID );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "INVALID ORG_ID":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId + Constants.INVALID );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                Log.message( headers + "" );
                params = new HashMap<>();
                params.put( OrganizationAPIConstants.FLAGS, OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED + "," + OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
        }
        Log.message( response.toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001: ", "200", "Verify all the flags are returned in response with 200 response code for given district", "VALID" },
                { "TC002: ", "401", "Verify status code 401 when SSO token  is not passed in header parameter", "SSO TOKEN NOT GIVEN" },
                { "TC003: ", "401", "Verify status code 401 when invalid SSO token  is passed in header parameter", "INVALID SSO TOKEN GIVEN" }, { "TC004: ", "400", "Verify status code 400 when no parameter", "WITHOUT PARAMETER" },
                { "TC005: ", "400", "Verify status code 400 when org_id not passed in header", "WITHOUT ORG_ID" }, { "TC006: ", "401", "Verify status code 401 when user_id not passed in header", "WITHOUT USER_ID" },
                { "TC007: ", "401", "Verify status code 401 when org_id and user_id not passed in header", "WITHOUT ORG_ID AND USER_ID" }, { "TC008: ", "401", "Verify status code 401 when invalid user_id passed in header", "INVALID USER_ID" },
                { "TC009: ", "403", "Verify status code 403 when invalid org_id passed in header", "INVALID ORG_ID" } };
    }
    
    
}