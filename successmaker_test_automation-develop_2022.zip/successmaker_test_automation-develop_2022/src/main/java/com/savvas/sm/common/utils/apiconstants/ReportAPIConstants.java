package com.savvas.sm.common.utils.apiconstants;

public interface ReportAPIConstants {
    String MATH_ID = "1";
    String READING_ID = "2";

    String STUDENT_ID = "[\"ffffffff6270f68d1bc9c2589bc92e15\"]";
    String SUBJECT = "subject";
    String START_DATE = "startDate";
    String END_DATE = "endDate";
    String STUDENTS = "students";
    String LIMIT = "limit";
    String OFFSET = "offset";
    String ASSIGNMENT_IDS = "assignmentIds";
    String ORDER_BY = "orderBy";
    String WEEK = "week";
    String TEACHER = "teacher";
    String USERID_HEADER = "userId";
    String districtId = "district-id";
    String ORGID_HEADER = "orgId";
    String ORG_ID = "8a720b467f656b2d017f656f4f7a0000";
    String USER_ID = "ffffffff62264613cf01ac0030da50f7";
    String differentDistrictID = "8a72042d81a3e1270181c53f3006007f";

    String PERSON_ID = "PERSON_ID";
    String ASSIGNMENT_ID = "ASSIGNMENT_ID";
    String CURRENT_LEVEL = "CURRENT_LEVEL";
    String TIME_SINCE_IP = "TIME_SINCE_IP";
    String TOTAL_MASTERED_SKILLS = "TOTAL_MASTERED_SKILLS";
    String SESSION_LENGTH = "SESSION_LENGTH";
    String AVERAGE_MIN_PER_DAY = "AVERAGE_MIN_PER_DAY";
    String CURRENT_LEARNING_RATE = "CURRENT_LEARNING_RATE";
    String ADDITIONAL_TIME_TO_REACH_TARGET = "ADDITIONAL_TIME_TO_REACH_TARGET";
    String ADDITIONAL_MINUTES_PER_DAY_TO_REACH_TARGET = "ADDITIONAL_MINUTES_PER_DAY_TO_REACH_TARGET";
    String ZERO_STATE = "No Data Found for selected criteria";
    String CURRENT_COURSE_LEVEL = "CURRENT_COURSE_LEVEL";
    String TOTAL_CORRECT = "TOTAL_CORRECT";
    String TOTAL_ATTEMPTS = "TOTAL_ATTEMPTS";
    String SESSION_HELP_COUNT = "SESSION_HELP_COUNT";
    String TOTAL_SESSION = "TOTAL_SESSION";

    String STRAND_NAME = "STRAND_NAME";
    String STRAND_LEVEL = "STRAND_LEVEL";
    String LO_DESCRIPTION = "LO_DESCRIPTION";
    String TRUE = "true";
    String FALSE = "false";

    String AUTHORISATION = "Authorization";
    String REQUESTID = "{requestID}";
    String PAYLOAD_REPORT_TYPE = "{reportType}";
    String PAYLOAD_PERSON_REPORT = "{personReport}";
    String PAYLOAD_FILTER_NAME = "{filterName}";
    String PAYLOAD_SUBJECT = "{subject}";
    String PAYLOAD_USER_TYPE = "{userType}";
    String REPORT_TYPE = "LS";

    String PS_REPORT_ENDPOINT = "/teacher-reports/report/psreport";
    String LS_REPORT_ENDPOINT = "/teacher-reports/report/lsreport";
    String CP_REPORT_ENDPOINT = "/teacher-reports/report/cpreport";
    String AOD_REPORT_ENDPOINT = "/teacher-reports/report/aodreport";
    String POST_SAVE_REPORT = "/teacher-reports/report/option/save";
    String PUT_EDIT_REPORT = "/teacher-reports/report/option/save/{requestID}";
    String MASTERY_REPORT_ENDPOINT = "/teacher-reports/report/masteryreport";
    String ISP_REPORT_ENDPOINT = "/teacher-reports/report/ispReport";
    String GET_SAVE_REPORT = "/teacher-reports/report/option/requests/{requestID}";
    String GET_SAVE_REPORT_OPTION = "/teacher-reports/report/option/requests";
    String GET_SAVE_REPORT_INVALID = "/teacher-reports/report/option//{requestID}";
    String GET_SAVE_REPORT_OPTION_INVALID = "/teacher-reports/report//request";
    String GET_CONTENT_SERVER_URL = "/lms/web/nyr/getContentUrl";
    
    String SUCCESS_ORDER_BY = "Output is order by ";
    String FAILED_ORDER_BY = "Output is not order by ";

    String INVALID = "invalid";
    String TNS_USESRNAME = "tns:UserName";
    String DISTRITC_ID = "district-id";
}
