package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students.Mastery_DropDowns;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentsMasteryListingTest extends BaseTest {

    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String teacherDetails;
    //  private static String studentDetails;
    private String courseName;
    private List<String> mathAssignments = new ArrayList<>();
    private List<String> readingAssignments = new ArrayList<>();
    private String skillCourseMath = null;
    private String settingsCourseMath = null;
    private String skillCourseRead = null;
    private String settingsCourseRead = null;

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;
    MasterySummaryComponent masteryComponent;

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify list of all field available on Student mastery page, Like Los, skill/standards, grade", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 1 )
    public void tcStudentMasteryListing001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcStudentMasteryListing001:Verify list of all field available on Student mastery page, Like Los, skill/standards, grade <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            CoursesPage navigateToCourseListingPage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            navigateToCourseListingPage.clickMathCourse();
            navigateToCourseListingPage.clickAssignBtn();
            navigateToCourseListingPage.addCourseToStudents();

            navigateToCourseListingPage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            navigateToCourseListingPage.clickReadingCourse();
            navigateToCourseListingPage.clickAssignBtn();
            navigateToCourseListingPage.addCourseToStudents();

            AssignmentsPage navigateToAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignments = navigateToAssignmentsPage.getAssignmentListBasedOnSubject( Constants.MATH );
            readingAssignments = navigateToAssignmentsPage.getAssignmentListBasedOnSubject( Constants.READING );

            for ( String assignment : mathAssignments ) {
                if ( assignment.toLowerCase().contains( "skill" ) ) {
                    skillCourseMath = assignment;
                } else if ( assignment.toLowerCase().contains( "setting" ) ) {
                    settingsCourseMath = assignment;
                }
            }

            for ( String assignment : readingAssignments ) {
                if ( assignment.toLowerCase().contains( "skill" ) ) {
                    skillCourseRead = assignment;
                } else if ( assignment.toLowerCase().contains( "setting" ) ) {
                    settingsCourseRead = assignment;
                }
            }

            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();
            attendCourseAsStudent();
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "SMK-13552:-Verify the Mastery in student tab if student attended sessions and Completed Los as Mastered" );
            Log.assertThat( studentsTab.isMasteryDisplayed(), "The Mastery sub-navigation is displayed on Student mastery page", "The Mastery sub-navigation is not displayed on Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13551:-Verify the Legends and its colors in students > Mastery" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.LEGENDS ), "The Legends are displayed in the mastery Page", "The Legends are not displayed in the mastery Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13553:- Verify the grade in Student-Mastery tab." );
            Log.assertThat( masteryComponent.verifyGradeIsDisplayed(), "Grade is displayed under mastery tab in the Student mastery page", "Grade is not displayed under mastery tab in the Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13554:-Verify the hierarchy of the Skill or standard in Student-Mastery tab." );
            Log.assertThat( masteryComponent.verifySkillHeadingIsDisplayed(), "Skill heading is displayed under domain and cluster in mastery tab of the Student mastery page",
                    "Skill heading is not displayed under domain and cluster in mastery tab of the Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13561:- Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.assertThat( masteryComponent.verifyLOColor( browser ), "Teacher is able to see the LO as a blue link on Student mastery page",
                    "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills on Student mastery page" );
            Log.testCaseResult();

            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify top level , middle level skill/Standards for math and reading on Student mastery page", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 1 )
    public void tcStudentMasteryListing002() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcStudentMasteryListing002:Verify top level , middle level skill/Standards for math and reading on Student mastery page <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            //Select Reading
            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            studentsTab.clickApplyFilter();

            SMUtils.logDescriptionTC( "SMK-13557:- Verify the Top level hierarchy, when Reading subject is chosen with skills/Standards" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.TOPLEVELHIERARCY ), "The Top Level Hierarcy are displayed in the mastery Page", "The Top Level Hierarcy are not displayed in the mastery Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13559:- Verify the middle level hierarchy, when Reading subject is chosen with skills/standard" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.MIDDLELEVELHIERARCY ), "The Middle Level Hierarcy are displayed in the mastery Page", "The Middle Level Hierarcy are not displayed in the mastery Page" );
            Log.testCaseResult();

            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 0 ) );
            //Click appply filter Buton
            studentsTab.clickApplyFilter();
            SMUtils.logDescriptionTC( "SMK-13555:- Verify the Top level hierarchy, when Math subject is chosen with skills" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.TOPLEVELHIERARCY ), "The Top Level Hierarcy are displayed in the mastery Page", "The Top Level Hierarcy are not displayed in the mastery Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13558:- Verify the middle level hierarchy, when Math subject is chosen with skills/standard" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.MIDDLELEVELHIERARCY ), "The Middle Level Hierarcy are displayed in the mastery Page", "The Middle Level Hierarcy are not displayed in the mastery Page" );
            Log.testCaseResult();

            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Skill Description. for subjects is chosen with skills/standard", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 1 )
    public void tcStudentMasteryListing003() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	Log.testCaseInfo( "tcAssignmentMastery003: Verify the Skill Description. for subjects is chosen with skills/standard <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            SMUtils.logDescriptionTC( "SMK-13566 - Verify the Skill Description. when Math subject is chosen with skills/standard" );
            masteryComponent = new MasterySummaryComponent( driver );
            Log.assertThat( masteryComponent.getLeafNodeContent().stream().allMatch( loDescription -> !loDescription.isEmpty() ), "Skill description is displayed for math related assignments ",
                    "LO description is not displayed for math related assignments " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13567 - Verify the Skill Description. when Reading subject is chosen with skills/standard" );
            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            studentsTab.clickApplyFilter();
            Log.assertThat( masteryComponent.getLeafNodeContent().stream().allMatch( loDescription -> !loDescription.isEmpty() ), "Skill description is displayed for reading related assignments ",
                    "LO description is not displayed for math related assignments " );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Mastery in student tab for all type of assignments", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 1 )
    public void tcStudentMasteryListing004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcAssignmentMastery004: Verify the Mastery in student tab for all type of assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );

            SMUtils.logDescriptionTC( "SMK-13582 - Verify Student tab >> Mastery for Default Math assignment" );
            studentsTab.selectDropDownValues( Mastery_DropDowns.ASSIGNMENTS, Constants.MATH );
            masteryComponent = masteryFilter.applyFilter();
            Log.assertThat( masteryComponent.verifyGradeIsDisplayed(), "Mastery displayed for default math assignment!", "Mastery is not displayed for default math assignment!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13586 - Verify the Mastery after attended the Math Custom by Skill assignment." );

            studentsTab.selectDropDownValues( Mastery_DropDowns.ASSIGNMENTS, skillCourseMath );
            masteryComponent = masteryFilter.applyFilter();
            Log.assertThat( masteryComponent.verifyGradeIsDisplayed(), "Mastery displayed for math-custom by skill assignment!", "Mastery is not displayed for math-custom by skill assignment!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13584 - Verify Student tab >> Mastery for Math Custom by Setting assignment" );
            studentsTab.selectDropDownValues( Mastery_DropDowns.ASSIGNMENTS, settingsCourseMath );
            masteryComponent = masteryFilter.applyFilter();
            Log.assertThat( masteryComponent.verifyGradeIsDisplayed(), "Mastery displayed for math-custom by setting assignment!", "Mastery is not displayed for math-custom by setting assignment!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13583 - Verify Student tab >> Mastery for Default Reading assignment" );
            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            studentsTab.selectDropDownValues( Mastery_DropDowns.ASSIGNMENTS, Constants.READING );
            studentsTab.clickApplyFilter();
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.TOPLEVELHIERARCY ), "Mastery displayed for default reading assignment!", "Mastery is not displayed for default reading assignment!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13589 - Verify the Mastery after attended the Reading Custom by Skill assignment." );
            studentsTab.selectDropDownValues( Mastery_DropDowns.ASSIGNMENTS, skillCourseRead );
            studentsTab.clickApplyFilter();
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.TOPLEVELHIERARCY ), "Mastery displayed for reading-custom by skill assignment!", "Mastery is not displayed for reading-custom by skill assignment!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13587 - Verify Student tab >> Mastery for Reading Custom by Setting assignment" );
            studentsTab.selectDropDownValues( Mastery_DropDowns.ASSIGNMENTS, settingsCourseRead );
            studentsTab.clickApplyFilter();
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.TOPLEVELHIERARCY ), "Mastery displayed for reading-custom by setting assignment!", "Mastery is not displayed for reading-custom by setting assignment!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify LO detail page for math and Reading", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 1 )
    public void tcStudentMasteryListing005() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcAssignmentMastery005: Verify LO detail page for math and Reading. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Create a course with single LO
            courseName = "MathSingleLOCourse__" + System.nanoTime();

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.createCustomByStandardCourse( courseName, Constants.MATH );

            // Assign custom course to students
            coursePage.clickCourseName( courseName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            // Assign focus course to students
            teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Constants.SM_FOCUS_READING_GRADE1 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );

            // Selecting subject drop-down as Math with Standards
            masteryFilter.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            MasterySummaryComponent masterySummaryComponent = masteryFilter.applyFilter();
            // Navigating to LO view page
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-13597- Verify the Skill Evaluated field will be display based on standard for a Math with Standards" );
            SMUtils.logDescriptionTC( "SMk-13601- Verify the Attempts Column for a Math with Standards" );

            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Skill Evaluated field is display", "Skill Evaluated field is not display" );

            masteryDetailsPage.clickBackBtn();

            SMUtils.nap( 1 ); // Required for Loading the dropdown!
            // Selecting subject drop-down as Reading with Standards
            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );
            masteryFilter.selectSkillStandards( Constants.READING_SKILLS_DROPDOWN_LIST.get( 1 ) );
            masteryFilter.applyFilter();

            // Navigating to LO view page
            masterySummaryComponent.navigateToLoViewPage( masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-13598- Verify the Skill Evaluated field will be display based on standard for a Reading with Standards" );
            SMUtils.logDescriptionTC( "SMK-13602- Verify the Attempts Column for a Reading with Standards" );
            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Skill Evaluated field is display for a Reading with Standards", "Skill Evaluated field is not display for a Reading with Standards" );
            Log.testCaseResult();
            masteryDetailsPage.clickBackBtn();

            // Selecting subject drop-down as Math with Successmaker Mastery Skills - Math
            masteryFilter.applyFilter();
            masterySummaryComponent.navigateToLoViewPage( masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-13599- Verify the Attempts Column for a Math with 'Successmaker Mastery Skills - Math'" );
            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Attempts Column is displayed for a Math with 'Successmaker Mastery Skills - Math'", "Attempts Column is not displayed for a Math with 'Successmaker Mastery Skills - Math'" );
            Log.testCaseResult();
            masteryDetailsPage.clickBackBtn();

            // Selecting subject drop-down as Reading with Successmaker Mastery Skills - Reading
            masteryFilter.applyFilter();
            masterySummaryComponent.navigateToLoViewPage( masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-13600- Verify the Attempts Column for a Reading with 'Successmaker Mastery Skills - reading'" );
            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Attempts Column is displayed for a Reading with 'Successmaker Mastery Skills - Reading'", "Attempts Column is not displayed for a Reading with 'Successmaker Mastery Skills - Reading'" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify mastery and LO status in Mastery tab in Student details page", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 3 )
    public void tcStudentMasteryListing006() throws Exception {

    	EventFiringWebDriver driver = null;
    	// Get driver
    	EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    	EventListener eventListner = new EventListener();
    	chromeDriver.register(eventListner);
    	Log.testCaseInfo( "tcStudentMasteryListing006: Verify mastery and LO status in Mastery tab in Student details page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Executing custom and focus assignments in student dashboard
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUserNames.get( 1 ), password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), courseName, "67", "2", "10" );
            studentOneDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.SM_FOCUS_READING_GRADE1, "100", "3", "10" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to mastery tab in Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 2 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            SMUtils.logDescriptionTC( "Verify the Mastery in Students tab if the student didn't attend any assignment." );
            Log.assertThat( studentsTab.verifyMasteryZeroState(), "Mastery status is same as excepted if student didn't attend any assignment", "Mastery status is wrong if student didn't attend any assignment" );

            // Navigate to mastery tab in Student detail Page
            studentsTab.clickBackBtninContaniner();
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );

            SMUtils.logDescriptionTC( "Verify the teacher can be able to expanded and collapsed the Skill name for Subject -Math/Reading." );
            masteryComponent.clickSecondLevelStrandName();
            Log.assertThat( masteryComponent.isStrandCollapsed(), "Strand is expanded and collapsed successfully", "Strand is not expanded and collapsed" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to see the LO as a blue link, when Math subject is chosen with standard" );
            masteryFilter.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            masteryFilter.applyFilter();
            Log.assertThat( !masteryComponent.verifyLoLinkIsPresent(), "LO is not displayed as blue link when Math subject is chosen with standard", "LO is displayed as blue link when Math subject is chosen with standard" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to see the SCO number, when Reading subject is chosen with skills" );
            masteryFilter.selectSubject( Constants.READING );
            masteryFilter.applyFilter();
            Log.assertThat( !masteryComponent.verifyLoLinkIsPresent(), "LO is not displayed as blue link when Reading subject is chosen with skills", "LO is displayed as blue link when Reading subject is chosen with skills" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to see the SCO number, when Reading subject is chosen with standards" );
            masteryFilter.selectSkillStandards( Constants.READING_SKILLS_DROPDOWN_LIST.get( 3 ) );
            masteryFilter.applyFilter();
            Log.assertThat( !masteryComponent.verifyLoLinkIsPresent(), "LO is not displayed as blue link when Reading subject is chosen with standard", "LO is displayed as blue link when Reading subject is chosen with standard" );

            SMUtils.logDescriptionTC( "Verify the Progress bar in right side of the LO Description" );
            Log.assertThat( masteryComponent.isLOviewLinkPresenet(), "Progress bar is present in LO Description", "Progress bar is not present in LO Description" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery status colour indicator order in the progress bar", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 3 )
    public void tcStudentMasteryListing007() throws Exception {

        EventFiringWebDriver driver = null;
        // Get driver
        EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
        EventListener eventListner = new EventListener();
        chromeDriver.register(eventListner);
        Log.testCaseInfo( "tcStudentMasteryListing007: Verify Mastery status colour indicator order in the progress bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Executing custom and focus assignments in student dashboard
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUserNames.get( 2 ), password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), courseName, "10", "5", "10" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "Verify the progress bar, Mastery status colour indicator order" );
            // Navigate to mastery tab in Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "Verify the progress bar, 'Mastered' status is indicated by Green color" );
            Log.message( "Mastery colors " + masteryComponent.getStatusColor( browser ).toString() );
            Log.softAssertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase() ), "Mastered status is indicated by Green color in the progress bar ",
                    "Mastered status is not indicated by Green color in the progress bar ", driver );
            Log.message( "Color From UI: " + masteryComponent.getStatusColor( browser ) );
            Log.message( "Expected: " + Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase() );
            studentsTab.clickBackBtninContaniner();

            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            SMUtils.logDescriptionTC( "Verify the progress bar, 'At Risk' status is indicated by Yellow color" );
            Log.softAssertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase() ), "At Risk status is indicated by Yellow color in the progress bar ",
                    "At Risk status is not indicated by Yellow color in the progress bar ", driver );
            Log.message( "Color From UI: " + masteryComponent.getStatusColor( browser ) );
            Log.message( "Expected: " + Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase() );
            SMUtils.logDescriptionTC( "Verify the progress bar, total number of students 'Mastered'/Not Mastered/At Risk with respect to that skill is displaying inside Green/Yellow/red colour." );
            Log.softAssertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().containsAll( masteryComponent.getStudentAssessmentCount() ), "Total number of student assessment is didplayed in progress bar",
                    "Total number of student assessment is not didplayed in progress bar" );

            SMUtils.logDescriptionTC( "On Mouse hovering on Progress bar, Verify tooltip is displaying" );
            Log.softAssertThat( masteryComponent.getLeafNodeBasedOnMasteryStatus( Constants.MasteryUI.MASTERED ).stream().allMatch( WebElement::isDisplayed ), "Tooltip is present in progress bar", "Tooltip is not present in progress bar" );

            studentsTab.clickBackBtninContaniner();
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 2 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            SMUtils.logDescriptionTC( "Verify the progress bar, 'Not Mastered' status is indicated by Red color" );
            Log.softAssertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.NOTMASTERED_COLOR_CODE.toLowerCase() ), "Not Mastered status is indicated by Red color in the progress bar ",
                    "Not Mastered status is not indicated by Red color in the progress bar " );
            Log.message( "Color From UI: " + masteryComponent.getStatusColor( browser ) );
            Log.message( "Expected: " + Constants.MasteryUI.NOTMASTERED_COLOR_CODE.toLowerCase() );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Count of Student Assessments and Mastery Status in Mastery tab", groups = { "SMK-39169", "students", "studentsMastery" }, priority = 3 )
    public void tcStudentMasteryListing008() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSkillsAssessment008: Verify the Count of Student Assessments and Mastery Status in Mastery tab. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "Verify the progress bar, Mastery status colour indicator order" );
            // Navigate to mastery tab in Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasteryDetailsPage masteryDetails = new MasteryDetailsPage( driver );
            String oneAssessmentCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT.replace( Constants.STUDENTS_COUNT, "1" );
            String twoAssessmentsCount = Constants.MasteryUI.STUDENT_ASSESSMENTS_COUNT.replace( Constants.STUDENTS_COUNT, "2" );

            SMUtils.logDescriptionTC( "Verify the count of student Assessments if student has Multiple assignments with same LO." );
            SMUtils.logDescriptionTC( "Verify the Count of Student Assessments and Mastery Status for Math custom by skill course if Student having Same LO with different Assignment and different Mastery status." );
            SMUtils.logDescriptionTC( "Verify the Count of Student Assessments and Mastery Status for Math custom by standard if Student having Same strandards with different SCOs and different Mastery status." );
            Log.assertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().contains( twoAssessmentsCount ) || masteryComponent.getStudentAssessmentOfLeafNodeLO().contains( oneAssessmentCount ),
                    "The count of student assessments is same as excdepted if student has multiple math assignments with same LO", "The count of student assessments is wrong if student has multiple math assignments with same LO" );

            SMUtils.logDescriptionTC( "Verify Student tab >> Mastery for Math Custom by Standard assignment" );
            Log.assertThat( masteryComponent.verifySkillHeadingIsDisplayed(), "Mastery details are displayed for math assignments", "Mastery details are not displayed for math assignments" );

            SMUtils.logDescriptionTC( "Verify the headers in student-Mastery Detail Page." );
            // Navigate to LO view page
            masteryComponent.navigateToLoViewPage( masteryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );
            Log.assertThat( masteryDetails.isDetailsDisplayed(), "Headers are displayed in student-Mastery Detail Page", "Headers are not displayed in student-Mastery Detail Page" );

            SMUtils.logDescriptionTC( "Verify the Skill Evaluated will be display '1' for a Math with 'Successmaker Mastery Skills - Math'" );
            Log.assertThat( masteryDetails.getAscendingOrderSkillsEvaluated().contains( "1" ), "Skill Evaluated is display as '1' for a Math with Successmaker Mastery Skills - Math",
                    "Skill Evaluated is not display as '1' for a Math with Successmaker Mastery Skills - Math" );

            SMUtils.logDescriptionTC( "Verify the Count of Student Assessments and Mastery Status for Reading custom by course if Student having Same SCO with different Assignment and different Mastery status." );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            masteryFilter.selectSubject( Constants.READING );
            masteryFilter.applyFilter();

            SMUtils.logDescriptionTC( "Verify the Count of Student Assessments and Mastery Status for Reading custom by standard if Student having Same strandards with different SCOs and different Mastery status." );
            Log.assertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().contains( twoAssessmentsCount ) || masteryComponent.getStudentAssessmentOfLeafNodeLO().contains( oneAssessmentCount ),
                    "The count of student assessments is same as excdepted if student has multiple reading assignments with same LO", "The count of student assessments is wrong if student has multiple reading assignments with same LO" );

            SMUtils.logDescriptionTC( "Verify Student tab >> Mastery for Reading Custom by Standard assignment" );
            SMUtils.logDescriptionTC( "Verify Student tab >> Mastery for Focus Courses" );
            Log.assertThat( masteryComponent.verifySkillHeadingIsDisplayed(), "Mastery details are displayed for reading and focus assignments", "Mastery details are not displayed for reading and focus assignments" );

            SMUtils.logDescriptionTC( "Verify the Skill Evaluated field will be display '1' for a Reading with 'Successmaker Mastery Skills - Reading'" );
            // Navigate to LO view page
            masteryComponent.navigateToLoViewPage( masteryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );
            Log.assertThat( masteryDetails.getAscendingOrderSkillsEvaluated().contains( "1" ), "Skill Evaluated is display as '1' for a Reading with 'Successmaker Mastery Skills - Reading",
                    "Skill Evaluated is not display as '1' for a Reading with Successmaker Mastery Skills - Reading" );

            SMUtils.logDescriptionTC( "Verify the LO Viewer can be loaded when teacher clicks on the LO Link" );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_ASSIGNMENTS );
            SMUtils.waitForSpinnertoDisapper( driver );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            masteryFilter.selectSubject( Constants.MATH );
            masteryFilter.applyFilter();
            // Click LO link
            String loName = masteryComponent.getLinkElementOfLeafNodeLO().get( 0 ).getText().trim();
            SMUtils.click( driver, masteryComponent.getLinkElementOfLeafNodeLO().get( 0 ) );

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = SMUtils.switchWindow( driver );
            Log.assertThat( driver.getCurrentUrl().contains( loName ), "LO viewer is loaded successfully!!", "LO viewer is not loaded" );

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
            }
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void attendCourseAsStudent() throws Exception {
        final WebDriver chromeDriver = WebDriverFactory.get( chromePlatform );
        try {
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smLoginPage.loginToSMasStudent( studentUserNames.get( 0 ), password, false );
            studentsPage.executeMathCourse( username, Constants.MATH, "70", "2", "30" );
            studentsPage.executeMathCourse( username, skillCourseMath, "30", "5", "30" );
            studentsPage.executeMathCourse( username, settingsCourseMath, "100", "3", "20" );
            studentsPage.executeReadingCourse( username, Constants.READING, "90", "2", "20" );
            studentsPage.executeReadingCourse( username, skillCourseRead, "30", "2", "20" );
            studentsPage.executeReadingCourse( username, settingsCourseRead, "70", "2", "20" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
            Log.endTestCase();
        }
    }

}
