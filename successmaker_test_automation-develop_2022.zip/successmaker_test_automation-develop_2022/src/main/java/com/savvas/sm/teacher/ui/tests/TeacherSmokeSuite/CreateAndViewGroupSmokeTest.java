package com.savvas.sm.teacher.ui.tests.TeacherSmokeSuite;

import java.util.ArrayList;
import java.util.List;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CreateAndViewGroupSmokeTest extends EnvProperties {
    
    
    private String smUrl;
    private String browser;
    private String username;
    private String studentID_1;
    private String studentID_2;
    private String groupName;
    private String groupDetails;
    private String student1;
    private String student2;

    private static String studentOne;
    private static String studentTwo;
    private static String studentFour;
    private static String studentFive;
    private static String studentSix;

    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentID_1 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        studentID_2 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        Log.message( "studentID 1: " + studentID_1 );
        Log.message( "studentID 2: " + studentID_2 );
    }

    @Test ( description = "Verify create new group", priority = 1, groups = { "Smoke_test_cases", "Teacher_TC11", "Groups", "P1" } )

    public void tcGroupstest001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupstest001:Verify create new group in group tab <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            List<String> groupsList = new ArrayList<String>();
            groupsList.add( GroupUIConstants.SIMPLE_GROUP_NAME );

            Log.message( "checking if the group is present on the UI" );
            List<String> groupsFromUI = groupsTab.getGroupNamesFromGroupsTab();
            Log.assertThat( groupsFromUI.containsAll( groupsList ), "The Created Group is present on the UI", "Group created" + groupsList + "is not present on the UI" + groupsFromUI );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Add Students to Group functionality", priority = 1, groups = { "Smoke_test_cases", "Teacher_TC34", "Groupsettings", "P1" } )

    public void tcGroupstest002() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupstest002:Verify add students to group functionality in Group tab <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.clickGetViewGroupBtn( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.clickAddStudentToGroup();
            Log.message( groupsTab.addStudentToGroupTitle() );
            Log.message( Constants.Groups.ADDSTUDENT_TO_GROUP_TITLE + " " + GroupUIConstants.SIMPLE_GROUP_NAME );
            String studentUN4 = studentOne;
            String studentUN5 = studentTwo;
            String studentUN6 = studentFour;
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN4 );
            studentUserNames.add( studentUN5 );
            studentUserNames.add( studentUN6 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            groupsTab.clickAddStudentButton();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify View Group", priority = 1, groups = { "Smoke_test_case", "Teacher_TC12", "Groups", "P1" } )

    public void tcGroupstest003() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupstest003:Verify view group in Group tab <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.clickGetViewGroupBtn( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.clickAddStudentToGroup();
            String studentUN4 = studentOne;
            String studentUN5 = studentTwo;
            String studentUN6 = studentFour;
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN4 );
            studentUserNames.add( studentUN5 );
            studentUserNames.add( studentUN6 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            groupsTab.clickAddStudentButton();
            groupsTab.clickAssignmentSideSubNav();
            SMUtils.waitForElement( driver, groupsTab.assignmentHeaderNOData );
            Log.assertThat( groupsTab.assignmentHeaderNOData.getText().equals( Constants.GroupUIConstants.ZEROSTATE_HEADER ), "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is displayed correctly",
                    "The '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is not displayed correctly" );
            Log.assertThat( groupsTab.assignmentNoMsg.getText().contains( Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG ), "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is displayed correctly",
                    "The message '" + Constants.GroupUIConstants.ZEROSTATE_ASSIGNMENT_MSG + "' is not displayed correctly" );

            groupsTab.clickGroupsSubNav( Constants.SETTINGS );
            groupsTab.editGroup( GroupUIConstants.NEW_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.NEW_GROUP_NAME ), "New Group name is displayed under groups tab!", "New Group name is not displayed under groups tab" );

            groupsTab.deleteGroup( groupName );
            GroupPage groupslistingpages = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI1 = groupslistingpages.getGroupListNames();
            Log.assertThat( !groupsFromUI1.contains( groupName ), "Deleted Group name is not displayed under groups tab", "Deleted Group name is displayed under groups tab!" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
