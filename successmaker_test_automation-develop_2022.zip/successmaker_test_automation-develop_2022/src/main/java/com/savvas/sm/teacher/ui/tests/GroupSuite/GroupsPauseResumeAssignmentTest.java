package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class test the Pausing Resuming Group Assignments UI testing.
 *
 * @author madhan.nagarathinam
 *
 */

@Listeners ( EmailReport.class )
public class GroupsPauseResumeAssignmentTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentUsername1 = null;
    private String studentUsername2 = null;
    private String studentUsername3 = null;
    private String studentUsername4 = null;
    private String school = null;
    String groupName;
    String groupName2;
    String assignmentName;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentUsername1 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        studentUsername2 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        studentUsername3 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        studentUsername4 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );

    }

    @Test ( priority = 1, groups = { "SMK-41565", "groups", "groupsPauseAssignment" } )
    public void tcGroupPauseAssignment( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        groupName = "Regression_Automation_" + System.nanoTime();
        groupName2 = "Regression_Automation_" + System.nanoTime();
        assignmentName = Constants.GroupsAssignments.MATH;

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> studentUsernames = new ArrayList<>();
            studentUsernames.add( studentUsername1 );
            studentUsernames.add( studentUsername2 );

            groupsTab.createGroupWithSchoolStudents( groupName, studentUsernames, "All Grades" );
            studentUsernames.clear();
            studentUsernames.add( studentUsername1 );
            studentUsernames.add( studentUsername2 );
            groupsTab.createGroupWithSchoolStudents( groupName2, studentUsernames, "All Grades" );

            // Assigning assignment for group
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // Navigate to Groups Tab
            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            // Navigate to Groups Assignment sub-Nav
            groupsTab.getAssignmentDetailsBasedOnGroup();
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickPauseAssignmentForAllStudents();

            SMUtils.logDescriptionTC( "SMK-8750 - Verify pause confirmation popup is having X, Cancel and Pause button with message" );
            Log.assertThat( groupsTab.isPauseResumeAssignmentPopupMessageDisplayed().contentEquals( Constants.GroupsAssignments.PAUSE_ASSIGNMENT_POPUP_MESSAGE ), "Pause Assignment pop-up is displayed with all components",
                    "Pause Assignment pop-up is not getting displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8752 - Verify by clicking 'X' or 'Cancel' button present on Pause confirmation popup will not pause assignment" );
            Log.assertThat( groupsTab.clickXButtononPauseResumeAssignmentpopup(), "Teacher is able to click on X button", "Teacher is not able to click on X button!" );
            Log.assertThat( !groupsTab.isGroupAssignmentPaused(), "After clicking X button, the assignment is not getting paused", "The assignment is getting paused even after clicking X button on Pause Assignment pop-up!" );
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickPauseAssignmentForAllStudents();
            Log.assertThat( groupsTab.clickCancelButtononPauseResumeAssignmentpopup(), "Teacher is able to click on Cancel button and the assignment is not paused", "Teacher is not able to click on Cancel button!" );
            Log.assertThat( !groupsTab.isGroupAssignmentPaused(), "After clicking Cancel button, the assignment is not getting paused", "The assignment is getting paused even after clicking Cancel button on Pause Assignment pop-up!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8749 - Verify user is able to pause assignment by clicking on Pause Assignments for All Students' link" );
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickPauseAssignmentForAllStudents();
            Log.assertThat( groupsTab.clickPauseResumeButtononPauseAssignmentpopup(), "Teacher is able to click on pause button", "Teacher is not able to click on pause button on Pause Assignment pop-up!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8753 - Verify for each Paused assignment, the teacher is able to see 'Paused' label." );
            Log.assertThat( groupsTab.isGroupAssignmentPaused(), "The teacher is able to see 'Paused' label for each paused assignment", "The teacher is not able to see 'Paused' label for each paused assignment!" );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8759 - Verify Paused assignments are not displaying for all the students present in that group" );
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner); LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername1, password, true );
            Log.assertThat( !studentsPage.isAssignmentExists( assignmentName ), "Paused assignment is not getting displayed", "Paused assignment is getting displayed in the studentsDashboard!" );
            studentsPage.logout();
            driver.quit();
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername2, password, true );
            Log.assertThat( !studentsPage.isAssignmentExists( assignmentName ), "Paused assignment is not getting displayed", "Paused assignment is getting displayed in the studentsDashboard!" );
            studentsPage.logout();
            driver.quit();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 1, groups = { "SMK-41565", "groups", "groupsResumeAssignment" } )
    public void tcGroupResumeAssignment( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            // Verify the groupName present
            groupsTab.viewGroup( groupName );
            groupsTab.getAssignmentDetailsBasedOnGroup();
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickResumeAssignmentForAllStudents();

            SMUtils.logDescriptionTC( "SMK-8755 - Verify Resume confirmation popup is having X, Cancel and Resume button with message" );
            Log.assertThat( groupsTab.isPauseResumeAssignmentPopupMessageDisplayed().contentEquals( Constants.GroupsAssignments.RESUME_ASSIGNMENT_POPUP_MESSAGE ), "Resume Assignment pop-up is displayed with all components",
                    "Resume Assignment pop-up is not getting displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8757 - Verify by clicking 'X' or 'Cancel' button present on Resume confirmation popup will not Resume assignment" );
            Log.assertThat( groupsTab.clickXButtononPauseResumeAssignmentpopup(), "Teacher is able to click on X button", "Teacher is not able to click on X button!" );
            Log.assertThat( groupsTab.isGroupAssignmentPaused(), "After clicking X button, the assignment is not getting Resumed", "The assignment is getting Resumed even after clicking X button on Resume Assignment pop-up!" );

            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickResumeAssignmentForAllStudents();
            Log.assertThat( groupsTab.clickCancelButtononPauseResumeAssignmentpopup(), "Teacher is able to click on Cancel button and the assignment is not Resumed", "Teacher is not able to click on Cancel button!" );
            Log.assertThat( groupsTab.isGroupAssignmentPaused(), "After clicking Cancel button, the assignment is not getting Resumed", "The assignment is getting Resumed even after clicking Cancel button on Resume Assignment pop-up!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8754 - Verify user is able to resume assignment by clicking on Resume Assignments for All Students' link" );
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickResumeAssignmentForAllStudents();
            Log.assertThat( groupsTab.clickPauseResumeButtononPauseAssignmentpopup(), "Teacher is able to click on resume button", "Teacher is not able to click on resume button on Resume Assignment pop-up!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8758 - Verify for each Resumed assignment, the teacher is not able to see 'Paused' label." );
            Log.assertThat( !groupsTab.isGroupAssignmentPaused(), "Teacher is not able to see 'Paused' label for Resumed assignment", "Teacher is able to see 'Paused' Label!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8760 - Verify Resumed assignments are displaying for all the students present in that group" );
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername1, password, true );
            Log.assertThat( studentsPage.isAssignmentExists( assignmentName ), "Resumed assignment is getting displayed", "Resumed assignment is not getting displayed in the studentsDashboard!" );
            driver.quit();
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername2, password, true );
            Log.assertThat( studentsPage.isAssignmentExists( assignmentName ), "Resumed assignment is getting displayed", "Resumed assignment is not getting displayed in the studentsDashboard!" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 2, groups = { "SMK-41565", "groups", "groupsPauseAssignment" } )
    public void tcGroupPauseResumeAssignment( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            // Verify the groupName present
            groupsTab.viewGroup( groupName );
            groupsTab.getAssignmentDetailsBasedOnGroup();

            SMUtils.logDescriptionTC( "SMK-8761 - Verify by pausing assignment in one group will not pause the same assignment in different groups" );
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickPauseAssignmentForAllStudents();
            groupsTab.clickPauseResumeButtononPauseAssignmentpopup();
            Log.assertThat( groupsTab.isGroupAssignmentPaused(), "The Assignment is getting paused for Group1: " + groupName, "The Assignment is not getting paused for Group1: " + groupName );

            //Verification for pausing assignment in group1 will not pause the same assignment in group2
            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName2 );
            groupsTab.getAssignmentDetailsBasedOnGroup();
            Log.assertThat( !groupsTab.isGroupAssignmentPaused(), "The same Assignment is not getting paused for Group2: " + groupName2, "The same Assignment in group2 is getting paused  " + groupName2 );

            //Pausing the group2 assignment for the next case verification
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickPauseAssignmentForAllStudents();
            groupsTab.clickPauseResumeButtononPauseAssignmentpopup();
            Log.assertThat( groupsTab.isGroupAssignmentPaused(), "The Assignment is getting paused for Group2: " + groupName2, "The Assignment is not getting paused for Group2: " + groupName2 );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8762 - Verify by resuming assignment in one group will not resume the same assignment in different groups" );
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickResumeAssignmentForAllStudents();
            groupsTab.clickPauseResumeButtononPauseAssignmentpopup();
            Log.assertThat( !groupsTab.isGroupAssignmentPaused(), "The assignment is Resumed for Group2: " + groupName2, "The assignment is not getting resumed for Group2!" );

            //Verification for resuming assignment in group2 will not resume the same assignment in group1
            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.getAssignmentDetailsBasedOnGroup();
            Log.assertThat( groupsTab.isGroupAssignmentPaused(), "The same assignment is not getting resumed in group1 ", "The same assignment is getting resumed by resuminig in group2" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }

    }
}
