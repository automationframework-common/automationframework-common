package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners(EmailReport.class)
public class AssignmentDetailsPage_AdvProgressMonitoringPrint extends BaseTest {
	private String smUrl;
	private String browser;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String teacherID;
	private String schoolID; 
	private String username = null;
	private String password = null;
	private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution
	String staticCourseName = null;
	String studentDetails;
	String teacherDetails;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String token = null;
	private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
	AssignmentAPI assign = new AssignmentAPI();
	private String orgId;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		orgId = RBSDataSetup.organizationIDs.get( school );
	    schoolID = RBSDataSetup.organizationIDs.get( school );
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		studentDetails = RBSDataSetup.getMyStudent(school, username);

		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, "userId"));

		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Group
		String groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");
		
		 // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
       Log.message( mathRssignmentResponse.toString() );
		
		

	}

	@Test(description = "Verify the teacher is able to assign default courses to student", groups = { "SMK-45613","AssignmentDetails", "Advance Progress Moinitoring-Print" }, priority = 1)
	public void verifyAssignCourse_01() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Verify the teacher is able to assign default courses to student"
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage customCourses = new CoursesPage(driver);
			CourseListingPage courseListingPage = new CourseListingPage(driver);
			List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
			List<String> studentList = new ArrayList<>();

			// To assign default Math course to the Student traverse to Courses page
			tHomePage.topNavBar.getCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Click on the default Math course
			customCourses.clickFromCourseListingPage(Constants.MATH);

			// Click on the assignment
			customCourses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			customCourses.addCourseToStudents();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Click on the View Assignment
			customCourses.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify whether the student is present in the particular assignment
			studentList = customCourses.getStudentListfromAssignementDetailsTable();

			// Assert Statement
			Log.softAssertThat(Boolean.TRUE.equals(studentList.size() == studentListFromTheAssignmentPopup.size()),
					Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
					Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT);

			// To assign default Reading course to the Student traverse to Courses page
			tHomePage.topNavBar.getCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Click on the default Reading course
			customCourses.clickFromCourseListingPage(Constants.READING);

			// Click on the assignment
			customCourses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			customCourses.addCourseToStudents();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Click on the View Assignment
			customCourses.clickOnTheHoveredAssignment(Constants.READING);

			// Verify whether the student is present in the particular assignment
			studentList = customCourses.getStudentListfromAssignementDetailsTable();

			// Assert Statement
			Log.softAssertThat(Boolean.TRUE.equals(studentList.size() == studentListFromTheAssignmentPopup.size()),
					Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
					Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT);

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-45613","AssignmentDetails", "Advance Progress Moinitoring-Print" }, priority = 2)
	public void verifyAttendCourse_02() throws Exception {

		Log.testCaseInfo("Verify the student is able to attend the Math course via simulator"
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		// for simulator run
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);


		try {
			Log.message("The subject name is " + Constants.MATH);
			// Executing math assignments in student dashboard
			String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername, password);

			StudentDashboardPage studentDashboardPage = new StudentDashboardPage(chromeDriver);
			studentDashboardPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "userId"),
					Constants.MATH, "95", "5", "30");
			studentDashboardPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the Print icon is displayed", priority = 3, groups = { "SMK-45613", "AssignmentDetails","Advance Progress Moinitoring-Print" })
	public void verifyPrintIconDisplayed_03() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Verify the Print icon is displayed");

		try {
			SMUtils.logDescriptionTC(
					"SMK-13603: Verify the availability of Print icon in both 'Advanced Progress monitoring Graph & Summary' section for Default Math assignment");

			
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed", "Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			CourseListingPage courseListingPage = new CourseListingPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			// Traverse to Courses page
			tHomePage.topNavBar.getCourseListingPage();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Click on the View Assignment
			customCourses.clickOnTheHoveredAssignment(Constants.MATH);

			assignmentDetailsPage.clicktoggleButtonForStudent(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));

			// To scroll into expanded student
			assignmentDetailsPage.scrollInToExpandedStudent();
		//	assignmentDetailsPage.scrollInToExpandedStudentAddition();

			// Verify print icon displayed
			Log.assertThat(assignmentDetailsPage.isDispayedPrintIcon(), "Print icon is displayed","Print icon is not displayed");

			// Click on view Summary
			assignmentDetailsPage.clickViewSummary();

			// Verify print icon displayed after clicked on view summary
			Log.assertThat(assignmentDetailsPage.isDispayedPrintIcon(),
					"Print icon is displayed after clicked on view summay",
					"Print icon is not displayed after clicked on view summary");

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

}
