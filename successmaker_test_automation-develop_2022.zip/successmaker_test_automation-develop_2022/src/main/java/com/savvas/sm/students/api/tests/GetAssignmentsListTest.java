package com.savvas.sm.students.api.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.student.api.dashboard.StudentAPI;

import io.restassured.response.Response;

public class GetAssignmentsListTest extends EnvProperties {

    private static String smUrl;
    private static String orgName;
    private static String orgId;
    private static String teacherDetails;
    private static String mathTeacherDetails;
    private static String teacherUsername;
    private static String teacherUserId;
    private static String token;
    private static String studentUsername;
    private static String studentUserId;
    private static String studentAccessToken;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static Response response;
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static List<String> courseIds = new ArrayList<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> assignmentIds = new HashMap<>();
    private static String mutliSchStudentUsername;
    private static String multiSchoolStudentID;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( orgName );

        teacherDetails = RBSDataSetup.getMyTeacher( orgName );
        mathTeacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID );
        token = new RBSUtils().getAccessToken( teacherUsername, password );

        String studentDetails = RBSDataSetup.getMyStudent( orgName, teacherUsername );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID );

        studentAccessToken = new RBSUtils().getAccessToken( studentUsername, password );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Math: Grade 1" );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Reading: Grade 1" );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), courseIds );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment IDs - " + assignmentIds );

        response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );
        Log.message( "Response - " + response.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest001() throws IOException {

        Log.testCaseInfo( "tc:001 - Verify status code is 200 and fetched all the active assignments for the student when all valid inputs are passed to API" );

        //status code
        Log.assertThat( response.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + response.getStatusCode() );

        //Data validation
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        Map<String, Map<String, String>> assignmentsFromResponse = new HashMap<>();
        for ( Object object : jsonArray ) {
            Map<String, String> assignmentFromResponse = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponse.put( assignmentFromResponse.get( "assignmentUserId" ), assignmentFromResponse );
        }

        Map<String, Map<String, String>> assignmentsDetailsFromDB = SqlHelperAssignment.getAssignmentsDetailsForStudent( studentUserId );
        Log.assertThat( assignmentsDetailsFromDB.entrySet().stream().allMatch(
                assignmentDetailFromDB -> assignmentDetailFromDB.getValue().keySet().stream().allMatch( key -> assignmentDetailFromDB.getValue().get( key ).equalsIgnoreCase( assignmentsFromResponse.get( assignmentDetailFromDB.getKey() ).get( key ) ) ) ),
                "All the assignments are fetched properly in the API response", "All the assignments are not fetched properly in the API response. Expected - " + assignmentsDetailsFromDB + ".Actual - " + assignmentsFromResponse );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest002() {

        Log.testCaseInfo( "tc:002 - Verify API response is fetching all the required fields for all the assignments" );

        //status code
        Log.assertThat( response.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + response.getStatusCode() );

        //Schema validation
        try {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getAssignmentDetailsForStudent", String.valueOf( response.getStatusCode() ), response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        } catch ( Exception e ) {
            Log.message( "Getting Issue while validate the schema.Exception -" + e.getMessage() );
            e.printStackTrace();
        }
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest003() {

        Log.testCaseInfo( "tc:003 - Verify default courses \"Math\" and \"Reading\" are fetched in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );

        List<String> assignmentNames = new ArrayList<>();
        for ( Object object : jsonArray ) {
            String courseName = SMUtils.getKeyValueFromResponse( object.toString(), "courseName" );
            assignmentNames.add( courseName );
        }

        Log.assertThat( assignmentNames.contains( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) && assignmentNames.contains( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ),
                "Default math and Reading course are fetched in the API response", "Default math and Reading course are not fetched in the API response" );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest004() {

        Log.testCaseInfo( "tc:004 - Verify custom courses from both subjects (Math and Reading)  are fetched in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );

        //To get the assignment Names from response
        List<String> assignmentNames = new ArrayList<>();
        for ( Object object : jsonArray ) {
            String courseName = SMUtils.getKeyValueFromResponse( object.toString(), "courseName" );
            assignmentNames.add( courseName );
        }
        Log.assertThat(
                assignmentNames.contains( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) )
                        && assignmentNames.contains( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ),
                "Custom math and Reading course are fetched in the API response", "Custom math and Reading course are not fetched in the API response" );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest005() {

        Log.testCaseInfo( "tc:005 - Verify creatorTitle is fetching Title value in API response when assignment owner is having Title value in profile" );

        try {
            //To update the teacher detail
            HashMap<String, String> teacherDetail = new HashMap<>();
            JSONObject teacher = new JSONObject( teacherDetails );
            teacherDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            teacherDetail.put( UserConstants.USERID, teacher.get( "userId" ).toString() );
            teacherDetail.put( UserConstants.ORGID, orgId );
            teacherDetail.put( UserConstants.STAFFID, teacher.get( "userId" ).toString() );
            teacherDetail.put( "personId", teacher.get( "userId" ).toString() );
            teacherDetail.put( "firstName", teacher.get( "firstName" ).toString() );
            teacherDetail.put( "middleName", teacher.get( "middleName" ).toString() );
            teacherDetail.put( "lastName", teacher.get( "lastName" ).toString() );
            teacherDetail.put( "email", new JSONObject( teacher.getJSONArray( "emailInfo" ).get( 0 ).toString() ).get( "emailAddress" ).toString() );
            teacherDetail.put( "userName", teacher.get( "userName" ).toString() );
            teacherDetail.put( "title", "DR" );
            teacherDetail.put( "userPassword", password );
            teacherDetail.put( "oldPassword", password );

            HashMap<String, String> updateStaffProfile = new UserAPI().updateStaffProfile( smUrl, teacherDetail );
            Log.message( updateStaffProfile.toString() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while update the teacher profile" );
            e.printStackTrace();
        }

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String teacherTitle = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                teacherTitle = SMUtils.getKeyValueFromResponse( object.toString(), "creatorTitle" );
                break;
            }
        }

        Log.assertThat( teacherTitle.equalsIgnoreCase( "Dr." ), "Teacher title is fetched properly in the response", "Teacher title is not fetching in the API response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest006() {

        Log.testCaseInfo( "tc:006 - Verify creatorTitle is fetching Title value in API response when assignment owner is having Title value in profile" );

        try {
            //To update the teacher detail
            HashMap<String, String> teacherDetail = new HashMap<>();
            JSONObject teacher = new JSONObject( teacherDetails );
            teacherDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            teacherDetail.put( UserConstants.USERID, teacher.get( "userId" ).toString() );
            teacherDetail.put( UserConstants.ORGID, orgId );
            teacherDetail.put( UserConstants.STAFFID, teacher.get( "userId" ).toString() );
            teacherDetail.put( "personId", teacher.get( "userId" ).toString() );
            teacherDetail.put( "firstName", teacher.get( "firstName" ).toString() );
            teacherDetail.put( "middleName", teacher.get( "middleName" ).toString() );
            teacherDetail.put( "lastName", teacher.get( "lastName" ).toString() );
            teacherDetail.put( "email", new JSONObject( teacher.getJSONArray( "emailInfo" ).get( 0 ).toString() ).get( "emailAddress" ).toString() );
            teacherDetail.put( "userName", teacher.get( "userName" ).toString() );
            teacherDetail.put( "title", "NOT_SPECIFIED" );
            teacherDetail.put( "userPassword", password );
            teacherDetail.put( "oldPassword", password );

            HashMap<String, String> updateStaffProfile = new UserAPI().updateStaffProfile( smUrl, teacherDetail );
            Log.message( updateStaffProfile.toString() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while update the teacher profile" );
            e.printStackTrace();
        }
        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String courseObject = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                courseObject = object.toString();
                break;
            }
        }

        Log.assertThat( !courseObject.contains( "creatorTitle" ), "Teacher title is not fetched as Expected if the teacher has no teacher title", "Teacher title is fetching in the API response if the teacher has no techer title" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest007() {

        Log.testCaseInfo( "tc:007 - Verify CreatorFirstName is fetching FirstName of the assignment owner in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String creatorFirstName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                creatorFirstName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorFirstName" );
                break;
            }
        }

        Log.assertThat( creatorFirstName.equalsIgnoreCase( new JSONObject( teacherDetails ).get( "firstName" ).toString() ), "Teacher FirstName is  fetched properly in the get assignment student response",
                "Teacher FirstName is not fetched properly in the get assignment student response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest008() {

        Log.testCaseInfo( "tc:008 - Verify CreatorMiddleName is fetching MiddleName of the assignment owner in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String creatorMiddleName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                creatorMiddleName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorMiddleName" );
                break;
            }
        }

        Log.assertThat( creatorMiddleName.equalsIgnoreCase( new JSONObject( teacherDetails ).get( "middleName" ).toString() ), "Teacher middle name is fetched properly in the get assignment student response",
                "Teacher middle name is not fetched properly in the get assignment student response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest009() {

        Log.testCaseInfo( "tc:009 - Verify CreatorLastName is fetching LastName of the assignment owner in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String creatorMiddleName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                creatorMiddleName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorLastName" );
                break;
            }
        }

        Log.assertThat( creatorMiddleName.equalsIgnoreCase( new JSONObject( teacherDetails ).get( "lastName" ).toString() ), "Teacher Last name is  fetched properly in the get assignment student response",
                "Teacher Last name is not fetched properly in the get assignment student response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest010() {

        Log.testCaseInfo( "tc:010 - Verify courses from both schools are fetched when student belongs to 2 schools" );

        RBSUtils rbsUtils = new RBSUtils();
        mutliSchStudentUsername = "multischstud@" + orgId;

        //To create the multiple school student
        try {
            List<String> allUserNamesFromOrg = rbsUtils.getAllUserNamesFromOrg( orgId );

            if ( allUserNamesFromOrg.contains( mutliSchStudentUsername ) ) {
                String userDetail = rbsUtils.getUser( rbsUtils.getUserIDByUserName( mutliSchStudentUsername ) );
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( userDetail, RBSDataSetupConstants.USERID );
            } else {
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, mutliSchStudentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                List<String> schools = Arrays.asList( orgId, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String studentDetail = new RBSUtils().createUser( userDetails );
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID );

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = RBSDataSetup.generateRequestValues( studentDetail, studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherUserId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, token );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( smUrl, studentInfo );

            }

            //Group Creation in flex school
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( multiSchoolStudentID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Flex School for multiple school student" );
            }

            //Group Creation in math school
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ), password ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USERID ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( multiSchoolStudentID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Math School for multiple school student" );
            }

            //Assigning reading assignment from flex school teacher
            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( multiSchoolStudentID ), Arrays.asList( "2" ) );

            //Assigning math assignment from math school teacher
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USERID ) );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ), password ) );
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( multiSchoolStudentID ), Arrays.asList( "1" ) );
        } catch ( Exception e ) {
            Log.message( "Issue in creating the assignment" );
            e.printStackTrace();
        }
        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, multiSchoolStudentID, rbsUtils.getAccessToken( mutliSchStudentUsername, password ) );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String flexSchoolCreatorFirstName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( "Reading" ) ) {
                flexSchoolCreatorFirstName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorFirstName" );
                break;
            }
        }

        String mathSchoolcreatorFirstName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( "Math" ) ) {
                mathSchoolcreatorFirstName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorFirstName" );
                break;
            }
        }

        Log.assertThat( flexSchoolCreatorFirstName.equalsIgnoreCase( new JSONObject( teacherDetails ).get( "firstName" ).toString() ) && mathSchoolcreatorFirstName.equalsIgnoreCase( new JSONObject( mathTeacherDetails ).get( "firstName" ).toString() ),
                "Both schools assignmnets are fetched properly for multiplpe school student", "Both schools assignmnets are not fetched properly for multiplpe school student" );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest011() {

        Log.testCaseInfo( "tc:011 - Verify subject id is fetched correctly for \"Math\" and \"Reading\" default courses" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String mathSubjectId = null;
        String readingSubjectId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                mathSubjectId = SMUtils.getKeyValueFromResponse( object.toString(), "subjectId" );
            } else if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) ) {
                readingSubjectId = SMUtils.getKeyValueFromResponse( object.toString(), "subjectId" );
            }
        }

        Log.assertThat( mathSubjectId.equals( "1" ) && readingSubjectId.equals( "2" ), "Subject id is fetched properly for math and reading default courses", "Subject id is not fetched properly for math and reading default courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest012() {

        Log.testCaseInfo( "tc:012 - Verify subject id is fetched correctly for \"Math\" and \"Reading\" custom courses" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String mathSubjectId = null;
        String readingSubjectId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                mathSubjectId = SMUtils.getKeyValueFromResponse( object.toString(), "subjectId" );
            } else if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ) {
                readingSubjectId = SMUtils.getKeyValueFromResponse( object.toString(), "subjectId" );
            }
        }

        Log.assertThat( mathSubjectId.equals( "1" ) && readingSubjectId.equals( "2" ), "Subject id is fetched properly for math and reading custom courses", "Subject id is not fetched properly for math and reading custom courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest013() {

        Log.testCaseInfo( "tc:013 - Verify \"CourseType\" is fetched correctly for \"Math\"  default course in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String mathCourseType = null;
        String readingCourseType = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                mathCourseType = SMUtils.getKeyValueFromResponse( object.toString(), "courseType" );
            } else if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) ) {
                readingCourseType = SMUtils.getKeyValueFromResponse( object.toString(), "courseType" );
            }
        }

        Log.assertThat( mathCourseType.equals( "1" ) && readingCourseType.equals( "1" ), "Course type is fetched properly for math and reading default courses", "Course type is not fetched properly for math and reading default courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest014() {

        Log.testCaseInfo( "tc:014 - Verify \"CourseType\" is fetched correctly for \"Math\" custom by setting course in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String mathCourseType = null;
        String readingCourseType = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ) {
                mathCourseType = SMUtils.getKeyValueFromResponse( object.toString(), "courseType" );
            } else if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ) {
                readingCourseType = SMUtils.getKeyValueFromResponse( object.toString(), "courseType" );
            }
        }

        Log.assertThat( mathCourseType.equals( "2" ) && readingCourseType.equals( "2" ), "Course type is fetched properly for math and reading custom by setting courses",
                "Course type is not fetched properly for math and reading custom by settings courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest015() {

        Log.testCaseInfo( "tc:015 - Verify \"CourseType\" is fetched correctly for \"Math\" custom by standard course in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String mathCourseType = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) ) {
                mathCourseType = SMUtils.getKeyValueFromResponse( object.toString(), "courseType" );
                break;
            }
        }

        Log.assertThat( mathCourseType.equals( "4" ), "Course type is fetched properly for math and reading custom by standard courses", "Course type is not fetched properly for math and reading custom by standard courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest016() {
        Log.testCaseInfo( "tc:016 - Verify \"CourseType\" is fetched correctly for \"Math\" custom by skill course in API response" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );

        String mathCourseType = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                mathCourseType = SMUtils.getKeyValueFromResponse( object.toString(), "courseType" );
                break;
            }
        }

        Log.assertThat( mathCourseType.equals( "3" ), "Course type is fetched properly for math and reading custom by skill courses", "Course type is not fetched properly for math and reading custom by skill courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest017() {

        Log.testCaseInfo( "tc:017 - Verify Product ID is fetched correctly for Math default and custom course" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String defaultmathProductId = null;
        String customMathProductId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                defaultmathProductId = SMUtils.getKeyValueFromResponse( object.toString(), "productId" );
            } else if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                customMathProductId = SMUtils.getKeyValueFromResponse( object.toString(), "productId" );
            }
        }

        Map<String, Map<String, String>> assignmentsDetailsFromDB = SqlHelperAssignment.getAssignmentsDetailsForStudent( studentUserId );
        Optional<String> expectedProductID = assignmentsDetailsFromDB.entrySet().stream().filter( entry -> entry.getValue().get( "courseName" ).equalsIgnoreCase( AssignmentAPIConstants.MATH_COURSE ) ).map(
                entry -> entry.getValue().get( "productId" ) ).findFirst();
        Log.assertThat( defaultmathProductId.equals( expectedProductID.get() ) && customMathProductId.equals( expectedProductID.get() ), "Product Id is fetched properly for Math courses", "Product Id is not fetched properly for math courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest018() {

        Log.testCaseInfo( "tc:018 - Verify Product ID is fetched correctly for Reading default and custom course" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String defaultmathProductId = null;
        String customMathProductId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) ) {
                defaultmathProductId = SMUtils.getKeyValueFromResponse( object.toString(), "productId" );
            } else if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ) {
                customMathProductId = SMUtils.getKeyValueFromResponse( object.toString(), "productId" );
            }
        }

        Map<String, Map<String, String>> assignmentsDetailsFromDB = SqlHelperAssignment.getAssignmentsDetailsForStudent( studentUserId );
        Optional<String> expectedProductID = assignmentsDetailsFromDB.entrySet().stream().filter( entry -> entry.getValue().get( "courseName" ).equalsIgnoreCase( AssignmentAPIConstants.READING_COURSE ) ).map(
                entry -> entry.getValue().get( "productId" ) ).findFirst();
        Log.assertThat( defaultmathProductId.equals( expectedProductID.get() ) && customMathProductId.equals( expectedProductID.get() ), "product Id is fetched properly for reading courses", "Product Id is not fetched properly for reading courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest019() {

        Log.testCaseInfo( "tc:019 - Verify Product ID is fetched correctly for Math focus course" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String focusmathProductId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) ) {
                focusmathProductId = SMUtils.getKeyValueFromResponse( object.toString(), "productId" );
                break;
            }
        }

        Map<String, Map<String, String>> assignmentsDetailsFromDB = SqlHelperAssignment.getAssignmentsDetailsForStudent( studentUserId );
        Optional<String> expectedProductID = assignmentsDetailsFromDB.entrySet().stream().filter(
                entry -> entry.getValue().get( "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) ).map( entry -> entry.getValue().get( "productId" ) ).findFirst();
        Log.assertThat( focusmathProductId.equals( expectedProductID.get() ), "product Id is fetched properly for Math focus courses", "Product Id is not fetched properly for math focus courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest020() {

        Log.testCaseInfo( "tc:020 - Verify Product ID is fetched correctly for Reading focus course" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String focusReadingProductId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) ) {
                focusReadingProductId = SMUtils.getKeyValueFromResponse( object.toString(), "productId" );
                break;
            }
        }

        Map<String, Map<String, String>> assignmentsDetailsFromDB = SqlHelperAssignment.getAssignmentsDetailsForStudent( studentUserId );
        Optional<String> expectedProductID = assignmentsDetailsFromDB.entrySet().stream().filter(
                entry -> entry.getValue().get( "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) ).map( entry -> entry.getValue().get( "productId" ) ).findFirst();
        Log.assertThat( focusReadingProductId.equals( expectedProductID.get() ), "product Id is fetched properly for reading focus courses", "Product Id is not fetched properly for reading focus courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest021() {

        Log.testCaseInfo( "tc:021 - Verify sessionLengthMin is fetching the mins selected while creating the course when there is no change in session length afterwards" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "30" ), "Session length is fetched properly for math courses", "Session length is not fetched properly for math courses.Expected - 30.Actual - " + sessionLength );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest022() throws Exception {

        Log.testCaseInfo( "tc:022 -Verify sessionLengthMin is fetching recently updated mins when there is a change in session length while assigning the course" );

        //To get the assignment userId
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
        Log.message( "assignmentUserId -" + assignmentUserId );
        //To update the assignment settings
        HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
        assignmentSettings.put( "SESSION_LENGTH", "30" );

        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        new AssignmentAPI().updateAssignmentUserSettings( smUrl, assignmentDetail, assignmentSettings, Arrays.asList( studentUserId ), AssignmentAPIConstants.MATH_COURSE );

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "30" ), "Session length is fetched properly for updated math settings courses", "Session length is not fetched properly for updated math settings courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest023() throws Exception {

        Log.testCaseInfo( "tc:023 - Verify sessionLengthMin is fetching recently updated mins when there is a change in session length in student assignment settings" );

        //To get the assignment userId
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
        Log.message( "assignmentUserId -" + assignmentUserId );
        //To update the assignment settings
        HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
        assignmentSettings.put( "SESSION_LENGTH", "25" );

        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        new AssignmentAPI().updateAssignmentUserSettings( smUrl, assignmentDetail, assignmentSettings, Arrays.asList( studentUserId ), AssignmentAPIConstants.MATH_COURSE );

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "25" ), "Session length is fetched properly for updated math settings courses", "Session length is not fetched properly for updated math settings courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest024() throws Exception {

        Log.testCaseInfo( "tc:024 - Verify sessionLengthMin is fetching recently updated mins when there is a change in session length in group assignment settings" );

        //Group Creation in flex school
        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentUserId ) );
        String groupId = SMUtils.getKeyValueFromResponse( createGroup.get( "body" ), "data,groupId" );
        if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
            Log.message( "Group Created in Flex School" );
        }
        String courseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() );
        String courseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName );

        //Assignment details
        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetail.put( AssignmentAPIConstants.GROUP_ID, groupId );
        assignmentDetail.put( AssignmentAPIConstants.COURSE_ID, courseId );

        new AssignmentAPI().assignAssignment( smUrl, assignmentDetail, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

        HashMap<String, String> updatedGroupAssignmentSettings = new HashMap<>();
        updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

        HashMap<String, String> apiResponseGetGroupAssignmentSettings = new AssignmentAPI().getGroupAssignmentSettings( smUrl, assignmentDetail );

        //Please remove before final merge
        Log.message( "Response is " + apiResponseGetGroupAssignmentSettings );

        JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetGroupAssignmentSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

        JSONObject data2 = getSettingsResp.getJSONObject( "SESSION_LENGTH" );
        String sessionLengthName = data2.getString( "name" );
        Long sessionLengthId = data2.getLong( "id" );
        String sessionLengthValue = data2.getString( "currentValue" );
        Log.message( "Name of the session length : " + sessionLengthName );
        Log.message( "Id of the session length : " + sessionLengthId );
        Log.message( "CurrentValue of the session length : " + sessionLengthValue );

        JSONObject data3 = getSettingsResp.getJSONObject( "IDLE_TIME" );
        String idleTimeName = data3.getString( "name" );
        Long idleTimeId = data3.getLong( "id" );
        String idleTimeValue = data3.getString( "currentValue" );
        Log.message( "Name of the idleTime : " + idleTimeName );
        Log.message( "Id of the idleTime : " + idleTimeId );
        Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

        //Updating the Settings As per Scenarios

        //Update the setting as per your need
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_ID, String.valueOf( sessionLengthId ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_NAME, sessionLengthName );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_VALUE, "60" );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, "4" );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.ORG_ID, orgId );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, teacherUserId );
        updatedGroupAssignmentSettings.put( "groupId", groupId );

        //Updating the Custom By Settings
        HashMap<String, String> apiResponseUpdatedGroupAssignmentSetting = new AssignmentAPI().updateGroupAssignmentSetting( smUrl, assignmentDetail, updatedGroupAssignmentSettings, DataSetupConstants.MATH );
        Log.message( "Update course setting response: " + apiResponseUpdatedGroupAssignmentSetting );

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( courseName ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "60" ), "Session length is fetched properly for updated the group assignment settings courses", "Session length is not fetched properly for updated the group assignment settings courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest025() {

        Log.testCaseInfo( "tc:025 - Verify sessionLengthMin is fetching 15 mins for default math course when student assignment setting is not changed" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "15" ), "Session length is fetched properly for default math courses", "Session length is not fetched properly for default math courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest026() {

        Log.testCaseInfo( "tc:026 - Verify sessionLengthMin is fetching 20 mins for default reading course when student assignment setting is not changed" );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "20" ), "Session length is fetched properly for default reading courses", "Session length is not fetched properly for default reading courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P2", "SMK-70075" }, priority = 2 )
    public void getAssignmentDetailsTest027() {

        Log.testCaseInfo( "tc:027 - Verify status code is 400 when invalid end point is given in API" );
        String invalidEndPoint = "/lms/web/api/v1/studentDashboard/assignmentsinvalid/{studentId}";

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentAccessToken );
        headers.put( Constants.USERID_SM_HEADER, studentUserId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        invalidEndPoint = invalidEndPoint.replace( "{studentId}", studentUserId );

        Response response = RestAssuredAPIUtil.GET( smUrl, headers, invalidEndPoint );

        Log.assertThat( response.getStatusCode() == 404, "Status code is returned as expected", "Status code is not returned as expected. Expected - 404 .Actual-" + response.getStatusCode() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P2", "SMK-70075" }, priority = 2 )
    public void getAssignmentDetailsTest028() {

        Log.testCaseInfo( "tc:028 - Verify status code is 403 when invalid authentication is passed in API" );
        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId + "invalid", studentUserId, studentAccessToken );

        //status code validation
        Log.assertThat( response.getStatusCode() == 403, "Status code is returned as expected", "Status code is not returned as expected. Expected - 403 .Actual-" + response.getStatusCode() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P2", "SMK-70075" }, priority = 2 )
    public void getAssignmentDetailsTest029() {

        Log.testCaseInfo( "tc:029 - Verify status code is 401 when invalid authorization is passed in API" );
        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken + "invalid" );

        //status code validation
        Log.assertThat( response.getStatusCode() == 401, "Status code is returned as expected", "Status code is not returned as expected. Expected - 401 .Actual-" + response.getStatusCode() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P2", "SMK-70075" }, priority = 2 )
    public void getAssignmentDetailsTest030() {

        Log.testCaseInfo( "tc:030 -Verify status code is 200 with empty response when any new student without any assignment authorization is passed in API" );

        String studentDetails = RBSDataSetup.getMyStudent( orgName, teacherUsername );

        //To get the previously assigned assignment
        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID ),
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME ), password ) );

        //To delete the assignments
        if ( response.getBody().asString().contains( "assignmentUserId" ) ) {
            JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
            List<String> assignmentUserIds = new ArrayList<>();
            for ( Object object : jsonArray ) {
                Map<String, String> assignmentFromResponse = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
                assignmentUserIds.add( assignmentFromResponse.get( "assignmentUserId" ) );
            }
            assignmentUserIds.forEach( assignmentUserId -> {
                try {
                    assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                    new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
                } catch ( Exception e ) {
                    e.printStackTrace();
                }
            } );
        }

        response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID ),
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME ), password ) );

        //status code validation
        Log.assertThat( response.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + response.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "messages,message" ).equalsIgnoreCase( "No Course Found for the student" ), "Zero State message is displayed as expected",
                "Zero State message is not displayed as expected .Actual-" + response.getBody().asString() );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P2", "SMK-70075" }, priority = 2 )
    public void getAssignmentDetailsTest031() {

        Log.testCaseInfo( "tc:031 -Verify status code is 400 when invalid org-id or user-id is given in API" );

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId + "invalid", studentAccessToken + "invalid" );

        //status code validation
        Log.assertThat( response.getStatusCode() == 401, "Status code is returned as expected", "Status code is not returned as expected. Expected - 401 .Actual-" + response.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "messages,message" ).equalsIgnoreCase( "Authentication Failed" ), " error message is displayed as expected",
                "error message is not displayed as expected .Actual-" + response.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P2", "SMK-70075" }, priority = 2 )
    public void getAssignmentDetailsTest032() throws Exception {

        Log.testCaseInfo( "tc:032 -Verify status code is 401 when any suspended student authentication is passed in API" );

        RBSUtils rbsUtils = new RBSUtils();
        String suspendedStudentUsername = "suspendedstud1@" + orgId;
        String suspendedStudentUserID = null;

        //To create the multiple school student
        try {
            List<String> allUserNamesFromOrg = rbsUtils.getAllUserNamesFromOrg( orgId );

            if ( allUserNamesFromOrg.contains( suspendedStudentUsername ) ) {
                String userDetail = rbsUtils.getUser( rbsUtils.getUserIDByUserName( suspendedStudentUsername ) );
                suspendedStudentUserID = SMUtils.getKeyValueFromResponse( userDetail, RBSDataSetupConstants.USERID );
            } else {
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, suspendedStudentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                List<String> schools = Arrays.asList( orgId );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String studentDetail = new RBSUtils().createUser( userDetails );
                suspendedStudentUserID = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID );

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = RBSDataSetup.generateRequestValues( studentDetail, studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherUserId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, token );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( smUrl, studentInfo );

            }

            //Group Creation in flex school
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( suspendedStudentUserID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Flex School for suspend student" );
            }

            //Assigning reading assignment from flex school teacher
            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( suspendedStudentUserID ), Arrays.asList( "2" ) );
        } catch ( Exception e ) {
            Log.message( "Issue in creating the assignment" );
            e.printStackTrace();
        }

        //To suspend the user
        new RBSUtils().suspendUser( Arrays.asList( suspendedStudentUserID ) );

        String accessToken = null;
        try {
            accessToken = new RBSUtils().getAccessToken( suspendedStudentUsername, password );
        } catch ( Exception e ) {
            Log.message( "Unable to create access token for suspended student as expected" );
        }

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, suspendedStudentUserID, Objects.isNull( accessToken ) ? "" : accessToken );

        //status code validation
        Log.assertThat( response.getStatusCode() == 401, "Status code is returned as expected", "Status code is not returned as expected. Expected - 401 .Actual-" + response.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "messages,message" ).equalsIgnoreCase( "Authentication Failed" ), " error message is displayed as expected",
                "error message is not displayed as expected .Actual-" + response.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest033() {

        Log.testCaseInfo( "tc:033 -Verify status code is 200 when multiple school student org authentication with anyone of org-id is passed in API" );

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, multiSchoolStudentID, new RBSUtils().getAccessToken( mutliSchStudentUsername, password ) );

        //status code
        Log.assertThat( response.getStatusCode() == 200, "Status code is returned as expected for multiple school student", "Status code is not returned as expected for multiple school student. Expected - 200 .Actual-" + response.getStatusCode() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest034() {

        Log.testCaseInfo( "tc:034 -Verify API response should not fetch paused assignments" );

        // To get the assignment user Id for DefaultMath
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String mathAssignmentUserId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                mathAssignmentUserId = SMUtils.getKeyValueFromResponse( object.toString(), "assignmentUserId" );
                break;
            }
        }

        //To pause the Math assignment
        try {
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId );
            HashMap<String, String> pauseAssignmentResponse = new AssignmentAPI().changeAssignmentStatus( smUrl, assignmentDetails, "INACTIVE", AssignmentAPIConstants.EXCEPTIONNULL );
            Log.message( pauseAssignmentResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        Log.message( "Response - " + response.getBody().asString() );
        // To get the assignment names
        jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        List<String> assignmentNames = new ArrayList<>();
        for ( Object object : jsonArray ) {
            assignmentNames.add( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ) );
        }

        Log.assertThat( !assignmentNames.contains( "Math" ), "Paused assignments are not fetched in the api as expected", "Paused assignments are fetching in the Get student assignment API" );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetails", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest035() {

        Log.testCaseInfo( "tc:035 -Verify API response should not fetch deleted assignments" );

        // To get the assignment user Id for Default reading
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        String readAssignmentUserId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) ) {
                readAssignmentUserId = SMUtils.getKeyValueFromResponse( object.toString(), "assignmentUserId" );
                break;
            }
        }

        //To delete the Reading assignment
        try {
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, readAssignmentUserId );
            new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Response response = StudentAPI.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );

        Log.message( "Response - " + response.getBody().asString() );
        // To get the assignment names
        jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
        List<String> assignmentNames = new ArrayList<>();
        for ( Object object : jsonArray ) {
            assignmentNames.add( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ) );
        }

        Log.assertThat( !assignmentNames.contains( "Reading" ), "Deleted assignments are not fetched in the api as expected", "Deleted assignments are fetching in the Get student assignment API" );
    }

}
