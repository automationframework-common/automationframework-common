package com.savvas.sm.api.tests.smnew.groups;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants.GroupAPIEndPoints;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
/**
 * To Test the API for the Group List that Given Students is not belong that.
 * 
 * @author suriya.kumar
 *
 */
public class GroupListNotBelongToStudentsAPITest extends GroupAPI {
	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	String sessionCookie;
	String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	String classId = null;
	String className = null;

	// Teacher variable used for this class
	private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
	private String teacherUsed;
	private String orgId;
	private String teacherId;
	private String teacherUsername;

	// other school constants
	private String readingSchoolId;
	private String readingSchoolTeacherId;
	private String readingSchoolTeacherUsername;

	// Second Teacher
	private String secondTeacherId;
	private String secondTeacherUsername;

	// API parameter
	public List<String> StudentIdsToTest = new ArrayList<String>();
	public List<String> groupIdsToVerify = new ArrayList<String>();
	public List<String> groupNamesToVerify = new ArrayList<String>();
	public String teacherUsernameToTest = null;
	public String teacherIdToTest = null;
	public String orgIdToTest = null;
	public String accessToken = null;
	private String browser;

	// Object 
	AtomicReference<String> readingSchool = new AtomicReference<String>();
	AtomicReference<String> schoolUsed = new AtomicReference<String>();
	private long startTime;
	private ArrayList<String> studentIdList =  new ArrayList<String>();;
	private ArrayList<String> studentUserNames =  new ArrayList<String>();;
	GroupAPI groupApi = new GroupAPI();
	private ArrayList<String> teacherGroupNames;
	private ArrayList<String> teacherGroupId;

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() {

		startTime = StopWatch.startTime();
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		browser = configProperty.getProperty( "BrowserPlatformToRun" );

		// Teacher used Details
		schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
		orgId = RBSDataSetup.organizationIDs.get( schoolUsed.get() );
		String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
		teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
		teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

		// Getting student details for the Teacher
		ArrayList<String> studentDetails = new ArrayList<String>();
		int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );
		IntStream.range( 0, StudentCount ).forEach( count -> {
			studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), teacherUsername ) );
		} );
		IntStream.range( 0, StudentCount ).forEach( counter -> {
			studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
			studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
		} );

		Log.message("studentIdList " + studentIdList);
		Log.message("studentUserNames " + studentUserNames);

		// Getting GroupId of the Teacher
		HashMap<String, String> response = new HashMap<String, String>();
		HashMap<String, String> apiDetails = new HashMap<String, String>();
		try {
			String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
			apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
			apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
			apiDetails.put( GroupConstants.STAFF_ID, teacherId );
			response = groupApi.getGroupListingForTeacherID( smUrl, apiDetails );
			Log.message( "GroupListing respone: " + response.toString() );
			JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
			JSONArray array = jsonObject.getJSONArray( CreateGroupAPIConstants.DATA );
			teacherGroupNames = new ArrayList<String>();
			teacherGroupId = new ArrayList<String>();
			IntStream.range( 0, array.length() ).forEach( iter -> {
				String eachObject = array.getJSONObject( iter ).toString();
				teacherGroupNames.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_NAME ) );
				teacherGroupId.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_ID ) );
			} );
		} catch ( Exception e ) {
			e.printStackTrace();
		}


		// Second Teacher for Data Setup purposes
		secondTeacherUsername = "secondTeacherUsername" + System.nanoTime();
		String teacherdetailsCreate = null;
		try {
			if ( !new RBSUtils().isUserExits( secondTeacherUsername, orgId ) ) {
				teacherdetailsCreate = new UserAPI().createUserWithCustomization( secondTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
			}
			secondTeacherId = new RBSUtils().getUserIDByUserName( secondTeacherUsername );
		} catch ( Exception e1 ) {
			e1.printStackTrace();
		}


		// Other School Details
		readingSchool.set( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
		readingSchoolId = RBSDataSetup.organizationIDs.get( readingSchool.get() );


		//teacher create       
		readingSchoolTeacherUsername = "readingSchoolTeacherUsername" + System.nanoTime();
		readingSchoolTeacherId = null;
		try {
			if ( !new RBSUtils().isUserExits( readingSchoolTeacherUsername, readingSchoolId ) ) {
				teacherdetailsCreate = new UserAPI().createUserWithCustomization( readingSchoolTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( readingSchoolId ) );
			}
			readingSchoolTeacherId = new RBSUtils().getUserIDByUserName( readingSchoolTeacherUsername );
		} catch ( Exception e1 ) {
			e1.printStackTrace();
		}
	}

	@AfterClass
	public void enofExecution() {
		long totalTime = StopWatch.elapsedTime( startTime );
		long sec = totalTime % 60;
		long min = ( totalTime / 60 ) % 60;
		Log.message( "=====================================================" );
		Log.message( "Group Listing for Student not Belong to Class Ran for : " + min + " minute (s)" + ":" + sec + " seconds (s)" );
	}


	/**
	 * Data provider for negative scenarios
	 * 
	 * @return
	 */
	@DataProvider ( name = "negativeScenarios" )
	public Object[][] negativeData() {
		Object[][] inputData = { { "NO_SM_PRODCUT", "200" }, { "INVALID_AUTH", "401" }, { "STUDENT_AUTH", "403" }, { "INVALID_TEACHER_ID", "400" }, { "INVALID_STUDENT_ID", "400" }, { "INVALID_ORG_ID", "400" } };
		return inputData;
	}



	@Test ( priority = 1, description = "In Valid Scenarios", dataProvider = "negativeScenarios", groups = { "SMK-51973", "Groups", "GroupsListForStudentNotBelongTo", "API" } )
	public void tcGroupsNotPartOfStudents01( String scenario, String expCode ) throws Exception {

		// Constants
		HashMap<String, String> response = null;
		String studentName;
		String studentDetails;
		String studentId;
		HashMap<String, String> userDetails;
		String classId;
		String groupName;
		String expException = null;


		switch ( scenario ) {
		case "NO_SM_PRODCUT":
			Log.testCaseInfo( " Verify the Group listed though it doesnot have successmaker product" );

			// Student Creation
			studentName = "student" + System.nanoTime();
			studentId = new UserAPI().createStudentAndResetPassword( orgId, studentName );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId );

			// Teacher create
			teacherUsernameToTest = "teacher" + System.nanoTime();
			teacherIdToTest = new UserAPI().createTeacherAndResetPassword( orgId, teacherUsernameToTest );
			orgIdToTest = orgId;



			//  enorlled in one class
			accessToken = new RBSUtils().getAccessToken( teacherUsernameToTest, password );
			groupName = "group" + System.nanoTime();
			HashMap<String, String> groupDetails = new HashMap<String, String>();
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgIdToTest );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

			Log.message("NO_SM_PRODCUT teacherUsernameToTest --> " + teacherUsernameToTest);
			Log.message("NO_SM_PRODCUT teacherIdToTest --> " + teacherIdToTest);
			Log.message("NO_SM_PRODCUT orgIdToTest  --> " + orgIdToTest);
			Log.message("NO_SM_PRODCUT StudentIdsToTest  --> " + StudentIdsToTest);
			Log.message("NO_SM_PRODCUT accessToken  --> " + accessToken);
			Log.message("NO_SM_PRODCUT teacherIdToTest  --> " + teacherIdToTest);
			Log.message("NO_SM_PRODCUT orgIdToTest  --> " + orgIdToTest);
			Log.message("NO_SM_PRODCUT studentId  --> " + studentId);
			Log.message("NO_SM_PRODCUT studentName  --> " + studentName);

			try {
				groupDetails = createGroup( smUrl, groupDetails, StudentIdsToTest );
				classId = new SMAPIProcessor().getKeyValues( new JSONObject( groupDetails.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
			} catch ( Exception e ) {
				Log.message( e.getMessage() );
			}

			// Groups creation To Verify
			groupIdsToVerify.clear();
			groupNamesToVerify.clear();
			IntStream.rangeClosed( 1, 3 ).forEach( index -> {
				final HashMap<String, String> groupEmpty = new HashMap<String, String>();
				String group = "group with product" + System.nanoTime();
				HashMap<String, String> classDetails = new HashMap<>();
				classDetails.put( RBSDataSetupConstants.USERNAME, teacherUsernameToTest );
				classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgIdToTest );
				classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, teacherIdToTest );
				classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studentId );
				classDetails.put( RBSDataSetupConstants.SECTION_NAME, group );
				try {
					String noSMProductClassJson = new RBSUtils().createClass( classDetails );
					String noSMProductClassId = new JSONObject( noSMProductClassJson ).getJSONObject( "data" ).getJSONObject( "section" ).get( "id" ).toString();
					groupIdsToVerify.add( noSMProductClassId );
					groupNamesToVerify.add( group );

					Log.message("NO_SM_PRODCUT groupIdsToVerify  --> " + groupIdsToVerify);
					Log.message("NO_SM_PRODCUT groupNamesToVerify  --> " + groupNamesToVerify);
					Log.message("NO_SM_PRODCUT group  --> " + group);
				} catch ( Exception e ) {
					e.printStackTrace();
				}
			} );
			response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			expException = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			break;


		case "INVALID_AUTH":
			Log.testCaseInfo( "Verify the Response for Invalid Access token" );

			// Student Creation
			studentName = "student" + System.nanoTime();
			studentId = new UserAPI().createStudentAndResetPassword( orgId, studentName );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId );

			// Data Creation
			CreateData( studentId, orgId, 3 );

			Log.message("INVALID_AUTH studentName  --> " + studentName);
			Log.message("INVALID_AUTH studentId  --> " + studentId);
			Log.message("INVALID_AUTH orgId  --> " + orgId);
			Log.message("INVALID_AUTH StudentIdsToTest  --> " + StudentIdsToTest);
			Log.message("INVALID_AUTH teacherIdToTest  --> " + teacherIdToTest);
			Log.message("INVALID_AUTH orgIdToTest  --> " + orgIdToTest);

			// Getting Response and Verification
			response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, CommonAPIConstants.INVALID_ACCESS_TOKEN );
			expException = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
			break;


		case "STUDENT_AUTH":
			Log.testCaseInfo( " - Verify the Response for Student Auth" );

			// Student Creation
			studentName = "student" + System.nanoTime();
			studentId = new UserAPI().createStudentAndResetPassword( orgId, studentName );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId );

			// Data Creation
			CreateData( studentId, orgId, 3 );

			// Getting Response and Verification
			teacherIdToTest = studentId;

			Log.message("STUDENT_AUTH studentName  --> " + studentName);
			Log.message("STUDENT_AUTH studentId  --> " + studentId);
			Log.message("STUDENT_AUTH orgId  --> " + orgId);
			Log.message("STUDENT_AUTH StudentIdsToTest  --> " + StudentIdsToTest);
			Log.message("STUDENT_AUTH teacherIdToTest  --> " + teacherIdToTest);
			Log.message("STUDENT_AUTH orgIdToTest  --> " + orgIdToTest);

			String studentAaccessToken = new RBSUtils().getAccessToken( studentName, password );
			response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, studentAaccessToken );
			expException = CommonAPIConstants.ACCESS_DENIED_EXCEPTION;
			break;


		case "INVALID_TEACHER_ID":
			Log.testCaseInfo( "Verify the Response for Invalid Staff Id" );

			// Student Creation
			studentName = "student" + System.nanoTime();
			studentId = new UserAPI().createStudentAndResetPassword( orgId, studentName );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId );

			// Data Creation
			CreateData( studentId, orgId, 3 );

			// Getting Response and Verification
			String endPoint = GroupAPIEndPoints.GET_GROUPLIST_STUDENTS_NOT_BELONG_TO;
			Map<String, String> headers = new HashMap<String, String>();
			HashMap<String, String> params = new HashMap<>();
			String body = null;
			try {

				// End point
				endPoint = String.format( endPoint, orgId, teacherId + "1" );

				//Parameters
				Log.message( "Parameters - " + params );

				// headers
				headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
				headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + accessToken );
				headers.put( Constants.USERID_SM_HEADER, teacherIdToTest );
				headers.put( Constants.ORGID_SM_HEADER, orgId );

				// Body
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append( "{\"studentIds\":[" );
				IntStream.rangeClosed( 0, StudentIdsToTest.size() - 1 ).forEach( index -> {
					stringBuilder.append( "\"" + StudentIdsToTest.get( index ) + "\"" );
					if ( index != StudentIdsToTest.size() - 1 ) {
						stringBuilder.append( "," );
					}
				} );
				stringBuilder.append( "]}" );
				body = stringBuilder.toString();
				Log.message( "The request Body is : " + body );
				// Respone
				response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, body );
				Log.message( "The response is  : " + response.toString() );
			} catch ( Exception e ) {
				Log.message( "Exception is : " + e.getMessage() );
			}
			expException = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			break;

		case "INVALID_STUDENT_ID":

			// Student Creation
			studentName = "student" + System.nanoTime();
			studentId = new UserAPI().createStudentAndResetPassword( orgId, studentName );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId + "1" );

			// Data Creation
			CreateData( studentId, orgId, 3 );

			// Getting Response and Verification
			endPoint = GroupAPIEndPoints.GET_GROUPLIST_STUDENTS_NOT_BELONG_TO;
			headers = new HashMap<String, String>();
			params = new HashMap<>();
			body = null;
			try {

				// End point
				endPoint = String.format( endPoint, orgId, teacherId );

				//Parameters
				Log.message( "Parameters - " + params );

				// headers
				headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
				headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + accessToken );
				headers.put( Constants.USERID_SM_HEADER, teacherIdToTest );
				headers.put( Constants.ORGID_SM_HEADER, orgId );

				// Body
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append( "{\"studentIds\":[" );
				IntStream.rangeClosed( 0, StudentIdsToTest.size() - 1 ).forEach( index -> {
					stringBuilder.append( "\"" + StudentIdsToTest.get( index ) + "\"" );
					if ( index != StudentIdsToTest.size() - 1 ) {
						stringBuilder.append( "," );
					}
				} );
				stringBuilder.append( "]}" );
				body = stringBuilder.toString();
				Log.message( "The request Body is : " + body );

				// Respone
				response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, body );
				Log.message( "The response is  : " + response.toString() );
			} catch ( Exception e ) {
				Log.message( "Exception is : " + e.getMessage() );
			}
			expException = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			break;


		case "INVALID_ORG_ID":
			Log.testCaseInfo( "- Verify the Response for Invalid Org Id" );

			// Student Creation
			studentName = "student" + System.nanoTime();
			studentId = new UserAPI().createStudentAndResetPassword( orgId, studentName );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId );


			// Data Creation
			CreateData( studentId, orgId, 3 );
			// Getting Response and Verification
			endPoint = GroupAPIEndPoints.GET_GROUPLIST_STUDENTS_NOT_BELONG_TO;
			headers = new HashMap<String, String>();
			params = new HashMap<>();
			body = null;
			try {

				// End point
				endPoint = String.format( endPoint, orgId + "k", teacherId );

				//Parameters
				Log.message( "Parameters - " + params );

				// headers
				headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
				headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
				headers.put( Constants.AUTHORIZATION, Constants.BEARER + accessToken );
				headers.put( Constants.USERID_SM_HEADER, teacherIdToTest );
				headers.put( Constants.ORGID_SM_HEADER, orgId );

				// Body
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append( "{\"studentIds\":[" );
				IntStream.rangeClosed( 0, StudentIdsToTest.size() - 1 ).forEach( index -> {
					stringBuilder.append( "\"" + StudentIdsToTest.get( index ) + "\"" );
					if ( index != StudentIdsToTest.size() - 1 ) {
						stringBuilder.append( "," );
					}
				} );
				stringBuilder.append( "]}" );
				body = stringBuilder.toString();
				Log.message( "The request Body is : " + body );

				// Respone
				response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, body );
				Log.message( "The response is  : " + response.toString() );
			} catch ( Exception e ) {
				Log.message( "Exception is : " + e.getMessage() );
			}
			expException = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			break;
		default:
			break;
		}

		//Validating response code and exception Message
		Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expCode ), "The Status code matched", "The Status code Doesnot matched" );
		Log.assertThat( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.BODY ) ), Constants.EXCEPTION ).get( 0 ).equals( expException ), "The Exception message is matched", "The Exception message is not matched" );
		Log.endTestCase();
		Log.testCaseResult();
	}




	/**
	 * Data provider for positive scenarios
	 * 
	 * @return
	 */
	@DataProvider ( name = "positiveScenarios" )
	public Object[][] positiveData() {
		Object[][] inputData = { { "VALID_SCENARIO" }, { "STUDENT_SUSPENDED" }, { "STUDENT_MULTI_ORG" }, { "SHARED_STUDENT" }, { "DELETED_GROUP" }, { "DUPLICATE_GROUP" }, };
		return inputData;
	}


	@Test ( priority = 2, description = "Valid Scenarios 200 Scenarios", dataProvider = "positiveScenarios", groups = { "SMK-51973","smoke_test_case","GroupsListForStudentNotBelong_TC01", "Groups", "GroupsListForStudentNotBelongTo", "API" } )
	public void tcGroupsNotPartOfStudents02( String scenario ) throws Exception {
		// Constants
		String studentName;
		String studentDetails;
		String studentId;
		HashMap<String, String> response;

		switch ( scenario ) {
		case "VALID_SCENARIO":
			Log.testCaseInfo( " - Verify the API for AutoRoastered Student for basic teacher" );
			Log.testCaseInfo( "- Verify the groupOwnerId field returns teacher id" );
			Log.testCaseInfo( "- Verify the groupOwnerId field returns teacher id" );
			Log.testCaseInfo( "- verify the API returns groupId in groupId field" );
			Log.testCaseInfo( "- Verify the API returns groupName in the groupName field" );
			Log.testCaseInfo( "- Verify the API returns organizationId in the organization id field" );

			// Student Creation
			String validStudentName = "student" + System.nanoTime();
			String validStudentId = new UserAPI().createStudentAndResetPassword( orgId, validStudentName );

			// Data Creation
			CreateData( validStudentId, orgId, 3 );

			// Getting Response and Verification
			HashMap<String, String> validResponse = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( validResponse );
			break;

		case "STUDENT_SUSPENDED ":
			Log.testCaseInfo( "Verify the API for suspended student" );

			// Student Creation
			String suspendedStudentName = "student" + System.nanoTime();
			String suspendedStudentId = new UserAPI().createStudentAndResetPassword( orgId, suspendedStudentName );

			// Data Creation
			CreateData( suspendedStudentId, orgId, 3 );

			// Suspend Student
			new RBSUtils().suspendUser( Arrays.asList( suspendedStudentId ) );

			// Getting Response and Verification
			HashMap<String, String> suspendedResponse = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( suspendedResponse );
			break;

		case "STUDENT_MULTI_ORG":
			Log.testCaseInfo( " Verify the Api when student part of Multiple Org" );

			// Student Creation
			String multiStudentName = "student" + System.nanoTime();
			String multiStudentDetails = new UserAPI().createUserWithCustomization( multiStudentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId, readingSchoolId ) );
			String multiStudentId = new SMUtils().getKeyValueFromResponse( multiStudentDetails, RBSDataSetupConstants.USERID );

			// Data Creation
			CreateData( multiStudentId, orgId, 3 );

			// Getting Response and Verification
			HashMap<String, String> multi1Response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( multi1Response );

			// Data Creation
			CreateData( multiStudentId, readingSchoolId, 3 );

			// Getting Response and Verification
			HashMap<String, String> multi2Response  = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( multi2Response );

			break;

		case "SHARED_STUDENT":
			Log.testCaseInfo( " - Verify the Api when student part of two same school teachers" );

			// Student Creation
			String sharedStudentName = "student" + System.nanoTime();
			String sharedStudentId = createSharedStudent( sharedStudentName, teacherId, new RBSUtils().getAccessToken( teacherUsername, password ), secondTeacherId, new RBSUtils().getAccessToken( secondTeacherUsername, password ), orgId );

			// Data Creation
			CreateData( sharedStudentId, orgId, 3 );

			// Getting Response and Verification
			HashMap<String, String> sharedResponse = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( sharedResponse );

			break;

		case "DELETED_GROUP":
			Log.testCaseInfo( "Verify the API Does not return the deleted group" );

			// Student Creation
			String deletStudentName = "student" + System.nanoTime();
			String deletStudentDetails = new UserAPI().createUserWithCustomization( deletStudentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
			String deletStudentId = new SMUtils().getKeyValueFromResponse( deletStudentDetails, RBSDataSetupConstants.USERID );

			// Data Creation
			CreateData( deletStudentId, orgId, 3 );

			// Deleting one Group
			new RBSUtils().deleteClass( groupIdsToVerify.get( 0 ), teacherIdToTest );
			groupIdsToVerify.remove( 0 );
			groupNamesToVerify.remove( 0 );

			// Getting Response and Verification
			HashMap<String, String> deletedResponse = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( deletedResponse );


		case "DUPLICATE_GROUP":
			Log.testCaseInfo( "Verify the API returns the Group that have duplicate names when selected student not part of" );

			// Student Creation
			String duplicateStudentName = "student" + System.nanoTime();
			String duplicateStudentDetails = new UserAPI().createUserWithCustomization( duplicateStudentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
			String duplicateStudentId = new SMUtils().getKeyValueFromResponse( duplicateStudentDetails, RBSDataSetupConstants.USERID );

			// Data Creation
			// Teacher create
			teacherUsernameToTest = "teacher" + System.nanoTime();
			teacherIdToTest = new UserAPI().createTeacherAndResetPassword( orgId, teacherUsernameToTest );

			orgIdToTest = orgId;

			// Student create 
			StudentIdsToTest.clear();
			StudentIdsToTest.add( duplicateStudentId );

			//  enorlled in one class
			accessToken = new RBSUtils().getAccessToken( teacherUsernameToTest, password );
			Log.message("DUPLICATE_GROUP accesstoken ---> " + accessToken );
			String groupName = "group" + System.nanoTime();
			HashMap<String, String> groupDetails = new HashMap<String, String>();
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );

			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			Log.message("DUPLICATE_GROUP groupDetails ---> " + groupDetails);
			try {
				groupDetails = createGroup( smUrl, groupDetails, StudentIdsToTest );
				String classId = new SMAPIProcessor().getKeyValues( new JSONObject( groupDetails.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ),
						StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
			} catch ( Exception e ) {
				Log.message( e.getMessage() );
			}

			// Groups creation To Verify
			groupIdsToVerify.clear();
			groupNamesToVerify.clear();
			IntStream.rangeClosed( 1, 3 ).forEach( index -> {
				final HashMap<String, String> groupEmpty = new HashMap<String, String>();
				groupEmpty.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
				groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );

				groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
				groupEmpty.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
				Log.message("GroupEMpty accesstoken ---> " +groupEmpty );
				try {
					String classId = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup( smUrl, groupEmpty, new ArrayList<String>() ).get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ),
							StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
					groupIdsToVerify.add( classId );
					groupNamesToVerify.add( groupName );
				} catch ( Exception e ) {
					Log.message( e.getMessage() );
				}
			} );

			// Getting Response and Verification
			HashMap<String, String> duplicateResponse = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( duplicateResponse );

			break;

		case "SHARAED_CLASS":
			Log.testCaseInfo( " Verify the API will not returns the no of Shared Group when selected student part of that group " );

			// Studnet Creation
			studentName = "student" + System.nanoTime();
			studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
			studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
			StudentIdsToTest.clear();
			StudentIdsToTest.add( studentId );

			// Teacher create
			String firstTeacherUsername = "teacher" + System.nanoTime();
			String firstTeacherId = new UserAPI().createTeacherAndResetPassword( orgId, teacherUsernameToTest );
			orgIdToTest = orgId;

			// Teacher create
			String secondTeacherUsername = "teacher" + System.nanoTime();
			String secondTeacherId = new UserAPI().createTeacherAndResetPassword( orgId, teacherUsernameToTest );

			// Enrolling student into the class
			accessToken = new RBSUtils().getAccessToken( firstTeacherUsername, password );
			String className = "class with multiple Teacher" + System.nanoTime();
			classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( firstTeacherId, secondTeacherId ), Arrays.asList( studentId ), orgId, accessToken );

			// Groups creation To Verify
			groupIdsToVerify.clear();
			groupNamesToVerify.clear();
			IntStream.rangeClosed( 1, 3 ).forEach( index -> {
				final HashMap<String, String> groupEmpty = new HashMap<String, String>();
				String grpName = "Group" + System.nanoTime();
				try {
					classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( firstTeacherId, secondTeacherId ), Arrays.asList(), orgId, accessToken );
					groupIdsToVerify.add( classId );
					groupNamesToVerify.add( grpName );
				} catch ( Exception e1 ) {
					e1.printStackTrace();
				}
			} );


			// Getting Response and Verification for teacher 1
			teacherIdToTest = firstTeacherId;
			response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( response );


			// Getting Response and Verification for teacher 2
			teacherIdToTest = secondTeacherId;
			accessToken = new RBSUtils().getAccessToken( secondTeacherUsername, password );
			response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			VerifyAPI( response );

			break;

		default:
			break;
		}
		Log.endTestCase();
		Log.testCaseResult();
	}


	@Test ( priority = 3, description = "Teachers with 100 plus Groups and Students", groups = { "SMK-51973", "Groups","GroupsListForStudentNotBelong_TC02", "GroupsListForStudentNotBelongTo", "API" } )
	public void tcGroupsNotPartOfStudents03() throws Exception {
		Log.testCaseInfo( " - Verify the api when the student doesnot belong to group of number 100" );
		Log.testCaseInfo( " Verify the api when the student doesnot belong to group of number more than 100" );
		int count = 100;
		StudentIdsToTest.clear();
		groupIdsToVerify.clear();
		groupNamesToVerify.clear();

		// Teacher create
		teacherUsernameToTest = "teacher" + System.nanoTime();
		teacherIdToTest = new UserAPI().createTeacherAndResetPassword( orgId, teacherUsernameToTest );
		orgIdToTest = orgId;
		accessToken = new RBSUtils().getAccessToken( teacherUsernameToTest, password );
		IntStream.rangeClosed( 1, count ).forEach( index -> {
			Log.message( "Student creating and enrolling in class of : " + index + "/" + count );

			// Student create 
			String studentDetails = new UserAPI().createUserWithCustomization( "student" + System.nanoTime(), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
			String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
			StudentIdsToTest.add( studentId );

			//  enorlled in one class
			String groupName = "group" + System.nanoTime();
			classId = createGroupWithParameter( groupName, teacherIdToTest, Arrays.asList( studentId ), orgId, accessToken );
			groupIdsToVerify.add( classId );
			groupNamesToVerify.add( groupName );
		} );

		// Getting Response and Verification
		HashMap<String, String> response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );

		//Validating response code and exception Message
		Log.assertThat( response.get( Constants.STATUS_CODE ).equals( "200" ), "The Status code matched", "The Status code Doesnot matched" );
		VerifyAPI( response );
		Log.endTestCase();
		Log.testCaseResult();

		// Adding one more group in payload
		// Student create 
		String studentDetails = new UserAPI().createUserWithCustomization( "student" + System.nanoTime(), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
		String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
		StudentIdsToTest.add( studentId );

		//  enorlloing in 101 class
		String groupName = "group" + System.nanoTime();
		classId = createGroupWithParameter( groupName, teacherIdToTest, Arrays.asList( studentId ), orgId, accessToken );
		groupIdsToVerify.add( classId );
		groupNamesToVerify.add( groupName );

		// Getting Response and Verification
		response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );

		//Validating response code and exception Message
		Log.assertThat( response.get( Constants.STATUS_CODE ).equals( "400" ), "The Status code matched", "The Status code Doesnot matched" );
		Log.assertThat( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.BODY ) ), Constants.MESSAGE ).get( 0 ).equals( CommonAPIConstants.LIMIT_STUDENT_COUNT_LESS_100_ERROR_MESSAGE ), "The Exception message is matched",
				"The Exception message is not matched" );
		Log.endTestCase();
		Log.testCaseResult();
	}



	@Test ( priority = 4, description = "Verify the API for Multiple students request Body", groups = { "SMK-51973", "Groups","smoke_test_case","GroupsListForStudentNotBelong_TC03", "GroupsListForStudentNotBelongTo", "API" } )
	public void tcGroupsNotPartOfStudents04() throws Exception {
		Log.testCaseInfo( "Verify the API for teacher who has three students and three groups and they were mapped with each group uniquely" );
		Log.testCaseInfo( " Verify student1 is part of three group and student 2 doesnot belong to thtree groups so it will display the three groups when two studentids is given" );
		Log.testCaseInfo( " Verify student1 is part of three group and student 2 belong to groups1 so it will display the two groups when two studentids is given" );


		// Student create 
		String studenName;

		// Student 1 
		String studentDetails = new UserAPI().createUserWithCustomization( "student" + System.nanoTime(), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
		String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
		StudentIdsToTest.clear();
		StudentIdsToTest.add( studentId );

		// Student 2
		studentDetails = new UserAPI().createUserWithCustomization( "student" + System.nanoTime(), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
		studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
		StudentIdsToTest.add( studentId );

		// Teacher create
		teacherUsernameToTest = "teacher" + System.nanoTime();
		teacherIdToTest = new UserAPI().createTeacherAndResetPassword( orgId, teacherUsernameToTest );
		orgIdToTest = orgId;
		List<String> student1Groups = new ArrayList<String>();
		List<String> student2Groups = new ArrayList<String>();

		// Teacher's student 1 Groups
		//  enorlled in one class
		accessToken = new RBSUtils().getAccessToken( teacherUsernameToTest, password );
		String groupName = "group for Stud 1" + System.nanoTime();
		HashMap<String, String> groupDetails = new HashMap<String, String>();
		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
		try {
			groupDetails = createGroup( smUrl, groupDetails, StudentIdsToTest.subList( 0, 1 ) );
			String classId = new SMAPIProcessor().getKeyValues( new JSONObject( groupDetails.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
			student1Groups.add( classId );
		} catch ( Exception e ) {
			Log.message( e.getMessage() );
		}
		IntStream.rangeClosed( 1, 3 ).forEach( index -> {
			final HashMap<String, String> groupEmpty = new HashMap<String, String>();
			String group = "group for Stud 1" + System.nanoTime();
			groupEmpty.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_NAME, group );
			try {
				String classId = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup( smUrl, groupEmpty, new ArrayList<String>() ).get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ),
						StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
				student1Groups.add( classId );
			} catch ( Exception e ) {
				Log.message( e.getMessage() );
			}
		} );

		// Teacher's student 2 Groups
		//  enorlled in one class
		accessToken = new RBSUtils().getAccessToken( teacherUsernameToTest, password );
		groupName = "group for Stud 2" + System.nanoTime();
		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
		try {
			groupDetails = createGroup( smUrl, groupDetails, StudentIdsToTest.subList( 1, 1 ) );
			String classId = new SMAPIProcessor().getKeyValues( new JSONObject( groupDetails.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
			student2Groups.add( classId );
		} catch ( Exception e ) {
			Log.message( e.getMessage() );
		}
		IntStream.rangeClosed( 1, 3 ).forEach( index -> {
			final HashMap<String, String> groupEmpty = new HashMap<String, String>();
			String group = "group for Stud 2" + System.nanoTime();
			groupEmpty.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_NAME, group );
			try {
				String classId = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup( smUrl, groupEmpty, new ArrayList<String>() ).get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ),
						StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
				student2Groups.add( classId );
			} catch ( Exception e ) {
				Log.message( e.getMessage() );
			}
		} );
		groupIdsToVerify.clear();
		groupIdsToVerify.addAll( student1Groups );
		groupIdsToVerify.addAll( student2Groups );
		// Getting Response and Verification
		HashMap<String, String> response = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
		List<String> groupId = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), CreateGroupAPIConstants.GROUP_ID );
		Log.assertThat( new SMUtils().compareTwoList( groupId, groupIdsToVerify ), "The Group Id is matching!", "The Group Id is not matching!" );
		Log.testCaseInfo( "Verify student1 is part of three group and student 2 belong to groups1,2,3 so it will display the no groups" );
		HashMap<String, String> groupDetail = new HashMap<String, String>();
		groupDetail.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
		groupDetail.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
		groupDetail.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgIdToTest );
		try {
			HashMap<String, String> resonseOfAddStudent = addStudentToGroup( smUrl, groupDetail, StudentIdsToTest, groupIdsToVerify );
			// Getting Response and Verification
			HashMap<String, String> totalResonse = GetGroupsListingForStudentsNotBelongTo( smUrl, StudentIdsToTest, teacherIdToTest, orgIdToTest, accessToken );
			List<String> groupIdsofBoth = new SMAPIProcessor().getKeyValues( new JSONObject( totalResonse.get( Constants.REPORT_BODY ) ), CreateGroupAPIConstants.GROUP_ID );
			//Validating response code and exception Message
			Log.assertThat( totalResonse.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ), "The Status code matched", "The Status code Doesnot matched" );
			String actualException = new SMAPIProcessor().getKeyValues( new JSONObject( totalResonse.get( Constants.BODY ) ), Constants.EXCEPTION ).get( 0 );
			Log.assertThat( actualException.equals( CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION ), "The Exception message is matched",
					"The Exception message is not matched Actual["+actualException+"] Expected["+CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION+"]" );
			Log.endTestCase();
			Log.testCaseResult();
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		Log.testCaseResult();
	}
	/*
	 * /** It will verify the schema
	 * 
	 * @param StatusCode
	 * 
	 * @param response
	 */
	public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
		boolean isValid = false;
		try {
			isValid = new SMAPIProcessor().isSchemaValid( FileNameConstatnts.GET_GROUPS_NOT_BELONGS_TO_STUDENTS_SCHEMA, StatusCode, response.get( Constants.REPORT_BODY ) );
			Log.assertThat( isValid, "The schema is valid", "The schema is not valid" );
		} catch ( IOException e ) {
			e.printStackTrace();
		}
	}
	/**
	 * Verifying API
	 * 
	 * @param response
	 * @param teacherId
	 * @param orgId
	 * @param accessToken
	 */
	public void VerifyAPI( HashMap<String, String> response ) {

		// Actual Values
		String actualStatusCode = response.get( Constants.STATUS_CODE );
		String actualBody = response.get( Constants.REPORT_BODY );
		JSONObject responseBody = new JSONObject( actualBody );
		String actualMessage = new SMAPIProcessor().getKeyValues( responseBody, Constants.MESSAGE ).get( 0 );

		// Schema validation
		VerifySchema( actualStatusCode, response );

		// Status code matches
		Log.assertThat( actualStatusCode.equals( CommonAPIConstants.STATUS_CODE_OK ), "The response code Matches! as 200 ", "The response code doesnot Matches expected 200 but received " + actualStatusCode );
		Log.assertThat( actualMessage.equals( "Operation succeeded!" ), "The success message matches!", "The success message doesnot matches" );

		//other verificatino
		List<String> groupId = new SMAPIProcessor().getKeyValues( responseBody, CreateGroupAPIConstants.GROUP_ID );
		String groupOwnerId = new SMAPIProcessor().getKeyValues( responseBody, CreateGroupAPIConstants.GROUP_OWNER_ID ).get( 0 );
		String groupOwnerOrgId = new SMAPIProcessor().getKeyValues( responseBody, CreateGroupAPIConstants.ORGANIZATION_ID ).get( 0 );
		List<String> groupNames = new SMAPIProcessor().getKeyValues( responseBody, CreateGroupAPIConstants.GROUP_NAME );
		Log.assertThat( new SMUtils().compareTwoList( groupId, groupIdsToVerify ), "The Group Id is matching!", "The Group Id is not matching!" );
		Log.assertThat( new SMUtils().compareTwoList( groupNames, groupNamesToVerify ), "The Group Name is matching!", "The Group Name is not matching!" );
		Log.assertThat( groupOwnerId.equals( teacherIdToTest ), "The teacher Id is matched", "The teacher Id is not matched " );
		Log.assertThat( groupOwnerOrgId.equals( orgIdToTest ), "The Org Id is matched ", "The Org Id is not matched " );
	}


	public void CreateData( String StudentId, String orgIdToCreate, int groupCount ) throws Exception {

		// Teacher create
		teacherUsernameToTest = "teacher" + System.nanoTime();
		teacherIdToTest = new UserAPI().createTeacherAndResetPassword( orgIdToCreate, teacherUsernameToTest );
		orgIdToTest = orgIdToCreate;

		// Student create 
		StudentIdsToTest.clear();
		StudentIdsToTest.add( StudentId );

		//  enorlled in one class
		accessToken = null;
		accessToken = new RBSUtils().getAccessToken( teacherUsernameToTest, password );
		String groupName = "group" + System.nanoTime();
		HashMap<String, String> groupDetails = new HashMap<String, String>();
		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgIdToCreate );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
		try {
			groupDetails = createGroup( smUrl, groupDetails, StudentIdsToTest );
			String classId = new SMAPIProcessor().getKeyValues( new JSONObject( groupDetails.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
		} catch ( Exception e ) {
			Log.message( e.getMessage() );
		}

		// Groups creation To Verify
		groupIdsToVerify.clear();
		groupNamesToVerify.clear();
		IntStream.rangeClosed( 1, groupCount ).forEach( index -> {
			final HashMap<String, String> groupEmpty = new HashMap<String, String>();
			String group = "group" + System.nanoTime();
			groupEmpty.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIdToTest );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgIdToCreate );
			groupEmpty.put( CreateGroupAPIConstants.GROUP_NAME, group );
			try {
				String classId = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup( smUrl, groupEmpty, new ArrayList<String>() ).get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ),
						StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
				groupIdsToVerify.add( classId );
				groupNamesToVerify.add( group );
			} catch ( Exception e ) {
				Log.message( e.getMessage() );
			}
		} );
	}




	/**
	 * Create shared student present in two two teachers group
	 * 
	 * @param studentName
	 * @param teacherId1
	 * @param accessCodeOfT1
	 * @param teacherId2
	 * @param accessCodeOfT2
	 * @param orgId
	 * @return
	 */
	public String createSharedStudent( String studentName, String teacherId1, String accessCodeOfT1, String teacherId2, String accessCodeOfT2, String orgId ) {
		String classId1 = null;
		String classId2 = null;
		try {
			String studentId = new UserAPI().createMultiOrgStudent( Arrays.asList( orgId ), studentName );
			classId1 = createGroupWithParameter( "Shared student Group with Teacher 1 ", teacherId1, Arrays.asList( studentId ), orgId, accessCodeOfT1 );
			classId2 = createGroupWithParameter( "Shared student Group with Teacher 2 ", teacherId2, Arrays.asList( studentId ), orgId, accessCodeOfT2 );
			if ( classId1 != null && classId2 != null ) {
				return studentId;
			} else {
				Log.failsoft( "Error in Creating Shared Student" );
				return null;
			}
		} catch ( Exception e ) {
			return null;
		}
	}



	/**
	 * It will create a group
	 * 
	 * @param groupName
	 * @param teacherId
	 * @param studentRumbaIds
	 * @param orgId
	 * @param access_Token
	 * @return
	 */
	public String createGroupWithParameter( String groupName, String teacherId, List<String> studentRumbaIds, String orgId, String access_Token ) {
		HashMap<String, String> groupDetails = new HashMap<String, String>();
		HashMap<String, String> groupDetail = null;
		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, access_Token );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
		try {
			groupDetail = createGroup( smUrl, groupDetails, studentRumbaIds );
		} catch ( Exception e ) {}
		return new SMAPIProcessor().getKeyValues( new JSONObject( groupDetail.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
	}
}