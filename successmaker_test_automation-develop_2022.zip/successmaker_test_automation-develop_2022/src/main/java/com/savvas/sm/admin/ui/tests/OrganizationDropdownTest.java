package com.savvas.sm.admin.ui.tests;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.Dashboard;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class OrganizationDropdownTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the Organisation drop down", groups = { "SMK-51098", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdown001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdown001: Verify the Organisation drop down. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the Organisation drop down is present in the dashboard page" );
            SMUtils.logDescriptionTC( "Verify the Organisation drop down is expandable in the dashboard page" );
            //expand organization dropdown
            dashBoardPage.expandOrganizationDropdown();
            Log.assertThat( dashBoardPage.isOrgDrodownExpanded(), "Organization dropdown is Expandable", "Organization dropdown is not expandable" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the default selection in the Organisation drop down in the dashboard page" );
            //get organization from organizations dropdown
            List<String> organizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.ALL_ORGANIZATIONS_SELECTED, organizations.size() ) ), "All organizations are selcted as default",
                    "All organizations are not selcted as default" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the ALL option is present in the Organisation drop down in the dashboard page" );
            //verifying the Select All label
            Log.assertThat( dashBoardPage.getSelectAllLabel().equalsIgnoreCase( String.format( Dashboard.ALL_ORGANIZATION, organizations.size() ) ), "ALL (" + organizations.size() + ") is displayed properly under the organization dropdown",
                    "ALL (" + organizations.size() + ") is not diplayed properly under the organization dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Organisation drop down is a multiselect drop down in the dashboard page" );
            SMUtils.logDescriptionTC( "Verify the user is able to select one or more organisations from the Organisation drop down in the dashboard page." );
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ) ) );
            Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( organizations.get( 0 ) ), "User can able to select single organizations.", "User cannot able to select single organizations." );

            //trying to select multi organizations
            if ( organizations.size() > 1 ) {
                dashBoardPage.clickAllOptionsInOrganizationDropdown();
                dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ), organizations.get( 1 ) ) );
                Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().size() == 2, "User can able to select multiple organizations.", "User cannot able to select multiple organizations." );
            } else {
                Log.message( "This admin having less than one organization" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of ALL option present in the Organisation drop down in the dashboard page", groups = { "SMK-51098", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdown002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdown002: Verify the functionality of ALL option present in the Organisation drop down in the dashboard page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the functionality of ALL option present in the Organisation drop down in the dashboard page" );
            //Uncheck the All organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().isEmpty(), "User can able to deselect all the organization using All option checkbox.", "User cannot able to deselect all the organization using All option checkbox." );
            List<String> organizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();

            //check the All organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            Log.assertThat( dashBoardPage.getselectedOrganizationsFromOrgDropdown().size() == organizations.size(), "User can able to select all the organization using All option checkbox.",
                    "User cannot able to select all the organization using All option checkbox." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Search Bar is present in the Organisation drop down in the dashboard page" );
            SMUtils.logDescriptionTC( "Verify the default text in the Search Bar in the Organisation drop down in the dashboard page" );
            Log.assertThat( dashBoardPage.getPlaceHolderForSearchTextBox().equalsIgnoreCase( Dashboard.SEARCH_ORGANIZATIONS ), Dashboard.SEARCH_ORGANIZATIONS + "is displayed properly in the search text box",
                    Dashboard.SEARCH_ORGANIZATIONS + "is not displayed properly in the search text box" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of Search Bar", groups = { "SMK-51098", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdown003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMOrganizationDropdown003: Verify the functionality of Search Bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            List<String> organizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();

            SMUtils.logDescriptionTC( "Verify the functionality of Search Bar with valid organisation name in the checked state in the Organisation drop down in the dashboard page" );
            dashBoardPage.enterTextInSearchTextBox( organizations.get( organizations.size() - 1 ) );
            //get the sorted/listed organizations
            List<String> sortedOrganizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( organizations.get( organizations.size() - 1 ).toLowerCase() ) ),
                    "User can able to see the relevant results for the Organsiation name(s) searched.", "User cannot able to see the relevant results for the Organsiation name(s) searched." );

            //uncheck all the sorted organizations
            dashBoardPage.selectOrganizationsFromOrgDropdown( sortedOrganizations );
            dashBoardPage.clickCancelIconInSearchTextBox();
            if ( organizations.size() - sortedOrganizations.size() > 1 ) {
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.SELECTED_ORGANIZATIONS_COUNT, organizations.size() - sortedOrganizations.size() ) ),
                        "The drop down header is displayed as (Updated Org Count) Organizations Selected", "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            } else {
                Log.assertThat( !dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( organizations.get( organizations.size() - 1 ) ), "The drop down header is displayed as (Updated Org Count) Organizations Selected",
                        "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of Search Bar with valid organisation name in the unchecked state in the Organisation drop down in the dashboard page" );
            //uncheck the All organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();

            dashBoardPage.enterTextInSearchTextBox( organizations.get( organizations.size() - 1 ) );
            //get the sorted/listed organizations
            sortedOrganizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( organizations.get( organizations.size() - 1 ).toLowerCase() ) ),
                    "User can able to see the relevant results for the Organsiation name(s) searched.", "User cannot able to see the relevant results for the Organsiation name(s) searched." );

            //uncheck all the sorted organizations
            dashBoardPage.selectOrganizationsFromOrgDropdown( sortedOrganizations );
            dashBoardPage.clickCancelIconInSearchTextBox();
            if ( sortedOrganizations.size() > 1 ) {
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( String.format( Dashboard.SELECTED_ORGANIZATIONS_COUNT, organizations.size() - sortedOrganizations.size() ) ),
                        "The drop down header is displayed as (Updated Org Count) Organizations Selected", "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            } else {
                Log.assertThat( dashBoardPage.getSelectedOrganizationCount().equalsIgnoreCase( organizations.get( organizations.size() - 1 ) ), "The drop down header is displayed as (Updated Org Count) Organizations Selected",
                        "The drop down header is not displayed as (Updated Org Count) Organizations Selected" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of Search Bar with valid organisation name in the unchecked state in the Organisation drop down in the dashboard page" );
            //uncheck all organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            //check all organizations checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( Dashboard.INVALID_ORGNAME );
            Log.assertThat( dashBoardPage.getNoOrganizationFoundMessage().equalsIgnoreCase( Dashboard.NO_ORGANIZATION_FOUND ), "User can able to see the error message(" + Dashboard.NO_ORGANIZATION_FOUND + ")in the organization displaying pane.",
                    "User cannot able to see the error message(" + Dashboard.NO_ORGANIZATION_FOUND + ")in the organization displaying pane." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of Search Bar with invalid organisation name in the unchecked state in the Organisation drop down in the dashboard page" );
            //uncheck all organization checkbox
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.enterTextInSearchTextBox( Dashboard.INVALID_ORGNAME );
            Log.assertThat( dashBoardPage.getNoOrganizationFoundMessage().equalsIgnoreCase( Dashboard.NO_ORGANIZATION_FOUND ), "User can able to see the error message(" + Dashboard.NO_ORGANIZATION_FOUND + ")in the organization displaying pane.",
                    "User cannot able to see the error message(" + Dashboard.NO_ORGANIZATION_FOUND + ")in the organization displaying pane." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of Search Bar", groups = { "SMK-51098", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdown004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMOrganizationDropdown004: Verify the functionality of Search Bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            List<String> organizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();

            SMUtils.logDescriptionTC( "Verify searching of organization with minimum characters in the Organization drop down in the dashboard page." );
            String singleCharacter = String.valueOf( organizations.get( organizations.size() - 1 ).charAt( organizations.get( organizations.size() - 1 ).length() - 1 ) );
            dashBoardPage.enterTextInSearchTextBox( singleCharacter );
            //get the sorted/listed organizations
            List<String> sortedOrganizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( singleCharacter.toLowerCase() ) ), "User can able to see the relevant search result with minimum of 1 character.",
                    "User cannot able to see the relevant search result with minimum of 1 character." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search bar is case sensitive in Organization drop down in dashboard page" );
            dashBoardPage.enterTextInSearchTextBox( singleCharacter.toUpperCase() );
            sortedOrganizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            Log.assertThat( sortedOrganizations.stream().allMatch( orgName -> orgName.toLowerCase().contains( singleCharacter.toLowerCase() ) ),
                    "User can be able to see the organizations listed in the display pane with relevant search result irrespective to case sensitivity.",
                    "User cannot be able to see the organizations listed in the display pane with relevant search result irrespective to case sensitivity." );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search bar allows to enter alphanumeric characters in the search bar of Organization drop down in the dashboard page." );
            SMUtils.logDescriptionTC( "Verify the search bar allows to enter special characters in the search bar of Organization drop down in the dashboard page." );
            SMUtils.logDescriptionTC( "Verify the search bar allows the double space as input in the Organization listing drop down in dashboard page" );
            dashBoardPage.enterTextInSearchTextBox( Dashboard.ORG_NAME_SPECIALCHARACTER );
            Log.assertThat( dashBoardPage.getEnteredTextInSearchTextBox().equals( Dashboard.ORG_NAME_SPECIALCHARACTER ), "User can able to enter the special characters in the search bar ",
                    "User cannot able to enter the special characters in the search bar " );
            dashBoardPage.clickCancelIconInSearchTextBox();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of Apply selection(s) button", groups = { "SMK-51098", "adminDashboard", "organizationDropdown" }, priority = 1 )
    public void tcSMOrganizationDropdown005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMOrganizationDropdown005: Verify the functionality of Apply selection(s) button. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the Apply Selection(s) button is disabled by default in the dashboard page." );
            Log.assertThat( !dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is disabled by default.", "Apply Selection(s) button is enabled by default." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of Apply Selection(s) button in the dashboard page." );
            List<String> organizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ) ) );
            Log.assertThat( dashBoardPage.isApplySelectionButtonEnabled(), "Apply Selection(s) button is enabled after selecting the organization", "Apply Selection(s) button is disabled after selecting the organization" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
