package com.savvas.sm.basetests;

import java.util.logging.Level;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeSuite;

import com.learningservices.utils.EnvironmentPropertiesReader;

public class BaseTest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    @BeforeSuite
    public void beforeSuiteTest() {

        // Suppress Logging
        //System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true"); 
        java.util.logging.Logger.getLogger( "org.openqa.selenium" ).setLevel( Level.SEVERE );
        System.setProperty( FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null" );
    }
}
