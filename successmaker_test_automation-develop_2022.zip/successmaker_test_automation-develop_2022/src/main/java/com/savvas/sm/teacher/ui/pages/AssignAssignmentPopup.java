package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AssignAssignmentPopup extends LoadableComponent<MyProfilePage> {

    private WebDriver driver;
    boolean isPageLoaded;
    
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    
    // ********* SuccessMaker Assign Assignment Page Elements ***************

    @FindBy ( css =  "filter-group-student >div >div.list-data > div")
    List<WebElement> studentListAssignmentPopUp;

    @FindBy ( css = "div.table-container>table>tbody>tr" )
    List<WebElement> studentListAssignmentTable;

    @IFindBy (how = How.CSS, using = ".dialog-header>h1", AI = false )
    public WebElement assignmentTitle;

    @FindBy ( css = "cel-radio-button.sc-cel-radio-button-s .radio__wrapper" )
    List<WebElement> radioButton;

    @FindBy ( css = "cel-radio-button.sc-cel-radio-button-s .radio__wrapper input" )
    List<WebElement> radioButtonDefault;

    @IFindBy (how = How.CSS, using = ".radio-btn-group cel-radio-button:nth-of-type(1) input", AI = false )
    public WebElement groupsRadioBtnSelection;

    @IFindBy (how = How.CSS, using = ".radio-btn-group cel-radio-button:nth-of-type(2) input", AI = false )
    public WebElement studentsRadioBtn;
        
    @IFindBy (how = How.CSS, using = ".list-data .student-name>div:nth-of-type(1)", AI = false )
    public WebElement firstListedGroupStudentName;

    @IFindBy (how = How.CSS, using = "input[name='filterText']", AI = false )
    public WebElement txtFilter;

    @FindBy ( css = ".list-data .student-name>div.name" )
    List<WebElement> getFirstName;

    @IFindBy (how = How.CSS, using = ".list-data .add-btn>cel-button.hydrated", AI = false )
    public WebElement firstListedGroupStudentAssignBtn;

    @IFindBy (how = How.CSS, using = "div.assign-course-footer cel-button.assign-course-button:nth-of-type(2)", AI = false )
    public WebElement assignBtnShadow;

    @IFindBy (how = How.CSS, using = "cel-button.assign-course-button.assign-button", AI = false )
    public WebElement assignBtnRoot;

    private String assignBtnCSS = ".primary_button";

    @IFindBy (how = How.CSS, using = ".footer cel-button:nth-of-type(1)", AI = false )
    public WebElement cancelBtnShadow;

    @IFindBy (how = How.CSS, using = "div .cel-button-Assign", AI = false )
    public WebElement assignBtnAssignmentlistRoot;

//    @IFindBy (how = How.CSS, using = "div.radio__wrapper #cel-rb-1", AI = false )
//    public WebElement studentRadioBtn;
  
    @IFindBy (how = How.CSS, using = "cel-radio-button:nth-of-type(2) .radio__label.sc-cel-radio-button", AI = false )
    public WebElement studentRadioBtn;
    
    @IFindBy (how=How.XPATH, xpath = "(//div[@class='name'])[1]", AI = false )
    public WebElement firstStudentName;

    @IFindBy (how = How.CSS, using = "div.add-btn  > cel-button", AI = false )
    public WebElement addGroupbtnRoot;

    @IFindBy (how = How.CSS, using = "cel-button[color='primary'][role='button']", AI = false )
    public WebElement assignbtnRoot;

    @IFindBy (how = How.CSS, using = "assign-course > div", AI = false )
    public WebElement assignCoursePopup;

    @IFindBy (how = How.CSS, using = "tr:nth-child(4) cel-button.hydrated", AI = false )
    public WebElement viewAssignmentbtnRoot;

    @FindBy ( css = ".student-name .username" )
    List<WebElement> listOfStudents;

    @IFindBy (how = How.CSS, using = "input.ng-valid", AI = false )
    public WebElement searchTxtBx;

    @FindBy ( css = "button.sc-cel-dropdown-select" )
    List<WebElement> dropdownsWidget;

    @FindBy ( css = "button.switch-button" )
    List<WebElement> togglesWidget;

    @FindBy ( css = "div.list-data" )
    List<WebElement> listData;

    @FindBy ( css = "span.chips" )
    List<WebElement> groupsInSearchTxtBx;

    @IFindBy (how = How.CSS, using = "span.cross-mark>cel-icon.hydrated", AI = false )
    public WebElement closeBtn;

    @IFindBy (how = How.CSS, using = "cel-button.assign-button", AI = false )
    public WebElement assignBtn;

    @FindBy ( css = "div.list-data > div  > div.student-info > div >.name" )
    List<WebElement> studentsList;

    @FindBy ( css = "div.setting-label" )
    List<WebElement> assignmentSettingLabels;

    @IFindBy (how = How.CSS, using = "div.justify-content-end > cel-button.close-button.hydrated", AI = false )
    public WebElement cancelBtn;

    @IFindBy (how = How.CSS, using = "h3.header", AI = false )
    public WebElement assignToZeroState;

    @IFindBy (how = How.CSS, using = "div.add-btn.remove-btn.ng-star-inserted .hydrated", AI = false )
    public WebElement removeGroupButton;

    // Assignment Popup Cancel Button
    @IFindBy (how = How.CSS, using = "div.assign-course-footer>cel-button[color='secondary']", AI = false )
    public WebElement cancelbtnRoot;

    // Group Default Selection
//    @IFindBy (how = How.CSS, using = "div.radio__wrapper >input#cel-rb-0", AI = false)
//    public WebElement groupSelected;

    @IFindBy (how = How.CSS, using = "div.radio__wrapper >input", AI = false)
    public WebElement groupSelected;

    // search textbox in Groups
    @IFindBy (how = How.CSS, using = "div.chip-area>input", AI = false )
    public WebElement textBoxSearch;

    // group remove icon
    @IFindBy (how = How.CSS, using = "cel-icon.close-icon", AI = false )
    public WebElement groupRemove;

    // group remove button
    @FindBy (css = "div.student-info div.add-btn cel-button" )
    List<WebElement> removeButton;

    @FindBy ( css = "span.chips" )
    List<WebElement> groupCount;

    @FindBy ( css = "cel-icon[name='icon_close']" )
    List<WebElement> removeIcon;

    @FindBy ( css = "cel-button[class='hydrated']" )
    List<WebElement> studentsAddButton;

    @IFindBy (how = How.CSS, using = "input.chip-search-area", AI = false)
    public WebElement groupWatermarkText;

    @FindBy ( css = "div.name" )
    List<WebElement> studentsListSize;

    @IFindBy (how = How.CSS, using = " div.zero-state-content > h3", AI = false )
    public WebElement zeroStateMessage;

    @IFindBy (how = How.CSS, using = "  div.zero-state-content > span", AI = false )
    public WebElement zerStateErrorMessage;

    @FindBy ( css = "div.student-info" )
    List<WebElement> listOfStudentsInfo;

    @FindBy ( css = ".list-data .student-name .first-name" )
    List<WebElement> studentFirstNameList;

    @FindBy ( css = ".list-data .student-name .last-name" )
    List<WebElement> studentLastnameList;

    @FindBy ( css = ".list-data .student-name .username" )
    List<WebElement> studentUserNameList;

    @FindBy ( css = "zero-state-icon" )
    List<WebElement> zerostateMessage;
    
    @FindBy ( css = "div.zero-state-content" )
    List<WebElement> zerostateContentMessage;

    // *****Child Elements********************

    private static String cancelBtnCSS = ".secondary_button";
    private static String assignBtnChild = ".primary_button";
    private static String addGroupBtnChild = ".secondary_button";
    private static String viewAssignmentbtnChild = ".secondary_button";
    private static String buttonText = "cel-button[class='hydrated']";
    //******* Remove icon
    private static String removeIconChild = ".icon-inner";

    public AssignAssignmentPopup() {}
    /**
     * Constructor to invoke the report component
     *
     * @param driver
     */
    public AssignAssignmentPopup( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, assignmentTitle ) ) {
            Log.message( "SM My profile page loaded successfully." );
        } else {
            Log.fail( "SM My profile page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, assignmentTitle );
    }

    /**
     * To Click Multiple Add Button on Popup page
     */
    public void clickMultipleAddButton() {
        SMUtils.waitForElement( driver, addGroupbtnRoot );
        studentsAddButton.forEach( element -> {
             WebElement addButton = SMUtils.getWebElement( driver, element, addGroupBtnChild );
            SMUtils.clickJS( driver, addButton );
            Log.message( "Clicked Add Button" );
        } );

    }

    /**
     * gets and returns the assignment title
     *
     * @return
     */
    public String getAssignmentTitle() {
        SMUtils.waitForElementToBeClickable( assignmentTitle, driver );
        return assignmentTitle.getText().replace( "Assign ", "" );
    }

    /**
     * returns the Groups radio btn's checked state as boolean
     *
     * @return
     */
    public boolean isGroupsChecked() {
        SMUtils.waitForElement( driver, groupsRadioBtnSelection );
        return groupsRadioBtnSelection.isSelected();
    }

    /**
     * returns the Groups and students radio btn's checked state as boolean from
     * list
     *
     * @return
     */
    public boolean radioButtonsDefaultSelection() {
        SMUtils.waitForElement( driver, assignmentTitle );
        return ( radioButtonDefault.iterator().next().isSelected() );
    }

    /**
     * returns the Groups radio btn's checked state as boolean
     *
     * @return
     */
    public boolean isStudentsChecked() {
        SMUtils.waitForElement( driver, studentsRadioBtn );
        return studentsRadioBtn.isSelected();
    }

    /**
     * check the students radio btn
     */
    public void checkStudents() {

        SMUtils.waitForElement( driver, studentsRadioBtn, 5 );
        if ( !isStudentsChecked() )
            SMUtils.clickJS( driver, studentsRadioBtn );
        Log.message( "Clicked Student Radio Button" );
    }

    /**
     * To add and get first student Name from list
     */
    public String addStudentsToAssignment() {
        checkStudents();

        SMUtils.waitForElementToBeClickable( assignmentTitle, driver );
        radioButtonSelectAssignWidget( Constants.STUDENTS );
        List<String> studentLists = new ArrayList<>();
        getFirstName.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( studentLists::add ) );
        String firstStudentUserName = studentLists.iterator().next();
        SMUtils.waitForElement( driver, firstListedGroupStudentAssignBtn, 5 );
        firstListedGroupStudentAssignBtn.click();

        assignBtn();
        return firstStudentUserName;
    }

    /**
     * To add student
     *
     * @return
     */
    public String addStudentToAssignment( String studentName ) {
        checkStudents();
        String firstStudentName = firstListedGroupStudentName.getText();
        this.listOfStudents.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( studentName ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement parentElement1 = parentElement.findElement( By.xpath( "./.." ) );
                WebElement parentElement2 = parentElement1.findElement( By.xpath( "./.." ) );
                WebElement addButton = parentElement2.findElement( By.cssSelector( ".add-btn" ) );
                SMUtils.waitForElement( driver, addButton, 5 );
                SMUtils.clickJS( driver, addButton );
            }
        } ) );
        SMUtils.nap( 0.5 );
        assign();
        return firstStudentName;
    }

    /**
     * Click on Save Btn
     */
    public void assign() {
        SMUtils.waitForElement( driver, assignBtnRoot );
        WebElement saveBtn = SMUtils.getWebElement( driver, assignBtnRoot, assignBtnCSS );
        SMUtils.waitForElement( driver, saveBtn );
        SMUtils.clickJS( driver, saveBtn );
        SMUtils.nap( 0.5 );
    }

    /**
     * To add and get first group Name from list
     */
    public String addgroupsToAssignment() {
        SMUtils.waitForElement( driver, assignmentTitle, 6 );
        List<String> studentLists = new ArrayList<>();
        getFirstName.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( studentLists::add ) );
        String firstGroupName = studentLists.iterator().next();
        firstListedGroupStudentAssignBtn.click();
        assignBtn();
        return firstGroupName;
    }

    /**
     * Click on Assign Btn
     */
    public void assignBtn() {
        SMUtils.waitForElementToBeClickable( assignBtn, driver );
        SMUtils.clickJS( driver, assignBtn );
        Log.message( "Clicked Assign Button" );
    }

    /**
     * Click on Cancel Btn
     */
    public void cancelChangesBtn() {
        SMUtils.waitForElementToBeClickable( cancelBtn, driver );
        SMUtils.clickJS( driver, cancelBtn );
        Log.message( "Clicked Cancel Button" );
    }

    /**
     * TO Get Student Listing on pop up
     *
     * @return
     */

    public List<String> getStudentListFromPopUp() {
        SMUtils.nap( 1 );
        List<String> studentListFromPopUp = new ArrayList<>();
        studentsList.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( studentListFromPopUp::add ) );
        Collections.sort( studentListFromPopUp );
        return studentListFromPopUp;

    }

    /**
     * To Click Add Button on Popup page
     */
    public void clickAddButton() {
        SMUtils.waitForElement( driver, addGroupbtnRoot );
        WebElement addButton = SMUtils.getWebElement( driver, addGroupbtnRoot, addGroupBtnChild );
        SMUtils.clickJS( driver, addButton );
        Log.message( "Clicked Add  Button" );

    }

    /**
     * Add Student in to the Chip area in Assign popup
     *
     * @param studentUsernames
     */
    public void addStudentsToChipBox( List<String> studentUsernames ) {
        studentUsernames.forEach( student -> {
            txtFilter.sendKeys( student );
            if ( listOfStudentsInfo.size() > 0 ) {
                SMUtils.click( driver, SMUtils.getWebElementDirect( driver, listOfStudentsInfo.get( 0 ).findElement( By.cssSelector( "div cel-button" ) ), "button" ) );
            } else {
                Log.message( "Student not found for the : " + student );
            }
        } );
    }

    /**
     * To Click Assign button on Popup for Math Assignments
     */
    public void clickAssignButtonOnPopup() {
        SMUtils.waitForElement( driver, assignbtnRoot );
        WebElement AssignButton = SMUtils.getWebElement( driver, assignbtnRoot, assignBtnChild );
        SMUtils.clickJS( driver, AssignButton );
        Log.message( "Clicked Assign Button" );

    }

    /**
     * To Click View Assignment Math Button
     */
    public void clickViewAssignment() {
        SMUtils.waitForElement( driver, viewAssignmentbtnRoot );
        WebElement viewAssignment = SMUtils.getWebElement( driver, viewAssignmentbtnRoot, viewAssignmentbtnChild );
        SMUtils.clickJS( driver, viewAssignment );
        Log.message( "Clicked View Assignment  Button" );

    }

    /**
     * assign existing assignment
     */
    public void assignMultipleStudentsToCourse() throws Exception {
        SMUtils.nap( 1 );

        SMUtils.waitForElement( driver, assignCoursePopup, 5 );
        if ( !assignCoursePopup.isDisplayed() ) {
            throw new Exception( "Assign Course Popup not visible" );
        }
        checkStudents();
        clickMultipleAddButton();
        SMUtils.nap( 2 );

    }

    /**
     * To Click Assign Button on Assign listing page
     */
    public void clickAssignButton() {
        SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot, 5 );
        WebElement assignButton = SMUtils.getWebElement( driver, assignBtnAssignmentlistRoot, assignBtnChild );
        SMUtils.clickJS( driver, assignButton );
        Log.message( "Clicked Assign Button on Assignments Listing Button" );
    }

    /**
     * To Get First Student name
     *
     * @return
     */

    public String getFirstStudentsName() {
        SMUtils.nap( 3 );
        String studentName = firstStudentName.getAttribute( "title" );
        Log.message( studentName );
        return studentName;
    }

    /**
     * Verify the Elements displayed on Course Assign Widget
     */
    public boolean elementsDisplayedOnCourseAssignWidget() {
        SMUtils.waitForElement( driver, assignmentTitle );
        return ( radioButton.stream().map( element -> Optional.ofNullable( element ).isPresent() ) != null && SMUtils.isElementPresent( searchTxtBx ) && dropdownsWidget.size() != 0 && togglesWidget.size() != 0 && listData.size() != 0 );
    }

    /**
     * Verify Groups in Search Text Box
     */
    public int groupsOrStudentsInSearchTxtBx() {
        SMUtils.waitForElement( driver, assignmentTitle );
        return groupsInSearchTxtBx.size();
    }

    /**
     * To Click Close button for Group or Student
     */
    public void clickCloseBtnForGroupOrStudent() {
        SMUtils.waitForElementToBeClickable( closeBtn, driver );
        closeBtn.click();
        Log.message( "Clicked Close Button" );
    }

    /**
     * To get text of Remove button
     */
    public boolean getRemoveButtonText() {
        SMUtils.waitForElement( driver, addGroupbtnRoot );
        return addGroupbtnRoot.getText().trim().equalsIgnoreCase( Constants.removeText );
    }

    /**
     * Verify Student is available under the list
     *
     * @return
     */

    @SuppressWarnings ( "unlikely-arg-type" )
    public boolean getStudentOrGroupFromPopUp( String studentName ) {
        boolean studentNameStatus = studentsList.stream().anyMatch( element -> Optional.ofNullable( element.getText() ).equals( studentName ) );
        return studentNameStatus;
    }

    /**
     * Verify the Elements displayed on Course Assign Widget
     */
    public boolean courseAssignSettingLabels() {
        SMUtils.waitForElement( driver, addGroupbtnRoot );
        boolean status = assignmentSettingLabels.stream().map( element -> Optional.ofNullable( element ).isPresent() ) != null && dropdownsWidget.size() != 0 && togglesWidget.size() != 0;
        return status;
    }

    /**
     * To VerifyAssign to zero state message
     *
     * @return
     */
    public boolean verifyAssignToZeroState() {
        SMUtils.waitForElement( driver, assignToZeroState );
        return SMUtils.isElementPresent( assignToZeroState );
    }

    /**
     * To select All the students in a list
     */
    public void selectAllStudents() {
        SMUtils.waitForElement( driver, addGroupbtnRoot );
        List<WebElement> studentAddRoots = driver.findElements( By.cssSelector( buttonText ) );
        studentAddRoots.forEach( element -> {
            WebElement addButton = SMUtils.getWebElement( driver, element, addGroupBtnChild );
            SMUtils.clickJS( driver, addButton );
            Log.message( "Clicked Add Button" );
        } );
    }

    /**
     * To check the student name available in the assign to popup
     */
    public Boolean GetStudentNameFromPopup() {
        checkStudents();
        return firstListedGroupStudentName.isDisplayed();
    }

    /**
     * To check the Remove course button available in the assign to popup
     */
    public Boolean RemoveStudentbutton() {
        SMUtils.waitForElement( driver, removeGroupButton );
        return SMUtils.isElementPresent( removeGroupButton );
    }

    /**
     * To check the Students radio btn's checked state as boolean
     *
     * @return
     */
    public boolean isStudentRadioChecked() {
        SMUtils.waitForElement( driver, studentsRadioBtn );
        return studentsRadioBtn.isSelected();
    }

    /*
     * To Click Cancel button on Popup for Assignments
     */
    public void clickCancelButtonOnPopup() {
        SMUtils.waitForElement( driver, cancelbtnRoot );
        WebElement cancelButton = SMUtils.getWebElement( driver, cancelbtnRoot, cancelBtnCSS );
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Clicked Cancel Button" );
    }

    /**
     * returns the Groups radio btn's checked state as boolean
     *
     * @return
     */
    public boolean isGroupSelected() {
        SMUtils.waitForElement( driver, groupSelected, 10 );
        return groupSelected.isSelected();
    }

    /**
     * Enter the value to the search text box in Assignment Pop up
     */
    public void enterSearchTextboxAssignment( String Value ) {
        SMUtils.waitForElement( driver, textBoxSearch, 10 );
        textBoxSearch.sendKeys( Value );

    }

    /**
     * To Get Text Value from the search text box
     *
     * @return
     */
    public String getTextValue() {
        SMUtils.waitForElement( driver, textBoxSearch, 10 );
        return textBoxSearch.getAttribute( "value" ).trim();
    }

    /**
     * To Click Multiple Remove icon in Assignment Pop up window
     */
    public void clickMultipleRemoveIcon() {
        SMUtils.waitForElement( driver, groupSelected );
        for ( WebElement remove : removeIcon ) {
            WebElement closeIcon = SMUtils.getWebElementDirect( driver, remove, removeIconChild );
            SMUtils.clickJS( driver, closeIcon );
            Log.message( "Clicked Close icon" );
        }
    }

    /**
     * To Click Multiple Remove Button on Popup page
     */
    public void clickRemoveButtonAll() {
        SMUtils.waitForElement( driver, groupSelected );
        IntStream.rangeClosed( 0, removeButton.size() - 1 ).forEach( element -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, removeButton.get( element ), addGroupBtnChild );
            SMUtils.clickJS( driver, addBtn );
            Log.message( "Clicked Remove button" );
        } );
    }

    /**
     * Verify all the groups are removed in the textbox
     */
    public void verifyallGroupsremoved() {
        if ( CollectionUtils.isEmpty( groupCount ) ) {
            Log.message( "Groups are removed  in the text box successfully" );
        } else {
            Log.fail( "Groups are not removed in the text box" );
        }

    }

    /**
     * Verify all the Students are removed in the textbox
     */
    public void verifyAllstudentsremoved() {
        if ( CollectionUtils.isEmpty( groupCount ) ) {
            Log.message( "Students are removed  in the text box successfully" );
        } else {
            Log.fail( "Students are not removed in the text box" );
        }

    }

    /**
     * To Click all add Button on Popup page
     */
    public void clickAddButtonAll() {
        SMUtils.waitForElement( driver, groupSelected );
        IntStream.rangeClosed( 0, removeButton.size() - 1 ).forEach( element -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, removeButton.get( element ), addGroupBtnChild );
            SMUtils.clickJS( driver, addBtn );
            Log.message( "Clicked add button" );
        } );

    }

    /**
     * Verify groups are added on Popup page
     */
    public void verifyallGroupsAdded() {
        if ( CollectionUtils.isNotEmpty( groupCount ) ) {
            Log.message( "Groups are added  in the text box successfully" );
        } else {
            Log.fail( "Groups are not added in the text box" );
        }

    }

    /**
     * Verify students are added on Popup page
     */
    public void verifyallStudentsAdded() {
        if ( CollectionUtils.isNotEmpty( groupCount ) ) {
            Log.message( "Students are added  in the text box successfully" );
        } else {
            Log.fail( "Students  are not added in the text box" );
        }

    }

    /**
     * To Click few add Buttons on Popup page
     */
    public void clickFewAddButton() {
        SMUtils.waitForElement( driver, groupSelected );
        IntStream.rangeClosed( 0, removeButton.size() ).limit( 2 ).forEach( element -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, removeButton.get( element ), addGroupBtnChild );
            SMUtils.clickJS( driver, addBtn );
            Log.message( "Clicked few Add button" );
        } );

    }

    /**
     * To Click few remove Buttons on Popup page
     */
    public void clickFewRemoveButton() {
        SMUtils.waitForElement( driver, groupSelected );
        IntStream.rangeClosed( 0, removeButton.size() ).limit( 2 ).forEach( element -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, removeButton.get( element ), addGroupBtnChild );
            SMUtils.clickJS( driver, addBtn );
            Log.message( "Clicked few Remove button" );
        } );

    }

    /**
     * TO check Assign Button Enable
     *
     * @return
     */
    public boolean isAssignButtonEnable() {
        SMUtils.waitForElement( driver, assignbtnRoot );
        WebElement AssignButton = SMUtils.getWebElement( driver, assignbtnRoot, assignBtnChild );
        return AssignButton.isEnabled();
    }

    /**
     * TO check Students are displayed
     */
    public void verifyGroupStudentsdisplayed() {
        if ( CollectionUtils.isEmpty( removeButton ) ) {
            Log.message( "Groups are not displayed sucessfuly" );
        } else {
            Log.fail( "Groups are displayed" );
        }
    }

    /**
     * To Verify cancel button is displayed for Assignments
     */
    public boolean isCancelButtonOnPopupEnable() {
        SMUtils.waitForElement( driver, cancelbtnRoot );
        WebElement cancelButton = SMUtils.getWebElement( driver, cancelbtnRoot, cancelBtnCSS );
        return cancelButton.isDisplayed();
    }

    /**
     * This method is to click student/group radio button
     *
     * @param radioBtnToClick
     */
    public void radioButtonSelectAssignWidget( String radioBtnToClick ) {
        SMUtils.waitForLocator( driver, By.cssSelector( "cel-radio-button.sc-cel-radio-button-s" ), 5 );
        try {
            radioButton.forEach(
                    element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( Constants.LABEL ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( radioBtnToClick ) ).ifPresent( elementFinalText -> {
                        if ( elementFinalText.equalsIgnoreCase( radioBtnToClick ) ) {
                            SMUtils.clickJS( driver, element.findElement( By.cssSelector( Constants.LABEL ) ) );
                        }
                    } ) );
        } catch ( Exception e ) {
            Log.message( "Hidden row detected." );
        }
    }

    /**
     * To Verify cancel button is displayed for Assignments
     */
    public String getWatermarkTestAvailable() {
        SMUtils.waitForElement( driver, groupWatermarkText );
        String groupsWatermarkText = groupWatermarkText.getAttribute( "placeholder" ).trim();
        Log.message( groupsWatermarkText );
        return groupsWatermarkText;
    }

    /**
     * To click on remove icon for selected group
     */
    public void toClickRemove() {
        SMUtils.waitForElement( driver, addGroupbtnRoot );
        removeIcon.forEach( element -> {
            WebElement iconRemove = SMUtils.getWebElement( driver, element, removeIconChild );
            SMUtils.clickJS( driver, iconRemove );
            Log.message( "Clicked Remove icon" );
        } );
    }

    /**
     * To check the text box value after changed the radio button to groups
     *
     * @return
     */
    public boolean checkGroupisReset() {
        SMUtils.waitForElement( driver, groupsRadioBtnSelection );
        SMUtils.clickJS( driver, groupsRadioBtnSelection );
        Log.message( "Group Radio button selected" );
        return groupWatermarkText.getText().isEmpty();
    }

    /**
     * To Verify the student and group list in the pop up
     */
    public int verifyStudents() {
        SMUtils.waitForElement( driver, addGroupbtnRoot, 10 );
        int size = studentsListSize.size();
        return size;
    }

    /**
     * To Verify the student and group list in the pop up
     */
    public String verifyErrorMessage( String browser ) {
        String finalValue = null;
        if ( !browser.contains( "Safari" ) ) {
            SMUtils.waitForElement( driver, zeroStateMessage, 10 );
            String errorMessage = zeroStateMessage.getText().trim();
            String errorMessagea = zerStateErrorMessage.getText().trim();
            finalValue = errorMessage + " " + errorMessagea;
        } else if ( browser.contains( "Safari" ) ) {
            SMUtils.waitForElement( driver, zeroStateMessage, 10 );
            String errorMessage = zeroStateMessage.getText().trim();
            String errorMessageconv = errorMessage.toUpperCase();
            String errorMessagea = zerStateErrorMessage.getText().trim();
            finalValue = errorMessageconv + " " + errorMessagea;
        }
        return finalValue;

    }

    /**
     * To get the student firstnamelist
     *
     * @return
     */
    public List<String> getStudentFirstNameList() {

        SMUtils.waitForElement( driver, textBoxSearch );
        return SMUtils.getAllTextFromWebElementList( studentFirstNameList );
    }

    /**
     * To get the student lastnamelist
     *
     * @return
     */
    public List<String> getStudentLastNamelist() {
        SMUtils.waitForElement( driver, textBoxSearch );
        return SMUtils.getAllTextFromWebElementList( studentLastnameList );
    }

    /**
     * To get student username list
     *
     * @return
     */
    public List<String> getStudentUserNameList() {
        SMUtils.waitForElement( driver, textBoxSearch );
        return SMUtils.getAllTextFromWebElementList( studentUserNameList );
    }

    /**
     * To verify zero state message
     *
     * @return
     */
    public List<String> verifyZeroState() {
        SMUtils.waitForElement( driver, textBoxSearch );
        System.out.println(SMUtils.getAllTextFromWebElementList( zerostateMessage ));
        return SMUtils.getAllTextFromWebElementList( zerostateMessage );
    }
      
    /**
     * To verify zero state message
     * 
     * @return
     */
    public List<String> verifyZeroStateMessage() {
        SMUtils.waitForElement( driver, textBoxSearch );
        System.out.println(SMUtils.getAllTextFromWebElementList( zerostateContentMessage ));
        return SMUtils.getAllTextFromWebElementList( zerostateContentMessage );
    }

}
