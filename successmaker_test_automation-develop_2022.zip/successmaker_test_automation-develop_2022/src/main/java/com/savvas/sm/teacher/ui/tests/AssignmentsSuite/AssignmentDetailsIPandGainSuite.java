package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentDetailsIPandGainSuite extends BaseTest {

    String chromeBrowser = "Windows_10_Chrome_latest";
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String schoolID;
    private String teacherID;
    private static String username = null;
    private static String password = null;
    String teacherDetails;
    String studentDetailsFirst;
    String studentDetailsSecond;
    String studentDetailsThird;
    String studentDetailsFour;
    String studentDetailsFive;
    String studentDetailsSix;
    String studentUsernameFirst;
    String studentUsernameSecond;
    String studentUsernameThird;
    String studentUsernameFour;
    String studentUsernameFive;
    String studentUsernameSix;
    private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution;
    String customSettingCourseMath;
    String customSettingCourseReading;

    String token;
    private static List<String> studentRumbaIds = new ArrayList<>();

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        studentDetailsFirst = RBSDataSetup.getMyStudent( school, username );
        studentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        studentDetailsThird = RBSDataSetup.getMyStudent( school, username );
        studentDetailsFour = RBSDataSetup.getMyStudent( school, username );
        studentDetailsFive = RBSDataSetup.getMyStudent( school, username );
        studentDetailsSix = RBSDataSetup.getMyStudent( school, username );

        studentUsernameFirst = SMUtils.getKeyValueFromResponse( studentDetailsFirst, "userName" );
        studentUsernameSecond = SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userName" );
        studentUsernameThird = SMUtils.getKeyValueFromResponse( studentDetailsThird, "userName" );
        studentUsernameFour = SMUtils.getKeyValueFromResponse( studentDetailsFour, "userName" );
        studentUsernameFive = SMUtils.getKeyValueFromResponse( studentDetailsFive, "userName" );
        studentUsernameSix = SMUtils.getKeyValueFromResponse( studentDetailsSix, "userName" );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThird, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsFour, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsFive, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSix, "userId" ) );

        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        customSettingCourseMath = "Custom-Setting-Math-IP-Off_" + System.nanoTime();
        customSettingCourseReading = "Custom-Setting-Reading-IP-Off_" + System.nanoTime();

    }

    @Test ( description = "Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(ON) when student answered of 150 questions", groups = { "SMK-46775", "AssignmentDetails", "IP and Gains" }, priority = 1 )
    public void tcSMAssignmentDetailsIPAndGain01() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAssignmentDetailsIPAndGain01: Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(ON) when student answered of 150 questions <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );
            String assignmentNameMath = "Math";
            String assignmentNameReading = "Reading";

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to student
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing Math & Reading assignments in the student dashboard by using simulator
    		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
    		
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUsernameFirst, password );
            StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );

            studentsPage.executeMathCourse( studentUsernameFirst, Constants.MATH, "95", "5", "33" );
            studentsPage.executeReadingCourse( studentUsernameFirst, Constants.READING, "85", "5", "35" );

            studentsPage.logout();
            chromeDriver.quit();
            
            // Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);


            //Navigate to teacher page again
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );

            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Math assignment for student from Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameMath );
            List<String> studentIPandGain = new ArrayList<String>();
            studentIPandGain = mathAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFirst, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFirst, "lastName" ) );

            // Getting IPLevel and Gain of Math assignment for student from Assignment API Page
            HashMap<String, HashMap<String, String>> studentIPandGainFromAPI = getStudentIPandGainFromAPI( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "userId" ) );
            HashMap<String, String> ipLevel = studentIPandGainFromAPI.get( Constants.IPLEVEL );
            HashMap<String, String> gain = studentIPandGainFromAPI.get( Constants.GAIN );

            //Matching the UI and API IP and Gain values for Math Assignment
            DecimalFormat decimalFormat = new DecimalFormat( "#0.00" );

            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( ipLevel.get( assignmentNameMath ) ) ) );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( gain.get( assignmentNameMath ) ) ) );
            Log.message( "UI Response:" + studentIPandGain.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGain.get( 1 ) );
            if ( Float.parseFloat( decimalFormat.format( Double.valueOf( ipLevel.get( assignmentNameMath ) ) ) ) > 0.0 ) {

                Log.assertThat( decimalFormat.format( Double.valueOf( ipLevel.get( assignmentNameMath ) ) ).equals( studentIPandGain.get( 0 ) ), "IP Level for student is matched", "IP Level is not matched" );
            } else {
                Log.assertThat( "IN-IP".equals( studentIPandGain.get( 0 ) ), "IP Level for student is matched", "IP Level is not matched" );
            }
            Log.assertThat( decimalFormat.format( Double.valueOf( gain.get( assignmentNameMath ) ) ).equals( studentIPandGain.get( 1 ) ), "Gain for student is matched", "Gain is not matched" );

            teacherHomePage.topNavBar.signOutfromSM();

			/* for browserstack execution */
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            //Navigate to teacher Dashboard after students take the test
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );

            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Reading assignment for student from Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameReading );
            List<String> studentIPandGainReading = new ArrayList<String>();
            studentIPandGainReading = readingAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFirst, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFirst, "lastName" ) );

            // Getting IPLevel and Gain of Math assignment for student from Assignment API Page
            studentIPandGainFromAPI = getStudentIPandGainFromAPI( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "userId" ) );
            ipLevel = studentIPandGainFromAPI.get( Constants.IPLEVEL );
            gain = studentIPandGainFromAPI.get( Constants.GAIN );

            //Matching the UI and API - IPLevel and Gain values for Reading Assignment
            decimalFormat = new DecimalFormat( "#0.00" );

            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( ipLevel.get( assignmentNameReading ) ) ) );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( gain.get( assignmentNameReading ) ) ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 1 ) );
            if ( Float.parseFloat( decimalFormat.format( Double.valueOf( ipLevel.get( assignmentNameReading ) ) ) ) > 0.0 ) {

                Log.assertThat( decimalFormat.format( Double.valueOf( ipLevel.get( assignmentNameReading ) ) ).equals( studentIPandGainReading.get( 0 ) ), "IP Level for student is matched", "IP Level is not matched" );
            } else {
                Log.assertThat( "IN-IP".equals( studentIPandGainReading.get( 0 ) ), "IP Level for student is matched", "IP Level is not matched" );
            }
            Log.assertThat( decimalFormat.format( Double.valueOf( gain.get( assignmentNameReading ) ) ).equals( studentIPandGainReading.get( 1 ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(ON) when student started few assignments but not completed", groups = { "SMK-46775", "AssignmentDetails",
            "IP and Gains" }, priority = 2 )
    public void tcSMAssignmentDetailsIPAndGain02() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAssignmentDetailsIPAndGain02: Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(ON) when student started few assignments but not completed <small><b><i>[" + browser
                + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            String assignmentNameMath = "Math";
            String assignmentNameReading = "Reading";

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to student
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing Math & Reading assignments in student dashboard
          	// Get driver
    		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
    			
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUsernameSecond, password );
            StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );

            studentsPage.executeMathCourse( studentUsernameSecond, Constants.MATH, "85", "1", "1" );
            studentsPage.executeReadingCourse( studentUsernameSecond, Constants.READING, "75", "1", "1" );

            // SignOut from SM
            studentsPage.logout();
            chromeDriver.quit();
            //driver = WebDriverFactory.get( browser );

            //Navigate to teacher dashboard after students took test
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			
			LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );

            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Math assignment for student from Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameMath );
            List<String> studentIPandGain = new ArrayList<String>();
            studentIPandGain = mathAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsSecond, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsSecond, "lastName" ) );
            Log.assertThat( ( studentIPandGain.get( 0 ).equalsIgnoreCase( Constants.INIP ) ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( ( studentIPandGain.get( 1 ).equalsIgnoreCase( Constants.INIP ) ), "Gain for student is matched", "Gain is not matched" );

            // Getting IPLevel and Gain of Reading assignment for student from Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameReading );
            List<String> studentIPandGainReading = new ArrayList<String>();
            studentIPandGainReading = readingAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsSecond, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsSecond, "lastName" ) );

            //Matching the UI and API - IPLevel and Gain values for Reading Assignment
            Log.message( "UI Response:" + studentIPandGainReading.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 1 ) );
            Log.assertThat( ( studentIPandGainReading.get( 0 ).equalsIgnoreCase( Constants.INIP ) ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( ( studentIPandGainReading.get( 1 ).equalsIgnoreCase( Constants.INIP ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(ON) when student does not started the assignment", groups = { "SMK-46775", "AssignmentDetails", "IP and Gains" }, priority = 3 )
    public void tcSMAssignmentDetailsIPAndGain03() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo(
                "tcSMAssignmentDetailsIPAndGain03: Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(ON) when student does not started the assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            String assignmentNameMath = "Math";
            String assignmentNameReading = "Reading";

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to student
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Getting IPLevel and Gain of Math assignment for student from Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameMath );
            List<String> studentIPandGain = new ArrayList<String>();
            studentIPandGain = mathAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsThird, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsThird, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsThird, "lastName" ) );
            Log.assertThat( ( studentIPandGain.get( 0 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( ( studentIPandGain.get( 1 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "Gain for student is matched", "Gain is not matched" );

            // Getting IPLevel and Gain of Reading assignment for student from Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameReading );
            List<String> studentIPandGainReading = new ArrayList<String>();
            studentIPandGainReading = readingAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsThird, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsThird, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsThird, "lastName" ) );

            //Matching the UI and API - IPLevel and Gain values for Reading Assignment
            Log.message( "UI Response:" + studentIPandGainReading.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 1 ) );
            Log.assertThat( ( studentIPandGainReading.get( 0 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( ( studentIPandGainReading.get( 1 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(OFF) when student answered of 150 questions", groups = { "SMK-46775", "AssignmentDetails", "IP and Gains" }, priority = 4 )
    public void tcSMAssignmentDetailsIPAndGain04() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAssignmentDetailsIPAndGain04: Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(OFF) when student answered of 150 questions <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Creating Math custom setting course with IP Off
            coursePage.clickMathCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( customSettingCourseMath );
            coursePage.clickSettingsRadioBtn();
            coursePage.clickNextBtn();
            coursePage.turnOffInitialPlacement();
            coursePage.clickCreateBtn();

            // Creating Reading custom setting course with IP Off
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( customSettingCourseReading );
            coursePage.clickSettingsRadioBtn();
            coursePage.clickNextBtn();
            coursePage.turnOffInitialPlacement();
            coursePage.clickCreateBtn();

            // Selecting Math custom setting Course and assigning to student
            CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickCourseFromTheListing( customSettingCourseMath );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to student
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickCourseFromTheListing( customSettingCourseReading );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing Math & Reading assignments in student dashboard
    		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
    			
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUsernameFour, password );
            StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );

            studentsPage.executeMathCourse( studentUsernameFour, customSettingCourseMath, "95", "5", "33" );
            studentsPage.executeReadingCourse( studentUsernameFour, customSettingCourseReading, "85", "5", "35" );

            studentsPage.logout();
            chromeDriver.quit();
            
            //Navigate to teacher Dashboard after students took the test
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );
            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IP Level and Gain of Math assignment for student from Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( customSettingCourseMath );
            List<String> studentIPandGain = new ArrayList<String>();
            studentIPandGain = mathAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFour, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFour, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFour, "lastName" ) );

            // Getting IPLevel and Gain of Math assignment for student from Assignment API Page
            HashMap<String, HashMap<String, String>> studentIPandGainFromAPI = getStudentIPandGainFromAPI( SMUtils.getKeyValueFromResponse( studentDetailsFour, "userId" ) );
            HashMap<String, String> ipLevel = studentIPandGainFromAPI.get( Constants.IPLEVEL );
            HashMap<String, String> gain = studentIPandGainFromAPI.get( Constants.GAIN );

            //Matching the UI and API - IPLevel and Gain values for Math Assignment
            DecimalFormat decimalFormat = new DecimalFormat( "#0.00" );

            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( ipLevel.get( customSettingCourseMath ) ) ) );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( gain.get( customSettingCourseMath ) ) ) );
            Log.message( "UI Response:" + studentIPandGain.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGain.get( 1 ) );
            Log.assertThat( studentIPandGain.get( 0 ).equalsIgnoreCase( Constants.NOTAPPLICABLE ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( decimalFormat.format( Double.valueOf( gain.get( customSettingCourseMath ) ) ).equals( studentIPandGain.get( 1 ) ), "Gain for student is matched", "Gain is not matched" );

            teacherHomePage.topNavBar.signOutfromSM();
            

            //Navigate to teacher dashboard after student tooks the test 
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );
            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Reading assignment for student from Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( customSettingCourseReading );
            List<String> studentIPandGainReading = new ArrayList<String>();
            studentIPandGainReading = readingAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFour, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFour, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFour, "lastName" ) );

            //Matching the UI and API - IPLevel and Gain values for Reading Assignment
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( ipLevel.get( customSettingCourseReading ) ) ) );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( gain.get( customSettingCourseReading ) ) ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 1 ) );
            Log.assertThat( studentIPandGainReading.get( 0 ).equalsIgnoreCase( Constants.NOTAPPLICABLE ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( decimalFormat.format( Double.valueOf( gain.get( customSettingCourseReading ) ) ).equals( studentIPandGainReading.get( 1 ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(OFF) when student started few assignments but not completed", groups = { "SMK-46775", "AssignmentDetails",
            "IP and Gains" }, priority = 5 )
    public void tcSMAssignmentDetailsIPAndGain05() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAssignmentDetailsIPAndGain05: Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(OFF) when student started few assignments but not completed <small><b><i>[" + browser
                + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            //Executing Math assignments in student dashboard
    		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
    		
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUsernameFive, password );
            StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );

            studentsPage.executeMathCourse( studentUsernameFive, customSettingCourseMath, "85", "1", "1" );
            studentsPage.executeReadingCourse( studentUsernameFive, customSettingCourseReading, "75", "1", "1" );

            // SignOut from SM
            studentsPage.logout();
            chromeDriver.quit();
            //driver = WebDriverFactory.get( browser );

            //Navigate to teacher Dashboard after students took the test
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );

            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Math assignment for student from Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( customSettingCourseMath );
            List<String> studentIPandGain = new ArrayList<String>();
            studentIPandGain = mathAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFive, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFive, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFive, "lastName" ) );

            // Getting IPLevel and Gain of Math assignment for student from Assignment API Page 
            HashMap<String, HashMap<String, String>> studentIPandGainFromAPI = getStudentIPandGainFromAPI( SMUtils.getKeyValueFromResponse( studentDetailsFive, "userId" ) );
            HashMap<String, String> ipLevel = studentIPandGainFromAPI.get( Constants.IPLEVEL );
            HashMap<String, String> gain = studentIPandGainFromAPI.get( Constants.GAIN );

            //Matching the UI and API - IPLevel and Gain values for Math Assignment
            DecimalFormat decimalFormat = new DecimalFormat( "#0.00" );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( ipLevel.get( customSettingCourseMath ) ) ) );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( gain.get( customSettingCourseMath ) ) ) );
            Log.message( "UI Response:" + studentIPandGain.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGain.get( 1 ) );
            Log.assertThat( studentIPandGain.get( 0 ).equalsIgnoreCase( Constants.NOTAPPLICABLE ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( decimalFormat.format( Double.valueOf( gain.get( customSettingCourseMath ) ) ).equals( studentIPandGain.get( 1 ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

            //Navigate to teacher Dashboard after students took the test
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            teacherHomePage = new TeacherHomePage( driver );

            courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Reading assignment for student from Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( customSettingCourseReading );
            List<String> studentIPandGainReading = new ArrayList<String>();
            studentIPandGainReading = readingAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFive, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFive, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFive, "lastName" ) );

            //Matching the UI and API - IPLevel and Gain values for Reading Assignment
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( ipLevel.get( customSettingCourseReading ) ) ) );
            Log.message( "API Response:" + decimalFormat.format( Double.valueOf( gain.get( customSettingCourseReading ) ) ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 1 ) );
            Log.assertThat( studentIPandGainReading.get( 0 ).equalsIgnoreCase( Constants.NOTAPPLICABLE ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( decimalFormat.format( Double.valueOf( gain.get( customSettingCourseReading ) ) ).equals( studentIPandGainReading.get( 1 ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(OFF) when student does not started the assignment", groups = { "SMK-46775", "AssignmentDetails",
            "IP and Gains" }, priority = 6 )
    public void tcSMAssignmentDetailsIPAndGain06() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo(
                "tcSMAssignmentDetailsIPAndGain06: Verify the Gain Values for the Assignment having Default Courses (or) Custom course by settings + IP(OFF) when student does not started the assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Getting IPLevel and Gain of Math assignment for student from Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( customSettingCourseMath );
            List<String> studentIPandGain = new ArrayList<String>();
            studentIPandGain = mathAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFirst, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFirst, "lastName" ) );
            Log.assertThat( ( studentIPandGain.get( 0 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( ( studentIPandGain.get( 1 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "Gain for student is matched", "Gain is not matched" );

            // Getting IPLevel and Gain of Reading assignment for student from Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( customSettingCourseReading );
            List<String> studentIPandGainReading = new ArrayList<String>();
            studentIPandGainReading = readingAssignmentDetailsPage.getStudentIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetailsFirst, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetailsFirst, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetailsFirst, "lastName" ) );

            //Matching the UI and API - IP and Gain values for Reading Assignment
            Log.message( "UI Response:" + studentIPandGainReading.get( 0 ) );
            Log.message( "UI Response:" + studentIPandGainReading.get( 1 ) );
            Log.assertThat( ( studentIPandGainReading.get( 0 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "IP Level for student is matched", "IP Level is not matched" );
            Log.assertThat( ( studentIPandGainReading.get( 1 ).equalsIgnoreCase( Constants.BLANKVALUE ) ), "Gain for student is matched", "Gain is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public HashMap<String, HashMap<String, String>> getStudentIPandGainFromAPI( String studentID ) throws Exception {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentID );
        endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
        endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );

        HashMap<String, String> assignmentByStudent = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        Log.message( assignmentByStudent.toString() );
        // Getting list of IPLevel
        HashMap<String, String> ipLevel = new HashMap<String, String>();
        HashMap<String, String> gain = new HashMap<String, String>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent.get( Constants.REPORT_BODY ), Constants.ASSIGNMENTNAME ) ).forEach( index -> {
            String courseDetails = SMUtils.getKeyValueFromJsonArray( assignmentByStudent.get( Constants.REPORT_BODY ), "courseDetail", index );
            ipLevel.put( SMUtils.getKeyValueFromResponse( courseDetails, Constants.ASSIGNMENTNAME ), SMUtils.getKeyValueFromJsonArray( assignmentByStudent.get( Constants.REPORT_BODY ), "ipLevel", index ) );

            gain.put( SMUtils.getKeyValueFromResponse( courseDetails, Constants.ASSIGNMENTNAME ), SMUtils.getKeyValueFromJsonArray( assignmentByStudent.get( Constants.REPORT_BODY ), "gain", index ) );
        } );
        Log.message( "Verify the value" + ipLevel.toString() );

        HashMap<String, HashMap<String, String>> studentIPandGainFromAPI = new HashMap<String, HashMap<String, String>>();
        studentIPandGainFromAPI.put( Constants.IPLEVEL, ipLevel );
        studentIPandGainFromAPI.put( Constants.GAIN, gain );
        Log.message( "Verify the value" + studentIPandGainFromAPI.toString() );
        return studentIPandGainFromAPI;
    }
}
