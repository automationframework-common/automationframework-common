package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class test the Mastery Hierarchy view Integration UI testing.
 *
 * @author madhan.nagarathinam
 *
 */

@Listeners ( EmailReport.class )
public class MasteryHierarchyViewTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentUsername1 = null;
    private String studentUsername2 = null;
    String chromePlatform = "Windows_10_Chrome_latest";

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher79" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        studentUsername1 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" );
        studentUsername2 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" );
    }

    @Test ( priority = 1, description = "Datasetup for Mastery Hierarchy Integration view page" )
    public void tcMasteryDataSetup( ITestContext context ) throws Exception {
      //  WebDriver driver = null;
    	// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);  	//for simulator run
        Log.testCaseInfo( "Test Data generation for Mastery Details LO View Page." + "<small><b><i>[" + chromePlatform + "]</b></i></small>" );
        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Assigning Math Courses to Students
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Constants.MATH );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            //Assigning Reading Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Constants.READING );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            chromeDriver.quit();

            Log.message( "Executing the courses using simulator" );

            //Login as student1 to the executeCourses
            Log.message( "Executing the courses using simulator for student1" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername1, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.MATH, "100", "2", "20" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.READING, "100", "2", "20" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student2 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername2, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.MATH, "20", "5", "6" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.READING, "20", "3", "10" );
            studentsPage.logout();
            chromeDriver.quit();

        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        }

        finally {
            
            
            Log.endTestCase();
            chromeDriver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39461", "mastery", "masterySummary" } )
    public void tcMasteryHierarchy001( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            SMUtils.logDescriptionTC( "SMK-7435: Verify the selected values from Mastery filters are shown in the Filters section-Collapsed view " );
            SMUtils.logDescriptionTC( "SMK-7434: Verify the Mastery Filter section collapses after clicking on Apply Filter button" );
            Log.assertThat( !masteryFiltersComponent.isFilterExpanded(), "Mastery Filter section collapses after clicking on Apply filter button", "Mastery Filter section is not collapsed after clicking on Apply filter button!" );
            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5948: Verify the Mastery Data are getting loaded and collapse the Filters on clicking Apply Filter button" );
            SMUtils.logDescriptionTC( "SMK-5945: Verify the Mastery Data are getting loaded on clicking Apply Filter button for valid selection of Mastery Filters" );
            Log.assertThat( masterySummaryComponent.verifyGradeIsDisplayed(), "Mastery Data are getting loaded on clicking Apply Filter button for valid selection of Mastery Filters",
                    "Mastery Data is not getting loaded on clicking Apply Filter button for valid selection of Mastery Filters!" );
            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-7436: Verify the Collapsed Filter section can be expanded" );
            Log.assertThat( masteryFiltersComponent.isFilterExpandable(), "The collapse Filter can be expandable", "The collapse Filter is not getting expandable!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5949: Verify user is able to expand collapsed Filters and change options to load a new mastery view" );
            Log.assertThat( masteryFiltersComponent.isFilterExpanded(), "The collpased filter gets expanded", "The collpased filter is not getting expanded!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5946: Verify the Reset button functionality" );
            masteryFiltersComponent.resetFilter();
            Log.assertThat( masteryFiltersComponent.isGroupsChecked(), "After clicking the reset, the values got resetted ", "After clicking the reset button, the values are not getting resetted!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-7437: Verify the applied filters can be modified" );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            masteryFiltersComponent.applyFilter();
            Log.assertThat( masterySummaryComponent.verifyGradeIsDisplayed(), "The applied filters are modified", "The applied filter are not modified!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-7438: Verify LO Number & hotlink to preview in LO viewer is displayed for SuccessMaker Mastery Skills - Math" );
            Log.assertThat( !masterySummaryComponent.getLinkOfLeafNodeLO().isEmpty(), "LO Number & hotlink to preview is displayed for SuccessMaker Mastery Skills - Math",
                    "LO Number & hotlink to preview is not getting displayed for SuccessMaker Mastery Skills - Math" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5951: Verify LO view link is present only for SuccessMaker Mastery Skills - Math skill/standard" );
            Log.assertThat( masterySummaryComponent.verifyLOColor( browser ), "Teacher is able to see the LO as a blue link", "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 1, groups = { "SMK-39461", "mastery", "masterySummary" } )
    public void tcMasteryHierarchy002( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            SMUtils.logDescriptionTC( "SMK-7441: Verify the detailed mastery status link is available next to the progress bar" );
            Log.assertThat( !masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).isEmpty(), "The detailed Mastery status link is available next to the progress bar",
                    "The detailed Mastery status link is not available next to the progress bar!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5952: Verify the number of students mastery status and progress bar is displaying for each skill/standard" );
            SMUtils.logDescriptionTC( "SMK-7440: Verify the number of students mastery status is displaying for each skill/standard" );
            Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( studentCount -> !studentCount.isEmpty() ), "The number of students mastery status is displaying for each skill/standard",
                    "The number of students mastery status is not getting displayed for each skill/standard" );
            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-7439: Verify the progress bar is displayed for the skill/standards avaialble" );
            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            Log.assertThat( !masteredProgressBars.isEmpty(), "Progress bar is getting displayed for the skills/standards available", "Progress bar is not getting displayed for the skills/standards available!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5953: Verify the first-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill" );
            SMUtils.logDescriptionTC( "SMK-5955: Verify the progress bar gets collapsed when collapsing first-level Strand for Subject -Math and Default Math Skill" );

            masterySummaryComponent.clickFirstLevelStrandName();
            Log.assertThat( !masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking collapse btn on First level strandName, the progress bar is collapsed",
                    "After Clicking collapse btn on First level strandName, the progress bar is not getting collapsed!" );

            masterySummaryComponent.clickFirstLevelStrandName();
            Log.assertThat( masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking Expand btn on First level strandName, the progress bar gets displayed",
                    "After Clicking collapse btn on First level strandName, the progress bar is not getting displayed!" );

            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5954: Verify the second-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill" );
            SMUtils.logDescriptionTC( "SMK-5956: Verify the progress bar gets collapsed when collapsing second-level Strand for Subject -Math and Default Math Skill" );

            masterySummaryComponent.clickSecondLevelStrandName();
            Log.assertThat( !masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking collapse btn on second level strandName, the progress bar is collapsed",
                    "After Clicking collapse btn on second level strandName, the progress bar is not getting collapsed!" );

            masterySummaryComponent.clickSecondLevelStrandName();
            Log.assertThat( masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking Expand btn on second level strandName, the progress bar gets displayed",
                    "After Clicking collapse btn on second level strandName, the progress bar is not getting displayed!" );

            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 1, groups = { "SMK-39461", "mastery", "masterySummary" } )
    public void tcMasteryHierarchy003( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            SMUtils.logDescriptionTC( "SMK-5957: Verify the first-level Strand can be expanded and collapsed for Subject -Reading" );
            SMUtils.logDescriptionTC( "SMK-5958: Verify the progress bar gets collapsed when collapsing first-level Strand for Subject -Reading" );

            masterySummaryComponent.clickFirstLevelStrandName();
            Log.assertThat( !masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking collapse btn on First level strandName, the progress bar is collapsed",
                    "After Clicking collapse btn on First level strandName, the progress bar is not getting collapsed!" );

            masterySummaryComponent.clickFirstLevelStrandName();
            Log.assertThat( masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking Expand btn on First level strandName, the progress bar gets displayed",
                    "After Clicking collapse btn on First level strandName, the progress bar is not getting displayed!" );

            Log.testCaseResult();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }
}