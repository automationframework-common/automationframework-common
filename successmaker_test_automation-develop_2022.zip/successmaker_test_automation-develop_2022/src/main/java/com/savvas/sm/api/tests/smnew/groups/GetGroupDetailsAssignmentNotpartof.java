package com.savvas.sm.api.tests.smnew.groups;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.ethnicity;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.gender;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasDisability;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.isMigrant;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.specialServices;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.SharedCourseTeacherAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

/**
 * To test the GetGroupDetailsAssignmentNotpartof API
 * 
 * @author nishanth.kamaraj
 *
 */
public class GetGroupDetailsAssignmentNotpartof extends GroupAPI {

	private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String teacherDetails = null;
	private String teacherDetails2 = null;
	private String studentID1T1 = null;
	private String firstTeacherId = null;
	private String teacherAccessToken;
	private String teacherUsername;

	String studentId;
	String studentID;
	String secondStudentId;
	String thirdStudentId;
	String CourseId;

	String studentUsed1T1;
	String studentUsed2T1;
	String studentUsed3T1;
	String studentUsed4T1;
	String studentUsed5T1;

	String studentUsed1T2;
	String studentUsed2T2;
	String studentUsed3T2;
	String studentUsed4T2;
	String studentUsed5T2;

	String studentID2T1;
	String studentID3T1;
	String studentID4T1;
	String studentID5T1;

	String studentID1T2;
	String studentID2T2;
	String studentID3T2;
	String studentID4T2;
	String studentID5T2;

	String student1Username;
	String secondTeacherId;
	RBSUtils rbs = new RBSUtils();

	//
	String orgId;
	String teacherId;
	//
	private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
	private String school2 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();
	private List<String> courseIDs = new ArrayList<>();
	HashMap<String, String> groupDetails = new HashMap<>();



	@BeforeClass(alwaysRun = true)
	public void BeforeTest() throws Exception {
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

		teacherDetails = RBSDataSetup.getMyTeacher( school );
		teacherDetails2 = RBSDataSetup.getMyTeacher( school );

		firstTeacherId = SMUtils.getKeyValueFromResponse(teacherDetails, Constants.USERID_HEADER);
		secondTeacherId = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );

		teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
		teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

		studentUsed1T1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
		studentUsed2T1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
		studentUsed3T1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
		studentUsed4T1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
		studentUsed5T1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );

		studentUsed1T2 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
		studentUsed2T2 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
		studentUsed3T2 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
		studentUsed4T2 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
		studentUsed5T2 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );

		studentID1T1 = SMUtils.getKeyValueFromResponse( studentUsed1T1, Constants.USERID_HEADER );
		studentID2T1 = SMUtils.getKeyValueFromResponse( studentUsed2T1, Constants.USERID_HEADER );
		studentID3T1 = SMUtils.getKeyValueFromResponse( studentUsed3T1, Constants.USERID_HEADER );
		studentID4T1 = SMUtils.getKeyValueFromResponse( studentUsed4T1, Constants.USERID_HEADER );
		studentID5T1 = SMUtils.getKeyValueFromResponse( studentUsed5T1, Constants.USERID_HEADER );

		student1Username = SMUtils.getKeyValueFromResponse( studentUsed2T1, Constants.USER_NAME );

		studentID1T2 = SMUtils.getKeyValueFromResponse( studentUsed1T2, Constants.USERID_HEADER );
		studentID2T2 = SMUtils.getKeyValueFromResponse( studentUsed2T2, Constants.USERID_HEADER );
		studentID3T2 = SMUtils.getKeyValueFromResponse( studentUsed3T2, Constants.USERID_HEADER );
		studentID4T2 = SMUtils.getKeyValueFromResponse( studentUsed4T2, Constants.USERID_HEADER );
		studentID5T2 = SMUtils.getKeyValueFromResponse( studentUsed5T2, Constants.USERID_HEADER );
	}

	/**
	 * Tests the positive scenarios of create group.
	 * 
	 * @param description
	 * @param scenario
	 * @param statusCode
	 * @throws Exception
	 */
	@Test ( dataProvider = "GroupNotPartOfAssignmentPositiveScenariosData", groups = { "SMK-52243", "Group", "smoke_test_case","GroupNotPartOfAssignment_TC01", "GroupNotPartOfAssignment", "P1", "API" } )
	public void tcGroupNotPartOfAssignment001( String description, String scenario, String statusCode ) throws Exception {
		Log.testCaseInfo( description );
		HashMap<String, String> groupDetails = new HashMap<>();
		HashMap<String, String> studentDetails = new HashMap<String, String>();
		HashMap<String, String> viewGroupDetails = new HashMap<String, String>();
		List<String> studentRumbaIds = new ArrayList<>();

		HashMap<String, String> userDetails = new HashMap<>();
		HashMap<String, String> createStudentResponse = new HashMap<>();
		List<String> schools = new ArrayList<>();
		String groupName = "Successmaker API Test Group " + System.nanoTime();
		boolean withStudent = false;
		String multiSchoolTeacher = null;
		String specialCharacter = "Test" + System.nanoTime();
		List<String> courseIDs = new ArrayList<>();
		String token = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
		String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
		String teacherId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERID );

		switch ( scenario ) {
		case "GROUP WITHOUT STUDENT":
			Log.testCaseInfo( "Verify the response when the group don't have any students." );
			Log.testCaseInfo( "Verify the response when there is multiple groups." );
			Log.testCaseInfo( "Verify the response returning group ID value properly" );
			Log.testCaseInfo( "Verify the response returning groupName value properly" );
			Log.testCaseInfo( "Verify the response returning studentCount value properly" );

			//String accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
			studentRumbaIds.add(studentID1T1);

			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			HashMap<String, String> response = createGroup( smUrl, groupDetails, studentRumbaIds );

			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			HashMap<String, String> empresponse = createGroup( smUrl, groupDetails, studentRumbaIds );
			String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
			String empgroupId = SMUtils.getKeyValueFromResponse( empresponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

			new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

			// Assigning Math Assignment
			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, firstTeacherId );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,teacherAccessToken );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_MATH_ID );
			//                HashMap<String, String> assignAssignment = assign.assignMultipleAssignments(smUrl, assignmentDetails, studentRumbaIds, Arrays.asList("0"));
			HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );
			break;

		case "DELETE ASSIGNMENT GROUP":

			Log.testCaseInfo( "Verify the status code, when the assignment has been deleted as already" );

			studentRumbaIds.add( studentID2T1 );
			studentRumbaIds.add( studentID3T1 );

			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			response = createGroup( smUrl, groupDetails, studentRumbaIds );
			String removeAssignmentGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
			new RBSUtils().addProduct( removeAssignmentGroupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

			CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.STANDARD,
					String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
			assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( removeAssignmentGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

			new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, CourseAPIConstants.NULL );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );
			break;

		case "SHARED GROUP":

			Log.testCaseInfo( "Verify the student details are not repeated in the API response(There should not be duplicate entries" );

			String className1 = "Customize Shared Group " + System.currentTimeMillis();

			List<String> teachers = new ArrayList<String>();
			teachers.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			teachers.add( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERID ) );

			List<String> stuIDs = new ArrayList<String>();

			studentRumbaIds.add( studentID4T1 );

			// group created with Third party application
			groupDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
			groupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( RBSDataSetupConstants.SECTION_NAME, className1 );
			groupDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studentID4T1 );

			String createClassWithMultipleTeacher1 = rbs.createClassWithMultipleTeacher( groupDetails, teachers, studentRumbaIds );
			JSONObject jsonnObject2 = new JSONObject( createClassWithMultipleTeacher1 );
			String classId2 = jsonnObject2.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( CreateGroupAPIConstants.SECTION ).get( CreateGroupAPIConstants.ID ).toString();

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );

			withStudent = true;

			break;

		case "SHARED STUDENT GROUP":

			String className2 = "Customize Shared Group " + System.currentTimeMillis();

			teachers = new ArrayList<String>();
			teachers.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			teachers.add( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERID ) );

			String sharedStudentID = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

			studentRumbaIds.add( studentID5T1 );

			// group created with Third party application
			groupDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
			groupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( RBSDataSetupConstants.SECTION_NAME, className2 );
			groupDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studentID5T1 );

			String createClassWithMultipleTeacher2 = rbs.createClassWithMultipleTeacher( groupDetails, teachers, studentRumbaIds );
			JSONObject jsonnObject3 = new JSONObject( createClassWithMultipleTeacher2 );
			String classId3 = jsonnObject3.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( CreateGroupAPIConstants.SECTION ).get( CreateGroupAPIConstants.ID ).toString();
			new RBSUtils().addProduct( classId3, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_MATH_ID );

			HashMap<String, String> assignAssignment1 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( classId3 ), AssignmentAPIConstants.GROUPS_TYPE );
			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.FOCUS_READING_ID );

			withStudent = true;

			break;

		case "REMOVE STUDENT FROM GROUP":
			Log.testCaseInfo( "Verify the response when the course assigned to partial students from the group." );

			studentRumbaIds.add( studentID1T2 );
			studentRumbaIds.add( studentID2T2 );
			studentRumbaIds.add( studentID3T2 );

			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			response = createGroup( smUrl, groupDetails, studentRumbaIds );

			String removeStudGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
			new RBSUtils().addProduct( removeStudGroup, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_MATH_ID );

			HashMap<String, String> assignAssignment3 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( removeStudGroup ), AssignmentAPIConstants.GROUPS_TYPE );
			new GroupAPI().removeStudentFromGroup( smUrl, studentId, removeStudGroup, teacherId, RBSDataSetup.organizationIDs.get( school ), token );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );
			withStudent = true;

			break;

		case "MULTIPLE COURSE GROUP":

			Log.testCaseInfo( "Verify the response when the course is custom course" );
			Log.testCaseInfo( "Verify the response when the course is default course." );
			Log.testCaseInfo( "Verify the response when the course is focus course" );

			studentRumbaIds.add( studentID4T1 );

			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			response = createGroup( smUrl, groupDetails, studentRumbaIds );

			String grpWithMultiCourse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

			//CREATING COURSES
			String math_settings = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SETTINGS,
					String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

			String math_skill = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SKILL,
					String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
			String math_standard = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.STANDARD,
					String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

			String reading_settings = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SETTINGS,
					String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
			String reading_skill = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SKILL,
					String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
			String reading_standard = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.STANDARD,
					String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

			courseIDs.add( math_settings );
			courseIDs.add( math_skill );
			courseIDs.add( math_standard );
			courseIDs.add( reading_settings );
			courseIDs.add( reading_skill );
			courseIDs.add( reading_standard );
			courseIDs.add( AssignmentAPIConstants.MATH );
			courseIDs.add( AssignmentAPIConstants.FOCUS_MATH );

			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			Log.message( "Assignment Details - " + new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs ) );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );
			withStudent = true;

			break;
		case "SHARED_COURSE_CREATED_BY_MULTIPLE_SCHOOL_TEACHER":
			Log.testCaseInfo( "Verify the response when the course is shared by district level. " );

			className1 = "Custom Group " + System.currentTimeMillis();
			//create multiple school teacher
			String multiSchoolTeachersm = "MultiSchTeacher" + System.nanoTime();
			userDetails = new HashMap<>();
			userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
			userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeachersm );
			userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

			schools = new ArrayList<String>();
			schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
			schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
			String listString = "";
			for ( String school : schools ) {
				listString += school.concat( "\",\"" );
			}
			listString = listString.substring( 0, listString.length() - 3 );
			userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
			String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

			//create course for multiple school teacher
			String courseIdByMultipleSchoolTeacher = new SharedCourseTeacherAPI().createSharedCourse( smUrl, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH,
					multipleSchoolTeacherID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), DataSetupConstants.SETTINGS, "Shared Math course" + System.nanoTime() );

			studentRumbaIds.add( studentID1T1 );
			studentRumbaIds.add( studentID2T1 );

			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			response = createGroup( smUrl, groupDetails, studentRumbaIds );

			String MultiOrgGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
			new RBSUtils().addProduct( MultiOrgGroup, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseIdByMultipleSchoolTeacher );

			HashMap<String, String> assignAssignment4 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( MultiOrgGroup ), AssignmentAPIConstants.GROUPS_TYPE );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );
			withStudent = true;

			break;
		}
		HashMap<String, String> response = getGroupDetailsAssignmentNotPartOfGrp( smUrl, viewGroupDetails );
		Log.message( "response" + response );
		Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
		Log.assertThat( ValidateGroupWithDB( response ), "Validated with the DB and All fields Matched", "Fields not matched with DB" );
		Log.testCaseResult();
	}

	/**
	 * Data provider for positive scenarios
	 * 
	 * @return
	 */

	@DataProvider ( name = "GroupNotPartOfAssignmentPositiveScenariosData" )
	public Object[][] createGroupData() {

		Object[][] inputData = { { "Verify the 200 response code and response body for valid data.", "GROUP WITHOUT STUDENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the response when the shared group", "SHARED GROUP", CommonAPIConstants.STATUS_CODE_OK }, 
				{ "Verify the response when the group having shared students.", "SHARED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the status code, when one of the student removed from the group which was mapped against assignment ", "REMOVE STUDENT FROM GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the status code, when the assignment has been deleted as already", "DELETE ASSIGNMENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the response when the group already have the same assignment. ", "MULTIPLE COURSE GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the response when the teacher from multiple schools. ", "SHARED_COURSE_CREATED_BY_MULTIPLE_SCHOOL_TEACHER", CommonAPIConstants.STATUS_CODE_OK },

		};
		return inputData;
	}

	/**
	 * To test the negative scenarios of create group API
	 * 
	 * @param description
	 * @param scenario
	 * @param statusCode
	 * @throws Exception
	 */
	@Test ( dataProvider = "GroupNotPartOfAssignmentNegativeScenariosData", groups = { "SMK-52243", "Group", "GroupNotPartOfAssignment", "P2", "API" } )
	public void tcGroupNotPartOfAssignment002( String description, String scenario, String statusCode ) throws Exception {

		Log.testCaseInfo( description );
		HashMap<String, String> groupDetails = new HashMap<>();
		HashMap<String, String> viewGroupDetails = new HashMap<>();
		List<String> studentRumbaIds = new ArrayList<>();
		String groupName = "Successmaker API Test Group " + System.nanoTime();
		String exception = null;
		boolean status = false;
		String message = null;

		switch ( scenario ) {

		case "INVALID ORGANIZATION":
			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_MATH_ID );
			viewGroupDetails.put( GroupConstants.INVALID_ORG, getGroupListAPIConstants.INVALID_INPUT );

			exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			message = CreateGroupAPIConstants.INVALID_ORGID_MESSAGE2;
			status = true;
			break;

		case "INVALID TEACHER":
			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_MATH_ID );
			viewGroupDetails.put( GroupConstants.INVALID_ORG, getGroupListAPIConstants.INVALID_INPUT );

			exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			message = CreateGroupAPIConstants.INVALID_ORGID_MESSAGE2;
			status = true;
			break;

		case "INVALID COURSE ID":
			Log.testCaseInfo( "Verify the status code, when the assignment id is text input" );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.INVALID_COURSE_ID, getGroupListAPIConstants.INVALID_INPUT );

			exception = CommonAPIConstants.METHO_ANNOTATION_EXP;
			message = CommonAPIConstants.INVALID_COURSEID_EXP;
			status = true;
			break;

		case "EMPTY COURSE ID":
			Log.testCaseInfo( "Verify the status code, when the assignment id is EMPTY input" );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.INVALID_COURSE_ID, CreateGroupAPIConstants.EMPTY_VALUE );

			exception = CommonAPIConstants.NULL_EXCEPTION;
			message = CommonAPIConstants.EMPTY_COURSEID_EXP;
			status = true;
			break;

		case "STUDENT AUTHORIZATION":

			studentRumbaIds.add( studentID2T1 );
			studentRumbaIds.add( studentID3T1 );
			studentRumbaIds.add( studentID4T1 );
			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( student1Username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, studentID2T1 );
			viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_MATH_ID );
			exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
			message = CommonAPIConstants.FORBIDDAN_MESSAGE;
			status = true;
			break;

		case "INVALID TOKEN":
			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_MATH_ID );

			exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
			message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
			status = true;
			break;

		case "OTHER ORG TEACHER":
			studentRumbaIds.add( studentID1T1 );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			HashMap<String, String> createGroup = createGroup( smUrl, groupDetails, studentRumbaIds );
			String removeAssignmentGroupId = SMUtils.getKeyValueFromResponse( createGroup.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
			new RBSUtils().addProduct( removeAssignmentGroupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school2 ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_MATH_ID );

			exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
			message = CommonAPIConstants.FORBIDDAN_MESSAGE;
			status = true;
			break;

		case "NO GROUPS":
			Log.testCaseInfo( "Verify the response when there is no groups for the teacher." );
			viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERID ) );
			viewGroupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school2 ) );
			viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_MATH_ID );

			exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
			message = CommonAPIConstants.FORBIDDAN_MESSAGE;
			status = true;
			break;

		}

		HashMap<String, String> response = getGroupDetailsAssignmentNotPartOfGrp( smUrl, viewGroupDetails );
		Log.message( "response" + response );
		Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
		Log.message( "Response: " + response.get( Constants.REPORT_BODY ) );
		verifyException( response.get( Constants.REPORT_BODY ), exception, status, message );

		Log.message( "actexception:" + exception );
		Log.message( "actmessage:" + message );
		Log.testCaseResult();
	}

	/**
	 * Data provider to give the data of negative scenarios
	 * 
	 * @return
	 */
	@DataProvider ( name = "GroupNotPartOfAssignmentNegativeScenariosData" )
	public Object[][] createGroupDataInvalid() {

		//Commented cases are has future backlog tickets since its excluded from execution
		Object[][] inputData = { { "Verify the response when the organization id is invalid and teacher ID and course ID is valid", "INVALID ORGANIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the response when the teacher id is invalid, organization is valid and course ID is valid.", "INVALID TEACHER", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the response when the course ID is invalid, org ID and teacher ID is valid.", "INVALID COURSE ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the 403 response code and response body for valid data with student credentials.", "STUDENT AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
				{ "Verify the status code 401 against invalid token in Assignment API", "INVALID TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
				{ "Verify the response when the teacher is in other organization.", "OTHER ORG TEACHER", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
				{ "Verify the response when there is no groups in organization.", "NO GROUPS", CommonAPIConstants.STATUS_CODE_FORBIDDAN }, { "Verify the status code, when the assignment id is blank", "EMPTY COURSE ID", CommonAPIConstants.STATUS_EMPTY },

		};
		return inputData;
	}

	/**
	 * bulk data test
	 * 
	 * @throws Exception
	 */
	@Test ( groups = { "SMK-52243", "Group","smoke_test_case", "GroupNotPartOfAssignment_TC02","GroupNotPartOfAssignment", "P2", "API" } )
	public void tcGroupNotPartOfAssignment003() throws Exception {

		Log.testCaseInfo( "Verify the group created with 100 students IDs" );

		HashMap<String, String> groupDetails = new HashMap<>();
		HashMap<String, String> viewGroupDetails = new HashMap<>();
		List<String> studentRumbaIds = new ArrayList<>();

		IntStream.rangeClosed( 1, 100 ).forEach( student -> {
			HashMap<String, String> userDetails = new HashMap<>();
			String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
			userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
			userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
			userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
			userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
			String multiSchoolStudentID = null;
			try {
				multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
				Log.message( "Student " + student + " - " + multiSchoolStudentID );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			studentRumbaIds.add( multiSchoolStudentID );
		} );
		String groupName = "Successmaker API Test Group " + System.nanoTime();
		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
		HashMap<String, String> response = createGroup( smUrl, groupDetails, studentRumbaIds );
		Log.message( "Response:" + response );
		String MultiOrgGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
		new RBSUtils().addProduct( MultiOrgGroup, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

		assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
		assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
		assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_MATH_ID );

		HashMap<String, String> assignAssignment4 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( MultiOrgGroup ), AssignmentAPIConstants.GROUPS_TYPE );

		viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
		viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
		viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		viewGroupDetails.put( GroupConstants.COURSE_ID_ENDPOINT, Constants.DEFAULT_READING_ID );

		response = getGroupDetailsAssignmentNotPartOfGrp( smUrl, viewGroupDetails );
		Log.message( "response" + response );
		Log.assertThat( ValidateGroupWithDB( response ), "Validated with the DB and All fields Matched", "Fields not matched with DB" );
		Log.testCaseResult();
	}

	/**
	 * This methods will update the details whatever given in Key and value
	 * 
	 * @param studentDetails
	 * @param key
	 * @param value
	 * @return
	 */
	public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
		HashMap<String, String> generatedStudentDetails = studentDetails;
		if ( generatedStudentDetails.containsKey( key ) ) {
			generatedStudentDetails.put( key, value );
		} else {
			generatedStudentDetails.put( key, value );
		}
		return generatedStudentDetails;
	}

	public Boolean ValidateGroupWithDB( HashMap<String, String> response ) throws Exception {
		HashMap<String, String> groupDetails = new HashMap<>();
		List<String> studentCountValueAct = new ArrayList<>();
		JSONObject userJsonObjectAct = new JSONObject( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
		JSONArray jsonArray = userJsonObjectAct.getJSONArray( "data" );
		for ( int i = 0; i < jsonArray.length(); i++ ) {
			JSONObject jobj = jsonArray.getJSONObject( i );
			String studentCountValueActual = new SMAPIProcessor().getKeyValues( jobj, StudentDetailsForStudentIdAPIConstants.STUDENT_COUNT ).toString();
			studentCountValueActual = studentCountValueActual.replaceAll( "\\[", "" ).replaceAll( "\\]", "" );
			studentCountValueAct.add( studentCountValueActual );
		}

		//studentCountValueAct = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.STUDENT_COUNT_DATAVALUE );
		Log.message( "studentactcount:" + studentCountValueAct );

		List<String> courseIds = new ArrayList<String>();

		//int count = 5;
		Boolean status = false;
		List<String> groupIdsFromResponse = new ArrayList<String>();
		jsonArray = userJsonObjectAct.getJSONArray( "data" );
		for ( int i = 0; i < jsonArray.length(); i++ ) {
			JSONObject jobj = jsonArray.getJSONObject( i );
			String groupIds = new SMAPIProcessor().getKeyValues( jobj, StudentDetailsForGivenTeacherConstants.GROUP_ID ).toString();
			groupIds = groupIds.replaceAll( "\\[", "" ).replaceAll( "\\]", "" );
			groupIdsFromResponse.add( groupIds );
		}
		String course = Constants.DEFAULT_READING_ID;

		//SqlHelperUsage helperPage = new SqlHelperUsage();
		//List<String> expecGrps = new ArrayList<String>();
		for ( String eachGrp : groupIdsFromResponse ) {
			courseIds = getgroupDetails( eachGrp );

			for ( String eachCourse : courseIds ) {
				if ( course.equalsIgnoreCase( eachCourse ) ) {
					Log.fail( "Already Assigned Group for given course id is showing in the UI" );
				} else {
					status = true;
				}
			}
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, eachGrp );
			HashMap<String, String> studentDetailsforGroup = getStudentDetailsforGroup( smUrl, groupDetails );

			JSONObject userJsonObjectExp = new JSONObject( studentDetailsforGroup.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
			List<String> studentIdActValue = new ArrayList<String>();
			jsonArray = userJsonObjectExp.getJSONArray( "data" );
			for ( int i = 0; i < jsonArray.length(); i++ ) {
				JSONObject jobj = jsonArray.getJSONObject( i );
				String studentIds = new SMAPIProcessor().getKeyValues( jobj, StudentDetailsForStudentIdAPIConstants.ID_STUDENT ).toString();
				studentIds = studentIds.replaceAll( "\\[", "" ).replaceAll( "\\]", "" );
				studentIdActValue.add( studentIds );
			}
			//studentIdActValue = new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.ID_STUDENT );

			for ( String eachStudent : studentIdActValue ) {
				courseIds = getStudentAssignmentDetails( eachStudent );
				for ( String eachCourse : courseIds ) {
					if ( course.equalsIgnoreCase( eachCourse ) ) {
						studentIdActValue.remove( eachStudent );
					} else {
						status = true;
					}
				}

				int size = studentIdActValue.size();
				Log.message( "expstudcount:" + size );
				for ( String eachGrpstudCount : studentCountValueAct ) {
					int parseInt = Integer.parseInt( eachGrpstudCount );
					if ( size == parseInt ) {
						status = true;
					} else {
						status = false;
					}
				}
			}
		}
		return status;
	}

	/**
	 * This method used to generate the intial values for the request
	 * 
	 * @param studentDetails
	 * @param key
	 * @param value
	 * @return
	 */
	public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
		HashMap<String, String> generatedStudentDetails = studentDetails;
		generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
		generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
		generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
		generatedStudentDetails.put( CreateStudentAPIConstants.GRADE, grade.FIRST.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
		generatedStudentDetails.put( CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
		generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
		generatedStudentDetails.put( CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
		generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.NOT_HISPANIC_OR_LATINO.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
		generatedStudentDetails.put( GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, gender.FEMALE.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
		return generatedStudentDetails;
	}

}
