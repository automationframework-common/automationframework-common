package com.savvas.sm.api.tests.smnew.users;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.ethnicity;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.gender;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasDisability;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.isMigrant;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.specialServices;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class CreateStudentAPITest extends UserAPI {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String teacherDetails = null;
	private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() {
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		teacherDetails = RBSDataSetup.getMyTeacher( school );
	}

	@Test ( dataProvider = "createStudentPositiveTestData", groups = { "SMK-52010", "smoke_test_case", "Smoke_CreateStudent_TC01", "User", "Create Student", "P1", "API" } )
	public void tcCreateStudentPositive001( String description, String scenario, String statusCode ) throws Exception {

		Log.testCaseInfo( description );
		HashMap<String, String> studentDetails = new HashMap<String, String>();
		HashMap<String, String> userDetails = new HashMap<String, String>();
		List<String> schools = new ArrayList<>();

		switch ( scenario ) {
		case "HAPPY PATH":
			Log.testCaseInfo("Verify the teacher can create the multiple students.");
			Log.testCaseInfo("Verify the student created in SM, reflectes in CMS with proper details.");
			Log.testCaseInfo("Verify the teacher can able to create the student who does not belongs to any group(Orphan student).");
			Log.testCaseInfo("Verify the students details are returned in response When given  the valid student details in request body  for teacher API.");
			Log.testCaseInfo("Verify the request body have valid user name for create student API");
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			break;

		case "MULTIPLE SCHOOL TEACHER":
			String multiSchoolTeacher = "MultiSchoolsTeacher" + System.nanoTime();
			userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
			userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
			userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

			List<String> multiTecSchools = new ArrayList<>();
			multiTecSchools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
			multiTecSchools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
			String listString = "";
			for ( String school : multiTecSchools ) {
				listString += school.concat( "\",\"" );
			}
			listString = listString.substring( 0, listString.length() - 3 );
			Log.message("FinalOrgIDList is --> " + listString);
			userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
			String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD )) ;
			break;

		case "GOOGLE CLASS TEACHER":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, CreateStudentAPIConstants.GOOGLE_SCHOOL_ORG_ID  );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, CreateStudentAPIConstants.GOOGLE_TEACHER_ID  );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(CreateStudentAPIConstants.GOOGLE_USERNAME , RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			break;
			// User Service API doesn't response Middle name field when creating a student without a middle name
		case "WITHOUT_MIDDLENAME":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.MIDDLENAME, "" );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			break;

		case "SPECIAL CHARACTER":
			String specialCharacter = "*&%#Test" + System.nanoTime();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.FIRSTNAME, "FN" + specialCharacter );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.MIDDLENAME, "M" );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.LASTNAME, "LN" + specialCharacter );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.USERNAME, "UN" + specialCharacter );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, "ID" + specialCharacter );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			break;

		case "SAME STUDENT ID USERNAME":
			String sameName = "SM_BASIC_STU" + System.nanoTime();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.USERNAME, sameName );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, sameName );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			break;

		case "EMPTY NON MANDATORY FIELD":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			break;

		case "NOT_SPECIFIED_DEMOGRAPHICS":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ETHINICITY, ethnicity.NOT_SPECIFIED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.NOT_SPECIFIED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.NOT_SPECIFIED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.NOT_SPECIFIED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.NOT_SPECIFIED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ISMIGRANT, isMigrant.NOT_SPECIFIED.toString() );
			break;

		case "ALL_DEMOGRAPHICS":
			SMUtils.logDescriptionTC("Verifing All the demographic values ");
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
//			Log.testCaseResult();
			break;

		}
		HashMap<String, String> apiResponse = createStudent( smUrl, studentDetails );
		String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
		Log.message( cmsResponse );
		cmsResponse= cmsResponse.replace("migrantStatus", "isMigrant");
		cmsResponse= cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
		cmsResponse= cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
		cmsResponse= cmsResponse.replace("disabilityStatus", "hasDisability");

		Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
				"Issue in returning status code! Expected - " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

		Log.message("Create Student API Response: " + apiResponse);
		Log.message("Create Student API Response: " + cmsResponse);

		if (scenario.equals( "WITHOUT_MIDDLENAME")) {
			verifyResponseMiddleName(apiResponse.get( Constants.BODY ));

		} else {
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
		}
		Log.assertThat( new SMAPIProcessor().isSchemaValid( "createStudentAPISchema", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

		Log.testCaseResult();
	}

	@DataProvider ( name = "createStudentPositiveTestData" )
	public Object[][] createStudentPositive() {

		Object[][] inputData = { 
				{ "Verify the teacher can create the student with valid input", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
				//				{ "Verify the teacher can create the multiple students.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the student created in given school when the teacher is part of multiple schools.", "MULTIPLE SCHOOL TEACHER", CommonAPIConstants.STATUS_CODE_CREATED },
				//				{ "Verify the student created in SM, reflectes in CMS with proper details.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
				//				{ "Verify the teacher can able to create the student who does not belongs to any group(Orphan student).", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the Google class room teacher can able to create student in Successmaker.", "GOOGLE CLASS TEACHER", CommonAPIConstants.STATUS_CODE_CREATED },
				//				{ "Verify the students details are returned in response When given  the valid student details in request body  for teacher API.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
				//				{ "Verify the request body have valid user name for create student API", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the student details listed correctly when the student don't have middlename for create student API.", "WITHOUT_MIDDLENAME", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the student details when student firstname and lastname has special character for create student API.", "SPECIAL CHARACTER", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the response when studentidentification id value as student username", "SAME STUDENT ID USERNAME", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the student is not creating in multiple schools when the teacher is part of multiple school.", "MULTIPLE SCHOOL TEACHER", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify the API creating the students when the non-mandatory fields are empty", "EMPTY NON MANDATORY FIELD", CommonAPIConstants.STATUS_CODE_CREATED },
				{ "Verify all the demographic fields", "ALL_DEMOGRAPHICS", CommonAPIConstants.STATUS_CODE_CREATED },
				{ " Verify the students are getting created with 'Not_Specified' demographics values", "NOT_SPECIFIED_DEMOGRAPHICS", CommonAPIConstants.STATUS_CODE_CREATED } };
		return inputData;
	}

	@Test ( groups = { "SMK-52010", "User", "smoke_test_case", "Create_Student_TC02",   "Create Student", "P1", "API" } )
	public void tcCreateStudentPositive003() throws Exception {
		Log.testCaseInfo( "Demographics test" );
		verifyDemographicsTest();
		Log.testCaseResult();
	}


	@Test ( groups = { "SMK-52010", "User","smoke_test_case","Smoke_CreateStudent_TC02", "Create Student", "P1", "API" } )
	public void tcCreateStudentPositive002() throws Exception {

		Log.testCaseInfo( "Grade values Test" );
		HashMap<String, String> gradeMapping = new HashMap<>();



		IntStream.range( 0, Arrays.asList( grade.values() ).size() ).forEach( gradeValue -> {
			gradeMapping.put( Arrays.asList( grade.values() ).get( gradeValue ).toString(), CreateStudentAPIConstants.GRADE_CODES_CMS.get( gradeValue ) );
		} );

		Arrays.asList( grade.values() ).forEach( gradeValue -> {

			HashMap<String, String> apiResponse = new HashMap<>();

			HashMap<String, String> studentDetails = new HashMap<String, String>();

			List<String> personIDs = new ArrayList<>();

			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.GRADE, gradeValue.toString() );
			Log.message("Student Details --> " + studentDetails);

			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}

			try {
				apiResponse = createStudent( smUrl, studentDetails );
				Log.message("CreateStudent APIResponse for GradeValue Test --> " +apiResponse );
				personIDs.add( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
				Log.message("PersonId is --> " + personIDs)	;	
				personIDs.clear();
			} catch ( Exception e ) {
				e.printStackTrace();
				try {
					Log.message( "Retrying CreateStudent API!!!!" );
					apiResponse = createStudent( smUrl, studentDetails );
					Log.message("CreateStudent APIResponse for GradeValue Test --> " +apiResponse );
					personIDs.add( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
					Log.message("PersonId is --> " + personIDs)	;	
					personIDs.clear();
				} catch (Exception e2) {
					Log.fail("Student Not created !!");
				}

			}

			String cmsResponse = null;
			long start = System.currentTimeMillis();
			long end = start + 180 * 1000;
			while (personIDs != null && System.currentTimeMillis() < end) {
				cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
				Log.message("CreateStudent CMS Response for GradeValue Test --> " +cmsResponse );
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				break;
			}

			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");

			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );

			String userMetadata = SMUtils.getKeyValueFromResponseWithArray( cmsResponse, "userMetaData" );

			String expectedGrade = SMUtils.getKeyValueFromResponse( userMetadata, "grade,defaultGradeLevel" );

			Log.message( "Expected grade = " + expectedGrade );
			Log.message( "Actual Grade = " + gradeMapping.get( gradeValue.toString() ) );

			if ( expectedGrade.equalsIgnoreCase( gradeMapping.get( gradeValue.toString() ) ) ) {
				Log.pass( "Grade values returned successfully!" );
			} else {
				Log.fail( "Grade is not matched! Expected: " + expectedGrade + "Actual: " + gradeMapping.get( gradeValue.toString() ) );
			}
			try {
				Log.assertThat( new SMAPIProcessor().isSchemaValid( "createStudentAPISchema", CommonAPIConstants.STATUS_CODE_CREATED, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
			} catch ( IOException e ) {
				e.printStackTrace();
			}

		} );

		Log.testCaseResult();

	}

	@Test ( dataProvider = "createStudentNegativeTestData", groups = { "SMK-52010", "User", "Create Student", "P1", "API" } )
	public void tcCreateStudentNegative001( String description, String scenario, String statusCode ) throws Exception {

		Log.testCaseInfo( description );
		HashMap<String, String> studentDetails = new HashMap<String, String>();
		String exception = null;
		String message = null;

		switch ( scenario ) {
		case "INVALID ORG ID":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateGroupAPIConstants.INVALID_ORG, getGroupListAPIConstants.INVALID_INPUT );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
			message = CommonAPIConstants.INVALID_ORG_SERVER_MESSAGE;

			break;
		case "INVALID TEACHER ID":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateGroupAPIConstants.INVALID_TEACHER, getGroupListAPIConstants.INVALID_INPUT );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
			message = CommonAPIConstants.INVALID_TEACHER_SERVER_MESSAGE;
			break;
		case "STUDENT CREDENTIALS":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID,
					SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
			message = CommonAPIConstants.FORBIDDAN_MESSAGE;
			break;
		case "INVALID CREDENTIALS":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
			message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
			break;
		case "WITHOUT GRADE":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.GRADE, "" );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
			message = CommonAPIConstants.EMPTY_GRADE_MESSAGE;
			break;

		case "INVALID GRADE":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.GRADE, getGroupListAPIConstants.INVALID_INPUT );
			exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
			message = CommonAPIConstants.INVALID_GRADE_MESSAGE;
			break;

		case "EMPTY DEMOGRAPHICS":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ETHINICITY, "" );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
			message = CommonAPIConstants.EMPTY_DEMOGRAPHICS_MESSAGE;
			break;

		case "INVALID DEMOGRAPHICS":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ETHINICITY, getGroupListAPIConstants.INVALID_INPUT );
			exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
			message = CommonAPIConstants.INVALID_ETHINICITY_MESSAGE;
			break;

		case "EMPTY MANDATORY FIELDS":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.FIRSTNAME, "" );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.LASTNAME, "" );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.USERNAME, "" );
			exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
			message = CommonAPIConstants.EMPTY_MANDATORY_FIELD_MESAGE;
			break;

		case "CHARACTER LIMIT":
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.FIRSTNAME, CreateStudentAPIConstants.MORETHEN_75_CHARACTERS );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.LASTNAME, CreateStudentAPIConstants.MORETHEN_75_CHARACTERS );
			studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.USERNAME, CreateStudentAPIConstants.MORETHEN_75_CHARACTERS );
			exception = CommonAPIConstants.VALIDATION_EXCEPTION;
			message = CommonAPIConstants.FIRSTNAME_LIMIT_EXCEED_EXCEPTION;
			break;

		}
		HashMap<String, String> apiResponse = createStudent( smUrl, studentDetails );
		Log.message( "Response = " + apiResponse );
		Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
				"Issue in returning status code! Expected - " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
		verifyException( apiResponse.get( Constants.REPORT_BODY ), exception, true, message );

		if ( !statusCode.equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_OK ) ) {
			if (scenario.equalsIgnoreCase( "WITHOUT GRADE" ) | scenario.equalsIgnoreCase( "INVALID GRADE" )){
				Log.message( "Not verifying the schema since it is a server case" );
			}else{

				Log.assertThat( new SMAPIProcessor().isSchemaValid( "createStudentAPISchema", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
			}
		} else {
			Log.assertThat( new SMAPIProcessor().isSchemaValid( "createStudentAPISchema", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
		}
		Log.testCaseResult();
	}

	@DataProvider ( name = "createStudentNegativeTestData" )
	public Object[][] createStudentNegative() {

		//All the commented cases having future backlog tickets. 
		Object[][] inputData = {
				//{ "Verify the API returns exception when the organization is invalid.", "INVALID ORG ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				//{ "Verify the API returns exception when the teacher id is invalid.", "INVALID TEACHER ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Role based Authorization: Verify the API throwing exception when the authorization is invalid.", "STUDENT CREDENTIALS", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
				{ "Verify the API throwing exception when the authentication is invalid.", "INVALID CREDENTIALS", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
				{ "Verify the student is not created without grade values.", "WITHOUT GRADE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the API returning exception when the grade is invalid.", "INVALID GRADE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				//{ "Verify the API returning exception when the grade is empty", "WITHOUT GRADE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				//{ "Verify the API returning exception when the demographics are empty.", "EMPTY DEMOGRAPHICS", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				//{ "Verify the API returning exception when the demographics are invalid.", "INVALID DEMOGRAPHICS", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				//{ "Verify the API returning exception when the mandatory fields are missing or empty values.", "EMPTY MANDATORY FIELDS", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the teacher cannot create the username with more then 75 characters.", "CHARACTER LIMIT", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }, };

		return inputData;
	}

	/**
	 * This method used to generate the initial values for the request
	 * 
	 * @param studentDetails
	 * @param key
	 * @param value
	 * @return
	 */
	public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
		HashMap<String, String> generatedStudentDetails = studentDetails;
		generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
		generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
		generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
		generatedStudentDetails.put( CreateStudentAPIConstants.GRADE, grade.FIRST.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
		generatedStudentDetails.put( CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
		generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
		generatedStudentDetails.put( CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
		generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
		generatedStudentDetails.put( GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, gender.FEMALE.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
		generatedStudentDetails.put( CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
		return generatedStudentDetails;
	}

	/**
	 * This methods will update the details whatever given in Key and value
	 * 
	 * @param studentDetails
	 * @param key
	 * @param value
	 * @return
	 */
	public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
		HashMap<String, String> generatedStudentDetails = studentDetails;
		if ( generatedStudentDetails.containsKey( key ) ) {
			generatedStudentDetails.put( key, value );
		} else {
			generatedStudentDetails.put( key, value );
		}
		return generatedStudentDetails;
	}

	/**
	 * This method verifies the response
	 * 
	 * @param actualResponse
	 * @param expectedResponse
	 * @return
	 */
	public boolean verifyResponse( String actualResponse, String expectedResponse ) {
		AtomicBoolean isVerified = new AtomicBoolean( false );
		AtomicReference<JSONObject> actualJson = new AtomicReference<>( new JSONObject( actualResponse ) );
		AtomicReference<JSONObject> expectedJson = new AtomicReference<>( new JSONObject( expectedResponse ) );

		String[] fields = { "personId", "firstName", "middleName", "lastName", RBSDataSetupConstants.USERNAME, "gender" };
		String[] demographics = { "isMigrant", "ethnicity", "hasDisability", "specialServices", "hasEnglishProficiency", "hasEconomicDisadvantage" };

		for ( String field : fields ) {
			if ( field.contentEquals( "personId" ) ) {
				if ( actualJson.get().getJSONObject( "data" ).get( field ).toString().equalsIgnoreCase( expectedJson.get().get( GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ).toString() ) ) {
					Log.pass( field + " verified and matching with actual " + field );
					isVerified.set( true );
				} else {
					Log.fail( field + " not matched with actual value. Actual:" + actualJson.get().getJSONObject( "data" ).get( field ).toString() + " Expected:" + expectedJson.get().get( field ).toString() );
					isVerified.set( false );
				}
			} else {
				if ( actualJson.get().getJSONObject( "data" ).get( field ).toString().equalsIgnoreCase( expectedJson.get().get( field ).toString() ) ) {
					Log.pass( field + " verified and matching with actual " + field );
					isVerified.set( true );
				} else {
					Log.fail( field + " not matched with actual value. Actual:" + actualJson.get().getJSONObject( "data" ).get( field ).toString() + " Expected:" + expectedJson.get().get( field ).toString() );
					isVerified.set( false );
				}
			}

		}
		for ( String field : demographics ) {
			if ( actualJson.get().getJSONObject( "data" ).get( field ).toString().equalsIgnoreCase( expectedJson.get().getJSONObject( "userMetaData" ).getJSONObject( "demographics" ).get( field ).toString() ) ) {
				Log.pass( field + " verified and matching with actual " + field );
				isVerified.set( true );
			} else {
				Log.fail( field + " not matched with actual value. Actual:" + actualJson.get().getJSONObject( "data" ).get( field ).toString() + " Expected:"
						+ expectedJson.get().getJSONObject( "userMetaData" ).getJSONObject( "demographics" ).get( field ).toString() );
				isVerified.set( false );
			}
		}

		return isVerified.get();

	}

	/**
	 * This method verifies the response for Case without Middle Name
	 * since USer Service API will not display middleName field in response while creating a student without middle name
	 * 
	 * @param actualResponse
	 * @param expectedResponse
	 * @return
	 */
	public boolean verifyResponseMiddleName( String actualResponse) {
		AtomicBoolean isVerified = new AtomicBoolean( false );
		AtomicReference<JSONObject> actualJson = new AtomicReference<>( new JSONObject( actualResponse ) );

		String[] fields = {  "middleName"};

		for ( String field : fields ) {
			if ( field.contentEquals( "middleName" ) ) {
				String middleNameValue = actualJson.get().getJSONObject( "data" ).get( field ).toString();
				Log.message("Middle Name Value: " + middleNameValue );
				middleNameValue.isEmpty();
				Log.pass( "Test Pass!" );
				isVerified.set( true );
			} else {
				Log.pass( "Test Failed!!" );
				isVerified.set( false );
			}

		}

		return isVerified.get();

	}


	/**
	 * Verifies the exception
	 * 
	 * @param actualResponse
	 * @param exception
	 * @param failureStatus
	 * @param message
	 * @return
	 */
	public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
		boolean isVerified = false;
		if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
			Log.pass( "Exception Verified successfully!" );
			isVerified = true;
		} else {
			Log.fail( "Issue in displaying exception!" );
		}
		if ( failureStatus ) {
			if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
				Log.pass( "Status Verified successfully!" );
				isVerified = true;
			} else {
				Log.fail( "Issue in displaying Status!" );
			}
		}
		if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
			Log.pass( "Message Verified successfully!" );
			isVerified = true;
		} else {
			Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
		}
		return isVerified;
	}

	/**
	 * This method loops the all demographics and doing the test
	 */
	public void verifyDemographicsTest() {

		SMUtils.logDescriptionTC( "Verifying Ethinicity" );
		StudentDetailsForStudentIdAPIConstants.ETHNICITY_VALUES.forEach( value -> {
			HashMap<String, String> apiResponse = new HashMap<>();
			HashMap<String, String> studentDetails = new HashMap<String, String>();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ETHINICITY, value.toString() );
			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}
			try {
				apiResponse = createStudent( smUrl, studentDetails );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
			Log.message( cmsResponse );
			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");
			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
			SMUtils.logDescriptionTC( "Verified " + value.toString() );
		} );
		SMUtils.logDescriptionTC( "Verifying specialServices" );
		Arrays.asList( specialServices.values() ).forEach( value -> {
			HashMap<String, String> apiResponse = new HashMap<>();
			HashMap<String, String> studentDetails = new HashMap<String, String>();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SPECIAL_SERVICES, value.toString() );
			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}
			try {
				apiResponse = createStudent( smUrl, studentDetails );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
			Log.message( cmsResponse );
			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");
			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
			SMUtils.logDescriptionTC( "Verified " + value.toString() );
		} );

		SMUtils.logDescriptionTC( "Verifying hasDisability" );
		Arrays.asList( hasDisability.values() ).forEach( value -> {
			HashMap<String, String> apiResponse = new HashMap<>();
			HashMap<String, String> studentDetails = new HashMap<String, String>();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_DISABILITY, value.toString() );
			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}
			try {
				apiResponse = createStudent( smUrl, studentDetails );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
			Log.message( cmsResponse );
			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");
			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
			SMUtils.logDescriptionTC( "Verified " + value.toString() );
		} );

		SMUtils.logDescriptionTC( "Verifying hasEconomicDisadvantage" );
		Arrays.asList( hasEconomicDisadvantage.values() ).forEach( value -> {
			HashMap<String, String> apiResponse = new HashMap<>();
			HashMap<String, String> studentDetails = new HashMap<String, String>();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, value.toString() );
			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}
			try {
				apiResponse = createStudent( smUrl, studentDetails );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
			Log.message( cmsResponse );
			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");
			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
			SMUtils.logDescriptionTC( "Verified " + value.toString() );
		} );

		SMUtils.logDescriptionTC( "Verifying hasEnglishProficiency" );
		Arrays.asList( hasEnglishProficiency.values() ).forEach( value -> {
			HashMap<String, String> apiResponse = new HashMap<>();
			HashMap<String, String> studentDetails = new HashMap<String, String>();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, value.toString() );
			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}
			try {
				apiResponse = createStudent( smUrl, studentDetails );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
			Log.message( cmsResponse );
			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");
			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
			SMUtils.logDescriptionTC( "Verified " + value.toString() );
		} );

		SMUtils.logDescriptionTC( "Verifying isMigrant" );
		Arrays.asList( isMigrant.values() ).forEach( value -> {
			HashMap<String, String> apiResponse = new HashMap<>();
			HashMap<String, String> studentDetails = new HashMap<String, String>();
			studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
			studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.ISMIGRANT, value.toString() );
			try {
				studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
						new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			} catch ( Exception e1 ) {
				e1.printStackTrace();
			}
			try {
				apiResponse = createStudent( smUrl, studentDetails );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
			String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
			Log.message( cmsResponse );
			cmsResponse = cmsResponse.replace("migrantStatus", "isMigrant");
			cmsResponse = cmsResponse.replace("englishProficiency", "hasEnglishProficiency");
			cmsResponse = cmsResponse.replace("socioEconomicStatus", "hasEconomicDisadvantage");
			cmsResponse = cmsResponse.replace("disabilityStatus", "hasDisability");
			Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
					"Issue in returning status code! Expected - " + CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
			Log.assertThat( verifyResponse( apiResponse.get( Constants.BODY ), cmsResponse ), "Response fields verified sucessfully!", "Response fields are having issue!" );
			SMUtils.logDescriptionTC( "Verified " + value.toString() );
		} );


	}

}