package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class PSRPage extends LoadableComponent<PSRPage> {

    private WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();
    ReportComponent reportComponents;

    @IFindBy(how = How.CSS, using="section.page-title div h1", AI = false)
    public WebElement reportHeader;

    @IFindBy(how = How.CSS, using="label.date-field-title", AI = false)
    public WebElement lblHolidayInfoText;

    @IFindBy(how = How.CSS, using="div.col-md-auto label", AI = false)
    public WebElement lblTargetDate;

    @IFindBy(how = How.CSS, using="div.grade label.date-field-title", AI = false)
    public WebElement lblSetTargetLevelPerGrade;

    @IFindBy(how = How.CSS, using="cel-date-picker#targetDate", AI = false)
    public WebElement txtboxTargetDateRoot;

    @IFindBy(how = How.CSS, using="span.error-message span", AI = false)
    public WebElement txterrorMessage;

    @FindBy ( css = "div.grade div.row label" )
    List<WebElement> lblGrades;

    /**
     * child Elements
     */
    String txtboxTargetDateChild = "div.date-picker input.date-picker-input";

    String sliderchild = "cel-range-slider input";

    String selectedTargetLevel = "div.slider-wrapper span.slider-value span";

    String sliderMinRange = "div.min-max-value span.min-value";

    String sliderMaxRange = "div.min-max-value span.max-value";

    String lblGradeChild = "label.form-label";

    /**
     * get the report header
     *
     * @return
     */
    public String getReportPageHeader() {
        return reportHeader.getText().trim();
    }

    public PSRPage()
    {}
    /**
     * Constructor to load driver and components
     *
     * @param driver
     */
    public PSRPage( WebDriver driver ) {
        this.driver = driver;
        // Have Top bar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
    }

    /**
     * Verify the page load
     */
    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, reportHeader );
    }

    /**
     * Verifying the page is loaded.
     */
    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, reportHeader ) ) {
            Log.message( "SM Prescriptive scheduling report page loaded successfully." );
        } else {
            Log.fail( "SM Prescriptive scheduling report page did not load." );
        }
    }

    /**
     * Verify the Holiday Info text
     *
     * @return
     */
    public boolean isHolidayInfoTextDisplayed() throws InterruptedException {
        Log.message( "Verifying holiday info text!" );
        return lblHolidayInfoText.getText().equals( Constants.Reports.PSR_HOLIDAY_INFO );
    }

    /**
     * Verify the Target date label
     *
     * @return
     */
    public boolean isTargetDateFieldDisplayed() throws InterruptedException {
        Log.message( "Verifying Target Date field!" );
        return lblTargetDate.getText().equals( Constants.Reports.PSR_TARGET_DATE );
    }

    /**
     * Verify the set target level per grade
     *
     * @return
     */
    public boolean isSetTargetLevelPerGradeFieldDisplayed() throws InterruptedException {
        Log.message( "Verifying Set Target Level per Grade field!" );
        return lblSetTargetLevelPerGrade.getText().equals( Constants.Reports.PSR_SET_TARGETLEVEL_PERGRADE );
    }

    /**
     * Set Target Date
     *
     * @param targetDate
     */
    public void setTargetDate( String targetDate ) {
        WebElement targetDatePicker = SMUtils.getWebElement( driver, txtboxTargetDateRoot, txtboxTargetDateChild );
        targetDatePicker.sendKeys( targetDate + Keys.ENTER );
        Log.message( "Entered Target date - " + targetDate );
    }

    /**
     * get error Message
     *
     * @return
     */
    public String getErrorMessage() {
        String errorMessage = txterrorMessage.getText();
        Log.message( "Displayed Error Message - " + errorMessage );
        return errorMessage;
    }

    /**
     * get slide range
     *
     * @return
     */
    public HashMap<String, String> getSliderRanges( String grade ) {
        HashMap<String, String> lowerAndHigherRange = new HashMap<>();
        Log.message( "Getting lowest and  highest for " + grade + " slider bar" );
        for ( WebElement lblgrade : lblGrades ) {
            if ( lblgrade.getText().trim().equals( grade ) ) {
                WebElement parentElement = lblgrade.findElement( By.xpath( "./.." ) );
                WebElement sliderMin = parentElement.findElement( By.cssSelector( sliderMinRange ) );
                lowerAndHigherRange.put( "lower Range", sliderMin.getText().trim() );
                WebElement sliderMax = parentElement.findElement( By.cssSelector( sliderMaxRange ) );
                lowerAndHigherRange.put( "highest Range", sliderMax.getText().trim() );
                break;
            }
        }
        return lowerAndHigherRange;
    }

    /**
     * get Students Grade
     *
     * @return
     */
    public List<String> getStudentsGrade( HashMap<String, List<String>> studentDetails, List<String> selectedStudents ) {
        List<String> grades = new ArrayList<>();
        for ( String studentName : selectedStudents ) {
            List<String> studentfirstNameAndLastName = Arrays.asList( studentName.split( " " ) );
            for ( int studentCount = 0; studentCount < studentDetails.get( Constants.GRADE ).size(); studentCount++ ) {
                if ( studentDetails.get( Constants.FIRSTNAME ).get( studentCount ).equals( studentfirstNameAndLastName.get( 0 ) )
                        && studentDetails.get( Constants.LASTNAME ).get( studentCount ).equals( studentfirstNameAndLastName.get( studentfirstNameAndLastName.size() - 1 ) ) ) {
                    grades.add( studentDetails.get( Constants.GRADE ).get( studentCount ) );
                }
            }
        }
        Log.message( "Got the Grades for Selected students from student dropodown" );
        return grades;
    }

    /**
     * get Grades slider bar from UI
     *
     * @return
     */
    public List<String> getDisplayedGradesFromUI() {
        List<String> grades = new ArrayList<>();
        for ( WebElement grade : lblGrades ) {
            grades.add( grade.getText().trim() );
        }
        Log.message( "Got the grades sliders form UI" );
        return grades;
    }

    /**
     * To move the slider
     *
     * @param grade, targetLevel
     */
    public boolean moveSliderTo( String grade, String targetLevel ) {
        String valueOfSlider = null;
        for ( WebElement lblgrade : lblGrades ) {
            if ( lblgrade.getText().trim().equalsIgnoreCase( grade ) ) {
                WebElement parentElement = lblgrade.findElement( By.xpath( "./.." ) );
                WebElement slider = parentElement.findElement( By.cssSelector( sliderchild ) );
                for ( float level = 0; level <= 8.95; level += 0.05 ) {
                    slider.sendKeys( Keys.ARROW_RIGHT );
                    WebElement selectedLevel = parentElement.findElement( By.cssSelector( selectedTargetLevel ) );
                    SMUtils.waitForElement( driver, selectedLevel );
                    valueOfSlider = selectedLevel.getText();
                    if ( valueOfSlider.trim().equals( targetLevel ) ) {
                        Log.message( "The course level is setted as " + valueOfSlider );
                        return true;
                    }
                }
            }
        }
        Log.message( "The course level is not setted as " + valueOfSlider );
        return false;

    }
}