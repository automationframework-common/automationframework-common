package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class MasteryFiltersTest extends BaseTest {

    private String smUrl;
    private String browser;

    static String username;
    static final String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher24" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( priority = 1, groups = { "SMK-39450", "mastery", "masteryStudentsFilter" } )
    public void tcMasteryFiltersStudentsDropdown() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String expValidationData = Constants.MasteryUI.ALL_STUDENTS_COUNT;

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );

            Log.message( "TC 1" + "- Verify the students associated with the teacher are listed in students Dropdown" );
            String actualStudentCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();
            Log.assertThat( expValidationData.equals( actualStudentCount ), "The students associated with the teacher are listed in students Dropdown", "The students associated with the teacher are not listed in students Dropdown" );

            Log.message( "TC 2- Verify the teacher is able to select a student in the students dropdown" );
            // reset filter component and select students dropdown
            masteryFiltersComponent.resetFilter();

            // Select a single student
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( Arrays.asList( 0 ) );

            // Get the count of selected students
            String selectedStudentCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();

            Log.assertThat( selectedStudentCount.equals( "1" ), "The teacher is able to select a single-student in the students dropdown", "The teacher not able to select a single-student in the students dropdown" );

            Log.message( "TC 3- Verify the teacher is able to select multiple students in the students dropdown" );

            // reset filter component and select students dropdown
            masteryFiltersComponent.resetFilter();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );

            List<String> totalAvailableStudents = masteryFiltersComponent.getValuesFromDropDownMS();
            int[] totalStudentsAvailable = new Random().ints( 0, totalAvailableStudents.size() ).distinct().limit( 2 ).toArray();

            // List of int
            List<Integer> studentIndex = Arrays.stream( totalStudentsAvailable ).boxed().collect( Collectors.toList() );

            String expectedStudentCount = String.valueOf( studentIndex.size() );
            // Select a single student
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( studentIndex );

            // Get the count of selected students
            selectedStudentCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();

            Log.assertThat( expectedStudentCount.equals( selectedStudentCount ), "The teacher is able to select multiple-student in the students dropdown", "The teacher not able to select multiple-student in the students dropdown" );

            expValidationData = Constants.MasteryUI.ALL_STUDENTS_MESSAGE;
            Log.message( "TC 4- Verify the teacher is able to select all students by clicking SELECT ALL checkbox in the students dropdown" );
            // reset filter component and select students dropdown
            masteryFiltersComponent.resetFilter();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );

            // Select all students from students dropdown
            masteryFiltersComponent.checkSelectAllDropdownMS();

            // Get the selected value from drop down
            String selectedStudentValue = masteryFiltersComponent.getDropDownMSSelectedValue();

            Log.assertThat( expValidationData.equals( selectedStudentValue ), "The teacher is able to select all students by clicking SELECT ALL checkbox in the students dropdow",
                    "The teacher is unable to select all students by clicking SELECT ALL checkbox in the students dropdow" );

            Log.message( "TC 5- Verify the total number of students associated with teacher are displayed in the students dropdown bar" );
            // reset filter component and select students dropdown
            masteryFiltersComponent.resetFilter();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );

            // Select all students from students dropdown
            masteryFiltersComponent.checkSelectAllDropdownMS();

            // Get the selected value from drop down
            selectedStudentValue = masteryFiltersComponent.getDropDownMSSelectedValue();

            Log.assertThat( expValidationData.equals( selectedStudentValue ), "The total number of students associated with teacher are displayed in the students dropdown bar)",
                    "The total number of students associated with teacher are not displayed/mismatch in the count in the students dropdown bar" );

            Log.message( "TC 6- Verify the All Student are selected as default in the Students dropdown" );
            // reset filter component and select students dropdown
            masteryFiltersComponent.resetFilter();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );

            // Get the selected value from drop down
            selectedStudentValue = masteryFiltersComponent.getDropDownMSSelectedValue();

            Log.assertThat( expValidationData.equals( selectedStudentValue ), "All Students are selected as default in the Students dropdown", "All Students are not selected as default in the Students dropdown" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 2, groups = { "SMK-39450", "mastery", "masterySkillsStandardsFilter" } )
    public void tcMasteryFiltersSkillStandardsDropdown() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // get values from Database for Math subject
            List<StandardVersionMastery> listStandardVersionDBMath = SqlHelperMastery.getStandards( Constants.MasteryUI.SUBJECT_MATH );

            // Get Standards name from DB data
            List<String> skillStandardsAvailableDBMath = new ArrayList<>();
            for ( StandardVersionMastery standardVersionMastery : listStandardVersionDBMath ) {
                skillStandardsAvailableDBMath.add( standardVersionMastery.getStandardsName() );
            }

            skillStandardsAvailableDBMath = skillStandardsAvailableDBMath.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.sort( skillStandardsAvailableDBMath );

            // get values from Database for Reading subject
            List<StandardVersionMastery> listStandardVersionDBReading = SqlHelperMastery.getStandards( Constants.MasteryUI.SUBJECT_READING );

            // Get Standards name from DB data
            List<String> skillStandardsAvailableDBReading = new ArrayList<>();
            for ( StandardVersionMastery standardVersionMastery : listStandardVersionDBReading ) {
                skillStandardsAvailableDBReading.add( standardVersionMastery.getStandardsName() );
            }

            // look for copyright_hexcode and replace as copyright symbol
            skillStandardsAvailableDBReading = skillStandardsAvailableDBReading.stream().map( s -> s.replaceAll( Constants.COPYRIGHT_HEXCODE, Constants.COPYRIGHT_SYMBOL ) ).collect( Collectors.toList() );
            skillStandardsAvailableDBReading = skillStandardsAvailableDBReading.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.sort( skillStandardsAvailableDBReading );

            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();

            Log.message( "TC 1- Verify the standards associated with Math Subject are listed in the Skills/Standards dropdown" );

            // Get the values from skill/standards drop down
            List<String> skillStandardsAvailableUI = masteryFiltersComponent.getAllSkillStandardsDropDownValues();
            skillStandardsAvailableUI.remove( Constants.MasteryUI.SKILL_MATH );

            // Sort/lowercase the list
            skillStandardsAvailableUI = skillStandardsAvailableUI.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.sort( skillStandardsAvailableUI );

            Log.assertThat( skillStandardsAvailableUI.equals( skillStandardsAvailableDBMath ), "The standards associated with Math Subject are listed in the Skills/Standards dropdown",
                    "The standards associated with Math Subject are not listed in the Skills/Standards dropdown" );

            Log.message( "TC 2- Verify the standards associated with Reading Subject are listed in the Skills/Standards dropdown" );

            // select Reading as subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Get the values from skill/standards drop down
            skillStandardsAvailableUI = masteryFiltersComponent.getAllSkillStandardsDropDownValues();
            skillStandardsAvailableUI.remove( Constants.MasteryUI.SKILL_READING );

            // Sort/lowercase the list
            skillStandardsAvailableUI = skillStandardsAvailableUI.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.sort( skillStandardsAvailableUI );

            String osName = System.getProperty( "os.name" );
            if ( osName.startsWith( "Windows" ) )
                Log.assertThat( skillStandardsAvailableUI.equals( skillStandardsAvailableDBReading ), "The standards associated with Reading Subject are listed in the Skills/Standards dropdown",
                        "The standards associated with Reading Subject are not listed in the Skills/Standards dropdown" );
            else
                Log.failsoft( "Encoding issue- The skills/Standards for Reading has copyright symbol, that cannot be compared in OS-" + osName );

            Log.message( "TC 3- Verify the teacher is able to select the standards in the Skills/Standards dropdown" );
            masteryFiltersComponent.resetFilter();

            // Get selected value from skillstandards drop down
            String defaultSkillStandards = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            // select skillstandards
            masteryFiltersComponent.selectSkillStandardsByIndex( 2 );

            // Get latest selected value from skillstandards drop down
            String latestSkillStandards = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            Log.assertThat( !defaultSkillStandards.equals( latestSkillStandards ), "The teacher is able to select the standards in the Skills/Standards dropdow", "The teacher is not able to select the standards in the Skills/Standards dropdow" );

            Log.message( "TC 4- Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown" );
            masteryFiltersComponent.resetFilter();

            // select skillstandards_1
            masteryFiltersComponent.selectSkillStandardsByIndex( 2 );

            // Get selected value from skillstandards drop down
            String selectedSkillStandards1 = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            // select skillstandards_2
            masteryFiltersComponent.selectSkillStandardsByIndex( 0 );

            // Get latest selected value from skillstandards drop down
            String selectedSkillStandards2 = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            Log.assertThat( !selectedSkillStandards1.equals( selectedSkillStandards2 ), "The teacher is not able to select multiple standards in the Skills/Standards dropdown",
                    "The teacher is able to select multiple standards in the Skills/Standards dropdown" );

            Log.message( "TC 5- Verify the SuccessMaker Mastery Skills- Math are selected default in the Skills/Standards dropdown when Math is chosen as subject" );
            masteryFiltersComponent.resetFilter();

            // Get selected value from skillstandards drop down
            String selectedSkillStandards = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            // verify SuccessMaker is default chosen option
            Log.assertThat( Constants.MasteryUI.SKILL_MATH.equals( selectedSkillStandards ), "The SuccessMaker Mastery Skills- Math are selected as default in the Skills/Standards dropdown(Mastery Page) when Math is chosen as subject",
                    "The SuccessMaker Mastery Skills- Math are not selected as default in the Skills/Standards dropdown(Mastery Page) when Math is chosen as subject" );

            Log.message( "TC 6- Verify the SuccessMaker Mastery Skills- Reading are selected default in the Skills/Standards dropdown when Reading is chosen as subject" );
            masteryFiltersComponent.resetFilter();

            // select reading from subject drop down
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Get selected value from skillstandards drop down
            selectedSkillStandards = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            // verify SuccessMaker is default chosen option
            Log.assertThat( Constants.MasteryUI.SKILL_READING.equals( selectedSkillStandards ), "The SuccessMaker Mastery Skills- Math are selected as default in the Skills/Standards dropdown(Mastery Page) when Reading is chosen as subject",
                    "The SuccessMaker Mastery Skills- Math are not selected as default in the Skills/Standards dropdown(Mastery Page) when Reading is chosen as subject" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-39450", "mastery", "masteryGroupsFilter" } )
    public void tcMasteryFiltersGroupsDropdown() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        String expValidationData = Constants.MasteryUI.ALL_GROUPS_COUNT;

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.GROUPS );

            SMUtils.logDescriptionTC( "TC 1- Verify the groups associated with the teacher are listed in Groups Dropdown" );

            // get total group count
            String actualGroupCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();
            Log.assertThat( expValidationData.equals( actualGroupCount ), "The groups associated with the teacher are listed in groups Dropdown", "The groups associated with the teacher are not listed in groups Dropdown" );

            SMUtils.logDescriptionTC( "TC 2- Verify the teacher is able to select a group in the Groups dropdown" );

            // Select a single group
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( Arrays.asList( 1 ) );

            // Get the count of selected groups
            String selectedGroupCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();

            Log.assertThat( selectedGroupCount.equals( "1" ), "The teacher is able to select a single-group in the students dropdown", "The teacher not able to select a single-group in the students dropdown" );

            SMUtils.logDescriptionTC( "TC 3- Verify the teacher is able to select multiple groups in the Groups dropdown" );

            // List of int
            List<Integer> groupIndex = Arrays.asList( 0, 1 );
            String expectedgroupCount = String.valueOf( groupIndex.size() );
            // Select a multiple groups
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( groupIndex );

            // Get the count of selected groups
            selectedGroupCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();

            Log.assertThat( expectedgroupCount.equals( selectedGroupCount ), "The teacher is able to select multiple-groups in the groups dropdown", "The teacher not able to select multiple-groups in the groups dropdown" );

            SMUtils.logDescriptionTC( "TC 4- Verify the teacher is able to select all groups by clicking SELECT ALL checkbox in the Groups dropdown" + Constants.HTML_BREAK_TAG
                    + "TC 5- Verify the total number of groups associated with teacher are displayed in the Groups dropdown bar" + Constants.HTML_BREAK_TAG + "TC 6- Verify the All Groups are selected as default in the Groups dropdown" );

            expValidationData = Constants.MasteryUI.ALL_GROUPS_MESSAGE;
            masteryFiltersComponent.resetFilter();

            // Select all groups from groups dropdown
            masteryFiltersComponent.checkSelectAllDropdownMS();

            // Get the selected value from drop down
            String selectedGroupValue = masteryFiltersComponent.getDropDownMSSelectedValue();

            Log.assertThat( expValidationData.equals( selectedGroupValue ),
                    "The teacher is able to select all groups by clicking SELECT ALL checkbox in the groups dropdown" + Constants.HTML_BREAK_TAG + " The total number of groups associated with teacher are displayed in the groups dropdown bar"
                            + Constants.HTML_BREAK_TAG + " All groups are selected as default in the groups dropdown",
                    "The teacher is unable to select all groups by clicking SELECT ALL checkbox in the groups dropdown" + Constants.HTML_BREAK_TAG
                            + " The total number of groups associated with teacher are not displayed/mismatch in the count in the groups dropdown bar" + Constants.HTML_BREAK_TAG + " All groups are not selected as default in the groups dropdown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39450", "mastery", "masteryAssignmentsFilter" } )
    public void tcMasteryFiltersAssignmentsDropdown() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        String expValidationData = Constants.MasteryUI.ALL_ASSIGNMENTS_COUNT;

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            SMUtils.logDescriptionTC( "TC-1 Verify the assignments associated with the students/groups are listed in Assignments Dropdown" );

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            String actualAssignmentCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();
            Log.assertThat( expValidationData.equals( actualAssignmentCount ), "The assignments associated with the students/groups are listed in Assignments Dropdown",
                    "The assignments associated with the students/groups are not listed in Assignments Dropdown" );

            SMUtils.logDescriptionTC( "TC-2 Verify the teacher is able to select a assignment in the Assignments dropdown" );

            // Select a single assignment
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( Arrays.asList( 2 ) );

            // Get the count of selected assignments
            String selectedAssignmentCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();

            Log.assertThat( selectedAssignmentCount.equals( "1" ), "The teacher is able to select a single-assignment in the assignments dropdown", "The teacher not able to select a single-assignment in the assignments dropdown" );

            SMUtils.logDescriptionTC( "TC-3 Verify the teacher is able to select multiple assignments in the Assignments dropdown" );

            // List of int
            List<Integer> assignmentsIndex = Arrays.asList( 0, 1 );
            String expectedassignmnetsCount = String.valueOf( assignmentsIndex.size() );
            // Select a multiple assignments
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( assignmentsIndex );

            // Get the count of selected assignments
            selectedAssignmentCount = masteryFiltersComponent.getSelectedCountFromDropDownMs().toString();

            Log.assertThat( expectedassignmnetsCount.equals( selectedAssignmentCount ), "The teacher is able to select multiple-assignments in the assignments dropdown", "The teacher not able to select multiple-assignments in the assignments dropdown" );

            SMUtils.logDescriptionTC( "TC-4 Verify the teacher is able to select all assignments by clicking ALL ASSIGNMENTS checkbox in the Assignments dropdown" + Constants.HTML_BREAK_TAG
                    + "TC-5 Verify the total number of assignments associated with students/groups are displayed in the Assignments dropdown bar" + Constants.HTML_BREAK_TAG
                    + "TC-6 Verify the All Assignments are selected as default in the Assignments dropdown" );
            expValidationData = Constants.MasteryUI.ALL_ASSIGNMENTS_MESSAGE;

            // reset filters
            masteryFiltersComponent.resetFilter();

            // Select all assignments from assignments dropdown
            masteryFiltersComponent.checkSelectAllDropdownMS();

            // Get the selected value from drop down
            String selectedAssignmentValue = masteryFiltersComponent.getDropDownMSSelectedValue();

            Log.assertThat( expValidationData.equals( selectedAssignmentValue ),
                    "The teacher is able to select all assignments by clicking SELECT ALL checkbox in the assignments dropdown" + Constants.HTML_BREAK_TAG
                            + " The total number of assignments associated with students/groups are displayed in the assignments dropdown bar" + Constants.HTML_BREAK_TAG + " All assignments are selected as default in the assignments dropdown",
                    "The teacher is unable to select all assignments by clicking SELECT ALL checkbox in the assignments dropdown" + Constants.HTML_BREAK_TAG
                            + " The total number of assignments associated with students/groups are not displayed/mismatch in the count in the assignments dropdown bar" + Constants.HTML_BREAK_TAG
                            + " All assignments are not selected as default in the assignments dropdown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39450", "mastery", "masterySubjectsFilter" } )
    public void tcMasteryFiltersSubjectsDropdown() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();

            SMUtils.logDescriptionTC( "TC 1-Verify the teacher is able to select the Reading subject in the Subjects dropdown" );

            // select reading subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // get the selected subject
            String selectedSubject = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            // verify teacher can select any subject
            Log.assertThat( Constants.MasteryUI.SUBJECT_READING.equals( selectedSubject ), "The teacher is able to select the subject in the Subjects dropdown", "The teacher is not able to select the subject in the Subjects dropdown" );

            SMUtils.logDescriptionTC( "TC 2- Verify the teacher is able to select the Math in the Subjects dropdown" );

            // select math subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // get the selected subject
            selectedSubject = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            // verify teacher can select any subject
            Log.assertThat( Constants.MasteryUI.SUBJECT_MATH.equals( selectedSubject ), "The teacher is able to select the Math in the Subjects dropdown", "The teacher is not able to select the Math in the Subjects dropdown" );

            SMUtils.logDescriptionTC( "TC 3- Verify the teacher is able to select the Reading subject in the Subjects dropdown" );
            // select math subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // get the selected subject
            selectedSubject = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            // verify teacher can select any subject
            Log.assertThat( Constants.MasteryUI.SUBJECT_READING.equals( selectedSubject ), "The teacher is able to select the Reading subject in the Subjects dropdown", "The teacher is not able to select the Reading subject in the Subjects dropdown" );

            SMUtils.logDescriptionTC( "TC 4- Verify Math is selected as default in the Subjects dropdown" );
            masteryFiltersComponent.resetFilter();

            // get the default selected subject
            String defaultSubject = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            // verify teacher can select any subject
            Log.assertThat( Constants.MasteryUI.SUBJECT_MATH.equals( defaultSubject ), "Math is selected as default in the Subjects dropdown", "Math is not selected as default in the Subjects dropdown" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
