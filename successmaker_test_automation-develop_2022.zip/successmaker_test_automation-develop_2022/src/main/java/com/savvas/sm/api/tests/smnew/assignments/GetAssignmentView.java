package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class GetAssignmentView extends AssignmentAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( priority = 1, dataProvider = "getRecentAssignmentsListing_PositiveFlow", groups = { "SMK-51885", "AssignmentView", "smoke_test_case", "P1", "API" } )
    public void tcGetAssignmentView_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        String endpoint = "null";
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );

        switch ( scenario ) {

            case "TEACHER ASSIGNED DEFAULT MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "TEACHER ASSIGNED DEFAULT READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "TEACHER ASSIGNED FOCUS READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "TEACHER ASSIGNED FOCUS MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "CUSTOM SETTINGS MATH":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "CUSTOM SKILL MATH":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "CUSTOM STANDARD MATH":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "CUSTOM SETTINGS READING":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "CUSTOM SKILL READING":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "CUSTOM STANDARD READING":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;
            default:
                Log.fail( "Case is invalid" );
                break;
        }

        HashMap<String, String> getresponse = getViewAssignment( smUrl, assignmentDetails, endpoint );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

        Log.assertThat( smAPIprocessor.isSchemaValid( "getAssignmentView", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ).replace( "chinese traditional", "chinesetraditional" ) ), "Schema is returned as expected.",
                "Schema is not as expected." );

    }

    @Test ( priority = 2, dataProvider = "getRecentAssignmentsListing_NegativeFlow", groups = { "SMK-51885", "AssignmentsSettings", "AssignmentsListing", "P1", "API" } )
    public void tcGetAssignmentView_02( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";
        String message = null;
        String exception = null;

        boolean status = false;

        switch ( scenario ) {

            case "INVALID ORGANIZATION":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", "abcd" ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );

                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = null;
                status = true;
                break;

            case "INVALID STAFFID":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "123" );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "INVALID AUTHORIZATION":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );

                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "INVALID CONTENTBASE_ID":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1234567" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );

                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.ASSIGNMENT_NOT_FOUND_MESSAGE;
                status = true;
                break;

            case "INVALID CONTENTBASE_ID_STRING":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "rr" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}", "abcd" );

                message = null;
                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                status = true;
                break;

            case "EMPTY CONTENTBASE_ID":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, " " );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}", "" );

                exception = CommonAPIConstants.NULL_EXCEPTION;
                message = null;
                status = true;
                break;

            case "EMPTY ORG_ID":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", "" ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );

                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = null;
                status = true;
                break;

            case "EMPTY STAFF_ID":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", "" ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );

                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = null;
                status = true;
                break;

            case "STAFF_NOT_BELONG_ORG":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                endpoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", "12345" ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );

                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = null;
                status = true;
                break;

            default:
                Log.fail( "Case is invalid" );
                break;

        }
        HashMap<String, String> getresponse = getViewAssignment( smUrl, assignmentDetails, endpoint );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

        if ( message != null ) {
            verifyException( getresponse.get( "body" ), exception, status, message );
        }
        if ( message != null ) {
            Log.assertThat( smAPIprocessor.isSchemaValid( "400_Schema", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ).replace( "chinese traditional", "chinesetraditional" ) ), "Schema is returned as expected.",
                    "Schema is not as expected." );
        }

    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "getRecentAssignmentsListing_PositiveFlow" )
    public Object[][] getRecentAssignmentsListing_PositiveFlow() {

        Object[][] inputData = {

                { "Verify the valid data To Get ViewAssignment  API for default Math", "TEACHER ASSIGNED DEFAULT MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment API for default Reading", "TEACHER ASSIGNED DEFAULT READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment API for Focus Reading", "TEACHER ASSIGNED FOCUS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment API for Focus Math", "TEACHER ASSIGNED FOCUS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment API for Custom Settings Math", "CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment API for Custom Skill Math", "CUSTOM SKILL MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment API for Custom Standards Math", "CUSTOM STANDARD MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment  API for Custom Settings Reading", "CUSTOM SETTINGS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment  API for Custom Skill Reading", "CUSTOM SKILL READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get ViewAssignment  API for Custom Standards Reading", "CUSTOM STANDARD READING", CommonAPIConstants.STATUS_CODE_OK }, };

        return inputData;
    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "getRecentAssignmentsListing_NegativeFlow" )
    public Object[][] getRecentAssignmentsListing_NegativeFlow() {

        Object[][] inputData = { { "Verify the API returns exception when the organization is invalid.", "INVALID ORGANIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API throwing exception when the authorization is invalid.", "INVALID AUTHORIZATION", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API throwing exception when the staff is invalid.", "INVALID STAFFID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API throwing exception when the Course id is invalid. ", "INVALID CONTENTBASE_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API throwing exception when the Course id is String. ", "INVALID CONTENTBASE_ID_STRING", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API throwing exception when the Course id is Empty ", "EMPTY CONTENTBASE_ID", CommonAPIConstants.STATUS_EMPTY },
                { "Verify the API throwing exception when the Org id is Empty ", "EMPTY ORG_ID", CommonAPIConstants.STATUS_EMPTY }, { "Verify the API throwing exception when the Staff id is Empty ", "EMPTY STAFF_ID", CommonAPIConstants.STATUS_EMPTY },
                { "Verify the API throwing exception when the Staff ID is not the part of Org ", "STAFF_NOT_BELONG_ORG", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        Log.message( "Actual : " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ) );
        Log.message( "Expected : " + exception );
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    public HashMap<String, String> getViewAssignment( String envUrl, HashMap<String, String> assignmentDetails, String endpoint ) throws Exception {

        String endPoint;
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String contentbaseId = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        if ( endpoint.equalsIgnoreCase( "null" ) ) {
            endPoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;
            endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{contentbaseId}", contentbaseId );
        } else {
            endPoint = endpoint;
        }
        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

}