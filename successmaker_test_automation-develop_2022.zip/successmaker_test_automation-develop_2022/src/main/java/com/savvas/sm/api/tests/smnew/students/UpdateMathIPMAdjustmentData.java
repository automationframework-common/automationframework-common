package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.student.api.licenses.StudentDashboardAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UpdateMathIPMAdjustmentData extends AssignmentAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String teacherUserName;
    private String mathAssignmentID;
    private String mathAssignmentUserId1;
    private String readingAssignmentID;
    private String readingAssignmentUserId;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetails1,studentUserId1, studentUserName1 ;
    private String studentDetails2,studentUserId2, studentUserName2 ;
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String browser;
    
    private String courseName;
    // Map<String, String> ReadingExitDataResponse = new HashMap<>();
    Map<String, String> updatewithPayload = new HashMap<>();
    Map<String, String> updatewithOutPayload = new HashMap<>();
    Map<String, String> mathAssignmentResponse = new HashMap<>();
    Map<String, String> readingAssignmentResponse = new HashMap<>();
    //HashMap<String, String> auID = new HashMap<>();
    String auID=null;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    String sessionID;
    String payload = null;
    
    String token=null;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String endPoint;
    Map<String, String> response=new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
		browser = configProperty.getProperty( "BrowserPlatformToRun" );

		teacherDetails = RBSDataSetup.getMyTeacher( school );
		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
		teacherUserName = SMUtils.getKeyValueFromResponse(teacherDetails, "userName");

		studentDetails1 = RBSDataSetup.getMyStudent(school, teacherUserName);
		studentUserId1 = SMUtils.getKeyValueFromResponse(studentDetails1, "userId");
		studentUserName1 = SMUtils.getKeyValueFromResponse(studentDetails1, "userName");

		studentRumbaIds.add( studentUserId1 );
		
		studentDetails2 = RBSDataSetup.getMyStudent(school, teacherUserName);
		studentUserId2 = SMUtils.getKeyValueFromResponse(studentDetails1, "userId");
		studentUserName2 = SMUtils.getKeyValueFromResponse(studentDetails1, "userName");

		studentRumbaIds.add( studentUserId2 );
		
		token = new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
        
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserId1 ) );
        
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );

        mathAssignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserId1 ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + mathAssignmentResponse );
        mathAssignmentID = SMUtils.getKeyValueFromResponse( mathAssignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        mathAssignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentUserId1, mathAssignmentID );
        Log.message( "assignmentUserId =" + mathAssignmentUserId1 );
        
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );

        readingAssignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserId2 ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + readingAssignmentResponse );
        readingAssignmentID = SMUtils.getKeyValueFromResponse( readingAssignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        readingAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserId2, readingAssignmentID );
        Log.message( "assignmentUserId =" + readingAssignmentUserId );
        
        
    }

    @Test ( priority = 1, dataProvider = "updateMathIpmAdjustmentPostivieScenarios", groups = { "SMK-66846", "smoke_test_case", "P1", "API" } )
      public void tcPostiveAPI( String testcaseName, String description, String scenario, String statusCode ) throws Exception {
    	        Log.testCaseInfo( description );

       
        switch (scenario) {
        
        case "MATH":
        	
        String Accesstoken = new RBSUtils().getAccessToken( studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD );
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + Accesstoken );
        header.put( Constants.USERID_SM_HEADER, studentUserId1 );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        StudentDashboardAPI studentAPI = new StudentDashboardAPI();

        sessionID = studentAPI.getSessionId(smUrl, studentUserId1, orgId, studentUserName1, password, mathAssignmentUserId1);
    //    sessionID = getSessionId( smUrl, studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId1 );
        header.put(Constants.SESSIONID_HEADER, sessionID);
        Log.message( "headers value: " + header.toString() );

        Map<String, String> params=new HashMap<>();
        params.put(Constants.ASSIGNMENT_USERID, mathAssignmentUserId1);
        
        response = UpdateData( smUrl, header, params );
        Log.message( "Math Response = " + response );
        Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + response.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        break;
        
        case "READING":
        	
            String Accesstoken2 = new RBSUtils().getAccessToken( studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD );
            HashMap<String, String> header2 = new HashMap<>();
            header2.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            header2.put( Constants.AUTHORIZATION, "Bearer " + Accesstoken2 );
            header2.put( Constants.USERID_SM_HEADER, studentUserId2 );
            header2.put( Constants.ORGID_SM_HEADER, orgId );
            StudentDashboardAPI studentAPI2 = new StudentDashboardAPI();

            sessionID = studentAPI2.getSessionId(smUrl, studentUserId2, orgId, studentUserName2, password, readingAssignmentUserId);
        //    sessionID = getSessionId( smUrl, studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId1 );
            header2.put(Constants.SESSIONID_HEADER, sessionID);
            Log.message( "headers value: " + header2.toString() );

            Map<String, String> params2=new HashMap<>();
            params2.put(Constants.ASSIGNMENT_USERID, readingAssignmentUserId);
            
            response = UpdateData( smUrl, header2, params2 );
            Log.message( "Reading Response = " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + response.get( Constants.STATUS_CODE ),
                    "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        }
    }
    
    /**
     * Data provider to give the positive data
     *
     * @return
     */
    @DataProvider ( name = "updateMathIpmAdjustmentPostivieScenarios" )
    public Object[][] tcPostiveAPI() {
        Object[][] inputData = {
                { "TC001", "Verify adjustment API calls triggered after 30 LO completion for custom by settings", "MATH", CommonAPIConstants.STATUS_CODE_OK }, 
                { "TC002", "Verify adjustment API calls triggered after 30 LO completion for custom by settings", "READING", CommonAPIConstants.STATUS_CODE_OK }
        };
        return inputData;
    }

    public Map<String, String> UpdateData( String url, HashMap<String, String> header, Map<String, String> params ) throws Exception {
    	String endPoint = StudentDetailsForGivenTeacherConstants.UPDATE_MATH_IPM;
        endPoint = endPoint.replace( Constants.AUID_VALUE, params.get( Constants.ASSIGNMENT_USERID ) );
        Log.message("endpoint is : "+ endPoint);
        payload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateMathIPMAdjustmentData.json" );
        Log.message( "Payload is : " + payload );
        return RestHttpClientUtil.PUT( url, header, new HashMap<>(), endPoint, payload );
    }    
   
}