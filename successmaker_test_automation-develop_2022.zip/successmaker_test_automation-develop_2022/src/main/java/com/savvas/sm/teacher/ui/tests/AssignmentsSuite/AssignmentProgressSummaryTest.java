package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AssignmentProgressSummaryTest extends BaseTest {

	private String smUrl;
	private String browser;
	private static String username = null;
	private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String flexSchoolTeacherDetails = null;
	private String token = null;
	private static String teacherDetails;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String teacherID;
	String studentDetails;
	String studentDetailsSecond;
	String studentSMDetails;
	String studentSMDetailsSecond;
	String studentFirstName;
	String studentMiddleName;
	String studentLastName;
	String studentUsername;
	private String orgId;
	AssignmentAPI assign = new AssignmentAPI();
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
	String customSettingCourseMath = Constants.CUSTOM_SETTINGS_MATH_ASSIGMENT_TITLE +System.nanoTime();
	String customSettingCourseReading = Constants.CUSTOM_READING_ASSIGMENT_TITLE + System.nanoTime();
	String customSettingCourseMathipon = Constants.CUSTOM_MATH_ASSIGMENT_TITLE + System.nanoTime();
	String customSettingCourseReadingipon = "Custom_Reading_IP_On"+ System.nanoTime();
	
	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		UserAPI userAPIMethod = new UserAPI();

		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsSecond, "userId"));
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Student SM Details
		studentSMDetails = userAPIMethod.getStudentDetailsByStudentId(SMUtils.getKeyValueFromResponse(studentDetails, "userId"), teacherID,		RBSDataSetup.organizationIDs.get(school), token).get(Constants.REPORT_BODY);
		studentSMDetailsSecond = userAPIMethod.getStudentDetailsByStudentId(SMUtils.getKeyValueFromResponse(studentDetailsSecond, "userId"),teacherID, RBSDataSetup.organizationIDs.get(school), token).get(Constants.REPORT_BODY);
		studentFirstName = SMUtils.getKeyValueFromResponse(studentDetails, "firstName");
		studentMiddleName = SMUtils.getKeyValueFromResponse(studentDetails, "middleName");
		studentLastName = SMUtils.getKeyValueFromResponse(studentDetails, "lastName");
		
		 // token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Teacher access token: " + token );
        
     // Getting group details
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherID );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId);
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );
        
        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );
        
        executeSimulator( studentUsername, Constants.MATH, Constants.MATH );
	}

	@Test(description = "Verify the teacher is teacher is able to assign default courses to student", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_progessViewSummary_001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Verify the teacher is teacher is able to assign default courses to student"+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			CourseListingPage courseListingPage = new CourseListingPage(driver);
			List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
			List<String> studentList = new ArrayList<>();

			// Traverse to Courses page
			tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Click on the default Math course
			customCourses.clickOnCourseNameFromList(Constants.MATH);

			// Click on the assignment
			customCourses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			customCourses.addCourseToStudents();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Click on the View Assignment
			customCourses.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify whether the student is present in the particular assignment
			studentList = customCourses.getStudentListfromAssignementDetailsTable();

			// Assert Statement
			Log.softAssertThat(Boolean.TRUE.equals(studentList.size() == studentListFromTheAssignmentPopup.size()),Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
					Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT);

			// To assign default Reading course to the Student traverse to Courses page
			tHomePage.topNavBar.getCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Click on the default Reading course
			customCourses.clickOnCourseNameFromList(Constants.READING);

			// Click on the assignment
			customCourses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			customCourses.addCourseToStudents();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Click on the View Assignment
			customCourses.clickOnTheHoveredAssignment(Constants.READING);

			// Verify whether the student is present in the particular assignment
			studentList = customCourses.getStudentListfromAssignementDetailsTable();

			// Assert Statement
			Log.softAssertThat(Boolean.TRUE.equals(studentList.size() == studentListFromTheAssignmentPopup.size()),Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
					Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT);

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the student doesnot start for the default courses for Math/Reading", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 2)
	public void tc_progessViewSummary_002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_progessViewSummary_002 : SMK-13884- Verify the student doesnot start for the default courses for Math/Reading"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			SMUtils.scrollDownPage(driver);
			SMUtils.nap(20);
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");
			SMUtils.logDescriptionTC("SMK-13853- Verify the teacher can view the summary page for default Math in assignment page");

			// Click on the View Summary
			assignmentDetailsPage.clickViewSummaryPage();
			SMUtils.logDescriptionTC("SMK-13884 - Verify the student doesnot start for the default courses for Math/Reading");
			assignmentDetailsPage.valuesFormatCheckingnotstart();

			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 3)
	public void tc_progessViewSummary_003() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_003-Verify the student is able to attend the Math course via simulator"+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.MATH);
			// Executing math assignments in student dashboard
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,password);

			// Page loading takes more time than expected. Hence providing the wait.
			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);
			studentsPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),Constants.MATH, "95", "5", "30");
			studentsPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Reading course via simulator", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 4)
	public void tc_progessViewSummary_004() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_004-Verify the student is able to attend the Reading course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
				EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
				EventListener eventListner = new EventListener();
				chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.READING);
			// Executing math assignments in student dashboard
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,	password);

			// Page loading takes more time than expected. Hence providing the wait.

		//	SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);
			studentsPage.executeReadingCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),Constants.MATH, "95", "1", "1");
			studentsPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the teacher can view the summary page for Math Course", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 5)
	public void tc_progessViewSummary_005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_progessViewSummary_005 : -Verify the teacher can view the summary page for Math Course"+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			SMUtils.scrollDownPage(driver);
			SMUtils.nap(5);
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),	"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");
			SMUtils.logDescriptionTC(	"SMK-13853- Verify the teacher can view the summary page for default Math in assignment page");

			// Click on the View Summary
			assignmentDetailsPage.clickViewSummaryPage();

			Log.assertThat((assignmentDetailsPage.getTextProgressHeading()).equals(Constants.SUMMARY_HEADER),
					"Progress Header  displayed correctly", "Progress Header not displayed correctly");

			SMUtils.logDescriptionTC(
					"SMK-13858- Verify the sub headings Perfomance Targets, Usage Details and Level Details are displayed in the summary of the student progress");

			List<String> summaryHeaders = assignmentDetailsPage.getViewSummayHeaders();
			Log.message(summaryHeaders.toString());
			Log.assertThat((summaryHeaders).equals(Constants.VIEW_SUMMARY_HEADER),"View Summary Headers are displayed successfully",
					"View Summary Headers are not displayed correctly");

			SMUtils.logDescriptionTC("SMK-13860, SMK-13861,SMK-13862- Verify under the Perfomance Targets,Usage Details,and Level Details heading below the following fields");

			List<String> summaryLabelsFromPage = assignmentDetailsPage.getViewSummayDetails();
			Log.message(summaryLabelsFromPage.toString());
			Log.assertThat((summaryLabelsFromPage).equals(Constants.VIEW_SUMMARY),"Summary Labels are displayed correctly", "Summary Labels are not displayed correctly");

			SMUtils.logDescriptionTC("SMK-13855- Verify the links View Graph, Edit Targets,Print are displayed in the summary of student progress");
			Log.assertThat(assignmentDetailsPage.isdisplayedViewGraph(), "View Graph Button is displayed successfully","View Graph Button is not  displayed");
			Log.assertThat(assignmentDetailsPage.isdisplayedEditTargets(),"Edit Target Button is displayed successfully", "Edit Target Button is not  displayed");
			Log.assertThat(assignmentDetailsPage.isdisplayedPrint(), "Print is displayed successfully","Print is not  displayed");

			assignmentDetailsPage.clickViewSummaryPage();
			SMUtils.logDescriptionTC("SMK-13863- Verify the View Graph link in the summary page");
			Log.assertThat(assignmentDetailsPage.iscourseLevelTextisdisplayed(),"View Graph link is redirected to respective page sucessfuly","View Graph link is redirected to respective page");
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("SMK-1867 -Verify the Primary Target and Secondary target value in the view summary of Math");
			// Verifying the Primary and Secondary Target Value
			assignmentDetailsPage.calculationPrimarySecondary();

			SMUtils.logDescriptionTC("SMK-13864- Verify the Edit Targets link in the summary page");
			assignmentDetailsPage.clickEditTargets();
			Log.assertThat(assignmentDetailsPage.isEditCancelButtonEnable(),"Edit pop up window is displayed sucessfuly", "Edit pop up window is displayed ");
			assignmentDetailsPage.clickeditCancelButton();

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the teacher can view the summary page for Math Course", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 6)
	public void tc_progessViewSummary_006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_progessViewSummary_006-Verify the teacher can view the summary page for Math Course"+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			SMUtils.scrollDownPage(driver);
			SMUtils.nap(5);
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");
			SMUtils.logDescriptionTC("SMK-13854- Verify the teacher can view the summary page for default Reading in assignment page");

			assignmentDetailsPage.clickViewSummaryPage();
			// Verifying the format of the Values
			SMUtils.logDescriptionTC(" SMK-13868 and SMK-13869_Verify the default value target date and default value days to target");
			assignmentDetailsPage.valuesFormatChecking();
			SMUtils.logDescriptionTC("SMK-13866 - Verify the Primary Target and Secondary target value in the view summary of Math Course");
			// Verifying the Primary and Secondary Target Value
			assignmentDetailsPage.calculationPrimarySecondary();

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the teacher can view the summary page for Math Course", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 7)
	public void tc_progessViewSummary_007() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_progessViewSummary_007-Verify the teacher can view the summary page and Values are matched with the Assignment"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			SMUtils.nap(5);
			SMUtils.scrollDownPage(driver);

			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			assignmentDetailsPage.clickViewSummaryPage();

			String studentName = assignmentDetailsPage.completeStudentName(studentFirstName, studentMiddleName,studentLastName);
			// Getting the value from the Assignment Page
			String ipLevelValue = assignmentDetailsPage.ipLevelValueChecking(studentName).trim();
			String currentLevelValue = assignmentDetailsPage.currentLevelValueChecking(studentName).trim();
			String gainValue = assignmentDetailsPage.gainValueChecking(studentName).trim();
			String assignedValue = assignmentDetailsPage.assignedLevelValueChecking(studentName).trim();

			SMUtils.logDescriptionTC("SMK-13871- Verify the IP Level value in the view summary match with the corresponding IP Value in the Assignement page");
			assignmentDetailsPage.viewSummaryvalCheckAsgmt(Constants.SUMMARY_LABEL_IP, ipLevelValue);

			SMUtils.logDescriptionTC("SMK-13872- Verify the Current Level value in the view summary match with the corresponding Current level Value in the Assignement page");
			assignmentDetailsPage.viewSummaryvalCheckAsgmt(Constants.SUMMARY_LABEL_CURRENT, currentLevelValue);

			SMUtils.logDescriptionTC("SMK-13873- Verify the Gain Level value in the view summary match with the corresponding Gain level Value in the Assignement page ");
			assignmentDetailsPage.viewSummaryvalCheckAsgmt(Constants.SUMMARY_LABEL_GAIN, gainValue);

			SMUtils.logDescriptionTC("SMK-13870- Verify the Assigned Level value in the view summary match with the corresponding Assigned Value in the Assignement page");
			assignmentDetailsPage.viewSummaryvalCheckAsgmt(Constants.SUMMARY_LABEL_ASSIGNED, assignedValue);

			SMUtils.logDescriptionTC("SMK-13856 :Verify links text are displayed with the blue color in the summary of student progress");
			assignmentDetailsPage.verifyLinksColorSummary();

			SMUtils.logDescriptionTC("SMK-13859 : Verify the Headings and Sub headings are displayed with Bold and Black color text in the summary of the student progress");
			assignmentDetailsPage.fontBold(browser);

			assignmentDetailsPage.subheadingsColor();

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the students assigned to Focus Reading and Math Focus courses", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 8)
	public void tc_progessViewSummary_008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_progessViewSummary_008-Verify the progress summary graph should not come for the Focus Reading and Math Focus courses"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
						
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(Constants.SM_FOCUS_MATH_GRADE1);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			assignmentPage.clickAssignmentSubMenu();
			tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickCourseName(Constants.SM_FOCUS_READING_GRADE1);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_MATH_GRADE1);

			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			// Verify the student does not start
			assignmentDetailsPage.valuesFormatCheckingnotstartFocus();

			// Verify the Progress heading
			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			String viewSummaryHeader = assignmentDetailsPage.getTextProgressHeading();
			Log.assertThat(viewSummaryHeader.matches(Constants.SUMMARY_HEADER),"Progress header is displayed successfully!", "Progress header is not displayed ");

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Focus  Math course via simulator", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 9)
	public void tc_progessViewSummary_009() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_009-Verify the student is able to attend the Focus  Math course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.SM_FOCUS_MATH_GRADE1);
			// Executing math assignments in student dashboard

			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,password);

			// Page loading takes more time than expected. Hence providing the wait.

			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);

		//	executeSimulator(Constants.SM_FOCUS_MATH_GRADE1, Constants.MATH);
			studentsPage.executeMathCourse( studentUsername, Constants.SM_FOCUS_MATH_GRADE1, "95", "5", "30" );
			studentsPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Focus  Reading course via simulator", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 10)
	public void tc_progessViewSummary_010() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_010-Verify the student is able to attend the Focus  Reading course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.SM_FOCUS_MATH_GRADE1);
			// Executing math assignments in student dashboard
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,password);

			// Page loading takes more time than expected. Hence providing the wait.

			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);

			//executeSimulator(Constants.SM_FOCUS_READING_GRADE1, Constants.READING);
			 studentsPage.executeReadingCourse( studentUsername, Constants.SM_FOCUS_READING_GRADE1, "95", "5", "30" );
			studentsPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the students assigned to custom courses Reading and Math IP Of", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 11)
	public void tc_progessViewSummary_011() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo("tc_progessViewSummary_011 - Verify the students assigned to custom courses Reading and Math IP Of"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			AssignmentsPage assignmentPage = new AssignmentsPage(driver);
			// Create Math custom setting course with IP Off
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(customSettingCourseMath);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.turnOffInitialPlacement();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customSettingCourseMath);
			coursePage.clickCourseName(customSettingCourseMath);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			tHomePage.topNavBar.navigateToCourseListingPage();

			// Create Reading custom setting course with IP Off
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(customSettingCourseReading);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.turnOffInitialPlacement();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customSettingCourseReading);
			coursePage.clickCourseName(customSettingCourseReading);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Create Math custom setting course with IP on
			tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(customSettingCourseMathipon);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customSettingCourseMathipon);
			coursePage.clickCourseName(customSettingCourseMathipon);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			tHomePage.topNavBar.navigateToCourseListingPage();

			// Create Reading custom setting course with IP On
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(customSettingCourseReadingipon);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.clickCreateBtn();
			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customSettingCourseReadingipon);
			coursePage.clickCourseName(customSettingCourseReadingipon);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(customSettingCourseMathipon);

			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			// Verify the student does not start for custom course IP On
			SMUtils.logDescriptionTC("SMK-13886 :Verify the student doesnot start for the custom course by settings IP ON");
			assignmentDetailsPage.valuesFormatCheckingnotstart();

			tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(customSettingCourseMath);

			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("SMK-13887 :Verify the student doesnot start for the custom course by settings IP Off ");

			// Verify the student does not start for custom course IP Off
			assignmentDetailsPage.valuesFormatCheckingnotstart();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Custom Setting Math course via simulator", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 12)
	public void tc_progessViewSummary_012() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_012-Verify the student is able to attend the Custom Setting course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.CUSTOM_MATH_ASSIGMENT_TITLE);
			
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,	password);

			// Page loading takes more time than expected. Hence providing the wait.

			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);

			//executeSimulator(customSettingCourseMath, Constants.MATH);
			 studentsPage.executeMathCourse( studentUsername, customSettingCourseMath, "95", "5", "30" );
             
			studentsPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Custom Setting Reading course via simulator", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 13)
	public void tc_progessViewSummary_013() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_013-Verify the student is able to attend the Focus  Reading course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.CUSTOM_READING_ASSIGMENT_TITLE);
			//String customSettingCourseReading = Constants.CUSTOM_READING_ASSIGMENT_TITLE;
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,password);

			// Page loading takes more time than expected. Hence providing the wait.

			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);

			//executeSimulator(customSettingCourseReading, Constants.READING);
			 studentsPage.executeReadingCourse( studentUsername, customSettingCourseReading, "95", "5", "30" );
			// Executing Math assignments in student dashboard
			studentsPage.logout();
			chromeDriver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Custom Math course via simulator", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 14)
	public void tc_progessViewSummary_014() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_014-Verify the student is able to attend the Custom Math course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.CUSTOM_MATH_ASSIGMENT_TITLE);

			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,password);

			// Page loading takes more time than expected. Hence providing the wait.

			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);

			studentsPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),customSettingCourseMathipon, "95", "5", "5");
			studentsPage.logout();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			chromeDriver.quit();
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the student is able to attend the Custom Setting  Reading IP On course via simulator", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 15)
	public void tc_progessViewSummary_015() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_015-Verify the student is able to attend the Custom Setting  Reading IP On course via simulator"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		//WebDriver driver = null;
		
		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		try {
			Log.message("The subject name is " + Constants.CUSTOM_READING_ASSIGMENT_TITLE);
		
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentUsername,password);

			// Page loading takes more time than expected. Hence providing the wait.

			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(chromeDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(chromeDriver);

			studentsPage.executeReadingCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),customSettingCourseReadingipon, "95", "1", "1");
			studentsPage.logout();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			chromeDriver.quit();
			Log.endTestCase();
		}
	}

	@Test(description = "Verify the teachers view summary for the Math Custom courses by settings by IP OFF and check the Perfomance Details Fields Value", groups = {"SMK-45591", "assignments", "assignmentDetailsPage" }, priority = 16)
	public void tc_progessViewSummary_016() throws Exception {

		Log.testCaseInfo("tc_progessViewSummary_016-Verify the teachers view summary for the Math Custom courses by settings by IP OFF and check the Perfomance Details Fields Value"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			assignmentPage.viewAssignmentDetailsByAssignmentName(customSettingCourseMath);
			SMUtils.nap(5);
			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			SMUtils.logDescriptionTC("SMK-13881 : Verify the view summary should come for the Custom courses by settings by IP OFF ");
			assignmentDetailsPage.valuesFormatCheckingcustomIPoff();

			tHomePage.topNavBar.navigateToAssignmentsPage();

			assignmentPage.viewAssignmentDetailsByAssignmentName(customSettingCourseReading);

			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			SMUtils.logDescriptionTC("SMK-13880 : Verify the view summary should come for the Custom courses by settings by IP ON ");
			assignmentDetailsPage.valuesFormatCheckingcustomIPoff();

			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}

	}

	@Test(description = "Verify the student has In-IP for the default course for Math/Reading", groups = { "SMK-45591","assignments", "assignmentDetailsPage" }, priority = 17)
	public void tc_progessViewSummary_017() throws Exception {
		Log.testCaseInfo("tc_progessViewSummary_017-Verify the student has In-IP for the default course for Math/Reading"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			
			assignmentPage.viewAssignmentDetailsByAssignmentName(customSettingCourseReadingipon);
			SMUtils.nap(5);
			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			assignmentDetailsPage.valuesFormatCheckingDefaultIP();

			tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(customSettingCourseReadingipon);

			// Click on the toggle button for student
			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);
			assignmentDetailsPage.clickViewSummaryPage();

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			SMUtils.logDescriptionTC("SMK-13888 : Verify the student has In-IP for the default course for Math/Reading");
			assignmentDetailsPage.valuesFormatCheckingDefaultIP();

			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
		}

	}

	public void executeSimulator( String studentUsername, String assignmentName, String assignmentType ) throws Exception {
        WebDriver studentDriver = WebDriverFactory.get( browser );
        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        try {
            if ( assignmentType.equals( Constants.MATH ) ) {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Math Course Execution" );
                    try {
                        studentDashboardPage.executeMathCourse( username, assignmentName, "95", "5", "30" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator for Math" );
                    }

                } );

            } else {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Reading Course Execution" );
                    try {
                        studentDashboardPage.executeReadingCourse( username, assignmentName, "100", "5", "15" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator Reading" );
                    }

                } );

            }
        } catch ( Exception e ) {

            Log.message( "Error occurred while running the simulator" );
        }
        studentDriver.quit();
    }

}