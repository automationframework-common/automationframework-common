package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class used to test the API of get assignments listing for Given teacher
 * 
 * @author Baskar.Panchavarnam
 * 
 */

public class GetContentAssignmentDetails extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    private String assignmentID;
    String teacherUsername;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    List<String> studentRumbaIds = new ArrayList<>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );

        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "getAssignmentsListingPositive", groups = { "SMK-51883", "smoke_test_case", "AssignmentDetails", "P1", "API" } )
    public void tcGetAssignmentsListingPositive01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();

        switch ( scenario ) {
            case "tc1-GetAssignment":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );

                    assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                    assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                    assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                }
                HashMap<String, String> createAssignment = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );

                break;

            case "tc2-NoAssignment Nogroup":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                break;

            case "tc3-NoAssignment withgroup":
                GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        HashMap<String, String> response = getAssignmentLists( smUrl, assignmentDetails );

        Log.message( response.get( "statusCode" ) );
        Log.message( response.get( "body" ) );
        Log.assertThat( response.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        // Verifying schema
        VerifySchema( CommonAPIConstants.STATUS_CODE_OK, response );
        validateResponse( assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), response.get( "body" ) );

        Log.testCaseResult();

    }

    @Test ( priority = 2, dataProvider = "getAssignmentsListingNegative", groups = { "SMK-51883", "Assignments", "AssignmentsListing", "P1", "API" } )
    public void tcGetAssignmentsListingNegative01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENTS_LIST;

        switch ( scenario ) {

            case "tc4-Wrong credentials":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );

                break;

            case "tc5-Invalid OrgID":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", "invalid" ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                VerifySchema( CommonAPIConstants.STATUS_CODE_BAD_REQUEST, response );
                Log.message( "Endpoint : " + endPoint );
                Log.message( "Response : " + response );
                break;

            case "tc6-Invalid Header OrgID":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) + "InvalidOrgId" );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );

                break;

            case "tc7-Empty Header OrgID":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, " " );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );

                break;

            case "tc8-Invalid StadffID":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", "invalid" );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                VerifySchema( CommonAPIConstants.STATUS_CODE_BAD_REQUEST, response );
                Log.message( "Endpoint : " + endPoint );
                Log.message( "Response : " + response );

                break;

            case "tc9-Invalid endpoint":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint + "invalidURL", headers, params );
                Log.message( "Endpoint : " + endPoint );
                Log.message( "Response : " + response );
                break;

            case "tc10-Empty Header OrgID":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, " " );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                //      endPoint = endPoint.replace( "{teacherID}", "invalid" ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );

                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        Log.message( response.get( "statusCode" ) );
        Log.message( response.get( "body" ) );
        Log.assertThat( response.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        Log.testCaseResult();
    }

    /**
     * Verify the schema for the api
     *
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = smAPIprocessor.isSchemaValid( FileNameConstatnts.GET_ASSIGNMENTS_SCHEMA_FILE, StatusCode, response.get( AssignmentAPIConstants.BODY_FIELD ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }

        Log.assertThat( isValid, "The schema is valid and mathching", "The schema is not valid and not mathching for the Status code :" + StatusCode );
    }

    /**
     * Data provider to give the positive data
     * 
     * @return
     */

    @DataProvider ( name = "getAssignmentsListingPositive" )
    public Object[][] getAssignmentsListingPositive() {

        Object[][] inputData = {

                { "1. Verify the valid data To Get Assignment listing ", "tc1-GetAssignment", CommonAPIConstants.STATUS_CODE_OK },
                { "2. Verify the valid data To Get Assignment listing API with No assignments and not having classes", "tc2-NoAssignment Nogroup", CommonAPIConstants.STATUS_CODE_OK },
                { "3. Verify the valid data To Get Assignment listing API with No assignments but having classes", "tc3-NoAssignment withgroup", CommonAPIConstants.STATUS_CODE_OK }

        };

        return inputData;
    }

    /**
     * Data provider to give the Negative data
     * 
     * @return
     */

    @DataProvider ( name = "getAssignmentsListingNegative" )
    public Object[][] getAssignmentsListingNegative() {

        Object[][] inputData = { { "4. Verify the status code as 403 for wrong credentials", "tc4-Wrong credentials", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "5. Verify the status code as 400 by applying the invalid org id in path params", "tc5-Invalid OrgID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "6. Verify the status code as 403 when passing an invalid orgid in the headers", "tc6-Invalid Header OrgID", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "7. Verify the status code as 403 when passing an Empty orgid in the headers", "tc7-Empty Header OrgID", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "8. Verify the status code as 200 by applying the invalid staffid in path params", "tc8-Invalid StadffID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "9. Verify the status code as 404 when passing invalid endpoint URL", "tc9-Invalid endpoint", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "10. Verify the status code as 403 when passing an invalid userid in the headers", "tc10-Empty Header OrgID", CommonAPIConstants.STATUS_CODE_FORBIDDAN }, };

        return inputData;
    }

    // DB Query Validation
    public void validateResponse( String staffId, String actualResponse ) {
        JSONObject actualData = new JSONObject( actualResponse );

        if ( !SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {

            JSONArray assignmentListFromResponse = actualData.getJSONArray( "data" );

            HashMap<String, List<String>> assignmentList = SqlHelperAssignment.getAssignmentListingDetails( staffId );
            Log.message( "AssignmentDetails = " + assignmentList );
            HashMap<String, String> studentCount = new HashMap<>();
            HashMap<String, String> productId = new HashMap<String, String>();
            HashMap<String, String> assignmentTitle = new HashMap<String, String>();
            HashMap<String, String> subject = new HashMap<String, String>();

            IntStream.range( 0, assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_ID ).size() ).forEach( i -> {
                String count = SqlHelperAssignment.getStudentCountForAssignment( assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_ID ).get( i ) );
                studentCount.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ), count );
                productId.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ),
                        SqlHelperCourses.getContentBaseDetails( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ) ).get( AssignmentAPIConstants.PRODUCT_ID ) );
                assignmentTitle.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ), assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_NAME ).get( i ) );
                subject.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ),
                        SqlHelperCourses.getContentBaseDetails( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ) ).get( AssignmentAPIConstants.SUBJECT_NAME ) );
            } );

            Log.message( "Student count for Assignments - " + studentCount );
            Log.message( "Product ID for Assignments - " + productId );
            Log.message( "Assignment Title for Assignments - " + assignmentTitle );
            Log.message( "Subject for Assignments - " + subject );

            boolean isTitleVerified = false;
            boolean isSubjectVerified = false;
            boolean isProductIDVerified = false;
            boolean isStudentsCountVerified = false;

            for ( Object assignment : assignmentListFromResponse ) {
                JSONObject assignemntJson = new JSONObject( assignment.toString() );

                if ( subject.get( assignemntJson.get( "id" ).toString() ).equalsIgnoreCase( "Mathematics" ) ) {
                    subject.put( assignemntJson.get( "id" ).toString(), "MATH" );
                } else {
                    subject.put( assignemntJson.get( "id" ).toString(), "READING" );
                }

                if ( assignemntJson.get( "subject" ).toString().equalsIgnoreCase( subject.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isSubjectVerified = true;
                }

                if ( assignemntJson.get( "name" ).toString().equalsIgnoreCase( assignmentTitle.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isTitleVerified = true;
                }

                if ( assignemntJson.get( "productId" ).toString().equalsIgnoreCase( productId.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isProductIDVerified = true;
                }

                if ( assignemntJson.get( "numberStudentsActive" ).toString().equalsIgnoreCase( studentCount.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isStudentsCountVerified = true;
                }

            }

            if ( isTitleVerified ) {
                Log.pass( "Assignment title matched successfully!" );

            } else {
                Log.fail( "Assignment title mismatched!" );

            }

            if ( isSubjectVerified ) {
                Log.pass( "subject matched successfully!" );

            } else {
                Log.fail( "subject mismatched!" );
            }

            if ( isProductIDVerified ) {
                Log.pass( "productId matched successfully!" );

            } else {
                Log.fail( "productId mismatched!" );
            }

            if ( isStudentsCountVerified ) {
                Log.pass( "Active Student Count matched successfully!" );

            } else {
                Log.fail( "Active Student Count mismatched!" );
            }

        } else {
            Log.message( "Data not found exception!!" );
        }
    }
}