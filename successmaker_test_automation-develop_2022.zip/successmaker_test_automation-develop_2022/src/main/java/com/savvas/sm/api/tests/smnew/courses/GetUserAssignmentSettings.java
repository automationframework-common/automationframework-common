package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class GetUserAssignmentSettings extends CourseAPI {

    private String smUrl;
    private String flexSchoolTeacherDetails = null;
    private String flexSchoolStudentDetails = null;
    private String flexSchoolStudentDetailsSecond = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    //Variable declaration
    String userName = null;
    String organizationId = null;
    String teacherId = null;
    String StudentId = null;
    String StudentId1 = null;
    String username = null;
    private String AssignmentUserId;
    String endPoint;

    @BeforeClass(alwaysRun=true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        username = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        flexSchoolStudentDetails = RBSDataSetup.getMyStudent( flexSchool, username );
        flexSchoolStudentDetailsSecond = RBSDataSetup.getMyStudent( flexSchool, username );

    }

    @Test ( priority = 1, dataProvider = "getUserAssignmentSettingsScenarios", groups = { "SMK-52073", "Update Custom by standards course", "Course", "P1", "API", "smoke_test_case" } )
    public void getUserAssignmentSettings( String description, String scenario, String scenario1, String statusCode, String message ) throws Exception {
        Log.testCaseInfo( description );

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        AssignmentAPI assignmentobj = new AssignmentAPI();

        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";

        teacherId = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" );
        organizationId = RBSDataSetup.organizationIDs.get( flexSchool );
        StudentId = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetails, "userId" );
        StudentId1 = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetailsSecond, "userId" );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID_ENDPOINT, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( CourseAPIConstants.OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );

        //Adding Student to a group
        studentRumbaIds = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, token, flexSchool );
        Log.message( "Student ID: " + studentRumbaIds.get( 0 ) );
        assignmentDetails.put( AssignmentAPIConstants.STUDENT_RUMBA_IDS, studentRumbaIds.get( 0 ) );

        if ( scenario1.equals( "Default Math" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
            Log.message( "COURSE ID: " + assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
        } else if ( scenario1.equals( "Default Reading" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
        } else if ( scenario1.equals( "Focus Math" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_1 );
        } else if ( scenario1.equals( "Focus Reading" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING_1 );
        } else if ( scenario1.equals( "Custom Math" ) ) {
            String customCourseID = createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
            Log.message( customCourseID );
            assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, customCourseID );
        } else if ( scenario1.equals( "Custom Reading" ) ) {
            String customCourseID = createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
            Log.message( customCourseID );
            assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, customCourseID );
        } else if ( scenario1.equals( "Invalid Student ID" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.STUDENT_RUMBA_IDS, AssignmentAPIConstants.INVALID_STUDENT_ID );
        } else if ( scenario1.equals( "Invalid Student ID" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.STUDENT_RUMBA_IDS, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student2" ), "userId" ) );
        } else if ( scenario1.equals( "Invalid Student&Assignment from Diff Org" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.STUDENT_RUMBA_IDS, AssignmentAPIConstants.INVALID_STUDENT_ID );
        }

        //Assigning the course to a student
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> responseSecondStudent = new HashMap<>();

        //Assigning assignment to student
        String customCourseId = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );
        response = addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, customCourseId, flexSchool, studentRumbaIds.get( 0 ) );
        Log.message( "assighnment response : " + response );
        String assignmentID = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,assignmentId" );

        if ( scenario.equals( "Reading_RemovedStudentFromAssignment" ) ) {

            responseSecondStudent = addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, customCourseId, flexSchool, studentRumbaIds.get( 1 ) );
            Log.message( "assighnment response : " + responseSecondStudent );
            String assignmentID1 = SMUtils.getKeyValueFromResponse( responseSecondStudent.get( Constants.REPORT_BODY ), "data,assignmentId" );

            AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID1 );
            Log.message( "AssignmentUserId : " + AssignmentUserId );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
            HashMap<String, String> getresponse = assignmentobj.removeStudentAssignment( smUrl, assignmentDetails, endpoint );
            Log.message( "status code of removeStudentAssignment " + getresponse.get( "statusCode" ) );
            Log.message( getresponse.get( "body" ) );
            Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        }

        if ( scenario.equals( "Reading_RemovedStudentFromAssignmentAndAgainAssigned" ) ) {
            AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
            HashMap<String, String> getresponse = assignmentobj.removeStudentAssignment( smUrl, assignmentDetails, endpoint );
            Log.message( "status code of removeStudentAssignment " + getresponse.get( "statusCode" ) );
            Log.message( getresponse.get( "body" ) );
            Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                    "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

            response = addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, customCourseId, flexSchool, studentRumbaIds.get( 0 ) );
            Log.message( "assighnment response 2nd time: " + response );
        }

        //Assigning assignment ID
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_ID, assignmentID );

        if ( scenario1.equals( "Invalid Assignment ID" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_ID, AssignmentAPIConstants.INVALID_ASSIGMENT_ID );
        } else if ( scenario1.equals( "Invalid Assignment ID - Non Existing" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_ID, AssignmentAPIConstants.NON_EXISTING_ASSIGMENT_ID );
        } else if ( scenario1.equals( "Invalid Student&Assignment from Diff Org" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_ID, AssignmentAPIConstants.MATH );
        } else if ( scenario1.equals( "Invalid Authorization" ) ) {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
        } else if ( scenario1.equals( "Invalid Org-ID" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, AssignmentAPIConstants.ORG_ID );
        } else if ( scenario1.equals( "Invalid Org-ID Enpoint" ) ) {
            assignmentDetails.put( CourseAPIConstants.OWNER_ORG_ID, CommonAPIConstants.INVALID_ORG_ID );
        } else if ( scenario1.equals( "Invalid Org-ID Null" ) ) {
            assignmentDetails.put( CourseAPIConstants.OWNER_ORG_ID, "null" );
        } else if ( scenario1.equals( "Invalid Staff-ID Null" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID_ENDPOINT, "null" );
        } else if ( scenario1.equals( "Invalid Staff-ID" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID_ENDPOINT, AssignmentAPIConstants.INVALID_STUDENT_ID );
        } else if ( scenario1.equals( "Invalid Student ID with No assignment" ) ) {
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_ID, AssignmentAPIConstants.NON_EXISTING_ASSIGMENT_ID );
        }

        HashMap<String, String> assignResponse = assignmentobj.getUserAssignmentSetting( smUrl, assignmentDetails );
        Log.message( "Get User Assignment Settings Response: " + assignResponse );
        //Assertion
        if ( scenario1.contains( "Invalid" ) && smUrl.equalsIgnoreCase( Constants.NIGHTLY_SM_URL ) ) {
            Log.softAssertThat( verifyExceptionMessage( assignResponse.get( "body" ), message ), "Exception getting as expected", "Message getting as not expected" );
        } else if ( scenario.equals( "Reading_RemovedStudentFromAssignment" ) && smUrl.equalsIgnoreCase( Constants.NIGHTLY_SM_URL ) ) {
            Log.softAssertThat( verifyExceptionMessage( assignResponse.get( "body" ), message ), "Exception getting as expected", "Message getting as not expected" );
        } else if ( smUrl.equalsIgnoreCase( Constants.NIGHTLY_SM_URL ) ){
            Log.softAssertThat( verifyMessage( assignResponse.get( "body" ), message ), "Message getting as expected", "Message getting as not expected" );
        }
        Log.softAssertThat( assignResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + assignResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + assignResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for Custom Course by Settings scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getUserAssignmentSettingsScenarios" )
    public Object[][] getUserAssignmentSettings() {
        Object[][] inputData = { { "TC01_Verify the status code is 200 when valid data is given for assignment which has been created from default math.", "Math", "Default Math", "200", "Operation succeeded!" },
                { "TC02_Verify the status code is 200 when valid data is given for assignment which has been created from default reading.", "Reading", "Default Reading", "200", "Operation succeeded!" },
                { "TC03_Verify the status code is 200 when valid data is given for assignment which has been created from custom math", "Math", "Custom Math", "200", "Operation succeeded!" },
                { "TC04_Verify the status code is 200 when valid data is given for assignment which has been created from custom reading", "Reading", "Custom Reading", "200", "Operation succeeded!" },
                { "TC05_Verify the status code is 200 when valid data is given for assignment which has been created from focus math.", "Math", "Focus Math", "200", "Operation succeeded!" },
                { "TC06_Verify the status code is 200 when valid data is given for assignment which has been created from focus reading.", "Reading", "Focus Reading", "200", "Operation succeeded!" },

                { "TC08_Verify the status code is 200 when sudent id is given which has been removed from assignment and again added to same assignment.", "Reading_RemovedStudentFromAssignmentAndAgainAssigned", "Default Reading", "200",
                        "Operation succeeded!" },

                { "TC09_Verify the status code is 400 when invalid student id is given. & TC10_Verify the status code is 200 when non existing student id is given.", "Math", "Invalid Student ID", "400",
                        "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC11_Verify the status code is 200 when student id is given which is not belongs to respective assignment.", "Math", "Invalid Student ID with No assignment", "200", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC12_Verify the status code is 400 when invalid assignment id($$) is given.", "Reading", "Invalid Assignment ID", "400", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC13_Verify the status code is 200 when non existing assignment id(6757647476) is given.", "Reading", "Invalid Assignment ID - Non Existing", "200", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC14_Verify the status code is 400 when student id and course id is given which is belongs to different org.", "Reading", "Invalid Student&Assignment from Diff Org", "400", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC15_Verify the status code is 200 when sudent id is given which has been removed from assignment.", "Reading_RemovedStudentFromAssignment", "Custom Reading", "200", "com.savvas.core.exceptions.DataNotFoundException" },

                { "TC18_Verify the status code is 401 when invalid authorization is given", "Math", "Invalid Authorization", "401", "java.lang.Exception" },
                { "TC19_Verify the status code is 403 when invalid Org-ID is given in header", "Reading", "Invalid Org-ID", "403", "org.springframework.security.access.AccessDeniedException" },
                { "TC20_Verify the status code is 400 when invalid Org-ID is given & TC25_Verify the status code is 400 when Different org-ID is given ", "Reading", "Invalid Org-ID Enpoint", "400",
                        "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC21_Verify the status code is 400 when Null Org-ID is given", "Reading", "Invalid Org-ID Null", "400", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC22_Verify the status code is 400 when Null Staff-ID is given", "Reading", "Invalid Staff-ID Null", "400", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC23_Verify the status code is 400 when Different Staff-ID is given & TC24_Verify the status code is 400 when Invalid Staff-ID is given", "Reading", "Invalid Staff-ID", "400",
                        "com.savvas.core.exceptions.BusinessRuleViolationException" },

        };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    /**
     * Verifying the message
     * 
     * @param actualResponse
     * @param message
     * @return boolean
     * @throws IOException
     */
    public boolean verifyMessage( String actualResponse, String message ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).equalsIgnoreCase( message ) ) {
            Log.message( "status Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying status!" );
        }
        return flag;
    }

    /**
     * Verifying the Exception information
     * 
     * @param actualResponse
     * @param exception
     * @return boolean
     * @throws IOException
     */
    public boolean verifyExceptionMessage( String actualResponse, String exception ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        return flag;
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     * @throws IOException
     */
    public boolean verifyResponse( String actualResponse, String statusCode ) throws IOException {
        boolean isVerified = false;

        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getUserAssignmentSettingsSchema", statusCode, actualResponse ), "Schema is returned as expected.", "Schema is not as expected." );

        return isVerified;
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( StudentId );
            studentRumbaIds.add( StudentId1 );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            Log.message( "groupDetails is " + groupDetails );
            GroupAPI GroupAPIobj = new GroupAPI();
            response = GroupAPIobj.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.message( "response for group creation is " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    //Assigning assignment to student
    public HashMap<String, String> addAssignmentsToStudents( String statusCode, String courseId, String school, String studentRumbaId ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> assignCourseToTheStudent = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        List<String> courseIdList = new ArrayList<>();
        studentRumbaIds.add( studentRumbaId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            courseIdList.add( courseId );

            AssignmentAPI assignmentobj = new AssignmentAPI();
            assignCourseToTheStudent = assignmentobj.assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIdList );
            return assignCourseToTheStudent;

        } catch ( Exception e ) {
            Log.message( "Issue occured in addAssignmentsToStudents: " + assignCourseToTheStudent );
            return assignCourseToTheStudent;
        }
    }
}
