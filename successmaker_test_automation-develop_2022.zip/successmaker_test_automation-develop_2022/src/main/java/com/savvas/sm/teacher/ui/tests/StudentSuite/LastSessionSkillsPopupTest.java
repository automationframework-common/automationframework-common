package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
/**
 * This java class file contains test cases for jira story SMK-43903.
 * 
 * @author baskar.panchavarnam
 *
 */
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LastSessionSkillsPopupTest extends BaseTest {

    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private String teacherId;
    private String orgId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    ArrayList<String> studentDetails = null;
    private AtomicReference<String> schoolUsed = new AtomicReference<String>();
    String teacherDetails = null;

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        studentDetails = new ArrayList<String>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<String>();
        studentUserNames = new ArrayList<String>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );
    }

    @Test ( description = "Verify the 'Last Session Skills' pop up for 'Custom Math' course", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 1 )
    public void tcSMLastSessionSkills1() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkills1: Verify the 'Last Session Skills' pop up for 'Custom Math' course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            String customCourse = "Custom Math_" + System.nanoTime();

            coursePage.clickCourseName( Constants.MATH );

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.MATH );

            teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM         
            teacherHomePage.topNavBar.signOutfromSM();

            WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

            //Executing math assignments and Reading in student dashboard
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), customCourse, "95", "1", "5" );
            studentDashboardPage.logout();
            chromeDriver.quit();

            //Login with teacher credential
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            String studentDetail = studentDetails.get( 0 );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );

            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( customCourse );
            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Popup Header 
            SMUtils.logDescriptionTC( "SMK-11743 - Verify the skill pop up header for Custom 'Math' course in 'Last Session Skills' section" );
            Log.assertThat( studentPage.checkPopupTitle().equals( Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER ), "Last session skills Popup title displays correctly for Custom Math Course", "Incorrect title displays in Popup" );

            // Check close button 
            SMUtils.logDescriptionTC( "SMK-11766 - Verify the 'Close' button in 'Last session skills popup'" );
            Boolean closeButtonState = studentPage.checkCloseButton();
            Log.assertThat( closeButtonState.equals( Constants.STATUSTRUE ), "Close button displays in Last session skills Popup", "Close button is not available" );

            // Check Point value in popup 
            SMUtils.logDescriptionTC( "SMK-11745 - Verify the 'Correct attempts / Total attempt' displays correctly in skill pop up for Custom 'Math' course" );
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );

            // Check Skill name in popup 
            SMUtils.logDescriptionTC( "SMK-11747 : Verify the LO number and the description in 'Last session skills popup'" );
            Log.assertThat( studentPage.getRecentSkillNameText().contains( studentPage.getRecentSkillNameTextPopup() ), "SkillName displays correctly in popop", "Skill name is incorrect" );

            // Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11741 : Verify the skill name displays correctly on bottom of the progress bar in black bold font for Default Math course" );
            Log.assertThat( studentPage.getSkillnameFontInPopup().equals( Constants.LastSessionSkillTested.COLOR_BLACK ), "SkillName text color displays correctly in Black color", "Skill name is not displaying in black color" );

            // Check Background color of Progressbar in popup
            SMUtils.logDescriptionTC( "SMK-11744 : Verify the Progress bar is displaying with green color in skill pop up for Custom Math course" );
            Log.assertThat( studentPage.progressBarBGColorInPopup().equals( Constants.LastSessionSkillTested.BG_COLOR_GREEN ), "Progressbar Background color displays correctly in Green for Custom Math",
                    "Progressbar color displaying incorrectly for Custom Math" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Last Session Skills' pop up for 'Default Reading' course", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 1 )
    public void tcSMLastSessionSkills2() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkills2: Verify the 'Last Session Skills' pop up for 'Default Reading' course' section <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Course Listing Page 
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student 
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM 
            teacherHomePage.topNavBar.signOutfromSM();

            WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

            //Executing Reading assignment in student dashboard 
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );

            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), "Reading", "95", "1", "2" );
            studentDashboardPage.logout();
            chromeDriver.quit();

            //Login with teacher credential 
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Student Page 
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            String studentDetail = studentDetails.get( 0 );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );

            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( Constants.READING );

            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Popup Header 
            SMUtils.logDescriptionTC( "SMK-11748 - Verify the skill pop up header for 'Default Reading' course in 'Last Session Skills' section" );
            Log.assertThat( studentPage.checkPopupTitle().equals( Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER ), "Last session skills Popup title displays correctly for Custom Math Course", "Incorrect title displays in Popup" );

            // Check Point value in popup 
            SMUtils.logDescriptionTC( "SMK-11751 - Verify the 'Correct attempts / Total attempt' displays correctly in skill pop up for 'Default Reading' course" );
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );

            // Check Background color of Progressbar in popup
            SMUtils.logDescriptionTC( "SMK-11749 : Verify the Progress bar is displaying with blue color in skill pop up for Default Reading course " );
            Log.assertThat( studentPage.progressBarBGColorReadingInPopup().equals( Constants.LastSessionSkillTested.BG_COLOR_BLUE ), "Progressbar Background color displays correctly in Blue for Default Reading",
                    "Progressbar color displaying incorrectly for Default Reading" );

            // Check %  value in text color in popup 
            SMUtils.logDescriptionTC( "SMK-11750 : Verify the % correct value displays correctly in white color on progress bar in skill pop up for Default Reading course" );
            Log.assertThat( studentPage.progressBarTextColorInReadingPopup().equals( Constants.LastSessionSkillTested.COLOR_WHITE ), "% value text colors displays correctly in White color for Default Reading",
                    "% value text color displaying incorrectly for Default Reading" );

            //Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11752 : Verify the skill name displays correctly on bottom of the progress bar in black bold font for Default Reading course " );
            Log.assertThat( studentPage.getSkillnameFontInPopup().equals( Constants.LastSessionSkillTested.COLOR_BLACK ), "SkillName text color displays correctly in Black color", "Skill name is not displaying in black color" );

            // Check Skill name in popup 
            SMUtils.logDescriptionTC( "SMK-11753 : Verify the LO number and the description in 'Last session skills popup' for Default Reading course" );
            Log.assertThat( studentPage.getRecentSkillNameText().contains( studentPage.getRecentSkillNameTextPopup() ), "SkillName displays correctly in popop", "Skill name is incorrect" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Last Session Skills' pop up for 'Custom Reading' course", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 1 )
    public void tcSMLastSessionSkills3() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkills3: Verify the 'Last Session Skills' pop up for 'Custom Reading' course' section<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student 
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            String customReadingCourse = "Custom Reading_" + System.nanoTime();

            //Get CourseLising Page

            coursePage.clickCourseName( Constants.READING );

            coursePage.copyOfCourse( customReadingCourse, Constants.STANDARDS, Constants.READING );

            teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customReadingCourse );

            Log.message( "Created custom reading course : " + customReadingCourse );
            coursePage.clickAssignBtn();

            coursePage.addCourseToStudents();

            // SignOut from SM 
            teacherHomePage.topNavBar.signOutfromSM();

            WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

            //Executing Reading assignment in student dashboard 
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), customReadingCourse, "95", "1", "2" );
            studentDashboardPage.logout();
            chromeDriver.quit();

            //Login with teacher credential 
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Student Page 
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            String studentDetail = studentDetails.get( 0 );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );

            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( customReadingCourse );

            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Popup Header 
            SMUtils.logDescriptionTC( "SMK-11754 -  Verify the Header and Progress bar displayed in skill pop up for 'Custom Reading' course" );
            Log.assertThat( studentPage.checkPopupTitle().equals( Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER ), "Last session skills Popup title displays correctly for Custom Math Course", "Incorrect title displays in Popup" );

            // Check Point value in popup 
            SMUtils.logDescriptionTC( "SMK-11755 - Verify the 'Correct attempts / Total attempt' displays correctly in skill pop up for 'Reading' course" );
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );

            //Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11756 : Verify the skill name displays correctly on bottom of the progress bar in black bold font " );
            Log.assertThat( studentPage.getSkillnameFontInPopup().equals( Constants.LastSessionSkillTested.COLOR_BLACK ), "SkillName text color displays correctly in Black color", "Skill name is not displaying in black color" );

            // Check Skill name in popup 
            SMUtils.logDescriptionTC( "SMK-11757 : Verify the LO number and the description in 'Last session skills popup' for Custom Reading" );
            Log.assertThat( studentPage.getRecentSkillNameText().contains( studentPage.getRecentSkillNameTextPopup() ), "SkillName displays correctly in popop", "Skill name is incorrect" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Last Session Skills' pop up for 'SM Focus Math' course", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 1 )
    public void tcSMLastSessionSkills4() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkills4 : Verify the 'Last Session Skills' pop up for 'SM Focus Math' course' section' <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Course Listing Page 
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student 
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE_I );

            coursePage.clickAssignBtn();

            coursePage.addCourseToStudents();

            // SignOut from SM 
            teacherHomePage.topNavBar.signOutfromSM();

            WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

            //Executing math assignments and Reading in student dashboard 
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.SM_FOCUS_MATH_GRADE1, "95", "1", "5" );

            studentDashboardPage.logout();
            chromeDriver.quit();

            //Login with teacher credential 
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page 
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            String studentDetail = studentDetails.get( 0 );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );

            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( Constants.SM_FOCUS_MATH_GRADE1 );

            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Popup Header 
            SMUtils.logDescriptionTC( "SMK-11758 - Verify the skill pop up header for 'SM Focus Math' course in 'Last Session Skills' section" );
            Log.assertThat( studentPage.checkPopupTitle().equals( Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER ), "Last session skills Popup title displays correctly for 'SM Focus Math: Grade 1'", "Incorrect title displays in Popup" );

            // Check Point value in popup 
            SMUtils.logDescriptionTC( "SMK-11761 - Verify the 'Correct attempts / Total attempt' displays correctly in skill pop up for 'SM Focus Math' course" );
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );

            // Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11759 : Verify the skill name displays correctly on bottom of the progress bar in black bold font for SM Focus Math course " );
            Log.assertThat( studentPage.getSkillnameFontInPopup().equals( Constants.LastSessionSkillTested.COLOR_BLACK ), "SkillName text color displays correctly in Black color", "Skill name is not displaying in black color" );

            // Check Skill name in popup 
            SMUtils.logDescriptionTC( "SMK-11760 : Verify the LO number and the description in 'Last session skills popup' for SM Focus Math" );
            Log.assertThat( studentPage.getRecentSkillNameText().contains( studentPage.getRecentSkillNameTextPopup() ), "SkillName displays correctly in popop", "Skill name is incorrect" );
            Log.testCaseResult();

            // SignOut from SM 
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Last Session Skills' pop up for 'SM Focus Reading' course", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 2 )
    public void tcSMLastSessionSkills5() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcSMLastSessionSkills5 : Verify the 'Last Session Skills' pop up for 'SM Focus Reading' course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Course Listing Page 
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student 
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( Constants.SM_FOCUS_READING_GRADE1 );

            coursePage.clickAssignBtn();

            coursePage.addCourseToStudents();

            // SignOut from SM 
            teacherHomePage.topNavBar.signOutfromSM();

            WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

            //Executing math assignments and Reading in student dashboard 
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.SM_FOCUS_READING_GRADE1, "100", "1", "2" );

            studentDashboardPage.logout();
            chromeDriver.quit();

            //Login with teacher credential 
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page 
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            String studentDetail = studentDetails.get( 0 );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );

            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( Constants.SM_FOCUS_READING_GRADE1 );

            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Popup Header 
            SMUtils.logDescriptionTC( "SMK-11762 - Verify the skill pop up header for 'SM Focus Reading' course in 'Last Session Skills' section" );
            Log.assertThat( studentPage.checkPopupTitle().equals( Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER ), "Last session skills Popup title displays correctly for 'SM Focus Math: Grade 1'",
                    "Incorrect title displays in Popup" );

            // Check Point value in popup 
            SMUtils.logDescriptionTC( "SMK-11763 - Verify the 'Correct attempts / Total attempt' displays correctly in skill pop up for 'SM Focus Reading' course" );
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );

            // Check Skill name in popup 
            SMUtils.logDescriptionTC( "SMK-11747 : Verify the LO number and the description in 'Last session skills popup' for SM Focus Reading course" );
            Log.assertThat( studentPage.getRecentSkillNameText().contains( studentPage.getRecentSkillNameTextPopup() ), "SkillName displays correctly in popop", "Skill name is incorrect" );

            //Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11764 : Verify the skill name displays correctly on bottom of the progress bar in black bold font for SM Focus Reading course" );
            Log.assertThat( studentPage.getSkillnameFontInPopup().equals( Constants.LastSessionSkillTested.COLOR_BLACK ), "SkillName text color displays correctly in Black color", "Skill name is not displaying in black color" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Last Session Skills' pop up for 'Default Math' course", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 2 )
    public void tcSMLastSessionSkills6() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkills6: SMK-11738 : Verify the Progress bar is displaying with green color in skill pop up for 'Default Math' course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            coursePage.addCourseToStudents();

            // SignOut from SM         
            teacherHomePage.topNavBar.signOutfromSM();

            WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

            //Executing math assignments and Reading in student dashboard
            String studentUsername = studentUserNames.get( 0 );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.MATH, "75", "1", "5" );
            studentDashboardPage.logout();
            chromeDriver.quit();

            //Login with teacher credential
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            String studentDetail = studentDetails.get( 0 );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );
            studentPage.clickRecentSkillName();

            // Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11767 : Verify the 'Close' icon in 'Last session skills popup'" );
            Boolean closeIconState = studentPage.checkCloseIcon();
            Log.assertThat( closeIconState.equals( Constants.STATUSTRUE ), "Close icon displays in Last session skills Popup", "Close icon is not available" );

            // Check skill name text color in popup
            SMUtils.logDescriptionTC( "SMK-11739 : Verify the '% correct' value displays correctly in black color on progress bar in skill pop up for 'Default Math' course" );
            Log.assertThat( studentPage.getSkillnameFontInPopup().equals( Constants.LastSessionSkillTested.COLOR_BLACK ), "SkillName text color displays correctly in Black color", "Skill name is not displaying in black color" );

            // Check Background color of Progressbar in popup
            SMUtils.logDescriptionTC( "SMK-11738 : Verify the Progress bar is displaying with green color in skill pop up for 'Default Math' course" );
            Log.assertThat( studentPage.progressBarBGColorInPopup().equals( Constants.LastSessionSkillTested.BG_COLOR_GREEN ), "Progressbar Background color displays correctly in Green for Default Math",
                    "Progressbar color displaying incorrectly for Default Math" );
            String loNumber = studentPage.getLONumberfromSkillsPopup();

            // Check corresponding LO page appears on clicking LO number from skills popup
            SMUtils.logDescriptionTC( "SMK-11768 : Verify the clicking LO number link from Skill popup navigates to corresponding LO viewer -" );
            Log.assertThat( studentPage.getLONumberfromUrl().contains( loNumber ), "Corresponding LO viewer page displays on clicking LO number", "Corresponding LO page is not displaying" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}