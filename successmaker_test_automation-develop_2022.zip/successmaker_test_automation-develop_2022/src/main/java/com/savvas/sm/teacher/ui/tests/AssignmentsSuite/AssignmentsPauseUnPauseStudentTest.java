package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Assignments;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * The JIRA ID of the stories - SMK- 39220
 *
 * @author Hariprasath
 *
 */
@Listeners(EmailReport.class)
public class AssignmentsPauseUnPauseStudentTest extends BaseTest {
	private String smUrl;
	private String browser;
	private static String username = null;
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String token = null;
	private static String teacherDetails;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String teacherID;
	String studentDetails;
	String studentDetailsSecond;
	String studentSMDetails;
	String studentSMDetailsSecond;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	String groupName = null;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		UserAPI userAPIMethod = new UserAPI();

		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);

		// Student SM Details
		studentSMDetails = userAPIMethod
				.getStudentDetailsByStudentId(SMUtils.getKeyValueFromResponse(studentDetails, "userId"), teacherID,
						RBSDataSetup.organizationIDs.get(school), token)
				.get(Constants.REPORT_BODY);
		studentSMDetailsSecond = userAPIMethod
				.getStudentDetailsByStudentId(SMUtils.getKeyValueFromResponse(studentDetailsSecond, "userId"),
						teacherID, RBSDataSetup.organizationIDs.get(school), token)
				.get(Constants.REPORT_BODY);

		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsSecond, "userId"));
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Student SM Details
		studentSMDetails = userAPIMethod
				.getStudentDetailsByStudentId(SMUtils.getKeyValueFromResponse(studentDetails, "userId"), teacherID,
						RBSDataSetup.organizationIDs.get(school), token)
				.get(Constants.REPORT_BODY);
		studentSMDetailsSecond = userAPIMethod
				.getStudentDetailsByStudentId(SMUtils.getKeyValueFromResponse(studentDetailsSecond, "userId"),
						teacherID, RBSDataSetup.organizationIDs.get(school), token)
				.get(Constants.REPORT_BODY);

		// Group
		groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");

	}

	@Test(description = "Verify teacher is able to pause for all the students", groups = { "SMK-39220", "assignments",
			"assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPause_001: SMK-8441 - Verify teacher is able to pause for all the students."
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			CoursesPage coursepage = new CoursesPage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			coursepage.clickCourseName(Constants.MATH);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify teacher is able to resume for all the students", groups = { "SMK-39220", "assignments",
			"assignmentDetailsPage" }, priority = 2)
	public void tc_AssignmentsPause_002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo("tc_AssignmentsPause_002: SMK-8442 - Verify teacher is able to resume for all the students."
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);
			
			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify Resume for all students
			assignmentDetailsPage.resumeAllAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the Pauses After Resume all
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment resumed at asignment level for all successfully",
					"Assignment Paused for all successfully");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify If teacher is able to Pause for single student", groups = { "SMK-39220", "assignments",
			"assignmentDetailsPage" }, priority = 3)
	public void tc_AssignmentsPause_003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPause_003: SMK-8443 - Verify If teacher is able to Pause for single student."
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify Pause for one student
			assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis();
			assignmentDetailsPage.pauseAssignmentForStudentTab();
			assignmentDetailsPage.clickPauseButtononPopUpPage();
			SMUtils.nap(5);// Waiting for toast message disappear
			Log.assertThat(assignmentDetailsPage.isAssignmentPaused(),
					"Assignment paused successfully", "Assignment has not Paused");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify if teacher is able to resume for single student", groups = { "SMK-39220", "assignments",
			"assignmentDetailsPage" }, priority = 4)
	public void tc_AssignmentsPause_004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPause_004: SMK-8444- Verify if teacher is able to resume for single student."
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify resume for one student
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify if teacher is able to cancel during the pause operation for all students", groups = {
			"SMK-39220", "assignments", "assignmentDetailsPage" }, priority = 5)
	public void tc_AssignmentsPause_005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentsPause_005: SMK-8445: Verify if teacher is able to cancel during the pause operation for all students."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify Pause all student and click cancel
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseAssignmentForStudentcancelButton();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify if teacer is able to cancel during the resume operation for all students", groups = {
			"SMK-39220", "assignments", "assignmentDetailsPage" }, priority = 6)
	public void tc_AssignmentsPause_006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentsPause_006: SMK-8446 - Verify if teacer is able to cancel during the resume operation for all students."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify Resume all and click cancel
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear
			assignmentDetailsPage.resumeAllAssignment();

			// Click Cancel Button
			assignmentDetailsPage.resumeAssignmentForStudentcancelButton();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify if teacher is able to cancel during the pause operation for single student", groups = {
			"SMK-39220", "assignments", "assignmentDetailsPage" }, priority = 7)
	public void tc_AssignmentsPause_007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo(
				"tc_AssignmentsPause_007: SMK-8447 Verify if teacher is able to cancel during the pause operation for single student."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify the Pause for one student and click cancel
			assignmentDetailsPage.resumeAllAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			SMUtils.nap(5);// Waiting for toast message disappear
			assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis();
			assignmentDetailsPage.pauseAssignmentForStudentTab();
			assignmentDetailsPage.pauseAssignmentForStudentcancelButton();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify if teacher is able to cancel during the resume operation for single student", groups = {
			"SMK-39220", "assignments", "assignmentDetailsPage" }, priority = 8)
	public void tc_AssignmentsPause_008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentsPause_008: SMK-8448:- Verify if teacher is able to cancel during the resume operation for single student."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify the Resume for one student and click cancel
			assignmentDetailsPage.pauseAssignmentForStudentTab();
			assignmentDetailsPage.clickPauseButtononPopUpPage();
			SMUtils.nap(5);// Waiting for toast message disappear
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.resumeAssignmentForStudentcancelButton();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify teacher is able to pause and resume for a single student student", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo("Verify teacher is able to pause and resume for a single student student"
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursepage = new CoursesPage(driver);
			// Get Assignments Page
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			coursepage.clickCourseName(Constants.MATH);
			coursepage.clickAssignBtn();

			coursepage.addCourseToStudents();
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify Pause All Student
			assignmentDetailsPage.resumeAllAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			SMUtils.nap(5);// Waiting for toast message disappear
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);

			// Verify resume for one student
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			SMUtils.logDescriptionTC(
					"SMK-20836 - TC01_Verify Teacher is able to Pause and Resume the Default Math Assignment for a student from Assignment page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "TC02_Verify Teacher is able to Pause and Resume All of the Custom Math by settings Assignment Assignment page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo(
				"TC02_Verify Teacher is able to Pause and Resume All of the Custom Math by settings Assignment Assignment page"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursepage = new CoursesPage(driver);
			// Get Assignments Page
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.SETTINGS, Constants.MATH);
			tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			coursepage.clickFromCourseListingPage(newlyCreatedCourse);

			SMUtils.waitForSpinnertoDisapper(driver);

			coursepage.clickAssignBtn();

			coursepage.addCourseToStudents();
			assignmentsPage.clickAssignmentSubMenu();

			assignmentsPage.clickColumnnAndSort(Assignments.COLUMN_ASSIGNMENT_TITILE, Constants.DESCENDING);

			coursepage.clickOnTheHoveredAssignment(newlyCreatedCourse);

			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(newlyCreatedCourse);

			// Verify resume for one student
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			SMUtils.logDescriptionTC(
					"SMK-20837 - TC02_Verify Teacher is able to Pause and Resume All of the Custom Math by settings Assignment Assignment page");
			SMUtils.logDescriptionTC(
					"SMK-20848 - TC13_Verify Teacher is able to Pause and Resume All of the Shared Custom Math by settings Assignment from Assignment page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify teacher is able to pause and resume for a single student student", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo("Verify teacher is able to pause and resume for a single student student"
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursepage = new CoursesPage(driver);
			// Get Assignments Page
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			coursepage.clickCourseName(Constants.READING);
			coursepage.clickAssignBtn();

			coursepage.addCourseToStudents();
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.READING);

			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.READING);

			// Verify resume for one student
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			SMUtils.logDescriptionTC(
					"SMK-20840 - TC05_Verify Teacher is able to Pause and Resume the Default Reading Assignment for a student from Assignment page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "TC06_Verify Teacher is able to Pause and Resume All of the Custom Reading by settings Assignment Assignment page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"TC06_Verify Teacher is able to Pause and Resume All of the Custom Reading by settings Assignment Assignment page"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursepage = new CoursesPage(driver);
			// Get Assignments Page
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.SETTINGS, Constants.READING);

			tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			coursepage.clickFromCourseListingPage(newlyCreatedCourse);

			SMUtils.waitForSpinnertoDisapper(driver);

			coursepage.clickAssignBtn();

			coursepage.addCourseToStudents();
			assignmentsPage.clickAssignmentSubMenu();
			assignmentsPage.clickColumnnAndSort(Assignments.COLUMN_ASSIGNMENT_TITILE, Constants.DESCENDING);
			coursepage.clickOnTheHoveredAssignment(newlyCreatedCourse);

			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(newlyCreatedCourse);

			// Verify resume for one student
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			SMUtils.logDescriptionTC(
					"SMK-20841 - TC06_Verify Teacher is able to Pause and Resume All of the Custom Reading by settings Assignment Assignment page");
			SMUtils.logDescriptionTC(
					"SMK-20847 - TC12_Verify Teacher is able to Pause and Resume the Shared Custom Reading Assignment for a student from Assignment page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "TC11_Verify Teacher is able to Pause and Resume the Shared Custom Focus Math Assignment for a student from Assignment page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"TC11_Verify Teacher is able to Pause and Resume the Shared Custom Focus Math Assignment for a student from Assignment page"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursepage = new CoursesPage(driver);
			// Get Assignments Page
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1);

			tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			coursepage.clickFromCourseListingPage(newlyCreatedCourse);

			SMUtils.waitForSpinnertoDisapper(driver);

			coursepage.clickAssignBtn();

			coursepage.addCourseToStudents();
			assignmentsPage.clickAssignmentSubMenu();
			assignmentsPage.clickColumnnAndSort(Assignments.COLUMN_ASSIGNMENT_TITILE, Constants.DESCENDING);
			coursepage.clickOnTheHoveredAssignment(newlyCreatedCourse);

			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(newlyCreatedCourse);

			// Verify resume for one student
			assignmentDetailsPage.resumeAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(Boolean.FALSE.equals(assignmentDetailsPage.isStudentPaused()),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			SMUtils.logDescriptionTC(
					"SMK-20846 - TC11_Verify Teacher is able to Pause and Resume the Shared Custom Focus Math Assignment for a student from Assignment page");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "TC03_Verify Teacher is able to Pause and Resume All of the Custom Math by Skills Assignment in Groups Page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_014(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		String testMethodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		Log.testCaseInfo(testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			GroupPage groupsTab = new GroupPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);

			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.SKILLS, Constants.MATH);

			tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			coursepage.clickFromCourseListingPage(newlyCreatedCourse);

			SMUtils.waitForSpinnertoDisapper(driver);

			coursepage.clickAssignBtn();
			coursepage.addCourseToGroups();

			// Navigate to Groups Tab
			groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			Log.assertThat(groupsTab.verifyGroupHeaders(), "Verified Headers successfully!",
					"Headers not displayed properly");
			groupsTab.clickViewGroupUsingGroupName(groupName);

			// Navigate to Groups Assignment sub-Nav
			groupsTab.getAssignmentDetailsBasedOnGroup();

			SMUtils.waitForSpinnertoDisapper(driver);
			groupsTab.clickThreeDotEllipsesonAssignment(newlyCreatedCourse);
			groupsTab.clickPauseAssignmentForAllStudents();
			Log.assertThat(groupsTab.clickPauseResumeButtononPauseAssignmentpopup(),
					"Teacher is able to click on pause button",
					"Teacher is not able to click on pause button on Pause Assignment pop-up!");
			Log.assertThat(groupsTab.isGroupAssignmentPaused(),
					"The teacher is able to see 'Paused' label for each paused assignment",
					"The teacher is not able to see 'Paused' label for each paused assignment!");

			// Navigate to Groups Tab
			groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			Log.assertThat(groupsTab.verifyGroupHeaders(), "Verified Headers successfully!",
					"Headers not displayed properly");
			groupsTab.clickViewGroupUsingGroupName(groupName);

			// Navigate to Groups Assignment sub-Nav
			groupsTab.getAssignmentDetailsBasedOnGroup();

			SMUtils.waitForSpinnertoDisapper(driver);
			groupsTab.clickThreeDotEllipsesonAssignment(newlyCreatedCourse);
			SMUtils.waitForSpinnertoDisapper(driver);
			groupsTab.clickResumeAssignmentForAllStudents();
			Log.assertThat(groupsTab.clickPauseResumeButtononPauseAssignmentpopup(),
					"Teacher is able to click on Resume button",
					"Teacher is not able to click on Resume button on Resume Assignment pop-up!");
			Log.assertThat(!groupsTab.isGroupAssignmentPaused(),
					"Teacher is not able to see 'Paused' label for Resumed assignment",
					"Teacher is able to see 'Paused' Label!");
			SMUtils.logDescriptionTC(
					"SMK-20838 - TC03_Verify Teacher is able to Pause and Resume All of the Custom Math by Skills Assignment in Groups Page");

			groupsTab.clickResumeAssignmentForAllStudents();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		}

		finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "TC07_Verify Teacher is able to Pause and Resume All of the Custom Reading by Skills Assignment in Groups Page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_015(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		Log.testCaseInfo(testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			SMUtils.nap(10);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			GroupPage groupsTab = new GroupPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);

			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.SKILLS, Constants.MATH);

			tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			coursepage.clickFromCourseListingPage(newlyCreatedCourse);

			SMUtils.waitForSpinnertoDisapper(driver);

			coursepage.clickAssignBtn();
			coursepage.addCourseToGroups();

			// Navigate to Groups Tab
			groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			Log.assertThat(groupsTab.verifyGroupHeaders(), "Verified Headers successfully!",
					"Headers not displayed properly");
			groupsTab.clickViewGroupUsingGroupName(groupName);

			// Navigate to Groups Assignment sub-Nav
			groupsTab.getAssignmentDetailsBasedOnGroup();

			SMUtils.waitForSpinnertoDisapper(driver);
			groupsTab.clickThreeDotEllipsesonAssignment(newlyCreatedCourse);
			groupsTab.clickPauseAssignmentForAllStudents();
			Log.assertThat(groupsTab.clickPauseResumeButtononPauseAssignmentpopup(),
					"Teacher is able to click on pause button",
					"Teacher is not able to click on pause button on Pause Assignment pop-up!");
			Log.assertThat(groupsTab.isGroupAssignmentPaused(),
					"The teacher is able to see 'Paused' label for each paused assignment",
					"The teacher is not able to see 'Paused' label for each paused assignment!");

			// Navigate to Groups Tab
			groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			Log.assertThat(groupsTab.verifyGroupHeaders(), "Verified Headers successfully!",
					"Headers not displayed properly");
			groupsTab.clickViewGroupUsingGroupName(groupName);

			// Navigate to Groups Assignment sub-Nav
			groupsTab.getAssignmentDetailsBasedOnGroup();

			SMUtils.waitForSpinnertoDisapper(driver);
			groupsTab.clickThreeDotEllipsesonAssignment(newlyCreatedCourse);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(5);
			groupsTab.clickResumeAssignmentForAllStudents();
			Log.assertThat(groupsTab.clickPauseResumeButtononPauseAssignmentpopup(),
					"Teacher is able to click on Resume button",
					"Teacher is not able to click on Resume button on Resume Assignment pop-up!");
			Log.assertThat(!groupsTab.isGroupAssignmentPaused(),
					"Teacher is not able to see 'Paused' label for Resumed assignment",
					"Teacher is able to see 'Paused' Label!");
			SMUtils.logDescriptionTC(
					"SMK-20842 - TC07_Verify Teacher is able to Pause and Resume All of the Custom Reading by Skills Assignment in Groups Page");

			groupsTab.clickResumeAssignmentForAllStudents();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		}

		finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "TC04_Verify Teacher is able to Pause and Resume All of the Custom Math by Skills Assignment in Students Page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_016(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"TC04_Verify Teacher is able to Pause and Resume All of the Custom Math by Skills Assignment in Students Page <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			String studentID = SMUtils.getKeyValueFromResponse(studentSMDetails, "data,userName");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// SM_FOCUS_READING_GRADE8 Assignment
			CoursesPage coursepage = new CoursesPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.SKILLS, Constants.MATH);

			SMUtils.waitForSpinnertoDisapper(driver, 60);

			SMUtils.nap(10);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			SMUtils.waitForSpinnertoDisapper(driver, 60);
			coursepage.clickFromCourseListingPage(newlyCreatedCourse);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			SMUtils.nap(5);
			// Navigate to Students Tab
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			SMUtils.nap(10);

			// Navigate to Ellipsis Menu
			studentsPage.clickviewStudentByEllipsis(studentID);

			// Navigate to 'Assignment' Side Navigation menu
			studentsPage.clickSubNavigation(Constants.Students.SIDE_NAV_ASSIGNMENT_TAB);
			// SMUtils.scrollDownPage( driver );

			// Clicking on Ellipsis
			studentsPage.clickingThreedotsEllipsisFromAssignments(newlyCreatedCourse);

			// Pause the Student from assignment
			studentsPage.pasueStudentFromAssignment(newlyCreatedCourse);
			Log.assertThat(studentsPage.isAssignmentPaused(newlyCreatedCourse),
					"Assignment paused successfully", "Assignment has not Paused");

			// Resume the Student from assignment
			studentsPage.resumeStudentFromAssignment(newlyCreatedCourse);

			SMUtils.logDescriptionTC(
					"SMK-20839 - TC04_Verify Teacher is able to Pause and Resume All of the Custom Math by Skills Assignment in Students Page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "TC08_Verify Teacher is able to Pause and Resume All of the Custom Reading by Standard Assignment in Students Page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_017(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"TC08_Verify Teacher is able to Pause and Resume All of the Custom Reading by Standard Assignment in Students Page <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			String studentID = SMUtils.getKeyValueFromResponse(studentSMDetails, "data,userName");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// SM_FOCUS_READING_GRADE8 Assignment
			CoursesPage coursepage = new CoursesPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.STANDARDS, Constants.READING);

			SMUtils.waitForSpinnertoDisapper(driver, 60);

			SMUtils.nap(10);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			SMUtils.waitForSpinnertoDisapper(driver, 60);
			coursepage.clickFromCourseListingPage(newlyCreatedCourse);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate to Students Tab
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			SMUtils.nap(10);

			// Navigate to Ellipsis Menu
			studentsPage.clickviewStudentByEllipsis(studentID);

			// Navigate to 'Assignment' Side Navigation menu
			studentsPage.clickSubNavigation(Constants.Students.SIDE_NAV_ASSIGNMENT_TAB);

			// Clicking on Ellipsis
			studentsPage.clickingThreedotsEllipsisFromAssignments(newlyCreatedCourse);

			// Pause the Student from assignment
			studentsPage.pasueStudentFromAssignment(newlyCreatedCourse);
			Log.assertThat(studentsPage.isAssignmentPaused(newlyCreatedCourse),
					"Assignment paused successfully", "Assignment has not Paused");

			// Resume the Student from assignment
			studentsPage.resumeStudentFromAssignment(newlyCreatedCourse);

			SMUtils.logDescriptionTC(
					"SMK-20843 - TC08_Verify Teacher is able to Pause and Resume All of the Custom Reading by Standard Assignment in Students Page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "TC09_Verify Teacher is able to Pause and Resume All of the Focus Math Assignment in Students Page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_018(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"TC09_Verify Teacher is able to Pause and Resume All of the Focus Math Assignment in Students Page <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			String studentID = SMUtils.getKeyValueFromResponse(studentSMDetails, "data,userName");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// SM_FOCUS_READING_GRADE8 Assignment
			CoursesPage coursepage = new CoursesPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1);

			SMUtils.waitForSpinnertoDisapper(driver, 60);

			SMUtils.nap(10);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			SMUtils.waitForSpinnertoDisapper(driver, 60);
			coursepage.clickFromCourseListingPage(newlyCreatedCourse);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate to Students Tab
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			SMUtils.nap(10);

			// Navigate to Ellipsis Menu
			studentsPage.clickviewStudentByEllipsis(studentID);

			// Navigate to 'Assignment' Side Navigation menu
			studentsPage.clickSubNavigation(Constants.Students.SIDE_NAV_ASSIGNMENT_TAB);

			// Clicking on Ellipsis
			studentsPage.clickingThreedotsEllipsisFromAssignments(newlyCreatedCourse);

			// Pause the Student from assignment
			studentsPage.pasueStudentFromAssignment(newlyCreatedCourse);
			Log.assertThat(studentsPage.isAssignmentPaused(newlyCreatedCourse),
					"Assignment paused successfully", "Assignment has not Paused");

			// Resume the Student from assignment
			studentsPage.resumeStudentFromAssignment(newlyCreatedCourse);

			SMUtils.logDescriptionTC(
					"SMK-20844 - TC09_Verify Teacher is able to Pause and Resume All of the Focus Math Assignment in Students Page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "TC10_Verify Teacher is able to Pause and Resume All of the Focus Reading Assignment in Group Page", groups = {
			"SMK-54708", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPause_019(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"TC10_Verify Teacher is able to Pause and Resume All of the Focus Reading Assignment in Group Page <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			String studentID = SMUtils.getKeyValueFromResponse(studentSMDetails, "data,userName");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// SM_FOCUS_READING_GRADE8 Assignment
			CoursesPage coursepage = new CoursesPage(driver);
			String newlyCreatedCourse = null;

			newlyCreatedCourse = coursepage.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);

			// Make a copy of the course
			coursepage.copyOfCourse(newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1);

			SMUtils.waitForSpinnertoDisapper(driver, 60);

			SMUtils.nap(10);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			SMUtils.waitForSpinnertoDisapper(driver, 60);
			coursepage.clickFromCourseListingPage(newlyCreatedCourse);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate to Students Tab
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			SMUtils.nap(10);

			// Navigate to Ellipsis Menu
			studentsPage.clickviewStudentByEllipsis(studentID);

			// Navigate to 'Assignment' Side Navigation menu
			studentsPage.clickSubNavigation(Constants.Students.SIDE_NAV_ASSIGNMENT_TAB);

			// Clicking on Ellipsis
			studentsPage.clickingThreedotsEllipsisFromAssignments(newlyCreatedCourse);

			// Pause the Student from assignment
			studentsPage.pasueStudentFromAssignment(newlyCreatedCourse);
			Log.assertThat(studentsPage.isAssignmentPaused(newlyCreatedCourse),
					"Assignment paused successfully", "Assignment has not Paused");

			// Resume the Student from assignment
			studentsPage.resumeStudentFromAssignment(newlyCreatedCourse);

			SMUtils.logDescriptionTC(
					"SMK-20845 - TC10_Verify Teacher is able to Pause and Resume All of the Focus Reading Assignment in Group Page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

}
