package com.savvas.sm.api.tests.smnew.logintest;

import java.util.HashMap;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.LoginAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

/**
 * This class is used to test the user role
 * 
 * @author madhan.nagarathinam
 *
 */
public class GETDashBoardAPITest extends BaseTest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private Response response;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String teacherDetails = null;
    private String studentDetails = null;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String token = "null";

    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ) );
    }

    /**
     * Method for testing DashBoard API-Positive cases.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-50083", "Shiro token cleanup", "API" }, priority = 1 )
    public void getUserRoleFromDashBoardTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LoginAPIConstants.GET_DASHBOARD_API_ENDPOINT;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "VALID_TEACHER":
                token = LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, token );
                break;

            case "VALID_STUDENT":
                token = LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), password );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, token );
                break;
        }
        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        String responseBody = response.getBody().asString();
        if ( scenarioType.equalsIgnoreCase( "VALID_TEACHER" ) ) {
            Log.assertThat( responseBody.contentEquals( "T" ), "The response for Valid Teacher is the same as expected", "The response for Valid Teacher is not the same as expected!" );
        } else {
            Log.assertThat( responseBody.contentEquals( "S" ), "The response for Student is the same as expected", "The response for Valid student is not the same as expected!" );
        }
        Log.testCaseResult();
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC001: ", "200", "Verify 200 status code and response body when valid teacher user-id and vaild authorization is given", "VALID_TEACHER" },
                { "TC002: ", "200", "Verify 200 status code and response body when valid student user-id and vaild authorization is given", "VALID_STUDENT" } };
        return data;
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-50083", "Shiro token cleanup", "API" }, priority = 2 )
    public void getUserRoleFromDashBoardTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LoginAPIConstants.GET_DASHBOARD_API_ENDPOINT;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "INVALID_AUTHORIZATION":
                token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, token );
                break;

            case "INVALID_USERID_WITH_VALID_AUTHORIZATION":
                token = LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) + 1 );
                headers.put( LoginAPIConstants.AUTHORIZATION, token );
                break;

        }
        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.testCaseResult();
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC003: ", "401", "Verify 401 status code when invalid authorization is given", "INVALID_AUTHORIZATION" },
                { "TC004: ", "401", "Verify 401 status code when invalid userid and valid authorization is given", "INVALID_USERID_WITH_VALID_AUTHORIZATION" } };
        return data;
    }

}
