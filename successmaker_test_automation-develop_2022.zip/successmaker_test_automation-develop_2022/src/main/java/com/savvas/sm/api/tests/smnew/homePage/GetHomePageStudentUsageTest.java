package com.savvas.sm.api.tests.smnew.homePage;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.SqlConstants;
import com.savvas.sm.utils.SqlConstants.StudentProgress;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

public class GetHomePageStudentUsageTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String coTeacherUsername;
    private String coTeacherID;
    private String flexSchool;
    private String mathSchool;
    private String orgId;
    private String mathOrgId;
    private String teacherId;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static List<String> studentRumbaUsernames = new ArrayList<>();
    RBSUtils rbsUtils = new RBSUtils();
    private List<String> courseIDs = new ArrayList<>();
    private Map<String, String> response = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String exception = null;
    private String message = null;
    private String teacherUsername;
    private String schoolAdminUsername;
    private String districtAdminUsername;
    private String savvasAdminUsername;
    private String schoolAdminUserId;
    private String districtAdminUserId;
    private String savvasAdminUserId;
    HashMap<String, String> assignmentResponse;
  

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolAdminUsername = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
        districtAdminUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        savvasAdminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );

        schoolAdminUserId = rbsUtils.getUserIDByUserName( schoolAdminUsername );
        districtAdminUserId = rbsUtils.getUserIDByUserName( districtAdminUsername );
        savvasAdminUserId = rbsUtils.getUserIDByUserName( savvasAdminUsername );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        mathOrgId = RBSDataSetup.organizationIDs.get( mathSchool );

        String teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        IntStream.rangeClosed( 1, 4 ).forEach( itr -> {
            String studentDetail = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
            studentRumbaUsernames.add( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
        } );

        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Auto Test Group" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Test Auto Group " + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "contentBaseName- " + contentBaseName );
        Log.message( "contentBase- " + contentBase );
        Log.message( "courseIDs- " + courseIDs );

        Log.message( "Assigning assignment..." );

        Log.message( "Assignment Details: " + assignmentDetails );
        Log.message( "Student Details: " + studentRumbaIds );

        assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        Log.message( "Assignment IDs - " + assignmentIds );

        String username = studentRumbaUsernames.get( 0 );
        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( studentRumbaUsernames.get( 1 ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );
        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );
        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), true );

        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );

        // Running fix-up query to get previous week data
   //       FixupFunction.executeFixupFunctions( orgId );

    }

    
    @Test ( priority = 1, dataProvider = "studentUsagePositive", groups = { "smoke_test_case", "SMK-52120", "Students", "Student Usage", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        List<String> assignments;
        List<String> students;
        List<String> schools = new ArrayList<>();
        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        switch ( scenario ) {
            case "VALID":
            	FixupFunction.executeFixupFunctions( orgId );
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                //for empty assignment array
                assignments = new ArrayList<>();
                Log.message(assignments.toString());
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;
                Log.message(students.toString());

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "ZERO_STATE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "MULTPLE_SCHOOL_TEACHER":

                // multiple school teacher creation
                String multiSchoolT = "MultiSchTeacher" + System.nanoTime();

                schools.add( mathOrgId );
                schools.add( orgId );
                String multiSchoolTID = new UserAPI().createMultiOrgTeacher( schools, multiSchoolT );

                //group creation for the above created teacher
                List<String> studentRumbaId = Arrays.asList( studentRumbaIds.get( 0 ) );

                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), multiSchoolTID, studentRumbaId, orgId, new RBSUtils().getAccessToken( multiSchoolT, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                headers.put( UserConstants.USERID, multiSchoolTID );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( multiSchoolT, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignments = assignmentIds.entrySet().stream().map( Entry::getValue ).collect( Collectors.toList() );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaId;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "MATH_ASSIGNMENT":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                Log.message("math response :"+response);
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "READING_ASSIGNMENT":

         //   	FixupFunction.executeFixupFunctions( orgId );
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "STUDENT_ASSOCIATED_WITH_TWO_GROUPS_FOR_SAME_TEACHER":

                //adding the student to the another group for the same tacher
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, studentRumbaIds, orgId, token );

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = assignmentIds.entrySet().stream().map( Entry::getValue ).collect( Collectors.toList() );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "STUDENT_ASSOCIATED_WITH_TWO_GROUPS_FOR_DIFF_TEACHER":

                //Creating the teacher in the Same school
                coTeacherUsername = "SchTeacher" + System.nanoTime();

                schools.add( orgId );
                String coTeacherDetails = new UserAPI().createUserWithCustomization( coTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, schools );
                coTeacherID = SMUtils.getKeyValueFromResponse( coTeacherDetails, RBSDataSetupConstants.USERID );

                //Creating group with existing student for above created teacher
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), coTeacherID, Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                headers.put( UserConstants.USERID, coTeacherID );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignments = assignmentIds.entrySet().stream().map( Entry::getValue ).collect( Collectors.toList() );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = Arrays.asList( studentRumbaIds.get( 0 ) );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "MULTIPLE_TEACHER_GROUP":

                String sharedGroup = "Shared Group" + System.nanoTime();

                //creating Shared group
                new RBSUtils().createClassWithMultipleTeacher( sharedGroup, Arrays.asList( teacherId, coTeacherID ), Arrays.asList( studentRumbaIds.get( 1 ) ), orgId, token );

                headers.put( UserConstants.USERID, coTeacherID );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignments = assignmentIds.entrySet().stream().map( Entry::getValue ).collect( Collectors.toList() );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = Arrays.asList( studentRumbaIds.get( 0 ), studentRumbaIds.get( 1 ) );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "CUSTOM_BY_SKILL_COURSE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ),
                        assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "CUSTOM_BY_STANDARD_COURSE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "CUSTOM_BY_SETTING_COURSE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ),
                        assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "AFTER_DELETE_THE_ASSIGNMENT":

                HashMap<String, String> assignmentDetail = new HashMap<>();
                assignmentDetail.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
       //         String assignmentUserId= getAssignmentUserId( studentRumbaIds.get( 0 ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE )) ;
                String assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( "body" ), "data,assignmentId" );
                String assignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );

                Log.message("assignment user ID:"+assignmentUserId);
                assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId    );
                Log.message("assignment user id get or not");
                new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = new ArrayList<>();
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );

                students = studentRumbaIds;

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;

            case "AFTER_REMOVE_THE_STUDENT_FROM _GROUP_WITH_ASSIGNMENT":

                //adding the student to the  group for the  tacher
                String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( studentRumbaIds.get( 2 ) ), orgId, token );

                //Assigning the assignment
                String courseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName ) );
                HashMap<String, String> assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );
                String assignmentId = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.REPORT_BODY ), "data,assignmentId" );

                //execute course through student dashboard
                executeCourse( studentRumbaUsernames.get( 2 ), courseName, true );

                new GroupAPI().removeStudentFromGroup( smUrl, studentRumbaIds.get( 2 ), newGroupId, teacherId, orgId, token );
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                assignments = Arrays.asList( assignmentId );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                students = Arrays.asList( studentRumbaIds.get( 2 ) );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
                break;
                
//              case "VALID":
//            	FixupFunction.executeFixupFunctions( orgId );
//                headers.put( UserConstants.USERID, teacherId );
//                headers.put( UserConstants.ORGID, orgId );
//                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
//                //for empty assignment array
//                assignments = new ArrayList<>();
//                Log.message(assignments.toString());
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
//                students = studentRumbaIds;
//                Log.message(students.toString());
//
//                //Status code validation
//                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
//
//                //data Validation
//                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, students );
//                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        //Schema validation
        if ( !scenario.equalsIgnoreCase( "ZERO_STATE" ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getStudentUsageSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
            
        } else {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

            //Exception validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( "com.savvas.core.exceptions.DataNotFoundException" ), "Exception Verified successfully!",
                    "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

            //Message Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( "Student usage not found" ), "Message Verified successfully!",
                    "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );
        }

        Log.testCaseResult();
    }

    @DataProvider ( name = "studentUsagePositive" )
    public Object[][] studentUsagePositive() {

        Object[][] inputData = {
                { "tc_HomePage_StudentUsage001", "Verify status code 200 should display when correct credential is given for Usage Report. & Verify status code 200 when given teacher has usage for one week ", "VALID", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage002", "Verify empty response returned when there is no usage data for the assignment and status code is 200", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK },
          //      { "tc_HomePage_StudentUsage003", "Verify the status code is 200 when searching with teacher who is associated with mutiple schools", "MULTPLE_SCHOOL_TEACHER", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage004", "Verify the status code is 200 when searching with math assignment id alone", "MATH_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage005", "Verify the status code is 200 when searching with reading assignment id alone", "READING_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage006", "Verify usage data in response if the student is associated with two different groups of same teacher", "STUDENT_ASSOCIATED_WITH_TWO_GROUPS_FOR_SAME_TEACHER", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage007", "Verify usage data in response if the student is associated with two different groups of two different teacher", "STUDENT_ASSOCIATED_WITH_TWO_GROUPS_FOR_DIFF_TEACHER", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage008", "Verify usage data in response if the two teachers are the owner for single group", "MULTIPLE_TEACHER_GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage009", "Verify Reponse should fetch the custom by skill course assignment usage details with status code 200 when passing custom skill course assignment id", "CUSTOM_BY_SKILL_COURSE",
                        CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage010", "Verify Reponse should fetch the custom by standard course assignment usage details with status code 200 when passing custom standard course assignment id", "CUSTOM_BY_STANDARD_COURSE",
                        CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage011", "Verify Reponse should fetch the custom by setting course assignment usage details with status code 200 when passing custom by setting course assignment id", "CUSTOM_BY_SETTING_COURSE",
                        CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage012", "Verify response will not return soft deleted assignment student usage also when any one of student assignment is deleted from particular assignment", "AFTER_DELETE_THE_ASSIGNMENT",
                        CommonAPIConstants.STATUS_CODE_OK },
                { "tc_HomePage_StudentUsage013", "Verify the student usage if the student removed from the group(group with assignments)", "AFTER_REMOVE_THE_STUDENT_FROM _GROUP_WITH_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK } };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "studentUsageNegative", groups = { "SMK-52120", "Students", "Student Usage", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        List<String> assignments = assignmentIds.entrySet().stream().map( Entry::getValue ).collect( Collectors.toList() );

        switch ( scenario ) {
            case "WITH_SCHOOL_ADMIN_CREDENTIAL":
                headers.put( UserConstants.USERID, schoolAdminUserId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( schoolAdminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_STUDENT_CREDENTIAL":
                headers.put( UserConstants.USERID, studentRumbaIds.get( 0 ) );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( studentRumbaUsernames.get( 0 ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_DISTRICT_ADMIN_CREDENTIAL":
                headers.put( UserConstants.USERID, districtAdminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( "district_ID" ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_SAVVAS_ADMIN_CREDENTIAL":
                headers.put( UserConstants.USERID, savvasAdminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( "district_ID" ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( savvasAdminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_HEADER":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId + "invalid" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), orgId, assignments, "", "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_ENDPOINT":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ) + "/usage", assignments, "", "" );
                break;

            case "INVALID_DATATYPE_BOOLEAN":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new UserAPI().getStudentUsage( smUrl, headers, "true", "true", assignments, "", "" );
                message = CommonAPIConstants.USER_ID_MISMATCH_MESSAGE;
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                break;

            case "INVALID_USERID":
                headers.put( UserConstants.USERID, teacherId + "invalid" );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new UserAPI().getStudentUsage( smUrl, headers, teacherId, headers.get( UserConstants.ORGID ), assignments, "", "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "EMPTY_ORGID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, "" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), orgId, assignments, "", "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_ACCESS_TOKEN":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, orgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token + "invalid" );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;

        }

        //Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

    }

    @DataProvider ( name = "studentUsageNegative" )
    public Object[][] studentUsageNegative() {

        Object[][] inputData = {
                { "tc_HomePage_StudentUsage014", "Verify the status code is 403 for incorrect authorization for invalids roles(Give school customer admin authorization)", "WITH_SCHOOL_ADMIN_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "tc_HomePage_StudentUsage015", "Verify the status code is 403 for incorrect authorization for invalids roles(Give student authorization)", "WITH_STUDENT_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "tc_HomePage_StudentUsage016", "Verify the status code is 401 for incorrect authorization for invalids roles(Give district customer admin authorization)", "WITH_DISTRICT_ADMIN_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "tc_HomePage_StudentUsage017", "Verify the status code is 401 for incorrect authorization for invalids roles(Give savvas admin authorization)", "WITH_SAVVAS_ADMIN_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "tc_HomePage_StudentUsage018", "Verify the status code is 403 when invalid headers is passed", "INVALID_HEADER", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "tc_HomePage_StudentUsage019", "Verify the status code is 404 for incorrect URL is given", "INVALID_ENDPOINT", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "tc_HomePage_StudentUsage020", "Verify response code 400 when org id and staff id is passing as Boolean data type as param.", "INVALID_DATATYPE_BOOLEAN", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "tc_HomePage_StudentUsage021", "Verify response 401 when invalid/empty user id given in header", "INVALID_USERID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "tc_HomePage_StudentUsage022", "Verify response 403 when empty orgid given in header", "EMPTY_ORGID", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "tc_HomePage_StudentUsage023", "Verify response 401 when user give invalid token for authorization.", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED } };
        return inputData;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "3", "10" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "3" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * To verify the response with DB
     * 
     */
    private void verifyResponseWithDB( String response, List<String> assignmentIds, List<String> studentIds ) {
        Map<String, Map<String, String>> usageDetailsFromResponse = new HashMap<>();
        String reponseData = SMUtils.getKeyValueFromResponse( response, "data" );
        IntStream.rangeClosed( 0, 7 ).forEach( iter -> {
            Map<String, String> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( iter );
            subjectUsage.put( StudentUsage.MATH_MINS, jObj.get( StudentUsage.MATH_MINS ).toString() );
            subjectUsage.put( StudentUsage.READING_MINS, jObj.get( StudentUsage.READING_MINS ).toString() );
            usageDetailsFromResponse.put( jObj.get( StudentUsage.WEEK ).toString(), subjectUsage );
        } );
        Map<String, String> individualFields = new HashMap<>();

        individualFields.put( StudentUsage.THIS_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.THIS_WEEK_MINS ) );
        individualFields.put( StudentUsage.LAST_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.LAST_WEEK_MINS ) );
        individualFields.put( StudentUsage.TOTAL_MINTUES, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.TOTAL_MINTUES ) );
        usageDetailsFromResponse.put( "individualFields", individualFields );

        Map<String, Map<String, String>> usageDetailsFromDB = getStudentUsage( assignmentIds, studentIds );

        Log.message( "usage Data from Db - " + usageDetailsFromDB );

        Log.assertThat( usageDetailsFromDB.entrySet().stream().allMatch( entry -> {
            if ( entry.getValue().containsKey( StudentUsage.MATH_MINS ) ) {
                int mathDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.MATH_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.MATH_MINS ) );
                int readDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.READING_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.READING_MINS ) );
                return ( mathDeviation >= -1 && mathDeviation <= 1 ) && ( readDeviation >= -1 && readDeviation <= 1 );
            } else if ( entry.getValue().containsKey( StudentUsage.THIS_WEEK_MINS ) ) {
                int thisWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.THIS_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.THIS_WEEK_MINS ) );
                int lastWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.LAST_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.LAST_WEEK_MINS ) );
                int toatalMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.TOTAL_MINTUES ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.TOTAL_MINTUES ) );
                return ( thisWeekMinsDeviation >= -2 && thisWeekMinsDeviation <= 2 ) && ( lastWeekMinsDeviation >= -2 && lastWeekMinsDeviation <= 2 ) && ( toatalMinsDeviation >= -2 && toatalMinsDeviation <= 2 );
            } else {
                return false;
            }
        } ), "Usage data are fetched properly", "Usage data are not fetched properly. Expected -" + usageDetailsFromDB.toString() + ": Actual -" + usageDetailsFromResponse.toString() );
    }

    
    /**
     * To get the student usage Details
     * 
     * @param assignmentIds
     * @param studentIds
     * @return
     */
    public Map<String, Map<String, String>> getStudentUsage( List<String> assignmentIds, List<String> studentIds ) {

        String query = "SELECT (SELECT SUM(EXTRACT (EPOCH FROM (session_complete_time - session_start_time))/60)::bigint AS readSessionMinutes  FROM read_session_history  WHERE assignment_user_id IN (SELECT assignment_user_id FROM Assignment_user WHERE assignment_id IN (assignmentIds) AND person_id IN (studentIds)  AND isdeleted = 0) AND session_complete_time BETWEEN 'fromDate' AND 'toDate') AS readmins,(SELECT SUM(EXTRACT (EPOCH FROM (session_complete_time - session_start_time))/60)::bigint AS mathSessionMinutes FROM math_session_history WHERE assignment_user_id IN (SELECT assignment_user_id FROM Assignment_user WHERE assignment_id IN (assignmentIds) AND person_id IN (studentIds) AND isdeleted = 0) AND session_complete_time BETWEEN 'fromDate' AND 'toDate') AS mathmins";

        if ( assignmentIds.isEmpty() ) {
            query = query.replace( "assignment_id IN (assignmentIds) AND", "" );
        } else {
            query = query.replace( "assignmentIds", assignmentIds.toString().substring( 1, assignmentIds.toString().length() - 1 ) );
        }

        query = query.replace( "studentIds", "'" + studentIds.toString().substring( 1, studentIds.toString().length() - 1 ).replace( ", ", "', '" ) + "'" );

        Map<String, Map<String, String>> usageDetails = new HashMap<>();
        Map<String, String> individualField = new HashMap<>();
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
        ZonedDateTime weekStartDate = ZonedDateTime.now( ZoneId.of( "America/Phoenix" ) );

        if ( weekStartDate.getDayOfWeek().toString().equals( "SUNDAY" ) ) {
            weekStartDate = weekStartDate.minusDays( 1 );
        }

        while ( !weekStartDate.getDayOfWeek().toString().equals( "MONDAY" ) ) {
            weekStartDate = weekStartDate.minusDays( 1 );
        }

        String querywithdate = "";
        querywithdate = query.replace( "toDate", ZonedDateTime.now( ZoneId.of( "America/Phoenix" ) ).plusDays( 1 ).format( dateFormat ) );
        querywithdate = querywithdate.replace( "fromDate", weekStartDate.format( dateFormat ) );
        Log.message("querywithdate diplayed correctly:"+querywithdate.toString());

        int iter = 0;
        while ( iter < 8 ) {

            List<Object[]> listItems = executeQuery( querywithdate );
            Map<String, String> arrMap = new HashMap<>();
            if ( listItems != null && listItems.size() > 0 ) {

                if ( Objects.nonNull( listItems.get( 0 )[1] ) ) {
                    arrMap.put( StudentUsage.MATH_MINS, listItems.get( 0 )[1].toString() );
                } else {
                    arrMap.put( StudentUsage.MATH_MINS, "0" );
                }

                if ( Objects.nonNull( listItems.get( 0 )[0] ) ) {
                    arrMap.put( StudentUsage.READING_MINS, listItems.get( 0 )[0].toString() );
                } else {
                    arrMap.put( StudentUsage.READING_MINS, "0" );
                }
            }
//            for (int i = 0; i < listItems.size(); i++) {
//				Object[] objects = listItems.get(i);
//				Log.message(objects.toString());
//			}
//            List<String> arrList = new ArrayList<String>();
//            for ( Object[] list : listItems ) {
//            //	    arrList.add(list[0].toString());
//            	if (Objects.nonNull(list[0])) {
//            		arrList.add(list[0].toString());
//				} else if(Objects.nonNull(list[1])){
//					arrList.add( list[1].toString() );
//				}else {
//					Log.message("Both Math and Reading are null");
//				}
//            	Log.message(arrList.toString());
//            }
        //    Log.message("checking: "+listItems.toString());	
            
//            Map<String, String> arrMap = new HashMap<>();
//            Log.message(arrMap.toString());
//            if ( arrList != null && arrList.size() > 0 ) {
//
//                if ( Objects.nonNull( arrList.get( 0 ) ) ) {
//                    arrMap.put( StudentUsage.MATH_MINS, arrList.get( 0 ).toString() );
//                } else {
//                    arrMap.put( StudentUsage.MATH_MINS, "0" );
//                    Log.message("math mins-0");
//                }
//
//                if ( Objects.nonNull( arrList.get( 0 ) ) ) {
//                    arrMap.put( StudentUsage.READING_MINS, arrList.get( 0 ).toString() );
//                } else {
//                    arrMap.put( StudentUsage.READING_MINS, "0" );
//                    Log.message("reading mins-0");
//                }
//            }
            if ( iter == 0 ) {
                individualField.put( StudentUsage.THIS_WEEK_MINS, String.valueOf( Integer.parseInt( arrMap.get( StudentUsage.MATH_MINS ) ) + Integer.parseInt( arrMap.get( StudentUsage.READING_MINS ) ) ) );
            }
            if ( iter == 1 ) {
                individualField.put( StudentUsage.LAST_WEEK_MINS, String.valueOf( Integer.parseInt( arrMap.get( StudentUsage.MATH_MINS ) ) + Integer.parseInt( arrMap.get( StudentUsage.READING_MINS ) ) ) );
            }
            usageDetails.put( weekStartDate.format( dateFormat ), arrMap );
            querywithdate = query.replace( "toDate", weekStartDate.format( dateFormat ) );
            weekStartDate = weekStartDate.minusDays( 7 );
            querywithdate = querywithdate.replace( "fromDate", weekStartDate.format( dateFormat ) );
            iter++;
        }

        query = query.replace( "AND session_complete_time BETWEEN 'fromDate' AND 'toDate'", "" );
        Log.message("query: "+query);
        List<Object[]> listItems = executeQuery( query );
        Map<String, String> arrMap = new HashMap<String, String>();
        if ( listItems != null && listItems.size() > 0 ) {

            if ( Objects.nonNull( listItems.get( 0 )[1] ) ) {
                arrMap.put( StudentUsage.MATH_MINS, listItems.get( 0 )[1].toString() );
            } else if ( Objects.nonNull( listItems.get( 1)[0] ) ){
                arrMap.put( StudentUsage.MATH_MINS, listItems.get( 1 )[1].toString() );
            } else if ( Objects.nonNull( listItems.get( 1)[1] ) ){
                arrMap.put( StudentUsage.MATH_MINS, listItems.get( 1 )[1].toString() );
            }else {
            	arrMap.put( StudentUsage.MATH_MINS, "0" );
            }

            if ( Objects.nonNull( listItems.get( 0 )[0] ) ) {
                arrMap.put( StudentUsage.READING_MINS, listItems.get( 0 )[0].toString() );
            } else {
                arrMap.put( StudentUsage.READING_MINS, "0" );
            }
        }
        individualField.put( StudentUsage.TOTAL_MINTUES, String.valueOf( Integer.parseInt( arrMap.get( StudentUsage.MATH_MINS ) ) + Integer.parseInt( arrMap.get( StudentUsage.READING_MINS ) ) ) );
        usageDetails.put( "individualFields", individualField );
        return usageDetails;
    }
    

//    /*
//     * To get the Progress Details of the student from DB
//     */
//    public HashMap<String, String> getProgressDetails( String assignmentID, String studentID, String subject ) {
//        String getData;
//        if ( subject.equals( Constants.MATH ) ) {
//            getData = SqlConstants.StudentProgress.MATH_PROGRESS_QUERY;
//        } else {
//            getData = StudentProgress.READING_PROGRESS_QUERY;
//        }
//
//        String query = String.format( getData, new SqlHelperCourses().getAssignmentUserId( studentID, assignmentID ) );
//        List<Object[]> listItems = null;
//
//        listItems = SQLUtil.executeQuery( query );
//        HashMap<String, String> arrMap = null;
//        if ( listItems != null && listItems.size() > 0 ) {
//            arrMap = new HashMap<String, String>();
//            arrMap.put( StudentProgress.CURRENT_LEVEL, listItems.get( 0 )[0].toString() );
//            arrMap.put( StudentProgress.IP_LEVEL, listItems.get( 0 )[1].toString() );
//            arrMap.put( StudentProgress.ASSIGNED_LEVEL, listItems.get( 0 )[2].toString() );
//            arrMap.put( StudentProgress.IP_COMPLETED_DATE, listItems.get( 0 )[3].toString() );
//        }
//        return arrMap;
//    }

/**
 * To get the assignment user id for the given student with assignment ID
 * 
 * @param studentPersonId
 * @param assignmentID
 * @return
 */
public String getAssignmentUserId( String studentPersonId, String assignmentID ) {
    String assignmentUserID = null;
    String queryString = null;
    queryString = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getAssignmentUserID.sql" );
    queryString = String.format( queryString, assignmentID, studentPersonId );
    List<Object[]> listItems = SQLUtil.executeQuery( queryString );
    List<String> arrList = new ArrayList<String>();
    for ( Object[] list : listItems ) {
        if ( list.length > 0 ) {
            arrList.add( list[0].toString() );
        }
    }
    return assignmentUserID = arrList.get( 0 );

}



private static final String POST_GRES_DRIVER = "org.postgresql.Driver";
private static StringBuilder dbUrl;

public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

static {
    try {
        Class.forName( POST_GRES_DRIVER );

        String dhHost = "";
        if ( configProperty.getProperty( "SMInstanceType" ).toLowerCase().trim().equals( "non-integrated" ) )
            dhHost = configProperty.getProperty( "dbHostNonIntegrated" );
        else
            dhHost = configProperty.getProperty( "dbHostIntegrated" );

        dbUrl = new StringBuilder();
        dbUrl.append( "jdbc:postgresql://" ).append( dhHost ).append( ":" ).append( configProperty.getProperty( "dbPort" ) ).append( "/" ).append( configProperty.getProperty( "dbName" ) ).append( "?user=" ).append(
                configProperty.getProperty( "dbUsername" ) ).append( "&password=" ).append( configProperty.getProperty( "dbPassword" ) );
    } catch ( Exception e ) {
        Log.fail( "Error while loading database driver." );
    }
}

/**
 * @return Connection
 */
private static Connection getConnection() {
    Connection queryConnection = null;
    int attempts = 1;
    while ( attempts < 4 ) {
        try {

            String dbHost = "";

            if ( configProperty.getProperty( "SMInstanceType" ).equalsIgnoreCase( "Non-Integrated" ) )
                dbHost = configProperty.getProperty( "dbHostNonIntegrated" );
            else
                dbHost = configProperty.getProperty( "dbHostIntegrated" );

            // Log.event( "Establishing connection to the database for attempt: " + attempts + " - " + dbHost );
            queryConnection = DriverManager.getConnection( dbUrl.toString() );
            break;
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Error in establishing DB connection" );
        }
        attempts++;
    }
    if ( attempts == 4 ) {
        Log.fail( "Unable to establish DB connection in 3 attempts" );
    }
    return queryConnection;
}

/**
 * @param queryConnection
 * @return Statement
 * @throws SQLException
 */
private static Statement createStmt( Connection queryConnection ) throws SQLException {
    Statement qSt = queryConnection.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY );
    return qSt;
}

/**
 * @param functionStatement
 * @param parameters
 * @return
 */
public static Integer executeFunction( String functionStatement, Object[] parameters ) {
    Connection queryConnection = getConnection();
    CallableStatement cst = null;
    ResultSet rs = null;
    Integer statusCode = 0;
    try {
        cst = queryConnection.prepareCall( functionStatement );
        for ( int i = 0; i < parameters.length; i++ ) {
            if ( parameters[i] instanceof String ) {
                cst.setString( i + 1, parameters[i].toString() );
            } else if ( parameters[i] instanceof Integer ) {
                cst.setInt( i + 1, ( (Integer) parameters[i] ).intValue() );
            } else if ( parameters[i] instanceof Long ) {
                cst.setLong( i + 1, ( (Long) parameters[i] ).longValue() );
            } else if ( parameters[i] instanceof Double ) {
                cst.setDouble( i + 1, ( (Float) parameters[i] ).doubleValue() );
            } else if ( parameters[i] instanceof Float ) {
                cst.setFloat( i + 1, ( (Float) parameters[i] ).floatValue() );
            } else if ( parameters[i] instanceof Timestamp ) {
                cst.setTimestamp( i + 1, ( (Timestamp) parameters[i] ) );
            }
        }
        cst.execute();
        rs = cst.getResultSet();
        if ( rs != null ) {
            while ( rs.next() ) {
                statusCode = rs.getInt( 1 );
            }
        }
    } catch ( SQLException sqe ) {
        sqe.printStackTrace();
        Log.fail( "Error while executing function." );
    } finally {

        try {
            //Close the result set
            if ( rs != null ) {
                rs.close();
                rs = null;
            }
            //Close the statement
            if ( cst != null ) {
                cst.close();
                cst = null;
            }
            if ( queryConnection != null ) {
                queryConnection.close();
                queryConnection = null;
            }
        } catch ( SQLException sqe ) {
            Log.fail( "Error while releasing resources" );
        }
    }
    return statusCode;
}

/**
 * @param queryString
 * @return
 */
public static List<Object[]> executeQuery( String queryString ) {
    Connection queryConnection = getConnection();
    ResultSet resultSet = null;
    Statement qSt = null;
    List<Object[]> records = new ArrayList<Object[]>();
    try {
        qSt = createStmt( queryConnection );
        Log.message( "Executing Query: " + queryString );
        resultSet = qSt.executeQuery( queryString );
        Log.event( "Query executed!" );

        // call only once
        int cols = resultSet.getMetaData().getColumnCount();
        while ( resultSet.next() ) {
            Object[] arr = new Object[cols];
            for ( int i = 0; i < cols; i++ ) {
                arr[i] = resultSet.getObject( i + 1 );
            }
            records.add( arr );
        }
    } catch ( SQLException e ) {
        if ( e.getMessage().toString().equalsIgnoreCase( Constants.NO_RESULT_QUERY ) ) {
            Log.pass( "Query executed and no result found" );
        } else {
            e.printStackTrace();
            Log.fail( "Error in executing the query" );
        }
    } finally {
        try {
            //Close the result set
            if ( resultSet != null ) {
                resultSet.close();
                resultSet = null;
            }
            //Close the statement
            if ( qSt != null ) {
                qSt.close();
                qSt = null;
            }
            if ( queryConnection != null ) {
                queryConnection.close();
                queryConnection = null;
            }
        } catch ( SQLException sqe ) {
            Log.fail( "Error while releasing resources" );
        }
    }
    return records;
}

/**
 * This method executes the given query and return the results as table
 * format. The CachedRowSet obj can be further used by DB representation
 * classes.
 * 
 * @param queryString
 * @return
 * @throws SQLException
 */
public static CachedRowSet executeQueryAndReturnTable( String queryString ) throws SQLException {
    Connection queryConnection = getConnection();
    ResultSet resultSet = null;
    Statement qSt = null;
    CachedRowSet crs = RowSetProvider.newFactory().createCachedRowSet();
    try {
        qSt = createStmt( queryConnection );
        Log.message( "Executing Query: " + queryString );
        resultSet = qSt.executeQuery( queryString );
        Log.event( "Query executed!" );

        crs.populate( resultSet );
    } catch ( SQLException e ) {
        Log.fail( "Error in executing the query" );
    } finally {
        try {
            //Close the result set
            if ( resultSet != null ) {
                resultSet.close();
                resultSet = null;
            }
            //Close the statement
            if ( qSt != null ) {
                qSt.close();
                qSt = null;
            }
            //Close the connection
            if ( queryConnection != null ) {
                queryConnection.close();
                queryConnection = null;
            }
        } catch ( SQLException sqe ) {
            Log.fail( "Error while releasing resources" );
        }
    }
    return crs;
}

/**
 * @param queryString
 * @return
 */
public static boolean executeUpdateQuery( String queryString ) {
    Connection queryConnection = getConnection();
    Statement qSt = null;
    try {
        qSt = createStmt( queryConnection );
        Log.message( "Executing Query: " + queryString );
        qSt.executeUpdate( queryString );
        Log.event( "Query executed!" );
    } catch ( SQLException e ) {
        Log.fail( "Error in executing the query" );
        return false;
    } finally {
        try {
            //Close the statement
            if ( qSt != null ) {
                qSt.close();
                qSt = null;
            }
            if ( queryConnection != null ) {
                queryConnection.close();
                queryConnection = null;
            }
        } catch ( SQLException sqe ) {
            Log.fail( "Error while releasing resources" );
        }
    }
    return true;
}

/**
 * @param queryString
 * @return
 */
public static boolean executeInsDelQuery( String queryString ) {
    Connection queryConnection = getConnection();
    Statement qSt = null;
    try {
        qSt = createStmt( queryConnection );
        Log.message( "Executing Query: " + queryString );
        qSt.executeQuery( queryString );
        Log.event( "Query executed!" );
    } catch ( SQLException e ) {
        Log.fail( "Error in executing the query" );
        return false;
    } finally {
        try {
            //Close the statement
            if ( qSt != null ) {
                qSt.close();
                qSt = null;
            }
            if ( queryConnection != null ) {
                queryConnection.close();
                queryConnection = null;
            }
        } catch ( SQLException sqe ) {
            Log.fail( "Error while releasing resources" );
        }
    }
    return true;
}

/**
 * This method is used to Execute the Query for insert/delete without result
 * set
 * 
 * @param queryString
 * @return
 */
public static boolean executeInsDelQueryWithoutResult( String queryString ) {
    Connection queryConnection = getConnection();
    Statement qSt = null;
    try {
        qSt = createStmt( queryConnection );
        Log.message( "Executing Query: " + queryString );
        qSt.executeQuery( queryString );
        Log.event( "Query executed!" );
    } catch ( SQLException e ) {
        if ( e.toString().contains( "No results were returned by the query" ) ) {
            Log.message( "Query executed!" );
            return true;
        } else {
            e.printStackTrace();
            Log.fail( "Error in executing the query" );
            return false;
        }

    } finally {
        try {
            //Close the statement
            if ( qSt != null ) {
                qSt.close();
                qSt = null;
            }
            if ( queryConnection != null ) {
                queryConnection.close();
                queryConnection = null;
            }
        } catch ( SQLException sqe ) {
            sqe.printStackTrace();
            Log.fail( "Error while releasing resources" );
        }
    }
    return true;
}


}
