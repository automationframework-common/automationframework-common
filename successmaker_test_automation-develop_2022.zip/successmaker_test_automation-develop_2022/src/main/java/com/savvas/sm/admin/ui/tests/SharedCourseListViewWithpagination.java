package com.savvas.sm.admin.ui.tests;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.SharedCourses;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.SharedCourses.SHARED_COURSE_TABLE_HEADER;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SharedCourseListViewWithpagination extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Shared Courses list Pagination", groups = { "SMK-51746", "adminDashboard", "sharedCourseListViewPagination" }, priority = 1 )
    public void tcSMSharedCoursesPagination001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMSharedCourses001: Verify Shared Courses list view in admin dashboard. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Shared Courses List View Page
            SharedCoursesListViewPage sharedCoursesPage = dashBoardPage.navigateToSharedCoursesListPage();

            SMUtils.logDescriptionTC( "Verify the total number shared courses are displayed in the shared course page" );
            List<String> allCourses = sharedCoursesPage.getAllSharedCourses();
            Log.assertThat( sharedCoursesPage.getCountOfSharedCourses().equalsIgnoreCase( String.format( SharedCourses.COUNT_OF_COURSES, 1, allCourses.size() > 100 ? 100 : allCourses.size(), allCourses.size() ) ),
                    "The total number shared courses are displayed in the shared course page", "The total number shared courses are not displayed in the shared course page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the number of pages of shared course displayed for the results less than 100 count in the shared course page." );
            SMUtils.logDescriptionTC( "Verify the number of pages of shared course displayed for the results more than 100 count in the shared course page." );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() > 100 ? allCourses.size() / 100 + 1 : 1 ) ),
                    "The number of pages of shared course displayed for the results in the shared course page.", "The number of pages of shared course not displayed for the results in the shared course page." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of forward navigation in the page navigation for more than 100 shared courses" );
            if ( allCourses.size() > 100 ) {
                sharedCoursesPage.clickForwardButton();
                Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 2, allCourses.size() / 100 + 1 ) ),
                        "After clicking the forward button, shared course page is navigated to second page.", "After clicking the forward button, shared course page is not navigated to second page" );
                sharedCoursesPage.clickPreBackwardButton();
            } else {
                Log.assertThat( !sharedCoursesPage.isForwardButtonEnabled(), "Forward button is disabled as expected", "Forward button is not disabled mode if the shared course have less than 100 courses" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of fast forward navigation in the page navigation for more than 100 shared courses" );
            if ( allCourses.size() > 100 ) {
                sharedCoursesPage.clickFastForwardButton();
                Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, allCourses.size() / 100 + 1, allCourses.size() / 100 + 1 ) ),
                        "After clicking the fast forward button, shared course page is navigated to last page.", "After clicking the fast forward button, shared course page is not navigated to last page" );
                sharedCoursesPage.clickPreBackwardButton();
            } else {
                Log.assertThat( !sharedCoursesPage.isFastForwardButtonEnabled(), "Fast forward button is disabled as expected", "Fast forward button is not disabled mode if the shared course have less than 100 courses" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of backward navigation in the page navigation for more than 100 shared courses" );
            if ( allCourses.size() > 100 ) {
                sharedCoursesPage.clickForwardButton();
                sharedCoursesPage.clickBackwardButton();
                Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() / 100 + 1 ) ),
                        "After clicking the backward button, shared course page is navigated to previous page.", "After clicking the backward button, shared course page is not navigated to previous page" );
                sharedCoursesPage.clickPreBackwardButton();
            } else {
                Log.assertThat( !sharedCoursesPage.isBackwardButtonEnabled(), "Backward button is disabled as expected", "Backward button is not disabled mode if the shared course have less than 100 courses" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of pre backward navigation in the page navigation for more than 100 shared courses" );
            if ( allCourses.size() > 100 ) {
                sharedCoursesPage.clickFastForwardButton();
                sharedCoursesPage.clickPreBackwardButton();
                Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() / 100 + 1 ) ),
                        "After clicking the pre backward button, shared course page is navigated to First page.", "After clicking the pre backward button, shared course page is not navigated to first page" );
                sharedCoursesPage.clickPreBackwardButton();
            } else {
                Log.assertThat( !sharedCoursesPage.isFastForwardButtonEnabled(), "pre backward button is disabled as expected", "pre backward button is not disabled mode if the shared course have less than 100 courses" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the pagination is updated for the sorted result of shared course listing" );
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.COURSE_NAME );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCourses().equalsIgnoreCase( String.format( SharedCourses.COUNT_OF_COURSES, 1, allCourses.size() > 100 ? 100 : allCourses.size(), allCourses.size() ) ),
                    "The total number shared courses are displayed in the shared course page after sorting by course name", "The total number shared courses are not displayed in the shared course pageafter sorting by course name" );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() > 100 ? allCourses.size() / 100 + 1 : 1 ) ),
                    "The number of pages of shared course displayed for the results in the shared course page after sorting by course name.",
                    "The number of pages of shared course not displayed for the results in the shared course page after sorting by course name." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the pagination is updated for the sorted result of course owner listing" );
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.COURSE_OWNER );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCourses().equalsIgnoreCase( String.format( SharedCourses.COUNT_OF_COURSES, 1, allCourses.size() > 100 ? 100 : allCourses.size(), allCourses.size() ) ),
                    "The total number shared courses are displayed in the shared course page after sorting by course owner", "The total number shared courses are not displayed in the shared course pageafter sorting by course owner" );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() > 100 ? allCourses.size() / 100 + 1 : 1 ) ),
                    "The number of pages of shared course displayed for the results in the shared course page after sorting by course owner.",
                    "The number of pages of shared course not displayed for the results in the shared course page after sorting by course owner." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the pagination is updated for the sorted result of organization shared with listing" );
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.ORGANIZATIONS_SHARED_WITH );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCourses().equalsIgnoreCase( String.format( SharedCourses.COUNT_OF_COURSES, 1, allCourses.size() > 100 ? 100 : allCourses.size(), allCourses.size() ) ),
                    "The total number shared courses are displayed in the shared course page after sorting by organization", "The total number shared courses are not displayed in the shared course pageafter sorting by organization" );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() > 100 ? allCourses.size() / 100 + 1 : 1 ) ),
                    "The number of pages of shared course displayed for the results in the shared course page after sorting by organization.",
                    "The number of pages of shared course not displayed for the results in the shared course page after sorting by organization." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the pagination is updated for the sorted result of organization shared with listing" );
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.ORGANIZATIONS_SHARED_WITH );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCourses().equalsIgnoreCase( String.format( SharedCourses.COUNT_OF_COURSES, 1, allCourses.size() > 100 ? 100 : allCourses.size(), allCourses.size() ) ),
                    "The total number shared courses are displayed in the shared course page after sorting by organization", "The total number shared courses are not displayed in the shared course pageafter sorting by organization" );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, allCourses.size() > 100 ? allCourses.size() / 100 + 1 : 1 ) ),
                    "The number of pages of shared course displayed for the results in the shared course page after sorting by organization.",
                    "The number of pages of shared course not displayed for the results in the shared course page after sorting by organization." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the sort functionality of Shared Course name in navigated next pages in organization shared listing" );
            if ( allCourses.size() > 100 ) {
                sharedCoursesPage.clickForwardButton();
                sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.COURSE_OWNER );
                Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 2, allCourses.size() > 100 ? allCourses.size() / 100 + 1 : 1 ) ),
                        "The number of pages of shared course displayed for the results in the shared course page after sorting by organization.",
                        "The number of pages of shared course not displayed for the results in the shared course page after sorting by organization." );
                sharedCoursesPage.clickPreBackwardButton();
            } else {
                Log.assertThat( !sharedCoursesPage.isForwardButtonEnabled(), "Forward button is disabled as expected", "Forward button is not disabled mode if the shared course have less than 100 courses" );
            }

            SMUtils.logDescriptionTC( "Verify the pagination is updated for the search valid result" );
            sharedCoursesPage.enterValueInSearchBox( allCourses.get( 0 ).substring( 0, 1 ) );
            List<String> filteredCourses = sharedCoursesPage.getAllSharedCourses();
            Log.assertThat( sharedCoursesPage.getCountOfSharedCourses().equalsIgnoreCase( String.format( SharedCourses.COUNT_OF_COURSES, 1, filteredCourses.size() > 100 ? 100 : filteredCourses.size(), filteredCourses.size() ) ),
                    "The total number shared courses are updated in the shared course page for the search valid result", "The total number shared courses are not updated in the shared course page for the search valid result" );
            Log.assertThat( sharedCoursesPage.getCountOfSharedCoursePages().equalsIgnoreCase( String.format( SharedCourses.PAGE_COUNT, 1, filteredCourses.size() > 100 ? filteredCourses.size() / 100 + 1 : 1 ) ),
                    "The number of pages of shared course are updated for the results in the shared course page.", "The number of pages of shared course are not updated for the results in the shared course page." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the pagination is updated for the search invalid result" );
            sharedCoursesPage.enterValueInSearchBox( SharedCourses.ALPHA_NUMERIC_SPECIAL_CHAR );
            Log.assertThat( sharedCoursesPage.getInvalidSearchMsgTxt().contains( AdminConstants.SharedCourses.INVALID_SEARCH_RESULT ), "Not found message is displayed while entering invalid shared course",
                    "Not found message is not displayed while entering invalid shared course" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}