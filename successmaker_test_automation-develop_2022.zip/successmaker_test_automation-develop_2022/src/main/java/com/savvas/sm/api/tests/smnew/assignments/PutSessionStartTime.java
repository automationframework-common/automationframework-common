package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class PutSessionStartTime extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    private String studentToken = null;
    String customCourseId = null;
    String orgID = null;
    String userID = null;
    private String assignmentID;
    private String AssignmentUserId;
    private String sessionId;
    private String studentDetail = null;
    private String studentUserID = null;
    private String studnetUserName = null;
    private String browser;
    private List<String> assignmentTitle;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        Log.message( "Flex school teacher details " + teacherDetails );
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        studentDetail = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studnetUserName = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "saveSessionStartTime_PositiveScenarios", groups = { "SMK-51953", "Save Session start time data", "Assignments", "P1", "API", "smoke_test_case" } )
    public void saveSessionStartTimePositiveScenarios( String description, String scenario, String scenario1, String scenario2, String statusCode, String courseId ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        String mainCourseType = "";
        String courseName = "";

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );
        studentTokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Create Custom course by standards
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );

        if ( scenario.contains( DataSetupConstants.MATH ) ) {
            mainCourseType = DataSetupConstants.MATH;
            courseName = DataSetupConstants.STANDARD_COURSE_NAME_MATH;
        } else {
            mainCourseType = DataSetupConstants.READING;
            courseName = DataSetupConstants.STANDARD_COURSE_NAME_READING;
        }

        //Create custom course
        switch ( scenario1 ) {
            case "customByStandards":
                customCourseId = courseAPI.createCourse( smUrl, token, mainCourseType, userID, orgID, DataSetupConstants.STANDARD, String.format( courseName, System.nanoTime() ) );
                Log.message( "Course id of custom course - " + customCourseId );
                break;

            case "customBySkills":
                customCourseId = courseAPI.createCourse( smUrl, token, mainCourseType, userID, orgID, DataSetupConstants.SKILL, String.format( courseName, System.nanoTime() ) );
                Log.message( "Course id of custom course - " + customCourseId );
                break;

            case "customBySettings":
                customCourseId = courseAPI.createCourse( smUrl, token, mainCourseType, userID, orgID, DataSetupConstants.SKILL, String.format( courseName, System.nanoTime() ) );
                Log.message( "Course id of custom course - " + customCourseId );
                break;

        }

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_OK, token, flexSchool );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );

        switch ( scenario2 ) {
            case "Default and Focus":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                assignmentTitle = SqlHelperAssignment.getAssignmentDetails( assignmentID );
                executeCourse( studnetUserName, assignmentTitle.get( 1 ).trim(), scenario, "1", "5" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                sessionId = SqlHelperAssignment.getSessionId( AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "custom":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, customCourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                assignmentTitle = SqlHelperAssignment.getAssignmentDetails( assignmentID );
                executeCourse( studnetUserName, assignmentTitle.get( 1 ).trim(), scenario, "1", "5" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                sessionId = SqlHelperAssignment.getSessionId( AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;
        }

        HashMap<String, String> studentHeaders = new HashMap<>();
        studentHeaders.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.AUTHORIZATION, "Bearer " + studentToken );
        studentHeaders.put( Constants.ORGID_SM_HEADER, orgID );
        studentHeaders.put( Constants.USERID_SM_HEADER, studentUserID );
        studentHeaders.put( AssignmentAPIConstants.SESSION_ID, sessionId );

        //SesionStart Time
        apiResponse = saveSessionStartTime1( smUrl, studentHeaders, assignmentDetails );
        Log.message( "Save API Changes : " + apiResponse );

        //Assertion

        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for save session start time
     * 
     * @return
     */
    @DataProvider ( name = "saveSessionStartTime_PositiveScenarios" )
    public Object[][] saveSessionStartTime_PositiveScenarios() {
        Object[][] inputData = { { "TC01_Verify the status code is 201 when valid data is given for assignment which has been created from Default Math for PUT Method", "MATH", "No need to create custom course", "Default and Focus", "201", "1" },
                { "TC02_Verify the status code is 201 when valid data is given for assignment which has been created from Custom Math(custom by Setting)  for PUT Method.", "MATH", "customBySettings", "custom", "201", "1" },
                { "TC03_Verify the status code is 201 when valid data is given for assignment which has been created from Custom Math(custom by Skill)  for PUT Method.", "MATH", "customBySkills", "custom", "201", "1" },
                { "TC04_Verify the status code is 201 when valid data is given for assignment which has been created from Custom Math(custom by Standard)  for PUT Method.", "MATH", "customByStandards", "custom", "201", "1" },
                { "TC05_Verify the status code is 201 when valid data is given for assignment which has been created from Focus Math for PUT Method.", "MATH", "customByStandards", "Default and Focus", "201", "3" },
                { "TC08_Verify the status code is 201 when valid data is given for assignment which has been created from Default Reading for PUT Method.", "READING", "No need to create custom course", "Default and Focus", "201", "2" },
                { "TC09_Verify the status code is 201 when valid data is given for assignment which has been created from Custom Reading(custom by Setting) for PUT Method.", "READING", "customBySettings", "custom", "201", "2" },
                { "TC10_Verify the status code is 201 when valid data is given for assignment which has been created from Custom Reading(custom by Skill) for PUT Method.", "READING", "customBySkills", "custom", "201", "2" },
                { "TC11_Verify the status code is 201 when valid data is given for assignment which has been created from Custom Reading(custom by Standard) for PUT Method.", "READING", "customByStandards", "custom", "201", "2" },
                { "TC12_Verify the status code is 201 when valid data is given for assignment which has been created from Focus Reading for PUT Method.", "READING", "customByStandards", "Default and Focus", "201", "11" } };
        return inputData;
    }

    //    @Test ( priority = 1, dataProvider = "saveSessionStartTime_NegativeScenarios", groups = { "SMK-51953", "Save Session start time data", "Assignemnts", "P1", "API" } )
    public void saveSessionStartTimeNegativeScenarios( String description, String scenario2, String statusCode, String courseId, String assignmentUserId ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );
        studentTokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_OK, token, flexSchool );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );

        switch ( courseId ) {
            case "1":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                break;

            case "2":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                break;
        }

        Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
        Log.message( Response.get( "body" ) );
        assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
        AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
        sessionId = SqlHelperAssignment.getSessionId( AssignmentUserId );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );

        HashMap<String, String> invalidAssignmentDetails = new HashMap<>();
        HashMap<String, String> headersInvalidToken = new HashMap<>();

        HashMap<String, String> studentHeaders = new HashMap<>();
        studentHeaders.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.AUTHORIZATION, "Bearer " + studentToken );
        studentHeaders.put( Constants.ORGID_SM_HEADER, orgID );
        studentHeaders.put( Constants.USERID_SM_HEADER, studentUserID );
        studentHeaders.put( AssignmentAPIConstants.SESSION_ID, sessionId );

        switch ( scenario2 ) {

            case "invalid authorization":
                headersInvalidToken.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.AUTHORIZATION, "Bearer " + CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                headersInvalidToken.put( Constants.ORGID_SM_HEADER, orgID );
                headersInvalidToken.put( Constants.USERID_SM_HEADER, studentUserID );
                apiResponse = saveSessionStartTime( smUrl, headersInvalidToken, assignmentDetails );
                Log.message( "Save API Changes : " + apiResponse );
                break;

            case "invalid assignment id":
                invalidAssignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                apiResponse = saveSessionStartTime( smUrl, studentHeaders, invalidAssignmentDetails );
                Log.message( "Save API Changes : " + apiResponse );
                break;
        }

        //Assertion
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider save session start time
     * 
     * @return
     */
    @DataProvider ( name = "saveSessionStartTime_NegativeScenarios" )
    public Object[][] saveSessionStartTime_NegativeScenarios() {
        Object[][] inputData = { { "TC15_Verify the status code is 401 when expired/invalid Authorization is given for PUT Method.", "invalid authorization", "401", "1", null },
                { "TC17_Verify the status code is 400 when invalid Assignment User ID is given for PUT Method.", "invalid assignment id", "400", "1", "@#$%" },
                { "TC18_Verify the status code is 400 when Assignment User ID of different student is given for PUT Method.", "invalid assignment id", "400", "2", "1345" },
                { "TC19_Verify the status code is 400 when Assignment User ID is given as string for PUT Method.", "invalid assignment id", "400", "2", "test" }

        };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            //            teacherDetails = teacherDetails;

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    //Token creation for Student login
    public void studentTokenCreation( String school ) {
        try {

            studentToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        //        HashMap<String, String> userDetails = new HashMap<>();
        List<String> groupIds = new ArrayList<>();
        GroupAPI groupAPI = new GroupAPI();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            groupIds.add( SMUtils.getKeyValueFromResponse( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

            //Student creation
            //            String studentUsername = "AddStudGRPS1" + System.nanoTime();
            //            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
            //            userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
            //            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            //            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

            //            String studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
            //            studentRumbaIds.add( studentID );

            studentRumbaIds.add( studentUserID );

            response = groupAPI.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );

            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected for add studnet to group!!",
                    "Issue in returning status code for group creation! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    // To Execute Course
    public void executeCourse( String studentUserName, String courseName, String courseType, String numberOfSessions, String numberOfQuestions ) throws IOException {
        final WebDriver studentDriver = WebDriverFactory.get( browser );
        LoginWrapper.loginToSuccessMakerAsStudent( studentDriver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( studentDriver );
        if ( courseType.equalsIgnoreCase( Constants.MATH ) ) {
            studentsPage.executeMathCourse( studentUserName, courseName, "75", numberOfSessions, numberOfQuestions );
        } else {
            studentsPage.executeReadingCourse( studentUserName, courseName, "75", numberOfSessions, numberOfQuestions );
        }
        studentsPage.logout();
        studentDriver.close();
    }

    //************

    public HashMap<String, String> saveSessionStartTime1( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails ) {
        try {
            Map<String, String> Headers = new HashMap<>();
            Headers.put( "session-id", headers.get( AssignmentAPIConstants.SESSION_ID ) );
            Headers.put( Constants.AUTHORIZATION, headers.get( Constants.AUTHORIZATION ) );
            Headers.put( Constants.ORGID_SM_HEADER, headers.get( Constants.ORGID_SM_HEADER ) );
            Headers.put( Constants.USERID_SM_HEADER, headers.get( Constants.USERID_SM_HEADER ) );
            Headers.put( Constants.CONTENT_TYPE, headers.get( Constants.CONTENT_TYPE ) );
            Headers.put( Constants.ACCEPT_TYPE, headers.get( Constants.ACCEPT_TYPE ) );

            String endpoint = CourseAPIConstants.SAVE_SAVE_SESSION_START_TIME;
            Log.message( "Save session start time = " + endpoint );

            String courseStartTime = String.valueOf( ZonedDateTime.now().toInstant().toEpochMilli() );

            endpoint = endpoint.concat( "/" ) + assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID ) + "?courseStartTime=" + courseStartTime;

            //Parameters
            HashMap<String, String> params = new HashMap<>();
            //            params.put( CourseAPIConstants.COURSE_START_TIME, courseStartTime );

            String requestBody = "";

            Log.message( Headers.toString() );

            HashMap<String, String> responseSaveSessionStartTime = RestHttpClientUtil.PUT( envUrl, Headers, params, endpoint, requestBody );

            return responseSaveSessionStartTime;

        } catch ( Exception e ) {
            Log.message( "Error in saveSCO method" );
            return null;
        }
    }
}