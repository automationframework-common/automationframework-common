package com.savvas.sm.api.tests.smnew.users;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.ReturnStudentListAPI;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

/**
 * This class used to test the API of get student list not part of the given
 * assignment
 * 
 * @author praveen.rangopi
 *
 */
public class GetStudentDetailsNotPartOfCourse extends UserAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String teacherDetails1 = null;
    private String teacherDetails2 = null;
    private String studentDetail = null;
    private String studentDetail1 = null;
    private String studentUsername = null;
    private String studentUserID = null;
    private String studentUserID1 = null;
    Boolean result = false;
    // private String teacherDetails3 = null;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String school1 = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String accessToken;
    RBSUtils rbs = new RBSUtils();
    RBSDataSetup data = new RBSDataSetup();
    public String userId;
    public String userId1;
    public String userId2;
    public String orgId;
    public String orgId1;
    // public String orgId1;
    public String username;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    // public String courseID;
    public String studentID1;
    public String studentID2;
    public String classId1;
    public String classId2;
    public String classId3;
    public String class1;
    public String class2;
    public HashMap<String, String> assignmentDetails = new HashMap<>();
    GroupAPI gUsage = new GroupAPI();
    UserAPI baseapi = new UserAPI();
    HashMap<String, String> assignCourseToTheStudent = new HashMap<String, String>();
    public static String fName;
    public static String mName;
    public static String lName;
    public static String studId;
    public static String uName;
    public String multipleSchoolTeacherID;
    public String multipleSchoolTeacherName;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        mathOnlyProduct = configProperty.getProperty( "mathOnlyProduct" );
        readingOnlyProduct = configProperty.getProperty( "readingOnlyProduct" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school1 );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentDetail1 = RBSDataSetup.getMyStudent( school, username );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUserID1 = SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        userId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USERID_HEADER );
        userId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );
        orgId = RBSDataSetup.organizationIDs.get( school );
        orgId1 = RBSDataSetup.organizationIDs.get( school1 );

        HashMap<String, String> userDetails = new HashMap<String, String>();
        List<String> schools = new ArrayList<String>();

        String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        String listString = "";
        for ( String school : schools ) {
            listString += school.concat( "\",\"" );
        }
        listString = listString.substring( 0, listString.length() - 3 );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
        String createUser = rbs.createUser( userDetails );

        multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
        multipleSchoolTeacherName = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

        HashMap<String, String> classDetails = new HashMap<String, String>();
        List<String> studentIds = new ArrayList<>();
        studentIds.add( studentUserID );
        studentIds.add( studentUserID1 );
        String className1 = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className1 );
        classId2 = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, studentIds ).get( Constants.BODY ), "data,groupId" );
    }

    @Test ( priority = 1, dataProvider = "returnStudentDetails", groups = { "smoke_test_case", "smoke unassigned course student001", "StudentNotPartofCourse", "SMK-52037", "courses", "ReturnStudentList", "P1", "API" } )
    public void tcReturnStudentList001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        String className = "Clever" + System.nanoTime();
        String courseName = "CustomCourse" + System.nanoTime();
        List<String> studentIDsToAddInClass = new ArrayList<String>();
        List<String> studentIDsToAssignCourse = new ArrayList<String>();
        String finalSchool = "";
        HashMap<String, String> classDetails = new HashMap<>();
        HashMap<String, String> apiResponse = null;
        String accessToken;
        String courseID = null;
        switch ( scenario ) {

            case "TEACHER_WITHOUT_SUCCESSMAKER_PRODUCT":
                accessToken = rbs.getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                studentID1 = createStudent();
                studentID2 = createStudent();
                studentIDsToAddInClass.add( studentID1 );
                studentIDsToAddInClass.add( studentID2 );
                List<String> teachers = new ArrayList<String>();
                teachers.add( multipleSchoolTeacherID );

                classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                classDetails.put( RBSDataSetupConstants.USERNAME, multipleSchoolTeacherName );
                classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails.put( RBSDataSetupConstants.SECTION_NAME, className );
                classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studentID1 );
                // group created with Third party application
                class1 = rbs.createClassWithMultipleTeacher( classDetails, teachers, studentIDsToAddInClass );
                classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId1 );

                JSONObject jsonnObject2 = new JSONObject( class1 );
                classId1 = jsonnObject2.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat( validateExceptionAndErrorMessage( baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION,
                        ReturnStudentListAPI.STUDENT_NOT_FOUND_MESSAGE, statusCode ), "Proper Exception and Error Message Thrown for Teacher without sucessmaker product", "Error : In throwing exception" );
                break;


            case "HAPPY PATH":
                accessToken = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                studentIDsToAssignCourse.add( studentUserID );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentIDsToAssignCourse, AssignmentAPIConstants.USERS_TYPE );
                Log.message( "data Setup" + assignCourseToTheStudent.toString() );
                apiResponse = baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                Log.message( "Data Setup " + apiResponse.toString() );
                Log.assertThat( validateResponseWithCMS( apiResponse, rbs.getUser( studentUserID1 ), studentUserID1 ), "Unassigned Student Detail fetched sucessfully and validated the fields with CMS Response", "Error in API" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "returnStudentList", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "STUDENT_WITH_DEFAULT_COURSE":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                studentIDsToAssignCourse.add( studentUserID );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentIDsToAssignCourse, AssignmentAPIConstants.USERS_TYPE );
                apiResponse = baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                Log.assertThat( validateResponseWithCMS( apiResponse, rbs.getUser( studentUserID1 ), studentUserID ), "Unassigned Student Detail fetched sucessfully and validated the fields with CMS Response", "Error in API" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "returnStudentList", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "STUDENT_WITH_CUSTOM_COURSE":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                studentIDsToAssignCourse.add( studentUserID );
                String assignemntID = new CourseAPI().createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL, courseName );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, assignemntID );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentIDsToAssignCourse, AssignmentAPIConstants.USERS_TYPE );
                apiResponse = baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                Log.assertThat( validateResponseWithCMS( apiResponse, rbs.getUser( studentUserID1 ), studentUserID1 ), "Unassigned Student Detail fetched sucessfully and validated the fields with CMS Response", "Error in API" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "returnStudentList", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "STUDENT_WITH_FOCUS_COURSE":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                studentIDsToAssignCourse.add( studentUserID );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.FOCUS_COURSE_1 );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentIDsToAssignCourse, AssignmentAPIConstants.USERS_TYPE );
                apiResponse = baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                Log.assertThat( validateResponseWithCMS( apiResponse, rbs.getUser( studentUserID1 ), studentUserID1 ), "Unassigned Student Detail fetched sucessfully and validated the fields with CMS Response", "Error in API" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "returnStudentList", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "STUDENTS_ASSIGNED_WITH_ASSIGNMENTS":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                apiResponse = baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                Log.assertThat( validateAssignedStudentNotShownInResponse( apiResponse, studentID1 ), "Assigned Student Details are not shown in the response", "Error : Assigned Student details are showing in the response" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "returnStudentList", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "GROUP_ASSIGNMENT":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                List<String> groupids = new ArrayList<String>();
                groupids.add( classId2 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.FOCUS_COURSE_2 );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, groupids, AssignmentAPIConstants.GROUPS_TYPE );
                Log.assertThat( validateAssignedStudentNotShownInResponse( baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), studentUserID ),
                        "The Student not shown to the assignment When he is already assigned with the assignment from group Level", "Error : Already assigned assignment shown for the student" );
                break;

            case "MULTI_SCHOOL_STUDENT":
                HashMap<String, String> userDetails = new HashMap<String, String>();
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                List<String> schools = new ArrayList<String>();
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );

                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = data.generateRequestValues( rbs.getUser( multiSchoolStudentID ), studentInfo, UserConstants.SCHOOLID, orgId1 );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId1 );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERID ) );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                SMUtils.updateRequestBodyValues( studentInfo, UserConstants.GRADE, "FIFTH" );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                List<String> studentIds = new ArrayList<>();
                studentIds.add( multiSchoolStudentID );

                String className1 = "Test Class" + System.nanoTime();
                classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId1 );
                classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId1 );
                classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className1 );
                classId3 = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, studentIds ).get( Constants.BODY ), "data,groupId" );

                String className2 = "Test Class" + System.nanoTime();
                classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId );
                classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className2 );
                String classId4 = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, studentIds ).get( Constants.BODY ), "data,groupId" );

                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId1 );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId1 );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentIds, AssignmentAPIConstants.USERS_TYPE );

                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                // Validation
                Log.assertThat( validateAssignedStudentNotShownInResponse( baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), multiSchoolStudentID ), "Assigned Student Details are not shown in the response",
                        "Error : Assigned Student details are showing in the response" );
                break;

            case "TEACHER_WITHOUT_CLASS":
                String teacherWithoutClass = "SharedTeacher" + System.nanoTime();
                HashMap<String, String> teacherDets = new HashMap<>();
                teacherDets.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                teacherDets.put( RBSDataSetupConstants.USERNAME, teacherWithoutClass );
                teacherDets.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                teacherDets.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );

                String teacherWithoutClasstID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( teacherDets ), RBSDataSetupConstants.USERID );

                rbs.resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, teacherWithoutClasstID );

                accessToken = rbs.getAccessToken( teacherWithoutClass, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, teacherWithoutClasstID );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                apiResponse = returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                Log.assertThat( validateExceptionAndErrorMessage( apiResponse, ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION, ReturnStudentListAPI.STUDENT_NOT_FOUND_MESSAGE, statusCode ), "Proper Exception Thrown for Teacher Without Class",
                        "Error : Message and Exception is not as expected" );
                break;

            case "SHARED_STUDENT":
                String groupName = "SharedStudent" + System.nanoTime();
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME );

                List<String> sharedStudent = new ArrayList<String>();
                sharedStudent.add( studentID2 );
                sharedStudent.add( studentID1 );
                List<String> sharedStudentteacher = new ArrayList<String>();
                sharedStudentteacher.add( userId2 );
                HashMap<String, String> sharedStudentClass = new HashMap<>();
                sharedStudentClass.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                sharedStudentClass.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ) );
                sharedStudentClass.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                sharedStudentClass.put( RBSDataSetupConstants.SECTION_NAME, groupName );
                sharedStudentClass.put( RBSDataSetupConstants.STUDENT_PI_ID, studentID1 );
                // group created with Third party application
                class1 = rbs.createClassWithMultipleTeacher( sharedStudentClass, sharedStudentteacher, sharedStudent );

                JSONObject jobjectForShared = new JSONObject( class1 );
                classId2 = jobjectForShared.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

                String adminToken1 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId2, mathOnlyProduct, adminToken1, userId2 );

                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId2 );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );

                // Validation
                Log.assertThat( validateAssignedStudentNotShownInResponse( baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), studentID1 ),
                        "Student already assigned with TeacheA is not showing in the response for Teacher B", "Error : Already Assigned Details are showing in the response" );
                break;

        }
        Log.testCaseResult();

    }

    @DataProvider ( name = "returnStudentDetails" )
    public Object[][] returnGrpDetails() {
        Object[][] inputData = { { "Verify the teacher cannot able to see the students when they don't have successmaker product associated with their class.", "TEACHER_WITHOUT_SUCCESSMAKER_PRODUCT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the students who don't have the courses assigned.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot see the students when they already assigned with focus courses", "STUDENT_WITH_FOCUS_COURSE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot see the students when they already assigned with Custom courses.", "STUDENT_WITH_CUSTOM_COURSE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot see the students when they already assigned with default courses.", "STUDENT_WITH_DEFAULT_COURSE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot able to see the students when the students already has the assignment assigned.", "STUDENTS_ASSIGNED_WITH_ASSIGNMENTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot able to see the student when the course already assigned to group and the student is part of the group", "GROUP_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the student from School 1 when the student part of multiple school and the same course assigned in school 2", "MULTI_SCHOOL_STUDENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot able to see the students who don't have any classes associated", "TEACHER_WITHOUT_CLASS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher1 cannot see the students when the teacher2 already assigned the assignment to students.", "SHARED_STUDENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot see the students when they already assigned with assignment by other teacher", "SHARED_STUDENT", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;
    }

    @Test ( priority = 1, dataProvider = "invalidScenarios", groups = { "SMK-52037", "courses", "ReturnStudentList", "P1", "API" } )
    public void tcReturnStudentList002( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );

        String courseName = "CustomCourse" + System.nanoTime();
        List<String> studentIDsToAddInClass = new ArrayList<String>();
        List<String> studentIDsToAssignCourse = new ArrayList<String>();
        HashMap<String, String> assignmentDetails = new HashMap<>();

        switch ( scenario ) {

            case "OTHER_TEACHER_ORG_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat( apiForInvalidAuth( smUrl, assignmentDetails, userId, orgId1 ).get( Constants.REPORT_STATUS_CODE ).equals( statusCode ), "Status code for Other Teacher Organization thrown successfully",
                        "Error : Message and Exception is not as expected" );
                break;

            case "INVALID_ORGANIZATION":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                HashMap<String, String> returnStudentListNotPartOfCourse = returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.INVALID_ORG_ID );
                Log.assertThat( returnStudentListNotPartOfCourse.get( Constants.REPORT_STATUS_CODE ).equals( statusCode ), "Status code for Invalid Organization thrown successfully", "Error : Message and Exception is not as expected" );
                break;

            case "INVALID_TEACHER_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat( validateExceptionAndErrorMessage( returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.INVALID_TEACHER ), ReturnStudentListAPI.BUSINESS_RULE_EXCEPTION,
                        ReturnStudentListAPI.INVALID_TEACHER_MESSAGE, statusCode ), "Message and Exception for Invalid Organization thrown successfully", "Error : Message and Exception is not as expected" );
                break;

            case "INVALID_COURSE_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat( returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.INVALID_COURSE_ID ).get( Constants.REPORT_STATUS_CODE ).equals( statusCode ), "Status code matched for invalid course id",
                        "Error : Response showing for invalid course id" );
                break;

            case "INVALID_AUTHENTICATION":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat(
                        validateExceptionAndErrorMessage( returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), ReturnStudentListAPI.EXCEPTION_MESSAGE, ReturnStudentListAPI.AUTHENTICATION_FAILED_MESSAGE, statusCode ),
                        "Message and Exception for Invalid Authentication thrown successfully", "Error : Message and Exception is not as expected" );

                break;

            case "INVALID_HEADERS":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId + 1 );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat(
                        validateExceptionAndErrorMessage( returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), ReturnStudentListAPI.EXCEPTION_MESSAGE, ReturnStudentListAPI.AUTHENTICATION_FAILED_MESSAGE, statusCode ),
                        "Message and Exception for Invalid Headers thrown successfully", "Error : Message and Exception is not as expected" );
                break;

            case "ASSIGNMENT_ID":
                String assignID = null;
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                studentIDsToAssignCourse.add( studentUserID1 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentIDsToAssignCourse, AssignmentAPIConstants.USERS_TYPE );
                JSONObject jsonObject = new JSONObject( assignCourseToTheStudent.get( Constants.BODY ) );
                assignID = jsonObject.getJSONObject( Constants.DATA ).get( Constants.ASSIGNMENT_ID ).toString();
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, assignID );
                Log.assertThat( returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ).get( Constants.REPORT_STATUS_CODE ).equals( statusCode ), "Status code matched for assignment id passed instead of content base id",
                        "Error : Response showing for assignment id" );
                break;

            case "OTHER_TEACHER_AUTHORIZATION":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, userId1 );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId1 );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                Log.assertThat( validateExceptionAndErrorMessage( apiForInvalidAuth( smUrl, assignmentDetails, userId, orgId ), ReturnStudentListAPI.BUSINESS_RULE_EXCEPTION, ReturnStudentListAPI.INVALID_TEACHER_MESSAGE, statusCode ),
                        "Teacher Cannot be able able to see other teacher details successfully", "Error : Teacher Can be able to see other teacher detail successfullly" );
                break;

            case "STUDENT_AUTHORIZATION":
                accessToken = rbs.getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, studentUserID );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                HashMap<String, String> apiForInvalidAuth = apiForInvalidAuth( smUrl, assignmentDetails, userId, orgId );
                Log.message( apiForInvalidAuth.toString() );

                Log.assertThat( validateExceptionAndErrorMessage( apiForInvalidAuth( smUrl, assignmentDetails, userId, orgId ), ReturnStudentListAPI.ACCESS_DENIED_EXCEPTION, ReturnStudentListAPI.ACCESS_DENIED_MESSAGE, statusCode ),
                        "Successfully Forbidden the student authentication", "Error : Student can be able to see Teacher Details" );
                break;
                

            case "STUDENT_WITH_NOT SPECIFIED_GRADE":
                accessToken = rbs.getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                String accessToken1 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId1, mathOnlyProduct, accessToken1, multipleSchoolTeacherID );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetails.put( CourseAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
                assignmentDetails.put( CourseAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( CourseAPIConstants.COURSE_ID, ReturnStudentListAPI.MATH_CONTENT_ID );
                String studentUserIDNS = SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER );
                Log.message( studentUserIDNS );
                //HashMap<String, String> returnStudentListNotPartOfCourse = baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID );
                //Log.message( returnStudentListNotPartOfCourse.toString() );
                Log.assertThat( validateExceptionAndErrorMessage( baseapi.returnStudentListNotPartOfCourse( smUrl, assignmentDetails, ReturnStudentListAPI.VALID ), "null", "Retreived UnAssigned student list", statusCode ),
                        "Student With Grade NotSpecified details are not returned in the response", "Error in Not specified student details" );
                break;
        }
        Log.testCaseResult();
    }

    // Commented Scenario is a backlog ticket (Response showing for invalid course
    // Id) - Link https://jira.savvasdev.com/browse/SMK-53435
    @DataProvider ( name = "invalidScenarios" )
    public Object[][] returnGrpDetailsforInvalidData() {
        Object[][] inputData = { { "Verify the API when the teacher not belongs to the school. ", "OTHER_TEACHER_ORG_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returns 400 when the org ID is invalid.", "INVALID_ORGANIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returns 400 when the Teacher ID is invalid.", "INVALID_TEACHER_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returns 403 when the access token given by the student.", "STUDENT_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the teacher cannot able to see the students from other school teacher", "OTHER_TEACHER_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

                //				  { "Verify the API returns 400 when the course ID is invalid.",
                //				  "INVALID_COURSE_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

                { "Verify the API returns 401 when the authentication is wrong.", "INVALID_AUTHENTICATION", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API returning 401 when the headers are not given properly.", "INVALID_HEADERS", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the teacher cannot see the students from other school when they don't assigned with any assignment.", "OTHER_TEACHER_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the teacher cannot able to see other teacher students when the student not assigned with the assignment.", "OTHER_TEACHER_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the student details returned that are not part of given course id", "STUDENT_WITH_NOT SPECIFIED_GRADE", CommonAPIConstants.STATUS_CODE_OK }

                //				  {"Verify the student details not displayed when assigment id is given in the endpoint", "ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }
        };
        return inputData;
    }

    /*
     * To Create student
     * 
     * @return
     * 
     * @throws Exception
     */

    private String createStudent() throws Exception {
        HashMap<String, String> userDetails = new HashMap<>();
        String Student = "student" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, Student );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        return SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

    }

    // To Validate Response with CMS
    public Boolean validateResponseWithCMS( HashMap<String, String> apiResponse, String user, String studentIdAssigned ) {
        JSONObject jsonObject = new JSONObject( apiResponse.get( Constants.BODY ) );
        JSONArray array = jsonObject.getJSONArray( Constants.DATA );

        IntStream.range( 0, array.length() ).forEach( iter -> {
            String eachObject = array.getJSONObject( iter ).toString();
            fName = SMUtils.getKeyValueFromResponse( eachObject, Constants.FIRSTNAME );
            mName = SMUtils.getKeyValueFromResponse( eachObject, Constants.MIDDLENAME );
            lName = SMUtils.getKeyValueFromResponse( eachObject, Constants.LASTNAME );
            studId = SMUtils.getKeyValueFromResponse( eachObject, Constants.StudentID );
            uName = SMUtils.getKeyValueFromResponse( eachObject, ReturnStudentListAPI.USERNAME );
            if ( studId.equals( studentIdAssigned ) ) {
                // Validation with CMS Response
                if ( SMUtils.getKeyValueFromResponse( user, Constants.USERID_HEADER ).equals( studId ) && SMUtils.getKeyValueFromResponse( user, Constants.USER_NAME ).equals( uName )
                        && SMUtils.getKeyValueFromResponse( user, Constants.FIRSTNAME ).equals( fName ) && SMUtils.getKeyValueFromResponse( user, Constants.MIDDLENAME ).equals( mName )
                        && SMUtils.getKeyValueFromResponse( user, Constants.LASTNAME ).equals( lName ) ) {
                    result = true;

                }
            }
        } );

        return result;

    }

    // To Validate Error Messag, Exception Message and Status Code
    public Boolean validateExceptionAndErrorMessage( HashMap<String, String> response, String exception, String errorMessage, String responseCode ) {
        Boolean status = false;
        JSONObject jsonObject = new JSONObject( response.get( Constants.BODY ) );
        String responseError = jsonObject.getJSONArray( Constants.MESSAGES ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
        String responseException = jsonObject.getJSONArray( Constants.MESSAGES ).getJSONObject( 0 ).get( Constants.EXCEPTION ).toString();
        String responseStatusCode = response.get( Constants.REPORT_STATUS_CODE );

        if ( responseError.equals( errorMessage ) && responseException.equals( exception ) && responseStatusCode.equals( responseCode ) ) {
            status = true;
        }
        return status;
    }

    // To Verify whether the assigned student is not returnin in the response
    public Boolean validateAssignedStudentNotShownInResponse( HashMap<String, String> apiResponse, String studentIdAssigned ) {
        Boolean status = true;
        List<String> stuIds = new ArrayList<String>();
        JSONObject jsonObject = new JSONObject( apiResponse.get( Constants.BODY ) );
        JSONArray array = jsonObject.getJSONArray( Constants.DATA );

        IntStream.range( 0, array.length() ).forEach( iter -> {
            String eachObject = array.getJSONObject( iter ).toString();
            stuIds.add( SMUtils.getKeyValueFromResponse( eachObject, Constants.StudentID ) );
        } );
        for ( String eachId : stuIds ) {
            if ( eachId.equals( studentIdAssigned ) ) {
                status = false;
            }
        }
        return status;
    }

    public HashMap<String, String> apiForInvalidAuth( String envUrl, HashMap<String, String> teacherDetails, String userID, String organizationID ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        String orgID = teacherDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = teacherDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = teacherDetails.get( AssignmentAPIConstants.COURSE_ID );

        // Headers
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, teacherID );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.AUTHORIZATION, "Bearer " + teacherDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        // Endpoints
        String endPoint = ReturnStudentListAPI.RETURN_STUDENT_ENDPOINT;
        endPoint = endPoint.replace( Constants.ORG_ID, organizationID );
        endPoint = endPoint.replace( Constants.USER_ID_VALUE, userID );
        endPoint = endPoint.replace( Constants.COURSE_ID, courseID );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
        return response;

    }

}
