package com.savvas.sm.ui.tests.smnew.Mastery;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.HomePageWidgetConstants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryPage;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

/*
 * @author aravindan.sivanandan This class test whether the mastery top & low
 * performing data are displayed in the teacher dashboard under Home Page
 * Mastery Widget based on formula.
 */

public class MasteryPerformanceTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    String teacherDetails;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = MasteryDataSetup.teacherUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( priority = 1, groups = { "SMK-51606", "mastery", "HomePage-Mastery-Top & Low Performing" } )
    public void tcMasteryHomePageTest_001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        try {
            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            SMUtils.waitForSpinnertoDisapper( driver );
            MasteryPage masterypage = new MasteryPage( driver );

            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> mathAssignments = assignmentPage.getMathCourses();
            List<String> readingAssignments = assignmentPage.getReadingCourses();
            teacherHomePage.topNavBar.navigateToHomeTab();

            SMUtils.logDescriptionTC( "SMK-22981,Verify on Mastery Card shows the 'Top Performing' (up to 3) and 'Low Performing' (up to 3) skills " + "for the particular assignment based on the subject & standards" );
            SMUtils.logDescriptionTC( "SMK-22982:Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two column" );
            SMUtils.logDescriptionTC( "SMK-22983:Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two columns and it has " + "LO Number, Skill name and Percentage displayed in it for math related assignments only" );
            SMUtils.logDescriptionTC( "SMK-22984:Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two columns and it has " + "Skill name and Percentage displayed in it for reading related assignments only" );
            SMUtils.logDescriptionTC( "SMK-22985:Verify on Mastery card, The first top three performing LO/skill datas are shown in percentage in the top " + "performing column for the mastered students with respect to subject,standards and assignment" );
            SMUtils.logDescriptionTC( "SMK-22986:Verify on Mastery card, The first three low performing LO/skill datas are shown in percentage in the low " + "performing column for the mastered students with respect to subject,standards and assignment" );
            SMUtils.logDescriptionTC( "SMK-22992:Verify the text 'Mastered' is displayed under percentage view in the mastery card top and low performing " + "column for the particular assignment ,standards and subject" );
            SMUtils.logDescriptionTC( "SMK-22993:Verify the correct LO/skill percentage is displayed in the mastery card top and low performing column for " + "the particular/All assignment ,standards and subject selected from the dropdown" );
            SMUtils.logDescriptionTC( "SMK-22994:Verify the 'view all' link is seen along with the breadcrumb icon in the top and low performing column under mastery card" );
            SMUtils.logDescriptionTC( "SMK-22991:Verify the LO/skill percentage displayed in the mastery card top and low performing column includes unassessed students count in calculation to that particular Assignment" );
            SMUtils.logDescriptionTC(
                    "SMK-22988:Verify the top or low 3 performing LOs/skill Percentage for an assignment displays accordingly in the mastery card in top and low performing column based on students mastered & total students assigned to a particular  assignment only which is selected from the assignment dropdown by the teacher" );
            SMUtils.logDescriptionTC(
                    "SMK-22987:Verify the top or low 3 performing LO/skill  percentage for all assignments displays accordingly in the mastery card in top and low performing column based on students mastered & total students assigned in all assignments if all assignments is selected from the dropdown" );
            teacherHomePage.verifyingMasteryCard();
            SMUtils.logDescriptionTC( "SMK-22995:Verify after clicking view all link breadcrumb icon , homepage is navigated to mastery summary " + "page under primary mastery tab" );
            teacherHomePage.clickViewAllinMasteryCard();
            Log.assertThat( masterypage.getMasteryHeading().equals( "Mastery" ), "NavigateD to Mastery page", "Clicking view all  is not navigated to Mastery page" );
            teacherHomePage.topNavBar.navigateToHomeTab();
            SMUtils.logDescriptionTC( "SMK-22976:Verify on Mastery Card , Apply filter button is in enabled state when '0 Assignment(s) ' is " + "selected from the assignment dropdown" );
            teacherHomePage.clickAssignmentDropdown();
            teacherHomePage.clickSelectAllCheckbox();
            Log.assertThat( !teacherHomePage.isMasteryApplyFilterdisabled(), "The apply filter is enabled", "The apply filter is not enabled" );
            SMUtils.logDescriptionTC( "SMK-22975:Verify on Mastery Card 'Top Performing' and 'Low Performing' datas are not displaying when " + "clicked on Apply filter button if '0 Assignment(s) ' is selected from the assignment dropdown" );
            teacherHomePage.clickApplyFilterinMasteryCard();
            Log.assertThat( !teacherHomePage.isMasterycardHasSkills(), "The skills are not displaying as Expected!", "The skills are displaying for the when 0 assignment is checked" );
            SMUtils.logDescriptionTC( "SMK-22978:Verify previously loaded Mastery Data are getting cleared on navigating back to home page" );
            teacherHomePage.selectAssignmentsinMasteryCard( Arrays.asList( "Math" ) );
            List<String> topSkillsPercent = teacherHomePage.getMasteryPercentValues( HomePageWidgetConstants.TOP_PERFORMING );
            teacherHomePage.navigateToGroupsMenu();
            teacherHomePage.topNavBar.navigateToHomeTab();
            //SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, teacherHomePage.getMasteryCardContainerElement(), 5 );
            Log.assertThat( !topSkillsPercent.equals( teacherHomePage.getMasteryLoDetails( HomePageWidgetConstants.TOP_PERFORMING ) ), "The values are changed", "The values are not changed" );
            SMUtils.logDescriptionTC( "SMK-22977:Verify previously loaded Mastery Data are getting cleared by logout and login again." );
            teacherHomePage.selectAssignmentsinMasteryCard( Arrays.asList( "Math" ) );
            topSkillsPercent = teacherHomePage.getMasteryLoDetails( HomePageWidgetConstants.TOP_PERFORMING );
            Log.assertThat( !topSkillsPercent.equals( teacherHomePage.getMasteryPercentValues( HomePageWidgetConstants.TOP_PERFORMING ) ), "The values are changed as expected!", "The values are not changed" );
            SMUtils.logDescriptionTC( "SMK-22979:Verify the assignment dropdown will list all available assignments for the logged in teacher based on subject only in mastery card in home page irrespective of standards selection " );
            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            // Math courses filter
            masteryFiltersComponent.selectSubject( Constants.MATH );
            teacherHomePage.clickApplyFilterinMasteryCard();
            List<String> filteredList = teacherHomePage.getAllAssignments();
            Collections.sort( mathAssignments );
            Collections.sort( filteredList );
            Log.assertThat( mathAssignments.equals( filteredList ), "All the math courses is listed", "All the math courses is not listed" );

            // Reading courses filter
            masteryFiltersComponent.selectSubject( Constants.READING );
            teacherHomePage.clickApplyFilterinMasteryCard();
            filteredList = teacherHomePage.getAllAssignments();
            Collections.sort( readingAssignments );
            Collections.sort( filteredList );
            Log.assertThat( readingAssignments.equals( filteredList ), "All the reading courses is listed", "All the reading courses is not listed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-51606", "mastery", "HomePage-Mastery-Top & Low Performing" } )
    public void tcMasteryHomePageTest_002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            // Go to the  assignment detail Page
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> AssignmentsName = assignmentsPage.getColumnAssignmentValues();

            // Deleting a all assignments
            for ( String assignmentName : AssignmentsName ) {
                AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentName );
                assignmentDetailsPage.deleteAssignment();
            }
            teacherHomePage.topNavBar.navigateToHomeTab();
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, teacherHomePage.getMasteryCardContainerElement(), 5 );
            SMUtils.logDescriptionTC( "SMK - 22976,Verify when Assignment count is zero, zero state message is displayed" );
            //Check for the zero state message for Low Performing
            Log.softAssertThat( teacherHomePage.getAllAssignments().size() < 1, "The assignment count is zero as expected!", "The assignments count is not zero as expected!" );

            //  SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
