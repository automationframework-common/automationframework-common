package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class CoursesNodes2 {
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    //Change this index if you want to select use teacher other than "Teacher63"
    //private String teacherIndex = "63";
    private String schoolID;
    private String teacherID;
    String studentDetails;
    String teacherDetails;
    Set<String> loMainListForMath = new HashSet<>();
    Set<String> loMainListForReading = new HashSet<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    CourseAPI coursesAPI = new CourseAPI();

    @BeforeTest
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    /**
     * This method is used to get bank id of the respective grade under the
     * standards.
     *
     * @param grade
     * @param standardsName
     */
    public String getBankIdOfTheGrade( String grade, String standardsName ) {
        String bankId = null;
        String queryString = "SELECT bank_id FROM successmaker.bank WHERE state_text='" + grade + "'AND parent_bank_id IN (SELECT bank_id FROM successmaker.bank WHERE state_text='" + standardsName + "')";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<>();
        if ( listItems.isEmpty() ) {
            listItems = SQLUtil.executeQuery( queryString );
        }
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        bankId = arrList.get( 0 );
        Log.message( "Bank id is " + bankId );
        return bankId.trim();
    }

    @Test ( description = "Get all the LO Details for Math and Reading", groups = { "SMK-43955", "Courses", "Courses - Tier2_Nodes" }, priority = 1 )
    public void verifyCoursesNodes_001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "Get all the LO Details for Math and Reading" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );

            HashMap<String, String> skillsHierarchyDetails = new HashMap<>();

            //Authorization
            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            //Get Standards Hierarchy
            skillsHierarchyDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            skillsHierarchyDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            skillsHierarchyDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

            /**
             * To get the list of all LO's for Default Reading courses -
             * Standards
             */
            Constants.READING_BANK_ID_LIST.forEach( element -> {
                HashMap<String, String> responseForDifferentGrades = new HashMap<>();
                Set<String> loMainListOfReadingAllGrade = new HashSet<>();

                try {
                    skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, "2" );
                    skillsHierarchyDetails.put( CourseAPIConstants.BANK_ID, element );
                    skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, Constants.NEGATIVE_ONE );
                    skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, Constants.FALSE );
                    responseForDifferentGrades = coursesAPI.getStandardHierarchy( smUrl, skillsHierarchyDetails );
                } catch ( Exception e ) {
                    Log.message( "Error occured while fetching Reading LO's" );
                }

                String reponseDataOfReadingForAllGrade = SMUtils.getKeyValueFromResponse( responseForDifferentGrades.get( Constants.REPORT_BODY ), Constants.DATA );
                //                Log.message( "reponseDataOfReadingForAllGrade: " + reponseDataOfReadingForAllGrade );

                JSONObject jsonObjectOfReadingAllGrade = new JSONObject( reponseDataOfReadingForAllGrade );
                //                Log.message( "reponseDataOfReadingForAllGrade: " + jsonObjectOfReadingAllGrade );
                if ( !jsonObjectOfReadingAllGrade.isEmpty() ) {
                    JSONObject gettaxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade = jsonObjectOfReadingAllGrade.getJSONObject( "taxonomyOrStandardIdToHierarchyNodes" );
                    String taxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade = gettaxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade.toString();
                    JSONObject jsonObjAllOfReadingForAllGrade = new JSONObject( taxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade );
                    loMainListOfReadingAllGrade = customCourses.getLoNamesList( jsonObjAllOfReadingForAllGrade );
                    loMainListForReading.addAll( loMainListOfReadingAllGrade );
                }

            } );

            /**
             * To get the list of all LO's for Default Math courses - Standards
             */
            Constants.MATH_BANK_ID_LIST.forEach( element -> {
                HashMap<String, String> responseForDifferentGrades = new HashMap<>();
                Set<String> loMainListOfMathAllGrade = new HashSet<>();

                try {
                    skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, "1" );
                    skillsHierarchyDetails.put( CourseAPIConstants.BANK_ID, element );
                    skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, Constants.NEGATIVE_ONE );
                    skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, Constants.FALSE );
                    responseForDifferentGrades = coursesAPI.getStandardHierarchy( smUrl, skillsHierarchyDetails );
                } catch ( Exception e ) {
                    Log.message( "Error occured while fetching Reading LO's" );
                }

                String reponseDataOfMathForAllGrade = SMUtils.getKeyValueFromResponse( responseForDifferentGrades.get( Constants.REPORT_BODY ), Constants.DATA );
                JSONObject jsonObjectOfMathAllGrade = new JSONObject( reponseDataOfMathForAllGrade );

                JSONObject gettaxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade = jsonObjectOfMathAllGrade.getJSONObject( "taxonomyOrStandardIdToHierarchyNodes" );
                String taxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade = gettaxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade.toString();
                JSONObject jsonObjAllOfMathForAllGrade = new JSONObject( taxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade );
                loMainListOfMathAllGrade = customCourses.getLoNamesList( jsonObjAllOfMathForAllGrade );
                loMainListForMath.addAll( loMainListOfMathAllGrade );
            } );

            /**
             * To get the list of all LO's for Default Reading courses - Skills
             */
            Constants.READING_CTYPE_ID.forEach( element -> {
                HashMap<String, String> responseForDifferentGrades = new HashMap<>();
                Set<String> loMainListOfReadingAllGrade = new HashSet<>();

                try {
                    skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, "2" );
                    skillsHierarchyDetails.put( CourseAPIConstants.CTTYPE_ID, element );
                    skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, Constants.NEGATIVE_ONE );
                    skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, Constants.FALSE );
                    responseForDifferentGrades = coursesAPI.getSkillsHierarchy( smUrl, skillsHierarchyDetails );
                } catch ( Exception e ) {
                    Log.message( "Error occured while fetching Reading LO's" );
                }

                String reponseDataOfReadingForAllGrade = SMUtils.getKeyValueFromResponse( responseForDifferentGrades.get( Constants.REPORT_BODY ), Constants.DATA );
                JSONObject jsonObjectOfReadingAllGrade = new JSONObject( reponseDataOfReadingForAllGrade );
                JSONObject gettaxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade = jsonObjectOfReadingAllGrade.getJSONObject( "taxonomyOrStandardIdToHierarchyNodes" );
                String taxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade = gettaxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade.toString();
                JSONObject jsonObjAllOfReadingForAllGrade = new JSONObject( taxonomyOrStandardIdToHierarchyNodesOfReadingForAllGrade );
                loMainListOfReadingAllGrade = customCourses.getLoNamesList( jsonObjAllOfReadingForAllGrade );
                loMainListForReading.addAll( loMainListOfReadingAllGrade );
            } );

            /**
             * To get the list of all LO's for Default Math courses - Skills
             */
            Constants.MATH_CTYPE_ID.forEach( element -> {
                HashMap<String, String> responseForDifferentGrades = new HashMap<>();
                Set<String> loMainListOfMathAllGrade = new HashSet<>();

                try {
                    skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, "1" );
                    skillsHierarchyDetails.put( CourseAPIConstants.CTTYPE_ID, element );
                    skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, Constants.NEGATIVE_ONE );
                    skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, Constants.FALSE );
                    responseForDifferentGrades = coursesAPI.getSkillsHierarchy( smUrl, skillsHierarchyDetails );
                } catch ( Exception e ) {
                    Log.message( "Error occured while fetching Reading LO's" );
                }

                String reponseDataOfMathForAllGrade = SMUtils.getKeyValueFromResponse( responseForDifferentGrades.get( Constants.REPORT_BODY ), Constants.DATA );
                JSONObject jsonObjectOfMathAllGrade = new JSONObject( reponseDataOfMathForAllGrade );
                JSONObject gettaxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade = jsonObjectOfMathAllGrade.getJSONObject( "taxonomyOrStandardIdToHierarchyNodes" );
                String taxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade = gettaxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade.toString();
                JSONObject jsonObjAllOfMathForAllGrade = new JSONObject( taxonomyOrStandardIdToHierarchyNodesOfMathForAllGrade );
                loMainListOfMathAllGrade = customCourses.getLoNamesList( jsonObjAllOfMathForAllGrade );
                loMainListForMath.addAll( loMainListOfMathAllGrade );
            } );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC019_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Georgia Standards of Excellence: English Language Arts, 2015", groups = { "SMK-43955", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_020() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo(
                "TC019_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Georgia Standards of Excellence: English Language Arts, 2015" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 18 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC020_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Common Core State Standards: English Language Arts, 2010", groups = { "SMK-43955", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_021() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo(
                "TC020_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Common Core State Standards: English Language Arts, 2010" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 19 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC021_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Alaska English/Language Arts Standards, 2012", groups = { "SMK-43955", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_022() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC021_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Alaska English/Language Arts Standards, 2012" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            SMUtils.logDescriptionTC( "SMK-18382 - TC009_Verify if Nodes and LO's are getting displayed correctly for SM Focus Reading -Alaska English/Language Arts, Standards,2012" );

            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 20 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            SMUtils.logDescriptionTC( "SMK-18389 - TC016_Verify if Nodes and LO's are getting displayed correctly for custom Course created from SM Focus Reading -Alaska English/Language Arts, Standards,2012" );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC022_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Tennessee Academic Standards: English Language Arts, 2016", groups = { "SMK-43955", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_23() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo(
                "TC022_Verify if Tier 2 nodes and LO's are getting displayed correctly for Reading - Tennessee Academic Standards: English Language Arts, 2016" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 21 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC003_Verify if Nodes and LO's are getting displayed correctly for Default Reading -Alabama Course of Study English Language Arts,2021", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_24() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-18376 - TC003_Verify if Nodes and LO's are getting displayed correctly for Default Reading -Alabama Course of Study English Language Arts,2021" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser
                + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 22 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC004_Verify if Nodes and LO's are getting displayed correctly for Default Reading - Texas myview Literacy 2020", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_25() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-18377 - TC004_Verify if Nodes and LO's are getting displayed correctly for Default Reading - Texas myview Literacy 2020" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 23 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC007_Verify if Nodes and LO's are getting displayed correctly for SM Focus Math - Virginia Mathematics Standards of Learning, 2016", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_26() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo(
                "SMK-18380 - TC007_Verify if Nodes and LO's are getting displayed correctly for SM Focus Math - Virginia Mathematics Standards of Learning, 2016" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 24 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForMath.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC008_Verify if Nodes and LO's are getting displayed correctly for SM Focus Math - Common Core State Standards: Mathematics, 2010", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_27() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo(
                "SMK-18381 - TC008_Verify if Nodes and LO's are getting displayed correctly for SM Focus Math - Common Core State Standards: Mathematics, 2010" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 25 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            SMUtils.logDescriptionTC( "SMK-18388 - TC015_Verify if Nodes and LO's are getting displayed correctly for custom Course created from SM Focus Math - Common Core State Standards: Mathematics, 2010" );

            //Assertion
            Log.softAssertThat( loMainListForMath.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC011_Verify if Nodes and LO's are getting displayed correctly for custom Course created from Default Math - enVision Florida Mathematics", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_28() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18384 - TC011_Verify if Nodes and LO's are getting displayed correctly for custom Course created from Default Math - enVision Florida Mathematics" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser
                + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 26 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            //Assertion
            Log.softAssertThat( loMainListForMath.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC005_Verify if Nodes and LO's are getting displayed correctly for Default Math by Skills", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_29() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-18378 - TC005_Verify if Nodes and LO's are getting displayed correctly for Default Math by Skills" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 27 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            SMUtils.logDescriptionTC( "SMK-18385 - TC012_Verify if Nodes and LO's are getting displayed correctly for custom Course created from Default Math by skills" );

            //Assertion
            Log.softAssertThat( loMainListForMath.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC006_Verify if Nodes and LO's are getting displayed correctly for Default Reading by Skills", groups = { "SMK-54699", "Courses", "Courses - Tier2_Nodes" }, priority = 2 )
    public void verifyCoursesNodes_30() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-18379 - TC006_Verify if Nodes and LO's are getting displayed correctly for Default Reading by Skills" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> sideNavList = new ArrayList<>();
            Set<String> allLosGradeK = new HashSet<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the Math course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the standards dropdown
            customCourses.clickStandardDropdownBtn();

            //Click on Alaska Mathematics Standards
            customCourses.clickStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 28 ), Constants.STANDARDS );

            //Click on the grade dropdown
            customCourses.clickGradeDropdownBtn();

            //Click on the Grade K
            customCourses.clickStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );

            //To get the list of side nav
            sideNavList = customCourses.getSideNavOfCourse();

            sideNavList.forEach( element -> {
                customCourses.clickOnTheSideNav( element );
                customCourses.clickAllTheTopicForEachStandard();
                customCourses.clickAllTheSubTopicsForEachStandard();
                customCourses.clickAllTheSubTopicsOfTopics();
                allLosGradeK.addAll( customCourses.getAllTheLosOfThetopic() );
            } );

            SMUtils.logDescriptionTC( "SMK-18387 - TC014_Verify if Nodes and LO's are getting displayed correctly for custom Course created from Default Reading by skills" );

            //Assertion
            Log.softAssertThat( loMainListForReading.containsAll( allLosGradeK ), "All LO's for Grade K are present", "All LO's Grade K are absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}