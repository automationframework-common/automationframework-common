package com.savvas.sm.api.tests.smnew.report.model;

public class ReportResponse {
    String personId;
    String assignmentId;
    Float currentLevel;
    Float timeSinceIp;
    String totalMasteredSkills;
    String sessionLength;
    String averageMinPerDay;
    String currentLearningRate;
    String additionalTimeToReachTarget;
    String additionalMinutesPerDayToReachTarget;
    Float currentCourseLevel;
    String totalCorrect;
    String totalAttempts;
    Float sessionHelpCount;
    Float totalSessions;
    String strandName;
    Float strandLevel;
    String loDescription;


    public String getPersonId() {
        return personId;
    }

    public void setPersonId( String personId ) {
        this.personId = personId;
    }

    public String getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId( String assignmentId ) {
        this.assignmentId = assignmentId;
    }

    public Float getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel( Float currentLevel ) {
        this.currentLevel = currentLevel;
    }

    public Float getTimeSinceIp() {
        return timeSinceIp;
    }

    public void setTimeSinceIp( Float timeSinceIp ) {
        this.timeSinceIp = timeSinceIp;
    }

    public String getTotalMasteredSkills() {
        return totalMasteredSkills;
    }

    public void setTotalMasteredSkills( String totalMasteredSkills ) {
        this.totalMasteredSkills = totalMasteredSkills;
    }

    public String getSessionLength() {
        return sessionLength;
    }

    public void setSessionLength( String sessionLength ) {
        this.sessionLength = sessionLength;
    }

    public String getAverageMinPerDay() {
        return averageMinPerDay;
    }

    public void setAverageMinPerDay( String averageMinPerDay ) {
        this.averageMinPerDay = averageMinPerDay;
    }

    public String getCurrentLearningRate() {
        return currentLearningRate;
    }

    public void setCurrentLearningRate( String currentLearningRate ) {
        this.currentLearningRate = currentLearningRate;
    }

    public String getAdditionalTimeToReachTarget() {
        return additionalTimeToReachTarget;
    }

    public void setAdditionalTimeToReachTarget( String additionalTimeToReachTarget ) {
        this.additionalTimeToReachTarget = additionalTimeToReachTarget;
    }

    public String getAdditionalMinutesPerDayToReachTarget() {
        return additionalMinutesPerDayToReachTarget;
    }

    public void setAdditionalMinutesPerDayToReachTarget( String additionalMinutesPerDayToReachTarget ) {
        this.additionalMinutesPerDayToReachTarget = additionalMinutesPerDayToReachTarget;
    }

    public Float getCurrentCourseLevel() {
        return currentCourseLevel;
    }

    public void setCurrentCourseLevel( Float currentCourseLevel ) {
        this.currentCourseLevel = currentCourseLevel;
    }

    public String getTotalCorrect() {
        return totalCorrect;
    }

    public void setTotalCorrect( String totalCorrect ) {
        this.totalCorrect = totalCorrect;
    }

    public String getTotalAttempts() {
        return totalAttempts;
    }

    public void setTotalAttempts( String totalAttempts ) {
        this.totalAttempts = totalAttempts;
    }

    public Float getSessionHelpCount() {
        return sessionHelpCount;
    }

    public void setSessionHelpCount( Float sessionHelpCount ) {
        this.sessionHelpCount = sessionHelpCount;
    }

    public Float getTotalSessions() {
        return totalSessions;
    }

    public void setTotalSessions( Float totalSessions ) {
        this.totalSessions = totalSessions;
    }

    public String getStrandName() {
        return strandName;
    }

    public void setStrandName( String strandName ) {
        this.strandName = strandName;
    }

    public Float getStrandLevel() {
        return strandLevel;
    }

    public void setStrandLevel( Float strandLevel ) {
        this.strandLevel = strandLevel;
    }

    public String getLoDescription() {
        return loDescription;
    }

    public void setLoDescription( String loDescription ) {
        this.loDescription = loDescription;
    }
}
