package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditCourseSettingPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This java class file contains test cases for JIRA story
 * <p>
 * SMK-54697 :Integration Testing for courses list courseware.
 * <p>
 * SMK-54703 : Integration Testing for create courses copy by custom
 * standards/skill/settings
 */

public class CourseListingTest {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;
    private static String username = null;
    private static String password = null;
    private String schoolID;
    private String teacherID;
    String teacherDetails;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    private String smUrl;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;

    @BeforeTest
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        UserAPI userAPIMethod = new UserAPI();

        //Flex School
        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        //username = "flex_teacher_3000";
        schoolID = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        //New approach
        studentDetails = RBSDataSetup.getMyStudent( flexSchool, username );
        studentDetailsSecond = RBSDataSetup.getMyStudent( flexSchool, username );
        studentDetailsThree = RBSDataSetup.getMyStudent( flexSchool, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Student SM Details
        studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( flexSchool ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsSecond = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( flexSchool ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsThree = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( flexSchool ), token ).get( Constants.REPORT_BODY );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "SMK-18497 - Verify we are able to create copy of course based on Settings for Default Math", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18497 - Verify we are able to create copy of course based on Settings for Default Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18312 - TC001_Verify if teacher is able to create courses copy by custom Settings from Default Math" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SETTINGS, Constants.MATH );

            SMUtils.logDescriptionTC( "SMK-22457 - TC014_Verify the teacher is able to create Custom By Settings course based on Default Math and the same is getting listed in the Courseware>Courses page" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );   
            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            //Verifying newly created course
            coursePage.verifyCoursecreated( newlyCreatedCourse );

           tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            
          //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18320 - TC009_Verify if teacher is able to create courses copy by Settings from Custom course created by Settings from Default Math" );

            SMUtils.logDescriptionTC( "SMK-18505 - Verify we are able to create copy of course based on Settings for Custom Math" );

            SMUtils.logDescriptionTC( "SMK-18328 - TC017_Verify if teacher is able to see the create courses copy by custom Settings from Default Math in \"My Custom Courses\"" );
            //Verifying newly created course
            coursePage.verifyCoursecreated( newCourseName );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            
            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18336 - TC025_Verify if teacher is able to see the create courses copy by Settings from Custom course created by Settings from Default Math in \"My Custom Courses\"" );
            //Verifying newly created course
            coursePage.verifyCoursecreated( newCourseNameCreatedOutOfCustomCourse );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );  	  
            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickEditBtnCourseLevel();
            String newCourseNameForEditVerification = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameForEditVerification );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickSaveBtnForEdit();
            SMUtils.logDescriptionTC( "SMK-18513 - Verify we are able to edit name of the Custom Defalut Math course" );

            SMUtils.waitForSpinnertoDisapper( driver );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newCourseNameForEditVerification );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18519 - Verify we are able to delete Custom Default Math based on Settings Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
          //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18527 - Verify we are able to delete Course which is created by CustomDefault Math Settings" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18498 - Verify we are able to create copy of course based on Skills for Default Math", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18498 - Verify we are able to create copy of course based on Skills for Default Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            SMUtils.logDescriptionTC( "SMK-18313 - TC002_Verify if teacher is able to create courses copy by custom Skill from Default Math" );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SKILLS, Constants.MATH );

            SMUtils.logDescriptionTC( "SMK-22458 - TC015_Verify the teacher is able to create Custom By Skills course based on Default Math and the same is getting listed in the Courseware>Courses page" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18506 - Verify we are able to create copy of course based on Skills for Custom Math" );
            SMUtils.logDescriptionTC( "SMK-18321 - TC010_Verify if teacher is able to create courses copy by Skills from Custom course created by Skills from Default Math" );
            SMUtils.logDescriptionTC( "SMK-18329 - TC018_Verify if teacher is able to see the create courses copy by custom Skill from Default Math  in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18337 - TC026_Verify if teacher is able to see the create courses copy by Skills from Custom course created by Skills from Default Math in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18520 - Verify we are able to delete Custom Default Math based on Skills Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18528 - Verify we are able to delete Course which is created by CustomDefault Math Skills" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18499 - Verify we are able to create copy of course based on Standards for Default Math", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing003() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18499 - Verify we are able to create copy of course based on Standards for Default Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18314 - TC003_Verify if teacher is able to create courses copy by custom Standards from Default Math" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18507 - Verify we are able to create copy of course based on Standards for Custom Math" );
            SMUtils.logDescriptionTC( "SMK-18322 - TC011_Verify if teacher is able to create courses copy by Standards from Custom course created by Standards from Default Math" );
            SMUtils.logDescriptionTC( "SMK-18330 - TC019_Verify if teacher is able to see the create courses copy by custom Standards from Default Math in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18338 - TC027_Verify if teacher is able to see the create courses copy by Standards from Custom course created by Standards from Default Math in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18521 - Verify we are able to delete Custom Default Math based on Standards Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18529 - Verify we are able to delete Course which is created by CustomDefault Math Standards" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18500 - Verify we are able to create copy of course based on Settings for Default Reading", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18500 - Verify we are able to create copy of course based on Settings for Default Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18315 - TC004_Verify if teacher is able to create courses copy by custom Settings from Default Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SETTINGS, Constants.READING );

            SMUtils.logDescriptionTC( "SMK-22460 - TC017_Verify the teacher is able to create Custom By Settings course based on Default Reading and the same is getting listed in the Courseware>Courses page" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18508 - Verify we are able to create copy of course based on Settings for Custom Reading" );
            SMUtils.logDescriptionTC( "SMK-18323 - TC012_Verify if teacher is able to create courses copy by Settings from Custom course created by Settings from Default Reading" );
            SMUtils.logDescriptionTC( "SMK-18331 - TC0020_Verify if teacher is able to see the create courses copy by custom Settings from Default Reading in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18339 - TC028_Verify if teacher is able to see the create courses copy by Settings from Custom course created by Settings from Default Reading in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickEditBtnCourseLevel();
            String newCourseNameForEditVerification = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameForEditVerification );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            //coursePage.clickSaveBtn();
            //Wait for spinner to go away
            coursePage.clickSaveBtnForEdit();
            SMUtils.logDescriptionTC( "SMK-18514 - Verify we are able to edit name of the Custom Defalut Reading course" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseNameForEditVerification );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18522 - Verify we are able to delete Custom Default Reading based on Settings Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18530 - Verify we are able to delete Course which is created by CustomDefault Reading Settings" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18501 - Verify we are able to create copy of course based on Skills for Default Reading", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-184501 - Verify we are able to create copy of course based on Skills for Default Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18316 - TC005_Verify if teacher is able to create courses copy by custom Skill from Default Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SKILLS, Constants.READING );

            SMUtils.logDescriptionTC( "SMK-22461 - TC018_Verify the teacher is able to create Custom By Skills course based on Default Reading and the same is getting listed in the Courseware>Courses page" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18509 - Verify we are able to create copy of course based on Skills for Custom Reading" );
            SMUtils.logDescriptionTC( "SMK-18324 - TC013_Verify if teacher is able to create courses copy by Skills from Custom course created by Skills from Default Reading" );
            SMUtils.logDescriptionTC( "SMK-18332 - TC021_Verify if teacher is able to see the create courses copy by custom Skill from Default Reading in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18340 - TC029_Verify if teacher is able to see the create courses copy by Skills from Custom course created by Skills from Default Reading in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18523 - Verify we are able to delete Custom Default Reading based on Skills Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18531 - Verify we are able to delete Course which is created by CustomDefault Reading Skills" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18502 - Verify we are able to create copy of course based on Standards for Default Reading", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing006() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-184502 - Verify we are able to create copy of course based on Standards for Default Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18317 - TC006_Verify if teacher is able to create courses copy by custom Standards from Default Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18510 - Verify we are able to create copy of course based on Standards for Custom Reading" );
            SMUtils.logDescriptionTC( "SMK-18325 - TC014_Verify if teacher is able to create courses copy by Standards from Custom course created by Standards from Default Reading" );
            SMUtils.logDescriptionTC( "SMK-18333 - TC022_Verify if teacher is able to see the create courses copy by custom Standards from Default Reading  in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18341 - TC030_Verify if teacher is able to see the create courses copy by Standards from Custom course created by Standards from Default Reading in \"My Custom Courses\"" );

            SMUtils.logDescriptionTC( "SMK-22462 -TC019_Verify the teacher is able to create Custom By Standards course based on Default Reading and the same is getting listed in the Courseware>Courses page" );
            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18524 - Verify we are able to delete Custom Default Reading based on Standards Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18532 - Verify we are able to delete Course which is created by CustomDefault Reading Standards" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18503 - Verify we are able to create copy of course based on Standards for Focus Math", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing007() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-184503 - Verify we are able to create copy of course based on Standards for Focus Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18318 - TC007_Verify if teacher is able to create courses copy by custom Standards from SM Focus Math" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1 );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18511 - Verify we are able to create copy of course based on Standards for Custom Focus Math" );
            SMUtils.logDescriptionTC( "SMK-18326 - TC015_Verify if teacher is able to create courses copy by Standards from Custom course created by Standards from SM Focus Math" );
            SMUtils.logDescriptionTC( "SMK-18334 - TC023_Verify if teacher is able to see the create courses copy by custom Standards from SM Focus Math in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18342 - TC031_Verify if teacher is able to see the create courses copy by Standards from Custom course created by Standards from SM Focus Math in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18525 - Verify we are able to delete Custom Focus Math based on Standards Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18533 - Verify we are able to delete Course which is created by Custom Focus Math Standards" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18504 - Verify we are able to create copy of course based on Standards for Focus Reading", priority = 1, groups = { "SMK-54697", "Courses", "courseListing" } )
    public void tcSMCoursesListing008() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18504 - Verify we are able to create copy of course based on Standards for Focus Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18319 - TC008_Verify if teacher is able to create courses copy by custom Standards from SM Focus Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18512 - Verify we are able to create copy of course based on Standards for Custom Focus Reading" );
            SMUtils.logDescriptionTC( "SMK-18327 - TC016_Verify if teacher is able to create courses copy by Standards from Custom course created by Standards from SM Focus Reading" );
            SMUtils.logDescriptionTC( "SMK-18335 - TC024_Verify if teacher is able to see the create courses copy by custom Standards from SM Focus Reading in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            /** Start here **/
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseNameCreatedOutOfCustomCourse = coursePage.generateRandomCourseName();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.enterCourseName( newCourseNameCreatedOutOfCustomCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18343 - TC032_Verify if teacher is able to see create courses copy by Standards from Custom course created by Standards from SM Focus Reading in \"My Custom Courses\"" );

            Log.assertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseNameCreatedOutOfCustomCourse ), "Course is created successfully", "Course is not created" );
            /** Ends here **/

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18526 - Verify we are able to delete Custom Focus Reading based on Standards Course" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            coursePage.clickFromCourseListingPage( newCourseName );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.removeCourse();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-18534 - Verify we are able to delete Course which is created by Custom Focus Reading Standards" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is deleted successfully", " Course is not deleted" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}