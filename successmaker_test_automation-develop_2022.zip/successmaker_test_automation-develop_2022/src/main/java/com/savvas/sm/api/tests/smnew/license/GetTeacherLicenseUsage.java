package com.savvas.sm.api.tests.smnew.license;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.OrganizationAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

/***
 * This class contains test scripts for teacher license details from lms
 * 
 * @author madhan.nagarathinam
 *
 */
public class GetTeacherLicenseUsage extends BaseAPITest {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private Response response;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String teacherDetails = null;
    private String studentDetails = null;
    private String token = null;
    private String math_School = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String math_TeacherDetails = null;
    private String reading_School = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String reading_TeacherDetails = null;
    private String flex_School = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String flex_TeacherDetails = null;

    String orgId;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        math_TeacherDetails = RBSDataSetup.getMyTeacher( math_School );
        reading_TeacherDetails = RBSDataSetup.getMyTeacher( reading_School );
        flex_TeacherDetails = RBSDataSetup.getMyTeacher( flex_School );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ) );
        orgId = configProperty.getProperty( "district_ID" );
    }

    /**
     * Method for testing license details API-Positive cases.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51572", "smoke_test_case", "P1", "Update teacher flow to check license", "API" }, priority = 1 )
    public void getTeacherLicenseUsage001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_TEACHER_LICENSE_USAGE;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "VALID_TEACHER":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                Log.message( headers + "" );
                break;

        }
        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.message( response.getBody().asString() );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getTeacher_License_Usage", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51572", "Update teacher flow to check license", "API" }, priority = 2 )
    public void getTeacherLicenseUsage002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_TEACHER_LICENSE_USAGE;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "INVALID_ORGID":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, LicenseAPIConstants.invalid_Org_Id );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                Log.message( headers + "" );
                break;

            case "INVALID_USERID":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LicenseAPIConstants.USERID, LicenseAPIConstants.invalid_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                Log.message( headers + "" );
                break;

            case "INVALID_ORGID_INVALID_USERID":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, LicenseAPIConstants.invalid_Org_Id );
                headers.put( LicenseAPIConstants.USERID, LicenseAPIConstants.invalid_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                Log.message( headers + "" );
                break;

            case "INVALID_AUTHORIZATION":
                token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                Log.message( headers + "" );
                break;

            case "STUDENT":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                Log.message( headers + "" );
                break;

            case "CUSTOMER_ADMIN":
                //Customer Admin details
                String username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
                String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
                String userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "SAVVAS_ADMIN":
                headers.put( LicenseAPIConstants.ORGID, LicenseAPIConstants.valid_SavvasAdmin_OrgId );
                headers.put( LicenseAPIConstants.USERID, LicenseAPIConstants.valid_SavvasAdmin_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( LicenseAPIConstants.savvasAdmin_UserName, LicenseAPIConstants.savvasAdmin_Password ) );
                Log.message( headers + "" );
                break;
        }

        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC001: ", "200", "Verify 200 status code and response body when valid teacher user-id with valid headers are given", "VALID_TEACHER" },

        };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC: 003 ", "403", "Verify 403 status code and response body when invalid org id and valid user id is given", "INVALID_ORGID" },
                { "TC: 004 ", "401", "Verify 401 status code and respone body when invalid user id is given", "INVALID_USERID" },
                { "TC: 005 ", "401", "Verify 401 status code and respone body when invalid org-id and invalid user id is given", "VALID_ORGID_INVALID_USERID" },
                { "TC: 006 ", "401", "Verify 401 status code and response body when valid header details and invalid authorization is given", "INVALID_AUTHORIZATION" },
                { "TC: 007 ", "403", "Verify 403 status code and response body when valid studentId is provided in the headers", "STUDENT" },
                { "TC: 008 ", "403", "Verify 403 status code and response body when valid customer Admin UserId is provided in the headers", "CUSTOMER_ADMIN" },
                { "TC: 009 ", "403", "Verify 403 status code and response body when valid Savvas Admin UserId is provided in the headers", "SAVVAS_ADMIN" }

        };
        return data;
    }

    /**
     * Method for testing license details and zero state API-Positive cases.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( dataProvider = "getDataForPostivieBussinessFlowCases", groups = { "SMK-52283", "smoke_test_case", "P1", " Update teacher flow to show zero state on dashboard when no courses are licensed", "API" }, priority = 1 )
    public void getTeacherLicenseUsage003( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_TEACHER_LICENSE_USAGE;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "TEACHER_WITH_FLEX":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flex_TeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( flex_School ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( flex_TeacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                break;

            case "TEACHER_WITH_MATH":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( math_TeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( math_School ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( math_TeacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                break;

            case "TEACHER_WITH_READING":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( reading_TeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( reading_School ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( reading_TeacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                break;

        }

        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.message( response.getBody().asString() );
        String data = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
        String subjectId = SMUtils.getKeyValueFromResponse( data, "subjectIds" );
        String messages = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "messages" );
        String message = getMessage( messages, "message" );

        if ( scenarioType.equalsIgnoreCase( "TEACHER_WITH_FLEX" ) ) {
            Log.assertThat( subjectId.equals( LicenseAPIConstants.FLEX_SUBJECT_ID ), "The subjectIds are matching for flex license", "The subjectIds are not matching for flex license!" );
        } else if ( scenarioType.equalsIgnoreCase( "TEACHER_WITH_MATH" ) ) {
            Log.assertThat( subjectId.equals( LicenseAPIConstants.MATH_SUBJECT_ID ), "The subjectIds are matching for math license", "The subjectIds are not matching for math license!" );
        } else if ( scenarioType.equalsIgnoreCase( "TEACHER_WITH_READING" ) ) {
            Log.assertThat( subjectId.equals( LicenseAPIConstants.READING_SUBJECT_ID ), "The subjectIds are matching for reading license", "The subjectIds are not matching for reading license!" );
        } else {
            Log.assertThat( message.equals( LicenseAPIConstants.ZERO_LICENSE_STATE_MESSAGE ), "'No Data Found' is message is getting displayed in the response when the org has no or expired or future license ",
                    "'No Data Found' is message is not getting displayed in the response when the org has no or expired or future license !" );
        }

    }

    @DataProvider
    public Object[][] getDataForPostivieBussinessFlowCases() {
        Object[][] data = { { "TC:010", "200", "Verify 200 status code and response when valid header, authorization are provided", "TEACHER_WITH_FLEX" },
                { "TC:011", "200", "Verify 200 status code and response when valid header, authorization are provided", "TEACHER_WITH_MATH" },
                { "TC:012", "200", "Verify 200 status code and response when valid header, authorization are provided", "TEACHER_WITH_READING" },

        };
        return data;
    }

    public String getMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }
}
