package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class MasteryPage extends LoadableComponent<MasteryPage> {

	private WebDriver driver;
	boolean isPageLoaded;
	public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();

	MasteryFiltersComponent masteryFilterComponent;

	// ********* SuccessMaker Mastery Page Elements ***************
	@IFindBy(how = How.CSS, using = "div.mastery-container div.zero-state-content h3", AI = false)
	public WebElement zeroStateHeader;

	@IFindBy(how = How.CSS, using = "div.mastery-container div.projected p", AI = false)
	public WebElement zeroStateMsg;

	@IFindBy(how = How.CSS, using = "div.mastery-container div.zero-state-icon img[alt='zero state']", AI = false)
	public WebElement zeroStateIcon;

	@IFindBy(how = How.CSS, using = "mastery .header-title", AI = false)
	public WebElement lblMasteryHeading;

	@IFindBy(how = How.CSS, using = "h2.filter-header", AI = false)
	public WebElement lblStep1Heading;

	@IFindBy(how = How.CSS, using = "mastery-step-two-filters h2", AI = false)
	public WebElement lblStep2Heading;

	@IFindBy(how = How.CSS, using = ".contextual-help-icon.hydrated", AI = false)
	public WebElement cellIcon;

	@IFindBy(how = How.CSS, using = "#mc-main-content>h1", AI = false)
	public WebElement masteryFromHelpPage;

	@IFindBy(how = How.CSS, using = "div.mastery-footer-button div.run-reports-button cel-button", AI = false)
	public WebElement masteryRunReportBtnRoot;

	public MasteryPage() {
	}

	/**
	 *
	 * Constructor class for Mastery page and initializing the driver for page
	 * factory objects.
	 *
	 * @param driver
	 *
	 */
	public MasteryPage(WebDriver driver) {
		this.driver = driver;
		// Have Topbar here and init
		ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
		PageFactory.initElements(finder, this);
		elementLayer = new ElementLayer(driver);
		masteryFilterComponent = new MasteryFiltersComponent(driver);
	}

	// Root Child Elements
	private static String runReportPrimaryBtn = "button.primary_button";

	/**
	 * Verify the run report button is enabled or disabled
	 *
	 * @return boolean
	 */
	public boolean isRunBtnEnabled() {
		Log.message("Verifying Run Report button is Enabled");
		SMUtils.waitForElement(driver, masteryRunReportBtnRoot, 5);
		WebElement runReportStatusDbd = SMUtils.getWebElementDirect(driver, masteryRunReportBtnRoot,
				runReportPrimaryBtn);
		return runReportStatusDbd.isEnabled();
	}

	/***
	 * return the masteryFilterComponent Object
	 *
	 * @return
	 */
	public MasteryFiltersComponent getMasteryFilterComponent() {
		Log.message(" Get mastery filter component");
		return masteryFilterComponent;
	}

	@Override
	protected void isLoaded() {
		if (!isPageLoaded) {
			Assert.fail();
		}

		if (SMUtils.waitForElement(driver, lblMasteryHeading)) {
			Log.message("SM Mastery page loaded successfully.", driver);
		} else {
			Log.fail("SM Mastery page did not load.");
		}
	}

	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForElement(driver, lblMasteryHeading);
	}

	/***
	 * returns the Heading
	 *
	 * @return
	 */
	public String getMasteryHeading() {
		return lblMasteryHeading.getText();
	}

	/**
	 * returns the students and groups filter heading
	 *
	 * @return
	 */
	public String getMasteryStep1Heading() {
		return lblStep1Heading.getText();
	}

	/**
	 * returns the refine search heading
	 *
	 * @return
	 */
	public String getMasteryStep2Heading() {
		return lblStep2Heading.getText();
	}

	/**
	 * returns the Cell Icon element
	 *
	 * @return webelement
	 */

	public WebElement getCellIcon() {
		return cellIcon;
	}

	/**
	 * returns the Mastery Help Page
	 *
	 * @return webelement
	 */

	public WebElement getMasteryFromHelpPage() {
		return masteryFromHelpPage;
	}
}
