package com.savvas.sm.api.tests.smnew.report;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

/**
 * This class is used to test the CP Report API Test
 * 
 * @author kathiravan.m
 *
 */

public class PutAPIEditReport extends EnvProperties {
    private String smUrl;
    private Map<String, String> response;
    private Map<String, String> postResponse;
    private String school;
    private String teacherDetails;
    private String userID;
    private String teacherUsername;
    private String password;
    String districtID;
    private String orgID;
    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        userID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtID = configProperty.getProperty( "district_ID" );
        // Getting ORGID of Flex school
        orgID = RBSDataSetup.organizationIDs.get( school );
    }

    @Test (dataProvider = "getDataForEditScenarios", groups = {"smoke_test_case","Smoke putEditReportTest001","Report","P1", "SMK-58049", "Java API for edit report", "API" }, priority = 1 )
    public void putEditReportTest001( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );
        //Test Data
        String authorization = "Basic YWRtaW50ZXN0OnRlc3Q=";
        String request = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putEditOrPostSaveReport_SMK58049.json" );
        request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.MATH_ID );
        request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
        request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
        request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
        Log.message( "request of POST Call - " + request );

        //Saving a report by POST API call
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( ReportAPIConstants.AUTHORISATION, authorization );
        headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
        headers.put( ReportAPIConstants.USERID_HEADER, userID );
        headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
        String postEndPoint = ReportAPIConstants.POST_SAVE_REPORT;
        postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
        Log.message( "response from POST Call - " + postResponse );

        //To get request ID from post call rsponse
        String requestID = SMUtils.getKeyValueFromResponse( postResponse.get( Constants.REPORT_BODY ), "requestId" );
        Log.message( "Request ID from POST Call - " + requestID );

        //PUT End Point
        String putEndPoint = ReportAPIConstants.PUT_EDIT_REPORT;
        String putRequest = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putEditOrPostSaveReport_SMK58049.json" );
        Log.message( "response from PUT Call - " + putRequest );

        switch ( scenarioType ) {
            case "VALID_TEST_PAYLOAD":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest );
                Log.message( response.get( Constants.RESPONSE_BODY ).toString() );
                Log.message( "Request ID from POST Call - " + response );
               
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "Edit_report", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;

            case "WITHOUT_TOKEN":
                headers.put( ReportAPIConstants.AUTHORISATION, "" );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest );
                Log.message( "Request ID from POST Call - " + response );
                break;

            case "EMPTY USER-ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, "" );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest );
                Log.message( "Request ID from POST Call - " + response );
                break;

            case "DIFFERENT_ORG-ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                String invalidOrgID = orgID + getRandomNumber();
                headers.put( ReportAPIConstants.ORGID_HEADER, invalidOrgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest );
                Log.message( "Request ID from POST Call - " + response );
                break;

            case "DIFFERENT_USER-ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                String invalidUserID = userID + getRandomNumber();
                headers.put( ReportAPIConstants.USERID_HEADER, invalidUserID);
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest );
                Log.message( "Request ID from POST Call - " + response );
                break;

            case "EMPTY ORG-ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, "" );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
                putRequest = putRequest.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest );
                Log.message( "Request ID from POST Call - " + response );
                break;

           
            case "INVALID_REPORT_TYPE":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                String putRequest4 = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putAPIEditInvalidScenarios_SMK58049.json" );
                putRequest4 = putRequest4.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest4 );
                Log.message( "Request ID from POST Call - " + response );
                break;

          

            case "INVALID_USER_TYPE":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                String putRequest5 = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putAPIEditInvalidScenarios_SMK58049.json" );
                putRequest5 = putRequest5.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest5 );
                Log.message( "Request ID from POST Call - " + response );
                break;

            case "EMPTY_REQUEST_BODY":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                String putRequest3 = null;
                Log.message( "response from PUT Call - " + putRequest3 );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest3 );
                Log.message( "Request ID from POST Call - " + response );
                break;

            case "EMPTY_REPORT_PARAMETER":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                String putRequest6 = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putAPIEditInvalidScenarios_SMK58049.json" );
                putRequest6 = putRequest6.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );

                putEndPoint = putEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint, putRequest6 );
                Log.message( "Request ID from POST Call - " + response );
                break;

        }
        Log.message( response.toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForEditScenarios() {
        Object[][] data = { { "TC001", "200", "Verify status code is 200 when valid test data is given.", "VALID_TEST_PAYLOAD" }, { "TC002", "401", "Verify 401 status code and response body when invalid Authoriztion token", "WITHOUT_TOKEN" },
                { "TC003", "400", "Verify 400 status code and response body when user-id is empty", "EMPTY USER-ID" },
                { "TC004", "404", "Verify 404 status code and response body when org-id is invalid/given different from which the report has been saved.", "DIFFERENT_ORG-ID" },
                { "TC005", "404", "Verify 404 status code and response body when user-id is invalid/given different from which the report has been saved.", "DIFFERENT_USER-ID" },
                { "TC006", "400", "Verify 400 status code and response body when org is empty", "EMPTY ORG-ID" },
                { "TC08", "400", "Verify 400 status code in the response when the reportType in the request payload is provided with empty value", "INVALID_REPORT_TYPE" },
                { "TC010", "400", "Verify 400 status code in the response when the userType in the request payload is provided with empty value", "INVALID_USER_TYPE" },
                { "TC011", "400", "Verify 400 status code in the response when empty request body is provided", "EMPTY_REQUEST_BODY" },
                { "TC014", "400", "Verify 400 status code in the response when empty reportParameters field is provided", "EMPTY_REPORT_PARAMETER" }, };
        return data;
    }
    @Test ( dataProvider = "getDataEditScenarios", groups = {"SMK-58049", "Java API for edit report", "API" }, priority = 1 )
    public void putEditReportTest002( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );
        //Test Data
        String authorization = "Basic YWRtaW50ZXN0OnRlc3Q=";
        String request = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putEditOrPostSaveReport_SMK58049.json" );
        request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.MATH_ID );
        request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
        request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
        request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
        Log.message( "request of POST Call - " + request );

        //Saving a report by POST API call
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( ReportAPIConstants.AUTHORISATION, authorization );
        headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
        headers.put( ReportAPIConstants.USERID_HEADER, userID );
        headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
        String postEndPoint = ReportAPIConstants.POST_SAVE_REPORT;
        postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
        Log.message( "response from POST Call - " + postResponse );

        //To get request ID from post call rsponse
        String requestID = SMUtils.getKeyValueFromResponse( postResponse.get( Constants.REPORT_BODY ), "requestId" );
        Log.message( "Request ID from POST Call - " + requestID );

        //PUT End Point
        String putEndPoint = ReportAPIConstants.PUT_EDIT_REPORT;
        String putRequest = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putEditOrPostSaveReport_SMK58049.json" );
        Log.message( "response from PUT Call - " + putRequest );
        
        switch ( scenarioType ) {
        case "INVALID_PERSON_REPORT":
            
            headers.put( ReportAPIConstants.AUTHORISATION, authorization );
            headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
            headers.put( ReportAPIConstants.USERID_HEADER, userID );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            String putEndPoint1 = ReportAPIConstants.PUT_EDIT_REPORT;
            String putRequest1 = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putAPIEditReport_SMK58049.json" );
            Log.message( "response from PUT Call - " + putRequest );

            putRequest1.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE,  ReportAPIConstants.REPORT_TYPE );
            putRequest1.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, ReportAPIConstants.INVALID );
            putRequest1.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME,  ReportAPIConstants.SUBJECT );
            putRequest1.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH);
            putRequest1.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

            putEndPoint1 = putEndPoint1.replace( ReportAPIConstants.REQUESTID, requestID );
            response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint1, putRequest1 );
            Log.message( "Request ID from POST Call - " + response );
            break;
            
        case "EMPTY_PERSON_REPORT":
            headers.put( ReportAPIConstants.AUTHORISATION, authorization );
            headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
            headers.put( ReportAPIConstants.USERID_HEADER, userID );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            String putEndPoint2 = ReportAPIConstants.PUT_EDIT_REPORT;
            String putRequest2 = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "putAPIEditReport_SMK58049.json" );
            Log.message( "response from PUT Call - " + putRequest );

            putRequest2.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.READING_ID );
            putRequest2.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, "" );
            putRequest2.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENTS );
            putRequest2.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.READING );
            putRequest2.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

            putEndPoint2 = putEndPoint2.replace( ReportAPIConstants.REQUESTID, requestID );
            response = RestHttpClientUtil.PUT( smUrl, headers, params, putEndPoint2, putRequest2 );
            Log.message( "Request ID from POST Call - " + response );
            break;

        
    }
        Log.message( response.toString() );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    public String getRandomNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt( 1000 );
        String generatedRandomNumber = Integer.toString( randomNumber );
        return generatedRandomNumber;
    }
    @DataProvider
    public Object[][] getDataEditScenarios() {
        Object[][] data = { 
                { "TC007", "400", "Verify 400 status code in the response when the personReport in the request payload is provided with invalid values", "INVALID_PERSON_REPORT" },
                { "TC009", "400", "Verify 400 status code in the response when the personReport in the request payload is provided with with empty value", "EMPTY_PERSON_REPORT" },
                };
                
        return data;
    }

}
