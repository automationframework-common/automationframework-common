package com.savvas.sm.api.tests.smnew.students;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class SaveAssignmetFilesAPI extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String assignmentID;
    private String assignmentUserId;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String CourseId;
    private String courseName;
    Response SaveAssignmentFilesResponse;
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    RequestSpecification httpRequest;
    Response response;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "tcPostiveforSaveAssignmentFilesAPI", groups = { "SMK-52003", "smoke_test_case", "P1", "API", "Student Dashboard" } )
    public void tcPostiveforSaveAssignmentFilesAPI( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );

        courseName = String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() );
        CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, courseName );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );

        selectCourse( studentUsername, courseName );
        SMUtils.nap( 20 );

        String SessionId = SqlHelperAssignment.getSessionId( assignmentUserId );
        Log.message( "SessionId : " + SessionId );

        String Accesstoken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.MULTIPART_FORMDATA_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + Accesstoken );
        header.put( Constants.USERID_SM_HEADER, studentUserID );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        header.put( Constants.SESSIONID_HEADER, SessionId );

        HashMap<String, String> pathparams = new HashMap<>();
        pathparams.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

        SaveAssignmentFilesResponse = SaveAssignmentFiles( header, pathparams );
        String statusCode1 = String.valueOf( SaveAssignmentFilesResponse.getStatusCode() );
        System.out.println( "Status-code : " + statusCode1 );

        Log.message( "SaveAssignmentFilesResponse = " + SaveAssignmentFilesResponse );
        Log.softAssertThat( statusCode1.equalsIgnoreCase( "201" ), "Status code is returned as expected and the same is " + statusCode1, "Status code is not returned as expected and the same is " + statusCode + " Actual - " + statusCode1 );

    }

    public Response SaveAssignmentFiles( HashMap<String, String> header, HashMap<String, String> path ) throws Exception {
        String endPoint = StudentDetailsForGivenTeacherConstants.SAVE_ASSIGNMENT_FILES;
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, path.get( Constants.ASSIGNMENT_USER_ID ) );
        String url = smUrl + endPoint;
        RestAssured.baseURI = smUrl;
        RestAssured.basePath = endPoint;
        Header acceptHeader = new Header( Constants.CONTENT_TYPE, Constants.MULTIPART_FORMDATA_CONTENT_TYPE );
        File file = new File( SMUtils.getPayLoadDirPath() + "smre_ip_00214_s1.zip" );
        httpRequest = RestAssured.given().header( acceptHeader );
        try {
            response = httpRequest.multiPart( "file", file ).headers( header ).when().post( url ).then().extract().response();
        } catch ( Exception e ) {
            // TODO: handle exception
            Log.exception( e );
        }

        return response;

    }

    /**
     * Data provider to give the positive data
     *
     * @return
     */
    @DataProvider ( name = "tcPostiveforSaveAssignmentFilesAPI" )
    public Object[][] tcPostiveforSaveAssignmentFilesAPI() {
        Object[][] inputData = { { "Verify the valid response to save assignment files API", "Skill Reading", CommonAPIConstants.STATUS_CODE_CREATED }, };
        return inputData;
    }

    /**
     * This method is used to select the course based on courseName.
     * 
     * @param studentUserName
     * @param courseName
     */
    public void selectCourse( String studentUserName, String courseName ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        Log.message( "Student username :" + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        SMUtils.nap( 30 );
        StudentDashboardPage studentPage = new StudentDashboardPage( driver );
        studentPage.selectAssignmentByName( courseName );
    }

}