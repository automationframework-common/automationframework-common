package com.savvas.sm.api.tests.smnew.users;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.UpdateStudentProfileConstants;

/**
 * To test the Update Staff Profile API
 * 
 * @author suriya.kumar
 */

public class UpdateStudentProfileAPITest extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    String sessionCookie;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class
    private String orgUsed;
    private String teacherUsed;
    private String orgId;
    private String teacherId;
    private String username;

    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String readingSchoolTeacherUsername;

    // Second Teacher
    private String secondTeacherId;
    private String secondTeacherUsername;

    //Student that is updated
    String updatedStudentId;
    String updatedStudentUsename;

    // Object 
    com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI utilsRepoGroupAPI;

    // Object 
    AtomicReference<String> readingSchool = new AtomicReference<String>();
    AtomicReference<String> schoolUsed = new AtomicReference<String>();
    private long startTime;
    private ArrayList<String> studentIdList;
    private ArrayList<String> studentUserNames;
    GroupAPI groupApi = new GroupAPI();
    private ArrayList<String> teacherGroupNames;
    private ArrayList<String> teacherGroupId;
    private String browser;
    private Object studentDetailsCreate;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() {

        startTime = StopWatch.startTime();
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );

        // Teacher used Details
        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgId = RBSDataSetup.organizationIDs.get( schoolUsed.get() );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        // Getting student details for the Teacher
        ArrayList<String> studentDetails = new ArrayList<String>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<String>();
        studentUserNames = new ArrayList<String>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

        // Getting GroupId of the Teacher
        HashMap<String, String> response = new HashMap<String, String>();
        HashMap<String, String> apiDetails = new HashMap<String, String>();
        try {
            String accessToken = new RBSUtils().getAccessToken( username, password );
            apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            apiDetails.put( GroupConstants.STAFF_ID, teacherId );
            response = groupApi.getGroupListingForTeacherID( smUrl, apiDetails );
            Log.message( "GroupListing respone: " + response.toString() );

            JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
            JSONArray array = jsonObject.getJSONArray( CreateGroupAPIConstants.DATA );

            teacherGroupNames = new ArrayList<String>();
            teacherGroupId = new ArrayList<String>();

            IntStream.range( 0, array.length() ).forEach( iter -> {
                String eachObject = array.getJSONObject( iter ).toString();
                teacherGroupNames.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_NAME ) );
                teacherGroupId.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_ID ) );
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        // Second Teacher for Data Setup purposes
        secondTeacherUsername = "teacher"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String teacherdetailsCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( secondTeacherUsername, orgId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( secondTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
            }
            secondTeacherId = new RBSUtils().getUserIDByUserName( secondTeacherUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Other School Details
        readingSchool.set( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
        readingSchoolId = RBSDataSetup.organizationIDs.get( readingSchool.get() );

        //teacher create       
        readingSchoolTeacherUsername = "teacher"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        readingSchoolTeacherId = null;
        try {
            if ( !new RBSUtils().isUserExits( readingSchoolTeacherUsername, readingSchoolId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( readingSchoolTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( readingSchoolId ) );
            }
            readingSchoolTeacherId = new RBSUtils().getUserIDByUserName( readingSchoolTeacherUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }
    }

    @AfterClass
    public void enofExecution() {
        long totalTime = StopWatch.elapsedTime( startTime );
        long sec = totalTime % 60;
        long min = ( totalTime / 60 ) % 60;
        Log.message( "=====================================================" );
        Log.message( "Update Student Class Ran for : " + min + " minute (s)" + ":" + sec + " seconds (s)" );
    }

    @Test ( priority = 1, description = "Valid 200 Scenarios", dataProvider = "positiveScenarios", groups = { "smoke_test_case", "Smoke UpateStudentDetails001", "UpateStudentDetails", "SMK-52031", "Students", "UpateStudentDetails", "API" } )
    public void tcUpdateStudentDetails_01( String scenario, String description ) throws Exception {

        Log.testCaseInfo( description );

        // Constants
        String studentName = null;
        String studentDetails;
        String studentId = null;
        HashMap<String, String> userDetails = null;
        String accessToken = null;
        String classId = null;
        String groupName = null;
        HashMap<String, String> response = null;
        String orgIdToVerify = null;
        String accessTokenToVerify = null;

        switch ( scenario ) {

            case "VALID_SCENARIO":

                accessToken = new RBSUtils().getAccessToken( username, password );
                SMUtils.logDescriptionTC( " Verify the response code as 200 and valid response body for the same username" );
                SMUtils.logDescriptionTC( " Verify the teacher can able to update the student and its reflected in A&E." );
                SMUtils.logDescriptionTC( " Verify the response code as 200 and valid response body for demographics value set as null." );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                String studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );

                orgIdToVerify = orgId;
                accessTokenToVerify = accessToken;
                updatedStudentId = studentId;
                updatedStudentUsename = studentName;

                break;

            case "STUDENT_SUSPENDED":

                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student"+System.nanoTime()+ "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // Suspend Student
                new RBSUtils().suspendUser( Arrays.asList( studentId ) );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                orgIdToVerify = orgId;
                accessTokenToVerify = accessToken;

                break;

            case "STUDENT_MULTI_ORG":
                accessToken = new RBSUtils().getAccessToken( username, password );
                // Student Creation
                studentName = "multiorgstudent"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId, readingSchoolId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                orgIdToVerify = orgId;
                accessTokenToVerify = accessToken;

                break;

            case "SHARED_STUDENT":
                // Student Creation
                studentName = "sharedstudent" + System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createSharedStudent( studentName, teacherId, new RBSUtils().getAccessToken( username, password ), secondTeacherId, new RBSUtils().getAccessToken( secondTeacherUsername, password ), orgId );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( secondTeacherUsername, secondTeacherId, studentName, studentId );

                orgIdToVerify = orgId;
                accessTokenToVerify = new RBSUtils().getAccessToken( secondTeacherUsername, password );

                break;

            case "STUDENT_ID_EMPTY":
                accessToken = new RBSUtils().getAccessToken( username, password );
                // Student Creation
                studentName = "emptystudent"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, "" );
                orgIdToVerify = orgId;
                accessTokenToVerify = accessToken;
                break;

            case "SPECIAL_CHARACTER":
                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "studentspl"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );

                userDetails.replace( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, "$savasspecial" + System.nanoTime() );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, "$#Firstname" + System.nanoTime() );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, "$&$Lastname" + System.nanoTime() );
                orgIdToVerify = orgId;
                accessTokenToVerify = accessToken;

                break;

            case "BIRTH_DAY_EMPTY":
                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "studentdob"+System.nanoTime() + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, "" );
                orgIdToVerify = orgId;
                accessTokenToVerify = accessToken;
                break;

            default:
                break;
        }

        // Getting response
        response = updateStudentProfile( smUrl, userDetails );

        // Verifying all Details
        VerifyAPI( response, orgIdToVerify, accessTokenToVerify );

        if ( !scenario.equalsIgnoreCase( "BIRTH_DAY_EMPTY" ) ) {
            VerifySchema( CommonAPIConstants.STATUS_CODE_OK, response );
        }
    }

    @Test ( priority = 2, description = "", dataProvider = "negativeScenarios", groups = { "SMK-52031", "Students", "UpateStudentDetails", "API" } )
    public void tcUpdateStudentDetails_02( String scenario, String expCode, String expException, String description ) throws Exception {

        Log.testCaseInfo( description );

        // Constants
        HashMap<String, String> response = null;
        String studentName;
        String studentDetails;
        String studentId = null;
        HashMap<String, String> userDetails = null;
        String accessToken = null;
        String classId;
        String groupName;
        String orgIdToVerify;
        String accessTokenToVerify;

        com.savvas.sm.utils.SMUtils utilsRepoObj = new com.savvas.sm.utils.SMUtils();
        switch ( scenario ) {

            case "STUDENT_AUTH":

                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659246413" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                String studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studentUserNames.get( 0 ), password ) );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, studentIdList.get( 0 ) );

                break;

            case "INVALID_AUTH":

                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659251425" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                break;

            case "STUDENT_DELETED":

                // Student Creation
                studentName = "student11654659262690" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // Deleting Student
                new RBSUtils().deleteUser( Arrays.asList( studentId ) );

                //  update Details
                userDetails = createData( username, teacherId, studentName, studentId );

                break;

            case "INVALID_DOB":
                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659265937" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, "2022-23-4334" );

                break;

            case "INVALID_GRADE":
                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659275442" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, "k" );

                break;

            case "ALREADY_USED_USERNAME":
                SMUtils.logDescriptionTC( "Verify the response code for student updation with invalid values of demographics." );
                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659282657" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // Student Creation
                String otherStudentName = "student" + System.nanoTime();
                createStudentAndResetPassword( orgId, otherStudentName );

                // update Details
                userDetails = createData( username, teacherId, otherStudentName, studentId );

                break;

            case "INVALID_DEMO":
                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659291417" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, studentName, studentId );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, "hkjfhdHJH79" );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, "hkjfhdHJH79" );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, "hkjfhdHJH79" );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, "hkjfhdHJH79" );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, "hkjfhdHJH79" );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, "hkjfhdHJH79" );
                userDetails.replace( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, "hkjfhdHJH79" );

                break;

            case "TEACHER_ID_UPDATE":

                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student1654659299209" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
                studentDetailsCreate = null;
                try {
                    if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                        studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    }
                    studentId = new RBSUtils().getUserIDByUserName( studentName );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                // Enrolling student into the class
                addStudentToGroup( studentName );

                // update Details
                userDetails = createData( username, teacherId, secondTeacherUsername, secondTeacherId );
                break;

            default:
                break;
        }

        // Getting response
        response = updateStudentProfile( smUrl, userDetails );

        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expCode ), "The Status code matched", "The Status code Doesnot matched" );
        Log.assertThat( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.BODY ) ), StudentDetailsForGivenTeacherConstants.EXCEPTION ).get( 0 ).equals( expException ), "The Exception message is matched",
                "The Exception message is not matched" );
    }

    @Test ( priority = 3, description = "Valid with all Data", groups = { "smoke_test_case", "Smoke UpateStudentDetails001", "UpateStudentDetails", "P1", "SMK-52031", "Students", "UpateStudentDetails", "API" } )
    public void tcUpdateStudentDetails_03() throws Exception {

        SMUtils.logDescriptionTC( " Verify the response code as 200 and valid response body for grade as 'Not Specified'" );
        SMUtils.logDescriptionTC( " Verify the response code as 200 and valid response body for Every DemoGraphic Value'" );

        String accessToken = new RBSUtils().getAccessToken( username, password );
        String groupName = "Group_" + System.nanoTime();

        // Student Creation
        String studentName = "alldatastudent"+System.nanoTime()+ "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String studentDetailsCreate = null;
        String studentId = null;
        try {
            if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                studentDetailsCreate = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
            }
            studentId = new RBSUtils().getUserIDByUserName( studentName );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Enrolling student into the class
        addStudentToGroup( studentName );

        // update Details
        Faker randomName = new Faker( new Locale( "en-IN" ) );
        String orgIdToTest = orgId;
        String accessTokenToTest = accessToken;

        HashMap<String, String> userDetails = new HashMap<String, String>();
        userDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHER_USERNAME, username );
        userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        userDetails.put( UserConstants.SCHOOLID, orgId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, studentId );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, teacherId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, studentName );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERPASSWORD_REQBODY, RBSDataSetupConstants.DEFAULT_PASSWORD );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.PERSONID_REQBODY, studentId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, randomName.name().firstName() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.MIDDLENAME_REQBODY, randomName.name().name() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, randomName.name().lastName() );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, getDOB() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, "Id" + studentId );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );

        // Each Grade update 
        StudentDetailsForStudentIdAPIConstants.GRADE_NAME.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // Each Gender update
        StudentDetailsForStudentIdAPIConstants.GENDER_VALUES_API.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // Each Special Services update
        StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES_VALUES.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // Each HAS_ECONONMIC_DISADVANTAGED_ update 
        StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE_VALUES.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // Each English PROFICIENCY update
        StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY_VALUES.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // Each disability update
        StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY_VALUES.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // EAch Migrant update
        StudentDetailsForStudentIdAPIConstants.IS_MIGRANT_VALUES.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

        // Each Ethnicity update
        StudentDetailsForStudentIdAPIConstants.ETHNICITY_VALUES.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            userDetails.replace( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, value );
            HashMap<String, String> resposne = updateStudentProfile( smUrl, data );
            VerifyAPI( resposne, orgIdToTest, accessTokenToTest );
        } );

    }

    @Test ( priority = 2, description = "other fields verification", groups = { "smoke_test_case", "Smoke UpateStudentDetails001", "UpateStudentDetails", "SMK-52031", "Students", "API" }, dependsOnMethods = "tcUpdateStudentDetails_01" )
    public void tcUpdateStudentDetails_04() throws Exception {

        SMUtils.logDescriptionTC( " Verify the response code for student updation without middle name." );
        SMUtils.logDescriptionTC( " Verify the response code for student updation without studentIdentification." );
        SMUtils.logDescriptionTC( " Verify the response code as 200 and valid response body for student updation with special character username." );
        SMUtils.logDescriptionTC( " Verify the teacher can able to update the student username with upper case and able to login." );
        SMUtils.logDescriptionTC( " Verify the response code when the student don't have birthday." );
        SMUtils.logDescriptionTC( " Verify the response when the first name value starts with Special Character in request body" );
        SMUtils.logDescriptionTC( " Verify the response when the last name value starts with Special Character in request body" );
        // special char, empty dob empty sissourceid
        String accessToken = new RBSUtils().getAccessToken( username, password );

        // update Details
        Faker randomName = new Faker();
        String orgIdToTest = orgId;
        String accessTokenToTest = accessToken;
        new RBSUtils().resetPassword( orgId, "password1", teacherId );

        String changedPassword = "student@123$#";
        String changesUsername = "savvas@3$" + System.nanoTime();

        HashMap<String, String> userDetails = new HashMap<String, String>();
        userDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHER_USERNAME, username );
        userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, updatedStudentId );
        userDetails.put( UserConstants.SCHOOLID, orgId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, teacherId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, changesUsername );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERPASSWORD_REQBODY, changedPassword );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.PERSONID_REQBODY, updatedStudentId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, randomName.name().firstName() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.MIDDLENAME_REQBODY, "" );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, randomName.name().lastName() );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, "" );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, "" );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );

        HashMap<String, String> resposne = updateStudentProfile( smUrl, userDetails );

        // Student can Log in changed password
        String studentAccessToken = new RBSUtils().getAccessToken( changesUsername.toLowerCase(), changedPassword );
        Log.assertThat( studentAccessToken != null, "The student can login to successmaker ", "The student cannot able to login to successMakaer" );
    }

    /**
     * It will verify all the details of API of valid scenario
     * 
     * @param response
     * @param orgId
     * @param accessToken
     */
    public void VerifyAPI( HashMap<String, String> response, String orgId, String accessToken ) {

        String actualStatusCode = response.get( Constants.STATUS_CODE );
        JSONObject jsonBody = new JSONObject( response.get( Constants.BODY ) );

        // Verifying Status code
        Log.assertThat( actualStatusCode.equals( com.savvas.sm.utils.constants.CommonAPIConstants.STATUS_CODE_OK ), "The response status code matches for '200' ", "The response code doesnot matches Expected '200' But received: " + actualStatusCode );

        // Verifying Success message
        String actualSuccessMessage = new SMAPIProcessor().getKeyValues( jsonBody, Constants.MESSAGE ).get( 0 );
        Log.assertThat( actualSuccessMessage.equals( CommonAPIConstants.STUDENT_DETAILS_UPDATED_SUCCESS_MESSAGE ), "The success message is matched as 'Student Details updated Successfully'",
                "Success Message is not matched Expectd[] but Actual [" + actualSuccessMessage + "]" );

        // Actual Values
        HashMap<String, String> actualDetails = new HashMap<String, String>();

        actualDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.TEACHERID_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.USERNAME_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.PERSONID_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.PERSONID_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.FIRSTNAME_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.MIDDLENAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.MIDDLENAME_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.LASTNAME_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.GRADE_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.GENDER_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.ISMIGRANT_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.ETHINICITY_REQBODY ).get( 0 ) );
        actualDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY ).get( 0 ) );

        String studentId = new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.PERSONID_REQBODY ).get( 0 );
        String teacherId = new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.TEACHERID_REQBODY ).get( 0 );

        // Expected Values
        HashMap<String, String> studentDetails = getStudentDetailsByStudentId( studentId, teacherId, orgId, accessToken );
        JSONObject jsonStudent = new JSONObject( studentDetails.get( Constants.BODY ) );

        HashMap<String, String> expectedDetails = new HashMap<String, String>();

        try {
            actualDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, new SMAPIProcessor().getKeyValues( jsonBody, UpdateStudentProfileConstants.BIRTHDAY_REQBODY ).get( 0 ).toString() );
            expectedDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.BIRTHDAY_REQBODY ).get( 0 ).toString() );
        } catch ( Exception e ) {
            actualDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, "" );
            expectedDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, "" );

        }

        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.TEACHERID_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.USERNAME_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.PERSONID_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.PERSONID_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.FIRSTNAME_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.MIDDLENAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.MIDDLENAME_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.LASTNAME_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.GRADE_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.GENDER_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.ISMIGRANT_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.ETHINICITY_REQBODY ).get( 0 ) );
        expectedDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, new SMAPIProcessor().getKeyValues( jsonStudent, UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY ).get( 0 ) );

        // Verifying all details
        Log.message( "act:"+actualDetails );
        Log.message( "exp:"+expectedDetails );
        Log.assertThat( new SMUtils().compareTwoHashMap( actualDetails, expectedDetails ), "The details of the Stduent is matched", "The Student Details is not matched " );

    }

    /*
     * /** It will verify the schema
     * 
     * @param StatusCode
     * 
     * @param response
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( FileNameConstatnts.UPDATE_STUDENT_PROFILE_SCHEMA, StatusCode, response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
            Log.assertThat( isValid, "The schema is valid", "The schema is not valid" );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    /**
     * To get the DOB
     * 
     * @return
     */

    public String getDOB() {
        SimpleDateFormat Dobformat = new SimpleDateFormat( "YYYY-MM-dd" );
        Date date = new Faker().date().birthday( 2, 22 );
        return Dobformat.format( date ).toString();
    }

    /**
     * Create HashMap data for student updating
     * 
     * @param username
     * @param teacherId
     * @param studentName
     * @param studentId
     * @return
     * @throws Exception
     */
    public HashMap<String, String> createData( String username, String teacherId, String studentName, String studentId ) throws Exception {

        // update Details
        Faker randomName = new Faker();
        HashMap<String, String> userDetails = new HashMap<String, String>();
        userDetails.put( UserConstants.SCHOOLID, orgId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, studentId );
        userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, teacherId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, studentName );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERPASSWORD_REQBODY, RBSDataSetupConstants.DEFAULT_PASSWORD );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.PERSONID_REQBODY, studentId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, randomName.name().firstName() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.MIDDLENAME_REQBODY, randomName.name().nameWithMiddle() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, randomName.name().lastName() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, getDOB() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, StudentDetailsForStudentIdAPIConstants.GRADE_NAME.get( 3 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, StudentDetailsForStudentIdAPIConstants.GENDER_VALUES_API.get( 1 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES_VALUES.get( 1 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE_VALUES.get( 1 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY_VALUES.get( 1 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY_VALUES.get( 1 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, StudentDetailsForStudentIdAPIConstants.IS_MIGRANT_VALUES.get( 1 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.ETHNICITY_VALUES.get( 2 ) );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, "Id" + studentId );
        return userDetails;
    }

    public String addStudentToGroup( String studentUsername ) {
        HashMap<String, String> groupDetails = new HashMap<String, String>();
        String studentId = null;
        try {
            studentId = new RBSUtils().getUserIDByUserName( studentUsername.toLowerCase() );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group for Student" + studentUsername );
            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );
            String groupId = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup.get( Constants.RESPONSE_BODY ) ), CreateGroupAPIConstants.GROUP_ID ).get( 0 );
            HashMap<String, String> response = new GroupAPI().addStudentToGroup( smUrl, groupDetails, Arrays.asList( studentId ), Arrays.asList( groupId ) );
            Log.message( response.toString() );
            return groupId;
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * Create shared student present in two two teachers group
     * 
     * @param studentName
     * @param teacherId1
     * @param accessCodeOfT1
     * @param teacherId2
     * @param accessCodeOfT2
     * @param orgId
     * @return
     */
    public String createSharedStudent( String studentName, String teacherId1, String accessCodeOfT1, String teacherId2, String accessCodeOfT2, String orgId ) {

        String classId1 = null;
        String classId2 = null;
        try {
            String studentId = new RBSUtils().getUserIDByUserName( studentName );
            HashMap<String, String> groupDetails = new HashMap<String, String>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessCodeOfT1 );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId1 );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group for Student" + studentName );
            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );
            classId1 = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup.get( Constants.RESPONSE_BODY ) ), CreateGroupAPIConstants.GROUP_ID ).get( 0 );
            groupDetails.clear();

            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessCodeOfT1 );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, accessCodeOfT2 );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group for Student" + studentName );
            createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );

            classId2 = new SMAPIProcessor().getKeyValues( new JSONObject( createGroup.get( Constants.RESPONSE_BODY ) ), CreateGroupAPIConstants.GROUP_ID ).get( 0 );

            if ( classId1 != null && classId2 != null ) {
                return studentId;
            } else {
                Log.failsoft( "Error in Creating Shared Student" );
                return null;
            }
        } catch ( Exception e ) {
            return null;
        }

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarios" )
    public Object[][] postiveData() {

        Object[][] inputData = { { "VALID_SCENARIO", "Verify the 200 response code for updating student with valid data" }, { "STUDENT_SUSPENDED", "Verify the response when suspended student is updated" },
                { "STUDENT_ID_EMPTY", "Verify the response when the studentId is empty" }, { "SPECIAL_CHARACTER", "Verify the response when when special charater for names" }, { "BIRTH_DAY_EMPTY", "Verify the response when birthday field is empty" },
                { "SHARED_STUDENT", "Verify the response when the student is shared student" }, { "STUDENT_MULTI_ORG", "Verify the response when the teacher tries to update the student who is a part multiple schools." } };
        return inputData;
    }

    @DataProvider ( name = "negativeScenarios" )
    public Object[][] negativeData() {

        Object[][] inputData = { { "STUDENT_AUTH", CommonAPIConstants.STATUS_CODE_FORBIDDAN, CommonAPIConstants.ACCESS_DENIED_EXCEPTION, "Verify the response code as 403 for student authorization." },
                { "INVALID_AUTH", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, CommonAPIConstants.JAVA_LANG_EXCEPTION, "Verify the 401 response code for valid student with invalid access token" },
                { "STUDENT_DELETED", CommonAPIConstants.STATUS_CODE_OK, CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION, "Verify the error code 400 appears when deleted student is updated" },
                { "INVALID_DOB", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.HTTP_MESSAGE_NOTREADABLE_EXCEPTION, "Verify the response code as 400 and valid response when the student have invalid format of birthday." },
                { "INVALID_GRADE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.HTTP_MESSAGE_NOTREADABLE_EXCEPTION, " Verify the response when the grade has lower case k." },
                { "ALREADY_USED_USERNAME", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.BAD_REQUEST_EXCEPTION, "Verify the response code as 400 while passing already existing username to request body" },
                { "INVALID_DEMO", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.HTTP_MESSAGE_NOTREADABLE_EXCEPTION, "Verify the response code as 400 and valid response body while passing grade >12" },
                { "TEACHER_ID_UPDATE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.BUSINESS_RULE_VIOLATION, "Verify the teacher can not able to update the teacher ID." } };
        return inputData;
    }
}