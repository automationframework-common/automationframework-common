package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AssignmentMasteryLOView extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String teacherDetails;
    private static String studentOne;
    private static String studentTwo;
    private static String studentThree;
    private static String studentFour;
    WebDriver driver;
    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher2" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        studentOne = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" ) );
        studentThree = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student3" ), "data,userName" ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student4" ), "data,userName" ) );
    }

    @Test ( priority = 1, groups = { "SMK-43597", "Assignments", "AssignmentsMasteryLOview" } )
    public void tcAssignmentMasteryDataSetup() throws Exception {

//        WebDriver driver = null;
   		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

        try {
            //Executing math assignments in student dash-board
            //Login as student1 to the executeCourses
//            chromeDriver = WebDriverFactory.get( chromePlatform );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentOne, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 2 ), "100", "2", "15" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            //Login as student2 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage2 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage2 = smStudentLoginPage2.loginToSMasStudent( studentTwo, password, true );
            studentOneDashboardPage2.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 2 ), "25", "3", "10" );
            studentOneDashboardPage2.logout();
            chromeDriver.quit();

            //Login as student3 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		 eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage3 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage3 = smStudentLoginPage3.loginToSMasStudent( studentThree, password, true );
            studentOneDashboardPage3.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 2 ), "20", "8", "10" );
            studentOneDashboardPage3.logout();
            chromeDriver.quit();

            //Login as student4 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage4 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage4 = smStudentLoginPage4.loginToSMasStudent( studentFour, password, true );
            studentOneDashboardPage4.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 2 ), "0", "1", "30" );
            studentOneDashboardPage4.logout();
            chromeDriver.quit();

        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        }

        finally {
            
            
            Log.endTestCase();
            chromeDriver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-42845", "mastery", "masteryLOview" } )
    public void tcAssignmentsMasteryLOViewTest001( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        // Login as Teacher
        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 2 ) );

            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            List<WebElement> masteredProgressBars = masteryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            MasteryDetailsPage masteryDetailsPage = masteryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-14507 TC :01 - Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.assertThat( masteryDetailsPage.getLOColor( browser ).contentEquals( Constants.MasteryUI.LO_ID_COLOR_CODE ), "Teacher is able to see the LO as a blue link",
                    "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-14520 TC :02 - Verify the Teacher can view the assessment details - No of Attempts) of the students based on assignment in the mastery details page corresponding to the LO" );
            Log.assertThat( masteryDetailsPage.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.ATTEMPTS_FIELD ), " " + Constants.MasteryUI.ATTEMPTS_FIELD + " Header is present in the Mastery details page ", "Header not Present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-14520 TC :03 - Verify the Teacher can view the assessment details - Mastery Status of the students based on assignment in the mastery details page corresponding to the LO" );
            Log.assertThat( masteryDetailsPage.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.MASTERY_STATUS_FIELD ), " " + Constants.MasteryUI.MASTERY_STATUS_FIELD + " Header is present in the Mastery details page ", "Header not Present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-14520 TC :04 -  Verify the Teacher can view the assessment details - Students Field  of the students based on assignment in the mastery details page corresponding to the LO" );
            Log.assertThat( masteryDetailsPage.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.STUDENT_FIELD ), " " + Constants.MasteryUI.STUDENT_FIELD + " Header is present in the Mastery details page ", "Header not Present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-14520 TC :05 -  Verify the Teacher can view the assessment details - SKILLS_EVALUATED_FIELD of the students based on assignment in the mastery details page corresponding to the LO" );
            Log.assertThat( masteryDetailsPage.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ), " " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " Header is present in the Mastery details page ", "Header not Present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "SMK-14517,SMK 14518 ,SMK 14519 TC :06 - Verify the teacher able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only irrespective of the number of assignments displayed in the mastery details page" );
            Log.assertThat( !masteryDetailsPage.getNoOfStudentAssessed().isEmpty(), "The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
                    "The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "SMK-14511,SMK 14512 ,SMK 14513 TC :07 - Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only irrespective of the number of assignments displayed in the mastery details page " );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ), "The text is displaying as 'number' Student Assessments for more than one student Assessment ",
                    "The text is displaying as 'number' Student Assessment for more than one student Assessment" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( " SMK-14516 TC :08 - Verify the count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar " );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ),
                    "The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
                    " The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar" );

            SMUtils.logDescriptionTC( "SMK-14508,14509,14510,14517,14518,14519 TC :01 - Verify the total count of students & background color of the mastered/Not mastered/At Risk/Unassessed displayed in the progress bar  " );
            Map<String, Map<String, Integer>> student_Status = masteryDetailsPage.getCountAndColorForAllStatus();
            Log.assertThat( student_Status.get( Constants.MasteryUI.MASTERED ).containsKey( Constants.MasteryUI.MASTERED_COLOR_CODE ), "The 'Mastered' value in the Mastery Status columnn is displayed in green color",
                    "The 'Mastered' value in the Mastery Status columnn is not displayed as green color" );
            Log.assertThat( student_Status.get( Constants.MasteryUI.AT_RISK ).containsKey( Constants.MasteryUI.ATRISK_COLOR_CODE ), "The 'AT Risk' value in the Mastery Status columnn is displayed in Yellow color",
                    "The 'At Risk' value in the Mastery Status columnn is not displayed as Yellow color" );
            Log.assertThat( student_Status.get( Constants.MasteryUI.UNASSESSED ).containsKey( Constants.MasteryUI.UNASSESSED_COLOR_CODE ), "The 'Unassessed' value in the Mastery Status columnn is displayed in Grey color",
                    "The 'Unassessed' value in the Mastery Status columnn is not displayed as grey color" );
            Log.message( "the total count of students & background color of the mastered/Not mastered/At Risk/ Unassessed status in the progress bar is displayed Successfully " );
            Log.testCaseResult();
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

}
