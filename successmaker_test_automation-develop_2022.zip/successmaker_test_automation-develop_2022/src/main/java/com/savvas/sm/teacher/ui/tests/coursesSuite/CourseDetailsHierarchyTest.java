package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class CourseDetailsHierarchyTest extends BaseTest {
    private String tag = "]</b></i></small>";
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String schoolID;
    private String teacherID;
    String teacherDetails;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    String courseFinalName = null;
    String sharedCourse = null;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        studentDetailsThree = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );
    }

    @Test ( description = "Verify the display of all details of a course when viewed in Course Details Page", priority = 1 )
    public void tcSMCourseDetailsHierarchy001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10364: tcSMCourseDetailsHierarchy001 -:Verify the display of all details of a course when viewed in Course Details Page<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickMathCourse();

            // Verify the left side panel shows strands
            coursePage.verifyLeftStrandsDisplayedForMathCourses();

            // Verify the mid panel shows hierarchy
            coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

            // Verify the right panel shows settings
            coursePage.verifySettingsDisplayedForMathCourses();

            // Verify the Skills drop are showing values
            coursePage.clickSkillsDropDown();
            List<WebElement> skillDropdownValues = coursePage.getSkillsDroppdownvalues();
            Log.assertThat( !skillDropdownValues.isEmpty(), "Skills DropDown Values are Listed", "Skills DropDown Values are not Listed" );

            // Verify the Grades drop are showing values
            coursePage.clickGradeDropDown();
            List<WebElement> gradeDropdownValues = coursePage.getGradeDroppdownvalues();
            Log.assertThat( !gradeDropdownValues.isEmpty(), "Grades DropDown Values are Listed", "Grades DropDown Values are not Listed" );

            // Verify Edit/Remove button not present for Math Course
            Log.assertThat( !coursePage.verifyRemoveBtnIsPresent(), "Remove button is not present for a Default Math Course", "Remove button is present" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for a Default course, Standars/Skills label is displayed", priority = 1 )
    public void tcSMCourseDetailsHierarchy002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10365: tcSMCourseDetailsHierarchy002:Verify for a Default course, Standars/Skills label is displayed<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickMathCourse();

            String courseTypeTitle = coursePage.getCourseTypeTitle();
            Log.assertThat( !courseTypeTitle.isEmpty(), "Course Type Title is:" + courseTypeTitle, "No Text is displayed" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if the teacher can view the hierarchy of the selected course", priority = 1 )
    public void tcSMCourseDetailsHierarchy003() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10366: tcSMCourseDetailsHierarchy003:Verify if the teacher can view the hierarchy of the selected course <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE1 );
            coursePage.verifyLeftStrandsDisplayedForMathCourses();
            coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Focus courses if the standard dropdown is displayed with default value", priority = 1 )
    public void tcSMCourseDetailsHierarchy005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10368: tcSMCourseDetailsHierarchy005:Verify for Focus courses if the standard dropdown is displayed with default value <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE1 );
            SMUtils.waitForSpinnertoDisapper( driver );

            // Verify the Skills drop down are showing values
            coursePage.clickSkillsDropDown();
            List<String> skillTexts = coursePage.getSkillsDropdownTextforFocusCourse();
            Log.assertThat( ( skillTexts.size() == 1 ), "For a Focus Course, Standard dropdown is displayed with a default value - " + skillTexts.toString(), "No values displayed in the dropdown" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if all Strand details associated with selected course are displayed in the left  navigation", priority = 1 )
    public void tcSMCourseDetailsHierarchy006() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10369: tcSMCourseDetailsHierarchy006:Verify if all Strand details associated with selected course are displayed in the left  navigation <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickMathCourse();
            coursePage.verifyLeftStrandsDisplayedForMathCourses();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if first strand of the selected course is highlighted by default on page load", priority = 2 )
    public void tcSMCourseDetailsHierarchy007() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10370: tcSMCourseDetailsHierarchy007:Verify if first strand of the selected course is highlighted by default on page load <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickMathCourse();
            String defaultStrand = coursePage.getDefaultFirstStrandValueBeforeClicking();
            Log.assertThat( !defaultStrand.isEmpty(), "By default the first strand: " + defaultStrand + " is selected.", "Default strand is not selected" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher can see the full hierarchy based on left hand strand selection", priority = 2 )
    public void tcSMCourseDetailsHierarchy008() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10371: tcSMCourseDetailsHierarchy008:Verify if teacher can see the full hierarchy based on left hand strand selection<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE4 );
            coursePage.selectLeftStrandForCourses();
            coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher can access LO using LO link", priority = 2 )
    public void tcSMCourseDetailsHierarchy010() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10373: tcSMCourseDetailsHierarchy010:Verify if teacher can access LO using LO link<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE8 );
            coursePage.selectLeftStrandForCourses();
            coursePage.expandTierNode();
            coursePage.clickLO();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher can view LO pdfs using PDF icon", priority = 2 )
    public void tcSMCourseDetailsHierarchy011() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10374: tcSMCourseDetailsHierarchy011:Verify if teacher can view LO pdfs using PDF icon<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickReadingCourse();
            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyPrintIconIsDisplayed() ), "Print PDF Icon is displayed", "Print PDF Icon is displayed" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if 'Remove Course ' button   is displayed for  a course that is unassigned", priority = 3 )
    public void tcSMCourseDetailsHierarchy012() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10375: tcSMCourseDetailsHierarchy012: Verify if 'Remove Course ' button is displayed for  a course that is unassigned <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            String courseName = customCourses.generateRandomCourseName();

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( courseName );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseName );
            Log.assertThat( coursePage.verifyRemoveBtnIsPresent(), "Remove button is displayed for a Custom Course that is Unassigned", "Remove button is not present" );

            // Remove Course
            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseName );
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( courseName ), "Course is deleted successfully", " Course is not deleted" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if 'Remove Course' button is not displayed for a course that is assigned to a student", priority = 3 )
    public void tcSMCourseDetailsHierarchy013() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10376: tcSMCourseDetailsHierarchy013: Verify the display of Remove Course button for an Assigned Custom Course <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            courseFinalName = coursePage.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( courseFinalName );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseFinalName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseFinalName );
            Log.assertThat( !coursePage.verifyRemoveBtnIsPresent(), "Remove button is not displayed for a course that is assigned to a student", "Remove button is present" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher can see the course settings", priority = 3 )
    public void tcSMCourseDetailsHierarchy014() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10377: tcSMCourseDetailsHierarchy014:Verify if teacher can see the course settings <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE1 );
            coursePage.verifyLeftStrandsDisplayedForMathCourses();
            coursePage.verifySettingsDisplayedForMathCourses();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if teacher can edit the settings for unassigned course", priority = 4 )
    public void tcSMCourseDetailsHierarchy015() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10378: tcSMCourseDetailsHierarchy015:Verify if teacher can edit the settings for unassigned course <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            sharedCourse = coursePage.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickMathCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( sharedCourse );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( sharedCourse );
            coursePage.clickEditBtn();
            coursePage.turnOffInitialPlacement();
            coursePage.clickSaveBtn();
            coursePage.clickEditBtn();
            coursePage.turnONInitialPlacement();
            coursePage.clickSaveBtn();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher can edit the settings for assigned course", priority = 4 )
    public void tcSMCourseDetailsHierarchy016() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10379: tcSMCourseDetailsHierarchy016:Verify if teacher can edit the settings for assigned course <small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( sharedCourse );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( sharedCourse );
            Log.assertThat( !coursePage.verifyEditBtnIsPresent(), "Edit button is not present for an Assigned Course", "Edit button is present" );
            SMUtils.logDescriptionTC( "SMK-18797 - TC039_Verify the Teacher who created the course is not able to 'Edit Seetings' of the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if teacher can view LO details", priority = 4 )
    public void tcSMCourseDetailsHierarchy017() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10380: tcSMCourseDetailsHierarchy017:Verify if teacher can view LO details<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE1 );
            coursePage.selectLeftStrandForCourses();
            coursePage.expandTierNode();
            String loDetail = coursePage.getLODetails();
            Log.assertThat( !loDetail.isEmpty(), "LO Details are displayed: " + loDetail, "LO details are not displayed" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher changes the hierarchy options,  the selected hierarchy is updated for the course", priority = 4 )
    public void tcSMCourseDetailsHierarchy004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10367: tcSMCourseDetailsHierarchy004:Verify if teacher changes the hierarchy options,  the selected hierarchy is updated for the course<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String courseNameGivenByTeacher = coursePage.generateRandomCourseName();
            coursePage.createCustomByStandardCourse( courseNameGivenByTeacher, Constants.MATH );
            tHomePage.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseNameGivenByTeacher );
            coursePage.selectLeftStrandForCourses();
            coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

            tHomePage.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseNameGivenByTeacher );
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();

            //verify course is deleted
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( courseNameGivenByTeacher ), "Course is deleted successfully", " Course is not deleted" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher can see status of course", priority = 4 )
    public void tcSMCourseDetailsHierarchy009() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10372: tcSMCourseDetailsHierarchy009:Verify if teacher can see status of course<small><b><i>[" + browser + tag );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String courseNameGivenByTeacher = coursePage.generateRandomCourseName();
            coursePage.createCustomByStandardCourse( courseNameGivenByTeacher, Constants.MATH );
            tHomePage.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseNameGivenByTeacher );
            String strandStatus = coursePage.getStrandStatus();
            Log.assertThat( !strandStatus.isEmpty(), "Teacher can see Strand Status :" + strandStatus, "No status is displayed" );
            coursePage.expandTierNode();
            String loStatus = coursePage.getLOStatus();
            Log.assertThat( !loStatus.isEmpty(), "Teacher can see LO Status :" + loStatus, "No status is displayed" );

            tHomePage.navigateToCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseNameGivenByTeacher );
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();

            //verify course is deleted
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( courseNameGivenByTeacher ), "Course is deleted successfully", " Course is not deleted" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
