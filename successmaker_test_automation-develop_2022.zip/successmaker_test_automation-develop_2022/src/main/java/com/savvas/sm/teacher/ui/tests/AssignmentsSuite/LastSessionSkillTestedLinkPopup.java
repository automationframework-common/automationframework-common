package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.TestDataConstants;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.assignment.SkillTested;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LastSessionSkillTestedLinkPopup {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String username = null;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String studentDetails;
    private String teacherDetails;
    private String assignmentId;
    private String assignmentUserId;
    private static String mathAssignment = Constants.MATH;
    private static String readingAssignment = Constants.READING;
    private static String CustomAssignment = "Math_Settings" + System.nanoTime();
    private static String mathFocusAssignment = Constants.SM_FOCUS_MATH_GRADE_I;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String schoolID;
    private String teacherID;
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    private HashMap<String, String> groupDetails = new HashMap<>();
    String studentSMDetails;
    private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    private String orgId;

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        UserAPI userAPIMethod = new UserAPI();

        studentDetails = RBSDataSetup.getMyStudent( school, username );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Student SM Details
        studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );
        //attend course through student dashboard
     //   attendCourseAsStudent();
        executeSimulator( SMUtils.getKeyValueFromResponse( studentDetails, "userName" ), Constants.MATH, Constants.MATH );
    }

    @Test ( description = "SMK-15121 : TC001_Verify the skill pop up header for Math course in 'Skill Tested' section.", dataProvider = "getMathSkillDataFromAPI", priority = 1 )
    public void tc001_LastSessionMathSkillTested( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc001_LastSessionMathSkillTested: SMK-15121 : TC001_Verify the skill pop up header for Math course in Skill Tested section. <small><b><i>[" + browser + "]</i></b></small>" );

        try {

            // Login to the SM_Application
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate 'CourseWare' tab and select the 'Assignments' option  
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment 
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( mathAssignment );

            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentSMDetails, "data,firstName" ), SMUtils.getKeyValueFromResponse( studentSMDetails, "data,middleName" ),
                    SMUtils.getKeyValueFromResponse( studentSMDetails, "data,lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );

            //Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillName );

            SMUtils.logDescriptionTC( "SMK-15128 : TC008_Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15129 : TC009_Verify the 'Cancel' icon in 'Last session skills popup'" );
            //Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15125_SMK-15126 : TC005_TC006_Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15127 : TC007_Verify the LO name and the description in 'Last session skills popup'" );
            //verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15124 : TC004_Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for Math course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            SMUtils.nap(3);
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15122 : TC002_Verify the Progress bar is displaying with green color in skill pop up for Math course" );
            //Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorMath( skillsTestedPopupList, skillName ), "Progress Bar color is Green", "Progress Bar color is not Green" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15123_SMK-15131 : TC003_TC011_Verify the '% correct' value displays correctly in black color on progress bar in skill pop up for 'Math' course" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextMath( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in black color",
                    "Progress Bar % Correct is not same or is not displayed in black color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver, Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15130 : TC010_Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-15132 : TC012_Verify the skill pop up header for Reading course in 'Skill Tested' section.", dataProvider = "getReadingSkillDataFromAPI", priority = 1 )
    public void tc002_LastSessionReadingSkillTested( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc002_LastSessionReadingSkillTested: SMK-15132 : TC012_Verify the skill pop up header for Reading course in 'Skill Tested' section. <small><b><i>[" + browser + "]</i></b></small>" );

        try {

            // Login to the SM_Application
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate 'CourseWare' tab and select the 'Assignments' option  
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment 
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( readingAssignment );

            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentSMDetails, "data,firstName" ), SMUtils.getKeyValueFromResponse( studentSMDetails, "data,middleName" ),
                    SMUtils.getKeyValueFromResponse( studentSMDetails, "data,lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );

            //Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillName );

            SMUtils.logDescriptionTC( "SMK-15139 : TC019_Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15140 : TC020_Verify the 'Cancel' icon in 'Last session skills popup'" );
            //Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.READING ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15136_SMK-15137 : TC016_TC017_Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15138 : TC018_Verify the LO name and the description in 'Last session skills popup'" );
            //verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15135 : TC015_Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for Reading course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15133 : TC013_Verify the Progress bar is displaying with blue color in skill pop up for Reading course" );
            //Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorRead( skillsTestedPopupList, skillName ), "Progress Bar color is Blue", "Progress Bar color is not blue" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15134_SMK-15142 : TC014_TC022_Verify the '% correct' value displays correctly in white color on progress bar in skill pop up for 'Reading' course" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextRead( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in white color",
                    "Progress Bar % Correct is not same or is not displayed in white color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15141 : TC021_Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-15143 : TC023_Verify the skill pop up header for 'Custom Math/Reading' course in 'Skill Tested' section.", dataProvider = "getCustomSkillDataFromAPI", priority = 1 )
    public void tc003_LastSessionCustomSkillTested( Map<String, String> skillDetails ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc003_LastSessionCustomSkillTested: SMK-15143 : TC023_Verify the skill pop up header for 'Custom Math/Reading' course in 'Skill Tested' section. <small><b><i>[" + browser + "]</i></b></small>" );

        try {

            // Login to the SM_Application
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate 'CourseWare' tab and select the 'Assignments' option  
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment 
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( CustomAssignment );

            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentSMDetails, "data,firstName" ), SMUtils.getKeyValueFromResponse( studentSMDetails, "data,middleName" ),
                    SMUtils.getKeyValueFromResponse( studentSMDetails, "data,lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );

            //Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillName );

            SMUtils.logDescriptionTC( "SMK-15150 : TC030_Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15151 : TC031_Verify the 'Cancel' icon in 'Last session skills popup'" );
            //Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15147_SMK-15148 : TC027_TC028_Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15149 : TC029_Verify the LO name and the description in 'Last session skills popup'" );
            //verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15146 : TC026_Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for 'Custom Math/Reading' course " );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15144 : TC024_Verify the Progress bar is displaying with green color in skill pop up for Math Skill course" );
            //Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorMath( skillsTestedPopupList, skillName ), "Progress Bar color is Green", "Progress Bar color is not Green" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15145_SMK-15153 : TC025_TC033_Verify the '% correct' value displays correctly in black color on progress bar in skill pop up for 'Math' course" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextMath( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in black color",
                    "Progress Bar % Correct is not same or is not displayed in black color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15152 : TC032_Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-15154 : TC034_Verify the skill pop up header for Focus course in 'Skill Tested' section.", dataProvider = "getFocusSkillDataFromAPI", priority = 1 )
    public void tc004_LastSessionFocusSkillTested( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc004_LastSessionFocusSkillTested: SMK-15143 : SMK-15154 : TC034_Verify the skill pop up header for Focus course in 'Skill Tested' section. <small><b><i>[" + browser + "]</i></b></small>" );

        try {

            // Login to the SM_Application
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate 'CourseWare' tab and select the 'Assignments' option  
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment 
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( mathFocusAssignment );

            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentSMDetails, "data,firstName" ), SMUtils.getKeyValueFromResponse( studentSMDetails, "data,middleName" ),
                    SMUtils.getKeyValueFromResponse( studentSMDetails, "data,lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );
            //Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillName );

            SMUtils.logDescriptionTC( "SMK-15161 : TC041_Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15162 : TC042_Verify the 'Cancel' icon in 'Last session skills popup' " );
            //Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15158_SMK-15159 : TC038_TC039_Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15160 : TC040_Verify the LO name and the description in 'Last session skills popup'" );
            //verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15157 : TC037_Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for Focus course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15155 : TC035_Verify the Progress bar is displaying with green color in skill pop up for \"Focus\" course" );
            //Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorMath( skillsTestedPopupList, skillName ), "Progress Bar color is Green", "Progress Bar color is not Green" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15156_SMK-15164 : TC036_TC044_Verify the \"% correct\" value displays correctly in black color on progress bar in skill pop up for \"Focus\" course " );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextMath( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in black color",
                    "Progress Bar % Correct is not same or is not displayed in black color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15163 : TC043_Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "getMathSkillDataFromAPI" )
    public Object[][] getMathSkillDataFromAPI() throws Exception {

        AssignmentAPI assignmentMethod = new AssignmentAPI();
        SkillTested skillTestedMethod = new SkillTested();

        String assignmentByStudent = getAssignmentByStudent( smUrl, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), schoolID, teacherID );

        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( mathAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );

        Boolean lastSessionValue = true;
        String response = skillTestedMethod.postSkillsTestedForAssignment( smUrl, schoolID, teacherID, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), assignmentId, Constants.MATH, assignmentUserId, lastSessionValue,
                new ArrayList<>() ).get( Constants.REPORT_BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    @DataProvider ( name = "getReadingSkillDataFromAPI" )
    public Object[][] getReadingSkillDataFromAPI() throws Exception {

        AssignmentAPI assignmentMethod = new AssignmentAPI();
        SkillTested skillTestedMethod = new SkillTested();

        String assignmentByStudent = getAssignmentByStudent( smUrl, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), schoolID, teacherID );

        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( readingAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );

        Boolean lastSessionValue = true;
        String response = skillTestedMethod.postSkillsTestedForAssignment( smUrl, schoolID, teacherID, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), assignmentId, Constants.READING, assignmentUserId, lastSessionValue,
                new ArrayList<>() ).get( Constants.REPORT_BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;
    }

    @DataProvider ( name = "getCustomSkillDataFromAPI" )
    public Object[][] getCustomSkillDataFromAPI() throws Exception {

        AssignmentAPI assignmentMethod = new AssignmentAPI();
        SkillTested skillTestedMethod = new SkillTested();

        String assignmentByStudent = getAssignmentByStudent( smUrl, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), schoolID, teacherID );

        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( CustomAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );

        Boolean lastSessionValue = true;
        String response = skillTestedMethod.postSkillsTestedForAssignment( smUrl, schoolID, teacherID, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), assignmentId, Constants.MATH, assignmentUserId, lastSessionValue,
                new ArrayList<>() ).get( Constants.REPORT_BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    @DataProvider ( name = "getFocusSkillDataFromAPI" )
    public Object[][] getFocusMathSkillDataFromAPI() throws Exception {

        AssignmentAPI assignmentMethod = new AssignmentAPI();
        SkillTested skillTestedMethod = new SkillTested();

        String assignmentByStudent = getAssignmentByStudent( smUrl, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), schoolID, teacherID );

        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( mathFocusAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );

        Boolean lastSessionValue = true;
        String response = skillTestedMethod.postSkillsTestedForAssignment( smUrl, schoolID, teacherID, token, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), assignmentId, Constants.MATH, assignmentUserId, lastSessionValue,
                new ArrayList<>() ).get( Constants.REPORT_BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    public void attendCourseAsStudent() throws Exception {
    	// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);
        try {
            CourseAPI coursesMethod = new CourseAPI();
            AssignmentAPI assignmentMethod = new AssignmentAPI();
            List<String> studentIdList = new ArrayList<>();
            HashMap<String, String> assignmentDeatilsForNewSchool = new HashMap<>();
            List<String> courseIdsForExistingSchools = new ArrayList<String>();
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
            String mathCourseId = coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherID, schoolID, DataSetupConstants.SETTINGS, CustomAssignment );
            assignmentDeatilsForNewSchool.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            assignmentDeatilsForNewSchool.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
            assignmentDeatilsForNewSchool.put( RBSDataSetupConstants.BEARER_TOKEN, token );

            courseIdsForExistingSchools.add( Constants.MATH_COURSE_ID );
            courseIdsForExistingSchools.add( Constants.READING_COURSE_ID );
            courseIdsForExistingSchools.add( mathCourseId );
            courseIdsForExistingSchools.add( Constants.FOCUS_COURSE_ID );
            assignmentMethod.assignMultipleAssignments( smUrl, assignmentDeatilsForNewSchool, studentIdList, courseIdsForExistingSchools );

            //execute in new way
            String studentDetail = studentDetails;
            Log.message( "Student details hashmap " + studentDetail );
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, "userName" );
            Log.message( "Student username " + studentUsername );
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );
            studentsPage.executeMathCourse( studentUsername, mathAssignment, "100", "1", "1" );
            studentsPage.executeReadingCourse( studentUsername, readingAssignment, "100", "1", "1" );
            studentsPage.executeMathCourse( studentUsername, CustomAssignment, "100", "1", "1" );
            studentsPage.executeMathCourse( studentUsername, mathFocusAssignment, "100", "1", "1" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
            Log.endTestCase();
        }
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	
    	Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "3", "5" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "5" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        }

    }

    /**
     * Get the assignment by student id
     * 
     * @param smUrl
     * @param token
     * @param studentID
     * @param schoolID
     * @param teacherID
     * 
     * @return response
     * 
     * @throws Exception
     */
    public String getAssignmentByStudent( String smUrl, String token, String studentID, String schoolID, String teacherID ) throws Exception {
        try {
            // headers
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, schoolID );

            HashMap<String, String> params = new HashMap<>();
            params.put( "organization-id", schoolID );
            params.put( "staff-id", teacherID );
            params.put( "student-id", studentID );

            // Input Path Parameters
            String endPoint = Constants.GET_ASSIGNMENT_DETAILS_BY_STUDENTID;

            Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint, params );
            return response.getBody().asString();
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void executeSimulator( String studentUsername, String assignmentName, String assignmentType ) throws Exception {
        WebDriver studentDriver = WebDriverFactory.get( browser );
        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        try {
            if ( assignmentType.equals( Constants.MATH ) ) {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Math Course Execution" );
                    try {
                        studentDashboardPage.executeMathCourse( username, assignmentName, "95", "2", "30" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator for Math" );
                    }

                } );

            } else {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Reading Course Execution" );
                    try {
                        studentDashboardPage.executeReadingCourse( username, assignmentName, "100", "2", "15" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator Reading" );
                    }

                } );

            }
        } catch ( Exception e ) {

            Log.message( "Error occurred while running the simulator" );
        }
        studentDriver.quit();
    }


}
