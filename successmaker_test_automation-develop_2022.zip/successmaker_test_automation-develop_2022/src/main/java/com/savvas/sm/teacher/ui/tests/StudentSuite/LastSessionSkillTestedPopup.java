package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentSkillAssesedConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LastSessionSkillTestedPopup extends BaseTest {
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private String teacherDetails;
    private String assignmentId;
    private String teacherId;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String browser;
    private static String username;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    List<String> studentDetailsList = null;

    @BeforeTest
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            String student = RBSDataSetup.getMyStudent( school, username );
            studentDetails.add( student );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify the Last Session skill pop up header for Math course in Student Page.", groups = { "SMK-43904", "lastSessionSkillTested", "studentUsageChart" }, priority = 1 )
    public void tcSMLastSessionSkillTestedPopup001() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkillTestedPopup001: Verify the Last Session skill pop up header for Math course in Student Page<small><b><i>[" + browser + "]</b></i></small>" );
        try {

        	// Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //Assigning Math Course
            CoursesPage navigateToCourseListingPage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            navigateToCourseListingPage.clickMathCourse();
            navigateToCourseListingPage.clickAssignBtn();
            navigateToCourseListingPage.addCourseToGroups();

            //Assigning Reading Course
            navigateToCourseListingPage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            navigateToCourseListingPage.clickReadingCourse();
            navigateToCourseListingPage.clickAssignBtn();
            navigateToCourseListingPage.addCourseToGroups();
            teacherHomePage.topNavBar.signOutfromSM();

            driver.quit();
            attendCourseAsStudent();
         
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            HashMap<String, String> skillDetails = getMathSkillDataFromAPI();
            //Clicking Skill name
            studentsPage.clickSkillNameInSkillTested( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );

            //Verify skill tested popup header
            SMUtils.logDescriptionTC( "SMK-11737 - Verify the skill pop up header for Default Math course in Last Session Skills section" );
            Log.assertThat( studentsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons not displayed properly" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-11740 - Verify the \"Correct attempts / Total attempt\" displays correctly in skill pop up for \"Default Math\" course" );
            SMUtils.logDescriptionTC( "SMK-11741 - Verify the skill name displays correctly on bottom of the progress bar in black bold font for Default Math course" );
            SMUtils.logDescriptionTC( "SMK-11742 - Verify the LO number and the description in 'Last session skills popup' for Default Math course" );
            //verify skill tested popup values
            Log.assertThat( studentsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();
            // Verifying after navigate to LO viewer
            studentsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
                Log.testCaseResult();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Last Session skill pop up header for Reading course in Student Page.", groups = { "SMK-43904", "lastSessionSkillTested", "studentUsageChart" }, priority = 2 )
    public void tcSMLastSessionSkillTestedPopup002() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMLastSessionSkillTestedPopup002: Verify the Last Session skill pop up header for Reading course in Student Page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {

    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( Constants.READING );

            HashMap<String, String> skillDetails = getReadingSkillDataFromAPI();
            //Clicking Skill name
            Log.message( "Expected Skill - " + skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );
            studentsPage.clickSkillNameSkillTested( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );

            //Verify skill tested popup header
            SMUtils.logDescriptionTC( "SMK-11737 - Verify the skill pop up header for Default Reading course in Last Session Skills section" );
            Log.assertThat( studentsPage.verifySkillTestedPopupHeaderAndButtons( Constants.READING ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons not displayed properly" );
            SMUtils.logDescriptionTC( "SMK-11740 - Verify the \"Correct attempts / Total attempt\" displays correctly in skill pop up for \"Default Reading\" course" );
            SMUtils.logDescriptionTC( "SMK-11741 - Verify the skill name displays correctly on bottom of the progress bar in black bold font for Default Reading course" );
            SMUtils.logDescriptionTC( "SMK-11742 - Verify the LO number and the description in 'Last session skills popup' for Default Reading course" );
            //verify skill tested popup values
            Log.assertThat( studentsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();
            // Verifying after navigate to LO viewer
            studentsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
                Log.testCaseResult();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    public HashMap<String, String> getMathSkillDataFromAPI() throws Exception {

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( username, password );
        studentRumbaIds.add( studentIdList.get( 0 ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentIdList.get( 0 ) );
        endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
        endpoint = endpoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) );
        endpoint = endpoint.replace( "{teacherID}", teacherId );
        endpoint = endpoint.replace( "{studentID}", studentIdList.get( 0 ) );

        HashMap<String, String> studnetAssignmentDetailsByStudnetID = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        AtomicReference<String> assignmentUserId = new AtomicReference<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( Constants.MATH ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "assignmentId", index );
                assignmentUserId.set( SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "studentAssignmentId", index ) );
            }
        } );

        HashMap<String, String> apiDetails = new HashMap<>();
        apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
        apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        apiDetails.put( Constants.STUDENT_ID, studentIdList.get( 0 ) );
        apiDetails.put( Constants.ASSIGNMENT_ID, assignmentId );
        apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
        apiDetails.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId.get() );
        apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
        apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );

        HashMap<String, String> studentSkillTested = getLastSessionSkill( apiDetails );

        //getting data from API
        String response = studentSkillTested.get( Constants.BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        return skillDetails;

    }

    public HashMap<String, String> getReadingSkillDataFromAPI() throws Exception {

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";
        Log.message( "username = " + username );
        String token = new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( studentIdList.get( 0 ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentIdList.get( 0 ) );
        endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
        endpoint = endpoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) );
        endpoint = endpoint.replace( "{teacherID}", teacherId );
        endpoint = endpoint.replace( "{studentID}", studentIdList.get( 0 ) );

        HashMap<String, String> studnetAssignmentDetailsByStudnetID = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        AtomicReference<String> assignmentUserId = new AtomicReference<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( Constants.READING ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "assignmentId", index );
                assignmentUserId.set( SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "studentAssignmentId", index ) );
            }
        } );

        HashMap<String, String> apiDetails = new HashMap<>();
        apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
        apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        apiDetails.put( Constants.STUDENT_ID, studentIdList.get( 0 ) );
        apiDetails.put( Constants.ASSIGNMENT_ID, assignmentId );
        apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
        apiDetails.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId.get() );
        apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
        apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );

        HashMap<String, String> studentSkillTested = getLastSessionSkill( apiDetails );

        //getting data from API
        String response = studentSkillTested.get( Constants.BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        JSONObject skillDetailsJson = new JSONObject( response );
        JSONArray skillArray = skillDetailsJson.getJSONArray( "data" );

        Object object = skillArray.get( 0 );
        JSONObject skillDetailsForReading = new JSONObject( object.toString() );

        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, skillDetailsForReading.getString( Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, skillDetailsForReading.get( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ).toString() );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, skillDetailsForReading.get( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ).toString() );

        JSONArray jsonArray = skillDetailsForReading.getJSONArray( Constants.LastSessionSkillTested.LO_DETAILS );
        Object object2 = jsonArray.get( 0 );
        JSONObject loDetailsRead = new JSONObject( object2.toString() );

        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, loDetailsRead.getString( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, loDetailsRead.getString( Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, loDetailsRead.getString( Constants.LastSessionSkillTested.LO_URL ) );

        return skillDetails;

    }

    public HashMap<String, String> getLastSessionSkill( HashMap<String, String> apiDetails ) throws Exception {
        String body = "{" + "\"subjectTypeId\":" + apiDetails.get( StudentSkillAssesedConstants.SUBJECT_TYPE_ID ) + ",\"assignmentUserId\":" + apiDetails.get( Constants.ASSIGNMENT_USER_ID ) + ",\"sessionDates\":"
                + apiDetails.get( StudentSkillAssesedConstants.SESSION_DATES ) + ",\"lastSessionFlag\":" + apiDetails.get( StudentSkillAssesedConstants.LAST_SESSION_FLAG ) + "}";
        Log.message( "body - " + body );

        String endpoint = UserConstants.UserAPIEndPoints.POST_LAST_SESSION_SKILLS_STUDENT_API;

        endpoint = endpoint.replace( Constants.STAFF_ID_VALUE, apiDetails.get( Constants.STAFF_ID_VALUE ) );
        endpoint = endpoint.replace( Constants.STUDENT_ID, apiDetails.get( Constants.STUDENT_ID ) );
        endpoint = endpoint.replace( Constants.ASSIGNMENT_ID, apiDetails.get( Constants.ASSIGNMENT_ID ) );
        endpoint = endpoint.replace( Constants.ORGANIZATION_ID, apiDetails.get( Constants.ORGANIZATION_ID ) );

        Map<String, String> headers = new HashMap<>();

        // headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( UserConstants.USERID, apiDetails.get( Constants.STAFF_ID_VALUE ) );
        headers.put( UserConstants.ORGID, apiDetails.get( Constants.ORGANIZATION_ID ) );

        // Input Params
        HashMap<String, String> params = new HashMap<>();
        HashMap<String, String> response = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, body );
        return response;
    }

    public void attendCourseAsStudent() throws Exception {
        final WebDriver chromeDriver = WebDriverFactory.get( chromePlatform );
        try {
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smLoginPage.loginToSMasStudent( studentUserNames.get( 0 ), password, false );
            studentsPage.executeMathCourse( username, Constants.MATH, "85", "1", "10" );
            studentsPage.executeReadingCourse( username, Constants.READING, "80", "1", "10" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
        }
    }
}