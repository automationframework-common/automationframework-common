package com.savvas.sm.common.utils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

public class CourseExecution {
    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public  void executeCourse( String studentUserName, String courseName, boolean isMath, String percent, String session, String LO ) throws IOException {
        EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
        String smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        String browser = configProperty.getProperty( "BrowserPlatformToRun" );
        WebDriver chromeDriver = null;
        StudentDashboardPage studentsPage = null;
        boolean flagIsExecutionSuccessfull = false;
        try {
            for ( int i = 0; i < 3; i++ ) {
                try {
                    // Get driver
                    chromeDriver = WebDriverFactory.get( browser );
                    LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                    studentsPage = new StudentDashboardPage( chromeDriver );
                    Log.message( "Student username " + studentUserName );
                } catch ( Exception e ) {
                    Log.message( "Issue occurrred at driver creation and Login , reattempting : " + i );
                    continue;
                }
                if ( isMath ) {
                    try {
                        studentsPage.executeMathCourse( studentUserName, courseName, percent, session, LO );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                } else {
                    try {
                        studentsPage.executeReadingCourse( studentUserName, courseName, percent, session, LO );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                }
            }
        } finally {
            if ( flagIsExecutionSuccessfull ) {
                Log.message( "Course executed successfully" );
            } else {
                Log.message( "Course execution failed after reattempting : 3" );
            }
            chromeDriver.quit();

        }

    }
}
